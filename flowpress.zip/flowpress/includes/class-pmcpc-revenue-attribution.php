<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Simple revenue attribution helpers.
 *
 * Designed for the dashboard: fast, low-risk, and works even when premium
 * automation modules are not loaded.
 *
 * Model: "last touch" within a short window — attribute an order to the most
 * recent email event (open/click/view/sent) for the subscriber that occurred
 * before the order, within the attribution window.
 *
 * Directional metric only — not accounting-grade attribution.
 */
class PMCPC_Revenue_Attribution {

    /**
     * Check whether an order already has direct campaign attribution from a tracked subscriber-update product click.
     *
     * @param WC_Order $order WooCommerce order.
     * @return array{campaign_id:int,update_id:int,product_id:int}|array{}
     */
    protected static function get_direct_order_attribution( $order ) {
        if ( ! $order || ! is_object( $order ) ) {
            return array();
        }

        $campaign_id = absint( $order->get_meta( '_pmcpc_attributed_campaign_id', true ) );
        $update_id   = absint( $order->get_meta( '_pmcpc_attributed_update_id', true ) );
        $product_id  = absint( $order->get_meta( '_pmcpc_attributed_product_id', true ) );

        if ( $campaign_id > 0 || $update_id > 0 || $product_id > 0 ) {
            return array(
                'campaign_id' => $campaign_id,
                'update_id'   => $update_id,
                'product_id'  => $product_id,
            );
        }

        return array();
    }


    /**
     * Calculate email-attributed orders & revenue totals.
     *
     * @param int $days Number of days of orders to consider.
     * @param int $attribution_window_days Max age (in days) of an email event before the order.
     * @param int $max_orders Safety limit to avoid heavy loads on large stores.
     * @return array{orders:int,revenue:float}
     */


    /**
     * Calculate last-touch attributed orders and revenue per campaign.
     *
     * Used by the unified Email > Analytics screen so campaign rows can show
     * commercial outcomes alongside email and website engagement.
     *
     * @param int $days Number of days of orders to consider.
     * @param int $attribution_window_days Max age (in days) of an email event before the order.
     * @param int $max_orders Safety limit to avoid heavy loads on large stores.
     * @return array<int,array{orders:int,revenue:float}>
     */
    public static function campaign_totals( $days = 30, $attribution_window_days = 7, $max_orders = 500 ) {
        global $wpdb;

        if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
            return array();
        }

        $days                  = max( 1, absint( $days ) );
        $attribution_window_ts = (int) current_time( 'timestamp' ) - ( absint( $attribution_window_days ) * DAY_IN_SECONDS );
        $orders_since_ts       = (int) current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS );

        $orders = wc_get_orders(
            array(
                'limit'   => max( 1, absint( $max_orders ) ),
                'status'  => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
                'return'  => 'ids',
                'orderby' => 'date',
                'order'   => 'DESC',
            )
        );

        if ( empty( $orders ) ) {
            return array();
        }

        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
        $queue_table       = $wpdb->prefix . 'pmcpc_email_queue';
        $events_table      = $wpdb->prefix . 'pmcpc_email_events';

        $order_rows = array();
        $emails     = array();

        $totals = array();
        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) { continue; }
            if ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) {
                continue;
            }

            $order_ts = $order->get_date_created() ? (int) $order->get_date_created()->getTimestamp() : 0;
            if ( ! $order_ts || $order_ts < $orders_since_ts ) {
                continue;
            }

            $direct = self::get_direct_order_attribution( $order );
            if ( ! empty( $direct['campaign_id'] ) ) {
                $cid = (int) $direct['campaign_id'];
                if ( ! isset( $totals[ $cid ] ) ) {
                    $totals[ $cid ] = array( 'orders' => 0, 'revenue' => 0.0 );
                }
                $totals[ $cid ]['orders']++;
                $totals[ $cid ]['revenue'] += (float) $order->get_total();
                continue;
            }

            $email = strtolower( (string) $order->get_billing_email() );
            if ( '' === $email ) {
                continue;
            }

            $order_rows[] = array(
                'email'     => $email,
                'timestamp' => $order_ts,
                'total'     => (float) $order->get_total(),
            );
            $emails[] = $email;
        }

        if ( empty( $order_rows ) ) {
            return $totals;
        }

        $emails = array_values( array_unique( $emails ) );
        $placeholders = implode( ',', array_fill( 0, count( $emails ), '%s' ) );

        $subscribers = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, email FROM {$subscribers_table} WHERE status = 'active' AND email IN ({$placeholders})",
                $emails
            ),
            ARRAY_A
        );

        if ( empty( $subscribers ) ) {
            return $totals;
        }

        $email_to_subscriber = array();
        foreach ( $subscribers as $row ) {
            $email_to_subscriber[ strtolower( (string) $row['email'] ) ] = (int) $row['id'];
        }

        $subscriber_ids = array_values( array_unique( array_map( 'intval', $email_to_subscriber ) ) );
        if ( empty( $subscriber_ids ) ) {
            return $totals;
        }

        $sid_placeholders = implode( ',', array_fill( 0, count( $subscriber_ids ), '%d' ) );
        $since_mysql      = gmdate( 'Y-m-d H:i:s', $attribution_window_ts );

        $events = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT q.subscriber_id, q.campaign_id, e.created_at
                FROM {$events_table} e
                INNER JOIN {$queue_table} q ON e.queue_id = q.id
                WHERE q.subscriber_id IN ({$sid_placeholders})
                  AND e.created_at >= %s",
                array_merge( $subscriber_ids, array( $since_mysql ) )
            ),
            ARRAY_A
        );

        if ( empty( $events ) ) {
            return $totals;
        }

        $event_index = array();
        foreach ( $events as $ev ) {
            $sid = (int) $ev['subscriber_id'];
            $cid = (int) $ev['campaign_id'];
            if ( $sid <= 0 || $cid <= 0 ) { continue; }

            $ts = strtotime( (string) $ev['created_at'] );
            if ( ! $ts ) { continue; }

            if ( ! isset( $event_index[ $sid ] ) ) { $event_index[ $sid ] = array(); }
            if ( ! isset( $event_index[ $sid ][ $cid ] ) || $ts > $event_index[ $sid ][ $cid ] ) {
                $event_index[ $sid ][ $cid ] = $ts;
            }
        }

        foreach ( $order_rows as $or ) {
            $email = $or['email'];
            if ( ! isset( $email_to_subscriber[ $email ] ) ) { continue; }
            $sid = $email_to_subscriber[ $email ];
            if ( empty( $event_index[ $sid ] ) || ! is_array( $event_index[ $sid ] ) ) { continue; }

            $order_ts = (int) $or['timestamp'];
            $best_campaign = 0;
            $best_ts = 0;
            foreach ( $event_index[ $sid ] as $cid => $ev_ts ) {
                if ( $ev_ts <= $order_ts && $ev_ts >= $attribution_window_ts && $ev_ts > $best_ts ) {
                    $best_ts = $ev_ts;
                    $best_campaign = (int) $cid;
                }
            }

            if ( $best_campaign <= 0 ) {
                continue;
            }

            if ( ! isset( $totals[ $best_campaign ] ) ) {
                $totals[ $best_campaign ] = array(
                    'orders'  => 0,
                    'revenue' => 0.0,
                );
            }

            $totals[ $best_campaign ]['orders']++;
            $totals[ $best_campaign ]['revenue'] += (float) $or['total'];
        }

        return $totals;
    }


    /**
     * Return recent orders attributed to FlowPress campaigns or automations.
     *
     * Uses direct order meta first, then falls back to subscriber email-event matching.
     *
     * @param int $days Number of days of orders to consider.
     * @param int $limit Maximum number of rows to return.
     * @param int $attribution_window_days Max age (in days) of an email event before the order.
     * @param int $max_orders Safety limit to avoid heavy loads on large stores.
     * @return array<int,array<string,mixed>>
     */
    public static function recent_orders( $days = 30, $limit = 8, $attribution_window_days = 7, $max_orders = 300 ) {
        global $wpdb;

        if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
            return array();
        }

        $days                  = max( 1, absint( $days ) );
        $limit                 = max( 1, absint( $limit ) );
        $attribution_window_ts = (int) current_time( 'timestamp' ) - ( absint( $attribution_window_days ) * DAY_IN_SECONDS );
        $orders_since_ts       = (int) current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS );

        $orders = wc_get_orders(
            array(
                'limit'   => max( $limit * 8, absint( $max_orders ) ),
                'status'  => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
                'return'  => 'ids',
                'orderby' => 'date',
                'order'   => 'DESC',
            )
        );

        if ( empty( $orders ) ) {
            return array();
        }

        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
        $queue_table       = $wpdb->prefix . 'pmcpc_email_queue';
        $events_table      = $wpdb->prefix . 'pmcpc_email_events';

        $rows   = array();
        $emails = array();
        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) {
                continue;
            }
            if ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) {
                continue;
            }

            $order_ts = $order->get_date_created() ? (int) $order->get_date_created()->getTimestamp() : 0;
            if ( ! $order_ts || $order_ts < $orders_since_ts ) {
                continue;
            }

            $base_row = array(
                'order_id'           => absint( $order->get_id() ),
                'campaign_id'        => 0,
                'customer'           => trim( $order->get_formatted_billing_full_name() ),
                'email'              => (string) $order->get_billing_email(),
                'date'               => $order_ts ? wp_date( 'Y-m-d H:i', $order_ts ) : '',
                'timestamp'          => $order_ts,
                'total'              => (float) $order->get_total(),
                'attribution_method' => '',
            );

            $direct = self::get_direct_order_attribution( $order );
            if ( ! empty( $direct['campaign_id'] ) ) {
                $base_row['campaign_id']        = (int) $direct['campaign_id'];
                $base_row['attribution_method'] = 'direct';
                $rows[]                         = $base_row;
                continue;
            }

            $email = strtolower( trim( (string) $base_row['email'] ) );
            if ( '' === $email ) {
                continue;
            }

            $base_row['email'] = $email;
            $rows[]            = $base_row;
            $emails[]          = $email;
        }

        if ( empty( $rows ) ) {
            return array();
        }

        $emails              = array_values( array_unique( $emails ) );
        $email_to_subscriber = array();
        $event_index         = array();
        if ( ! empty( $emails ) ) {
            $placeholders = implode( ',', array_fill( 0, count( $emails ), '%s' ) );
            $subscribers  = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, email FROM {$subscribers_table} WHERE status = 'active' AND email IN ({$placeholders})",
                    $emails
                ),
                ARRAY_A
            );

            if ( ! empty( $subscribers ) ) {
                foreach ( $subscribers as $row ) {
                    $email_to_subscriber[ strtolower( (string) $row['email'] ) ] = (int) $row['id'];
                }

                $subscriber_ids = array_values( array_unique( array_map( 'intval', $email_to_subscriber ) ) );
                if ( ! empty( $subscriber_ids ) ) {
                    $sid_placeholders = implode( ',', array_fill( 0, count( $subscriber_ids ), '%d' ) );
                    $since_mysql      = gmdate( 'Y-m-d H:i:s', $attribution_window_ts );
                    $events = $wpdb->get_results(
                        $wpdb->prepare(
                            "SELECT q.subscriber_id, q.campaign_id, e.created_at
                            FROM {$events_table} e
                            INNER JOIN {$queue_table} q ON e.queue_id = q.id
                            WHERE q.subscriber_id IN ({$sid_placeholders})
                              AND e.created_at >= %s",
                            array_merge( $subscriber_ids, array( $since_mysql ) )
                        ),
                        ARRAY_A
                    );

                    if ( ! empty( $events ) ) {
                        foreach ( $events as $ev ) {
                            $sid = (int) $ev['subscriber_id'];
                            $cid = (int) $ev['campaign_id'];
                            $ts  = strtotime( (string) $ev['created_at'] );
                            if ( $sid <= 0 || $cid <= 0 || ! $ts ) {
                                continue;
                            }
                            if ( ! isset( $event_index[ $sid ] ) ) {
                                $event_index[ $sid ] = array();
                            }
                            if ( ! isset( $event_index[ $sid ][ $cid ] ) || $ts > $event_index[ $sid ][ $cid ] ) {
                                $event_index[ $sid ][ $cid ] = $ts;
                            }
                        }
                    }
                }
            }
        }

        foreach ( $rows as $index => $row ) {
            if ( ! empty( $row['campaign_id'] ) ) {
                continue;
            }
            $email = strtolower( trim( (string) $row['email'] ) );
            if ( '' === $email || empty( $email_to_subscriber[ $email ] ) ) {
                unset( $rows[ $index ] );
                continue;
            }
            $sid      = (int) $email_to_subscriber[ $email ];
            $order_ts = (int) $row['timestamp'];
            $best_cid = 0;
            $best_ts  = 0;
            foreach ( (array) ( $event_index[ $sid ] ?? array() ) as $cid => $ev_ts ) {
                if ( $ev_ts <= $order_ts && $ev_ts >= $attribution_window_ts && $ev_ts > $best_ts ) {
                    $best_ts  = $ev_ts;
                    $best_cid = (int) $cid;
                }
            }
            if ( $best_cid <= 0 ) {
                unset( $rows[ $index ] );
                continue;
            }
            $rows[ $index ]['campaign_id']        = $best_cid;
            $rows[ $index ]['attribution_method'] = 'fallback';
        }

        if ( empty( $rows ) ) {
            return array();
        }

        usort(
            $rows,
            static function( $left, $right ) {
                return (int) $right['timestamp'] <=> (int) $left['timestamp'];
            }
        );

        return array_slice( array_values( $rows ), 0, $limit );
    }

    public static function totals( $days = 30, $attribution_window_days = 7, $max_orders = 500 ) {
        global $wpdb;

        if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
            return array( 'orders' => 0, 'revenue' => 0.0 );
        }

        $days                  = max( 1, absint( $days ) );
        $attribution_window_ts = (int) current_time( 'timestamp' ) - ( absint( $attribution_window_days ) * DAY_IN_SECONDS );
        $orders_since_ts       = (int) current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS );

        // Fetch recent orders (ids) using WC API (HPOS-safe).
        $orders = wc_get_orders(
            array(
                'limit'   => max( 1, absint( $max_orders ) ),
                'status'  => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
                'return'  => 'ids',
                'orderby' => 'date',
                'order'   => 'DESC',
            )
        );

        if ( empty( $orders ) ) {
            return array( 'orders' => 0, 'revenue' => 0.0 );
        }

        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
        $queue_table       = $wpdb->prefix . 'pmcpc_email_queue';
        $events_table      = $wpdb->prefix . 'pmcpc_email_events';

        $order_rows = array();
        $emails     = array();

        $direct_total_orders  = 0;
        $direct_total_revenue = 0.0;
        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) { continue; }

            if ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) {
                continue;
            }

            $order_ts = $order->get_date_created() ? (int) $order->get_date_created()->getTimestamp() : 0;
            if ( ! $order_ts || $order_ts < $orders_since_ts ) {
                continue;
            }

            $direct = self::get_direct_order_attribution( $order );
            if ( ! empty( $direct ) ) {
                $direct_total_orders++;
                $direct_total_revenue += (float) $order->get_total();
                continue;
            }

            $email = strtolower( (string) $order->get_billing_email() );
            if ( '' === $email ) {
                continue;
            }

            $total = (float) $order->get_total();

            $order_rows[] = array(
                'email'     => $email,
                'timestamp' => $order_ts,
                'total'     => $total,
            );
            $emails[] = $email;
        }

        if ( empty( $order_rows ) ) {
            return array( 'orders' => (int) $direct_total_orders, 'revenue' => (float) $direct_total_revenue );
        }

        $emails = array_values( array_unique( $emails ) );
        $placeholders = implode( ',', array_fill( 0, count( $emails ), '%s' ) );

        // Map email -> subscriber_id (active only).
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $subscribers = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, email FROM {$subscribers_table} WHERE status = 'active' AND email IN ({$placeholders})",
                $emails
            ),
            ARRAY_A
        );

        if ( empty( $subscribers ) ) {
            return array( 'orders' => (int) $direct_total_orders, 'revenue' => (float) $direct_total_revenue );
        }

        $email_to_subscriber = array();
        foreach ( $subscribers as $row ) {
            $email_to_subscriber[ strtolower( (string) $row['email'] ) ] = (int) $row['id'];
        }

        $subscriber_ids = array_values( array_unique( array_map( 'intval', $email_to_subscriber ) ) );
        if ( empty( $subscriber_ids ) ) {
            return array( 'orders' => (int) $direct_total_orders, 'revenue' => (float) $direct_total_revenue );
        }

        $sid_placeholders = implode( ',', array_fill( 0, count( $subscriber_ids ), '%d' ) );
        $since_mysql      = gmdate( 'Y-m-d H:i:s', $attribution_window_ts );

        // Pull recent events for those subscribers.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $events = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT q.subscriber_id, q.campaign_id, e.created_at
                FROM {$events_table} e
                INNER JOIN {$queue_table} q ON e.queue_id = q.id
                WHERE q.subscriber_id IN ({$sid_placeholders})
                  AND e.created_at >= %s",
                array_merge( $subscriber_ids, array( $since_mysql ) )
            ),
            ARRAY_A
        );

        if ( empty( $events ) ) {
            return array( 'orders' => (int) $direct_total_orders, 'revenue' => (float) $direct_total_revenue );
        }

        // Index most-recent event timestamp per subscriber per campaign.
        $event_index = array(); // subscriber_id => [campaign_id => ts]
        foreach ( $events as $ev ) {
            $sid = (int) $ev['subscriber_id'];
            $cid = (int) $ev['campaign_id'];
            if ( $sid <= 0 || $cid <= 0 ) { continue; }

            $ts = strtotime( (string) $ev['created_at'] );
            if ( ! $ts ) { continue; }

            if ( ! isset( $event_index[ $sid ] ) ) { $event_index[ $sid ] = array(); }
            if ( ! isset( $event_index[ $sid ][ $cid ] ) || $ts > $event_index[ $sid ][ $cid ] ) {
                $event_index[ $sid ][ $cid ] = $ts;
            }
        }

        $total_orders  = 0;
        $total_revenue = 0.0;

        foreach ( $order_rows as $or ) {
            $email = $or['email'];
            if ( ! isset( $email_to_subscriber[ $email ] ) ) { continue; }
            $sid = $email_to_subscriber[ $email ];
            if ( ! isset( $event_index[ $sid ] ) ) { continue; }

            $order_ts = (int) $or['timestamp'];

            $best_ts = 0;
            foreach ( $event_index[ $sid ] as $cid => $ev_ts ) {
                if ( $ev_ts <= $order_ts && $ev_ts >= $attribution_window_ts && $ev_ts > $best_ts ) {
                    $best_ts = $ev_ts;
                }
            }

            if ( ! $best_ts ) { continue; }

            $total_orders++;
            $total_revenue += (float) $or['total'];
        }

        return array(
            'orders'  => (int) ( $direct_total_orders + $total_orders ),
            'revenue' => (float) ( $direct_total_revenue + $total_revenue ),
        );
    }
}
