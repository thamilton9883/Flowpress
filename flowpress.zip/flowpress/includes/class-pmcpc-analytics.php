<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

class PMCPC_Analytics {
	// Table names are built from $wpdb->prefix and are not user-controlled.
	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

    protected static function get_subscriber_update_campaign_stats( $days = 30 ) {
        $days  = max( 1, absint( $days ) );
        $since = (int) current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS );
        $store = function_exists( 'pmcpc_get_subscriber_updates_analytics_store' ) ? pmcpc_get_subscriber_updates_analytics_store() : array();
        $stats = array();

        if ( empty( $store['days'] ) || ! is_array( $store['days'] ) ) {
            return $stats;
        }

        foreach ( $store['days'] as $day_key => $bucket ) {
            $ts = strtotime( $day_key . ' 00:00:00' );
            if ( ! $ts || $ts < $since ) {
                continue;
            }
            if ( empty( $bucket['by_campaign'] ) || ! is_array( $bucket['by_campaign'] ) ) {
                continue;
            }
            foreach ( $bucket['by_campaign'] as $campaign_id => $row ) {
                $campaign_id = (int) $campaign_id;
                if ( $campaign_id <= 0 ) {
                    continue;
                }
                if ( empty( $stats[ $campaign_id ] ) ) {
                    $stats[ $campaign_id ] = array(
                        'views'            => 0,
                        'subscriber_views' => 0,
                        'cta_clicks'       => 0,
                        'unlocks'          => 0,
                        'product_clicks'   => 0,
                    );
                }
                $stats[ $campaign_id ]['views']            += isset( $row['views'] ) ? (int) $row['views'] : 0;
                $stats[ $campaign_id ]['subscriber_views'] += isset( $row['subscriber_views'] ) ? (int) $row['subscriber_views'] : 0;
                $stats[ $campaign_id ]['cta_clicks']       += isset( $row['cta_clicks'] ) ? (int) $row['cta_clicks'] : 0;
                $stats[ $campaign_id ]['unlocks']          += isset( $row['unlocks'] ) ? (int) $row['unlocks'] : 0;
                $stats[ $campaign_id ]['product_clicks']   += isset( $row['product_clicks'] ) ? (int) $row['product_clicks'] : 0;
            }
        }

        return $stats;
    }

    public static function render_page() {
        global $wpdb;

        $campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
        $queue_table     = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
        $events_table    = esc_sql( $wpdb->prefix . 'pmcpc_email_events' );

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filters.
        $campaign_search = isset( $_GET['pmcpc_campaign_search'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_campaign_search'] ) ) : '';
        $campaign_search = trim( $campaign_search );
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filters.
        $campaign_status = isset( $_GET['pmcpc_campaign_status'] ) ? sanitize_key( (string) wp_unslash( $_GET['pmcpc_campaign_status'] ) ) : '';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $campaigns = $wpdb->get_results( "SELECT * FROM $campaigns_table ORDER BY created_at DESC LIMIT 50" );

        if ( ! $campaigns ) {
            echo '<p>' . esc_html__( 'No campaigns found yet.', 'product-mailer-campaigns' ) . '</p>';
            return;
        }

        $status_options = array();
        foreach ( $campaigns as $campaign ) {
            $status_value = isset( $campaign->status ) ? sanitize_key( (string) $campaign->status ) : '';
            if ( '' !== $status_value ) {
                $status_options[ $status_value ] = ucfirst( $status_value );
            }
        }
        ksort( $status_options );
        if ( '' !== $campaign_status && ! isset( $status_options[ $campaign_status ] ) ) {
            $campaign_status = '';
        }

        $filtered_campaigns = array();
        foreach ( $campaigns as $campaign ) {
            $name   = isset( $campaign->name ) ? (string) $campaign->name : '';
            $status = isset( $campaign->status ) ? sanitize_key( (string) $campaign->status ) : '';
            if ( '' !== $campaign_status && $campaign_status !== $status ) {
                continue;
            }
            if ( '' !== $campaign_search ) {
                $haystack = strtolower( $name . ' #' . (int) $campaign->id );
                if ( false === strpos( $haystack, strtolower( $campaign_search ) ) ) {
                    continue;
                }
            }
            $filtered_campaigns[] = $campaign;
        }
        $campaigns = $filtered_campaigns;

        $website_stats   = self::get_subscriber_update_campaign_stats( 30 );
        $revenue_by_camp = class_exists( 'PMCPC_Revenue_Attribution' ) ? PMCPC_Revenue_Attribution::campaign_totals( 30, 7, 500 ) : array();
        $revenue_totals  = class_exists( 'PMCPC_Revenue_Attribution' ) ? PMCPC_Revenue_Attribution::totals( 30, 7, 500 ) : array( 'orders' => 0, 'revenue' => 0.0 );

        $summary = array(
            'web_views'          => 0,
            'subscriber_views'   => 0,
            'unlocks'            => 0,
            'cta_clicks'         => 0,
            'product_clicks'     => 0,
            'attributed_orders'  => isset( $revenue_totals['orders'] ) ? (int) $revenue_totals['orders'] : 0,
            'attributed_revenue' => isset( $revenue_totals['revenue'] ) ? (float) $revenue_totals['revenue'] : 0.0,
        );

        foreach ( $website_stats as $row ) {
            $summary['web_views']        += isset( $row['views'] ) ? (int) $row['views'] : 0;
            $summary['subscriber_views'] += isset( $row['subscriber_views'] ) ? (int) $row['subscriber_views'] : 0;
            $summary['unlocks']          += isset( $row['unlocks'] ) ? (int) $row['unlocks'] : 0;
            $summary['cta_clicks']       += isset( $row['cta_clicks'] ) ? (int) $row['cta_clicks'] : 0;
            $summary['product_clicks']   += isset( $row['product_clicks'] ) ? (int) $row['product_clicks'] : 0;
        }

        echo '<p>' . esc_html__( 'Unified campaign analytics for recent sends, website engagement, and attributed revenue. Store-level revenue remains on the Dashboard → Store Revenue section.', 'product-mailer-campaigns' ) . '</p>';

        echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin:16px 0 18px;">';
        $cards = array(
            array( 'label' => __( 'Website views (30d)', 'product-mailer-campaigns' ), 'value' => number_format_i18n( (int) $summary['web_views'] ) ),
            array( 'label' => __( 'Subscriber views (30d)', 'product-mailer-campaigns' ), 'value' => number_format_i18n( (int) $summary['subscriber_views'] ) ),
            array( 'label' => __( 'Unlocks (30d)', 'product-mailer-campaigns' ), 'value' => number_format_i18n( (int) $summary['unlocks'] ) ),
            array( 'label' => __( 'Website CTA clicks (30d)', 'product-mailer-campaigns' ), 'value' => number_format_i18n( (int) $summary['cta_clicks'] ) ),
            array( 'label' => __( 'Product clicks (30d)', 'product-mailer-campaigns' ), 'value' => number_format_i18n( (int) $summary['product_clicks'] ) ),
            array( 'label' => __( 'Attributed orders (30d)', 'product-mailer-campaigns' ), 'value' => number_format_i18n( (int) $summary['attributed_orders'] ) ),
            array( 'label' => __( 'Attributed revenue (30d)', 'product-mailer-campaigns' ), 'value' => function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( (float) $summary['attributed_revenue'] ) ) : number_format_i18n( (float) $summary['attributed_revenue'], 2 ) ),
        );
        foreach ( $cards as $card ) {
            echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:14px 16px;">';
            echo '<div style="font-size:12px;color:#50575e;margin-bottom:6px;">' . esc_html( $card['label'] ) . '</div>';
            echo '<div style="font-size:24px;font-weight:600;line-height:1.2;">' . esc_html( $card['value'] ) . '</div>';
            echo '</div>';
        }
        echo '</div>';

        echo '<div class="pmcpc-card" style="margin:0 0 14px;padding:14px 16px;">';
        echo '<div style="font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#3858e9;margin-bottom:12px;">' . esc_html__( 'Table filters', 'product-mailer-campaigns' ) . '</div>';
        echo '<form method="get" class="pmcpc-table-toolbar" style="margin:0;padding:0;background:transparent;border:0;box-shadow:none;">';
        echo '<input type="hidden" name="page" value="pmcpc_email" />';
        echo '<input type="hidden" name="pmcpc_tab" value="analytics" />';
        echo '<input type="hidden" name="tab" value="analytics" />';
        echo '<div class="pmcpc-table-toolbar__group">';
        echo '<label class="screen-reader-text" for="pmcpc_analytics_campaign_status">' . esc_html__( 'Campaign status', 'product-mailer-campaigns' ) . '</label>';
        echo '<select id="pmcpc_analytics_campaign_status" name="pmcpc_campaign_status">';
        echo '<option value="">' . esc_html__( 'All statuses', 'product-mailer-campaigns' ) . '</option>';
        foreach ( $status_options as $status_key => $status_label ) {
            echo '<option value="' . esc_attr( $status_key ) . '"' . selected( $campaign_status, $status_key, false ) . '>' . esc_html( $status_label ) . '</option>';
        }
        echo '</select>';
        echo '<label class="screen-reader-text" for="pmcpc_analytics_campaign_search">' . esc_html__( 'Search campaigns', 'product-mailer-campaigns' ) . '</label>';
        echo '<input id="pmcpc_analytics_campaign_search" type="text" name="pmcpc_campaign_search" value="' . esc_attr( $campaign_search ) . '" placeholder="' . esc_attr__( 'Search campaign name…', 'product-mailer-campaigns' ) . '" style="min-width:240px;" />';
        echo '<button type="submit" class="button">' . esc_html__( 'Filter', 'product-mailer-campaigns' ) . '</button>';
        if ( '' !== $campaign_status || '' !== $campaign_search ) {
            echo '<a class="button button-secondary" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=analytics&tab=analytics' ) ) . '">' . esc_html__( 'Clear', 'product-mailer-campaigns' ) . '</a>';
        }
        echo '</div>';
        echo '</form>';
        echo '<p class="description" style="margin:10px 0 0;">' . esc_html__( 'Filter the reporting table by campaign name or status.', 'product-mailer-campaigns' ) . '</p>';
        echo '</div>';

        echo '<style>
        .pmcpc-analytics-table-wrap{margin-top:12px;background:#fff;border:1px solid #dcdcde;border-radius:12px;overflow:hidden;}
        .pmcpc-analytics-table-wrap__scroll{overflow-x:auto;overflow-y:hidden;max-width:100%;-webkit-overflow-scrolling:touch;scrollbar-gutter:stable both-edges;padding-bottom:2px;}
        .pmcpc-analytics-table{width:max-content;min-width:100%;table-layout:auto;}
        .pmcpc-analytics-table col.pmcpc-analytics-col-campaign{width:320px;}
        .pmcpc-analytics-table col.pmcpc-analytics-col-status{width:110px;}
        .pmcpc-analytics-table col.pmcpc-analytics-col-metric{width:88px;}
        .pmcpc-analytics-table col.pmcpc-analytics-col-rate{width:96px;}
        .pmcpc-analytics-table col.pmcpc-analytics-col-engagement{width:108px;}
        .pmcpc-analytics-table col.pmcpc-analytics-col-revenue{width:110px;}
        .pmcpc-analytics-table th,.pmcpc-analytics-table td{vertical-align:top;}
        .pmcpc-analytics-table thead th{white-space:nowrap;}
        .pmcpc-analytics-table .pmcpc-table-record__title{font-weight:600;}
        .pmcpc-analytics-table .pmcpc-table-record__meta{margin-top:4px;}
        .pmcpc-analytics-table .pmcpc-col-compare,.pmcpc-analytics-table .pmcpc-col-metric{text-align:center;}
        .pmcpc-analytics-table .pmcpc-col-anchor{text-align:left;}
        </style>';
        echo '<div class="pmcpc-analytics-table-wrap pmcpc-table-wrap"><div class="pmcpc-analytics-table-wrap__scroll pmcpc-table-wrap__scroll">';
        echo '<table class="widefat striped pmcpc-wide-table pmcpc-analytics-table">';
        echo '<colgroup>';
        echo '<col class="pmcpc-analytics-col-campaign" />';
        echo '<col class="pmcpc-analytics-col-status" />';
        echo '<col class="pmcpc-analytics-col-metric" />';
        echo '<col class="pmcpc-analytics-col-metric" />';
        echo '<col class="pmcpc-analytics-col-metric" />';
        echo '<col class="pmcpc-analytics-col-rate" />';
        echo '<col class="pmcpc-analytics-col-metric" />';
        echo '<col class="pmcpc-analytics-col-rate" />';
        echo '<col class="pmcpc-analytics-col-metric" />';
        echo '<col class="pmcpc-analytics-col-engagement" />';
        echo '<col class="pmcpc-analytics-col-engagement" />';
        echo '<col class="pmcpc-analytics-col-metric" />';
        echo '<col class="pmcpc-analytics-col-engagement" />';
        echo '<col class="pmcpc-analytics-col-engagement" />';
        echo '<col class="pmcpc-analytics-col-metric" />';
        echo '<col class="pmcpc-analytics-col-revenue" />';
        echo '</colgroup>';
        echo '<thead><tr>';
        echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Queued', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Sent', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Opens', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Open rate', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Clicks', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Click rate', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Unsubs', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Web views', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Subscriber views', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Unlocks', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'CTA clicks', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Product clicks', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-metric">' . esc_html__( 'Orders', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Revenue', 'product-mailer-campaigns' ) . '</th>';
        echo '</tr></thead><tbody>';

        if ( empty( $campaigns ) ) {
            echo '<tr><td colspan="16"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'No campaigns match the current table filters.', 'product-mailer-campaigns' ) . '</span></div></td></tr>';
        } else {
            foreach ( $campaigns as $campaign ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $total = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM $queue_table WHERE campaign_id = %d",
                        $campaign->id
                    )
                );

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $sent = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM $queue_table WHERE campaign_id = %d AND status = %s",
                        $campaign->id,
                        'sent'
                    )
                );

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $opens = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(DISTINCT e.queue_id)
                         FROM $events_table e
                         INNER JOIN $queue_table q ON q.id = e.queue_id
                         WHERE q.campaign_id = %d AND e.event_type = %s",
                        $campaign->id,
                        'opened'
                    )
                );

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $clicks = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(DISTINCT e.queue_id)
                         FROM $events_table e
                         INNER JOIN $queue_table q ON q.id = e.queue_id
                         WHERE q.campaign_id = %d AND e.event_type = %s",
                        $campaign->id,
                        'clicked'
                    )
                );

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $unsubs = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(DISTINCT e.queue_id)
                         FROM $events_table e
                         INNER JOIN $queue_table q ON q.id = e.queue_id
                         WHERE q.campaign_id = %d AND e.event_type = %s",
                        $campaign->id,
                        'unsubscribed'
                    )
                );

                $web_row          = isset( $website_stats[ (int) $campaign->id ] ) ? $website_stats[ (int) $campaign->id ] : array();
                $web_views        = isset( $web_row['views'] ) ? (int) $web_row['views'] : 0;
                $subscriber_views = isset( $web_row['subscriber_views'] ) ? (int) $web_row['subscriber_views'] : 0;
                $unlocks          = isset( $web_row['unlocks'] ) ? (int) $web_row['unlocks'] : 0;
                $web_cta_clicks   = isset( $web_row['cta_clicks'] ) ? (int) $web_row['cta_clicks'] : 0;
                $product_clicks   = isset( $web_row['product_clicks'] ) ? (int) $web_row['product_clicks'] : 0;
                $rev_row          = isset( $revenue_by_camp[ (int) $campaign->id ] ) ? $revenue_by_camp[ (int) $campaign->id ] : array( 'orders' => 0, 'revenue' => 0.0 );
                $open_rate        = $sent > 0 ? round( ( $opens / $sent ) * 100, 1 ) . '%' : '–';
                $click_rate       = $sent > 0 ? round( ( $clicks / $sent ) * 100, 1 ) . '%' : '–';

                echo '<tr>';
                echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( $campaign->name ) . '</span><span class="pmcpc-table-record__meta">#' . esc_html( (string) $campaign->id ) . '</span></div></td>';
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $campaign->status ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $total ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $sent ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $opens ) . '</span></div></td>';
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $open_rate ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $clicks ) . '</span></div></td>';
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $click_rate ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $unsubs ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $web_views ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $subscriber_views ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $unlocks ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $web_cta_clicks ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $product_clicks ) . '</span></div></td>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( (int) $rev_row['orders'] ) . '</span></div></td>';
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( (float) $rev_row['revenue'] ) ) : number_format_i18n( (float) $rev_row['revenue'], 2 ) ) . '</span></div></td>';
                echo '</tr>';
            }
        }

        echo '</tbody></table>';
        echo '</div></div>';
    }
}
