<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once PMCPC_PLUGIN_DIR . 'includes/tracking/traits/trait-pmcpc-tracking-methods.php';

/**
 * Tracking controller.
 *
 * Transitional implementation: uses the existing trait while providing an
 * instance-based API for DI and testing.
 */
class PMCPC_Tracking_Controller {
    use PMCPC_Tracking_Methods_Trait;
}
