<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Tracking implementation (split out of the facade class).
 */
trait PMCPC_Tracking_Methods_Trait {

    /**
     * Cached schema checks (per request) to avoid repeated SHOW COLUMNS calls.
     */
    protected static $subscriber_has_lifetime_cols   = null;
    protected static $subscriber_has_engagement_cols = null;

    /**
     * Verify a tracking token for public endpoints.
     *
     * These endpoints are called from email clients (logged-out users), so WordPress nonces
     * are not suitable. We validate using the per-email queue token instead.
     *
     * @param int    $queue_id Queue ID.
     * @param string $token    Token.
     * @return bool|int False if invalid. If queue_id is 0, returns resolved queue_id on success.
     */
    protected static function verify_request_token( $queue_id, $token ) {
        $queue_id = absint( $queue_id );
        $token    = (string) $token;
        if ( '' === $token ) {
            return false;
        }

        // If a queue_id is provided, ensure the token matches that queue.
        if ( $queue_id ) {
            return (bool) ( self::does_queue_have_view_token( $queue_id, $token ) || self::is_valid_view_token( $queue_id, $token ) );
        }

        // Otherwise, allow resolving by token.
        $resolved = self::get_queue_id_by_view_token( $token );
        return $resolved ? absint( $resolved ) : false;
    }

    /**
     * Decode a base64+urlencoded URL parameter safely.
     *
     * @param string $param   Raw param value.
     * @param string $default Default URL.
     * @return string Safe URL.
     */
    protected static function decode_target_url_param( $param, $default ) {
        $target_url = $default;
        $param      = (string) $param;

        if ( '' === $param ) {
            return $target_url;
        }

        $decoded = base64_decode( rawurldecode( $param ), true );
        if ( false === $decoded ) {
            return $target_url;
        }

        $decoded = esc_url_raw( (string) $decoded );
        if ( empty( $decoded ) || ! wp_http_validate_url( $decoded ) ) {
            return $target_url;
        }

        $safe = esc_url_raw( $decoded );
        if ( ! empty( $safe ) ) {
            $target_url = $safe;
        }

        return $target_url;
    }

    /**
     * Admin-ajax endpoint: record an open and return a 1x1 png.
     */
    public static function ajax_open() {
        // Public tracking endpoint.
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $queue_id = isset( $_GET['queue_id'] ) ? absint( wp_unslash( $_GET['queue_id'] ) ) : 0;
        $token    = isset( $_GET['token'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['token'] ) ) : '';
        if ( ! self::verify_request_token( $queue_id, $token ) ) {
            self::output_tracking_pixel();
            exit;
        }
        if ( $queue_id ) {
            self::record_event_once( $queue_id, 'opened' );
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        self::output_tracking_pixel();
        exit;
    }

    /**
     * Admin-ajax endpoint: record a click and redirect.
     */
    public static function ajax_click() {
        // Public tracking endpoint.
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $queue_id     = isset( $_GET['queue_id'] ) ? absint( wp_unslash( $_GET['queue_id'] ) ) : 0;
        $token        = isset( $_GET['token'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['token'] ) ) : '';
        $token_valid  = self::verify_request_token( $queue_id, $token );
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Base64 URL is validated after decoding.
        $url_param    = isset( $_GET['url'] ) ? wp_unslash( $_GET['url'] ) : '';

        $target_url = self::decode_target_url_param( $url_param, home_url( '/' ) );

        if ( $queue_id && $token_valid ) {
            self::record_event_once( $queue_id, 'clicked' );
            self::store_click_attribution_cookie( $queue_id );
        }

        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        wp_safe_redirect( $target_url );
        exit;
    }

    /**
     * Admin-ajax endpoint: unsubscribe.
     */
    public static function ajax_unsub() {
        // Public tracking endpoint.
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $queue_id = isset( $_GET['queue_id'] ) ? absint( wp_unslash( $_GET['queue_id'] ) ) : 0;
        $token    = isset( $_GET['token'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['token'] ) ) : '';
        if ( ! self::verify_request_token( $queue_id, $token ) ) {
            wp_die( esc_html__( 'Invalid unsubscribe link.', 'product-mailer-campaigns' ) );
        }
        self::handle_unsubscribe( $queue_id, $token );
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        exit;
    }

    /**
     * Admin-ajax endpoint: "view in browser".
     */
    public static function ajax_view() {
        // Public tracking endpoint.
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $queue_id = isset( $_GET['queue_id'] ) ? absint( wp_unslash( $_GET['queue_id'] ) ) : 0;
        $token    = isset( $_GET['token'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['token'] ) ) : '';
        if ( ! self::verify_request_token( $queue_id, $token ) ) {
            wp_die( esc_html__( 'Invalid view link.', 'product-mailer-campaigns' ) );
        }

        if ( '' === $token ) {
            wp_die( esc_html__( 'Invalid view link.', 'product-mailer-campaigns' ) );
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        $resolved_queue_id = 0;

        // 1) Back-compat: if queue_id is present, accept either deterministic token OR stored random view_token.
        if ( $queue_id ) {
            if ( self::is_valid_view_token( $queue_id, $token ) || self::does_queue_have_view_token( $queue_id, $token ) ) {
                $resolved_queue_id = $queue_id;
            }
        }

        // 2) Preferred: resolve by stored token only.
        if ( ! $resolved_queue_id ) {
            $resolved_queue_id = self::get_queue_id_by_view_token( $token );
        }

        if ( ! $resolved_queue_id ) {
            self::record_event_log( $queue_id ? $queue_id : 0, 'view_invalid' );
            wp_die( esc_html__( 'Invalid view link.', 'product-mailer-campaigns' ) );
        }

        $html = self::get_queue_html( $resolved_queue_id );
        if ( '' === $html ) {
            wp_die( esc_html__( 'This email could not be loaded.', 'product-mailer-campaigns' ) );
        }

        self::record_event_once( $resolved_queue_id, 'viewed' );

        // Hard no-cache.
        self::send_no_cache_headers();

        header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
        echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    /**
     * Query-var handler endpoints (non-ajax).
     */
    public static function handle_requests() {
        // Public tracking endpoints are accessed from email clients and third-party sites.
        // Validate using the per-email token (nonces are not suitable for logged-out users).
        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        if ( isset( $_GET['pmcpc_open'] ) ) {
            $queue_id = absint( wp_unslash( $_GET['pmcpc_open'] ) );
            $token    = isset( $_GET['token'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['token'] ) ) : '';
            if ( $queue_id && ! self::verify_request_token( $queue_id, $token ) ) {
                self::output_tracking_pixel();
                exit;
            }
            if ( $queue_id ) {
                self::record_event_once( $queue_id, 'opened' );
            }
            self::output_tracking_pixel();
            exit;
        }

        if ( isset( $_GET['pmcpc_click'] ) ) {
            $queue_id    = absint( wp_unslash( $_GET['pmcpc_click'] ) );
            $token       = isset( $_GET['token'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['token'] ) ) : '';
            $token_valid = ( $queue_id ? self::verify_request_token( $queue_id, $token ) : false );

            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Base64 URL is validated after decoding.
            $url_param = isset( $_GET['pmcpc_url'] ) ? wp_unslash( $_GET['pmcpc_url'] ) : '';

            $target_url = self::decode_target_url_param( $url_param, home_url( '/' ) );

            if ( $queue_id && $token_valid ) {
                self::record_event_once( $queue_id, 'clicked' );
                self::store_click_attribution_cookie( $queue_id );
            }

            wp_safe_redirect( $target_url );
            exit;
        }

        if ( isset( $_GET['pmcpc_unsub'] ) ) {
            $queue_id = absint( wp_unslash( $_GET['pmcpc_unsub'] ) );
            $token    = isset( $_GET['token'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['token'] ) ) : '';
            if ( $queue_id && ! self::verify_request_token( $queue_id, $token ) ) {
                wp_die( esc_html__( 'Invalid unsubscribe link.', 'product-mailer-campaigns' ) );
            }
            self::handle_unsubscribe( $queue_id, $token );
            exit;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
    }

    // ============================
    // The remainder of the original class follows (DB + helpers)
    // ============================



    /**
     * Cron task: delete old raw tracking logs.
     */
    public static function cleanup_tracking_logs() {
        // Only keep logs when debug is enabled.
        if ( class_exists( 'PMCPC_Settings' ) && 'yes' !== PMCPC_Settings::get( 'tracking_debug', 'no' ) ) {
            return;
        }

        global $wpdb;
        $logs_table = esc_sql( $wpdb->prefix . 'pmcpc_email_event_logs' );

        // If table doesn't exist, skip.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $logs_table ) );
        if ( $exists !== $logs_table ) {
            return;
        }

        // Default retention: 90 days.
        $days = 90;
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query(
            $wpdb->prepare(
				/* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
                "DELETE FROM $logs_table WHERE created_at < %s",
                $cutoff
            )
        );
    }

    
    /**
     * Build the public preferences centre URL for a queue recipient (token-based).
     *
     * @param int $queue_id Queue row id.
     * @param string $anchor Optional anchor (e.g. '#pmcpc-unsubscribe').
     * @return string
     */
    private static function get_preferences_url_for_queue( $queue_id, $anchor = '' ) {
        $email = self::get_queue_recipient_email( (int) $queue_id );
        if ( ! $email ) {
            return '';
        }

        $token = self::issue_preferences_token( $email );
        if ( ! $token ) {
            return '';
        }

        $base = apply_filters( 'pmcpc_preferences_page_url', home_url( '/manage-preferences/' ) );
        $url  = add_query_arg( array( 'pmcpc_token' => $token ), $base );

        if ( $anchor ) {
            $url .= $anchor;
        }

        return $url;
    }

    /**
     * Create a signed preferences token for an email address.
     *
     * Matches PMCPC_Preferences_Center token format.
     *
     * @param string $email Email address.
     * @return string
     */
    private static function issue_preferences_token( $email ) {
        $email = sanitize_email( (string) $email );
        if ( '' === $email ) {
            return '';
        }
        $exp  = time() + ( WEEK_IN_SECONDS * 2 );
        $data = strtolower( $email ) . '|' . $exp;
        $sig  = hash_hmac( 'sha256', $data, wp_salt( 'auth' ) );
        return rtrim( strtr( base64_encode( $data . '|' . $sig ), '+/', '-_' ), '=' );
    }

    /**
     * Get recipient email for a queue item.
     *
     * @param int $queue_id Queue row id.
     * @return string
     */
    private static function get_queue_recipient_email( $queue_id ) {
        global $wpdb;
        $queue_id = (int) $queue_id;
        if ( $queue_id <= 0 ) {
            return '';
        }

        $queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
        $email_column = 'subscriber_email';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$queue_table}", 0 );
        if ( is_array( $columns ) ) {
            if ( in_array( 'subscriber_email', $columns, true ) ) {
                $email_column = 'subscriber_email';
            } elseif ( in_array( 'to_email', $columns, true ) ) {
                $email_column = 'to_email';
            } else {
                return '';
            }
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $email = $wpdb->get_var( $wpdb->prepare( "SELECT {$email_column} FROM {$queue_table} WHERE id = %d", $queue_id ) );
        return sanitize_email( (string) $email );
    }

public static function add_tracking_to_html( $html, $queue_id, $view_token = '' ) {
        $token = ( $view_token ? $view_token : self::make_view_token( $queue_id ) );
        // Use admin-ajax endpoints to avoid page caches/CDNs serving cached HTML
        // (which can prevent WordPress from executing and recording events).
        
        // One-click unsubscribe (admin-ajax endpoint).
        $one_click_unsubscribe_url = add_query_arg(
            array(
                'action'   => 'pmcpc_unsub',
                'queue_id' => $queue_id,
                'token'    => $token,
            ),
            admin_url( 'admin-ajax.php' )
        );

        // Soft unsubscribe: send users to the preferences centre first.
        $prefs_url = self::get_preferences_url_for_queue( $queue_id, '' );
        $prefs_unsub_url = self::get_preferences_url_for_queue( $queue_id, '#pmcpc-unsubscribe' );

        // Backwards-compatible placeholder: now points to the soft unsubscribe flow.
        if ( $prefs_unsub_url ) {
            $html = str_replace( '{{unsubscribe_url}}', esc_url_raw( $prefs_unsub_url ), $html );
        } else {
            $html = str_replace( '{{unsubscribe_url}}', esc_url_raw( $one_click_unsubscribe_url ), $html );
        }

        // Optional placeholder for one-click unsubscribe, if themes/templates want it.
        $html = str_replace( '{{one_click_unsubscribe_url}}', esc_url_raw( $one_click_unsubscribe_url ), $html );
// View in browser (fallback when images are blocked).
        $view_url = add_query_arg(
            array(
                'action'     => 'pmcpc_view',
                'queue_id'   => $queue_id,
                'token'      => $token,
            ),
            admin_url( 'admin-ajax.php' )
        );

        $html = str_replace( '{{view_in_browser_url}}', esc_url_raw( $view_url ), $html );

        // If the template doesn't include a placeholder, inject a small "View in browser" link.
        if ( false === strpos( $html, '{{view_in_browser_url}}' ) && false === stripos( $html, 'action=pmcpc_view' ) ) {
            $view_link = '<p style="margin:0 0 12px 0;font-size:12px;line-height:1.4;">'
                . '<a href="' . esc_url_raw( $view_url ) . '" target="_blank" rel="noopener">'
                . esc_html__( 'View in browser', 'product-mailer-campaigns' )
                . '</a>'
                . '</p>';

            // Put it near the top of the email.
            if ( stripos( $html, '<body' ) !== false ) {
                // Insert right after the first <body ...> tag.
                $html = preg_replace( '/<body([^>]*)>\s*/i', '<body$1>' . $view_link, $html, 1 );
            } else {
                $html = $view_link . $html;
            }
        }

        // Cache-busted open pixel.
        $open_url = add_query_arg(
            array(
                'action'     => 'pmcpc_open',
                'queue_id'   => $queue_id,
                'token'      => $token,
                't'        => wp_rand( 100000, 999999 ),
            ),
            admin_url( 'admin-ajax.php' )
        );

        $open_img = '<img src="' . esc_url( $open_url ) . '" width="1" height="1" style="display:none;" alt="" />';

        if ( stripos( $html, '</body>' ) !== false ) {
            $html = str_ireplace( '</body>', $open_img . '</body>', $html );
        } else {
            $html .= $open_img;
        }

        $html = preg_replace_callback(
            '/href=(["\'])([^"\']+)(["\'])/i',
            function( $matches ) use ( $queue_id, $token ) {
                $quote = $matches[1];
                $url   = $matches[2];

                if ( stripos( $url, 'mailto:' ) === 0 ) {
                    return $matches[0];
                }

                if ( strpos( $url, 'pmcpc_unsub=' ) !== false ) {
                    return $matches[0];
                }

                $encoded = rawurlencode( base64_encode( $url ) );
                $redirect_url = add_query_arg(
                    array(
                        'action'   => 'pmcpc_click',
                        'queue_id' => $queue_id,
                        'url'      => $encoded,
                        'token'    => $token,
                        't'        => wp_rand( 100000, 999999 ),
                    ),
                    admin_url( 'admin-ajax.php' )
                );

                return 'href=' . $quote . esc_url( $redirect_url ) . $quote;
            },
            $html
        );

        return $html;
    }

    protected static function handle_unsubscribe( $queue_id, $token = '' ) {
        if ( ! $queue_id || empty( $token ) ) {
            wp_die( esc_html__( 'Invalid unsubscribe link.', 'product-mailer-campaigns' ) );
        }

        global $wpdb;
		$queue_table       = $wpdb->prefix . 'pmcpc_email_queue';
		$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
		$events_table      = $wpdb->prefix . 'pmcpc_email_events';

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix.
		$cache_key = 'pmcpc_queue_row_' . (int) $queue_id . '_' . md5( (string) $token );
		$queue = wp_cache_get( $cache_key, 'pmcpc' );
		if ( false === $queue ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$queue = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$queue_table} WHERE id = %d AND view_token = %s", $queue_id, $token ) );
			wp_cache_set( $cache_key, $queue, 'pmcpc', 60 );
		}

        if ( ! $queue ) {
            wp_die( esc_html__( 'Invalid unsubscribe link.', 'product-mailer-campaigns' ) );
        }

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix.
		$cache_key = 'pmcpc_subscriber_row_' . (int) $queue->subscriber_id;
		$subscriber = wp_cache_get( $cache_key, 'pmcpc' );
		if ( false === $subscriber ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$subscriber = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$subscribers_table} WHERE id = %d", $queue->subscriber_id ) );
			wp_cache_set( $cache_key, $subscriber, 'pmcpc', 60 );
		}

        if ( ! $subscriber ) {
            wp_die( esc_html__( 'Subscriber not found.', 'product-mailer-campaigns' ) );
        }

        $now = current_time( 'mysql' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $subscribers_table,
            array(
                'status'     => 'unsubscribed',
                'updated_at' => $now,
            ),
            array( 'id' => $subscriber->id ),
            array( '%s', '%s' ),
            array( '%d' )
        );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->insert(
            $events_table,
            array(
                'queue_id'   => $queue_id,
                'event_type' => 'unsubscribed',
                'created_at' => $now,
            ),
            array( '%d', '%s', '%s' )
        );

        wp_die(
            '<h1>' . esc_html__( 'You have been unsubscribed', 'product-mailer-campaigns' ) . '</h1><p>' .
            esc_html__( 'You will no longer receive emails from this sender. If this was a mistake, you can subscribe again on our website.', 'product-mailer-campaigns' ) .
            '</p>',
            esc_html__( 'Unsubscribed', 'product-mailer-campaigns' ),
            array( 'response' => 200 )
        );
    }

    protected static function record_event_once( $queue_id, $event_type ) {
        global $wpdb;

        $events_table = esc_sql( $wpdb->prefix . 'pmcpc_email_events' );

        // Always log the raw hit (for debugging and for filtering bot/proxy traffic).
        self::record_event_log( $queue_id, $event_type );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $existing = $wpdb->get_var(
            $wpdb->prepare(
				/* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
                "SELECT id FROM $events_table WHERE queue_id = %d AND event_type = %s LIMIT 1",
                $queue_id,
                $event_type
            )
        );

        $now = current_time( 'mysql' );

        // Even if this event was already recorded (unique per queue/event),
        // keep the subscriber's "last engaged" timestamps fresh.
        self::touch_subscriber_engagement( $queue_id, $event_type, $now );

        if ( $existing ) {
            return;
        }

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->insert(
            $events_table,
            array(
                'queue_id'   => $queue_id,
                'event_type' => $event_type,
                'created_at' => $now,
            ),
            array( '%d', '%s', '%s' )
        );

        // Maintain lifetime subscriber stats so Subscriber profiles do not "reset"
        // when old queue items / raw logs are cleaned up.
        self::increment_subscriber_lifetime( $queue_id, $event_type, $now );
    }

    /**
     * Update last-engaged timestamps on the subscriber record.
     */
    protected static function touch_subscriber_engagement( $queue_id, $event_type, $now ) {
        global $wpdb;

        $queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
        $subs_table  = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );

	        $subscriber_id = absint(
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	            $wpdb->get_var(
	                $wpdb->prepare(
	                    /* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
	                    "SELECT subscriber_id FROM $queue_table WHERE id = %d LIMIT 1",
	                    absint( $queue_id )
	                )
	            )
	        );

        if ( ! $subscriber_id ) {
            return;
        }

        // Only attempt updates if engagement columns exist.
        if ( null === self::$subscriber_has_engagement_cols ) {
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			self::$subscriber_has_engagement_cols = (bool) $wpdb->get_var(
				$wpdb->prepare(
					/* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
					"SHOW COLUMNS FROM $subs_table LIKE %s",
					'last_engaged_at'
				)
			);
        }
        if ( ! self::$subscriber_has_engagement_cols ) {
            return;
        }

        $fields = array(
            'last_engaged_at' => $now,
            'updated_at'      => $now,
        );

        if ( 'clicked' === $event_type ) {
            $fields['last_clicked_at'] = $now;
        }

        if ( 'opened' === $event_type || 'viewed' === $event_type ) {
            $fields['last_opened_at'] = $now;
        }

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $subs_table,
            $fields,
            array( 'id' => $subscriber_id ),
            array_fill( 0, count( $fields ), '%s' ),
            array( '%d' )
        );
    }

    /**
     * Increment lifetime counters on the subscriber record.
     *
     * We increment only on the first unique event per queue item to avoid
     * inflating stats due to repeated pixel loads / refreshes.
     */
    protected static function increment_subscriber_lifetime( $queue_id, $event_type, $now ) {
        global $wpdb;

        $queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
        $subs_table  = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );

	        $subscriber_id = absint(
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	            $wpdb->get_var(
	                $wpdb->prepare(
					/* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
	                    "SELECT subscriber_id FROM $queue_table WHERE id = %d LIMIT 1",
	                    absint( $queue_id )
	                )
	            )
	        );

        if ( ! $subscriber_id ) {
            return;
        }

        // Only attempt updates if the lifetime columns exist.
        if ( null === self::$subscriber_has_lifetime_cols ) {
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	            self::$subscriber_has_lifetime_cols = (bool) $wpdb->get_var(
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					/* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
					"SHOW COLUMNS FROM $subs_table LIKE %s",
					'lifetime_opens'
				)
			);
        }
        if ( ! self::$subscriber_has_lifetime_cols ) {
            return;
        }

        if ( 'clicked' === $event_type ) {
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query(
                $wpdb->prepare(
	                    /* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
                    "UPDATE $subs_table
                     SET lifetime_clicks = lifetime_clicks + 1,
                         last_clicked_at = %s,
                         last_engaged_at = %s,
                         updated_at = %s
                     WHERE id = %d",
                    $now,
                    $now,
                    $now,
                    $subscriber_id
                )
            );
            return;
        }

        if ( 'opened' === $event_type || 'viewed' === $event_type ) {
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query(
                $wpdb->prepare(
	                    /* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
                    "UPDATE $subs_table
                     SET lifetime_opens = lifetime_opens + 1,
                         last_opened_at = %s,
                         last_engaged_at = %s,
                         updated_at = %s
                     WHERE id = %d",
                    $now,
                    $now,
                    $now,
                    $subscriber_id
                )
            );
        }
    }

    protected static function output_tracking_pixel() {
        $pixel = base64_decode(
            'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGNgYAAAAAMAASsJTYQAAAAASUVORK5CYII='
        );

        // Ensure caches don't store the pixel response.
        self::send_no_cache_headers();

        header( 'Content-Type: image/png' );
        header( 'Content-Length: ' . strlen( $pixel ) );
        echo $pixel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Binary PNG response.
    }

    /**
     * Strong no-cache headers for tracking endpoints.
     */
    protected static function send_no_cache_headers() {
        if ( function_exists( 'nocache_headers' ) ) {
            nocache_headers();
        }

        // Some CDNs/proxies are aggressive; belt-and-braces.
        header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
        header( 'Cache-Control: post-check=0, pre-check=0', false );
        header( 'Pragma: no-cache' );
        header( 'Expires: 0' );
    }

    /**
     * Create a signed token for view-in-browser links.
     */
    protected static function make_view_token( $queue_id ) {
        // wp_hash is salted (AUTH/SECURE_AUTH salts) and doesn't leak anything.
        return wp_hash( 'pmcpc_view|' . absint( $queue_id ) );
    }

    protected static function is_valid_view_token( $queue_id, $token ) {
        return hash_equals( self::make_view_token( $queue_id ), (string) $token );
    }


    /**
     * Generate a random, stored view token.
     * This is more robust than a deterministic hash because it survives changes to WP salts/keys.
     */
    public static function generate_view_token() {
        try {
            return bin2hex( random_bytes( 16 ) );
        } catch ( Exception $e ) {
            // Fallback if random_bytes is unavailable for any reason.
            return wp_generate_password( 32, false, false );
        }
    }

    /**
     * Look up a queue id by stored view token.
     */
    protected static function get_queue_id_by_view_token( $token ) {
        global $wpdb;
        $queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

        return absint(
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->get_var(
                $wpdb->prepare(
	                    /* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
                    "SELECT id FROM $queue_table WHERE view_token = %s LIMIT 1",
                    $token
                )
            )
        );
    }

    /**
     * Check if a given queue row has the provided stored view token.
     */
    protected static function does_queue_have_view_token( $queue_id, $token ) {
        global $wpdb;
        $queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $stored = (string) $wpdb->get_var(
            $wpdb->prepare(
	                /* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
                "SELECT view_token FROM $queue_table WHERE id = %d LIMIT 1",
                absint( $queue_id )
            )
        );

        return ( '' !== $stored && hash_equals( $stored, (string) $token ) );
    }

    /**
     * Fetch the stored email HTML for a queue item.
     */
    protected static function get_queue_html( $queue_id ) {
        global $wpdb;
        $queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $html = (string) $wpdb->get_var(
            $wpdb->prepare(
	                /* phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is a plugin table derived from $wpdb->prefix. */
                "SELECT body_html FROM $queue_table WHERE id = %d LIMIT 1",
                $queue_id
            )
        );

        return $html;
    }

    /**
     * Persist a short-lived click attribution cookie so WooCommerce orders can
     * be linked directly back to the originating FlowPress email.
     *
     * @param int $queue_id Queue row id.
     * @return void
     */
    protected static function store_click_attribution_cookie( $queue_id ) {
        global $wpdb;

        $queue_id = absint( $queue_id );
        if ( $queue_id <= 0 ) {
            return;
        }

        $queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $queue = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT campaign_id, subscriber_id FROM {$queue_table} WHERE id = %d LIMIT 1",
                $queue_id
            ),
            ARRAY_A
        );

        if ( empty( $queue ) ) {
            return;
        }

        $campaign_id   = isset( $queue['campaign_id'] ) ? absint( $queue['campaign_id'] ) : 0;
        $subscriber_id = isset( $queue['subscriber_id'] ) ? absint( $queue['subscriber_id'] ) : 0;
        $email         = strtolower( (string) self::get_queue_recipient_email( $queue_id ) );

        if ( $campaign_id <= 0 || '' === $email ) {
            return;
        }

        $payload = array(
            'queue_id'       => $queue_id,
            'campaign_id'    => $campaign_id,
            'subscriber_id'  => $subscriber_id,
            'subscriber_email' => $email,
            'ts'             => (int) current_time( 'timestamp' ),
            'source'         => 'flowpress_email_click',
        );

        $cookie = rawurlencode( (string) wp_json_encode( $payload ) );

        setcookie(
            'pmcpc_last_email_click',
            $cookie,
            time() + ( 7 * DAY_IN_SECONDS ),
            COOKIEPATH ? COOKIEPATH : '/',
            COOKIE_DOMAIN,
            is_ssl(),
            true
        );

        $_COOKIE['pmcpc_last_email_click'] = $cookie;
    }

    /**
     * Record raw tracking hits (optional, controlled by setting).
     */
    protected static function record_event_log( $queue_id, $event_type ) {
        // Only log raw hits when debug is enabled (keeps DB small on busy sites).
        if ( class_exists( 'PMCPC_Settings' ) && 'yes' !== PMCPC_Settings::get( 'tracking_debug', 'no' ) ) {
            return;
        }

        global $wpdb;
        $logs_table = esc_sql( $wpdb->prefix . 'pmcpc_email_event_logs' );

        // If table doesn't exist yet, skip quietly.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $logs_table ) );
        if ( $exists !== $logs_table ) {
            return;
        }

        $meta = self::get_request_meta();

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $wpdb->insert(
            $logs_table,
            array(
                'queue_id'    => $queue_id,
                'event_type'  => $event_type,
                'created_at'  => current_time( 'mysql' ),
                'ip_hash'     => $meta['ip_hash'],
                'ua_hash'     => $meta['ua_hash'],
                'user_agent'  => $meta['user_agent'],
                'referrer'    => $meta['referrer'],
                'is_bot'      => $meta['is_bot'] ? 1 : 0,
                'is_proxy'    => $meta['is_proxy'] ? 1 : 0,
            ),
            array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d' )
        );
    }

    protected static function get_request_meta() {
        $ua  = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
        $ref = isset( $_SERVER['HTTP_REFERER'] ) ? sanitize_text_field( (string) wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
        $ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

        // Defensive truncation.
        $ua  = substr( $ua, 0, 255 );
        $ref = substr( $ref, 0, 255 );
        $ip  = substr( $ip, 0, 64 );

        $ua_lc = strtolower( $ua );

        // Heuristics: security scanners and link checkers (not perfect, but useful).
        $bot_signals = array(
            'bot', 'spider', 'crawler', 'preview', 'prefetch', 'scanner', 'security',
            'facebookexternalhit', 'slackbot', 'twitterbot', 'telegrambot',
            'curl/', 'wget/', 'python-requests', 'go-http-client', 'java/',
            'headless', 'node-fetch',
        );

        $is_bot = false;
        foreach ( $bot_signals as $sig ) {
            if ( false !== strpos( $ua_lc, $sig ) ) {
                $is_bot = true;
                break;
            }
        }

        // Proxy-ish signals: very rough.
        $proxy_signals = array(
            'googleimageproxy', // Gmail image proxy (sometimes)
            'googlebot-image',
            'cloudflare',
        );

        $is_proxy = false;
        foreach ( $proxy_signals as $sig ) {
            if ( false !== strpos( $ua_lc, $sig ) ) {
                $is_proxy = true;
                break;
            }
        }

        return array(
            'user_agent' => $ua,
            'referrer'   => $ref,
            'ip_hash'    => $ip ? hash( 'sha256', $ip ) : '',
            'ua_hash'    => $ua ? hash( 'sha256', $ua ) : '',
            'is_bot'     => $is_bot,
            'is_proxy'   => $is_proxy,
        );
    }

}
