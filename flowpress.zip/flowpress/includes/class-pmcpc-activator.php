<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.SchemaChange

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.SchemaChange

class PMCPC_Activator {

    /**
     * Register plugin cron schedules.
     *
     * Use plugin-specific schedule names so they don't depend on other plugins/themes
     * and avoid collisions.
     */
    public static function add_cron_schedules( $schedules ) {
        if ( ! isset( $schedules['pmcpc_every_minute'] ) ) {
            $schedules['pmcpc_every_minute'] = array(
                'interval' => 60,
                'display'  => __( 'PMCPC: Every Minute', 'product-mailer-campaigns' ),
            );
        }

        if ( ! isset( $schedules['pmcpc_every_five_minutes'] ) ) {
            $schedules['pmcpc_every_five_minutes'] = array(
                'interval' => 300,
                'display'  => __( 'PMCPC: Every 5 Minutes', 'product-mailer-campaigns' ),
            );
        }

        if ( ! isset( $schedules['pmcpc_every_six_hours'] ) ) {
            $schedules['pmcpc_every_six_hours'] = array(
                'interval' => 6 * HOUR_IN_SECONDS,
                'display'  => __( 'PMCPC: Every 6 Hours', 'product-mailer-campaigns' ),
            );
        }

        // Back-compat: if older code used 'minute', register it too.
        if ( ! isset( $schedules['minute'] ) ) {
            $schedules['minute'] = array(
                'interval' => 60,
                'display'  => __( 'Every Minute', 'product-mailer-campaigns' ),
            );
        }

        return $schedules;
    }

		/**
	 * Legacy migration removed for a clean-slate install.
	 *
	 * @param wpdb $wpdb WordPress database object.
	 */
	protected static function migrate_legacy_tables( $wpdb ) {
		return;
	}


    /**
     * Database schema version.
     *
     * Increment this when changing table schemas (new columns / indexes, etc.).
     */
	// 2026-01-02-01:
	// - Ensure spam submissions table exists on hosts that update plugins without activation.
	// - Ensure campaigns table has automation_trigger / pro_segment_key columns used by diagnostics.
	// - Ensure inbox/spam submissions table has optional campaign_id column for campaign context.
	const DB_VERSION = '2026-05-01-01';

    /**
     * Ensure DB schema is up to date.
     *
     * Activation hooks do not run when a plugin is simply replaced/updated.
     * This method lets us run dbDelta upgrades safely on normal requests.
     */
    public static function maybe_upgrade() {
		global $wpdb;
		// These queries are part of controlled plugin activation / schema management.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange

		$current = (string) get_option( 'pmcpc_db_version', '' );
		$spam_submissions_table  = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
		$abandoned_carts_table   = esc_sql( $wpdb->prefix . 'pmcpc_abandoned_carts' );

		// Some hosts update plugins by replacing files without triggering activation hooks.
		// Also, the stored db version can be out of sync with the actual schema (e.g. failed
		// dbDelta due to missing privileges). In both cases, ensure critical tables exist.
		$missing_table = false;
		if ( ! empty( $wpdb->prefix ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $spam_submissions_table ) );
			$missing_table = empty( $found );
		
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$found2 = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $abandoned_carts_table ) );
			$missing_table = $missing_table || empty( $found2 );
}

			if ( $missing_table ) {
				self::create_spam_submissions_table( $wpdb );
				self::create_abandoned_carts_table( $wpdb );
				update_option( 'pmcpc_db_version', self::DB_VERSION, false );
				return;
			}


			// Ensure columns used by newer code exist even if activation hooks didn't run.
			self::ensure_campaigns_columns( $wpdb );
			self::ensure_spam_submissions_columns( $wpdb );
			self::ensure_email_log_table( $wpdb );
			self::ensure_subscriber_tags_columns( $wpdb );
			self::ensure_email_event_logs_columns( $wpdb );
			self::ensure_block_log_columns( $wpdb );
			self::ensure_abandoned_carts_columns( $wpdb );

			// Avoid calling dbDelta automatically (it may emit warnings on hosts that disable set_time_limit()).
			// We only record the schema version after our targeted, safe checks.
			if ( self::DB_VERSION !== $current ) {
				update_option( 'pmcpc_db_version', self::DB_VERSION, false );
			}
    }

	/**
	 * Ensure campaigns table has columns referenced by the diagnostics page.
	 *
	 * Some sites updated from earlier builds where these columns didn't exist.
	 * We add them safely via ALTER TABLE if missing.
	 */
	protected static function ensure_campaigns_columns( $wpdb ) {
		$campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
		if ( empty( $wpdb->prefix ) ) {
			return;
		}

		// Bail if campaigns table doesn't exist.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $campaigns_table ) );
		if ( empty( $found ) ) {
			return;
		}

		// automation_trigger
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$campaigns_table} LIKE %s", 'automation_trigger' ) );
		if ( empty( $col ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$campaigns_table} ADD COLUMN automation_trigger VARCHAR(50) NULL AFTER name" );
		}

		// pro_segment_key
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$campaigns_table} LIKE %s", 'pro_segment_key' ) );
		if ( empty( $col ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$campaigns_table} ADD COLUMN pro_segment_key VARCHAR(100) NULL AFTER automation_trigger" );
		}


			// workflow_key / workflow_name / workflow_step (groups multi-step automation emails under one workflow row).
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$campaigns_table} LIKE %s", 'workflow_key' ) );
			if ( empty( $col ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$wpdb->query( "ALTER TABLE {$campaigns_table} ADD COLUMN workflow_key VARCHAR(100) NULL AFTER pro_segment_key" );
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$campaigns_table} LIKE %s", 'workflow_name' ) );
			if ( empty( $col ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$wpdb->query( "ALTER TABLE {$campaigns_table} ADD COLUMN workflow_name VARCHAR(190) NULL AFTER workflow_key" );
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$campaigns_table} LIKE %s", 'workflow_step' ) );
			if ( empty( $col ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$wpdb->query( "ALTER TABLE {$campaigns_table} ADD COLUMN workflow_step INT(11) UNSIGNED NOT NULL DEFAULT 0 AFTER workflow_name" );
			}

		// trigger_delay_minutes (canonical delay storage for all triggers)
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$campaigns_table} LIKE %s", 'trigger_delay_minutes' ) );
		if ( empty( $col ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$campaigns_table} ADD COLUMN trigger_delay_minutes INT(11) UNSIGNED NOT NULL DEFAULT 0 AFTER broadcast_delay_minutes" );

			// Best-effort migration from legacy delay columns.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query(
				"UPDATE {$campaigns_table}
				 SET trigger_delay_minutes = CASE
					WHEN is_welcome = 1 AND welcome_delay_minutes > 0 THEN welcome_delay_minutes
					WHEN is_post_purchase = 1 AND post_purchase_delay_minutes > 0 THEN post_purchase_delay_minutes
					WHEN broadcast_delay_minutes > 0 THEN broadcast_delay_minutes
					ELSE 0
				 END
				 WHERE trigger_delay_minutes = 0
					AND (welcome_delay_minutes > 0 OR post_purchase_delay_minutes > 0 OR broadcast_delay_minutes > 0)"
			);
		}

		// Backfill automation_trigger for legacy automation campaigns.
		// Older installs used flags like is_welcome / is_post_purchase but left automation_trigger empty.
		// We only set the trigger when it is missing so this is safe on newer installs.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->query(
			"UPDATE {$campaigns_table}
			 SET automation_trigger = CASE
			 	WHEN (automation_trigger IS NULL OR automation_trigger = '' OR automation_trigger = 'none') AND is_welcome = 1 THEN 'new_subscriber'
			 	WHEN (automation_trigger IS NULL OR automation_trigger = '' OR automation_trigger = 'none') AND is_post_purchase = 1 THEN 'post_purchase'
			 	ELSE automation_trigger
			 END
			 WHERE (automation_trigger IS NULL OR automation_trigger = '' OR automation_trigger = 'none')
			   AND (is_welcome = 1 OR is_post_purchase = 1)"
		);

		// Upgrade path: older quick-setup created "Review request" as a post_purchase automation.
		// Convert those campaigns to the dedicated review_request trigger so it can be managed separately.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$campaigns_table}
				 SET automation_trigger = %s,
				     is_post_purchase = 0
				 WHERE automation_trigger = %s
				   AND name LIKE %s",
				'review_request',
				'post_purchase',
				'Automation: Review request%'
			)
		);

		// Upgrade path: older builds stored win-back with non-canonical trigger keys.
		// Canonical trigger key is `customer_inactive`.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$campaigns_table}
				 SET automation_trigger = %s
				 WHERE automation_trigger IN (%s, %s)",
				'customer_inactive',
				'inactive',
				'win_back_automation'
			)
		);

		// Also catch quick-setup naming patterns where the trigger might be missing/legacy.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$campaigns_table}
				 SET automation_trigger = %s
				 WHERE (automation_trigger IS NULL OR automation_trigger = '' OR automation_trigger = 'none')
				   AND name LIKE %s",
				'customer_inactive',
				'Automation: Win-back%'
			)
		);
	}

	/**
	 * Ensure abandoned carts table has columns required for recovery sequencing.
	 */
	protected static function ensure_abandoned_carts_columns( $wpdb ) {
		$table = esc_sql( $wpdb->prefix . 'pmcpc_abandoned_carts' );
		if ( empty( $wpdb->prefix ) ) {
			return;
		}
		// Bail if table doesn't exist.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( empty( $found ) ) {
			return;
		}

		$cols = array(
			'recovery_status'       => "ALTER TABLE {$table} ADD COLUMN recovery_status VARCHAR(20) NOT NULL DEFAULT 'none' AFTER status",
			'recovery_step'         => "ALTER TABLE {$table} ADD COLUMN recovery_step TINYINT(3) UNSIGNED NOT NULL DEFAULT 0 AFTER recovery_status",
			'recovery_next_at'      => "ALTER TABLE {$table} ADD COLUMN recovery_next_at DATETIME NULL AFTER recovery_step",
			'recovery_started_at'   => "ALTER TABLE {$table} ADD COLUMN recovery_started_at DATETIME NULL AFTER recovery_next_at",
			'recovery_completed_at' => "ALTER TABLE {$table} ADD COLUMN recovery_completed_at DATETIME NULL AFTER recovery_started_at",
		);

		foreach ( $cols as $col_name => $sql ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", $col_name ) );
			if ( empty( $col ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$wpdb->query( $sql );
			}
		}
	}

	/**
	 * Ensure spam submissions table has optional columns used by the Inbox UI.
	 *
	 * This allows linking submissions to a campaign (e.g. when a form is embedded
	 * on a campaign landing page).
	 */
	protected static function ensure_spam_submissions_columns( $wpdb ) {
		$spam_table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
		if ( empty( $wpdb->prefix ) ) {
			return;
		}

		// Bail if table doesn't exist.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $spam_table ) );
		if ( empty( $found ) ) {
			return;
		}

		// campaign_id (nullable)
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$spam_table} LIKE %s", 'campaign_id' ) );
		if ( empty( $col ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$spam_table} ADD COLUMN campaign_id BIGINT(20) UNSIGNED NULL AFTER context" );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$spam_table} ADD KEY campaign_id (campaign_id)" );
		}


		// spam_score (nullable) + score_details (nullable): stores message/content scoring results.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$spam_table} LIKE %s", 'spam_score' ) );
		if ( empty( $col ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$spam_table} ADD COLUMN spam_score FLOAT NULL AFTER message" );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$spam_table} LIKE %s", 'score_details' ) );
		if ( empty( $col ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$spam_table} ADD COLUMN score_details LONGTEXT NULL AFTER spam_score" );
		}

		// Composite index for common Inbox queries (status + created_at).
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$idx = $wpdb->get_var( $wpdb->prepare( "SHOW INDEX FROM {$spam_table} WHERE Key_name = %s", 'status_created_at' ) );
		if ( empty( $idx ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$spam_table} ADD KEY status_created_at (status, created_at)" );
		}
	}

		/**
		 * Create the spam submissions table without dbDelta.
		 *
		 * Some hosts disable set_time_limit(), which dbDelta may call. This direct
		 * CREATE TABLE keeps updates quiet and reliable.
		 */
		
/**
 * Ensure the email log table exists (used for sent/failed history).
 *
 * Plugin updates can replace files without running activation hooks.
 */
protected static function ensure_email_log_table( $wpdb ) {
	$table = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
	if ( empty( $found ) ) {
		self::create_email_log_table( $wpdb );
	} else {

		// Ensure newer columns exist (upgrades from older versions).
		self::ensure_email_log_columns( $wpdb );
	}
}

	/**
	 * Ensure subscriber tags table has columns referenced by newer builds.
	 *
	 * Adds created_at if missing.
	 */
	protected static function ensure_subscriber_tags_columns( $wpdb ) {
		$table = esc_sql( $wpdb->prefix . 'pmcpc_subscriber_tags' );
		if ( empty( $wpdb->prefix ) ) {
			return;
		}
		// Bail if table doesn't exist.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( empty( $found ) ) {
			return;
		}
		// created_at
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", 'created_at' ) );
		if ( empty( $col ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$table} ADD COLUMN created_at DATETIME NULL" );
		}
	}

	/**
	 * Ensure email event logs table has columns referenced by newer builds.
	 *
	 * Adds event_data if missing.
	 */
	protected static function ensure_email_event_logs_columns( $wpdb ) {
		$table = esc_sql( $wpdb->prefix . 'pmcpc_email_event_logs' );
		if ( empty( $wpdb->prefix ) ) {
			return;
		}
		// Bail if table doesn't exist.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( empty( $found ) ) {
			return;
		}
		// event_data
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", 'event_data' ) );
		if ( empty( $col ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$table} ADD COLUMN event_data LONGTEXT NULL" );
		}
	}

	/**
	 * Ensure block log table has columns referenced by newer builds.
	 *
	 * Adds to_email if missing.
	 */
	protected static function ensure_block_log_columns( $wpdb ) {
		$table = esc_sql( $wpdb->prefix . 'pmcpc_block_log' );
		if ( empty( $wpdb->prefix ) ) {
			return;
		}
		// Bail if table doesn't exist.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( empty( $found ) ) {
			return;
		}
		// to_email
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$col = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", 'to_email' ) );
		if ( empty( $col ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query( "ALTER TABLE {$table} ADD COLUMN to_email VARCHAR(255) NULL" );
		}
	}


/**
 * Create the email log table without dbDelta().
 */
protected static function create_email_log_table( $wpdb ) {
	$table = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
	$charset_collate = $wpdb->get_charset_collate();

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
	$wpdb->query(
		"CREATE TABLE IF NOT EXISTS {$table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			queue_id BIGINT(20) UNSIGNED NULL,
			subscriber_id BIGINT(20) UNSIGNED NULL,
			campaign_id BIGINT(20) UNSIGNED NOT NULL,
			to_email VARCHAR(190) NOT NULL,
			subject VARCHAR(190) NOT NULL,
			body_html LONGTEXT NULL,
			body_text LONGTEXT NULL,
			headers TEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'sent',
			last_error TEXT NULL,
			sent_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY campaign_id (campaign_id),
			KEY subscriber_id (subscriber_id),
			KEY status (status),
			KEY sent_at (sent_at),
			KEY to_email (to_email)
		) {$charset_collate}"
	);
}


/**
 * Ensure expected columns exist on the email log table (upgrade-safe).
 */
protected static function ensure_email_log_columns( $wpdb ) {
		$table  = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
		$needed = array( 'body_text', 'headers' );

		foreach ( $needed as $col ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$exists = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", $col ) );
			if ( empty( $exists ) ) {
				// DDL statements can't be prepared; table name is plugin-controlled.
				if ( 'body_text' === $col ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$wpdb->query( "ALTER TABLE {$table} ADD COLUMN body_text LONGTEXT NULL AFTER body_html" );
				} elseif ( 'headers' === $col ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$wpdb->query( "ALTER TABLE {$table} ADD COLUMN headers TEXT NULL AFTER body_text" );
				}
			}
		}
	}

protected static function create_spam_submissions_table( $wpdb ) {
			$table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
			$charset_collate = $wpdb->get_charset_collate();
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->query(
				"CREATE TABLE IF NOT EXISTS {$table} (
					id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
					email VARCHAR(190) NULL,
					domain VARCHAR(190) NULL,
					ip_hash CHAR(64) NULL,
					reason VARCHAR(100) NOT NULL,
					context VARCHAR(50) NOT NULL,
					campaign_id BIGINT(20) UNSIGNED NULL,
					status VARCHAR(20) NOT NULL DEFAULT 'held',
					subject VARCHAR(255) NULL,
					message LONGTEXT NULL,
					reviewed_at DATETIME NULL,
					created_at DATETIME NOT NULL,
					PRIMARY KEY (id),
					KEY created_at (created_at),
					KEY status (status),
					KEY domain (domain),
					KEY reason (reason),
					KEY campaign_id (campaign_id)
				) {$charset_collate}"
			);
		}

    public static function activate() {
        if ( class_exists( "PMCPC_Prefix_Guard" ) ) {
            PMCPC_Prefix_Guard::validate_or_die();
        }

        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

		$subscribers_table = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );
		$campaigns_table   = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
		$queue_table       = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
				$email_log_table  = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
		$events_table      = esc_sql( $wpdb->prefix . 'pmcpc_email_events' );
		$event_logs_table  = esc_sql( $wpdb->prefix . 'pmcpc_email_event_logs' );
		$block_log_table   = esc_sql( $wpdb->prefix . 'pmcpc_block_log' );
		$tags_table        = esc_sql( $wpdb->prefix . 'pmcpc_subscriber_tags' );
		$abandoned_carts_table = esc_sql( $wpdb->prefix . 'pmcpc_abandoned_carts' );

        // Avoid dbDelta() on shared hosts that disable set_time_limit().
        // We create tables with direct CREATE TABLE IF NOT EXISTS statements instead.

        $sql_subscribers = "CREATE TABLE IF NOT EXISTS $subscribers_table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            email VARCHAR(190) NOT NULL,
            first_name VARCHAR(100) NULL,
            last_name VARCHAR(100) NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            lifetime_opens BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            lifetime_clicks BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            last_opened_at DATETIME NULL,
            last_clicked_at DATETIME NULL,
            last_engaged_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email)
        ) $charset_collate;";


        $sql_campaigns = "CREATE TABLE IF NOT EXISTS $campaigns_table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            campaign_type VARCHAR(30) NOT NULL DEFAULT 'manual',
            automation_trigger VARCHAR(50) NULL,
            pro_segment_key VARCHAR(100) NULL,
            workflow_key VARCHAR(100) NULL,
            workflow_name VARCHAR(190) NULL,
            workflow_step INT(11) UNSIGNED NOT NULL DEFAULT 0,
            subject VARCHAR(190) NOT NULL,
            from_name VARCHAR(190) NOT NULL,
            from_email VARCHAR(190) NOT NULL,
            content LONGTEXT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            is_welcome TINYINT(1) NOT NULL DEFAULT 0,
            is_post_purchase TINYINT(1) NOT NULL DEFAULT 0,
            target_tag VARCHAR(100) NULL,
            welcome_delay_minutes INT(11) UNSIGNED NOT NULL DEFAULT 0,
            post_purchase_delay_minutes INT(11) UNSIGNED NOT NULL DEFAULT 0,
            broadcast_delay_minutes INT(11) UNSIGNED NOT NULL DEFAULT 0,
			trigger_delay_minutes INT(11) UNSIGNED NOT NULL DEFAULT 0,
            schedule_type VARCHAR(20) NOT NULL DEFAULT 'manual',
            schedule_datetime DATETIME NULL,
            schedule_frequency VARCHAR(20) NULL,
            next_run_at DATETIME NULL,
            product_block_enabled TINYINT(1) NOT NULL DEFAULT 0,
            product_block_source VARCHAR(50) NULL,
            product_block_limit INT(11) UNSIGNED NOT NULL DEFAULT 3,
            auto_footer_links_enabled TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";


        $sql_queue = "CREATE TABLE IF NOT EXISTS $queue_table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            subscriber_id BIGINT(20) UNSIGNED NOT NULL,
            campaign_id BIGINT(20) UNSIGNED NOT NULL,
            to_email VARCHAR(190) NOT NULL,
            subject VARCHAR(190) NOT NULL,
            body_html LONGTEXT NOT NULL,
            view_token VARCHAR(100) NULL,
            scheduled_at DATETIME NOT NULL,
            attempts TINYINT(3) UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            last_error TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY subscriber_id (subscriber_id),
            KEY campaign_id (campaign_id),
            KEY status (status),
            KEY scheduled_at (scheduled_at),
            KEY view_token (view_token)
        ) $charset_collate;";

        
$sql_email_log = "CREATE TABLE IF NOT EXISTS $email_log_table (
    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    queue_id BIGINT(20) UNSIGNED NULL,
    subscriber_id BIGINT(20) UNSIGNED NULL,
    campaign_id BIGINT(20) UNSIGNED NOT NULL,
    to_email VARCHAR(190) NOT NULL,
    subject VARCHAR(190) NOT NULL,
    body_html LONGTEXT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'sent',
    last_error TEXT NULL,
    sent_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY campaign_id (campaign_id),
    KEY subscriber_id (subscriber_id),
    KEY status (status),
    KEY sent_at (sent_at),
    KEY to_email (to_email)
) $charset_collate;";

$sql_events = "CREATE TABLE IF NOT EXISTS $events_table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            queue_id BIGINT(20) UNSIGNED NOT NULL,
            event_type VARCHAR(50) NOT NULL,
            event_data LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY queue_id (queue_id),
            KEY event_type (event_type)
        ) $charset_collate;";

        $sql_event_logs = "CREATE TABLE IF NOT EXISTS $event_logs_table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            queue_id BIGINT(20) UNSIGNED NOT NULL,
            event_type VARCHAR(50) NOT NULL,
            event_data LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            ip_hash CHAR(64) NULL,
            ua_hash CHAR(64) NULL,
            user_agent TEXT NULL,
            referrer TEXT NULL,
            is_bot TINYINT(1) NOT NULL DEFAULT 0,
            is_proxy TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY queue_id (queue_id),
            KEY event_type (event_type),
            KEY created_at (created_at)
        ) $charset_collate;";

        $sql_tags = "CREATE TABLE IF NOT EXISTS $tags_table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            subscriber_id BIGINT(20) UNSIGNED NOT NULL,
            tag VARCHAR(100) NOT NULL,
            created_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY subscriber_id (subscriber_id),
            KEY tag (tag)
        ) $charset_collate;";

        $sql_abandoned_carts = "CREATE TABLE IF NOT EXISTS $abandoned_carts_table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_key VARCHAR(64) NOT NULL,
            user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            email VARCHAR(190) NOT NULL DEFAULT '',
            cart_hash VARCHAR(64) NOT NULL DEFAULT '',
            cart_total DECIMAL(18,4) NOT NULL DEFAULT 0,
            currency VARCHAR(10) NOT NULL DEFAULT '',
            items_json LONGTEXT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            last_activity_at DATETIME NOT NULL,
            abandoned_at DATETIME NULL,
            recovered_at DATETIME NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_key (session_key),
            KEY status (status),
            KEY last_activity_at (last_activity_at)
        ) $charset_collate;";

		$sql_block_log = "CREATE TABLE IF NOT EXISTS $block_log_table (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			email VARCHAR(190) NULL,
			domain VARCHAR(190) NULL,
			ip_hash CHAR(64) NULL,
			reason VARCHAR(100) NOT NULL,
			context VARCHAR(50) NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY created_at (created_at),
			KEY reason (reason),
			KEY domain (domain)
		) $charset_collate;";


		$spam_submissions_table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
		$sql_spam_submissions = "CREATE TABLE IF NOT EXISTS $spam_submissions_table (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			email VARCHAR(190) NULL,
			domain VARCHAR(190) NULL,
			ip_hash CHAR(64) NULL,
			reason VARCHAR(100) NOT NULL,
			context VARCHAR(50) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'held',
			subject VARCHAR(255) NULL,
			message LONGTEXT NULL,
			reviewed_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY created_at (created_at),
			KEY status (status),
			KEY domain (domain),
			KEY reason (reason)
		) $charset_collate;";


        // Direct table creation (quiet on hosts that disable set_time_limit()).
        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
        $wpdb->query( $sql_subscribers );
        $wpdb->query( $sql_campaigns );
        $wpdb->query( $sql_queue );
        $wpdb->query( $sql_email_log );
        $wpdb->query( $sql_events );
        $wpdb->query( $sql_event_logs );
        $wpdb->query( $sql_tags );
        $wpdb->query( $sql_abandoned_carts );
		$wpdb->query( $sql_block_log );
		$wpdb->query( $sql_spam_submissions );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared

		// Ensure expected columns exist even if tables were created by an older build.
		self::ensure_campaigns_columns( $wpdb );

		// No legacy migrations: this plugin uses pmcpc_* tables only.

		// Avoid a custom recurring schedule here: on some hosts, cron can run while plugins
		// are being updated, which means our custom schedule may not be registered yet.
		// That leads to noisy "invalid_schedule" reschedule errors.
		//
		// Instead we use self-rescheduling single events from the handlers.
		wp_clear_scheduled_hook( 'pmcpc_process_email_queue' );
		wp_clear_scheduled_hook( 'pmcpc_process_scheduled_campaigns' );

		if ( ! wp_next_scheduled( 'pmcpc_process_email_queue' ) ) {
			wp_schedule_single_event( time() + 60, 'pmcpc_process_email_queue' );
		}

		if ( ! wp_next_scheduled( 'pmcpc_process_scheduled_campaigns' ) ) {
			wp_schedule_single_event( time() + 60, 'pmcpc_process_scheduled_campaigns' );
		}

        // Cleanup raw tracking logs daily (if enabled) to avoid unlimited growth.
        if ( ! wp_next_scheduled( 'pmcpc_tracking_logs_cleanup' ) ) {
            wp_schedule_event( time() + 120, 'daily', 'pmcpc_tracking_logs_cleanup' );
        }

		// Cleanup Inbox / spam submissions daily based on retention settings.
		if ( ! wp_next_scheduled( 'pmcpc_inbox_cleanup' ) ) {
			wp_schedule_event( time() + 180, 'daily', 'pmcpc_inbox_cleanup' );
		}

		// Cleanup email queue daily based on retention settings.
		if ( ! wp_next_scheduled( 'pmcpc_queue_retention_cleanup' ) ) {
			wp_schedule_event( time() + 240, 'daily', 'pmcpc_queue_retention_cleanup' );
		}

		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
    }

	private static function create_abandoned_carts_table( $wpdb ) {
		$charset_collate = $wpdb->get_charset_collate();
		$table = esc_sql( $wpdb->prefix . 'pmcpc_abandoned_carts' );

		$sql = "CREATE TABLE IF NOT EXISTS $table (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			session_key VARCHAR(64) NOT NULL,
			user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			email VARCHAR(190) NOT NULL DEFAULT '',
			cart_hash VARCHAR(64) NOT NULL DEFAULT '',
			cart_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			currency VARCHAR(10) NOT NULL DEFAULT '',
			items_json LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			last_activity_at DATETIME NOT NULL,
			abandoned_at DATETIME NULL,
			recovered_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY session_key (session_key),
			KEY status (status),
			KEY last_activity_at (last_activity_at)
		) $charset_collate;";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
		$wpdb->query( $sql );
	}

}