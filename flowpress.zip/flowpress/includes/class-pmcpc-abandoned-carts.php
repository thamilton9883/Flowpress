<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Lightweight abandoned cart capture for WooCommerce.
 *
 * Captures cart sessions into a dedicated table so the plugin can show
 * "money on the table" opportunity counts even before an upgrade.
 *
 * Premium workflows (abandoned cart emails, recovery sequences) are gated elsewhere.
 */
class PMCPC_Abandoned_Carts {

    const CRON_HOOK = 'pmcpc_abandoned_cart_sweep';

    /**
     * Premium recovery runner (queues abandoned cart emails when automation is enabled).
     */
    const RECOVERY_CRON_HOOK = 'pmcpc_abandoned_cart_recovery_runner';

	/**
	 * Default workflow timing (minutes).
	 *
	 * These act as fallbacks when step campaigns have not been created yet,
	 * or when their Delay after trigger value is still 0.
	 */
	const DEFAULT_STEP1_DELAY_MINUTES = 60;           // 1 hour
	const DEFAULT_STEP2_DELAY_MINUTES = 24 * 60;      // 24 hours
	const DEFAULT_STEP3_DELAY_MINUTES = 3 * 24 * 60;  // 3 days

    public static function init() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        // Keep capture, attribution, and opportunity reporting active even when the
        // paid WooCommerce automation layer is unavailable.
        add_action( 'wp_loaded', array( __CLASS__, 'maybe_capture_cart' ), 20 );
        add_action( 'woocommerce_add_to_cart', array( __CLASS__, 'maybe_capture_cart' ), 20 );
        add_action( 'woocommerce_cart_updated', array( __CLASS__, 'maybe_capture_cart' ), 20 );
        add_action( 'woocommerce_checkout_update_order_review', array( __CLASS__, 'maybe_capture_cart' ), 20 );

        // Attach session key to orders, then mark carts recovered.
        add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'attach_session_to_order' ), 10, 2 );
        add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'mark_recovered_from_order' ), 10, 3 );

        // Cron sweep to mark stale carts abandoned and queue any due recovery emails.
        // Recovery now piggybacks on the sweep hook so WordPress only has one abandoned-cart
        // cron event to maintain. Older recovery-runner events are removed during ensure_cron().
        add_action( self::CRON_HOOK, array( __CLASS__, 'sweep_abandoned' ) );

        // Back-compat: if an old recovery-runner event is already due before cleanup runs,
        // allow it to process safely, but do not schedule this hook again.
        add_action( self::RECOVERY_CRON_HOOK, array( __CLASS__, 'process_recovery_queue' ) );

        // Ensure cron is scheduled.
        add_action( 'init', array( __CLASS__, 'ensure_cron' ), 30 );
    }

    public static function ensure_cron() {
        // 1.4.10: keep abandoned-cart work on one recurring sweep hook.
        // Previous builds used a frequent single-event recovery runner. On some hosts,
        // WordPress can log noisy "Cron unschedule event error ... schedule:false" messages
        // when removing frequent single events. The sweep now also queues due recovery steps,
        // so the separate recovery-runner hook is retired.
        self::migrate_to_sweep_only_cron_once();

        self::ensure_recurring_event( self::CRON_HOOK, 'pmcpc_every_five_minutes', 5 * MINUTE_IN_SECONDS );

        // Do not schedule RECOVERY_CRON_HOOK. It remains registered only so an old already-due
        // event can run safely during the transition.
    }

    /**
     * Ensure a hook is scheduled as a recurring event with the expected interval.
     *
     * @param string $hook     Cron hook name.
     * @param string $schedule Cron schedule key.
     * @param int    $delay    Delay before first run in seconds.
     * @return void
     */
    protected static function ensure_recurring_event( $hook, $schedule, $delay ) {
        $hook     = (string) $hook;
        $schedule = (string) $schedule;

        if ( '' === $hook || '' === $schedule ) {
            return;
        }

        $event = function_exists( 'wp_get_scheduled_event' ) ? wp_get_scheduled_event( $hook ) : null;
        if ( $event && isset( $event->schedule ) && $schedule === (string) $event->schedule ) {
            return;
        }

        // Avoid wp_clear_scheduled_hook() here. On hosts with fragile cron-option writes,
        // that function can emit the same noisy errors we are trying to avoid. Directly
        // pruning our hook keeps this migration quiet and leaves unrelated cron untouched.
        self::remove_all_events_for_hook( $hook );

        if ( ! wp_next_scheduled( $hook ) ) {
            wp_schedule_event( time() + absint( $delay ), $schedule, $hook );
        }
    }

    /**
     * Clear a scheduled hook only when WordPress can see a matching event.
     *
     * @param string $hook Cron hook name.
     * @return void
     */
    protected static function clear_scheduled_hook_if_present( $hook ) {
        $hook = (string) $hook;
        if ( '' === $hook || ! wp_next_scheduled( $hook ) ) {
            return;
        }

        self::remove_all_events_for_hook( $hook );
    }

    /**
     * One-time migration away from the separate recovery-runner cron hook.
     *
     * @return void
     */
    protected static function migrate_to_sweep_only_cron_once() {
        if ( 'sweep_only_recurring_1' === (string) get_option( 'pmcpc_abandoned_cart_cron_model', '' ) ) {
            return;
        }

        self::remove_all_events_for_hook( self::RECOVERY_CRON_HOOK );

        // Rebuild the sweep hook once so any older single-event copy is replaced by the
        // recurring sweep schedule registered by the plugin.
        self::remove_all_events_for_hook( self::CRON_HOOK );

        update_option( 'pmcpc_abandoned_cart_cron_model', 'sweep_only_recurring_1', false );
    }

    /**
     * Directly remove all cron entries for a hook.
     *
     * @param string $hook Cron hook name.
     * @return void
     */
    protected static function remove_all_events_for_hook( $hook ) {
        $hook = (string) $hook;
        if ( '' === $hook || ! function_exists( '_get_cron_array' ) || ! function_exists( '_set_cron_array' ) ) {
            return;
        }

        $crons   = _get_cron_array();
        $changed = false;

        if ( empty( $crons ) || ! is_array( $crons ) ) {
            return;
        }

        foreach ( $crons as $timestamp => $hooks ) {
            if ( empty( $hooks[ $hook ] ) ) {
                continue;
            }

            unset( $crons[ $timestamp ][ $hook ] );
            $changed = true;

            if ( empty( $crons[ $timestamp ] ) ) {
                unset( $crons[ $timestamp ] );
            }
        }

        if ( $changed ) {
            _set_cron_array( $crons );
        }
    }
    public static function maybe_capture_cart() {
        if ( is_admin() && ! wp_doing_ajax() ) {
            return;
        }
        if ( ! function_exists( 'WC' ) ) {
            return;
        }
        $wc = WC();
        if ( empty( $wc ) || empty( $wc->cart ) || empty( $wc->session ) ) {
            return;
        }
        if ( $wc->cart->is_empty() ) {
            return;
        }

        $session_key = (string) $wc->session->get_customer_id();
        if ( '' === $session_key ) {
            return;
        }

        $user_id  = get_current_user_id();
        $email    = self::guess_customer_email();
        $currency = function_exists( 'get_woocommerce_currency' ) ? (string) get_woocommerce_currency() : '';
        $cart_hash = method_exists( $wc->cart, 'get_cart_hash' ) ? (string) $wc->cart->get_cart_hash() : '';

        // Total (edit context to avoid formatting). Fallback to cart contents total.
        $total = 0.0;
        if ( isset( $wc->cart->total ) ) {
            $total = (float) $wc->cart->total;
        } else {
            $total = (float) $wc->cart->get_cart_contents_total();
        }

        $items = array();
        foreach ( (array) $wc->cart->get_cart() as $cart_item_key => $cart_item ) {
            $product_id = isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
            $qty        = isset( $cart_item['quantity'] ) ? (int) $cart_item['quantity'] : 0;
            if ( $product_id > 0 && $qty > 0 ) {
                $items[] = array(
                    'product_id' => $product_id,
                    'qty'        => $qty,
                );
            }
        }

        self::upsert_cart( array(
            'session_key' => $session_key,
            'user_id'     => $user_id,
            'email'       => $email,
            'cart_hash'   => $cart_hash,
            'cart_total'  => $total,
            'currency'    => $currency,
            'items_json'  => wp_json_encode( $items ),
        ) );
    }

    private static function guess_customer_email() {
        // Logged-in users.
        $user_id = get_current_user_id();
        if ( $user_id ) {
            $u = get_user_by( 'id', $user_id );
            if ( $u && ! empty( $u->user_email ) ) {
                return (string) $u->user_email;
            }
        }

        // WooCommerce customer/session.
        if ( function_exists( 'WC' ) ) {
            $customer = WC()->customer;
            if ( $customer && method_exists( $customer, 'get_email' ) ) {
                $email = (string) $customer->get_email();
                if ( is_email( $email ) ) {
                    return $email;
                }
            }
        }

        // Checkout posted email (AJAX order review updates).
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if ( isset( $_POST['billing_email'] ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $email = sanitize_email( wp_unslash( $_POST['billing_email'] ) );
            if ( is_email( $email ) ) {
                return $email;
            }
        }

        return '';
    }

    private static function upsert_cart( $data ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pmcpc_abandoned_carts';

        $session_key = (string) $data['session_key'];
        $now_mysql   = self::now_mysql();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $existing_id = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$table} WHERE session_key = %s LIMIT 1",
                $session_key
            )
        );

        $row = array(
            'session_key'       => $session_key,
            'user_id'           => (int) $data['user_id'],
            'email'             => (string) $data['email'],
            'cart_hash'         => (string) $data['cart_hash'],
            'cart_total'        => (float) $data['cart_total'],
            'currency'          => (string) $data['currency'],
            'items_json'        => (string) $data['items_json'],
            'status'            => 'active',
            'abandoned_at'      => null,
            'recovered_at'      => null,
            'updated_at'        => $now_mysql,
            'last_activity_at'  => $now_mysql,
        );

        if ( $existing_id > 0 ) {
            // If it was previously abandoned but the cart is active again, revive it.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            // Clear any stale abandoned/recovery state when the cart becomes active again.
            $row['recovery_status']       = 'none';
            $row['recovery_step']         = 0;
            $row['recovery_next_at']      = null;
            $row['recovery_started_at']   = null;
            $row['recovery_completed_at'] = null;

            $wpdb->update(
                $table,
                $row,
                array( 'id' => $existing_id ),
                array( '%s','%d','%s','%s','%f','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s','%s' ),
                array( '%d' )
            );
        } else {
            $row['created_at'] = $now_mysql;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $wpdb->insert(
                $table,
                $row,
                array( '%s','%d','%s','%s','%f','%s','%s','%s','%s','%s','%s' )
            );
        }
    }

    public static function attach_session_to_order( $order, $data ) {
        if ( ! function_exists( 'WC' ) ) {
            return;
        }
        $session_key = (string) WC()->session->get_customer_id();
        if ( '' !== $session_key && is_object( $order ) && method_exists( $order, 'update_meta_data' ) ) {
            $order->update_meta_data( '_pmcpc_session_key', $session_key );
        }
    }

    public static function mark_recovered_from_order( $order_id, $posted_data, $order ) {
        if ( empty( $order_id ) ) {
            return;
        }

        $session_key = '';
        $email       = '';
        $user_id     = 0;

        if ( $order && is_object( $order ) ) {
            if ( method_exists( $order, 'get_meta' ) ) {
                $session_key = (string) $order->get_meta( '_pmcpc_session_key' );
            }
            if ( method_exists( $order, 'get_billing_email' ) ) {
                $email = (string) $order->get_billing_email();
            }
            if ( method_exists( $order, 'get_customer_id' ) ) {
                $user_id = (int) $order->get_customer_id();
            }
        }

        self::mark_recovered( $session_key, $email, $user_id );
    }

    private static function mark_recovered( $session_key, $email, $user_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pmcpc_abandoned_carts';
        $now_mysql = self::now_mysql();

        $where = array();
        $sql_where = array();

        if ( '' !== $session_key ) {
            $sql_where[] = $wpdb->prepare( 'session_key = %s', $session_key );
        }
        if ( is_email( $email ) ) {
            $sql_where[] = $wpdb->prepare( 'email = %s', $email );
        }
        if ( $user_id > 0 ) {
            $sql_where[] = $wpdb->prepare( 'user_id = %d', $user_id );
        }

        if ( empty( $sql_where ) ) {
            return;
        }

        $where_sql = implode( ' OR ', $sql_where );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $set = "status = 'recovered', recovered_at = '{$now_mysql}', updated_at = '{$now_mysql}'";
        // If recovery sequencing columns exist, mark them too.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $has_cols = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", 'recovery_status' ) );
        if ( ! empty( $has_cols ) ) {
            $set .= ", recovery_status = 'recovered', recovery_completed_at = '{$now_mysql}'";
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query(
            "UPDATE {$table}
             SET {$set}
             WHERE ( {$where_sql} )
               AND status IN ('active','abandoned')"
        );
    }

    /**
     * Queue abandoned cart recovery emails (premium).
     *
     * This runs on cron. It is designed to be safe to run frequently.
     */
    public static function process_recovery_queue() {
        self::ensure_cron();

        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        // Only run when WooCommerce automation is enabled (trial or license).
        if ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() ) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pmcpc_abandoned_carts';

        $now = self::now_mysql();

        // Ensure recovery columns exist (safe even if already present).
        if ( class_exists( 'PMCPC_Activator' ) ) {
            PMCPC_Activator::maybe_upgrade();
        }

        // Process a small batch to keep requests fast.
        $limit = 50;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table}
                 WHERE status = 'abandoned'
                   AND (recovery_status IS NULL OR recovery_status = '' OR recovery_status = 'none' OR recovery_status = 'in_progress')
                   AND email <> ''
                   AND (recovery_next_at IS NULL OR recovery_next_at <= %s)
                 ORDER BY abandoned_at ASC
                 LIMIT %d",
                $now,
                $limit
            ),
            ARRAY_A
        );

        if ( empty( $rows ) ) {
            return;
        }

        foreach ( $rows as $cart ) {
            $cart_id = isset( $cart['id'] ) ? (int) $cart['id'] : 0;
            if ( ! $cart_id ) {
                continue;
            }

            $email = isset( $cart['email'] ) ? sanitize_email( (string) $cart['email'] ) : '';
            if ( ! $email || ! is_email( $email ) ) {
                continue;
            }

            $step   = isset( $cart['recovery_step'] ) ? (int) $cart['recovery_step'] : 0;
            $status = isset( $cart['recovery_status'] ) ? (string) $cart['recovery_status'] : 'none';
            if ( '' === $status ) {
                $status = 'none';
            }

			// If the sequence is uninitialised, anchor Step 1 to abandoned_at, not to when the runner first notices the cart.
			if ( 'none' === $status ) {
				$delay_step1     = self::get_recovery_delay_minutes_for_step( 1 );
				$abandoned_at    = ! empty( $cart['abandoned_at'] ) ? (string) $cart['abandoned_at'] : $now;
				$first_due_at    = self::mysql_add_minutes( $abandoned_at, $delay_step1 );
				$started_at      = ( isset( $cart['recovery_started_at'] ) && ! empty( $cart['recovery_started_at'] ) ) ? (string) $cart['recovery_started_at'] : $abandoned_at;

				// If Step 1 is not due yet, prime the sequence and wait.
				if ( self::mysql_time_is_future( $first_due_at ) ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->update(
						$table,
						array(
							'recovery_status'     => 'in_progress',
							'recovery_step'       => 0,
							'recovery_next_at'    => $first_due_at,
							'recovery_started_at' => $started_at,
							'updated_at'          => $now,
						),
						array( 'id' => $cart_id ),
						array( '%s', '%d', '%s', '%s', '%s' ),
						array( '%d' )
					);
					continue;
				}

				// Step 1 is already due; fall through and send it on this run.
				$status                  = 'in_progress';
				$step                    = 0;
				$cart['recovery_started_at'] = $started_at;
			}

			// Progress to next step.
			$step   = (int) $step + 1;
			$status = 'in_progress';

            if ( $step > 3 ) {
                // Completed.
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $wpdb->update(
                    $table,
                    array(
                        'recovery_status'       => 'completed',
                        'recovery_step'         => 3,
                        'recovery_next_at'      => null,
                        'recovery_completed_at' => $now,
                        'updated_at'            => $now,
                    ),
                    array( 'id' => $cart_id ),
                    array( '%s', '%d', '%s', '%s', '%s' ),
                    array( '%d' )
                );
                continue;
            }

            // Ensure subscriber exists for this cart email.
            if ( class_exists( 'PMCPC_Subscriber_Manager' ) ) {
                PMCPC_Subscriber_Manager::upsert_subscriber( $email );
            }

            // Build context for template vars.
            $cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' );
            $context  = array(
                'cart_id'     => $cart_id,
                'cart_total'  => isset( $cart['cart_total'] ) ? (string) $cart['cart_total'] : '',
                'currency'    => isset( $cart['currency'] ) ? (string) $cart['currency'] : '',
                'cart_url'    => $cart_url,
                'items_json'  => isset( $cart['items_json'] ) ? (string) $cart['items_json'] : '[]',
            );

            // Provide a formatted total for templates.
            if ( isset( $cart['cart_total'] ) && (float) $cart['cart_total'] > 0 && function_exists( 'wc_price' ) ) {
                $context['cart_total'] = wp_strip_all_tags( wc_price( (float) $cart['cart_total'], array( 'currency' => $context['currency'] ) ) );
            }

            // Provide a simple HTML block for {{cart_items}}.
            $context['cart_items_html'] = self::build_cart_items_html( $context['items_json'] );

            // Fire unified automation trigger (campaigns decide audience + delay + content).
            // Abandoned-cart step timing is already handled here, so force queue delay to zero when the step becomes due.
            $trigger_key = 'abandoned_cart_step_' . $step;
            $context['__pmcpc_force_zero_delay'] = true;
            $context['__pmcpc_trigger_key']      = $trigger_key;
            $queued_before = 0;
            if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
                PMCPC_Activity_Feed::log(
                    sprintf(
                        /* translators: 1: email address, 2: step number */
                        __( 'Abandoned cart recovery checked %1$s for Step %2$d.', 'product-mailer-campaigns' ),
                        $email,
                        (int) $step
                    )
                );
            }
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $queued_before = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}pmcpc_email_queue q INNER JOIN {$wpdb->prefix}pmcpc_campaigns c ON c.id = q.campaign_id WHERE q.to_email = %s AND c.automation_trigger = %s",
                    $email,
                    $trigger_key
                )
            );
            if ( class_exists( 'PMCPC_Automation_Dispatcher' ) ) {
                PMCPC_Automation_Dispatcher::fire_for_email( $trigger_key, $email, $context );
            }
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $queued_after = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}pmcpc_email_queue q INNER JOIN {$wpdb->prefix}pmcpc_campaigns c ON c.id = q.campaign_id WHERE q.to_email = %s AND c.automation_trigger = %s",
                    $email,
                    $trigger_key
                )
            );
            if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
                if ( $queued_after > $queued_before ) {
                    PMCPC_Activity_Feed::log(
                        sprintf(
                            /* translators: 1: step number, 2: email address */
                            __( 'Abandoned cart Step %1$d queued for %2$s.', 'product-mailer-campaigns' ),
                            (int) $step,
                            $email
                        )
                    );
                } else {
                    PMCPC_Activity_Feed::log(
                        sprintf(
                            /* translators: 1: step number, 2: email address */
                            __( 'Abandoned cart Step %1$d became due for %2$s, but no queue row was created.', 'product-mailer-campaigns' ),
                            (int) $step,
                            $email
                        )
                    );
                }
            }

            // Determine schedule for the NEXT step.
            $next_delay_minutes = self::get_recovery_delay_minutes_for_step( $step + 1 );
            $next_at = self::mysql_add_minutes( $now, $next_delay_minutes );

            // Update cart recovery state.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update(
                $table,
                array(
                    'recovery_status'     => $status,
                    'recovery_step'       => $step,
                    'recovery_next_at'    => ( $step < 3 ? $next_at : null ),
                    'recovery_started_at' => ( isset( $cart['recovery_started_at'] ) && ! empty( $cart['recovery_started_at'] ) ) ? (string) $cart['recovery_started_at'] : $now,
                    'updated_at'          => $now,
                ),
                array( 'id' => $cart_id ),
                array( '%s', '%d', '%s', '%s', '%s' ),
                array( '%d' )
            );
        }
    }

    /**
     * Ensure the 3 system campaigns exist for recovery steps.
     */
    protected static function ensure_recovery_campaigns() {
        for ( $i = 1; $i <= 3; $i++ ) {
            self::get_recovery_campaign_id_for_step( $i );
        }
    }

    protected static function get_recovery_campaign_id_for_step( $step ) {
        global $wpdb;
        $step = (int) $step;
        if ( $step < 1 || $step > 3 ) { return 0; }

        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        $trigger = 'abandoned_cart_step_' . $step;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $existing = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE automation_trigger = %s LIMIT 1', $campaigns_table, $trigger ) );
        if ( $existing > 0 ) {
            return $existing;
        }

        $from_name  = get_bloginfo( 'name' );
        $from_email = get_option( 'admin_email' );
        if ( class_exists( 'PMCPC_Settings' ) ) {
            $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );
            $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );
            if ( ! empty( $from_name_setting ) ) { $from_name = $from_name_setting; }
            if ( ! empty( $from_email_setting ) ) { $from_email = $from_email_setting; }
        }

        $now = self::now_mysql();
        $name = sprintf( 'Abandoned Cart Recovery (Step %d)', $step );

        $content = '<p>' . esc_html__( 'System campaign created by FlowPress.', 'product-mailer-campaigns' ) . '</p>';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $wpdb->insert(
            $campaigns_table,
            array(
                'name'               => $name,
                'campaign_type'      => 'automation',
                'automation_trigger' => $trigger,
                'subject'            => self::get_recovery_subject_for_step( $step ),
                'from_name'          => $from_name,
                'from_email'         => sanitize_email( $from_email ),
                'content'            => $content,
                'status'             => 'active',
                'created_at'         => $now,
                'updated_at'         => $now,
            ),
            array( '%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' )
        );

        return (int) $wpdb->insert_id;
    }

    protected static function get_recovery_subject_for_step( $step ) {
        $step = (int) $step;
        $site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
        switch ( $step ) {
            case 1:
                return sprintf( __( 'You left something in your cart at %s', 'product-mailer-campaigns' ), $site );
            case 2:
                return sprintf( __( 'Still thinking it over? Your cart is waiting — %s', 'product-mailer-campaigns' ), $site );
            case 3:
            default:
                return sprintf( __( 'Last chance to complete your order — %s', 'product-mailer-campaigns' ), $site );
        }
    }

    public static function get_recovery_delay_minutes_for_step( $step ) {
        $step = (int) $step;
        if ( $step < 1 || $step > 3 ) {
            return 0;
        }

		// Prefer the workflow step campaign delay (Delay after trigger) when it is
		// intentionally set above zero. A zero value on abandoned-cart steps used to
		// be created by the starter setup and caused all three emails to queue at the
		// same time, so zero now falls back to the staggered recovery defaults.
		$delay = self::get_step_delay_minutes_from_campaign( $step );
		if ( null !== $delay && (int) $delay > 0 ) {
			return max( 0, (int) $delay );
		}

		// Fallback defaults (filterable for developers).
		if ( 1 === $step ) {
			return (int) apply_filters( 'pmcpc_abandoned_cart_step1_delay_minutes', self::DEFAULT_STEP1_DELAY_MINUTES );
		}
		if ( 2 === $step ) {
			return (int) apply_filters( 'pmcpc_abandoned_cart_step2_delay_minutes', self::DEFAULT_STEP2_DELAY_MINUTES );
		}
		return (int) apply_filters( 'pmcpc_abandoned_cart_step3_delay_minutes', self::DEFAULT_STEP3_DELAY_MINUTES );
    }

	/**
	 * Read the delay (in minutes) for a given abandoned cart step from the
	 * corresponding campaign's trigger_delay_minutes.
	 *
	 * @param int $step
	 * @return int|null Returns null when no campaign row exists yet. An explicit 0
	 *                  means the campaign is configured to send immediately.
	 */
	protected static function get_step_delay_minutes_from_campaign( $step ) {
		$step = (int) $step;
		if ( $step < 1 || $step > 3 ) {
			return null;
		}

		global $wpdb;
		$campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
		$trigger         = 'abandoned_cart_step_' . $step;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT trigger_delay_minutes FROM {$campaigns_table} WHERE automation_trigger = %s AND status IN ('active','draft','paused','scheduled') ORDER BY id ASC LIMIT 1",
				$trigger
			)
		);
		if ( $row && isset( $row->trigger_delay_minutes ) ) {
			return max( 0, (int) $row->trigger_delay_minutes );
		}
		return null;
	}

    protected static function now_mysql() {
        $offset_minutes = (int) get_option( 'pmcpc_testing_time_offset_minutes', 0 );
        $timestamp      = current_time( 'timestamp', true ) + ( $offset_minutes * MINUTE_IN_SECONDS );
        return gmdate( 'Y-m-d H:i:s', $timestamp );
    }

    protected static function mysql_add_minutes( $mysql_datetime, $minutes ) {
        $minutes  = (int) $minutes;
        $timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
        $base     = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', (string) $mysql_datetime, $timezone );

        if ( ! $base ) {
            $base = new DateTimeImmutable( 'now', $timezone );
        }

        if ( 0 !== $minutes ) {
            $base = $base->modify( ( $minutes > 0 ? '+' : '' ) . $minutes . ' minutes' );
        }

        return $base->format( 'Y-m-d H:i:s' );
    }

    protected static function mysql_time_is_future( $mysql_datetime ) {
        $timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
        $value    = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', (string) $mysql_datetime, $timezone );

        if ( ! $value ) {
            return false;
        }

        $offset_minutes = (int) get_option( 'pmcpc_testing_time_offset_minutes', 0 );
        $now_timestamp   = current_time( 'timestamp', true ) + ( $offset_minutes * MINUTE_IN_SECONDS );
        $now             = ( new DateTimeImmutable( '@' . $now_timestamp ) )->setTimezone( $timezone );

        return $value->getTimestamp() > $now->getTimestamp();
    }

    protected static function build_recovery_email_html( $step, $cart ) {
        $step = (int) $step;
        $cart_total = isset( $cart['cart_total'] ) ? (float) $cart['cart_total'] : 0.0;
        $currency   = isset( $cart['currency'] ) ? (string) $cart['currency'] : '';
        $items_json = isset( $cart['items_json'] ) ? (string) $cart['items_json'] : '[]';
        $items      = json_decode( $items_json, true );
        if ( ! is_array( $items ) ) { $items = array(); }

        $cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' );
        $shop     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

        $intro = '';
        if ( 1 === $step ) {
            $intro = __( 'It looks like you left a few items in your cart. If you had any questions, just reply to this email.', 'product-mailer-campaigns' );
        } elseif ( 2 === $step ) {
            $intro = __( 'Just a quick reminder — your cart is still available. Complete your order before items sell out.', 'product-mailer-campaigns' );
        } else {
            $intro = __( 'Final reminder — complete your order now to secure your items.', 'product-mailer-campaigns' );
        }

        $html  = '<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.5;">';
        $html .= '<p>' . esc_html( $intro ) . '</p>';

        if ( ! empty( $items ) ) {
            $html .= '<h3 style="margin:18px 0 10px;">' . esc_html__( 'Items in your cart', 'product-mailer-campaigns' ) . '</h3>';
            $html .= '<ul style="padding-left:18px;">';
            foreach ( $items as $it ) {
                $pid = isset( $it['product_id'] ) ? (int) $it['product_id'] : 0;
                $qty = isset( $it['qty'] ) ? (int) $it['qty'] : 0;
                if ( $pid > 0 ) {
                    $title = get_the_title( $pid );
                    $link  = get_permalink( $pid );
                    $line  = ( $qty > 1 ) ? sprintf( '%s × %d', $title, $qty ) : $title;
                    $html .= '<li><a href="' . esc_url( $link ) . '">' . esc_html( $line ) . '</a></li>';
                }
            }
            $html .= '</ul>';
        }

        if ( $cart_total > 0 ) {
            $formatted = function_exists( 'wc_price' ) ? wc_price( $cart_total, array( 'currency' => $currency ) ) : number_format_i18n( $cart_total, 2 );
            $html .= '<p style="margin:10px 0;">' . sprintf( esc_html__( 'Cart total: %s', 'product-mailer-campaigns' ), wp_kses_post( $formatted ) ) . '</p>';
        }

        $html .= '<p style="margin:18px 0;">'
            . '<a href="' . esc_url( $cart_url ) . '" style="display:inline-block;padding:10px 16px;text-decoration:none;border-radius:6px;background:#111;color:#fff;">'
            . esc_html__( 'Return to your cart', 'product-mailer-campaigns' )
            . '</a>'
            . '</p>';

        $html .= '<p style="color:#666;font-size:12px;">' . sprintf( esc_html__( 'Sent by %s', 'product-mailer-campaigns' ), esc_html( $shop ) ) . '</p>';
        $html .= '</div>';

        return $html;
    }

    /**
     * Build a simple HTML list of cart items for template insertion.
     *
     * Used as {{cart_items}} via the pmcpc_campaign_template_vars filter.
     *
     * @param string $items_json
     * @return string
     */
    protected static function build_cart_items_html( $items_json ) {
        $items = json_decode( (string) $items_json, true );
        if ( ! is_array( $items ) || empty( $items ) ) {
            return '';
        }

        $html = '<ul style="padding-left:18px;margin:10px 0;">';
        foreach ( $items as $it ) {
            $pid = isset( $it['product_id'] ) ? (int) $it['product_id'] : 0;
            $qty = isset( $it['qty'] ) ? (int) $it['qty'] : 0;
            if ( $pid < 1 ) {
                continue;
            }
            $title = get_the_title( $pid );
            $link  = get_permalink( $pid );
            $line  = ( $qty > 1 ) ? sprintf( '%s × %d', $title, $qty ) : $title;
            $html .= '<li><a href="' . esc_url( $link ) . '">' . esc_html( $line ) . '</a></li>';
        }
        $html .= '</ul>';

        return $html;
    }

    protected static function enqueue_email( $args ) {
        global $wpdb;
        $queue_table = $wpdb->prefix . 'pmcpc_email_queue';

        $now = self::now_mysql();
        $scheduled_at = isset( $args['scheduled_at'] ) ? (string) $args['scheduled_at'] : $now;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $wpdb->insert(
            $queue_table,
            array(
                'subscriber_id' => (int) $args['subscriber_id'],
                'campaign_id'   => (int) $args['campaign_id'],
                'to_email'      => (string) $args['to_email'],
                'subject'       => (string) $args['subject'],
                'body_html'     => (string) $args['body_html'],
                'scheduled_at'  => $scheduled_at,
                'attempts'      => 0,
                'status'        => 'pending',
                'created_at'    => $now,
                'updated_at'    => $now,
            ),
            array( '%d','%d','%s','%s','%s','%s','%d','%s','%s','%s' )
        );
    }

    public static function sweep_abandoned() {
        self::ensure_cron();

        global $wpdb;
        $table = $wpdb->prefix . 'pmcpc_abandoned_carts';

        $minutes = (int) get_option( 'pmcpc_cart_abandon_minutes', 60 );
        if ( $minutes < 10 ) { $minutes = 10; }

        $cutoff    = self::mysql_add_minutes( self::now_mysql(), -1 * $minutes );
        $now_mysql = self::now_mysql();

        // Mark stale active carts as abandoned.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $set_sql = "status = 'abandoned', abandoned_at = %s, updated_at = %s";
        // Normalise recovery sequencing columns for newly-abandoned carts.
        // Older rows may have empty or NULL recovery values, which would stop the runner from picking them up.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $has_recovery_cols = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", 'recovery_status' ) );
        if ( ! empty( $has_recovery_cols ) ) {
            $set_sql .= ", recovery_status = 'none', recovery_step = 0, recovery_next_at = NULL, recovery_started_at = NULL, recovery_completed_at = NULL";
        }

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table}
                 SET {$set_sql}
                 WHERE status = 'active'
                   AND last_activity_at < %s",
                $now_mysql,
                $now_mysql,
                $cutoff
            )
        );

        if ( $updated > 0 ) {
            if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
                PMCPC_Activity_Feed::log(
                    sprintf(
                        /* translators: %d: number of carts */
                        __( 'Abandoned cart sweep marked %d cart(s) abandoned.', 'product-mailer-campaigns' ),
                        (int) $updated
                    )
                );
            }
        }

        // The recovery runner now piggybacks on the sweep hook. Run it every sweep, not
        // only when new carts are marked abandoned, so later workflow steps can become due.
        if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
            self::process_recovery_queue();
        }
    }

    public static function get_abandoned_metrics( $days = 7 ) {
        global $wpdb;
        $table = $wpdb->prefix . 'pmcpc_abandoned_carts';

        $days = (int) $days;
        if ( $days < 1 ) { $days = 1; }
        if ( $days > 90 ) { $days = 90; }

        $cutoff = self::mysql_add_minutes( self::now_mysql(), (int) ( -1 * $days * 24 * 60 ) );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT COUNT(*) AS cnt, COALESCE(SUM(cart_total),0) AS total
                 FROM {$table}
                 WHERE status = 'abandoned'
                   AND abandoned_at >= %s
                   AND cart_total > 0
                   AND (user_id > 0 OR email <> '')
                   AND items_json IS NOT NULL
                   AND items_json <> '[]'",
                $cutoff
            ),
            ARRAY_A
        );

        return array(
            'count' => isset( $row['cnt'] ) ? (int) $row['cnt'] : 0,
            'total' => isset( $row['total'] ) ? (float) $row['total'] : 0.0,
            'days'  => $days,
        );
    }
}
