<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PMCPC_User_Subscriber_Sync {

    public static function init() {
        add_action( 'delete_user', array( __CLASS__, 'on_user_deleted' ), 10, 1 );
        add_action( 'pmcpc_subscriber_status_updated', array( __CLASS__, 'on_subscriber_status_updated' ), 10, 2 );
    }

    public static function on_user_deleted( $user_id ) {
        $user = get_userdata( (int) $user_id );
        if ( ! $user || empty( $user->user_email ) ) {
            return;
        }

        if ( ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {
            return;
        }

        $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $user->user_email );
        if ( ! $subscriber ) {
            return;
        }

        // Prefer hard delete if available, otherwise mark unsubscribed.
        if ( method_exists( 'PMCPC_Subscriber_Manager', 'delete_subscriber' ) ) {
            PMCPC_Subscriber_Manager::delete_subscriber( $subscriber->id );
        } else {
            PMCPC_Subscriber_Manager::update_status( $subscriber->id, 'unsubscribed' );
        }
    }

    public static function on_subscriber_status_updated( $subscriber_id, $status ) {
        if ( ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pmcpc_subscribers';

        // Table name is controlled by the plugin and not user input.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $subscriber = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $subscriber_id ) );

        if ( ! $subscriber || empty( $subscriber->email ) ) {
            return;
        }

        $user = get_user_by( 'email', (string) $subscriber->email );
        if ( ! $user ) {
            return;
        }

        if ( 'unsubscribed' === $status ) {
            update_user_meta( $user->ID, 'pmcpc_email_unsubscribed', 1 );
            update_user_meta( $user->ID, 'pmcpc_is_subscriber', 0 );
        } elseif ( 'active' === $status ) {
            update_user_meta( $user->ID, 'pmcpc_email_unsubscribed', 0 );
            update_user_meta( $user->ID, 'pmcpc_is_subscriber', 1 );
        }
    }
}
