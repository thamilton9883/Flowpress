<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Admin traits (split for maintainability).
require_once PMCPC_PLUGIN_DIR . 'includes/admin/traits/trait-pmcpc-admin-inbox.php';
require_once PMCPC_PLUGIN_DIR . 'includes/admin/traits/trait-pmcpc-admin-settings.php';
require_once PMCPC_PLUGIN_DIR . 'includes/admin/traits/trait-pmcpc-admin-dashboard.php';
require_once PMCPC_PLUGIN_DIR . 'includes/admin/class-pmcpc-admin-view-helper.php';

// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

// Many queries in this file run only on admin screens and are parameterized.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

class PMCPC_Admin {

	use PMCPC_Admin_Inbox_Trait;
	use PMCPC_Admin_Settings_Trait;
	use PMCPC_Admin_Dashboard_Trait;


	/**
	 * Render a stored sent email (HTML) from the email log.
	 *
	 * @return void
	 */
	public static function render_email_preview() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		global $wpdb;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only view parameter.
		$id = isset( $_GET['log_id'] ) ? absint( wp_unslash( $_GET['log_id'] ) ) : 0;

		$table = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );

		echo '<div class="wrap">';
		if ( empty( $row ) ) {
			echo '<h1>' . esc_html__( 'Email not found', 'product-mailer-campaigns' ) . '</h1>';
			echo '</div>';
			return;
		}

		$subject = isset( $row->subject ) ? (string) $row->subject : '';
		$to      = isset( $row->to_email ) ? (string) $row->to_email : '';
		$html    = isset( $row->body_html ) ? (string) $row->body_html : '';

		echo '<h1>' . esc_html( $subject ) . '</h1>';
		echo '<p><strong>' . esc_html__( 'To:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $to ) . '</p>';

		if ( ! empty( $html ) ) {
			$resend_url = wp_nonce_url(
				admin_url( 'admin-post.php?action=pmcpc_resend_email&log_id=' . (int) $row->id ),
				'pmcpc_resend_email_' . (int) $row->id
			);
			echo '<p><a class="button button-primary" href="' . esc_url( $resend_url ) . '">' . esc_html__( 'Resend this email', 'product-mailer-campaigns' ) . '</a></p>';
			echo '<hr />';
			echo '<div style="background:#fff;padding:20px;border:1px solid #ccd0d4;max-width:1000px">';
			// Stored HTML created by this plugin at send time.
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo $html;
			echo '</div>';
		} else {
			echo '<p>' . esc_html__( 'No stored email body is available for this log entry.', 'product-mailer-campaigns' ) . '</p>';
		}

		echo '</div>';
	}

	/**
	 * Admin-post handler to resend a stored email log entry.
	 *
	 * @return void
	 */
	public static function handle_resend_email() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Access denied.', 'product-mailer-campaigns' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only view parameter.
		$id = isset( $_GET['log_id'] ) ? absint( wp_unslash( $_GET['log_id'] ) ) : 0;
		check_admin_referer( 'pmcpc_resend_email_' . $id );

		global $wpdb;
		$table = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );

		if ( empty( $row ) ) {
			wp_die( esc_html__( 'Email log entry not found.', 'product-mailer-campaigns' ) );
		}

		$to      = isset( $row->to_email ) ? (string) $row->to_email : '';
		$subject = isset( $row->subject ) ? (string) $row->subject : '';
		$html    = isset( $row->body_html ) ? (string) $row->body_html : '';

		if ( '' === $to || '' === $subject || '' === $html ) {
			wp_die( esc_html__( 'This log entry does not have enough data to resend.', 'product-mailer-campaigns' ) );
		}

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		$ok      = wp_mail( $to, $subject, $html, $headers );

		$redirect = wp_get_referer();
		if ( empty( $redirect ) ) {
			$redirect = admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=history' );
		}

		$redirect = add_query_arg( 'pmcpc_resend', $ok ? 'success' : 'failed', $redirect );
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Render a small Pro upsell box on plugin admin screens.
	 *
	 * Only shows when Pro is not active and only where explicitly called.
	 *
	 * @return void
	 */
	public static function render_pro_upsell_box() {
		if ( function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features() ) {
			return;
		}

		if ( function_exists( 'pmcpc_is_pro_active' ) && pmcpc_is_pro_active() ) {
			return;
		}

		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		echo '<div class="pmcpc-settings-card pmcpc-settings-promo-card">';
		echo '<h3>' . esc_html__( 'Want WooCommerce sales automations?', 'product-mailer-campaigns' ) . '</h3>';
		echo '<p>' . esc_html__( 'Upgrade to FlowPress Commerce and unlock post-purchase flows, win-back campaigns, and revenue automation for your WooCommerce store.', 'product-mailer-campaigns' ) . '</p>';
		echo '<ul>';
		echo '<li>' . esc_html__( 'Automated post-purchase emails', 'product-mailer-campaigns' ) . '</li>';
		echo '<li>' . esc_html__( 'Win-back campaigns for inactive customers', 'product-mailer-campaigns' ) . '</li>';
		echo '<li>' . esc_html__( 'Segmentation by spend, products, and categories', 'product-mailer-campaigns' ) . '</li>';
		echo '</ul>';
		echo '<div class="pmcpc-settings-promo-actions">';
		echo '<a class="button button-primary" href="' . esc_url( function_exists( 'pmcpc_pricing_url' ) ? pmcpc_pricing_url() : 'https://flowpress.uk/pricing/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'View FlowPress Commerce', 'product-mailer-campaigns' ) . '</a>';
		echo '<a class="button" href="' . esc_url( function_exists( 'pmcpc_docs_url' ) ? pmcpc_docs_url() : 'https://flowpress.uk/docs/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Documentation', 'product-mailer-campaigns' ) . '</a>';
		echo '<a class="button" href="' . esc_url( function_exists( 'pmcpc_account_url' ) ? pmcpc_account_url() : 'https://flowpress.uk/my-account/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'My account', 'product-mailer-campaigns' ) . '</a>';
		echo '</div>';
		echo '</div>';
	}


	// Table names are built from $wpdb->prefix and are not user-controlled.
	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared


	/**
	 * Shared in-app brand label used across admin screens.
	 *
	 * @return string
	 */
	public static function app_brand() {
		return PMCPC_Admin_View_Helper::app_brand();
	}

	/**
	 * Shared tagline shown in the custom admin header.
	 *
	 * @return string
	 */
	public static function app_tagline() {
		return PMCPC_Admin_View_Helper::app_tagline();
	}

	/**
	 * Normalize repetitive admin labels into plainer user-facing copy.
	 *
	 * @param string $text Source label or message.
	 * @return string
	 */
	public static function normalize_admin_copy( $text ) {
		return PMCPC_Admin_View_Helper::normalize_admin_copy( $text );
	}


	/**
	 * Enqueue shared admin polish assets for plugin screens.
	 *
	 * @return void
	 */
	public static function enqueue_polish_assets() {
		if ( ! self::is_plugin_admin_page() ) {
			return;
		}

		$css_path = PMCPC_PLUGIN_DIR . 'assets/css/pmcpc-admin-polish.css';
		$js_path  = PMCPC_PLUGIN_DIR . 'assets/js/pmcpc-admin-polish.js';
		$css_url  = PMCPC_PLUGIN_URL . 'assets/css/pmcpc-admin-polish.css';
		$js_url   = PMCPC_PLUGIN_URL . 'assets/js/pmcpc-admin-polish.js';

		if ( file_exists( $css_path ) ) {
			wp_enqueue_style(
				'pmcpc-admin-polish',
				$css_url,
				array(),
				(string) filemtime( $css_path )
			);
		}

		if ( file_exists( $js_path ) ) {
			wp_enqueue_script(
				'pmcpc-admin-polish',
				$js_url,
				array(),
				(string) filemtime( $js_path ),
				true
			);
		}
	}


	/**
	 * Determine whether the current admin screen belongs to this plugin.
	 *
	 * @return bool
	 */
	public static function is_plugin_admin_page() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing param.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( '' !== $page && ( 0 === strpos( (string) $page, 'pmcpc_' ) || 0 === strpos( (string) $page, 'pmcpc-' ) ) ) {
			return true;
		}

		// Subscriber Updates CPT screens also belong to the shared workspace.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing params.
		$post_type = isset( $_GET['post_type'] ) ? sanitize_key( wp_unslash( $_GET['post_type'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing params.
		$post = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0;
		if ( 'pmcpc_sub_update' === $post_type ) {
			return true;
		}
		if ( $post > 0 ) {
			$ptype = get_post_type( $post );
			if ( 'pmcpc_sub_update' === $ptype ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Build a consistent plugin-wide notification list for plugin admin pages.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function get_notification_items() {
		$items = array();
		$hide_paid_features = function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features();

		if ( ! current_user_can( 'manage_options' ) ) {
			return $items;
		}

		global $wpdb;
		$table_exists = static function( $table ) use ( $wpdb ) {
			if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || empty( $table ) ) {
				return false;
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
		};

		if ( ! $hide_paid_features && class_exists( 'WooCommerce' ) && function_exists( 'pmcpc_wc_automation_enabled' ) && ! pmcpc_wc_automation_enabled() ) {
			$trial_active = function_exists( 'pmcpc_trial' ) && pmcpc_trial()->is_active();
			$trial_used   = 'yes' === (string) get_option( 'pmcpc_trial_used', 'no' );
			$actions      = array();

			if ( $trial_active ) {
				$items[] = array(
					'type'    => 'info',
					'icon'    => 'dashicons-controls-repeat',
					'title'   => __( 'WooCommerce automations are enabled during your trial', 'product-mailer-campaigns' ),
					'message' => __( 'Your trial is active. Activate Commerce any time to keep abandoned cart recovery, post-purchase journeys, and customer segments running after the trial ends.', 'product-mailer-campaigns' ),
					'actions' => array(
						array(
							'label' => __( 'End Trial Now', 'product-mailer-campaigns' ),
							'url'   => wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_end_trial' ), 'pmcpc_end_trial' ),
							'class' => '',
						),
						array(
							'label' => __( 'Activate Commerce', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_upgrade' ),
							'class' => 'button-primary',
						),
					),
				);
			} elseif ( $trial_used ) {
				$items[] = array(
					'type'    => 'warning',
					'icon'    => 'dashicons-lock',
					'title'   => __( 'WooCommerce automations are visible but locked', 'product-mailer-campaigns' ),
					'message' => __( 'Your free trial has ended. Activate Commerce to resume abandoned cart recovery, post-purchase journeys, and customer segments.', 'product-mailer-campaigns' ),
					'actions' => array(
						array(
							'label' => __( 'Activate Commerce', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_upgrade' ),
							'class' => 'button-primary',
						),
						array(
							'label' => __( 'View automations', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_automations' ),
							'class' => '',
						),
					),
				);
			} else {
				$items[] = array(
					'type'    => 'info',
					'icon'    => 'dashicons-controls-repeat',
					'title'   => __( 'WooCommerce automations are available but not enabled', 'product-mailer-campaigns' ),
					'message' => __( 'Start a 14-day trial or activate Commerce to enable abandoned cart recovery, post-purchase journeys, and customer segments.', 'product-mailer-campaigns' ),
					'actions' => array(
						array(
							'label' => __( 'Start Free Trial', 'product-mailer-campaigns' ),
							'url'   => wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' ),
							'class' => 'button-primary',
						),
						array(
							'label' => __( 'Activate Commerce', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_upgrade' ),
							'class' => '',
						),
					),
				);
			}
		}

		if ( ! $hide_paid_features && function_exists( 'pmcpc_license' ) && function_exists( 'pmcpc_trial' ) && ! pmcpc_license()->is_active() ) {
			$expires = (int) pmcpc_trial()->expires_at();
			$used    = get_option( 'pmcpc_trial_used', 'no' );

			if ( pmcpc_trial()->is_active() ) {
				$days = (int) pmcpc_trial()->days_left();
				if ( $days <= 3 ) {
					$items[] = array(
						'type'    => 'warning',
						'icon'    => 'dashicons-clock',
						'title'   => __( 'Your FlowPress Commerce trial is ending soon', 'product-mailer-campaigns' ),
						'message' => sprintf( _n( '%d day left before WooCommerce automations pause.', '%d days left before WooCommerce automations pause.', $days, 'product-mailer-campaigns' ), $days ),
						'actions' => array(
							array(
								'label' => __( 'View Commerce options', 'product-mailer-campaigns' ),
								'url'   => admin_url( 'admin.php?page=pmcpc_upgrade' ),
								'class' => 'button-primary',
							),
						),
					);
				}
			} elseif ( 'yes' === (string) $used && class_exists( 'WooCommerce' ) && $expires > 0 && time() > $expires ) {
				$items[] = array(
					'type'    => 'error',
					'icon'    => 'dashicons-warning',
					'title'   => __( 'Trial ended — WooCommerce automations are paused', 'product-mailer-campaigns' ),
					'message' => __( 'Your existing automation campaigns remain saved, but WooCommerce automated sends are paused until you activate Commerce.', 'product-mailer-campaigns' ),
					'actions' => array(
						array(
							'label' => __( 'Activate Commerce', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_upgrade' ),
							'class' => 'button-primary',
						),
						array(
							'label' => __( 'View automations', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_automations' ),
							'class' => '',
						),
					),
				);
			}
		}


		if ( function_exists( 'pmcpc_license' ) && pmcpc_license()->is_active() ) {
			$license_expires = (int) pmcpc_license()->expires_at();
			if ( $license_expires > 0 ) {
				$license_days = max( 0, (int) ceil( ( $license_expires - time() ) / DAY_IN_SECONDS ) );
				$expiry_label = wp_date( get_option( 'date_format', 'F j, Y' ), $license_expires );
				if ( $license_days <= 30 ) {
					$items[] = array(
						'type'    => $license_days <= 7 ? 'warning' : 'info',
						'icon'    => 'dashicons-clock',
						'title'   => $license_days <= 7
							? __( 'Your Commerce license expires very soon', 'product-mailer-campaigns' )
							: __( 'Your Commerce license expires soon', 'product-mailer-campaigns' ),
						'message' => sprintf(
							/* translators: 1: days left, 2: expiry date */
							_n( 'Commerce features are active for %1$d more day, expiring on %2$s.', 'Commerce features are active for %1$d more days, expiring on %2$s.', $license_days, 'product-mailer-campaigns' ),
							$license_days,
							$expiry_label
						),
						'actions' => array(
							array(
								'label' => __( 'Manage Commerce license', 'product-mailer-campaigns' ),
								'url'   => admin_url( 'admin.php?page=pmcpc_upgrade' ),
								'class' => 'button-primary',
							),
							array(
								'label' => __( 'Open account', 'product-mailer-campaigns' ),
								'url'   => function_exists( 'pmcpc_account_url' ) ? pmcpc_account_url() : 'https://flowpress.uk/my-account/',
								'class' => '',
							),
						),
					);
				}
			}
		}

		$skipped_domain = get_transient( 'pmcpc_notice_auto_block_skipped' );
		if ( $skipped_domain ) {
			delete_transient( 'pmcpc_notice_auto_block_skipped' );
			$skipped_domain = strtolower( trim( (string) $skipped_domain ) );
			if ( '' !== $skipped_domain ) {
				$items[] = array(
					'type'    => 'warning',
					'icon'    => 'dashicons-shield-alt',
					'title'   => __( 'Protected email domain was not auto-blocked', 'product-mailer-campaigns' ),
					'message' => sprintf( __( 'Spam protection skipped auto-blocking for "%s" because it is a protected or shared email provider. Add it manually under Additional blocked domains if you really want to block it.', 'product-mailer-campaigns' ), $skipped_domain ),
					'actions' => array(
						array(
							'label' => __( 'Open settings', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_settings' ),
							'class' => '',
						),
					),
				);
			}
		}

		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
			$items[] = array(
				'type'    => 'warning',
				'icon'    => 'dashicons-clock',
				'title'   => __( 'WP-Cron appears disabled', 'product-mailer-campaigns' ),
				'message' => __( 'Queue processing and automation timing may rely on a real server cron job.', 'product-mailer-campaigns' ),
				'actions' => array(
					array(
						'label' => __( 'Open diagnostics', 'product-mailer-campaigns' ),
						'url'   => admin_url( 'admin.php?page=pmcpc_diagnostics' ),
						'class' => '',
					),
				),
			);
		}

		$queue_next = wp_next_scheduled( 'pmcpc_process_email_queue' );
		if ( false === $queue_next ) {
			$items[] = array(
				'type'    => 'warning',
				'icon'    => 'dashicons-email-alt',
				'title'   => __( 'Email queue processor is not scheduled', 'product-mailer-campaigns' ),
				'message' => __( 'Queued emails may not send until the queue processor is scheduled again.', 'product-mailer-campaigns' ),
				'actions' => array(
					array(
						'label' => __( 'Open diagnostics', 'product-mailer-campaigns' ),
						'url'   => admin_url( 'admin.php?page=pmcpc_diagnostics' ),
						'class' => '',
					),
				),
			);
		}

		if ( isset( $wpdb ) && is_object( $wpdb ) ) {
			$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
			if ( $table_exists( $subscribers_table ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$pending_subscribers = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$subscribers_table} WHERE status = %s",
						'pending'
					)
				);
				if ( $pending_subscribers > 0 ) {
					$items[] = array(
						'type'    => 'info',
						'icon'    => 'dashicons-admin-users',
						'title'   => sprintf(
							/* translators: %d: pending subscribers. */
							_n( '%d subscriber is pending confirmation', '%d subscribers are pending confirmation', $pending_subscribers, 'product-mailer-campaigns' ),
							$pending_subscribers
						),
						'message' => __( 'Review pending subscribers so they can be confirmed, contacted, or cleaned up.', 'product-mailer-campaigns' ),
						'actions' => array(
							array(
								'label' => __( 'View pending subscribers', 'product-mailer-campaigns' ),
								'url'   => admin_url( 'admin.php?page=pmcpc_subscribers&pmcpc_status=pending' ),
								'class' => '',
							),
						),
					);
				}
			}

			$spam_table = $wpdb->prefix . 'pmcpc_spam_submissions';
			if ( $table_exists( $spam_table ) ) {
				$user_id   = get_current_user_id();
				$last_seen = (int) get_user_meta( $user_id, 'pmcpc_messages_last_seen_id', true );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$inbox_ready = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$spam_table} WHERE status = %s",
						'allowed'
					)
				);
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$held_count = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$spam_table} WHERE status = %s",
						'held'
					)
				);
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$unread_count = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$spam_table} WHERE id > %d AND status IN (%s, %s)",
						$last_seen,
						'allowed',
						'held'
					)
				);

				if ( $unread_count > 0 || $held_count > 0 ) {
					$inbox_message_parts = array();
					if ( $unread_count > 0 ) {
						$inbox_message_parts[] = sprintf(
							/* translators: %d: unread inbox items. */
							_n( '%d unread item', '%d unread items', $unread_count, 'product-mailer-campaigns' ),
							$unread_count
						);
					}
					if ( $inbox_ready > 0 ) {
						$inbox_message_parts[] = sprintf(
							/* translators: %d: inbox-ready items. */
							_n( '%d message in Inbox', '%d messages in Inbox', $inbox_ready, 'product-mailer-campaigns' ),
							$inbox_ready
						);
					}
					if ( $held_count > 0 ) {
						$inbox_message_parts[] = sprintf(
							/* translators: %d: held messages. */
							_n( '%d message held for review', '%d messages held for review', $held_count, 'product-mailer-campaigns' ),
							$held_count
						);
					}

					$actions = array(
						array(
							'label' => __( 'Open Inbox Review', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_inbox' ),
							'class' => 'button-primary',
						),
					);
					if ( $inbox_ready > 0 ) {
						$actions[] = array(
							'label' => __( 'View Inbox', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_inbox&pmcpc_status=allowed' ),
							'class' => '',
						);
					}
					if ( $held_count > 0 ) {
						$actions[] = array(
							'label' => __( 'View Held', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_inbox&pmcpc_status=held' ),
							'class' => '',
						);
					}

					$items[] = array(
						'type'    => ( $held_count > 0 ) ? 'warning' : 'info',
						'icon'    => 'dashicons-email-alt2',
						'title'   => __( 'Inbox Review has messages waiting', 'product-mailer-campaigns' ),
						'message' => implode( '; ', $inbox_message_parts ) . '.',
						'actions' => $actions,
					);
				}
			}

			$reviews_table = $wpdb->prefix . 'pmcpc_reviews';
			if ( $table_exists( $reviews_table ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$pending_reviews = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$reviews_table} WHERE status = %s",
						'pending'
					)
				);
				if ( $pending_reviews > 0 ) {
					$items[] = array(
						'type'    => 'warning',
						'icon'    => 'dashicons-star-filled',
						'title'   => sprintf(
							/* translators: %d: pending reviews. */
							_n( '%d review is waiting for moderation', '%d reviews are waiting for moderation', $pending_reviews, 'product-mailer-campaigns' ),
							$pending_reviews
						),
						'message' => __( 'Open Reviews to approve, reject, or mark feedback as private.', 'product-mailer-campaigns' ),
						'actions' => array(
							array(
								'label' => __( 'Moderate reviews', 'product-mailer-campaigns' ),
								'url'   => admin_url( 'admin.php?page=pmcpc_reviews&pmcpc_status=pending' ),
								'class' => 'button-primary',
							),
						),
					);
				}
			}

			$queue_table = $wpdb->prefix . 'pmcpc_email_queue';
			if ( $table_exists( $queue_table ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$queue_pending = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$queue_table} WHERE status = 'pending'" );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$queue_failed = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$queue_table} WHERE status = 'failed'" );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$queue_paused = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$queue_table} WHERE status = 'paused'" );
				$total_queue_attention = $queue_pending + $queue_failed + $queue_paused;

				if ( $total_queue_attention > 0 ) {
					$queue_message_parts = array();
					if ( $queue_pending > 0 ) {
						$queue_message_parts[] = sprintf(
							/* translators: %d: pending queued emails. */
							_n( '%d pending email', '%d pending emails', $queue_pending, 'product-mailer-campaigns' ),
							$queue_pending
						);
					}
					if ( $queue_failed > 0 ) {
						$queue_message_parts[] = sprintf(
							/* translators: %d: failed queued emails. */
							_n( '%d failed email', '%d failed emails', $queue_failed, 'product-mailer-campaigns' ),
							$queue_failed
						);
					}
					if ( $queue_paused > 0 ) {
						$queue_message_parts[] = sprintf(
							/* translators: %d: paused queued emails. */
							_n( '%d paused email', '%d paused emails', $queue_paused, 'product-mailer-campaigns' ),
							$queue_paused
						);
					}

					$actions = array(
						array(
							'label' => __( 'Open Email Queue', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=queue' ),
							'class' => 'button-primary',
						),
					);
					if ( $queue_failed > 0 ) {
						$actions[] = array(
							'label' => __( 'View failed', 'product-mailer-campaigns' ),
							'url'   => admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=queue&status=failed' ),
							'class' => '',
						);
					}

					$items[] = array(
						'type'    => ( $queue_failed > 0 ) ? 'warning' : 'info',
						'icon'    => 'dashicons-email-alt',
						'title'   => __( 'Email Queue needs attention', 'product-mailer-campaigns' ),
						'message' => implode( '; ', $queue_message_parts ) . '.',
						'actions' => $actions,
					);
				}
			}
		}

		if ( class_exists( 'PMCPC_Diagnostics' ) ) {
			$checks = PMCPC_Diagnostics::get_setup_checks();
			if ( is_array( $checks ) && ! empty( $checks ) ) {
				$warn_count = 0;
				$fail_count = 0;
				foreach ( $checks as $check ) {
					$status = isset( $check['status'] ) ? (string) $check['status'] : 'pass';
					if ( 'warn' === $status || 'warning' === $status ) {
						++$warn_count;
					} elseif ( 'fail' === $status || 'error' === $status ) {
						++$fail_count;
					}
				}

				if ( $warn_count > 0 || $fail_count > 0 ) {
					$diagnostics_parts = array();
					if ( $fail_count > 0 ) {
						$diagnostics_parts[] = sprintf(
							/* translators: %d: failed diagnostics checks. */
							_n( '%d failed check', '%d failed checks', $fail_count, 'product-mailer-campaigns' ),
							$fail_count
						);
					}
					if ( $warn_count > 0 ) {
						$diagnostics_parts[] = sprintf(
							/* translators: %d: warning diagnostics checks. */
							_n( '%d warning', '%d warnings', $warn_count, 'product-mailer-campaigns' ),
							$warn_count
						);
					}

					$items[] = array(
						'type'    => ( $fail_count > 0 ) ? 'warning' : 'info',
						'icon'    => 'dashicons-dashboard',
						'title'   => __( 'System diagnostics need review', 'product-mailer-campaigns' ),
						'message' => implode( '; ', $diagnostics_parts ) . '.',
						'actions' => array(
							array(
								'label' => __( 'Open System Status', 'product-mailer-campaigns' ),
								'url'   => admin_url( 'admin.php?page=pmcpc_diagnostics' ),
								'class' => 'button-primary',
							),
						),
					);
				}
			}
		}

		usort( $items, function( $a, $b ) {
			$order = array( 'error' => 0, 'warning' => 1, 'info' => 2, 'success' => 3 );
			$av = isset( $order[ $a['type'] ] ) ? $order[ $a['type'] ] : 99;
			$bv = isset( $order[ $b['type'] ] ) ? $order[ $b['type'] ] : 99;
			return $av <=> $bv;
		} );

		return $items;
	}

	/**
	 * Render the plugin-wide notification center under the shared page header.
	 *
	 * @return void
	 */
	public static function render_notification_center( $items = null ) {
		if ( ! is_array( $items ) ) {
			$items = self::get_notification_items();
		}
		$count = count( $items );
		$expanded = false;

		echo '<div class="pmcpc-notification-center" data-pmcpc-notification-center="1">';
		echo '<div class="pmcpc-notification-center__header">';
		echo '<div class="pmcpc-notification-center__summary">';
		echo '<span class="dashicons dashicons-bell" aria-hidden="true"></span>';
		echo '<strong>' . esc_html( self::normalize_admin_copy( __( 'Notification Center', 'product-mailer-campaigns' ) ) ) . '</strong>';
		if ( $count > 0 ) {
			echo '<span class="pmcpc-notification-center__badge">' . esc_html( (string) $count ) . '</span>';
			echo '<span class="pmcpc-notification-center__summary-text">' . esc_html( sprintf( _n( '%d item needs attention', '%d items need attention', $count, 'product-mailer-campaigns' ), $count ) ) . '</span>';
		} else {
			echo '<span class="pmcpc-notification-center__summary-text">' . esc_html__( 'All clear. No active notifications right now.', 'product-mailer-campaigns' ) . '</span>';
		}
		echo '</div>';
		echo '<button type="button" class="button button-secondary pmcpc-notification-center__toggle" aria-expanded="' . ( $expanded ? 'true' : 'false' ) . '" data-show-label="' . esc_attr__( 'Show notifications', 'product-mailer-campaigns' ) . '" data-hide-label="' . esc_attr__( 'Hide notifications', 'product-mailer-campaigns' ) . '">';
		echo esc_html( $expanded ? __( 'Hide notifications', 'product-mailer-campaigns' ) : __( 'Show notifications', 'product-mailer-campaigns' ) );
		echo '</button>';
		echo '</div>';

		echo '<div class="pmcpc-notification-center__body"' . ( $expanded ? '' : ' hidden' ) . '>';
		if ( $count > 0 ) {
			foreach ( $items as $item ) {
				$type    = isset( $item['type'] ) ? (string) $item['type'] : 'info';
				$icon    = isset( $item['icon'] ) ? (string) $item['icon'] : 'dashicons-bell';
				$title   = isset( $item['title'] ) ? (string) $item['title'] : '';
				$message = isset( $item['message'] ) ? (string) $item['message'] : '';
				$actions = isset( $item['actions'] ) && is_array( $item['actions'] ) ? $item['actions'] : array();

				echo '<div class="pmcpc-notification-center__item pmcpc-notification-center__item--' . esc_attr( $type ) . '">';
				echo '<div class="pmcpc-notification-center__item-main">';
				echo '<div class="pmcpc-notification-center__item-title"><span class="dashicons ' . esc_attr( $icon ) . '" aria-hidden="true"></span><span>' . esc_html( self::normalize_admin_copy( $title ) ) . '</span></div>';
				echo '<div class="pmcpc-notification-center__item-message">' . esc_html( self::normalize_admin_copy( $message ) ) . '</div>';
				if ( ! empty( $actions ) ) {
					echo '<div class="pmcpc-notification-center__item-actions">';
					foreach ( $actions as $action ) {
						$label = isset( $action['label'] ) ? (string) $action['label'] : '';
						$url   = isset( $action['url'] ) ? (string) $action['url'] : '';
						$class = isset( $action['class'] ) ? (string) $action['class'] : '';
						if ( '' === $label || '' === $url ) {
							continue;
						}
						echo '<a class="button ' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '">' . esc_html( self::normalize_admin_copy( $label ) ) . '</a>';
					}
					echo '</div>';
				}
				echo '</div>';
				echo '</div>';
			}
		} else {
			echo '<div class="pmcpc-notification-center__empty">' . esc_html( self::normalize_admin_copy( __( 'Everything looks healthy. Active alerts and shortcuts will appear here across Campaigns, Automations, Audience, Email, Settings, and System Status.', 'product-mailer-campaigns' ) ) ) . '</div>';
		}
		echo '</div>';
		echo '</div>';
	}

	/**
	 * Render a consistent SaaS-style header across plugin admin pages.
	 *
	 * @param string $title   Page title.
	 * @param array  $actions Optional CTA buttons.
	 * @return void
	 */
	public static function render_app_header( $title, $actions = array() ) {
		static $printed = false;

		if ( ! $printed ) {
			echo '<style id="pmcpc-app-header-css">';
			echo '.pmcpc-workspace-screen #wpbody-content > .wrap{max-width:1360px;margin:0 auto;padding:0 18px 24px;box-sizing:border-box;}';
			echo '.pmcpc-workspace-anchor{height:0;margin:0 0 4px;}';
			echo '.pmcpc-app-header{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin:8px 0 14px;padding-bottom:14px;border-bottom:1px solid #dcdcde;}';
			echo '.pmcpc-app-header__eyebrow{display:flex;align-items:center;gap:8px;margin:0 0 4px;font-size:12px;font-weight:600;letter-spacing:.02em;text-transform:uppercase;color:#2271b1;}';
			echo '.pmcpc-app-header__eyebrow .dashicons{font-size:16px;width:16px;height:16px;}';
			echo '.pmcpc-app-header__title{margin:0;font-size:28px;line-height:1.15;font-weight:600;color:#1d2327;}';
			echo '.pmcpc-app-header__tagline{margin:6px 0 0;color:#50575e;font-size:13px;}';
			echo '.pmcpc-app-header__main{flex:1 1 320px;}';
			echo '.pmcpc-app-header__utility{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:12px;}';
			echo '.pmcpc-app-header__utility-link{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border:1px solid #dcdcde;border-radius:999px;background:#fff;color:#1d2327;text-decoration:none;font-size:12px;font-weight:500;line-height:1.2;}';
			echo '.pmcpc-app-header__utility-link:hover{background:#f6f7f7;color:#135e96;}';
			echo '.pmcpc-app-header__utility-link .dashicons{font-size:14px;width:14px;height:14px;}';
			echo '.pmcpc-app-header__actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center;justify-content:flex-end;flex:0 0 auto;}';
			echo '.pmcpc-app-header__notice-link .dashicons{font-size:15px;width:15px;height:15px;margin-right:4px;vertical-align:text-bottom;}';
			echo '.pmcpc-app-header__notice-count{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;border-radius:999px;background:#d63638;color:#fff;font-size:11px;font-weight:700;padding:0 5px;margin-left:4px;}';
			echo '.pmcpc-app-header__paid-toggle .dashicons{font-size:15px;width:15px;height:15px;margin-right:4px;vertical-align:text-bottom;}';
			echo '.pmcpc-app-header__paid-toggle.is-hidden{border-color:#8c8f94;background:#f6f7f7;color:#3c434a;}';
			echo '@media (max-width: 960px){.pmcpc-app-header__actions{justify-content:flex-start;width:100%;}.pmcpc-app-header__utility{margin-right:0;}}';
			echo '.pmcpc-notification-center{margin:0 0 16px;border:1px solid #dcdcde;border-radius:12px;background:#fff;box-shadow:0 1px 1px rgba(0,0,0,.03);}';
			echo '.pmcpc-notification-center__header{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:14px 16px;border-bottom:1px solid #f0f0f1;flex-wrap:wrap;}';
			echo '.pmcpc-notification-center__summary{display:flex;align-items:center;gap:10px;flex-wrap:wrap;color:#1d2327;}';
			echo '.pmcpc-notification-center__summary .dashicons{color:#2271b1;}';
			echo '.pmcpc-notification-center__badge{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;border-radius:999px;background:#2271b1;color:#fff;font-size:11px;font-weight:700;padding:0 6px;}';
			echo '.pmcpc-notification-center__summary-text{color:#646970;font-size:13px;}';
			echo '.pmcpc-notification-center__body{padding:0 16px 16px;}';
			echo '.pmcpc-notification-center__item{border:1px solid #dcdcde;border-left-width:4px;border-radius:10px;padding:14px 14px 12px;margin-top:14px;background:#fff;}';
			echo '.pmcpc-notification-center__item--error{border-left-color:#d63638;background:#fcf0f1;}';
			echo '.pmcpc-notification-center__item--warning{border-left-color:#dba617;background:#fff8e5;}';
			echo '.pmcpc-notification-center__item--info{border-left-color:#2271b1;background:#f0f6fc;}';
			echo '.pmcpc-notification-center__item--success{border-left-color:#00a32a;background:#edfaef;}';
			echo '.pmcpc-notification-center__item-title{display:flex;align-items:center;gap:8px;font-weight:600;color:#1d2327;margin-bottom:6px;}';
			echo '.pmcpc-notification-center__item-message{color:#3c434a;max-width:1000px;}';
			echo '.pmcpc-notification-center__item-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;}';
			echo '.pmcpc-notification-center__empty{margin-top:14px;border:1px dashed #c3c4c7;border-radius:10px;padding:14px;color:#646970;background:#fcfcfc;}';
            echo '.pmcpc-page-intro,.pmcpc-hub-intro{margin:0 0 16px;padding:18px 20px;border:1px solid #dcdcde;border-radius:14px;background:linear-gradient(180deg,#fff 0%,#fbfbfc 100%);box-shadow:0 1px 1px rgba(0,0,0,.03);}';
            echo '.pmcpc-page-intro__eyebrow{display:inline-flex;align-items:center;gap:6px;margin:0 0 8px;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#2271b1;}';
            echo '.pmcpc-page-intro__eyebrow .dashicons{font-size:14px;width:14px;height:14px;}';
            echo '.pmcpc-page-intro h2,.pmcpc-hub-intro h2{margin:0 0 6px;font-size:22px;line-height:1.25;color:#1d2327;}';
            echo '.pmcpc-page-intro p,.pmcpc-hub-intro p{margin:0;color:#50575e;font-size:13px;max-width:88ch;}';
            echo '.pmcpc-page-intro__meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;}';
            echo '.pmcpc-page-intro__pill{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border:1px solid #dcdcde;border-radius:999px;background:#fff;color:#1d2327;font-size:12px;line-height:1.2;}';
            echo '.pmcpc-page-intro__pill .dashicons{font-size:14px;width:14px;height:14px;color:#2271b1;}';
            echo '.pmcpc-help-collapsible{margin:0 0 16px;border:1px solid #dcdcde;border-radius:14px;background:#fff;box-shadow:0 1px 1px rgba(0,0,0,.03);overflow:hidden;}';
            echo '.pmcpc-help-collapsible__summary{list-style:none;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:11px 14px;cursor:pointer;background:#f8fafc;color:#1d2327;}';
            echo '.pmcpc-help-collapsible__summary::-webkit-details-marker{display:none;}';
            echo '.pmcpc-help-collapsible__summary-main{display:flex;align-items:center;gap:10px;flex-wrap:wrap;min-width:0;}';
            echo '.pmcpc-help-collapsible__label{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#2271b1;white-space:nowrap;}';
            echo '.pmcpc-help-collapsible__label .dashicons{font-size:14px;width:14px;height:14px;}';
            echo '.pmcpc-help-collapsible__title{font-size:13px;font-weight:600;color:#1d2327;min-width:0;overflow-wrap:anywhere;}';
            echo '.pmcpc-help-collapsible__toggle{font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#646970;white-space:nowrap;}';
            echo '.pmcpc-help-collapsible__toggle::before{content:"Show";}';
            echo '.pmcpc-help-collapsible[open] .pmcpc-help-collapsible__toggle::before{content:"Hide";}';
            echo '.pmcpc-help-collapsible__body{padding:16px 18px;border-top:1px solid #eef0f2;background:linear-gradient(180deg,#fff 0%,#fbfbfc 100%);}';
            echo '.pmcpc-help-collapsible .pmcpc-page-intro,.pmcpc-help-collapsible .pmcpc-hub-intro{margin:0;padding:0;border:0;border-radius:0;background:transparent;box-shadow:none;}';
            echo '.pmcpc-help-collapsible .pmcpc-page-support-grid{margin:0;}';
            echo '.pmcpc-help-collapsible--combined .pmcpc-page-intro + .pmcpc-page-support-grid{margin-top:14px;}';
            echo '.pmcpc-help-collapsible .pmcpc-support-card{box-shadow:none;}';
            echo '.pmcpc-stats-strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:0 0 18px;}';
            echo '.pmcpc-page-support-grid{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(280px,1fr);gap:16px;margin:0 0 18px;align-items:start;}';
            echo '.pmcpc-page-support-grid--single{grid-template-columns:minmax(0,1fr);}';
            echo '.pmcpc-support-card{padding:18px 20px;border:1px solid #dcdcde;border-radius:14px;background:#fff;box-shadow:0 1px 1px rgba(0,0,0,.03);min-width:0;}';
            echo '.pmcpc-support-card--soft{background:linear-gradient(180deg,#fff 0%,#fbfbfc 100%);}';
            echo '.pmcpc-support-card__eyebrow{display:inline-flex;align-items:center;gap:6px;margin:0 0 8px;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#2271b1;}';
            echo '.pmcpc-support-card__eyebrow .dashicons{font-size:14px;width:14px;height:14px;}';
            echo '.pmcpc-support-card__title{margin:0 0 6px;font-size:20px;line-height:1.25;color:#1d2327;}';
            echo '.pmcpc-support-card__text{margin:0;color:#50575e;font-size:13px;max-width:80ch;}';
            echo '.pmcpc-support-card__list{margin:12px 0 0;padding:0;list-style:none;display:grid;gap:8px;}';
            echo '.pmcpc-support-card__list li{display:flex;gap:8px;align-items:flex-start;color:#1d2327;line-height:1.5;}';
            echo '.pmcpc-support-card__list .dashicons{margin-top:2px;font-size:14px;width:14px;height:14px;color:#2271b1;flex:0 0 14px;}';
            echo '.pmcpc-support-card__actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;}';
            echo '.pmcpc-stat-card{padding:14px 16px;border:1px solid #dcdcde;border-radius:14px;background:#fff;box-shadow:0 1px 1px rgba(0,0,0,.03);min-width:0;}';
            echo '.pmcpc-stat-card__label{display:block;margin:0 0 6px;color:#646970;font-size:12px;font-weight:600;letter-spacing:.01em;}';
            echo '.pmcpc-stat-card__value{display:block;color:#1d2327;font-size:24px;line-height:1.15;font-weight:600;}';
            echo '.pmcpc-stat-card__meta{display:block;margin-top:6px;color:#646970;font-size:12px;line-height:1.4;}';
            echo '.pmcpc-stack{display:grid;gap:16px;}';
            echo '.pmcpc-section{margin:0 0 18px;}';
            echo '.pmcpc-section:last-child{margin-bottom:0;}';
            echo '.pmcpc-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;box-shadow:0 1px 1px rgba(0,0,0,.03);}';
            echo '.pmcpc-card > :first-child{margin-top:0;}';
            echo '.pmcpc-card > :last-child{margin-bottom:0;}';
            echo '.pmcpc-table-wrap{width:100%;margin:0 0 16px;overflow:hidden;}';
			echo '.pmcpc-table-card,.pmcpc-table-wrap{margin:12px 0 0;background:#fff;border:1px solid #dcdcde;border-radius:12px;overflow:hidden;box-shadow:0 1px 1px rgba(0,0,0,.03);}';
			echo '.pmcpc-table-scroll,.pmcpc-table-wrap__scroll{overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch;max-width:100%;scrollbar-gutter:stable both-edges;padding:0 8px 6px;}';
			echo '.pmcpc-table-toolbar,.pmcpc-workspace-screen .tablenav{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;flex-wrap:wrap;margin:10px 0 12px;padding:12px 14px;background:#fff;border:1px solid #dcdcde;border-radius:12px;box-shadow:0 1px 1px rgba(0,0,0,.03);}';
			echo '.pmcpc-table-toolbar__group,.pmcpc-workspace-screen .tablenav .actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:0;}';
			echo '.pmcpc-table-toolbar__group > *,.pmcpc-workspace-screen .tablenav .actions > *{margin:0 !important;}';
			echo '.pmcpc-table-toolbar__meta{display:flex;align-items:center;gap:10px;flex-wrap:wrap;color:#50575e;font-size:12px;}';
			echo '.pmcpc-workspace-screen .tablenav .tablenav-pages{margin-left:auto;}';
			echo '.pmcpc-workspace-screen .widefat{width:100%;border:1px solid #dcdcde;border-radius:12px;overflow:hidden;background:#fff;box-shadow:0 1px 1px rgba(0,0,0,.03);border-collapse:separate;border-spacing:0;}';
			echo '.pmcpc-workspace-screen .widefat thead th,.pmcpc-workspace-screen .widefat tfoot th{background:#f6f7f7;color:#50575e;font-size:12px;text-transform:none;border-bottom:1px solid #e8eaed;}';
			echo '.pmcpc-workspace-screen .widefat tbody tr:nth-child(even){background:#fcfcfd;}';
			echo '.pmcpc-workspace-screen .widefat tbody tr:hover{background:#f5f9fd;}';
			echo '.pmcpc-workspace-screen .widefat td,.pmcpc-workspace-screen .widefat th{vertical-align:top;padding:14px 16px;text-align:left;}';
			echo '.pmcpc-workspace-screen .widefat td p:last-child,.pmcpc-workspace-screen .widefat th p:last-child{margin-bottom:0;}';
			echo '.pmcpc-workspace-screen .widefat .row-actions{padding-top:6px;color:#646970;}';
			echo '.pmcpc-workspace-screen .widefat .row-actions span{display:inline-flex;align-items:center;}';
			echo '.pmcpc-workspace-screen .widefat td .button,.pmcpc-workspace-screen .widefat td .button-secondary,.pmcpc-workspace-screen .widefat td .button-link{margin:2px 6px 2px 0;}';
			echo '.pmcpc-table-record{display:flex;flex-direction:column;gap:6px;line-height:1.45;}';
			echo '.pmcpc-table-record__title{display:block;font-weight:600;color:#1d2327;line-height:1.4;}';
			echo '.pmcpc-table-record__title a{font-weight:600;text-decoration:none;}';
			echo '.pmcpc-table-record__title a:hover{text-decoration:underline;}';
			echo '.pmcpc-table-record__meta{display:block;font-size:12px;color:#646970;line-height:1.5;word-break:break-word;overflow-wrap:anywhere;}';
			echo '.pmcpc-table-badges{display:flex;flex-wrap:wrap;gap:6px;align-items:center;}';
			echo '.pmcpc-table-actions{display:flex;flex-direction:column;gap:6px;min-width:108px;}';
			echo '.pmcpc-table-actions__primary,.pmcpc-table-actions__secondary{display:flex;flex-wrap:wrap;gap:8px;align-items:center;}';
			echo '.pmcpc-table-actions__secondary{font-size:12px;color:#646970;}';
			echo '.pmcpc-table-actions__secondary a{color:#50575e;text-decoration:none;}';
			echo '.pmcpc-table-actions__secondary a:hover{text-decoration:underline;}';
			echo '.pmcpc-table-actions__menu{position:relative;display:block;width:100%;}';
			echo '.pmcpc-table-actions__summary{list-style:none;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;width:100%;box-sizing:border-box;margin:0;min-height:30px;}';
			echo '.pmcpc-table-actions__summary::-webkit-details-marker{display:none;}';
			echo '.pmcpc-table-actions__popover{position:absolute;top:calc(100% + 6px);right:0;z-index:30;display:flex;flex-direction:column;gap:6px;min-width:160px;padding:10px 12px;background:#fff;border:1px solid #dcdcde;border-radius:10px;box-shadow:0 8px 20px rgba(15,23,42,.08);text-align:left;}';
			echo '.pmcpc-table-actions__popover a{color:#1d2327;text-decoration:none;line-height:1.4;}';
			echo '.pmcpc-table-actions__popover a:hover{text-decoration:underline;}';
			echo '.pmcpc-table-actions .button.button-primary,.pmcpc-table-actions .button.button-secondary{box-shadow:none;}';
			echo '.pmcpc-workspace-screen .widefat td:last-child .button.button-primary{margin-right:8px;}';
			echo '.pmcpc-workspace-screen .widefat td:last-child > a:first-child:not(.button),.pmcpc-workspace-screen .widefat td:last-child .row-title:first-child{font-weight:600;}';
			echo '.pmcpc-table-cell-stack{display:flex;flex-direction:column;gap:6px;line-height:1.45;}';
			echo '.pmcpc-table-cell-stack__main{display:block;font-weight:600;color:#1d2327;line-height:1.4;word-break:break-word;overflow-wrap:anywhere;}';
			echo '.pmcpc-table-cell-stack__sub{display:block;font-size:12px;color:#646970;line-height:1.5;word-break:break-word;overflow-wrap:anywhere;}';
			echo '.pmcpc-wide-table{width:max-content;min-width:100%;table-layout:auto;}';
			echo '.pmcpc-wide-table th.pmcpc-col-anchor,.pmcpc-wide-table td.pmcpc-col-anchor{min-width:220px;max-width:360px;}';
			echo '.pmcpc-wide-table td.pmcpc-col-anchor .pmcpc-table-record__title{font-size:14px;}';
			echo '.pmcpc-wide-table td.pmcpc-col-anchor .pmcpc-table-record__title,.pmcpc-wide-table td.pmcpc-col-anchor .pmcpc-table-record__meta{max-width:100%;overflow-wrap:anywhere;}';
			echo '.pmcpc-wide-table th.pmcpc-col-compare,.pmcpc-wide-table td.pmcpc-col-compare{white-space:nowrap;min-width:100px;max-width:140px;}';
			echo '.pmcpc-wide-table td.pmcpc-col-compare .pmcpc-table-cell-stack{min-width:100px;max-width:140px;}';
			echo '.pmcpc-wide-table th.pmcpc-col-meta,.pmcpc-wide-table td.pmcpc-col-meta{min-width:140px;max-width:240px;}';
			echo '.pmcpc-wide-table td.pmcpc-col-meta .pmcpc-table-cell-stack,.pmcpc-wide-table td.pmcpc-col-meta .pmcpc-table-record{min-width:140px;max-width:240px;}';
			echo '.pmcpc-wide-table th.pmcpc-col-actions{width:1%;white-space:nowrap;}';
			echo '.pmcpc-wide-table th.pmcpc-col-compare,.pmcpc-wide-table td.pmcpc-col-compare,.pmcpc-wide-table th.pmcpc-col-metric,.pmcpc-wide-table td.pmcpc-col-metric{text-align:center;}';
			echo '.pmcpc-wide-table th.pmcpc-col-actions,.pmcpc-wide-table td.pmcpc-col-actions{text-align:right;}';
			echo '.pmcpc-wide-table td.pmcpc-col-actions{width:1%;min-width:120px;max-width:144px;background:transparent;border-left:1px solid #eef2f6;}';
			echo '.pmcpc-wide-table td.pmcpc-col-actions .pmcpc-table-actions{min-width:120px;max-width:144px;display:flex;flex-direction:column;gap:6px;flex-wrap:wrap;align-items:flex-end;}';
			echo '.pmcpc-wide-table td.pmcpc-col-actions .pmcpc-table-actions__primary{gap:6px;justify-content:flex-end;}';
			echo '.pmcpc-wide-table td.pmcpc-col-actions .pmcpc-table-actions__secondary{gap:6px 8px;justify-content:flex-end;text-align:right;}';
			echo '.pmcpc-wide-table td.pmcpc-col-actions .pmcpc-table-actions__menu{width:100%;}';
			echo '.pmcpc-wide-table td.pmcpc-col-actions .pmcpc-table-actions__summary{width:100%;}';
			echo '.pmcpc-wide-table td.pmcpc-col-metric,.pmcpc-wide-table th.pmcpc-col-metric{white-space:nowrap;min-width:78px;max-width:96px;}';
			echo '.pmcpc-wide-table td.pmcpc-col-metric .pmcpc-table-cell-stack{min-width:78px;max-width:96px;}';
			echo '.pmcpc-wide-table td .pmcpc-table-record,.pmcpc-wide-table td .pmcpc-table-cell-stack{max-width:100%;}';
			echo '.pmcpc-wide-table td,.pmcpc-wide-table td *{word-break:break-word;overflow-wrap:anywhere;}';
			echo '.pmcpc-workspace-screen form .form-table th{width:220px;}';
			echo '.pmcpc-workspace-screen .button + .button{margin-left:6px;}';
			echo '.pmcpc-workspace-screen .notice{margin:0 0 14px;}';
			echo '@media (max-width: 1100px){.pmcpc-workspace-screen #wpbody-content > .wrap{padding-left:14px;padding-right:14px;}.pmcpc-stats-strip{grid-template-columns:repeat(auto-fit,minmax(160px,1fr));}.pmcpc-app-header__title{font-size:24px;}.pmcpc-page-intro,.pmcpc-hub-intro,.pmcpc-card{padding:16px;}.pmcpc-workspace-screen .widefat th,.pmcpc-workspace-screen .widefat td{padding:12px 14px;}.pmcpc-wide-table td .pmcpc-table-record{gap:6px;}.pmcpc-wide-table td .pmcpc-table-cell-stack{gap:6px;}.pmcpc-wide-table td .pmcpc-table-actions__secondary{gap:5px 8px;}.pmcpc-wide-table th.pmcpc-col-anchor,.pmcpc-wide-table td.pmcpc-col-anchor{min-width:200px;max-width:320px;}.pmcpc-wide-table th.pmcpc-col-meta,.pmcpc-wide-table td.pmcpc-col-meta{min-width:128px;max-width:220px;}.pmcpc-wide-table td.pmcpc-col-actions,.pmcpc-wide-table td.pmcpc-col-actions .pmcpc-table-actions{min-width:112px;max-width:136px;}}';
			echo '@media (max-width: 782px){.pmcpc-app-header{gap:12px;}.pmcpc-app-header__actions,.pmcpc-app-header__utility{width:100%;}.pmcpc-app-header__utility-link{flex:1 1 160px;justify-content:center;}.pmcpc-page-intro__meta{display:grid;grid-template-columns:1fr;}.pmcpc-page-intro__pill{justify-content:flex-start;}.pmcpc-stats-strip{grid-template-columns:1fr 1fr;}.pmcpc-page-support-grid{grid-template-columns:1fr;}.pmcpc-table-toolbar,.pmcpc-workspace-screen .tablenav{align-items:stretch;padding:12px;}.pmcpc-table-toolbar__group,.pmcpc-workspace-screen .tablenav .actions,.pmcpc-workspace-screen .tablenav .tablenav-pages{width:100%;margin-left:0;}.pmcpc-table-toolbar__group select,.pmcpc-table-toolbar__group input,.pmcpc-table-toolbar__group .button,.pmcpc-workspace-screen .tablenav .actions select,.pmcpc-workspace-screen .tablenav .actions input,.pmcpc-workspace-screen .tablenav .actions .button{width:100%;max-width:none;}.pmcpc-table-actions,.pmcpc-table-actions__primary,.pmcpc-table-actions__secondary{width:100%;}.pmcpc-table-actions .button,.pmcpc-table-actions .button-secondary,.pmcpc-workspace-screen .widefat td .button,.pmcpc-workspace-screen .widefat td .button-secondary{display:inline-flex;justify-content:center;width:100%;margin-right:0;}.pmcpc-wide-table td.pmcpc-col-actions{background:transparent;border-left:none;text-align:left;}.pmcpc-wide-table td.pmcpc-col-actions .pmcpc-table-actions{align-items:stretch;}.pmcpc-wide-table td.pmcpc-col-actions .pmcpc-table-actions__primary,.pmcpc-wide-table td.pmcpc-col-actions .pmcpc-table-actions__secondary{justify-content:flex-start;text-align:left;}.pmcpc-wide-table th.pmcpc-col-anchor,.pmcpc-wide-table td.pmcpc-col-anchor{min-width:180px;}}';
            echo '@media (max-width: 600px){.pmcpc-stats-strip{grid-template-columns:1fr;}.pmcpc-app-header__utility{display:grid;grid-template-columns:1fr 1fr;}.pmcpc-app-header__actions{display:grid;grid-template-columns:1fr;}.pmcpc-app-header__actions .button{width:100%;}}';
			echo '</style>';
			echo '<script id="pmcpc-notification-center-js">document.addEventListener("click",function(e){var btn=e.target.closest(".pmcpc-notification-center__toggle,.pmcpc-app-header__notice-link");if(!btn){return;}var center=document.querySelector(".pmcpc-notification-center");if(!center){return;}var body=center.querySelector(".pmcpc-notification-center__body");var toggle=center.querySelector(".pmcpc-notification-center__toggle");if(!body||!toggle){return;}e.preventDefault();var expanded=toggle.getAttribute("aria-expanded")=="true";body.hidden=expanded;toggle.setAttribute("aria-expanded", expanded ? "false" : "true");toggle.textContent=expanded ? toggle.getAttribute("data-show-label") : toggle.getAttribute("data-hide-label");if(!expanded){center.scrollIntoView({behavior:"smooth",block:"start"});}});document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll(".pmcpc-workspace-screen .pmcpc-hub-intro").forEach(function(intro){if(intro.closest(".pmcpc-help-collapsible")||intro.dataset.pmcpcCollapsedHelp==="1"){return;}var title=intro.querySelector("h1,h2,h3");var summaryTitle=title?title.textContent.trim():"Page guidance";var details=document.createElement("details");details.className="pmcpc-help-collapsible pmcpc-help-collapsible--hub";var summary=document.createElement("summary");summary.className="pmcpc-help-collapsible__summary";summary.innerHTML="<span class=\"pmcpc-help-collapsible__summary-main\"><span class=\"pmcpc-help-collapsible__label\"><span class=\"dashicons dashicons-editor-help\" aria-hidden=\"true\"></span><span>Help & shortcuts</span></span><span class=\"pmcpc-help-collapsible__title\"></span></span><span class=\"pmcpc-help-collapsible__toggle\" aria-hidden=\"true\"></span>";summary.querySelector(".pmcpc-help-collapsible__title").textContent=summaryTitle;var body=document.createElement("div");body.className="pmcpc-help-collapsible__body";details.appendChild(summary);details.appendChild(body);intro.parentNode.insertBefore(details,intro);body.appendChild(intro);intro.dataset.pmcpcCollapsedHelp="1";});});</script>';
			$printed = true;
		}

		$notification_items  = self::is_plugin_admin_page() ? self::get_notification_items() : array();
		$notification_count  = count( $notification_items );


		echo '<div class="pmcpc-app-header">';
		echo '<div class="pmcpc-app-header__main">';
		echo '<div class="pmcpc-app-header__eyebrow"><span class="dashicons dashicons-controls-repeat" aria-hidden="true"></span><span>' . esc_html( self::app_brand() ) . '</span></div>';
		echo '<h1 class="pmcpc-app-header__title">' . esc_html( self::normalize_admin_copy( $title ) ) . '</h1>';
		echo '<p class="pmcpc-app-header__tagline">' . esc_html( self::app_tagline() ) . '</p>';
		echo '</div>';

		echo '<div class="pmcpc-app-header__actions">';
		if ( self::is_plugin_admin_page() ) {
			echo '<button type="button" class="button pmcpc-app-header__notice-link"><span class="dashicons dashicons-bell" aria-hidden="true"></span>' . esc_html__( 'Notifications', 'product-mailer-campaigns' );
			if ( $notification_count > 0 ) {
				echo '<span class="pmcpc-app-header__notice-count">' . esc_html( (string) $notification_count ) . '</span>';
			}
			echo '</button>';
		}
		if ( self::is_plugin_admin_page() && function_exists( 'pmcpc_paid_feature_visibility_toggle_available' ) && pmcpc_paid_feature_visibility_toggle_available() ) {
			$paid_features_hidden = function_exists( 'pmcpc_hide_paid_features_setting_enabled' ) && pmcpc_hide_paid_features_setting_enabled();
			$toggle_label = $paid_features_hidden ? __( 'Show paid features', 'product-mailer-campaigns' ) : __( 'Hide paid features', 'product-mailer-campaigns' );
			$toggle_icon  = $paid_features_hidden ? 'dashicons-visibility' : 'dashicons-hidden';
			$toggle_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_toggle_paid_feature_visibility' ), 'pmcpc_toggle_paid_feature_visibility' );
			echo '<a class="button pmcpc-app-header__paid-toggle' . ( $paid_features_hidden ? ' is-hidden' : '' ) . '" href="' . esc_url( $toggle_url ) . '"><span class="dashicons ' . esc_attr( $toggle_icon ) . '" aria-hidden="true"></span>' . esc_html( $toggle_label ) . '</a>';
		}
		if ( ! empty( $actions ) ) {
			foreach ( $actions as $action ) {
				$label = isset( $action['label'] ) ? (string) $action['label'] : '';
				$url   = isset( $action['url'] ) ? (string) $action['url'] : '';
				if ( '' === $label || '' === $url ) {
					continue;
				}
				$class = isset( $action['class'] ) ? (string) $action['class'] : '';
				echo '<a class="button ' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '">' . esc_html( self::normalize_admin_copy( $label ) ) . '</a>';
			}
		}
		echo '<a class="button" href="' . esc_url( admin_url() ) . '"><span class="dashicons dashicons-wordpress" aria-hidden="true" style="font-size:14px;width:14px;height:14px;line-height:1.2;margin-right:4px;vertical-align:text-bottom;"></span>' . esc_html__( 'Back to WordPress', 'product-mailer-campaigns' ) . '</a>';
		echo '</div>';

		echo '</div>';

		if ( self::is_plugin_admin_page() ) {
			self::render_notification_center( $notification_items );
			echo '<div class="pmcpc-workspace-anchor" aria-hidden="true"></div>';
		}
	}

	/**
	 * Render a reusable page intro block below the shared app header.
	 *
	 * @param string $title Intro title.
	 * @param string $text  Supporting helper text.
	 * @param array  $meta  Optional pill metadata rows.
	 * @return void
	 */
	public static function render_page_intro( $title, $text = '', $meta = array() ) {
		PMCPC_Admin_View_Helper::render_page_intro( $title, $text, $meta );
	}

	/**
	 * Render a compact summary strip for admin overview metrics.
	 *
	 * @param array $items Summary card items.
	 * @return void
	 */
	public static function render_stats_strip( $items ) {
		PMCPC_Admin_View_Helper::render_stats_strip( $items );
	}


	/**
	 * Render reusable support panels so key pages follow the same layout pattern.
	 *
	 * @param array $panels Support panel definitions.
	 * @return void
	 */
	public static function render_support_panels( $panels ) {
		PMCPC_Admin_View_Helper::render_support_panels( $panels );
	}

	/**
	 * Small inline help icon for settings tables.
	 * Uses the native browser tooltip via the title attribute.
	 *
	 * @param string $text Help text.
	 * @return string
	 */
	private static function help_icon( $text ) {
		$text = (string) $text;
		if ( '' === $text ) {
			return '';
		}
		return '<span class="dashicons dashicons-editor-help pmcpc-help-tip" title="' . esc_attr( $text ) . '" aria-label="' . esc_attr( $text ) . '"></span>';
	}

	/**
	 * Admin notices for plugin screens.
	 */
	public static function admin_notices() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Only show notices on our own admin pages.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only check.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( 0 !== strpos( $page, 'pmcpc_' ) ) {
			return;
		}

		// Plugin-wide notices are rendered inside the shared Notification Center.
		return;

		// WooCommerce activation funnel: show only when WooCommerce is present but the
		// WooCommerce automation layer is not enabled (trial/license).
		if ( class_exists( 'WooCommerce' ) && function_exists( 'pmcpc_wc_automation_enabled' ) ) {
			if ( ! pmcpc_wc_automation_enabled() ) {
				$upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
				$trial_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );
				echo '<div class="notice notice-info"><p><strong>' . esc_html__( 'WooCommerce detected — unlock automated sales flows', 'product-mailer-campaigns' ) . '</strong><br/>';
				echo esc_html__( 'Start a 14‑day WooCommerce automation trial to enable abandoned cart recovery, post‑purchase journeys, and customer segments.', 'product-mailer-campaigns' );
				echo '</p><p><a class="button button-primary" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Start Free Trial', 'product-mailer-campaigns' ) . '</a> ';
				echo '<a class="button" href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Activate Commerce', 'product-mailer-campaigns' ) . '</a></p></div>';
			}
		}

		$skipped_domain = get_transient( 'pmcpc_notice_auto_block_skipped' );
		if ( ! $skipped_domain ) {
			return;
		}

		delete_transient( 'pmcpc_notice_auto_block_skipped' );
		$skipped_domain = strtolower( trim( (string) $skipped_domain ) );
		if ( '' === $skipped_domain ) {
			return;
		}

		echo '<div class="notice notice-warning is-dismissible"><p>';
		echo esc_html(
			sprintf(
				/* translators: %s: email domain. */
				__( 'Spam protection: auto-blocking was skipped for "%s" because it is a protected/shared email provider. If you really want to block it, add it manually under “Additional blocked domains”.', 'product-mailer-campaigns' ),
				$skipped_domain
			)
		);
		echo '</p></div>';
	}

	/**
	 * AJAX: Test spam protection rules from the settings screen.
	 */
	public static function ajax_test_spam() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'product-mailer-campaigns' ) ), 403 );
		}
		$nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['_wpnonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'pmcpc_test_spam' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'product-mailer-campaigns' ) ), 403 );
		}

		$email      = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['first_name'] ) ) : '';
		$last_name  = isset( $_POST['last_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['last_name'] ) ) : '';
		$context    = isset( $_POST['context'] ) ? sanitize_key( wp_unslash( $_POST['context'] ) ) : 'subscribe';
		$honeypot   = isset( $_POST['honeypot'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['honeypot'] ) ) : '';
		$subject    = isset( $_POST['subject'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['subject'] ) ) : '';
		$message    = isset( $_POST['message'] ) ? wp_kses_post( (string) wp_unslash( $_POST['message'] ) ) : '';
		$ft_mode    = isset( $_POST['ft_mode'] ) ? sanitize_key( wp_unslash( $_POST['ft_mode'] ) ) : 'valid';
		$ft_secs    = isset( $_POST['ft_seconds'] ) ? absint( wp_unslash( $_POST['ft_seconds'] ) ) : 10;

		if ( ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {
			wp_send_json_error( array( 'message' => __( 'Subscriber manager not available.', 'product-mailer-campaigns' ) ), 500 );
		}

		$base = PMCPC_Subscriber_Manager::evaluate_spam(
			array(
				'email'      => $email,
				'first_name' => $first_name,
				'last_name'  => $last_name,
				'context'    => $context,
				'honeypot'   => $honeypot,
			)
		);

		// Simulate the PMCPC form timing token checks (used by contact/selling shortcodes).
		$timing = array( 'allowed' => true, 'action' => 'allowed', 'reason' => '' );
		if ( class_exists( 'PMCPC_Settings' ) ) {
			$enabled  = PMCPC_Settings::get( 'spam_form_timing_enabled', 'yes' );
			$min_secs = (int) PMCPC_Settings::get( 'spam_form_timing_min_seconds', 4 );
			if ( 'yes' === $enabled ) {
				if ( 'missing' === $ft_mode || 'invalid' === $ft_mode ) {
					$timing = array( 'allowed' => false, 'action' => 'blocked', 'reason' => 'timing_token_' . $ft_mode );
				} elseif ( $min_secs > 0 && $ft_secs < $min_secs ) {
					$timing = array( 'allowed' => false, 'action' => 'blocked', 'reason' => 'timing_too_fast:' . $ft_secs . 's' );
				}
			}
		}

		// Message scoring (mostly relevant to contact/selling contexts).
		$msg = array( 'allowed' => true, 'action' => 'allowed', 'reason' => '', 'score' => 0, 'details' => array() );
		if ( method_exists( 'PMCPC_Subscriber_Manager', 'evaluate_message_spam' ) ) {
			$msg = PMCPC_Subscriber_Manager::evaluate_message_spam( $subject, $message, $context );
		}

		// Combine into a single result for the UI.
		$allowed = true;
		$action  = 'allowed';
		$reasons = array();

		foreach ( array( $timing, $base, $msg ) as $part ) {
			if ( empty( $part['allowed'] ) ) {
				$allowed = false;
				$action  = ( isset( $part['action'] ) ? (string) $part['action'] : 'blocked' );
				if ( isset( $part['reason'] ) && '' !== (string) $part['reason'] ) {
					$reasons[] = (string) $part['reason'];
				}
				// Hard block wins.
				if ( 'blocked' === $action ) {
					break;
				}
			} else {
				// Preserve name_stripped state if otherwise allowed.
				if ( isset( $part['action'] ) && 'name_stripped' === $part['action'] && 'allowed' === $action ) {
					$action = 'name_stripped';
					if ( isset( $part['reason'] ) && '' !== (string) $part['reason'] ) {
						$reasons[] = (string) $part['reason'];
					}
				}
			}
		}

		wp_send_json_success(
			array(
				'allowed' => $allowed,
				'action'  => $action,
				'reason'  => implode( ', ', array_unique( array_filter( $reasons ) ) ),
				'parts'   => array(
					'timing'  => $timing,
					'identity'=> $base,
					'message' => $msg,
				),
			)
		);
	}

	/**
	 * AJAX: Add a spam keyword/phrase to the message scoring list.
	 * Used by Inbox → View submission “Spam training” panel.
	 */
	public static function ajax_add_spam_phrase() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'product-mailer-campaigns' ) ), 403 );
		}
		$nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['_wpnonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'pmcpc_add_spam_phrase' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'product-mailer-campaigns' ) ), 403 );
		}

		$phrase = isset( $_POST['phrase'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['phrase'] ) ) : '';
		$phrase = trim( preg_replace( '/\s+/', ' ', $phrase ) );
		$phrase = str_replace( array( "\r", "\n" ), '', $phrase );
		if ( '' === $phrase || strlen( $phrase ) < 3 ) {
			wp_send_json_error( array( 'message' => __( 'Phrase is too short.', 'product-mailer-campaigns' ) ), 400 );
		}
		if ( strlen( $phrase ) > 80 ) {
			wp_send_json_error( array( 'message' => __( 'Phrase is too long.', 'product-mailer-campaigns' ) ), 400 );
		}
		// Avoid URLs/domains (too volatile).
		if ( false !== strpos( $phrase, '://' ) || preg_match( '/\.[a-z]{2,}(\b|\/)/i', $phrase ) ) {
			wp_send_json_error( array( 'message' => __( 'Please add a word/phrase, not a URL or domain.', 'product-mailer-campaigns' ) ), 400 );
		}

		$current = '';
		if ( class_exists( 'PMCPC_Settings' ) ) {
			$current = (string) PMCPC_Settings::get( 'spam_message_keywords', '' );
		}
		$lines = preg_split( '/\r\n|\r|\n/', $current );
		$lines = is_array( $lines ) ? $lines : array();
		$norm_existing = array();
		foreach ( $lines as $l ) {
			$l = strtolower( trim( (string) $l ) );
			if ( '' !== $l ) {
				$norm_existing[ $l ] = true;
			}
		}
		$norm_phrase = strtolower( $phrase );
		if ( isset( $norm_existing[ $norm_phrase ] ) ) {
			wp_send_json_success( array( 'added' => false, 'phrase' => $phrase ) );
		}
		$lines[] = $phrase;
		$updated = trim( implode( "\n", array_filter( array_map( 'trim', $lines ) ) ) );
		if ( class_exists( 'PMCPC_Settings' ) ) {
			PMCPC_Settings::update( array( 'spam_message_keywords' => $updated ) );
		}
		wp_send_json_success( array( 'added' => true, 'phrase' => $phrase ) );
	}

    

    /**
     * Manual queue run from dashboard.
     */
    

    

    

    

    

    /**
     * Combined Email screen with tabs for Queue + History.
     *
     * @param string|null $force_tab Optional forced tab for back-compat routes.
     */
    



    

    

	/**
	 * Render the Spam Log admin page.
	 */
	

	/**
	 * Unified Inbox: shows allowed, held, and blocked submissions in one place.
	 *
	 * Data is stored in the pmcpc_spam_submissions table for simplicity and so
	 * admins can audit decisions (allowlist/blocklist) against historical entries.
	 */
/**
 * Admin helper: remove a domain from the blocked domains setting.
 */
private static function inbox_unblock_domain( $domain ) {
	$domain = strtolower( trim( (string) $domain ) );
	$domain = ltrim( $domain, "@ 	" );
	if ( '' === $domain ) {
		return false;
	}

	$new = array();
	foreach ( PMCPC_Settings::get_multiline_list( 'blocked_email_domains' ) as $line ) {
		$d = strtolower( trim( (string) $line ) );
		$d = ltrim( $d, "@ 	" );
		if ( '' === $d ) { continue; }
		if ( $d === $domain ) { continue; }
		$new[] = $d;
	}

	PMCPC_Settings::update_multiline_list( 'blocked_email_domains', $new );

	return true;
}

/**
 * Admin helper: add a domain to the protected (never auto-block) list.
 */
private static function inbox_protect_domain( $domain ) {
	$domain = strtolower( trim( (string) $domain ) );
	$domain = ltrim( $domain, "@ 	" );
	if ( '' === $domain ) {
		return false;
	}

	$lines   = PMCPC_Settings::get_multiline_list( 'spam_auto_block_protected_domains' );
	$lines[] = $domain;
	PMCPC_Settings::update_multiline_list( 'spam_auto_block_protected_domains', $lines );

	return true;
}

/**
 * Admin helper: set timing protection settings.
 */
private static function inbox_set_timing_settings( $enabled, $min_seconds ) {
	$enabled     = ( 'yes' === $enabled ) ? 'yes' : 'no';
	$min_seconds = max( 0, (int) $min_seconds );

	PMCPC_Settings::update(
		array(
			'spam_form_timing_enabled'     => $enabled,
			'spam_form_timing_min_seconds' => $min_seconds,
		)
	);

	return true;
}


	


    /**
     * Render the Forms admin page for creating simple dynamic forms.
     */
    

	/**
	 * Render Email History (sent emails only).
	 */
	
}

add_action( 'admin_enqueue_scripts', array( 'PMCPC_Admin', 'enqueue_polish_assets' ) );

if ( ! function_exists( 'pmcpc_render_pro_upsell_box' ) ) {
    /**
     * Backward-compatible wrapper for the Pro upsell box renderer.
     */
    function pmcpc_render_pro_upsell_box() {
        PMCPC_Admin::render_pro_upsell_box();
    }

	}



if ( ! function_exists( 'pmcpc_register_email_preview_page' ) ) {
	/**
	 * Backward-compatible wrapper for registering the hidden Email Preview page.
	 */
	function pmcpc_register_email_preview_page() {
		if ( class_exists( 'PMCPC_Admin_UI_Service' ) ) {
			$service = new PMCPC_Admin_UI_Service();
			$service->register_email_preview_page();
		}
	}
}

if ( ! function_exists( 'pmcpc_render_email_preview' ) ) {
	/**
	 * Backward-compatible wrapper for rendering a stored sent email.
	 */
	function pmcpc_render_email_preview() {
		PMCPC_Admin::render_email_preview();
	}
}

if ( ! function_exists( 'pmcpc_handle_resend_email' ) ) {
	/**
	 * Backward-compatible wrapper for resending a stored email log entry.
	 */
	function pmcpc_handle_resend_email() {
		PMCPC_Admin::handle_resend_email();
	}
}
