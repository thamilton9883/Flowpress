<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/traits/trait-pmcpc-automation-ui-methods.php';
require_once __DIR__ . '/traits/trait-pmcpc-automation-testing-methods.php';
require_once __DIR__ . '/traits/trait-pmcpc-automation-runtime-methods.php';
require_once __DIR__ . '/traits/trait-pmcpc-automation-templates-methods.php';
require_once __DIR__ . '/traits/trait-pmcpc-automation-admin-methods.php';
require_once __DIR__ . '/traits/trait-pmcpc-automation-segments-methods.php';

/**
 * Main bootstrap for Product Mailer Campaigns Pro.
 *
 * This add-on expects the free Product Mailer Campaigns plugin to be active.
 * It adds Automations and Segments pages under the existing FlowPress menu.
 */
class PMCPC_Automation_Bootstrap {

    /**
     * Cron hook name for inactive customer checks.
     */
    const CRON_HOOK_INACTIVE = 'pmcpc_pro_cron_check_inactive_customers';

    /**
     * Cron hook name for core subscriber trigger checks.
     */
    const CRON_HOOK_CORE = 'pmcpc_core_cron_check_subscriber_triggers';

    use PMCPC_Automation_UI_Methods;
    use PMCPC_Automation_Testing_Methods;
    use PMCPC_Automation_Runtime_Methods;
    use PMCPC_Automation_Templates_Methods;
    use PMCPC_Automation_Admin_Methods;
    use PMCPC_Automation_Segments_Methods;



/**
     * Run the Pro plugin.
     */
    public function run() {
        // Runtime hooks must run on front-end too (automation triggers).
        add_action( 'init', array( $this, 'register_runtime_hooks' ) );
        add_action( self::CRON_HOOK_INACTIVE, array( $this, 'cron_check_inactive_customers' ) );
        add_action( self::CRON_HOOK_CORE, array( $this, 'cron_check_core_subscriber_triggers' ) );

        // Filter campaign subscribers in the free plugin so we can apply Pro segments.
        add_filter( 'pmcpc_campaign_subscribers', array( $this, 'filter_campaign_subscribers_by_segment' ), 10, 2 );

        // Admin-only UI.
        if ( is_admin() ) {
            add_action( 'admin_init', array( $this, 'check_dependencies' ) );
            add_action( 'admin_menu', array( $this, 'register_menus' ), 20 );

            // AJAX helpers (admin only).
            add_action( 'wp_ajax_pmcpc_pro_subscriber_search', array( $this, 'ajax_subscriber_search' ) );
            add_action( 'wp_ajax_pmcpc_et_send_test', array( $this, 'ajax_email_template_send_test' ) );

            // Manual tools (admin-post handlers).
            add_action( 'admin_post_pmcpc_pro_run_inactive_scan', array( $this, 'handle_manual_inactive_scan' ) );
            add_action( 'admin_post_pmcpc_pro_simulate_trigger', array( $this, 'handle_manual_simulate_trigger' ) );
            add_action( 'admin_post_pmcpc_pro_debug_abandoned_cart', array( $this, 'handle_manual_debug_abandoned_cart' ) );
            add_action( 'admin_post_pmcpc_pro_force_abandoned_cart', array( $this, 'handle_manual_force_abandoned_cart' ) );
            add_action( 'admin_post_pmcpc_pro_start_abandoned_recovery', array( $this, 'handle_manual_start_abandoned_recovery' ) );
            add_action( 'admin_post_pmcpc_pro_queue_abandoned_step_now', array( $this, 'handle_manual_queue_abandoned_step_now' ) );
            add_action( 'admin_post_pmcpc_pro_adjust_testing_time', array( $this, 'handle_manual_adjust_testing_time' ) );
            add_action( 'admin_post_pmcpc_pro_run_queue_processor', array( $this, 'handle_manual_run_queue_processor' ) );
            add_action( 'admin_post_pmcpc_pro_run_profile_trigger_scan', array( $this, 'handle_manual_run_profile_trigger_scan' ) );

            // Prefill the step-by-step Campaign builder fields when arriving via Pro shortcuts.
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_campaign_builder_prefill' ) );

            // Email Template UX helpers (media picker + color picker).
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_email_template_assets' ) );

            // Automations testing tools UX.
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_automations_assets' ) );
        }
    }

}
