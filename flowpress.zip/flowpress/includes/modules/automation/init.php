<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once __DIR__ . '/class-pmcpc-automation-bootstrap.php';

add_action(
    'plugins_loaded',
    function() {
        // Only load for admins.
        if ( ! is_admin() ) {
            return;
        }
        $bootstrap = new PMCPC_Automation_Bootstrap();
        $bootstrap->run();
    },
    25
);
