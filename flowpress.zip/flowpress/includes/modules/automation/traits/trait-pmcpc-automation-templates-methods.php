<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Email template and editor methods for FlowPress automations.
 */
trait PMCPC_Automation_Templates_Methods {

    /**
     * Enqueue assets used on the Email Template page.
     */
    public function enqueue_email_template_assets() {
        if ( ! is_admin() ) {
            return;
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( ! in_array( $page, array( 'pmcpc_email_template', 'pmcpc_email_templates' ), true ) ) {
            return;
        }

        // WP media modal.
        if ( function_exists( 'wp_enqueue_media' ) ) {
            wp_enqueue_media();
        }

        // WP color picker.
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );

        // Ensure jQuery exists for wpColorPicker.
        wp_enqueue_script( 'jquery' );

        // Email Template admin helpers (external file to avoid inline-script blockers).
        wp_enqueue_script(
            'pmcpc-pro-email-template-admin',
            PMCPC_PLUGIN_URL . 'assets/js/email-template-admin.js',
            array( 'jquery', 'wp-color-picker' ),
            PMCPC_PLUGIN_VERSION,
            true
        );

        // Provide data for the live preview renderer.
        $blogname = get_bloginfo( 'name' );
        $preview_body = implode(
            '',
            array(
                '<h2 style="margin:0 0 10px;font-size:20px;line-height:1.3;">New arrivals at {{site_name}}</h2>',
                '<p style="margin:0 0 14px;">A few freshly listed pieces we thought you might love.</p>',
                '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="width:100%;">',
                '  <tr>',
                '    <td style="padding:12px;border:1px solid #e5e7eb;border-radius:10px;">',
                '      <strong>Vintage oak sideboard</strong><br />',
                '      <span style="color:#6b7280;">Characterful storage, beautifully aged.</span><br />',
                '      <a href="#" style="display:inline-block;margin-top:10px;background:{{accent}};color:#fff;text-decoration:none;padding:10px 14px;border-radius:8px;">View item</a>',
                '    </td>',
                '  </tr>',
                '</table>',
            )
        );

        // Provide a little context to the JS layer so it can support autosave + unsaved indicators.
        $selected_id = isset( $_GET['template'] ) ? sanitize_key( wp_unslash( $_GET['template'] ) ) : '';
        if ( ! $selected_id ) {
            $selected_id = $this->get_default_email_template_id();
        }
        $all = $this->get_all_email_templates();
        if ( ! isset( $all[ $selected_id ] ) ) {
            $selected_id = $this->get_default_email_template_id();
        }
        $updated_at = 0;
        if ( isset( $all[ $selected_id ]['updated_at'] ) ) {
            $updated_at = absint( $all[ $selected_id ]['updated_at'] );
        }

        wp_localize_script( 'pmcpc-pro-email-template-admin', 'pmcpcET', array(
            'siteName'    => $blogname,
            'previewBody' => $preview_body,
            'productsHtml' => '<div style="padding:12px;border:1px solid #e5e7eb;border-radius:10px;margin-top:14px;"><strong>Example product (preview)</strong><div style="color:#6b7280;margin-top:4px;">This is placeholder content for the preview only.</div></div>',
            'reviewsHtml' => '<div style="margin-top:14px;"><p style="margin:0 0 12px 0;font-weight:600;color:#111;">What customers are saying</p><div style="border:1px solid #e5e7eb;border-radius:12px;padding:16px;background:#fafafa;"><div style="margin:0 0 10px 0;font-size:16px;color:#111;letter-spacing:1px;">★★★★★</div><p style="margin:0 0 10px 0;color:#444;line-height:1.6;">“A beautiful and unusual piece — exactly the sort of find we hoped for.”</p><p style="margin:0;color:#6b7280;font-size:13px;">— Example customer</p></div></div>',
            'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
            'sendTestNonce' => wp_create_nonce( 'pmcpc_et_send_test' ),
            'adminEmail'  => (string) get_option( 'admin_email', '' ),
            'templateId'  => $selected_id,
            'updatedAt'   => $updated_at,
        ) );
    }

    /**
     * AJAX: Send a test email for the Email Template builder.
     */
    public function ajax_email_template_send_test() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'product-mailer-campaigns' ) ), 403 );
        }

        check_ajax_referer( 'pmcpc_et_send_test', 'nonce' );

        $to = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : '';
        if ( empty( $to ) || ! is_email( $to ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'product-mailer-campaigns' ) ), 400 );
        }

        $subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
        if ( '' === $subject ) {
            $subject = sprintf( __( 'Test email: %s', 'product-mailer-campaigns' ), get_bloginfo( 'name' ) );
        }

        $html = isset( $_POST['html'] ) ? wp_kses_post( wp_unslash( $_POST['html'] ) ) : '';
        if ( '' === trim( $html ) ) {
            wp_send_json_error( array( 'message' => __( 'Template content is empty.', 'product-mailer-campaigns' ) ), 400 );
        }

        $headers = array( 'Content-Type: text/html; charset=UTF-8' );
        $sent = wp_mail( $to, $subject, $html, $headers );

        if ( $sent ) {
            wp_send_json_success( array( 'message' => __( 'Test email sent.', 'product-mailer-campaigns' ) ) );
        }

        wp_send_json_error( array( 'message' => __( 'Test email could not be sent. Check your mail configuration.', 'product-mailer-campaigns' ) ), 500 );
    }

    /**
     * Automations admin-page assets.
     *
     * Currently used for the subscriber email autocomplete in the testing tool.
     */
    public function enqueue_automations_assets( $hook_suffix ) {
        // Only on our Automations page.
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 'pmcpc_automations' !== $page ) {
            return;
        }

        // Use WP core jQuery UI Autocomplete (already bundled in wp-admin).
        wp_enqueue_script( 'jquery' );
        wp_enqueue_script( 'jquery-ui-autocomplete' );

        // Automations page layout tweaks (WP admin card max-width override + responsive grid).
        wp_enqueue_style(
            'pmcpc-automations-testing-center',
            PMCPC_PLUGIN_URL . 'assets/css/automations-testing.css',
            array(),
            PMCPC_PLUGIN_VERSION
        );

        wp_register_style( 'pmcpc-automations-admin', false, array( 'pmcpc-automations-testing-center' ), PMCPC_PLUGIN_VERSION );
        wp_enqueue_style( 'pmcpc-automations-admin' );
        wp_add_inline_style(
            'pmcpc-automations-admin',
            '/* Automations page layout */' . "\n"
            . '.pmcpc-automations-top{display:grid;grid-template-columns:minmax(320px,420px) minmax(0,1fr);gap:16px;margin:16px 0;align-items:start;}' . "\n"
            . '.pmcpc-automations-top .pmcpc-card{max-width:none;width:auto;margin:0;align-self:start;}
.pmcpc-automations-top .pmcpc-card--starter{position:static;top:auto;}' . "\n"
            . '.pmcpc-automations-top .pmcpc-card--full{grid-column:1 / -1;}' . "\n"
            . '.pmcpc-trigger-test{border:1px solid #dcdcde;border-radius:8px;background:#fff;padding:16px 18px;box-shadow:0 1px 0 rgba(0,0,0,.02);}' . "\n"
            . '.pmcpc-trigger-test__title{margin:0 0 6px 0;font-size:16px;line-height:1.35;}' . "\n"
            . '.pmcpc-trigger-test__intro{margin:0 0 14px 0;color:#50575e;max-width:940px;}' . "\n"
            . '.pmcpc-automation-lede{margin:0 0 10px 0;color:#50575e;max-width:920px;}' . "\n"
            . '.pmcpc-automation-controls{display:flex;gap:12px;align-items:center;margin:14px 0;flex-wrap:wrap;}' . "\n"
            . '.pmcpc-automation-controls .button-group{display:flex;gap:0;}' . "\n"
            . '.pmcpc-automation-controls .button-group .button{margin-right:0;}' . "\n"
            . '.pmcpc-automation-controls .button-group .button + .button{margin-left:-1px;}' . "\n"
            . '.pmcpc-automation-controls [data-pmcpc-search]{min-width:250px;}' . "\n"
            . '.pmcpc-automation-controls [data-pmcpc-count]{color:#646970;}' . "\n"
            . '.pmcpc-automation-table td{vertical-align:top;}' . "\n"
            . '.pmcpc-automation-trigger{display:flex;align-items:flex-start;gap:8px;}' . "\n"
            . '.pmcpc-automation-trigger__icon{font-size:16px;line-height:1.35;width:18px;text-align:center;flex:0 0 18px;}' . "\n"
            . '.pmcpc-status-pill{display:inline-flex;gap:6px;align-items:center;padding:2px 8px;border-radius:999px;line-height:1.5;font-size:12px;}' . "\n"
            . '.pmcpc-status-pill--active{background:#e6f4ea;color:#116329;}' . "\n"
            . '.pmcpc-status-pill--inactive{background:#f0f0f1;color:#50575e;}' . "\n"
            . '.pmcpc-status-pill--locked,.pmcpc-status-pill--needs-data{background:#fff8e5;color:#8a5a00;}' . "\n"
            . '.pmcpc-automation-actions{display:flex;flex-wrap:wrap;gap:6px;align-items:center;}' . "\n"
            . '.pmcpc-automation-actions .button{margin:0;white-space:nowrap;}' . "\n"
            . '.pmcpc-badge-grid{display:flex;flex-wrap:wrap;gap:4px;}' . "\n"
            . '.pmcpc-badge-grid .pmcpc-badge{display:inline-flex;gap:6px;align-items:center;padding:1px 7px;border-radius:999px;background:#e7f5ff;line-height:1.4;}' . "\n"
            . '.pmcpc-automation-table .pmcpc-badge .description{margin:0;}' . "\n"
            . '@media (max-width: 782px){.pmcpc-automations-top{grid-template-columns:1fr;}.pmcpc-automations-top .pmcpc-card--full{grid-column:auto;}.pmcpc-automation-controls{align-items:stretch;}.pmcpc-automation-controls [data-pmcpc-count]{margin-left:0;}.pmcpc-automation-controls [data-pmcpc-search]{min-width:0;width:100%;}}' . "\n"
        );

        $nonce = wp_create_nonce( 'pmcpc_pro_subscriber_search' );

        wp_enqueue_script(
            'pmcpc-automations-testing',
            PMCPC_PLUGIN_URL . 'assets/js/automations-testing.js',
            array( 'jquery', 'jquery-ui-autocomplete' ),
            PMCPC_PLUGIN_VERSION,
            true
        );

        wp_localize_script(
            'pmcpc-automations-testing',
            'PMCPC_PRO_AUTOMATIONS',
            array(
                'ajax_url'       => admin_url( 'admin-ajax.php' ),
                'nonce'          => $nonce,
                'collapse_label' => __( 'Collapse testing center', 'product-mailer-campaigns' ),
                'expand_label'   => __( 'Expand testing center', 'product-mailer-campaigns' ),
                'storage_key'    => 'pmcpc_testing_center_state',
            )
        );
    }


    /**
     * AJAX: search subscriber emails for the testing tool autocomplete.
     */
    public function ajax_subscriber_search() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
        }

        $nonce = isset( $_GET['nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'pmcpc_pro_subscriber_search' ) ) {
            wp_send_json_error( array( 'message' => 'bad_nonce' ), 400 );
        }

        $term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';
        $term = trim( $term );

        if ( strlen( $term ) < 2 ) {
            wp_send_json_success( array() );
        }

        global $wpdb;
        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT email FROM %i WHERE email LIKE %s ORDER BY id DESC LIMIT 12",
                $subscribers_table,
                '%' . $wpdb->esc_like( $term ) . '%'
            )
        );

        $out = array();
        if ( $rows && is_array( $rows ) ) {
            foreach ( $rows as $e ) {
                $e = sanitize_email( (string) $e );
                if ( $e ) {
                    $out[] = $e;
                }
            }
        }

        wp_send_json_success( array_values( array_unique( $out ) ) );
    }

    /**
     * Enqueue an inline script that pre-fills campaign Name/Subject when using the new wizard.
     *
     * We only do this for new campaigns (pmcpc_new=1) because existing campaigns should not
     * be overwritten.
     */
    public function enqueue_campaign_builder_prefill() {
        if ( ! is_admin() ) {
            return;
        }

        // Only on the Campaign builder page.
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 'pmcpc_campaigns' !== $page ) {
            return;
        }

        $is_new = isset( $_GET['pmcpc_new'] ) && '1' === sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_new'] ) );

        // IMPORTANT: In the base plugin, the wizard can create a draft campaign ID early in the flow.
        // We still want to apply Pro template defaults whenever pmcpc_new=1, even if an id param exists.
        if ( ! $is_new ) {
            return;
        }

        $blogname = get_bloginfo( 'name' );
        $tmpl = $this->get_email_template_settings();
        $all_tmpl = $this->get_all_email_templates();

        // Campaign wizard prefill (Name/Subject/Email wrapper)
        // IMPORTANT: some hosts block inline JS in wp-admin. Use an enqueued file instead.
        wp_enqueue_script( 'jquery' );
        wp_enqueue_script(
            'pmcpc-pro-campaign-prefill',
            PMCPC_PLUGIN_URL . 'assets/js/campaign-prefill.js',
            array( 'jquery' ),
            PMCPC_PLUGIN_VERSION,
            true
        );
        wp_localize_script(
            'pmcpc-pro-campaign-prefill',
            'pmcpcCampaignPrefill',
            array(
                'siteName'    => $blogname,
                'defaultTmpl' => $tmpl,
                'allTemplates'=> $all_tmpl,
            )
        );
    }

    /**
     * Built-in Pro email template presets.
     *
     * Each preset is a full wrapper that must contain {pmcpc_body}.
     *
     * @return array<string,array{label:string,logo_url:string,accent_color:string,header_html:string}>
     */
    protected function get_email_template_presets() {
        return PMCPC_Email_Templates::get_presets();
    }

/**
     * Get all Pro email templates (presets + saved overrides + saved custom templates).
     *
     * @return array<string,array{label:string,logo_url:string,accent_color:string,header_html:string}>
     */
    protected function get_all_email_templates() {
        // Migration: legacy single-template option -> create a saved custom template once.
        $legacy = get_option( 'pmcpc_email_template', null );
        if ( is_array( $legacy ) ) {
            $saved = get_option( 'pmcpc_pro_email_templates', array() );
            if ( ! is_array( $saved ) ) {
                $saved = array();
            }
            if ( ! isset( $saved['custom_legacy'] ) ) {
                $saved['custom_legacy'] = array(
                    'label'        => __( 'Custom (legacy)', 'product-mailer-campaigns' ),
                    'logo_url'     => isset( $legacy['logo_url'] ) ? (string) $legacy['logo_url'] : '',
                    'accent_color' => isset( $legacy['accent_color'] ) ? (string) $legacy['accent_color'] : '#1d4ed8',
                    'header_html'  => isset( $legacy['header_html'] ) ? (string) $legacy['header_html'] : '',
                );
                update_option( 'pmcpc_pro_email_templates', $saved );
            }
        }

        return PMCPC_Email_Templates::get_all();
    }

/**
     * Get the default template id.
     */
    protected function get_default_email_template_id() {
        return PMCPC_Email_Templates::get_default_id();
    }

/**
     * Get per-trigger default email template mapping.
     *
     * @return array<string,string>
     */
    protected function get_email_template_by_trigger_map() {
        $map = get_option( 'pmcpc_pro_email_template_by_trigger', array() );
        if ( ! is_array( $map ) ) {
            return array();
        }
        $clean = array();
        foreach ( $map as $k => $v ) {
            $k = sanitize_key( (string) $k );
            $v = sanitize_key( (string) $v );
            if ( '' !== $k && '' !== $v ) {
                $clean[ $k ] = $v;
            }
        }
        return $clean;
    }

    /**
     * Resolve the default template id for a given automation trigger key.
     *
     * @param string $trigger_key
     * @return string
     */
    protected function get_email_template_id_for_trigger( $trigger_key ) {
        $trigger_key = sanitize_key( (string) $trigger_key );
        if ( '' === $trigger_key ) {
            return $this->get_default_email_template_id();
        }

        // If we ship a preset with the same id as the trigger key, prefer it.
        // This gives a sensible "one template per trigger" default without
        // forcing users to manage mappings unless they want to.
        $all = $this->get_all_email_templates();
        if ( isset( $all[ $trigger_key ] ) ) {
            return $trigger_key;
        }

        $map = $this->get_email_template_by_trigger_map();
        if ( isset( $map[ $trigger_key ] ) ) {
            if ( isset( $all[ $map[ $trigger_key ] ] ) ) {
                return (string) $map[ $trigger_key ];
            }
        }
        return $this->get_default_email_template_id();
    }

    /**
     * Set per-trigger default template id.
     *
     * @param string $trigger_key
     * @param string $template_id
     * @return void
     */
    protected function set_email_template_id_for_trigger( $trigger_key, $template_id ) {
        $trigger_key = sanitize_key( (string) $trigger_key );
        $template_id = sanitize_key( (string) $template_id );
        if ( '' === $trigger_key ) {
            return;
        }
        $all = $this->get_all_email_templates();
        if ( '' === $template_id || ! isset( $all[ $template_id ] ) ) {
            // Remove mapping.
            $map = $this->get_email_template_by_trigger_map();
            if ( isset( $map[ $trigger_key ] ) ) {
                unset( $map[ $trigger_key ] );
                update_option( 'pmcpc_pro_email_template_by_trigger', $map );
            }
            return;
        }
        $map = $this->get_email_template_by_trigger_map();
        $map[ $trigger_key ] = $template_id;
        update_option( 'pmcpc_pro_email_template_by_trigger', $map );
    }


    /**
     * Get Pro email template settings.
     *
     * If $template_id is omitted, returns the current default template.
     *
     * @param string|null $template_id
     *
     * @return array{label:string,logo_url:string,accent_color:string,header_html:string}
     */
    protected function get_email_template_settings( $template_id = null ) {
        $all = $this->get_all_email_templates();
        if ( null === $template_id || '' === $template_id ) {
            $template_id = $this->get_default_email_template_id();
        }
        $template_id = sanitize_key( (string) $template_id );
        if ( isset( $all[ $template_id ] ) ) {
            return $all[ $template_id ];
        }
        // Final fallback.
        return array(
            'label'        => __( 'Classic', 'product-mailer-campaigns' ),
            'logo_url'     => '',
            'accent_color' => '#1d4ed8',
            'header_html'  => $this->get_default_wrapper_html(),
        );
    }

    /**
     * Render the Email Template settings page (Pro).
     */
    public function render_email_template_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $presets = $this->get_email_template_presets();
        $all     = $this->get_all_email_templates();


        // Optional: set per-automation template defaults (e.g. review request vs post-purchase).
        $automation_key = '';
        if ( isset( $_GET['automation'] ) ) {
            $automation_key = sanitize_key( wp_unslash( $_GET['automation'] ) );
        }
        $selected_id = isset( $_GET['template'] ) ? sanitize_key( wp_unslash( $_GET['template'] ) ) : '';
        if ( ! $selected_id ) {
            $selected_id = $this->get_default_email_template_id();
        }
        if ( ! isset( $all[ $selected_id ] ) ) {
            $selected_id = $this->get_default_email_template_id();
        }


        // When the user clicks 'Update preview' we rebuild the preview from posted values without saving.
        $pmcpc_preview_post = null;

        // Save / actions.
        if ( isset( $_POST['pmcpc_pro_email_template_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pmcpc_pro_email_template_nonce'] ) ), 'pmcpc_pro_email_template_save' ) ) {
                        $automation_key_post = '';
            if ( isset( $_POST['automation_key'] ) ) {
                $automation_key_post = sanitize_key( wp_unslash( $_POST['automation_key'] ) );
            }
$action      = isset( $_POST['pmcpc_action'] ) ? sanitize_key( wp_unslash( $_POST['pmcpc_action'] ) ) : 'save';
            $template_id = isset( $_POST['template_id'] ) ? sanitize_key( wp_unslash( $_POST['template_id'] ) ) : $selected_id;

            $saved = get_option( 'pmcpc_pro_email_templates', array() );
            if ( ! is_array( $saved ) ) {
                $saved = array();
            }

            // Preview only (do not save).
            if ( 'preview' === $action ) {
                $posted_header_html = isset( $_POST['header_html'] ) ? (string) wp_unslash( $_POST['header_html'] ) : '';
                // Do not allow scripts in wrapper HTML (emails should never include them).
                $posted_header_html = preg_replace( '/<\s*script[^>]*>.*?<\s*\/\s*script\s*>/is', '', $posted_header_html );
                // If Wrapper HTML is blank (or was hidden / not edited), keep the current template wrapper.
                if ( '' === trim( $posted_header_html ) ) {
                    $posted_header_html = (string) ( $all[ $template_id ]['header_html'] ?? '' );
                }

                $pmcpc_preview_post = array(


                    'label'        => isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : ( $all[ $template_id ]['label'] ?? $template_id ),
                    'logo_url'     => isset( $_POST['logo_url'] ) ? esc_url_raw( wp_unslash( $_POST['logo_url'] ) ) : '',
                    'accent_color' => isset( $_POST['accent_color'] ) ? sanitize_text_field( wp_unslash( $_POST['accent_color'] ) ) : '#1d4ed8',
                    'header_html'  => $posted_header_html,
                );




                if ( ! preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', (string) $pmcpc_preview_post['accent_color'] ) ) {
                    $pmcpc_preview_post['accent_color'] = '#1d4ed8';
                }
                if ( isset( $_POST['pmcpc_restore_default_wrapper'] ) || 'restore_classic' === $action ) {
                    $pmcpc_preview_post['header_html'] = $this->get_default_wrapper_html();
                }

                $selected_id = $template_id;
                echo '<div class="notice notice-info"><p>' . esc_html__( 'Preview updated (not saved).', 'product-mailer-campaigns' ) . '</p></div>';
            }

            elseif ( 'duplicate' === $action ) {
                $source_id = $template_id;
                $source    = $this->get_email_template_settings( $source_id );
                $new_label = isset( $_POST['new_label'] ) ? sanitize_text_field( wp_unslash( $_POST['new_label'] ) ) : '';
                if ( '' === trim( $new_label ) ) {
                    $new_label = __( 'Custom copy', 'product-mailer-campaigns' );
                }
                $new_id = 'custom_' . gmdate( 'Ymd_His' );

                $saved[ $new_id ] = array(
                    'label'        => $new_label,
                    'logo_url'     => (string) ( $source['logo_url'] ?? '' ),
                    'accent_color' => (string) ( $source['accent_color'] ?? '#1d4ed8' ),
                    'header_html'  => (string) ( $source['header_html'] ?? $this->get_default_wrapper_html() ),
                    'updated_at'   => time(),
                );

                update_option( 'pmcpc_pro_email_templates', $saved );
                update_option( 'pmcpc_pro_email_template_default', $new_id );

                $selected_id = $new_id;
                $all         = $this->get_all_email_templates();

                echo '<div class="notice notice-success"><p>' . esc_html__( 'Template duplicated and set as default.', 'product-mailer-campaigns' ) . '</p></div>';
            } elseif ( 'restore_preset' === $action ) {
                // Reset to preset by removing any saved override for that key.
                if ( isset( $presets[ $template_id ] ) && isset( $saved[ $template_id ] ) ) {
                    unset( $saved[ $template_id ] );
                    update_option( 'pmcpc_pro_email_templates', $saved );
                    $all = $this->get_all_email_templates();
                    echo '<div class="notice notice-success"><p>' . esc_html__( 'Preset restored.', 'product-mailer-campaigns' ) . '</p></div>';
                }
                $selected_id = $template_id;
            } elseif ( 'delete' === $action ) {
                // Delete custom template (presets cannot be deleted).
                if ( isset( $presets[ $template_id ] ) ) {
                    echo '<div class="notice notice-warning"><p>' . esc_html__( 'Preset templates cannot be deleted.', 'product-mailer-campaigns' ) . '</p></div>';
                    $selected_id = $template_id;
                } else {
                    if ( isset( $saved[ $template_id ] ) ) {
                        unset( $saved[ $template_id ] );
                        update_option( 'pmcpc_pro_email_templates', $saved );
                    }
                    // If deleting the default, fall back to classic.
                    $cur_default = $this->get_default_email_template_id();
                    if ( $cur_default === $template_id ) {
                        update_option( 'pmcpc_pro_email_template_default', 'classic' );
                    }
                    $all = $this->get_all_email_templates();
                    $selected_id = $this->get_default_email_template_id();
                    echo '<div class="notice notice-success"><p>' . esc_html__( 'Template deleted.', 'product-mailer-campaigns' ) . '</p></div>';
                }
            } else {
                // Save changes to the selected template.
                                $posted_header_html = isset( $_POST['header_html'] ) ? (string) wp_unslash( $_POST['header_html'] ) : '';
                // Do not allow scripts in wrapper HTML (emails should never include them).
                $posted_header_html = preg_replace( '/<\s*script[^>]*>.*?<\s*\/\s*script\s*>/is', '', $posted_header_html );
                // If Wrapper HTML is blank (or was hidden / not edited), keep the existing wrapper for this template.
                if ( '' === trim( $posted_header_html ) ) {
                    $posted_header_html = (string) ( $all[ $template_id ]['header_html'] ?? '' );
                }

                $settings = array(
                    'label'        => isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : ( $all[ $template_id ]['label'] ?? $template_id ),
                    'logo_url'     => isset( $_POST['logo_url'] ) ? esc_url_raw( wp_unslash( $_POST['logo_url'] ) ) : '',
                    'accent_color' => isset( $_POST['accent_color'] ) ? sanitize_text_field( wp_unslash( $_POST['accent_color'] ) ) : '',
                    'header_html'  => $posted_header_html,
                    'updated_at'   => time(),
                );



                // Basic validation on color.
                if ( ! preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $settings['accent_color'] ) ) {
                    $settings['accent_color'] = '#1d4ed8';
                }

                // Restore default wrapper (classic preset HTML) if requested via UI button.
                if ( isset( $_POST['pmcpc_restore_default_wrapper'] ) || 'restore_classic' === $action ) {
                    $settings['header_html'] = $this->get_default_wrapper_html();
                }

                $saved[ $template_id ] = $settings;
                update_option( 'pmcpc_pro_email_templates', $saved );

                if ( 'set_default' === $action ) {
                    update_option( 'pmcpc_pro_email_template_default', $template_id );
                    echo '<div class="notice notice-success"><p>' . esc_html__( 'Template saved and set as default.', 'product-mailer-campaigns' ) . '</p></div>';
                }
            if ( 'set_for_trigger' === $action && ! empty( $automation_key_post ) ) {
                $this->set_email_template_id_for_trigger( $automation_key_post, $template_id );
                add_settings_error( 'pmcpc_templates', 'pmcpc_set_for_trigger', sprintf( __( 'Set as default template for automation: %s', 'product-mailer-campaigns' ), esc_html( $automation_key_post ) ), 'updated' );
            }
 else {
                    echo '<div class="notice notice-success"><p>' . esc_html__( 'Template saved.', 'product-mailer-campaigns' ) . '</p></div>';
                }

                $selected_id = $template_id;
                $all         = $this->get_all_email_templates();
            }
        }

        $s           = $this->get_email_template_settings( $selected_id );
        if ( is_array( $pmcpc_preview_post ) ) {
            $s = $pmcpc_preview_post;
        }
        $wrapper     = isset( $s['header_html'] ) ? trim( (string) $s['header_html'] ) : '';
        $is_preset   = isset( $presets[ $selected_id ] );
        $default_id  = $this->get_default_email_template_id();

        

        echo '<div class="wrap">';
        if ( class_exists( 'PMCPC_Admin' ) ) {
            PMCPC_Admin::render_app_header(
                __( 'Templates', 'product-mailer-campaigns' ),
                array(
                    array(
                        'label' => __( 'New Campaign', 'product-mailer-campaigns' ),
                        'url'   => admin_url( 'admin.php?page=pmcpc_campaigns&action=new' ),
                        'class' => 'button-primary',
                    ),
                    array(
                        'label' => __( 'New Automation', 'product-mailer-campaigns' ),
                        'url'   => $this->build_new_automation_url(),
                    ),
                )
            );
        }
        echo '<div class="pmcpc-hub-intro"><h2>' . esc_html__( 'Templates', 'product-mailer-campaigns' ) . '</h2><p class="description">' . esc_html__( 'Choose a default email template for campaigns created from Commerce shortcuts such as Automations and Segments. Templates use the same HTML as Campaigns → Email, so you can copy and paste between them.', 'product-mailer-campaigns' ) . '</p></div>';
        if ( ! empty( $automation_key ) ) {
            echo '<div class="pmcpc-inline-result pmcpc-inline-result--info"><p>' . sprintf( esc_html__( 'You are editing template defaults for the %s automation. Use “Save & set for this automation” to apply a wrapper just for this trigger.', 'product-mailer-campaigns' ), '<strong>' . esc_html( $automation_key ) . '</strong>' ) . '</p></div>';
        }

        // Lightweight page styles (kept inline to avoid asset management overhead).
        echo '<style>';
        echo '  .pmcpc-et-topbar{position:sticky;top:32px;z-index:60;background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:12px 14px;margin:0 0 14px;box-shadow:0 1px 0 rgba(0,0,0,.03)}';
        echo '  .pmcpc-et-topbar h2{margin:0;font-size:14px;line-height:1.2}';
        echo '  .pmcpc-et-topbar .pmcpc-et-sub{color:#646970;font-size:12px;margin:2px 0 0}';
        echo '  .pmcpc-et-topbar .pmcpc-et-bar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:space-between}';
        echo '  .pmcpc-et-topbar .pmcpc-et-bar-left{display:flex;gap:10px;align-items:center;flex-wrap:wrap}';
        echo '  .pmcpc-et-topbar .pmcpc-et-bar-right{display:flex;gap:8px;align-items:center;flex-wrap:wrap}';
        echo '  .pmcpc-et-switcher{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:14px 0 14px;padding:12px 16px;border:1px solid #dcdcde;border-radius:12px;background:#fff;box-shadow:0 1px 1px rgba(0,0,0,.03)}';
        echo '  .pmcpc-et-switcher .description{margin-left:auto}';
        echo '  .pmcpc-et-grid{display:flex;gap:20px;align-items:flex-start;max-width:1260px}';
        echo '  .pmcpc-et-left{flex:1 1 0;min-width:560px}';
        echo '  .pmcpc-et-right{width:560px;max-width:48vw}';
        echo '  .pmcpc-et-sticky{position:sticky;top:32px}';
        echo '  .pmcpc-et-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;box-shadow:0 1px 1px rgba(0,0,0,.03)}';
        echo '  .pmcpc-et-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}';
        echo '  .pmcpc-et-row .button{white-space:nowrap}';
        echo '  .pmcpc-et-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:14px 0 0}';
        echo '  .pmcpc-et-actions .pmcpc-et-spacer{flex:1}';
        echo '  .pmcpc-et-logo{display:flex;gap:12px;align-items:flex-start;flex-wrap:wrap}';
        echo '  .pmcpc-et-logo-thumb{width:180px;min-height:68px;border:1px solid #dcdcde;border-radius:10px;background:#f6f7f7;display:flex;align-items:center;justify-content:center;overflow:hidden}';
        echo '  .pmcpc-et-logo-thumb img{max-width:160px;max-height:56px;height:auto;width:auto;display:block}';
        echo '  .pmcpc-et-logo-thumb .pmcpc-et-logo-empty{color:#646970;font-size:12px;padding:10px;text-align:center}';
        echo '  .pmcpc-et-more{margin-left:auto;position:relative}';
        echo '  .pmcpc-et-more > div{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:10px;position:absolute;right:0;top:40px;z-index:50;box-shadow:0 2px 8px rgba(0,0,0,.08);min-width:280px}';
        echo '  .pmcpc-et-more summary{cursor:pointer;user-select:none}';
        echo '  .pmcpc-et-more[open] summary{margin-bottom:0}';
        echo '  .pmcpc-et-more .button{margin:0 0 6px 0;display:inline-flex}';
	        // Advanced section is toggled via CSS (works even if JS is blocked).
	        echo '  #pmcpcEtAdvancedToggle{display:none!important}';
	        echo '  #pmcpcEtAdvancedToggle:not(:checked) ~ .pmcpc-et-advanced-wrap{display:none}';
	        echo '  #pmcpcEtAdvancedToggle:checked ~ .pmcpc-et-advanced-wrap{display:block}';
	        echo '  .pmcpc-et-advanced-wrap textarea{min-height:220px}';

		        // Preview width controls (CSS only).
		        // Use display:none so inputs never show even if admin CSS resets positioning.
	        echo '  .pmcpc-et-prevmode{display:none!important}';
	        echo '  .pmcpc-et-prevbtn{display:inline-flex;align-items:center;justify-content:center;border:1px solid #2271b1;border-radius:3px;padding:0 10px;height:30px;cursor:pointer;background:#f6f7f7;color:#2271b1;font-size:12px;line-height:28px}';
	        echo '  .pmcpc-et-prevbtn:hover{background:#fff}';
        echo '  .pmcpc-et-preview-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin:0 0 10px}';
        echo '  .pmcpc-et-preview-meta{margin:4px 0 0;color:#646970;font-size:12px;line-height:1.45}';
        echo '  .pmcpc-et-preview-frame{border:1px solid #dcdcde;border-radius:12px;overflow:hidden;background:linear-gradient(180deg,#f6f7f7 0%,#eef2f6 100%);padding:14px;text-align:center;box-shadow:inset 0 1px 0 rgba(255,255,255,.7)}';
        echo '  .pmcpc-et-preview-canvas{background:#dfe5eb;border:1px solid #c7d0db;border-radius:18px;padding:18px 16px 22px;position:relative}';
        echo '  .pmcpc-et-preview-canvas::before{content:"";display:block;width:84px;height:6px;border-radius:999px;background:#b9c3cf;margin:0 auto 14px}';
        echo '  #pmcpcPreviewSizer{width:100%;margin:0 auto;max-width:680px;transition:max-width .18s ease}';
	        echo '  #pmcpcPrevModeDesktop:checked ~ .pmcpc-et-preview-frame #pmcpcPreviewSizer{max-width:640px}';
	        echo '  #pmcpcPrevModeMobile:checked ~ .pmcpc-et-preview-frame #pmcpcPreviewSizer{max-width:400px}';
	        echo '  #pmcpcPrevModeDesktop:checked ~ .pmcpc-et-preview-head .pmcpc-et-prevbtn--desktop{background:#2271b1;color:#fff}';
	        echo '  #pmcpcPrevModeMobile:checked ~ .pmcpc-et-preview-head .pmcpc-et-prevbtn--mobile{background:#2271b1;color:#fff}';
        echo '  .pmcpc-et-help{color:#646970;font-size:12px;line-height:1.4;margin:6px 0 0}';
        echo '  .pmcpc-et-sendtest{position:relative}';
        echo '  .pmcpc-et-sendtest > div{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:12px;position:absolute;right:0;top:38px;z-index:70;box-shadow:0 6px 24px rgba(0,0,0,.12);min-width:340px}';
        echo '  .pmcpc-et-sendtest input[type=email]{width:100%;max-width:none}';
        echo '  @media (max-width: 1100px){.pmcpc-et-grid{display:block}.pmcpc-et-left{min-width:0}.pmcpc-et-right{width:auto;max-width:none;margin-top:18px}.pmcpc-et-sticky{position:static}.pmcpc-et-switcher .description{margin-left:0;width:100%}}';
        echo '</style>';

	        // Template selector (server-side). No JS required (a Load button is provided).
	        echo '<form method="get" id="pmcpc_template_switcher" class="pmcpc-et-switcher">';
	        // Keep the user on the Email Template admin page when switching templates.
	        // Using a non-registered slug will trigger a core "Sorry, you are not allowed to access this page." error.
	        $current_page_slug = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'pmcpc_email_templates';
	        if ( ! in_array( $current_page_slug, array( 'pmcpc_email_template', 'pmcpc_email_templates' ), true ) ) {
	            $current_page_slug = 'pmcpc_email_templates';
	        }
	        echo '<input type="hidden" name="page" value="' . esc_attr( $current_page_slug ) . '" />';
	        echo '<label for="pmcpc_template_select"><strong>' . esc_html__( 'Template', 'product-mailer-campaigns' ) . '</strong></label> ';
	        echo '<select name="template" id="pmcpc_template_select" style="min-width:240px;">';
        foreach ( $all as $id => $t ) {
            $label = (string) ( $t['label'] ?? $id );
            $suffix = ( $id === $default_id ) ? ' — ' . __( 'Default', 'product-mailer-campaigns' ) : '';
            echo '<option value="' . esc_attr( $id ) . '"' . selected( $selected_id, $id, false ) . '>' . esc_html( $label . $suffix ) . '</option>';
        }
        echo '</select>';
	        echo '<button type="submit" class="button">' . esc_html__( 'Load', 'product-mailer-campaigns' ) . '</button>';
        echo '<span class="description">' . ( $is_preset ? esc_html__( 'Preset', 'product-mailer-campaigns' ) : esc_html__( 'Custom', 'product-mailer-campaigns' ) ) . '</span>';
        echo '</form>';

        echo '<div class="pmcpc-et-grid" id="pmcpcEtRoot">';
        echo '  <div class="pmcpc-et-left">';

        echo '<form method="post" id="pmcpc_template_form" class="pmcpc-et-card">';
        wp_nonce_field( 'pmcpc_pro_email_template_save', 'pmcpc_pro_email_template_nonce' );
        echo '<input type="hidden" name="template_id" id="pmcpc_template_id" value="' . esc_attr( $selected_id ) . '" />';
        echo '<input type="hidden" name="new_label" id="pmcpcEtNewLabel" value="" />';
        if ( ! empty( $automation_key ) ) {
            echo '<input type="hidden" name="automation_key" value="' . esc_attr( $automation_key ) . '" />';
        }
			// Advanced toggle checkbox (must be a direct child of the form for CSS-only toggling).
			echo '<input type="checkbox" id="pmcpcEtAdvancedToggle" style="display:none!important" />';

			// Sticky top bar with primary actions.
			$editing_label = (string) ( $s['label'] ?? $selected_id );
			$is_default    = ( $selected_id === $default_id );
			$used_hint     = $is_default ? __( 'Default template', 'product-mailer-campaigns' ) : ( $is_preset ? __( 'Preset template', 'product-mailer-campaigns' ) : __( 'Custom template', 'product-mailer-campaigns' ) );
			// Usage hint: show how many automation defaults currently point at this template.
			$map = $this->get_email_template_by_trigger_map();
			$usage_count = 0;
			if ( is_array( $map ) ) {
				foreach ( $map as $k => $v ) {
					if ( (string) $v === (string) $selected_id ) {
						$usage_count++;
					}
				}
			}
			$usage_hint = '';
			if ( $usage_count > 0 ) {
				/* translators: %d is number of automation defaults */
				$usage_hint = sprintf( _n( 'Used by %d automation default', 'Used by %d automation defaults', $usage_count, 'product-mailer-campaigns' ), $usage_count );
			}
			$updated_at    = isset( $s['updated_at'] ) ? absint( $s['updated_at'] ) : 0;
			$updated_hint  = '';
			if ( $updated_at > 0 ) {
				/* translators: %s is a human time diff like "2 hours" */
				$updated_hint = sprintf( __( 'Last edited %s ago', 'product-mailer-campaigns' ), human_time_diff( $updated_at, time() ) );
			}
			echo '<div class="pmcpc-et-topbar" id="pmcpcEtTopbar">';
			echo '  <div class="pmcpc-et-bar">';
			echo '    <div class="pmcpc-et-bar-left">';
			echo '      <div>';
			echo '        <h2>' . esc_html( $editing_label ) . '</h2>';
			echo '        <div class="pmcpc-et-sub">' . esc_html( $used_hint ) . ( $usage_hint ? ' · ' . esc_html( $usage_hint ) : '' ) . ( $updated_hint ? ' · ' . esc_html( $updated_hint ) : '' ) . '</div>';
			echo '      </div>';
			echo '    </div>';
			echo '    <div class="pmcpc-et-bar-right">';
			echo '      <span id="pmcpcEtDirtyBadge" style="display:none;margin-right:6px;padding:3px 8px;border-radius:999px;background:#fff3cd;border:1px solid #ffecb5;color:#664d03;font-size:12px;">' . esc_html__( 'Unsaved changes', 'product-mailer-campaigns' ) . '</span>';
			echo '      <button type="submit" class="button button-primary" name="pmcpc_action" value="save">' . esc_html__( 'Save', 'product-mailer-campaigns' ) . '</button>';
			echo '      <button type="button" class="button" id="pmcpcEtSaveAsNew">' . esc_html__( 'Save as new', 'product-mailer-campaigns' ) . '</button>';
			echo '      <button type="submit" class="button" name="pmcpc_action" value="set_default">' . esc_html__( 'Set as default', 'product-mailer-campaigns' ) . '</button>';
			if ( ! empty( $automation_key ) ) {
				echo '  <button type="submit" class="button" name="pmcpc_action" value="set_for_trigger">' . esc_html__( 'Set for this automation', 'product-mailer-campaigns' ) . '</button>';
			}
			echo '      <details class="pmcpc-et-sendtest">';
			echo '        <summary class="button">' . esc_html__( 'Send test', 'product-mailer-campaigns' ) . '</summary>';
			echo '        <div>'; 
			echo '          <label for="pmcpcEtTestTo" class="screen-reader-text">' . esc_html__( 'Send test to', 'product-mailer-campaigns' ) . '</label>';
			echo '          <input type="email" id="pmcpcEtTestTo" placeholder="you@example.com" />';
			echo '          <div class="pmcpc-et-row" style="justify-content:flex-end;margin-top:8px;">';
			echo '            <button type="button" class="button button-primary" id="pmcpcEtSendTestGo">' . esc_html__( 'Send', 'product-mailer-campaigns' ) . '</button>';
			echo '          </div>';
			echo '          <p class="pmcpc-et-help">' . esc_html__( 'Leave blank to use the site admin email.', 'product-mailer-campaigns' ) . '</p>';
			echo '        </div>';
			echo '      </details>';
			echo '    </div>';
			echo '  </div>';
			echo '</div>';
			echo '<div id="pmcpcEtDraftNotice" style="display:none;margin-top:10px;padding:10px 12px;border:1px solid #dcdcde;border-radius:10px;background:#f6f7f7;"></div>';

	        // Advanced toggle (CSS-driven so it still works even if JS is blocked).
	        // IMPORTANT: the checkbox must be a *direct child* of the form so the sibling CSS selector works.
	        echo '<div class="pmcpc-et-row" style="justify-content:space-between;margin:2px 0 10px;">';
	        echo '  <div class="pmcpc-et-row">';
	        echo '    <strong>' . esc_html__( 'Editing:', 'product-mailer-campaigns' ) . '</strong> <span id="pmcpcEtEditingLabel" class="description"></span>';
	        echo '  </div>';
	        echo '  <div class="pmcpc-et-row" style="gap:8px;">';
	        echo '    <label for="pmcpcEtAdvancedToggle" style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;user-select:none;">';
	        echo '      <span>' . esc_html__( 'Advanced', 'product-mailer-campaigns' ) . '</span>';
	        echo '    </label>';
	        echo '  </div>';
	        echo '</div>';

	        // NOTE: The advanced section is outside the table so it can be toggled with pure CSS.
	        echo '<table class="form-table" role="presentation">';

        echo '<tr><th scope="row"><label for="label">' . esc_html__( 'Template name', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="label" id="label" type="text" class="regular-text" value="' . esc_attr( (string) ( $s['label'] ?? '' ) ) . '" />';
        echo '<p class="description">' . esc_html__( 'Shown in the template selector.', 'product-mailer-campaigns' ) . '</p></td></tr>';

        echo '<tr><th scope="row"><label for="logo_url">' . esc_html__( 'Logo', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
		echo '  <input name="logo_url" id="logo_url" type="hidden" value="' . esc_attr( (string) ( $s['logo_url'] ?? '' ) ) . '" />';
		echo '  <div class="pmcpc-et-logo">';
		echo '    <div class="pmcpc-et-logo-thumb" id="pmcpcLogoThumb">';
		$logo_url = (string) ( $s['logo_url'] ?? '' );
		if ( $logo_url ) {
			echo '      <img src="' . esc_url( $logo_url ) . '" alt="" />';
		} else {
			echo '      <div class="pmcpc-et-logo-empty">' . esc_html__( 'No logo selected', 'product-mailer-campaigns' ) . '</div>';
		}
		echo '    </div>';
		echo '    <div>'; 
		echo '      <div class="pmcpc-et-row">';
		echo '        <button type="button" class="button" id="pmcpcLogoPick">' . esc_html__( 'Replace', 'product-mailer-campaigns' ) . '</button>';
		echo '        <button type="button" class="button" id="pmcpcLogoClear">' . esc_html__( 'Remove', 'product-mailer-campaigns' ) . '</button>';
		echo '      </div>';
		echo '      <p class="pmcpc-et-help">' . esc_html__( 'Used by {{logo_html}} and as a fallback in previews.', 'product-mailer-campaigns' ) . '</p>';
		echo '    </div>';
		echo '  </div>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="accent_color">' . esc_html__( 'Brand colour', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="accent_color" id="accent_color" type="text" class="regular-text" value="' . esc_attr( (string) ( $s['accent_color'] ?? '' ) ) . '" placeholder="#1d4ed8" />';
	    echo '<p class="pmcpc-et-help">' . esc_html__( 'Used for buttons and links.', 'product-mailer-campaigns' ) . '</p></td></tr>';

	        echo '</table>';

	        echo '<div class="pmcpc-et-advanced-wrap" style="margin-top:12px;">';
	        echo '  <h3 style="margin:0 0 8px;">' . esc_html__( 'Template HTML', 'product-mailer-campaigns' ) . '</h3>';
	        echo '  <div class="pmcpc-placeholder-list pmcpc-insert-actions" style="margin:0 0 10px;">';
	        echo '    <button type="button" class="button" data-pmcpc-insert-target="header_html" data-pmcpc-insert-value="{{reviews_block}}">' . esc_html__( 'Insert Reviews', 'product-mailer-campaigns' ) . '</button>';
	        echo '    <button type="button" class="button" data-pmcpc-insert-target="header_html" data-pmcpc-insert-value="{{review_stars_block}}">' . esc_html__( 'Insert Review Stars', 'product-mailer-campaigns' ) . '</button>';
	        echo '  </div>';
	        echo '  <textarea name="header_html" id="header_html" class="large-text code" rows="10">' . esc_textarea( (string) ( $s['header_html'] ?? '' ) ) . '</textarea>';
	        echo '  <p class="pmcpc-et-help">' . esc_html__( 'This HTML is inserted directly into Campaigns → Email. Common placeholders: {{first_name}}, {{email}}, {{accent}}, {{site_name}}, {{logo_html}}, {{unsubscribe_url}}, {{products_block}}, {{reviews_block}}. Trigger-specific automations may also provide {{cart_items}}, {{cart_total}}, {{cart_url}}, {{order_id}}, {{review_url}}, or {{review_stars_block}}.', 'product-mailer-campaigns' ) . '</p>';
	        echo '  <p class="pmcpc-et-help">' . esc_html__( 'Use the insert buttons to place review content at the current cursor position.', 'product-mailer-campaigns' ) . '</p>';
	        echo '</div>';

        // Buttons.
        
echo '<div class="pmcpc-et-actions">';
echo '  <span class="pmcpc-et-spacer"></span>';
echo '  <details class="pmcpc-et-more" style="margin-left:auto;">';
echo '    <summary class="button">' . esc_html__( 'More actions', 'product-mailer-campaigns' ) . '</summary>';
echo '    <div>';
echo '      <button type="submit" class="button" name="pmcpc_action" value="restore_classic" >' . esc_html__( 'Restore classic wrapper', 'product-mailer-campaigns' ) . '</button>';

if ( ! $is_preset ) {
    // Custom templates can be deleted. Presets cannot.
    echo '      <button type="submit" class="button button-link-delete pmcpc-et-delete" name="pmcpc_action" value="delete">' . esc_html__( 'Delete template', 'product-mailer-campaigns' ) . '</button>';
}
if ( $is_preset ) {
    echo '      <button type="submit" class="button" name="pmcpc_action" value="restore_preset">' . esc_html__( 'Restore preset', 'product-mailer-campaigns' ) . '</button>';
}
echo '    </div>';
echo '  </details>';
echo '</div>';


        // Blog name (used in the preview replacements).
        $blogname = get_bloginfo( 'name' );

        // Sample body used for the live preview (also used for the initial server-rendered preview).
        $preview_body = implode(
            "",
            array(
                '<h2 style="margin:0 0 10px;font-size:20px;line-height:1.3;">New arrivals at {{site_name}}</h2>',
                '<p style="margin:0 0 14px;">A few freshly listed pieces we thought you might love.</p>',
                '<div style="margin:0 0 10px;font-size:12px;color:#6b7280;">Preview: example products block</div>',
                '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="width:100%;">',
                '  <tr>',
                '    <td style="padding:12px;border:1px solid #e5e7eb;border-radius:10px;">',
                '      <strong>Example product (preview)</strong><br />',
                '      <span style="color:#6b7280;">This is placeholder content for the preview only.</span><br />',
                '      <a href="#" style="display:inline-block;margin-top:10px;background:{{accent}};color:#fff;text-decoration:none;padding:10px 14px;border-radius:8px;">View item (example)</a>',
                '    </td>',
                '  </tr>',
                '</table>',
            )
        );

        echo '</form>';
        echo '  </div>'; // left

        // Preview (right column).
        echo '  <div class="pmcpc-et-right pmcpc-et-sticky">';
	        echo '    <div class="pmcpc-et-card">';
	        // Preview mode controls (CSS only). IMPORTANT: inputs must be direct children of the card so the sibling CSS selector works.
	        echo '      <input class="pmcpc-et-prevmode" type="radio" name="pmcpc_prev_mode" id="pmcpcPrevModeDesktop" checked="checked" />';
	        echo '      <input class="pmcpc-et-prevmode" type="radio" name="pmcpc_prev_mode" id="pmcpcPrevModeMobile" />';
	        echo "      <div class=\"pmcpc-et-row\" style=\"justify-content:space-between;align-items:center;margin:0 0 6px;\">";
			echo "        <div><h2 style=\"margin:0;\">" . esc_html__( 'Live preview', 'product-mailer-campaigns' ) . "</h2><p class=\"pmcpc-et-preview-meta\">" . esc_html__( 'Check spacing, logo scale, and button colour before saving.', 'product-mailer-campaigns' ) . "</p></div>";
	        echo "        <div class=\"pmcpc-et-row\" style=\"gap:6px;\">";
		echo '          <label class="pmcpc-et-prevbtn pmcpc-et-prevbtn--desktop" for="pmcpcPrevModeDesktop">' . esc_html__( 'Desktop', 'product-mailer-campaigns' ) . '</label>';
		echo '          <label class="pmcpc-et-prevbtn pmcpc-et-prevbtn--mobile" for="pmcpcPrevModeMobile">' . esc_html__( 'Mobile', 'product-mailer-campaigns' ) . '</label>';
	        echo "        </div>";
        echo "      </div>";
        echo '      <p class="description" style="margin:0 0 10px;">' . esc_html__( 'Preview updates automatically as you edit. Use Advanced mode when you need to edit the wrapper HTML directly.', 'product-mailer-campaigns' ) . '</p>';
	        echo '      <div class="pmcpc-et-preview-frame">';

        // Build an initial preview server-side so the user sees something even if inline JS is blocked.
        $accent0   = isset( $s['accent_color'] ) ? (string) $s['accent_color'] : '#1d4ed8';
        $tpl0      = isset( $s['header_html'] ) ? (string) $s['header_html'] : '';
        $logo_url0 = isset( $s['logo_url'] ) ? (string) $s['logo_url'] : '';
        $logo_html0 = $logo_url0
            ? '<img src="' . esc_url( $logo_url0 ) . '" alt="' . esc_attr( $blogname ) . '" style="max-width:180px;height:auto;display:block;" />'
            : esc_html( $blogname );

        // Products/reviews preview blocks (replace placeholders in preview only).
        $products_preview = implode(
            '',
            array(
                '<div style="margin:0 0 10px;font-size:12px;color:#6b7280;">Preview: products block placeholder</div>',
                '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="width:100%;">',
                '  <tr>',
                '    <td style="padding:12px;border:1px solid #e5e7eb;border-radius:10px;">',
                '      <strong>Example product (preview)</strong><br />',
                '      <span style="color:#6b7280;">This is placeholder content for the preview only.</span><br />',
                '      <a href="#" style="display:inline-block;margin-top:10px;background:{{accent}};color:#fff;text-decoration:none;padding:10px 14px;border-radius:8px;">View item (example)</a>',
                '    </td>',
                '  </tr>',
                '</table>'
            )
        );

        $reviews_preview = implode(
            '',
            array(
                '<div style="margin:16px 0 0;font-size:12px;color:#6b7280;">Preview: reviews block placeholder</div>',
                '<div style="border:1px solid #e5e7eb;border-radius:12px;padding:16px;background:#fafafa;margin-top:10px;">',
                '  <div style="margin:0 0 10px 0;font-size:16px;color:#111;letter-spacing:1px;">★★★★★</div>',
                '  <p style="margin:0 0 10px 0;color:#444;line-height:1.6;">“A beautiful and unusual piece — exactly the sort of find we hoped for.”</p>',
                '  <p style="margin:0;color:#6b7280;font-size:13px;">— Example customer</p>',
                '</div>'
            )
        );

        // Legacy support: if the template is still a wrapper (contains {pmcpc_body}), inject a preview body.
        $body0 = str_replace( array( '{{site_name}}', '{{accent}}' ), array( $blogname, $accent0 ), $preview_body );
        if ( $tpl0 && ( false !== strpos( $tpl0, '{pmcpc_body}' ) || false !== strpos( $tpl0, '{{pmcpc_body}}' ) ) ) {
            $out0 = str_replace( array( '{{pmcpc_body}}', '{pmcpc_body}' ), array( $body0, $body0 ), $tpl0 );
        } elseif ( $tpl0 ) {
            $out0 = $tpl0;
        } else {
            $out0 = '<div style="font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.6;color:#111827;padding:18px;">' . $body0 . '</div>';
        }

        // Preview replacements.
        // IMPORTANT: replace double-brace placeholders first. Otherwise "{products_block}" would match inside
        // "{{products_block}}" and leave stray braces in the output.
        $out0 = str_replace( array( '{{products_block}}', '{products_block}' ), array( $products_preview, $products_preview ), $out0 );
        $out0 = str_replace( array( '{{reviews_block}}', '{{reviews}}', '{reviews_block}' ), array( $reviews_preview, $reviews_preview, $reviews_preview ), $out0 );
        $out0 = str_replace(
            array( '{{accent}}', '{accent}', '{{site_name}}', '{{unsubscribe_url}}', '{{logo_html}}', '{{logo_url}}' ),
            array( $accent0, $accent0, $blogname, '#', $logo_html0, $logo_url0 ),
            $out0
        );

        $initial_doc = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body style="margin:0;padding:0;background:#f4f4f4;"><div style="padding:16px;display:flex;justify-content:center;"><div style="width:100%;max-width:640px;">' . $out0 . '</div></div></body></html>';

	        echo '<div class="pmcpc-et-preview-canvas">';
	        echo '<div id="pmcpcPreviewSizer">';
			echo '<iframe id="pmcpc_template_preview" title="' . esc_attr__( 'Email preview', 'product-mailer-campaigns' ) . '" style="width:100%;height:520px;border:0;display:block;margin:0 auto;border-radius:12px;background:#fff;box-shadow:0 12px 24px rgba(15,23,42,.12);" sandbox="allow-same-origin" srcdoc="' . esc_attr( $initial_doc ) . '"></iframe>';
			echo '</div>';
	        echo '</div>';
        echo '      </div>';
        echo '    </div>';
        echo '  </div>'; // right

        echo '</div>'; // grid


        echo '</div>';
    }

}
