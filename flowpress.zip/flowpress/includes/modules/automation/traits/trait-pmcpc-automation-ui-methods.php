<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * UI and admin helper methods for FlowPress automations.
 */
trait PMCPC_Automation_UI_Methods {

    /**
     * Trigger keys that depend on WooCommerce automation capability.
     *
     * @return array
     */
    protected function get_woo_trigger_keys() {
        return array(
            'new_customer',
            'repeat_customer',
            'post_purchase',
            'review_request',
            'customer_inactive',
            'high_value',
            'lapsed_high_value_customer',
            'vip_customer',
            'abandoned_cart',
            'abandoned_cart_step_1',
            'abandoned_cart_step_2',
            'abandoned_cart_step_3',
            'workflow_post_purchase_sequence',
            'workflow_customer_winback_sequence',
        );
    }

    /**
     * Canonical automation trigger aliases used across admin and simulation flows.
     *
     * @return array<string,array>
     */
    protected function get_trigger_alias_map() {
        return array(
            'new_subscriber'         => array( 'new_subscriber', 'welcome', 'new-subscriber', 'signup', 'signup_form', 'list_join', 'welcome_subscriber' ),
            'welcome_follow_up'      => array( 'welcome_follow_up', 'welcome-follow-up', 'subscriber_welcome_follow_up', 'subscriber_welcome_followup' ),
            'new_customer'           => array( 'new_customer', 'first_order', 'new-customer' ),
            'first_order'            => array( 'first_order', 'new_customer' ),
            'repeat_customer'        => array( 'repeat_customer', 'repeat', 'repeat_customer_2plus', 'repeat-customer' ),
            'review_request'         => array( 'review_request', 'review', 'review-request' ),
            'high_value'             => array( 'high_value', 'high-value', 'high_value_customer' ),
            'lapsed_high_value_customer' => array( 'lapsed_high_value_customer', 'lapsed-high-value-customer', 'lapsed_high_value', 'high_value_lapsed', 'lapsed_vip_offer' ),
            'vip_customer'           => array( 'vip_customer', 'vip', 'top_spenders', 'vip-customer' ),
            'customer_inactive'      => array( 'customer_inactive', 'inactive', 'win_back_automation', 'winback', 'win_back', 'customer-inactive', 'inactive_customers' ),
            'post_purchase'          => array( 'post_purchase', 'post-purchase' ),
            'lead_magnet_download'   => array( 'lead_magnet_download', 'lead_magnet_delivery', 'lead-magnet-download', 'lead-magnet-delivery' ),
            'subscriber_inactive'    => array( 'subscriber_inactive', 'subscriber-inactive' ),
            'subscriber_anniversary' => array( 'subscriber_anniversary', 'anniversary', 'subscriber-anniversary' ),
            'subscriber_birthday'    => array( 'subscriber_birthday', 'birthday', 'subscriber-birthday' ),
            'abandoned_cart'         => array( 'abandoned_cart', 'abandoned-cart', 'abandoned_cart_step_1', 'abandoned_cart_step_2', 'abandoned_cart_step_3', 'abandoned-cart-step-1', 'abandoned-cart-step-2', 'abandoned-cart-step-3' ),
            'abandoned_cart_step_1'  => array( 'abandoned_cart_step_1', 'abandoned_cart', 'abandoned-cart-step-1' ),
            'abandoned_cart_step_2'  => array( 'abandoned_cart_step_2', 'abandoned-cart-step-2' ),
            'abandoned_cart_step_3'  => array( 'abandoned_cart_step_3', 'abandoned-cart-step-3' ),
            'workflow_welcome_series' => array( 'new_subscriber', 'welcome', 'new-subscriber', 'signup', 'signup_form', 'list_join', 'welcome_subscriber' ),
            'workflow_post_purchase_sequence' => array( 'post_purchase', 'post-purchase' ),
            'workflow_customer_winback_sequence' => array( 'customer_inactive', 'inactive', 'win_back_automation', 'winback', 'win_back', 'customer-inactive', 'inactive_customers' ),
        );
    }

    /**
     * Get sanitized aliases for a trigger key.
     *
     * @param string $trigger Trigger key.
     * @return array
     */
    protected function get_trigger_aliases( $trigger ) {
        $trigger = sanitize_key( (string) $trigger );
        if ( '' === $trigger ) {
            return array();
        }

        $trigger_aliases = $this->get_trigger_alias_map();
        $aliases         = isset( $trigger_aliases[ $trigger ] ) ? $trigger_aliases[ $trigger ] : array( $trigger );

        return array_values( array_unique( array_filter( array_map( 'sanitize_key', $aliases ) ) ) );
    }

    /**
     * Default email wrapper HTML (Pro).
     *
     * Uses {pmcpc_body} as the insertion point for campaign content.
     *
     * @return string
     */
    protected function get_default_wrapper_html() {
        // Intentionally minimal + email-client-safe.
        return implode(
            "",
            array(
                '<!-- FULL WRAPPER (uses {pmcpc_body}) -->',
                '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f4f4f4;margin:0;padding:0;">',
                '  <tr>',
                '    <td align="center" style="padding:24px 12px;">',
                '      <!-- Preheader (hidden) -->',
                '      <div style="display:none;font-size:1px;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;color:transparent;">',
                '        New finds from {{site_name}}.&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;',
                '      </div>',
                '      <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;">',
                '        <tr>',
                '          <td align="center" style="padding:22px 20px 12px 20px;">',
                '            <div style="font-family:Arial,Helvetica,sans-serif;font-size:18px;line-height:1.3;color:#111;font-weight:700;">{{logo_html}}</div>',
                '          </td>',
                '        </tr>',
                '        <tr><td style="padding:0 20px;"><div style="height:1px;background:#e5e7eb;line-height:1px;font-size:1px;">&nbsp;</div></td></tr>',
                '        <tr>',
                '          <td style="padding:18px 20px 10px 20px;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.6;color:#222;">',
                '            {pmcpc_body}',
                '          </td>',
                '        </tr>',
                '      </table>',
                '    </td>',
                '  </tr>',
                '</table>',
            )
        );
    }

    /**
     * Render a combined Automations table (Triggers + Store opportunities).
     *
     * @param array $triggers Each item: key,label,when,common_use,action_label,create_url
     * @param array $opportunities Map keyed by trigger key.
     *                            Supports either:
     *                            - Legacy: [ 'count' => int, 'note' => string ]
     *                            - Multi-badge: [ 'badges' => [ [ 'count' => int, 'label' => string, 'note' => string ], ... ] ]
     */
    protected function render_automation_ideas_table( array $triggers, array $opportunities = array() ) {
        // Normalise and merge opportunity info.
        $rows = array();
        foreach ( $triggers as $t ) {
            if ( empty( $t['key'] ) ) {
                continue;
            }
            $key  = (string) $t['key'];
            $opp  = isset( $opportunities[ $key ] ) && is_array( $opportunities[ $key ] ) ? $opportunities[ $key ] : array();

            // Normalize to a list of badges.
            $badges = array();
            if ( isset( $opp['badges'] ) && is_array( $opp['badges'] ) ) {
                foreach ( $opp['badges'] as $b ) {
                    if ( ! is_array( $b ) ) {
                        continue;
                    }
                    $c = isset( $b['count'] ) ? (int) $b['count'] : 0;
                    if ( $c <= 0 ) {
                        continue;
                    }
                    $badges[] = array(
                        'count' => $c,
                        'label' => isset( $b['label'] ) ? (string) $b['label'] : '',
                        'note'  => isset( $b['note'] ) ? (string) $b['note'] : '',
                    );
                }
            } elseif ( isset( $opp['count'] ) && (int) $opp['count'] > 0 ) {
                // Legacy single badge.
                $badges[] = array(
                    'count' => (int) $opp['count'],
                    'label' => '',
                    'note'  => isset( $opp['note'] ) ? (string) $opp['note'] : '',
                );
            }

            // For search and display convenience.
            $t['_opp_badges'] = $badges;
            $t['_opp_count']  = 0;
            $t['_opp_note']   = '';
            if ( ! empty( $badges ) ) {
                $t['_opp_count'] = array_sum( array_map( function( $b ) { return (int) ( $b['count'] ?? 0 ); }, $badges ) );

                // Compact summary line: "36 Lapsed (60d+) · 5 VIP lapsed".
                $parts = array();
                foreach ( $badges as $b ) {
                    $bc = (int) ( $b['count'] ?? 0 );
                    if ( $bc <= 0 ) {
                        continue;
                    }
                    $bl = trim( (string) ( $b['label'] ?? '' ) );
                    $parts[] = $bl ? ( $bc . ' ' . $bl ) : (string) $bc;
                }
                $t['_opp_note'] = implode( ' · ', $parts );
            }

            $t['_recommended']  = ( ! empty( $badges ) );
            $rows[] = $t;
        }

        // Recommended first, then by total opportunity count (desc), then by label.
        usort(
            $rows,
            function ( $a, $b ) {
                $ra = ! empty( $a['_recommended'] ) ? 1 : 0;
                $rb = ! empty( $b['_recommended'] ) ? 1 : 0;
                if ( $ra !== $rb ) {
                    return $rb <=> $ra;
                }
                $ca = (int) ( $a['_opp_count'] ?? 0 );
                $cb = (int) ( $b['_opp_count'] ?? 0 );
                if ( $ca !== $cb ) {
                    return $cb <=> $ca;
                }
                $prio = array(
                    'workflow_welcome_series' => 1,
                    'new_subscriber'    => 2,
                    'welcome_follow_up' => 3,
                    'new_customer'      => 4,
                    'workflow_post_purchase_sequence' => 5,
                    'post_purchase'     => 6,
                    'review_request'    => 5,
                    'repeat_customer'   => 6,
                    'customer_inactive' => 7,
                    'workflow_customer_winback_sequence' => 8,
                    'abandoned_cart'    => 9,
                    'high_value'        => 9,
                    'lapsed_high_value_customer' => 10,
                    'lead_magnet_download' => 11,
                    'subscriber_inactive'  => 11,
                    'subscriber_anniversary' => 12,
                    'subscriber_birthday' => 13,
                    'date'              => 99,
                );
                $pa = (int) ( $prio[ (string) ( $a['key'] ?? '' ) ] ?? 50 );
                $pb = (int) ( $prio[ (string) ( $b['key'] ?? '' ) ] ?? 50 );
                if ( $pa !== $pb ) {
                    return $pa <=> $pb;
                }
                return strcasecmp( (string) ( $a['label'] ?? '' ), (string) ( $b['label'] ?? '' ) );
            }
        );

        echo '<div class="pmcpc-automation-controls" style="display:flex; gap:12px; align-items:center; margin: 14px 0; flex-wrap:wrap;">';
        echo '  <div class="button-group" role="tablist" aria-label="Automation scope">';
        echo '    <button type="button" class="button button-primary" data-pmcpc-scope="all">' . esc_html__( 'All', 'product-mailer-campaigns' ) . '</button>';
        echo '    <button type="button" class="button" data-pmcpc-scope="core">' . esc_html__( 'Core', 'product-mailer-campaigns' ) . '</button>';
        echo '    <button type="button" class="button" data-pmcpc-scope="woocommerce">' . esc_html__( 'WooCommerce', 'product-mailer-campaigns' ) . '</button>';
        echo '  </div>';
        echo '  <input type="search" class="regular-text" placeholder="' . esc_attr__( 'Search triggers…', 'product-mailer-campaigns' ) . '" aria-label="' . esc_attr__( 'Search triggers', 'product-mailer-campaigns' ) . '" data-pmcpc-search style="max-width: 320px;" />';
        echo '  <span class="description" data-pmcpc-count style="margin-left:auto;"></span>';
        echo '</div>';
        echo '<style>.pmcpc-automation-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.pmcpc-automation-table .pmcpc-automation-trigger{min-width:220px}.pmcpc-automation-table td{vertical-align:top}.pmcpc-trigger-stack-note{display:block;margin-top:4px;color:#646970;font-size:12px;line-height:1.35}.pmcpc-trigger-stack-ok{color:#008a20}</style>';

        echo '<div class="pmcpc-table-card pmcpc-automation-table-card"><div class="pmcpc-managed-table-scroll pmcpc-automation-table-scroll">';
        echo '<table class="widefat striped pmcpc-automation-table" data-pmcpc-table style="width:100%;">';
        echo '<thead><tr>';
        echo '<th style="width: 22%;">' . esc_html__( 'Trigger', 'product-mailer-campaigns' ) . '</th>';
        echo '<th style="width: 12%;">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
        echo '<th style="width: 28%;">' . esc_html__( 'When it fires', 'product-mailer-campaigns' ) . '</th>';
        echo '<th style="width: 28%;">' . esc_html__( 'Common use', 'product-mailer-campaigns' ) . '</th>';
        echo '<th style="width: 10%;">' . esc_html__( 'Action', 'product-mailer-campaigns' ) . '</th>';
        echo '</tr></thead><tbody>';

        $core_trigger_keys = array( 'workflow_welcome_series', 'new_subscriber', 'welcome_follow_up', 'subscriber_inactive', 'subscriber_anniversary', 'subscriber_birthday', 'lead_magnet_download', 'date' );
        $woo_trigger_keys  = array( 'workflow_post_purchase_sequence', 'workflow_customer_winback_sequence', 'new_customer', 'repeat_customer', 'post_purchase', 'review_request', 'customer_inactive', 'high_value', 'lapsed_high_value_customer', 'vip_customer', 'abandoned_cart', 'abandoned_cart_step_1', 'abandoned_cart_step_2', 'abandoned_cart_step_3' );

        foreach ( $rows as $r ) {
            $key   = (string) ( $r['key'] ?? '' );
            $label = (string) ( $r['label'] ?? '' );
            $when  = (string) ( $r['when'] ?? '' );
            $use   = (string) ( $r['common_use'] ?? '' );
            $url   = (string) ( $r['create_url'] ?? '' );
            $btn   = (string) ( $r['action_label'] ?? __( 'Set up', 'product-mailer-campaigns' ) );
            $existing_id = 0;
            if ( ! empty( $r['workflow_key'] ) ) {
                $ui_state = $this->get_step_workflow_ui_state( (string) $r['workflow_key'], absint( $r['workflow_steps'] ?? 1 ), $btn );
            } else {
                $existing_id = $this->get_latest_campaign_id_for_trigger( $key );
                $ui_state    = $this->get_trigger_ui_state( $key, $existing_id );
            }
            if ( 'abandoned_cart' === $key || ! empty( $r['workflow_key'] ) ) {
                $existing_id = ! empty( $ui_state['latest_id'] ) ? (int) $ui_state['latest_id'] : 0;
            } elseif ( ! empty( $ui_state['latest_id'] ) ) {
                $existing_id = (int) $ui_state['latest_id'];
            }
            $btn         = $ui_state['action_label'];
            if ( isset( $ui_state['status'] ) && 'not_created' === (string) $ui_state['status'] ) {
                $btn = __( 'Activate', 'product-mailer-campaigns' );
            }

            $rec     = ! empty( $r['_recommended'] );
            $note    = (string) ( $r['_opp_note'] ?? '' );
            $badges  = isset( $r['_opp_badges'] ) && is_array( $r['_opp_badges'] ) ? $r['_opp_badges'] : array();

            $badge_hay = '';
            if ( ! empty( $badges ) ) {
                foreach ( $badges as $b ) {
                    $badge_hay .= ' ' . (string) ( $b['label'] ?? '' ) . ' ' . (string) ( $b['note'] ?? '' );
                }
            }
            $schedule_hint = ( 'date' === $key ) ? ' scheduled not automation' : '';
            $haystack = strtolower( trim( $label . $schedule_hint . ' ' . $when . ' ' . $use . ' ' . $note . ' ' . $badge_hay ) );

            $row_style = ( 'date' === $key ) ? ' style="opacity:0.92;"' : '';
            $scope = ! empty( $r['scope'] ) ? sanitize_key( (string) $r['scope'] ) : ( in_array( $key, $woo_trigger_keys, true ) ? 'woocommerce' : ( in_array( $key, $core_trigger_keys, true ) ? 'core' : 'all' ) );
            $is_step_workflow_row = ( 'abandoned_cart' === $key || ! empty( $r['workflow_key'] ) );
            $workflow_key_for_row = ! empty( $r['workflow_key'] ) ? sanitize_key( (string) $r['workflow_key'] ) : ( 'abandoned_cart' === $key ? 'abandoned_cart' : '' );
            $workflow_expected_steps = ( 'abandoned_cart' === $key ) ? 3 : max( 1, absint( $r['workflow_steps'] ?? 1 ) );
            $workflow_group_id = ( $is_step_workflow_row && $workflow_key_for_row ) ? 'auto_workflow_' . substr( md5( $workflow_key_for_row ), 0, 12 ) : '';
            $workflow_parent_attr = $workflow_group_id ? ' data-pmcpc-auto-acc-parent="' . esc_attr( $workflow_group_id ) . '"' : '';
            $actual_trigger_key = ! empty( $r['automation_trigger'] ) ? sanitize_key( (string) $r['automation_trigger'] ) : $key;
            if ( 0 === strpos( $key, 'workflow_' ) && empty( $r['automation_trigger'] ) ) {
                $actual_trigger_key = $this->get_workflow_underlying_trigger_key( $workflow_key_for_row );
            }
            $stack_info = $this->get_trigger_stack_info( $actual_trigger_key );
            echo '<tr data-pmcpc-row data-pmcpc-scope="' . esc_attr( $scope ) . '" data-pmcpc-recommended="' . ( $rec ? '1' : '0' ) . '" data-pmcpc-key="' . esc_attr( $key ) . '" data-pmcpc-searchtext="' . esc_attr( $haystack ) . '"' . $workflow_parent_attr . $row_style . '>';

            echo '<td><div class="pmcpc-automation-trigger"><span class="pmcpc-automation-trigger__icon" aria-hidden="true">' . esc_html( $this->get_trigger_icon( $key ) ) . '</span><div><strong>' . esc_html( $label ) . '</strong>';
            if ( 'date' === $key ) {
                echo ' <span class="pmcpc-badge" style="display:inline-flex; align-items:center; padding:1px 7px; border-radius:999px; background:#f0f0f1; line-height:1.4;">';
                echo '<span class="description" style="margin:0;">' . esc_html__( 'Scheduled (not an automation)', 'product-mailer-campaigns' ) . '</span>';
                echo '</span>';
            } elseif ( 'abandoned_cart' === $key ) {
                echo ' <span class="pmcpc-badge" style="display:inline-flex; align-items:center; padding:1px 7px; border-radius:999px; background:#f0f0f1; line-height:1.4;">';
                echo '<span class="description" style="margin:0;">' . esc_html__( '3-step workflow', 'product-mailer-campaigns' ) . '</span>';
                echo '</span>';
            } elseif ( ! empty( $r['workflow_steps'] ) ) {
                $workflow_steps = max( 1, absint( $r['workflow_steps'] ) );
                echo ' <span class="pmcpc-badge" style="display:inline-flex; align-items:center; padding:1px 7px; border-radius:999px; background:#f0f0f1; line-height:1.4;">';
                echo '<span class="description" style="margin:0;">' . esc_html( sprintf( _n( '%d-step workflow', '%d-step workflow', $workflow_steps, 'product-mailer-campaigns' ), $workflow_steps ) ) . '</span>';
                echo '</span>';
            }
            echo '</div></div></td>';
            $status = $this->get_trigger_status_badge( $key, $rec, $badges, $ui_state );
            echo '<td>' . $status;
            if ( ! empty( $stack_info['active_count'] ) && (int) $stack_info['active_count'] > 1 ) {
                echo '<span class="pmcpc-trigger-stack-note pmcpc-trigger-stack-ok">' . esc_html( sprintf( _n( '%d active email uses this trigger — all will queue.', '%d active emails use this trigger — all will queue.', (int) $stack_info['active_count'], 'product-mailer-campaigns' ), (int) $stack_info['active_count'] ) ) . '</span>';
            } elseif ( ! empty( $stack_info['active_count'] ) && (int) $stack_info['active_count'] === 1 ) {
                echo '<span class="pmcpc-trigger-stack-note">' . esc_html__( 'This trigger has 1 active email.', 'product-mailer-campaigns' ) . '</span>';
            }
            echo '</td>';
            echo '<td>' . esc_html( $when ) . '</td>';
            echo '<td>' . esc_html( $use ) . '</td>';
            echo '<td><div class="pmcpc-automation-actions">';
            $is_woo = in_array( $key, $this->get_woo_trigger_keys(), true ) || ( ! empty( $r['scope'] ) && 'woocommerce' === sanitize_key( (string) $r['scope'] ) );
            $woo_locked = $is_woo && class_exists( 'WooCommerce' ) && function_exists( 'pmcpc_wc_automation_enabled' ) && ! pmcpc_wc_automation_enabled();

            if ( $woo_locked ) {
                $trial_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );
                $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
                echo '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
                echo '<a class="button button-primary" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Start free trial', 'product-mailer-campaigns' ) . '</a>';
                echo '<a class="button" href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Activate license', 'product-mailer-campaigns' ) . '</a>';
                echo '</div>';
            } elseif ( 'date' === $key && ! empty( $ui_state['status'] ) && 'scheduled' === $ui_state['status'] ) {
                $view_url = admin_url( 'admin.php?page=pmcpc_campaigns' );
                echo '<a class="button button-secondary button-small" href="' . esc_url( $view_url ) . '">' . esc_html__( 'View schedules', 'product-mailer-campaigns' ) . '</a>';
            } elseif ( $existing_id > 0 ) {
                $edit_url = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . (int) $existing_id );
                if ( $is_step_workflow_row ) {
                    $campaigns_group_id = ( 'abandoned_cart' === $key ) ? 'abandoned_cart' : 'workflow_' . substr( md5( $workflow_key_for_row ), 0, 12 );
                    $edit_url           = admin_url( 'admin.php?page=pmcpc_campaigns&pmcpc_open_acc=' . rawurlencode( $campaigns_group_id ) );
                }
                echo '<a class="button button-secondary button-small" href="' . esc_url( $edit_url ) . '">' . esc_html__( 'Edit in Campaigns', 'product-mailer-campaigns' ) . '</a>';
            } elseif ( $url ) {
                if ( 'abandoned_cart' === $key || ! empty( $r['workflow_key'] ) ) {
                    echo '<a class="button button-primary button-small" href="' . esc_url( $url ) . '">' . esc_html( $btn ) . '</a>';
                } else {
                    $this->render_create_campaign_with_template_picker( $url, $btn );
                }
            } else {
                echo '<span class="description">—</span>';
            }
            echo '</div></td>';
            echo '</tr>';
        }

        echo '</tbody></table></div></div>';

        // Small JS for filter + search (kept inline to avoid asset management overhead).
        ?>
        <script>
        (function(){
          var table = document.querySelector('[data-pmcpc-table]');
          if (!table) return;
          var rows = Array.prototype.slice.call(table.querySelectorAll('[data-pmcpc-row]'));
          var btnAll = document.querySelector('[data-pmcpc-scope="all"]');
          var btnCore = document.querySelector('[data-pmcpc-scope="core"]');
          var btnWoo = document.querySelector('[data-pmcpc-scope="woocommerce"]');
          var search = document.querySelector('[data-pmcpc-search]');
          var countEl = document.querySelector('[data-pmcpc-count]');
          var scope = 'all';
          var q = '';
          var focusKey = '';
          try {
            var params = new URLSearchParams(window.location.search || '');
            focusKey = (params.get('focus') || '').trim();
            var paramScope = (params.get('scope') || '').trim();
            if (paramScope) scope = paramScope;
          } catch(e) {}
          if (focusKey) { scope = 'all'; }

          function setScope(next){
            scope = next || 'all';
            try {
              var url = new URL(window.location.href);
              if (scope && scope !== 'all') url.searchParams.set('scope', scope);
              else url.searchParams.delete('scope');
              window.history.replaceState({}, '', url.toString());
            } catch(e) {}
            apply();
          }

          function apply(){
            var query = (q || '').trim().toLowerCase();
            var visible = 0;
            rows.forEach(function(tr){
              var rowScope = tr.getAttribute('data-pmcpc-scope') || 'all';
              var text = tr.getAttribute('data-pmcpc-searchtext') || '';
              var passScope = (scope === 'all') ? true : (rowScope === scope);
              var passSearch = query ? (text.indexOf(query) !== -1) : true;
              var passFocus = focusKey ? (tr.getAttribute('data-pmcpc-key') === focusKey) : true;
              var show = passScope && passSearch && passFocus;
              tr.style.display = show ? '' : 'none';
              if (show) visible++;
            });
            if (countEl) countEl.textContent = visible + ' <?php echo esc_js( __( 'shown', 'product-mailer-campaigns' ) ); ?>';

            if (btnAll) btnAll.classList.toggle('button-primary', scope === 'all');
            if (btnCore) btnCore.classList.toggle('button-primary', scope === 'core');
            if (btnWoo) btnWoo.classList.toggle('button-primary', scope === 'woocommerce');
          }

          if (btnAll) btnAll.addEventListener('click', function(){ setScope('all'); });
          if (btnCore) btnCore.addEventListener('click', function(){ setScope('core'); });
          if (btnWoo) btnWoo.addEventListener('click', function(){ setScope('woocommerce'); });
          if (search) search.addEventListener('input', function(e){ q = e.target.value || ''; apply(); });

          apply();
          if (focusKey) {
            var row = table.querySelector('[data-pmcpc-row][data-pmcpc-key="' + focusKey.replace(/"/g,'') + '"]');
            if (row) {
              row.style.outline = '2px solid #2271b1';
              row.style.outlineOffset = '2px';
              row.scrollIntoView({behavior:'smooth', block:'center'});
            }
          }
        })();
        </script>
        <?php
    }

        /**
     * Render an "Active / Not active / Needs data" badge for a trigger row.
     *
     * @param string $trigger
     * @param bool   $recommended
     * @param array  $badges
     * @return string HTML
     */
    /**
     * Format a workflow delay in minutes for compact admin tables.
     *
     * @param int $delay_minutes Delay in minutes.
     * @return string
     */
    /**
     * Resolve a grouped workflow key to the real trigger shared by its steps.
     *
     * @param string $workflow_key
     * @return string
     */
    protected function get_workflow_underlying_trigger_key( $workflow_key ) {
        $workflow_key = sanitize_key( (string) $workflow_key );
        $map = array(
            'welcome_series'            => 'new_subscriber',
            'post_purchase_sequence'    => 'post_purchase',
            'customer_winback_sequence' => 'customer_inactive',
        );
        return isset( $map[ $workflow_key ] ) ? $map[ $workflow_key ] : $workflow_key;
    }

    /**
     * Count active campaign emails that share the same automation trigger.
     * This confirms that single automations and step workflows using the same
     * trigger are additive: when the trigger fires, every active matching email
     * is queued, subject to its own audience/delay settings.
     *
     * @param string $trigger_key
     * @return array{active_count:int}
     */
    protected function get_trigger_stack_info( $trigger_key ) {
        global $wpdb;

        $trigger_key = sanitize_key( (string) $trigger_key );
        if ( '' === $trigger_key || 'date' === $trigger_key || ! isset( $wpdb ) || ! $wpdb instanceof wpdb ) {
            return array( 'active_count' => 0 );
        }

        $table = $wpdb->prefix . 'pmcpc_campaigns';

        if ( 'abandoned_cart' === $trigger_key ) {
            // Built-in abandoned cart is displayed as one workflow, but stored as three step triggers.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $count = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$table} WHERE automation_trigger IN (%s,%s,%s) AND status = %s",
                    'abandoned_cart_step_1',
                    'abandoned_cart_step_2',
                    'abandoned_cart_step_3',
                    'active'
                )
            );
            return array( 'active_count' => max( 0, $count ) );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $count = (int) $wpdb->get_var(
            $wpdb->prepare(
                'SELECT COUNT(*) FROM %i WHERE automation_trigger = %s AND status = %s',
                $table,
                $trigger_key,
                'active'
            )
        );

        return array( 'active_count' => max( 0, $count ) );
    }

    protected function format_automation_workflow_delay_label( $delay_minutes ) {
        $delay_minutes = max( 0, (int) $delay_minutes );
        if ( $delay_minutes <= 0 ) {
            return __( 'Immediately', 'product-mailer-campaigns' );
        }
        if ( 0 === ( $delay_minutes % 1440 ) ) {
            $days = (int) ( $delay_minutes / 1440 );
            return sprintf( _n( '%d day', '%d days', $days, 'product-mailer-campaigns' ), $days );
        }
        if ( $delay_minutes >= 60 && 0 === ( $delay_minutes % 60 ) ) {
            $hours = (int) ( $delay_minutes / 60 );
            return sprintf( _n( '%d hour', '%d hours', $hours, 'product-mailer-campaigns' ), $hours );
        }

        return sprintf( _n( '%d minute', '%d minutes', $delay_minutes, 'product-mailer-campaigns' ), $delay_minutes );
    }

    /**
     * Load editable step rows for a grouped workflow on the Automations page.
     *
     * @param string $workflow_key Workflow key, or abandoned_cart.
     * @param bool   $abandoned Whether this is the built-in abandoned cart workflow.
     * @return array<int,object>
     */
    protected function get_automation_workflow_step_rows( $workflow_key, $abandoned = false ) {
        global $wpdb;

        if ( ! isset( $wpdb ) || ! $wpdb instanceof wpdb ) {
            return array();
        }

        $table = $wpdb->prefix . 'pmcpc_campaigns';
        $steps = array();

        if ( $abandoned ) {
            foreach ( array( 1, 2, 3 ) as $step ) {
                $trigger = 'abandoned_cart_step_' . $step;
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $row = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT id, name, subject, status, automation_trigger, trigger_delay_minutes, created_at, updated_at
                         FROM {$table}
                         WHERE automation_trigger = %s
                         ORDER BY updated_at DESC, id DESC
                         LIMIT 1",
                        $trigger
                    )
                );
                if ( $row && ! empty( $row->id ) ) {
                    $row->workflow_step = $step;
                    $steps[ $step ] = $row;
                }
            }

            return $steps;
        }

        $workflow_key = sanitize_key( (string) $workflow_key );
        if ( '' === $workflow_key ) {
            return array();
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $has_column = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", 'workflow_key' ) );
        if ( empty( $has_column ) ) {
            return array();
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, name, subject, status, automation_trigger, trigger_delay_minutes, workflow_step, created_at, updated_at
                 FROM {$table}
                 WHERE workflow_key = %s
                   AND workflow_step > 0
                   AND status IN ('active','scheduled','queued','draft','needs_data','paused','inactive','disabled')
                 ORDER BY workflow_step ASC, id ASC",
                $workflow_key
            )
        );

        if ( empty( $rows ) || ! is_array( $rows ) ) {
            return array();
        }

        foreach ( $rows as $row ) {
            $step = isset( $row->workflow_step ) ? absint( $row->workflow_step ) : 0;
            if ( $step <= 0 ) {
                $step = count( $steps ) + 1;
            }
            $steps[ $step ] = $row;
        }

        return $steps;
    }

    /**
     * Render the expandable child step row beneath a grouped workflow.
     *
     * @param string $group_id       UI group identifier.
     * @param string $workflow_key   Workflow key.
     * @param int    $expected_steps Expected step count.
     * @param bool   $abandoned      Whether this is abandoned cart.
     * @return void
     */
    protected function render_automation_workflow_steps_row( $group_id, $workflow_key, $expected_steps, $abandoned = false ) {
        $group_id       = sanitize_key( (string) $group_id );
        $expected_steps = max( 1, absint( $expected_steps ) );
        $steps          = $this->get_automation_workflow_step_rows( $workflow_key, $abandoned );

        if ( empty( $steps ) ) {
            return;
        }

        $max_step = $expected_steps;
        foreach ( array_keys( $steps ) as $step_no ) {
            $max_step = max( $max_step, absint( $step_no ) );
        }

        echo '<tr class="pmcpc-auto-workflow-detail-row" data-pmcpc-auto-acc-row="' . esc_attr( $group_id ) . '" style="display:none;background:#fff;">';
        echo '<td colspan="6" style="padding:14px 16px;">';
        echo '<div class="pmcpc-auto-workflow-detail">';
        echo '<p class="description" style="margin:0 0 10px 0;">' . esc_html__( 'Each step remains a separate editable email. Open a step below to change its subject, content, delay, or status.', 'product-mailer-campaigns' ) . '</p>';
        echo '<table class="widefat striped pmcpc-auto-workflow-steps" style="margin:0;min-width:760px;">';
        echo '<thead><tr>';
        echo '<th style="width:90px;">' . esc_html__( 'Step', 'product-mailer-campaigns' ) . '</th>';
        echo '<th style="width:110px;">' . esc_html__( 'Delay', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Email', 'product-mailer-campaigns' ) . '</th>';
        echo '<th style="width:110px;">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
        echo '<th style="width:230px;">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
        echo '</tr></thead><tbody>';

        for ( $i = 1; $i <= $max_step; $i++ ) {
            if ( empty( $steps[ $i ] ) ) {
                echo '<tr>';
                echo '<td><strong>' . esc_html( sprintf( __( 'Step %d', 'product-mailer-campaigns' ), $i ) ) . '</strong></td>';
                echo '<td>—</td>';
                echo '<td><span class="description">' . esc_html__( 'Step email not found', 'product-mailer-campaigns' ) . '</span></td>';
                echo '<td><span class="pmcpc-status-pill pmcpc-status-pill--inactive"><span>' . esc_html__( 'Missing', 'product-mailer-campaigns' ) . '</span></span></td>';
                echo '<td>—</td>';
                echo '</tr>';
                continue;
            }

            $row           = $steps[ $i ];
            $campaign_id   = ! empty( $row->id ) ? (int) $row->id : 0;
            $edit_url      = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . $campaign_id );
            $preview_url   = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . $campaign_id . '&pmcpc_preview=1' );
            $send_test_url = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_send_test_email&campaign_id=' . $campaign_id ), 'pmcpc_send_test_email_' . $campaign_id );

            $delay_minutes = isset( $row->trigger_delay_minutes ) ? absint( $row->trigger_delay_minutes ) : 0;
            if ( $abandoned && $delay_minutes <= 0 && class_exists( 'PMCPC_Abandoned_Carts' ) ) {
                $delay_minutes = (int) PMCPC_Abandoned_Carts::get_recovery_delay_minutes_for_step( $i );
            }

            $status = isset( $row->status ) ? sanitize_key( (string) $row->status ) : '';
            $active = in_array( $status, array( 'active', 'scheduled', 'queued' ), true );
            $status_class = $active ? 'pmcpc-status-pill pmcpc-status-pill--active' : 'pmcpc-status-pill pmcpc-status-pill--inactive';
            $status_label = $active ? __( 'Active', 'product-mailer-campaigns' ) : __( 'Inactive', 'product-mailer-campaigns' );

            echo '<tr>';
            echo '<td><strong>' . esc_html( sprintf( __( 'Step %d', 'product-mailer-campaigns' ), $i ) ) . '</strong><br><span class="description">#' . esc_html( $campaign_id ) . '</span></td>';
            echo '<td>' . esc_html( $this->format_automation_workflow_delay_label( $delay_minutes ) ) . '</td>';
            echo '<td><a href="' . esc_url( $edit_url ) . '"><strong>' . esc_html( ! empty( $row->subject ) ? (string) $row->subject : (string) $row->name ) . '</strong></a><br><span class="description">' . esc_html( ! empty( $row->name ) ? (string) $row->name : __( 'Workflow email', 'product-mailer-campaigns' ) ) . '</span></td>';
            echo '<td><span class="' . esc_attr( $status_class ) . '"><span>' . esc_html( $status_label ) . '</span></span></td>';
            echo '<td><div style="display:flex;gap:8px;flex-wrap:wrap;">';
            echo '<a href="' . esc_url( $edit_url ) . '">' . esc_html__( 'Edit', 'product-mailer-campaigns' ) . '</a>';
            echo '<a href="' . esc_url( $preview_url ) . '">' . esc_html__( 'View email', 'product-mailer-campaigns' ) . '</a>';
            echo '<a href="' . esc_url( $send_test_url ) . '">' . esc_html__( 'Send test', 'product-mailer-campaigns' ) . '</a>';
            echo '</div></td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
        echo '</td>';
        echo '</tr>';
    }

    protected function get_trigger_icon( $trigger ) {
        $icons = array(
            'high_value'            => '💎',
            'lapsed_high_value_customer' => '🏆',
            'post_purchase'         => '📦',
            'review_request'        => '⭐',
            'repeat_customer'       => '🔁',
            'new_customer'          => '👋',
            'new_subscriber'        => '✉️',
            'welcome_follow_up'     => '💌',
            'subscriber_inactive'   => '💤',
            'subscriber_anniversary'=> '🎉',
            'subscriber_birthday'   => '🎂',
            'lead_magnet_download'  => '📩',
            'customer_inactive'     => '⏳',
            'workflow_welcome_series' => '📨',
            'workflow_post_purchase_sequence' => '📦',
            'workflow_customer_winback_sequence' => '⏳',
            'abandoned_cart'        => '🛒',
            'abandoned_cart_step_1' => '🛒',
            'abandoned_cart_step_2' => '🛒',
            'abandoned_cart_step_3' => '🛒',
            'date'                  => '🗓️',
        );

        return isset( $icons[ $trigger ] ) ? $icons[ $trigger ] : '⚡';
    }

    protected function get_trigger_status_badge( $trigger, $recommended, $badges, $ui_state = null ) {
        $trigger = (string) $trigger;
        unset( $recommended, $badges );

        $woo_triggers = $this->get_woo_trigger_keys();
        if ( in_array( $trigger, $woo_triggers, true ) && ! class_exists( 'WooCommerce' ) ) {
            return '<span class="pmcpc-status-pill pmcpc-status-pill--inactive"><span>' . esc_html__( 'Needs WooCommerce', 'product-mailer-campaigns' ) . '</span></span>';
        }

        if ( in_array( $trigger, $woo_triggers, true ) && class_exists( 'WooCommerce' ) && function_exists( 'pmcpc_wc_automation_enabled' ) && ! pmcpc_wc_automation_enabled() ) {
            return '<span class="pmcpc-status-pill pmcpc-status-pill--locked"><span>' . esc_html__( 'Locked', 'product-mailer-campaigns' ) . '</span></span>';
        }

        if ( ! is_array( $ui_state ) ) {
            $ui_state = $this->get_trigger_ui_state( $trigger, $this->get_latest_campaign_id_for_trigger( $trigger ) );
        }
        if ( 'date' === $trigger && isset( $ui_state['status'] ) && in_array( $ui_state['status'], array( 'active', 'scheduled' ), true ) ) {
            $count = isset( $ui_state['count'] ) ? (int) $ui_state['count'] : $this->count_campaigns_for_trigger( 'date', 'any' );
            $ui_state['label'] = $count > 1
                ? sprintf( __( 'Scheduled (%d)', 'product-mailer-campaigns' ), $count )
                : __( 'Scheduled', 'product-mailer-campaigns' );
            if ( empty( $ui_state['status'] ) || 'active' === $ui_state['status'] ) {
                $ui_state['status'] = 'scheduled';
            }
        }
        $status = isset( $ui_state['status'] ) ? (string) $ui_state['status'] : 'not_created';
        $label  = isset( $ui_state['label'] ) ? (string) $ui_state['label'] : __( 'Not created', 'product-mailer-campaigns' );

        $class = 'pmcpc-status-pill pmcpc-status-pill--inactive';
        if ( 'active' === $status ) {
            $class = 'pmcpc-status-pill pmcpc-status-pill--active';
            return '<span class="' . esc_attr( $class ) . '"><strong>●</strong><span>' . esc_html( $label ) . '</span></span>';
        }
        if ( 'needs_setup' === $status ) {
            $class = 'pmcpc-status-pill pmcpc-status-pill--needs-data';
        }
        return '<span class="' . esc_attr( $class ) . '"><span>' . esc_html( $label ) . '</span></span>';
    }

    protected function get_trigger_ui_state( $trigger, $existing_id = 0 ) {
        $trigger = (string) $trigger;
        $existing_id = (int) $existing_id;

        $workflow_definition = $this->get_step_workflow_definition_for_trigger( $trigger );
        if ( ! empty( $workflow_definition ) ) {
            return $this->get_step_workflow_ui_state(
                $workflow_definition['workflow_key'],
                $workflow_definition['total_steps'],
                isset( $workflow_definition['action_label'] ) ? $workflow_definition['action_label'] : ''
            );
        }

        if ( 'abandoned_cart' === $trigger ) {
            return $this->get_abandoned_cart_workflow_ui_state();
        }

        if ( 'date' === $trigger ) {
            $scheduled_count = $this->count_campaigns_for_trigger( 'date', 'any' );
            if ( $scheduled_count > 0 ) {
                return array(
                    'status'       => 'scheduled',
                    'label'        => $scheduled_count > 1 ? sprintf( __( 'Scheduled (%d)', 'product-mailer-campaigns' ), $scheduled_count ) : __( 'Scheduled', 'product-mailer-campaigns' ),
                    'action_label' => __( 'View schedules', 'product-mailer-campaigns' ),
                    'count'        => $scheduled_count,
                );
            }

            return array(
                'status'       => 'not_created',
                'label'        => __( 'Not created', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create campaign', 'product-mailer-campaigns' ),
                'count'        => 0,
            );
        }

        if ( $existing_id <= 0 ) {
            return array(
                'status'       => 'not_created',
                'label'        => __( 'Not created', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
            );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'pmcpc_campaigns';
        $raw_status = (string) $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$table} WHERE id = %d LIMIT 1", $existing_id ) );
        $raw_status = sanitize_key( $raw_status );

        if ( 'active' === $raw_status || 'scheduled' === $raw_status || 'queued' === $raw_status ) {
            return array(
                'status'       => 'active',
                'label'        => __( 'Active', 'product-mailer-campaigns' ),
                'action_label' => __( 'Edit workflow', 'product-mailer-campaigns' ),
            );
        }

        if ( in_array( $raw_status, array( 'draft', 'needs_data' ), true ) ) {
            return array(
                'status'       => 'needs_setup',
                'label'        => __( 'Needs setup', 'product-mailer-campaigns' ),
                'action_label' => __( 'Complete setup', 'product-mailer-campaigns' ),
            );
        }

        if ( in_array( $raw_status, array( 'paused', 'inactive', 'disabled' ), true ) ) {
            return array(
                'status'       => 'inactive',
                'label'        => __( 'Inactive', 'product-mailer-campaigns' ),
                'action_label' => __( 'Enable workflow', 'product-mailer-campaigns' ),
            );
        }

        return array(
            'status'       => 'inactive',
            'label'        => __( 'Inactive', 'product-mailer-campaigns' ),
            'action_label' => __( 'Edit workflow', 'product-mailer-campaigns' ),
        );
    }

    /**
     * Built-in non-abandoned-cart step workflow definitions shown on the Automations page.
     *
     * @param string $trigger UI trigger key.
     * @return array
     */
    protected function get_step_workflow_definition_for_trigger( $trigger ) {
        $trigger = sanitize_key( (string) $trigger );
        $definitions = array(
            'workflow_welcome_series' => array(
                'workflow_key' => 'welcome_series',
                'total_steps'  => 3,
            ),
            'workflow_post_purchase_sequence' => array(
                'workflow_key' => 'post_purchase_sequence',
                'total_steps'  => 3,
            ),
            'workflow_customer_winback_sequence' => array(
                'workflow_key' => 'customer_winback_sequence',
                'total_steps'  => 2,
            ),
        );

        return isset( $definitions[ $trigger ] ) ? $definitions[ $trigger ] : array();
    }

    /**
     * Return aggregate UI state for a workflow_key stored across campaign rows.
     *
     * @param string $workflow_key Workflow key stored in campaigns table.
     * @param int    $total_steps  Expected number of workflow steps.
     * @param string $fallback_action Optional action label.
     * @return array
     */
    protected function get_step_workflow_ui_state( $workflow_key, $total_steps, $fallback_action = '' ) {
        global $wpdb;

        $workflow_key = sanitize_key( (string) $workflow_key );
        $total_steps  = max( 1, absint( $total_steps ) );
        if ( '' === $workflow_key || ! isset( $wpdb ) || ! $wpdb instanceof wpdb ) {
            return array(
                'status'       => 'not_created',
                'label'        => __( 'Not created', 'product-mailer-campaigns' ),
                'action_label' => $fallback_action ? $fallback_action : __( 'Create workflow', 'product-mailer-campaigns' ),
                'count'        => 0,
                'latest_id'    => 0,
            );
        }

        $table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $has_column = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", 'workflow_key' ) );
        if ( empty( $has_column ) ) {
            return array(
                'status'       => 'not_created',
                'label'        => __( 'Not created', 'product-mailer-campaigns' ),
                'action_label' => $fallback_action ? $fallback_action : __( 'Create workflow', 'product-mailer-campaigns' ),
                'count'        => 0,
                'latest_id'    => 0,
            );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, status, workflow_step FROM {$table} WHERE workflow_key = %s AND workflow_step > 0 AND status IN ('active','scheduled','queued','draft','needs_data','paused','inactive','disabled') ORDER BY workflow_step ASC, id ASC",
                $workflow_key
            )
        );

        $created   = 0;
        $active    = 0;
        $needs     = 0;
        $inactive  = 0;
        $latest_id = 0;

        if ( ! empty( $rows ) && is_array( $rows ) ) {
            foreach ( $rows as $row ) {
                if ( empty( $row->id ) ) {
                    continue;
                }
                $created++;
                if ( 0 === $latest_id ) {
                    $latest_id = (int) $row->id;
                }
                $status = isset( $row->status ) ? sanitize_key( (string) $row->status ) : '';
                if ( in_array( $status, array( 'active', 'scheduled', 'queued' ), true ) ) {
                    $active++;
                } elseif ( in_array( $status, array( 'draft', 'needs_data' ), true ) ) {
                    $needs++;
                } elseif ( in_array( $status, array( 'paused', 'inactive', 'disabled' ), true ) ) {
                    $inactive++;
                }
            }
        }

        if ( 0 === $created ) {
            return array(
                'status'       => 'not_created',
                'label'        => __( 'Not created', 'product-mailer-campaigns' ),
                'action_label' => $fallback_action ? $fallback_action : __( 'Create workflow', 'product-mailer-campaigns' ),
                'count'        => 0,
                'latest_id'    => 0,
            );
        }

        if ( $active === $total_steps ) {
            return array(
                'status'       => 'active',
                'label'        => sprintf( __( '%1$d/%2$d active', 'product-mailer-campaigns' ), $active, $total_steps ),
                'action_label' => __( 'Edit workflow', 'product-mailer-campaigns' ),
                'count'        => $created,
                'latest_id'    => $latest_id,
            );
        }

        if ( $active > 0 ) {
            return array(
                'status'       => 'active',
                'label'        => sprintf( __( '%1$d/%2$d active', 'product-mailer-campaigns' ), $active, $total_steps ),
                'action_label' => __( 'Edit workflow', 'product-mailer-campaigns' ),
                'count'        => $created,
                'latest_id'    => $latest_id,
            );
        }

        if ( $needs > 0 ) {
            return array(
                'status'       => 'needs_setup',
                'label'        => sprintf( __( '%1$d/%2$d needs setup', 'product-mailer-campaigns' ), $needs, $total_steps ),
                'action_label' => __( 'Complete workflow', 'product-mailer-campaigns' ),
                'count'        => $created,
                'latest_id'    => $latest_id,
            );
        }

        return array(
            'status'       => 'inactive',
            'label'        => $inactive > 0 ? sprintf( __( '%1$d/%2$d inactive', 'product-mailer-campaigns' ), $inactive, $total_steps ) : sprintf( __( '%1$d/%2$d created', 'product-mailer-campaigns' ), $created, $total_steps ),
            'action_label' => __( 'Edit workflow', 'product-mailer-campaigns' ),
            'count'        => $created,
            'latest_id'    => $latest_id,
        );
    }

    /**
     * Return aggregate UI state for the three abandoned-cart email steps.
     *
     * The database keeps each email as its own editable campaign, but the
     * Automations page presents them as one customer-facing workflow.
     *
     * @return array
     */
    protected function get_abandoned_cart_workflow_ui_state() {
        $steps = array( 'abandoned_cart_step_1', 'abandoned_cart_step_2', 'abandoned_cart_step_3' );

        $created = 0;
        $active  = 0;
        $needs   = 0;
        $inactive = 0;
        $latest_id = 0;

        foreach ( $steps as $step ) {
            $row = $this->get_latest_campaign_row_for_trigger( $step );
            if ( ! $row || empty( $row->id ) ) {
                continue;
            }

            $created++;
            $latest_id = (int) $row->id;
            $status    = isset( $row->status ) ? sanitize_key( (string) $row->status ) : '';

            if ( in_array( $status, array( 'active', 'scheduled', 'queued' ), true ) ) {
                $active++;
            } elseif ( in_array( $status, array( 'draft', 'needs_data' ), true ) ) {
                $needs++;
            } elseif ( in_array( $status, array( 'paused', 'inactive', 'disabled' ), true ) ) {
                $inactive++;
            }
        }

        if ( 0 === $created ) {
            return array(
                'status'       => 'not_created',
                'label'        => __( 'Not created', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create workflow', 'product-mailer-campaigns' ),
                'count'        => 0,
                'latest_id'    => 0,
            );
        }

        if ( 3 === $active ) {
            return array(
                'status'       => 'active',
                'label'        => __( '3/3 active', 'product-mailer-campaigns' ),
                'action_label' => __( 'Edit workflow', 'product-mailer-campaigns' ),
                'count'        => $created,
                'latest_id'    => $latest_id,
            );
        }

        if ( $active > 0 ) {
            return array(
                'status'       => 'active',
                'label'        => sprintf( __( '%1$d/3 active', 'product-mailer-campaigns' ), $active ),
                'action_label' => __( 'Edit workflow', 'product-mailer-campaigns' ),
                'count'        => $created,
                'latest_id'    => $latest_id,
            );
        }

        if ( $needs > 0 ) {
            return array(
                'status'       => 'needs_setup',
                'label'        => sprintf( __( '%1$d/3 needs setup', 'product-mailer-campaigns' ), $needs ),
                'action_label' => __( 'Complete workflow', 'product-mailer-campaigns' ),
                'count'        => $created,
                'latest_id'    => $latest_id,
            );
        }

        return array(
            'status'       => 'inactive',
            'label'        => $inactive > 0 ? sprintf( __( '%1$d/3 inactive', 'product-mailer-campaigns' ), $inactive ) : sprintf( __( '%1$d/3 created', 'product-mailer-campaigns' ), $created ),
            'action_label' => __( 'Edit workflow', 'product-mailer-campaigns' ),
            'count'        => $created,
            'latest_id'    => $latest_id,
        );
    }

    /**
     * Count existing campaigns that use a given automation trigger.
     *
     * @param string $trigger
     * @return int
     */
    /**
     * Count campaigns for a given trigger.
     *
     * @param string $trigger Trigger key.
     * @param string $mode    'active' for enabled campaigns only, 'any' for any status.
     * @return int
     */

    /**
     * Get the most recently created campaign id for a given automation trigger.
     *
     * @param string $trigger
     * @return int
     */
    protected function get_latest_campaign_id_for_trigger( $trigger ) {
        $campaign = $this->get_latest_campaign_row_for_trigger( $trigger );
        return ( $campaign && ! empty( $campaign->id ) ) ? (int) $campaign->id : 0;
    }

    protected function get_latest_campaign_row_for_trigger( $trigger ) {
        global $wpdb;

        $trigger = sanitize_key( (string) $trigger );
        if ( empty( $trigger ) ) {
            return null;
        }

        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        $where_parts     = array();
        $prepare_args    = array();

        if ( 'date' === $trigger ) {
            $where_parts[] = "(automation_trigger = %s)";
            $prepare_args[] = 'date';
            $where_parts[] = "(schedule_type IN (%s, %s) AND (automation_trigger IS NULL OR automation_trigger = '' OR automation_trigger = 'none'))";
            $prepare_args[] = 'one_time';
            $prepare_args[] = 'recurring';
        } else {
            $aliases = $this->get_trigger_aliases( $trigger );
            if ( $aliases ) {
                $where_parts[] = 'automation_trigger IN (' . implode( ', ', array_fill( 0, count( $aliases ), '%s' ) ) . ')';
                $prepare_args  = array_merge( $prepare_args, $aliases );
            }

            if ( 'new_subscriber' === $trigger ) {
                $where_parts[] = 'is_welcome = 1';
            } elseif ( 'post_purchase' === $trigger ) {
                $where_parts[] = 'is_post_purchase = 1';
            }
        }

        if ( empty( $where_parts ) ) {
            return null;
        }

        $sql = "SELECT id, status, automation_trigger, schedule_type FROM {$campaigns_table} WHERE (" . implode( ' OR ', $where_parts ) . ") AND (workflow_key IS NULL OR workflow_key = '') ORDER BY updated_at DESC, id DESC LIMIT 1";
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->get_row( $wpdb->prepare( $sql, $prepare_args ) );
    }

    protected function count_campaigns_for_trigger( $trigger, $mode = 'active' ) {
        $trigger = sanitize_key( (string) $trigger );
        if ( '' === $trigger ) {
            return 0;
        }

        global $wpdb;
        if ( ! isset( $wpdb ) || ! $wpdb instanceof wpdb ) {
            return 0;
        }

        $table = $wpdb->prefix . 'pmcpc_campaigns';

        if ( 'date' === $trigger || 'specific_date' === $trigger ) {
            $statuses = ( 'active' === $mode )
                ? array( 'scheduled', 'active', 'queued' )
                : array( 'scheduled', 'active', 'queued', 'draft', 'paused', 'inactive', 'disabled' );
            $status_placeholders = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );
            $args = array_merge(
                $statuses,
                array( 'date', 'specific_date', 'one_time', 'recurring' )
            );
            $sql = "SELECT COUNT(*) FROM {$table} WHERE status IN ({$status_placeholders}) AND ((automation_trigger IN (%s, %s)) OR (schedule_type IN (%s, %s) AND (automation_trigger IS NULL OR automation_trigger = '' OR automation_trigger = 'none')))";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            return (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) );
        }

        $aliases = $this->get_trigger_aliases( $trigger );
        if ( empty( $aliases ) ) {
            return 0;
        }

        $statuses = ( 'active' === $mode )
            ? array( 'active' )
            : array( 'active', 'scheduled', 'queued', 'draft', 'paused', 'inactive', 'disabled' );

        $where_parts   = array();
        $prepare_args  = array();
        $where_parts[] = 'status IN (' . implode( ', ', array_fill( 0, count( $statuses ), '%s' ) ) . ')';
        $prepare_args  = array_merge( $prepare_args, $statuses );

        $trigger_parts   = array();
        $trigger_parts[] = 'automation_trigger IN (' . implode( ', ', array_fill( 0, count( $aliases ), '%s' ) ) . ')';
        $prepare_args    = array_merge( $prepare_args, $aliases );

        if ( 'post_purchase' === $trigger ) {
            $trigger_parts[] = 'is_post_purchase = 1';
        } elseif ( 'new_subscriber' === $trigger ) {
            $trigger_parts[] = 'is_welcome = 1';
        }

        $where_parts[] = "(workflow_key IS NULL OR workflow_key = '')";

        $sql = "SELECT COUNT(*) FROM {$table} WHERE " . implode( ' AND ', $where_parts ) . " AND (" . implode( ' OR ', $trigger_parts ) . ")";
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        return (int) $wpdb->get_var( $wpdb->prepare( $sql, $prepare_args ) );
    }


/**
     * Get the most likely column name that stores the human-readable campaign name.
     *
     * The core/free plugin database schema has changed across versions.
     * Some installs use `campaign_name` while older installs used `name`.
     *
     * @return string
     */
    protected function get_campaign_name_column() {
        global $wpdb;

        // Defensive: if wpdb isn't available for some reason, default.
        if ( ! isset( $wpdb ) || ! $wpdb instanceof wpdb ) {
            return 'campaign_name';
        }

        $table = $wpdb->prefix . 'pmcpc_campaigns';

        // Prefer the newest schema.
        $candidates = array( 'campaign_name', 'name', 'title', 'campaign_title', 'subject' );
        foreach ( $candidates as $col ) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $exists = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", $col ) );
            if ( ! empty( $exists ) ) {
                return $col;
            }
        }

        return 'campaign_name';
    }

    
/**
 * Build the base URL for creating a campaign, using the newest workflow if available.
 *
 * The free plugin has evolved over time (list page vs. create wizard). We try to
 * detect the registered admin page slug and fall back safely.
 *
 * @return string
 */
public function get_create_campaign_base_url() {
    // Prefer newer create-workflow slugs first, then fall back to the legacy list/create screen.
    $candidates = array(
        'pmcpc_campaign_create',
        'pmcpc_campaign_new',
        'pmcpc_create_campaign',
        'pmcpc_campaigns',
    );

    $slug = $this->detect_registered_admin_page_slug( $candidates );

    return add_query_arg(
        array( 'page' => $slug ),
        admin_url( 'admin.php' )
    );
}

/**
 * Best-effort detection of an admin page slug registered by the free plugin.
 *
 * @param array $candidates
 * @return string
 */
protected function detect_registered_admin_page_slug( $candidates ) {
    if ( ! is_array( $candidates ) || empty( $candidates ) ) {
        return 'pmcpc_campaigns';
    }

    // Look for the slug in global menus/submenus, which is the most reliable signal.
    global $menu, $submenu;

    foreach ( $candidates as $slug ) {
        // Check top-level menu.
        if ( is_array( $menu ) ) {
            foreach ( $menu as $item ) {
                if ( isset( $item[2] ) && $item[2] === $slug ) {
                    return $slug;
                }
            }
        }

        // Check submenus.
        if ( is_array( $submenu ) ) {
            foreach ( $submenu as $parent => $items ) {
                if ( ! is_array( $items ) ) {
                    continue;
                }
                foreach ( $items as $item ) {
                    if ( isset( $item[2] ) && $item[2] === $slug ) {
                        return $slug;
                    }
                }
            }
        }
    }

    // Fall back to legacy.
    return end( $candidates );
}

/**
 * Build a "create campaign" URL that is compatible with both legacy and new workflows.
 *
 * @param array $args Query args to add.
 * @return string
 */
public function build_create_campaign_url( $args = array() ) {
    $base = $this->get_create_campaign_base_url();

    if ( ! is_array( $args ) ) {
        $args = array();
    }

    // Mark that the campaign wizard was launched from a Pro shortcut (Segments/Automations).
    // Used by the builder prefill to apply the selected Pro email template wrapper
    // even when the free plugin already provides default content.
    if ( ! isset( $args['pmcpc_pro_shortcut'] ) ) {
        $args['pmcpc_pro_shortcut'] = '1';
    }

    // Back-compat / forward-compat: mirror the segment key into newer parameter names.
    if ( isset( $args['pro_segment_key'] ) ) {
        if ( ! isset( $args['segment_key'] ) ) {
            $args['segment_key'] = $args['pro_segment_key'];
        }
        if ( ! isset( $args['segment'] ) ) {
            $args['segment'] = $args['pro_segment_key'];
        }
    }

    // If this is an automation shortcut, some newer wizards expect a "type" hint.
    if ( isset( $args['trigger'] ) && ! isset( $args['campaign_type'] ) ) {
        $args['campaign_type'] = 'automation';
    }

    /*
     * New step-by-step workflow compatibility:
     * If we know we're coming from Segments/Automations, provide best-effort "start at step" hints.
     * The free plugin may use any of these keys; unknown keys are ignored safely.
     */
    $has_segment = isset( $args['pro_segment_key'] ) || isset( $args['segment_key'] ) || isset( $args['segment'] );
    $has_trigger = isset( $args['trigger'] );

    // If a trigger is provided and no explicit template was chosen, use the per-automation default template.
    if ( $has_trigger && ! isset( $args['pmcpc_template'] ) && ! isset( $args['pmcpc_template_id'] ) ) {
        $args['pmcpc_template'] = $this->get_email_template_id_for_trigger( (string) $args['trigger'] );
    }


    $has_products_prefill = isset( $args['product_ids'] ) || isset( $args['products'] ) || isset( $args['include_products'] ) || isset( $args['exclude_products'] );

    if ( $has_segment && $has_trigger && $has_products_prefill ) {
        /*
         * If trigger + audience + products are already provided, jump to Email (step 5).
         */
        $args = array_merge(
            array(
                'pmcpc_new'   => isset( $args['pmcpc_new'] ) ? $args['pmcpc_new'] : '1',
                'pmcpc_stage' => isset( $args['pmcpc_stage'] ) ? $args['pmcpc_stage'] : '5',
                'step'        => isset( $args['step'] ) ? $args['step'] : 'email',
                'stage'       => isset( $args['stage'] ) ? $args['stage'] : 'email',
                'wizard_step' => isset( $args['wizard_step'] ) ? $args['wizard_step'] : 'email',
                'tab'         => isset( $args['tab'] ) ? $args['tab'] : 'email',
                'view'        => isset( $args['view'] ) ? $args['view'] : 'email',
            ),
            $args
        );
    } elseif ( $has_segment && $has_trigger ) {
        /*
         * Smart jump:
         * If both a trigger (automation) and a segment (audience) are already provided,
         * skip straight to Products (step 4) so the user doesn't have to click through
         * Timing + Audience just to confirm prefilled values.
         */
        $args = array_merge(
            array(
                'pmcpc_new'   => isset( $args['pmcpc_new'] ) ? $args['pmcpc_new'] : '1',
                'pmcpc_stage' => isset( $args['pmcpc_stage'] ) ? $args['pmcpc_stage'] : '4',
                'step'        => isset( $args['step'] ) ? $args['step'] : 'products',
                'stage'       => isset( $args['stage'] ) ? $args['stage'] : 'products',
                'wizard_step' => isset( $args['wizard_step'] ) ? $args['wizard_step'] : 'products',
                'tab'         => isset( $args['tab'] ) ? $args['tab'] : 'products',
                'view'        => isset( $args['view'] ) ? $args['view'] : 'products',
            ),
            $args
        );
    } elseif ( $has_segment ) {
        // Audience step (step 3 in the wizard UI).
        $args = array_merge(
            array(
                'pmcpc_new'   => isset( $args['pmcpc_new'] ) ? $args['pmcpc_new'] : '1',
                'pmcpc_stage' => isset( $args['pmcpc_stage'] ) ? $args['pmcpc_stage'] : '3',
                'step'        => isset( $args['step'] ) ? $args['step'] : 'audience',
                'stage'       => isset( $args['stage'] ) ? $args['stage'] : 'audience',
                'wizard_step' => isset( $args['wizard_step'] ) ? $args['wizard_step'] : 'audience',
                'tab'         => isset( $args['tab'] ) ? $args['tab'] : 'audience',
                'view'        => isset( $args['view'] ) ? $args['view'] : 'audience',
            ),
            $args
        );
    } elseif ( $has_trigger ) {
        // Timing step (step 2 in the wizard UI).
        $args = array_merge(
            array(
                'pmcpc_new'   => isset( $args['pmcpc_new'] ) ? $args['pmcpc_new'] : '1',
                'pmcpc_stage' => isset( $args['pmcpc_stage'] ) ? $args['pmcpc_stage'] : '2',
                'step'        => isset( $args['step'] ) ? $args['step'] : 'timing',
                'stage'       => isset( $args['stage'] ) ? $args['stage'] : 'timing',
                'wizard_step' => isset( $args['wizard_step'] ) ? $args['wizard_step'] : 'timing',
                'tab'         => isset( $args['tab'] ) ? $args['tab'] : 'timing',
                'view'        => isset( $args['view'] ) ? $args['view'] : 'timing',
            ),
            $args
        );
    }

    /**
     * Allow the free plugin (or site) to fully override the create URL.
     *
     * @param string $base
     * @param array  $args
     */
    $base = apply_filters( 'pmcpc_pro_create_campaign_base_url', $base, $args );

    return add_query_arg( $args, $base );
}

/**
 * Build a generic "new automation" URL that opens the campaign builder on the
 * trigger step, so users can start an automation from either the Campaigns or
 * Automations pages without needing a preselected trigger.
 *
 * @param array $args Optional query args to merge into the base automation builder URL.
 * @return string
 */
public function build_new_automation_url( $args = array() ) {
    if ( ! is_array( $args ) ) {
        $args = array();
    }

    $defaults = array(
        'campaign_type' => 'automation',
        'pmcpc_new'     => '1',
        'pmcpc_stage'   => '2',
        'step'          => 'timing',
        'stage'         => 'timing',
        'wizard_step'   => 'timing',
        'tab'           => 'timing',
        'view'          => 'timing',
    );

    return $this->build_create_campaign_url( array_merge( $defaults, $args ) );
}


    /**
     * Render a split "Create campaign" button with per-template choices.
     *
     * This is progressive-enhancement friendly and works without JavaScript.
     *
     * @param string $base_url
     * @param string $primary_label
     * @param array  $extra_query Optional extra query args to always include.
     */
    protected function render_create_campaign_with_template_picker( $base_url, $primary_label = '', $extra_query = array() ) {
        static $did_css = false;
        if ( ! $did_css ) {
            $did_css = true;
            echo '<style>.pmcpc-split{display:inline-flex;align-items:center;gap:6px;flex-wrap:wrap}.pmcpc-split details{position:relative}.pmcpc-split details>summary{list-style:none}.pmcpc-split details>summary::-webkit-details-marker{display:none}.pmcpc-split .pmcpc-menu{position:absolute;right:0;z-index:20;background:#fff;border:1px solid #c3c4c7;border-radius:6px;box-shadow:0 4px 14px rgba(0,0,0,.08);padding:6px;min-width:220px}.pmcpc-split .pmcpc-menu a{display:block;padding:6px 8px;text-decoration:none;border-radius:4px}.pmcpc-split .pmcpc-menu a:hover{background:#f0f0f1}.pmcpc-split .pmcpc-menu small{opacity:.7}</style>';
        }

        $base_url = (string) $base_url;
        if ( '' === trim( $base_url ) ) {
            echo '<span class="description">—</span>';
            return;
        }

        if ( '' === trim( $primary_label ) ) {
            $primary_label = __( 'Create campaign', 'product-mailer-campaigns' );
        }

        // Normalise extra query.
        if ( ! is_array( $extra_query ) ) {
            $extra_query = array();
        }

        $all_templates = $this->get_all_email_templates();
        $default_id    = $this->get_default_email_template_id();

        // Primary button uses default template (no explicit template param).
        $primary_url = $base_url;
        if ( ! empty( $extra_query ) ) {
            $primary_url = add_query_arg( $extra_query, $primary_url );
        }

        echo '<span class="pmcpc-split">';
        echo '<a class="button button-small" href="' . esc_url( $primary_url ) . '">' . esc_html( $primary_label ) . '</a>';
echo '</span>';
    }


/**
     * Run the Pro plugin.
     */
    public function run() {
        // Runtime hooks must run on front-end too (automation triggers).
        add_action( 'init', array( $this, 'register_runtime_hooks' ) );
        add_action( self::CRON_HOOK_INACTIVE, array( $this, 'cron_check_inactive_customers' ) );
        add_action( self::CRON_HOOK_CORE, array( $this, 'cron_check_core_subscriber_triggers' ) );

        // Filter campaign subscribers in the free plugin so we can apply Pro segments.
        add_filter( 'pmcpc_campaign_subscribers', array( $this, 'filter_campaign_subscribers_by_segment' ), 10, 2 );

        // Admin-only UI.
        if ( is_admin() ) {
            add_action( 'admin_init', array( $this, 'check_dependencies' ) );
            add_action( 'admin_menu', array( $this, 'register_menus' ), 20 );

            // AJAX helpers (admin only).
            add_action( 'wp_ajax_pmcpc_pro_subscriber_search', array( $this, 'ajax_subscriber_search' ) );
            add_action( 'wp_ajax_pmcpc_et_send_test', array( $this, 'ajax_email_template_send_test' ) );

            // Manual tools (admin-post handlers).
            add_action( 'admin_post_pmcpc_pro_run_inactive_scan', array( $this, 'handle_manual_inactive_scan' ) );
            add_action( 'admin_post_pmcpc_pro_simulate_trigger', array( $this, 'handle_manual_simulate_trigger' ) );
            add_action( 'admin_post_pmcpc_pro_debug_abandoned_cart', array( $this, 'handle_manual_debug_abandoned_cart' ) );
            add_action( 'admin_post_pmcpc_pro_force_abandoned_cart', array( $this, 'handle_manual_force_abandoned_cart' ) );
            add_action( 'admin_post_pmcpc_pro_start_abandoned_recovery', array( $this, 'handle_manual_start_abandoned_recovery' ) );
            add_action( 'admin_post_pmcpc_pro_queue_abandoned_step_now', array( $this, 'handle_manual_queue_abandoned_step_now' ) );
            add_action( 'admin_post_pmcpc_pro_adjust_testing_time', array( $this, 'handle_manual_adjust_testing_time' ) );
            add_action( 'admin_post_pmcpc_pro_run_queue_processor', array( $this, 'handle_manual_run_queue_processor' ) );
            add_action( 'admin_post_pmcpc_pro_run_profile_trigger_scan', array( $this, 'handle_manual_run_profile_trigger_scan' ) );

            // Prefill the step-by-step Campaign builder fields when arriving via Pro shortcuts.
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_campaign_builder_prefill' ) );

            // Email Template UX helpers (media picker + color picker).
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_email_template_assets' ) );

            // Automations testing tools UX.
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_automations_assets' ) );
        }
    }

}
