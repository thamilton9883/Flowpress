<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Segment and core trigger methods for FlowPress automations.
 */
trait PMCPC_Automation_Segments_Methods {



    /**
     * Calculate a simple revenue attribution per campaign for the last N days.
     *
     * This uses a basic "last touch" model: for each WooCommerce order in the
     * period, we look for the most recent email event for that subscriber
     * (sent/open/click) that occurred before the order, within a limited
     * attribution window. If found, the order total is attributed to that
     * campaign.
     *
     * @param int $days Number of days of orders to consider.
     * @param int $attribution_window_days Max age (in days) of an email event before the order.
     * @return array Array with 'campaigns' (per-campaign metrics) and 'totals'.
     */
    protected function calculate_campaign_revenue_metrics( $days = 30, $attribution_window_days = 7 ) {
        global $wpdb;

        if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
            return array(
                'campaigns' => array(),
                'totals'    => array(
                    'orders'   => 0,
                    'revenue'  => 0.0,
                ),
            );
        }

        $days                  = max( 1, absint( $days ) );
        $attribution_window_ts = time() - ( absint( $attribution_window_days ) * DAY_IN_SECONDS );
        $orders_since_ts       = strtotime( '-' . $days . ' days' );

        // Fetch recent WooCommerce orders.
        $args = array(
            'limit'   => 500,
            'status'  => array( 'wc-completed', 'wc-processing' ),
            'return'  => 'ids',
            'orderby' => 'date',
            'order'   => 'DESC',
        );

        $orders = wc_get_orders( $args );
        if ( empty( $orders ) ) {
            return array(
                'campaigns' => array(),
                'totals'    => array(
                    'orders'   => 0,
                    'revenue'  => 0.0,
                ),
            );
        }

        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
        $queue_table       = $wpdb->prefix . 'pmcpc_email_queue';
        $events_table      = $wpdb->prefix . 'pmcpc_email_events';

        // Build a map of email -> subscriber_id from pmcpc_subscribers for relevant emails.
        $order_rows = array();
        $emails     = array();

        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) {
                continue;
            }

            if ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) {
                continue;
            }

            $order_ts = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : 0;
            if ( ! $order_ts || $order_ts < $orders_since_ts ) {
                continue;
            }

            $email = strtolower( $order->get_billing_email() );
            if ( ! $email ) {
                continue;
            }

            $total = (float) $order->get_total();

            $order_rows[] = array(
                'order_id'  => $order_id,
                'email'     => $email,
                'timestamp' => $order_ts,
                'total'     => $total,
            );

            $emails[] = $email;
        }

        if ( empty( $order_rows ) ) {
            return array(
                'campaigns' => array(),
                'totals'    => array(
                    'orders'   => 0,
                    'revenue'  => 0.0,
                ),
            );
        }

        $emails = array_unique( $emails );

        // Map email -> subscriber ID.
        $placeholders = implode( ',', array_fill( 0, count( $emails ), '%s' ) );
        $subscribers  = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, email FROM {$subscribers_table} WHERE status = 'active' AND email IN ({$placeholders})",
                $emails
            ),
            ARRAY_A
        );

        if ( empty( $subscribers ) ) {
            return array(
                'campaigns' => array(),
                'totals'    => array(
                    'orders'   => 0,
                    'revenue'  => 0.0,
                ),
            );
        }

        $email_to_subscriber = array();
        foreach ( $subscribers as $row ) {
            $email_to_subscriber[ strtolower( $row['email'] ) ] = (int) $row['id'];
        }

        // Build a map of subscriber -> recent events (campaign + latest event timestamp).
        $subscriber_ids = array_values( $email_to_subscriber );
        $subscriber_ids = array_map( 'intval', $subscriber_ids );
        $subscriber_ids = array_unique( $subscriber_ids );

        if ( empty( $subscriber_ids ) ) {
            return array(
                'campaigns' => array(),
                'totals'    => array(
                    'orders'   => 0,
                    'revenue'  => 0.0,
                ),
            );
        }

        $placeholders = implode( ',', array_fill( 0, count( $subscriber_ids ), '%d' ) );

        $events = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT q.subscriber_id, q.campaign_id, e.event_type, e.created_at
                FROM {$events_table} e
                INNER JOIN {$queue_table} q ON e.queue_id = q.id
                WHERE q.subscriber_id IN ({$placeholders})
                  AND e.created_at >= %s",
                array_merge( $subscriber_ids, array( gmdate( 'Y-m-d H:i:s', $attribution_window_ts ) ) )
            ),
            ARRAY_A
        );
        $event_index = array(); // subscriber_id => array of (campaign_id => latest_ts).
        if ( ! empty( $events ) ) {
            foreach ( $events as $event ) {
                $sid        = (int) $event['subscriber_id'];
                $campaign_id = (int) $event['campaign_id'];

                if ( $sid <= 0 || $campaign_id <= 0 ) {
                    continue;
                }

                $event_ts = strtotime( $event['created_at'] );
                if ( ! $event_ts ) {
                    continue;
                }

                if ( ! isset( $event_index[ $sid ] ) ) {
                    $event_index[ $sid ] = array();
                }
                if ( ! isset( $event_index[ $sid ][ $campaign_id ] ) || $event_ts > $event_index[ $sid ][ $campaign_id ] ) {
                    $event_index[ $sid ][ $campaign_id ] = $event_ts;
                }
            }
        }

        $campaign_metrics = array();
        $total_orders     = 0;
        $total_revenue    = 0.0;

        foreach ( $order_rows as $order_row ) {
            $email = $order_row['email'];
            if ( ! isset( $email_to_subscriber[ $email ] ) ) {
                continue;
            }

            $subscriber_id = $email_to_subscriber[ $email ];
            $order_ts      = $order_row['timestamp'];
            $order_total   = $order_row['total'];

            if ( ! isset( $event_index[ $subscriber_id ] ) ) {
                continue;
            }

            // Find the most recent event before the order, within the attribution window.
            $best_campaign_id = 0;
            $best_event_ts    = 0;

            foreach ( $event_index[ $subscriber_id ] as $campaign_id => $event_ts ) {
                if ( $event_ts <= $order_ts && $event_ts >= $attribution_window_ts && $event_ts > $best_event_ts ) {
                    $best_event_ts    = $event_ts;
                    $best_campaign_id = $campaign_id;
                }
            }

            if ( $best_campaign_id <= 0 ) {
                continue;
            }

            if ( ! isset( $campaign_metrics[ $best_campaign_id ] ) ) {
                $campaign_metrics[ $best_campaign_id ] = array(
                    'orders'  => 0,
                    'revenue' => 0.0,
                );
            }

            $campaign_metrics[ $best_campaign_id ]['orders']++;
            $campaign_metrics[ $best_campaign_id ]['revenue'] += $order_total;

            $total_orders++;
            $total_revenue += $order_total;
        }

        return array(
            'campaigns' => $campaign_metrics,
            'totals'    => array(
                'orders'  => $total_orders,
                'revenue' => $total_revenue,
            ),
        );
    }

    /**
     * Filter campaign subscribers according to the Pro recipient segment.
     *
     * This is called from the free plugin via the pmcpc_campaign_subscribers filter.
     *
     * @param array  $subscribers List of subscriber rows from the pmcpc_subscribers table.
     * @param object $campaign    Campaign row from pmcpc_campaigns.
     * @return array
     */
    public function filter_campaign_subscribers_by_segment( $subscribers, $campaign ) {
        if ( empty( $subscribers ) || ! is_array( $subscribers ) ) {
            return $subscribers;
        }

        if ( ! isset( $campaign->pro_segment_key ) || '' === $campaign->pro_segment_key ) {
            return $subscribers;
        }

        if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
            return $subscribers;
        }

        global $wpdb;

        $segment = $campaign->pro_segment_key;

        // Build map of subscriber ID -> email for the provided subscribers.
        $subscriber_map = array();
        foreach ( $subscribers as $sub ) {
            if ( empty( $sub->id ) || empty( $sub->email ) ) {
                continue;
            }
            $subscriber_map[ (int) $sub->id ] = strtolower( $sub->email );
        }

        if ( empty( $subscriber_map ) ) {
            return $subscribers;
        }

        // Build inverse map: email -> subscriber ID for quick lookup.
        $email_to_subscriber = array();
        foreach ( $subscriber_map as $id => $email ) {
            $email_to_subscriber[ $email ] = $id;
        }

        // Fetch a reasonable sample of recent orders for matching.
        $args = array(
            'limit'   => 1000,
            'status'  => array( 'wc-completed', 'wc-processing' ),
            'return'  => 'ids',
            'orderby' => 'date',
            'order'   => 'DESC',
        );

        $orders = wc_get_orders( $args );

        if ( empty( $orders ) ) {
            return array();
        }

        $now             = time();
        $ninety_days_ago = strtotime( '-90 days', $now );

        $subscriber_totals   = array();
        $subscriber_last_ts  = array();
        $subscriber_order_counts = array();

        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) {
                continue;
            }

            // Skip refunds or non-standard order types.
            if ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) {
                continue;
            }

            $email = strtolower( $order->get_billing_email() );
            if ( ! $email || ! isset( $email_to_subscriber[ $email ] ) ) {
                continue;
            }

            $subscriber_id = $email_to_subscriber[ $email ];
            $order_ts      = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : false;

            if ( ! $order_ts ) {
                continue;
            }

            if ( ! isset( $subscriber_totals[ $subscriber_id ] ) ) {
                $subscriber_totals[ $subscriber_id ]  = 0;
                $subscriber_last_ts[ $subscriber_id ] = 0;
            }
            if ( ! isset( $subscriber_order_counts[ $subscriber_id ] ) ) {
                $subscriber_order_counts[ $subscriber_id ] = 0;
            }
            $subscriber_order_counts[ $subscriber_id ]++;


            $subscriber_totals[ $subscriber_id ] += (float) $order->get_total();
            if ( $order_ts > $subscriber_last_ts[ $subscriber_id ] ) {
                $subscriber_last_ts[ $subscriber_id ] = $order_ts;
            }
        }

        if ( empty( $subscriber_totals ) ) {
            return array();
        }

// Determine which subscriber IDs belong to the requested segment.
$segment_ids = array();

if ( 'customers' === $segment ) {
    // Any subscriber with at least one qualifying order.
    $segment_ids = array_keys( $subscriber_totals );
} elseif ( 'new_customers' === $segment ) {
    // Subscribers with exactly one qualifying order (first-time customers).
    foreach ( $subscriber_order_counts as $subscriber_id => $order_count ) {
        if ( 1 === (int) $order_count ) {
            $segment_ids[] = (int) $subscriber_id;
        }
    }
} elseif ( 'repeat_customers' === $segment ) {
    // Subscribers with two or more qualifying orders.
    foreach ( $subscriber_order_counts as $subscriber_id => $order_count ) {
        if ( (int) $order_count >= 2 ) {
            $segment_ids[] = (int) $subscriber_id;
        }
    }
} elseif ( 'recent' === $segment ) {
    $thirty_days_ago = strtotime( '-30 days' );
    foreach ( $subscriber_last_ts as $subscriber_id => $last_ts ) {
        if ( $last_ts > $thirty_days_ago ) {
            $segment_ids[] = $subscriber_id;
        }
    }
} elseif ( 'high_value' === $segment ) {
    $threshold = 0;
    if ( function_exists( 'pmcpc_get_setting' ) ) {
        $threshold = (float) pmcpc_get_setting( 'lifecycle_high_value_threshold', 0 );
    }
    if ( $threshold > 0 ) {
        foreach ( $subscriber_totals as $subscriber_id => $total_spent ) {
            if ( $total_spent >= $threshold ) {
                $segment_ids[] = $subscriber_id;
            }
        }
    }
} elseif ( 'vip' === $segment ) {
    arsort( $subscriber_totals );
    $total_customers = count( $subscriber_totals );
    $vip_count       = max( 1, (int) ceil( $total_customers * 0.1 ) );
    $segment_ids     = array_keys( array_slice( $subscriber_totals, 0, $vip_count, true ) );
} elseif ( 'lapsed' === $segment ) {
    foreach ( $subscriber_last_ts as $subscriber_id => $last_ts ) {
        if ( $last_ts <= $ninety_days_ago ) {
            $segment_ids[] = $subscriber_id;
        }
    }
}
        if ( empty( $segment_ids ) ) {
            return array();
        }

        $segment_ids = array_map( 'intval', array_unique( $segment_ids ) );

        // Filter the original subscribers list down to those IDs.
        $filtered = array();
        foreach ( $subscribers as $sub ) {
            if ( isset( $sub->id ) && in_array( (int) $sub->id, $segment_ids, true ) ) {
                $filtered[] = $sub;
            }
        }

        return $filtered;
    }

    /**
     * Cron: scan core subscriber-based automation triggers.
     *
     * Supported live triggers:
     * - lead_magnet_download
     * - subscriber_inactive
     * - subscriber_anniversary
     * - subscriber_birthday
     *
     * @return void
     */
    public function cron_check_core_subscriber_triggers() {
        // Self-reschedule as a single event. The helper lives in the runtime trait.
        if ( method_exists( $this, 'ensure_automation_single_event' ) ) {
            $this->ensure_automation_single_event( self::CRON_HOOK_CORE, HOUR_IN_SECONDS );
        }

        $triggers = array(
            'welcome_follow_up',
            'lead_magnet_download',
            'subscriber_inactive',
            'subscriber_anniversary',
            'subscriber_birthday',
        );

        foreach ( $triggers as $trigger ) {
            $this->run_core_trigger_scan( $trigger );
        }
    }

    /**
     * Run a live scan for one core trigger.
     *
     * @param string $trigger
     * @return int Number of queue attempts created.
     */
    protected function run_core_trigger_scan( $trigger ) {
        global $wpdb;

        if ( ! class_exists( 'PMCPC_Campaign_Manager' ) ) {
            return 0;
        }

        $trigger = sanitize_key( (string) $trigger );
        if ( '' === $trigger ) {
            return 0;
        }

        $campaigns_table   = $wpdb->prefix . 'pmcpc_campaigns';
        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $campaigns = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM %i WHERE automation_trigger = %s AND status = %s ORDER BY id ASC',
                $campaigns_table,
                $trigger,
                'active'
            )
        );

        if ( empty( $campaigns ) || ! is_array( $campaigns ) ) {
            return 0;
        }

        $queued = 0;

        foreach ( $campaigns as $campaign ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $subscribers = $wpdb->get_results(
                $wpdb->prepare(
                    'SELECT * FROM %i WHERE status = %s ORDER BY id ASC',
                    $subscribers_table,
                    'active'
                )
            );

            if ( empty( $subscribers ) || ! is_array( $subscribers ) ) {
                continue;
            }

            foreach ( $subscribers as $subscriber ) {
                $event_ts = $this->get_core_trigger_event_timestamp( $trigger, $subscriber, $campaign );
                if ( ! $event_ts ) {
                    continue;
                }

                if ( $this->maybe_queue_core_trigger_campaign( $trigger, $campaign, $subscriber, $event_ts ) ) {
                    $queued++;
                }
            }
        }

        if ( class_exists( 'PMCPC_Automation_Debug_Log' ) ) {
            PMCPC_Automation_Debug_Log::log(
                'core_trigger_scan',
                sprintf( 'Core trigger scan completed: %s queued %d item(s).', str_replace( '_', ' ', $trigger ), (int) $queued ),
                array(
                    'trigger' => $trigger,
                    'queued'  => (string) $queued,
                )
            );
        }

        return $queued;
    }

    /**
     * Determine the trigger event timestamp for a core subscriber-based trigger.
     *
     * Returns 0 when the subscriber does not currently qualify.
     *
     * @param string $trigger
     * @param object $subscriber
     * @param object $campaign
     * @return int
     */
    protected function get_core_trigger_event_timestamp( $trigger, $subscriber, $campaign ) {
        $trigger = sanitize_key( (string) $trigger );
        if ( empty( $subscriber ) || empty( $subscriber->id ) ) {
            return 0;
        }

        $now_ts = current_time( 'timestamp' );

        switch ( $trigger ) {
            case 'welcome_follow_up':
                if ( empty( $subscriber->created_at ) ) {
                    return 0;
                }

                $created_ts = (int) strtotime( (string) $subscriber->created_at );
                if ( ! $created_ts ) {
                    return 0;
                }

                return $created_ts;

            case 'lead_magnet_download':
                if ( ! $this->subscriber_matches_lead_magnet_source( $subscriber, $campaign ) ) {
                    return 0;
                }

                if ( empty( $subscriber->created_at ) ) {
                    return 0;
                }

                return (int) strtotime( (string) $subscriber->created_at );

            case 'subscriber_inactive':
                $reference_raw = '';
                foreach ( array( 'last_engaged_at', 'last_clicked_at', 'last_opened_at', 'updated_at', 'created_at' ) as $field ) {
                    if ( ! empty( $subscriber->{$field} ) ) {
                        $reference_raw = (string) $subscriber->{$field};
                        break;
                    }
                }

                if ( '' === $reference_raw ) {
                    return 0;
                }

                $reference_ts = (int) strtotime( $reference_raw );
                if ( ! $reference_ts ) {
                    return 0;
                }

                $inactive_days = (int) apply_filters( 'pmcpc_core_inactive_days', 30, $subscriber, $campaign );
                if ( $inactive_days <= 0 ) {
                    $inactive_days = 30;
                }

                $event_ts = $reference_ts + ( $inactive_days * DAY_IN_SECONDS );
                return ( $event_ts <= $now_ts ) ? $event_ts : 0;

            case 'subscriber_anniversary':
                if ( empty( $subscriber->created_at ) ) {
                    return 0;
                }

                $created_ts = (int) strtotime( (string) $subscriber->created_at );
                if ( ! $created_ts ) {
                    return 0;
                }

                $month_day = gmdate( 'm-d', $created_ts + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) );
                if ( gmdate( 'm-d', $now_ts + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) !== $month_day ) {
                    return 0;
                }

                return $this->build_site_local_timestamp_for_today( gmdate( 'H:i:s', $created_ts + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) );

            case 'subscriber_birthday':
                $birthday = $this->get_subscriber_birthday_parts( $subscriber );
                if ( empty( $birthday['month'] ) || empty( $birthday['day'] ) ) {
                    return 0;
                }

                $today_md = gmdate( 'm-d', $now_ts + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) );
                $birth_md = sprintf( '%02d-%02d', (int) $birthday['month'], (int) $birthday['day'] );
                if ( $today_md !== $birth_md ) {
                    return 0;
                }

                $time_of_day = ! empty( $birthday['time'] ) ? (string) $birthday['time'] : '09:00:00';
                return $this->build_site_local_timestamp_for_today( $time_of_day );
        }

        return 0;
    }

    /**
     * Queue a core trigger campaign when due and not already delivered for the current event window.
     *
     * @param string $trigger
     * @param object $campaign
     * @param object $subscriber
     * @param int    $event_ts
     * @return bool
     */
    protected function maybe_queue_core_trigger_campaign( $trigger, $campaign, $subscriber, $event_ts ) {
        if ( empty( $campaign ) || empty( $campaign->id ) || empty( $subscriber ) || empty( $subscriber->id ) ) {
            return false;
        }

        $candidates = array( $subscriber );
        $filtered   = apply_filters( 'pmcpc_campaign_subscribers', $candidates, $campaign );
        if ( empty( $filtered ) || ! is_array( $filtered ) ) {
            return false;
        }

        $target = reset( $filtered );
        if ( empty( $target ) || empty( $target->id ) ) {
            return false;
        }

        $delay_minutes = isset( $campaign->trigger_delay_minutes ) ? absint( $campaign->trigger_delay_minutes ) : 0;
        if ( ! $delay_minutes && ! empty( $campaign->is_welcome ) && isset( $campaign->welcome_delay_minutes ) ) {
            $delay_minutes = absint( $campaign->welcome_delay_minutes );
        }
        if ( ! $delay_minutes && ! empty( $campaign->is_post_purchase ) && isset( $campaign->post_purchase_delay_minutes ) ) {
            $delay_minutes = absint( $campaign->post_purchase_delay_minutes );
        }
        if ( ! $delay_minutes && isset( $campaign->broadcast_delay_minutes ) ) {
            $delay_minutes = absint( $campaign->broadcast_delay_minutes );
        }

        $due_ts = $event_ts + ( max( 0, (int) $delay_minutes ) * MINUTE_IN_SECONDS );
        $window_start_ts = $event_ts;

        if ( $due_ts > current_time( 'timestamp' ) ) {
            if ( class_exists( 'PMCPC_Automation_Debug_Log' ) ) {
                PMCPC_Automation_Debug_Log::log(
                    'core_trigger_skip',
                    sprintf( 'Skipped queue for %s: delay window has not been reached yet for %s.', ! empty( $campaign->name ) ? $campaign->name : __( 'Automation campaign', 'product-mailer-campaigns' ), ! empty( $target->email ) ? $target->email : __( 'unknown email', 'product-mailer-campaigns' ) ),
                    array(
                        'email'   => ! empty( $target->email ) ? (string) $target->email : '',
                        'trigger' => $trigger,
                        'result'  => 'waiting_for_due_time',
                    )
                );
            }
            return false;
        }

        $allow_recurring = in_array( $trigger, array( 'subscriber_inactive', 'subscriber_anniversary', 'subscriber_birthday' ), true );
        if ( ! $allow_recurring ) {
            PMCPC_Campaign_Manager::queue_campaign_for_subscriber( $campaign, $target, max( 0, (int) floor( ( $due_ts - current_time( 'timestamp' ) ) / MINUTE_IN_SECONDS ) ) );
            if ( class_exists( 'PMCPC_Automation_Debug_Log' ) ) {
                PMCPC_Automation_Debug_Log::log(
                    'core_trigger_queue',
                    sprintf( 'Queued %s for %s.', ! empty( $campaign->name ) ? $campaign->name : __( 'Automation campaign', 'product-mailer-campaigns' ), ! empty( $target->email ) ? $target->email : __( 'unknown email', 'product-mailer-campaigns' ) ),
                    array(
                        'email'    => ! empty( $target->email ) ? (string) $target->email : '',
                        'trigger'  => $trigger,
                        'campaign' => ! empty( $campaign->name ) ? (string) $campaign->name : '',
                        'result'   => 'queued',
                    )
                );
            }
            return true;
        }

        if ( $this->core_trigger_delivery_exists_since( (int) $campaign->id, (int) $target->id, $window_start_ts ) ) {
            if ( class_exists( 'PMCPC_Automation_Debug_Log' ) ) {
                PMCPC_Automation_Debug_Log::log(
                    'core_trigger_skip',
                    sprintf( 'Skipped duplicate queue for %s: an event in this recurrence window already exists for %s.', ! empty( $campaign->name ) ? $campaign->name : __( 'Automation campaign', 'product-mailer-campaigns' ), ! empty( $target->email ) ? $target->email : __( 'unknown email', 'product-mailer-campaigns' ) ),
                    array(
                        'email'   => ! empty( $target->email ) ? (string) $target->email : '',
                        'trigger' => $trigger,
                        'result'  => 'duplicate_window',
                    )
                );
            }
            return false;
        }

        PMCPC_Campaign_Manager::queue_campaign_for_subscriber( $campaign, $target, 0, true );
        if ( class_exists( 'PMCPC_Automation_Debug_Log' ) ) {
            PMCPC_Automation_Debug_Log::log(
                'core_trigger_queue',
                sprintf( 'Queued %s for %s.', ! empty( $campaign->name ) ? $campaign->name : __( 'Automation campaign', 'product-mailer-campaigns' ), ! empty( $target->email ) ? $target->email : __( 'unknown email', 'product-mailer-campaigns' ) ),
                array(
                    'email'    => ! empty( $target->email ) ? (string) $target->email : '',
                    'trigger'  => $trigger,
                    'campaign' => ! empty( $campaign->name ) ? (string) $campaign->name : '',
                    'result'   => 'queued',
                )
            );
        }
        return true;
    }

    /**
     * Check whether a queue row or email log already exists for the current trigger window.
     *
     * @param int $campaign_id
     * @param int $subscriber_id
     * @param int $since_ts
     * @return bool
     */
    protected function core_trigger_delivery_exists_since( $campaign_id, $subscriber_id, $since_ts ) {
        global $wpdb;

        $campaign_id   = absint( $campaign_id );
        $subscriber_id = absint( $subscriber_id );
        $since_ts      = absint( $since_ts );
        if ( ! $campaign_id || ! $subscriber_id || ! $since_ts ) {
            return false;
        }

        $queue_table = $wpdb->prefix . 'pmcpc_email_queue';
        $log_table   = $wpdb->prefix . 'pmcpc_email_log';
        $since_mysql = gmdate( 'Y-m-d H:i:s', $since_ts );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $pending_id = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM %i WHERE subscriber_id = %d AND campaign_id = %d AND status IN ('pending','sent') AND created_at >= %s LIMIT 1",
                $queue_table,
                $subscriber_id,
                $campaign_id,
                $since_mysql
            )
        );

        if ( $pending_id > 0 ) {
            return true;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $sent_id = (int) $wpdb->get_var(
            $wpdb->prepare(
                'SELECT id FROM %i WHERE subscriber_id = %d AND campaign_id = %d AND status = %s AND created_at >= %s LIMIT 1',
                $log_table,
                $subscriber_id,
                $campaign_id,
                'sent',
                $since_mysql
            )
        );

        return $sent_id > 0;
    }

    /**
     * Determine whether a subscriber should qualify for lead magnet delivery.
     *
     * @param object $subscriber
     * @param object $campaign
     * @return bool
     */
    protected function subscriber_matches_lead_magnet_source( $subscriber, $campaign ) {
        $tags = array();
        if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'get_tags_for_subscriber' ) ) {
            $tags = (array) PMCPC_Subscriber_Manager::get_tags_for_subscriber( (int) $subscriber->id );
        }

        $tags = array_map( 'strtolower', array_map( 'strval', $tags ) );

        $default_match_tags = array(
            'lead-magnet',
            'lead_magnet',
            'lead-magnet-download',
            'signup-form',
            'contact-optin',
            'email-prefs',
        );

        $default_match_tags = (array) apply_filters( 'pmcpc_lead_magnet_source_tags', $default_match_tags, $subscriber, $campaign );

        foreach ( $default_match_tags as $tag ) {
            $tag = strtolower( (string) $tag );
            if ( '' !== $tag && in_array( $tag, $tags, true ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get birthday month/day for a subscriber from tags or matching WP user meta.
     *
     * Supported formats:
     * - tag: birthday:MM-DD or birthday:YYYY-MM-DD
     * - user meta: pmcpc_birthday / birthday / birthdate
     *
     * @param object $subscriber
     * @return array{month:int,day:int,time:string}
     */
    protected function get_subscriber_birthday_parts( $subscriber ) {
        $result = array( 'month' => 0, 'day' => 0, 'time' => '09:00:00' );

        if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'get_subscriber_birthday' ) && ! empty( $subscriber->id ) ) {
            $raw = (string) PMCPC_Subscriber_Manager::get_subscriber_birthday( (int) $subscriber->id );
            if ( '' !== $raw && method_exists( 'PMCPC_Subscriber_Manager', 'parse_birthday_parts' ) ) {
                $parts = (array) PMCPC_Subscriber_Manager::parse_birthday_parts( $raw );
                if ( ! empty( $parts['month'] ) && ! empty( $parts['day'] ) ) {
                    $result['month'] = (int) $parts['month'];
                    $result['day']   = (int) $parts['day'];
                    if ( ! empty( $parts['time'] ) ) {
                        $result['time'] = (string) $parts['time'];
                    }
                    return $result;
                }
            }
        }

        $candidates = array();
        foreach ( array( 'birthday', 'birthdate', 'birth_date', 'date_of_birth', 'subscriber_birthday', 'profile_birthday', 'pmcpc_birthday' ) as $field ) {
            if ( ! empty( $subscriber->{$field} ) ) {
                $candidates[] = (string) $subscriber->{$field};
            }
        }

        if ( ! empty( $subscriber->email ) && function_exists( 'get_user_by' ) ) {
            $user = get_user_by( 'email', (string) $subscriber->email );
            if ( $user && ! empty( $user->ID ) ) {
                foreach ( array( 'pmcpc_birthday', 'birthday', 'birthdate' ) as $meta_key ) {
                    $raw = (string) get_user_meta( (int) $user->ID, $meta_key, true );
                    if ( '' !== trim( $raw ) ) {
                        $candidates[] = $raw;
                    }
                }
            }
        }

        foreach ( $candidates as $raw ) {
            if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'parse_birthday_parts' ) ) {
                $parts = (array) PMCPC_Subscriber_Manager::parse_birthday_parts( $raw );
                if ( ! empty( $parts['month'] ) && ! empty( $parts['day'] ) ) {
                    $result['month'] = (int) $parts['month'];
                    $result['day']   = (int) $parts['day'];
                    if ( ! empty( $parts['time'] ) ) {
                        $result['time'] = (string) $parts['time'];
                    }
                    return $result;
                }
            }
        }

        return $result;
    }

    /**
     * Build a site-local timestamp for today at the requested time of day.
     *
     * @param string $time_string
     * @return int
     */
    protected function build_site_local_timestamp_for_today( $time_string ) {
        $time_string = trim( (string) $time_string );
        if ( '' === $time_string ) {
            $time_string = '09:00:00';
        }

        $today = current_time( 'Y-m-d' );
        return (int) strtotime( $today . ' ' . $time_string );
    }


}
