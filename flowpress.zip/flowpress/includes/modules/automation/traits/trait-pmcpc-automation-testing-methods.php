<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Testing center and debugging methods for FlowPress automations.
 */
trait PMCPC_Automation_Testing_Methods {

    /**
     * Handle the "Run inactive scan now" admin tool.
     *
     * Runs a single batch (same size as cron) to help test win-back automations without waiting
     * for WP-Cron.
     */
    public function handle_manual_inactive_scan() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_pro_run_inactive_scan' );

        $reset   = ! empty( $_POST['pmcpc_pro_inactive_reset'] );
        $dry_run = ! empty( $_POST['pmcpc_pro_inactive_dry_run'] );
        $max_q   = isset( $_POST['pmcpc_pro_inactive_max_queue'] ) ? absint( wp_unslash( $_POST['pmcpc_pro_inactive_max_queue'] ) ) : 0;
        // Safety: cap to batch size.
        if ( $max_q > 200 ) {
            $max_q = 200;
        }
        $stats = $this->run_inactive_scan_batch( $reset, $dry_run, $max_q );

        $redirect_url = add_query_arg(
            array(
                'page'                 => 'pmcpc_automations',
                'pmcpc_pro_scan'       => 1,
                'processed'            => isset( $stats['processed'] ) ? absint( $stats['processed'] ) : 0,
                'queued'               => isset( $stats['queued'] ) ? absint( $stats['queued'] ) : 0,
                'offset_before'        => isset( $stats['offset_before'] ) ? absint( $stats['offset_before'] ) : 0,
                'offset_after'         => isset( $stats['offset_after'] ) ? absint( $stats['offset_after'] ) : 0,
                'done'                 => ! empty( $stats['done'] ) ? 1 : 0,
                'dry_run'              => $dry_run ? 1 : 0,
                'max_queue'            => $max_q,
                'pmcpc_test_tab'       => 'customer_scan',
            ),
            admin_url( 'admin.php' )
        );

	    // Hard safety: never pass null/false into wp_safe_redirect (avoids PHP 8.1+ deprecation warnings).
	    if ( empty( $redirect_url ) ) {
	        $redirect_url = admin_url( 'admin.php?page=pmcpc_pro_automations' );
	    }

        wp_safe_redirect( $redirect_url );
        exit;
    }


    /**
     * Handle the "Simulate trigger" admin tool.
     *
     * Runs the trigger logic for a single subscriber (by email) and optionally queues emails.
     *
     * @return void
     */
    public function handle_manual_simulate_trigger() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_pro_simulate_trigger' );

        $email   = isset( $_POST['pmcpc_pro_sim_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_pro_sim_email'] ) ) : '';
        $trigger = isset( $_POST['pmcpc_pro_sim_trigger'] ) ? sanitize_key( wp_unslash( $_POST['pmcpc_pro_sim_trigger'] ) ) : '';
        $dry_run = false;
        if ( ! empty( $_POST['pmcpc_pro_sim_dry_run'] ) ) {
            $dry_run = true;
        }
        if ( isset( $_POST['pmcpc_pro_sim_mode'] ) ) {
            $mode = sanitize_key( wp_unslash( $_POST['pmcpc_pro_sim_mode'] ) );
            if ( 'dry' === $mode ) {
                $dry_run = true;
            } elseif ( 'queue' === $mode ) {
                $dry_run = false;
            }
        }

        $stats = array(
            'email'          => $email,
            'trigger'        => $trigger,
            'campaigns'      => 0,
            'eligible'       => 0,
            'queued'         => 0,
            'details'        => array(),
            'error'          => '',
        );

        if ( empty( $email ) || empty( $trigger ) ) {
            $stats['error'] = __( 'Please provide a subscriber email and choose a trigger.', 'product-mailer-campaigns' );
        } else {
            $subscriber = $this->get_subscriber_by_email( $email );
            if ( ! $subscriber ) {
                $stats['error'] = __( 'Subscriber not found for that email.', 'product-mailer-campaigns' );
            } else {
                $stats = array_merge( $stats, $this->simulate_trigger_for_subscriber( $trigger, $subscriber, $dry_run ) );
            }
        }

        // Store details in a short-lived transient so we can render a readable breakdown.
        // Always create a transient (even if empty) so the UI can show 'no matches' inline.
        $details_key = 'pmcpc_pro_sim_' . get_current_user_id() . '_' . wp_generate_password( 8, false, false );
        $details     = array();
        if ( isset( $stats['details'] ) && is_array( $stats['details'] ) ) {
            $details = $stats['details'];
        }
        $history_key = '';
        if ( ! empty( $stats['error'] ) ) {
            // Don't store anything on error.
            $details_key = '';
        } else {
            set_transient( $details_key, $details, 10 * MINUTE_IN_SECONDS );
            $history = $this->get_recent_simulation_history_for_subscriber( $subscriber );
            if ( ! empty( $history ) ) {
                $history_key = 'pmcpc_pro_hist_' . get_current_user_id() . '_' . wp_generate_password( 8, false, false );
                set_transient( $history_key, $history, 10 * MINUTE_IN_SECONDS );
            }
        }

        $redirect_url = add_query_arg(
            array(
                'page'            => 'pmcpc_automations',
                'pmcpc_pro_sim'   => 1,
                'trigger'         => rawurlencode( (string) $stats['trigger'] ),
                'email'           => rawurlencode( (string) $stats['email'] ),
                'campaigns'       => absint( $stats['campaigns'] ),
                'eligible'        => absint( $stats['eligible'] ),
                'queued'          => absint( $stats['queued'] ),
                'dry_run'         => $dry_run ? 1 : 0,
                'details_key'     => rawurlencode( (string) $details_key ),
                'history_key'     => rawurlencode( (string) $history_key ),
                'error'           => rawurlencode( (string) $stats['error'] ),
                'pmcpc_test_tab'  => isset( $_POST['pmcpc_test_tab'] ) ? sanitize_key( wp_unslash( $_POST['pmcpc_test_tab'] ) ) : 'quick_test',
            ),
            admin_url( 'admin.php' )
        );

	    // Hard safety: never pass null/false into wp_safe_redirect (avoids PHP 8.1+ deprecation warnings).
	    if ( empty( $redirect_url ) ) {
	        $redirect_url = admin_url( 'admin.php?page=pmcpc_pro_automations' );
	    }

        wp_safe_redirect( $redirect_url );
        exit;
    }



    /**
     * Handle the abandoned cart debugger lookup admin tool.
     *
     * @return void
     */
    public function handle_manual_debug_abandoned_cart() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_pro_debug_abandoned_cart' );

        $email = isset( $_POST['pmcpc_pro_debug_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_pro_debug_email'] ) ) : '';

        $args = array(
            'page'                => 'pmcpc_automations',
            'pmcpc_ab_cart_debug' => 1,
            'debug_email'         => rawurlencode( (string) $email ),
            'pmcpc_test_tab'      => 'cart_inspector',
        );

        if ( empty( $email ) || ! is_email( $email ) ) {
            $args['debug_error'] = rawurlencode( __( 'Please enter a valid customer email address.', 'product-mailer-campaigns' ) );
        }

        $redirect_url = add_query_arg( $args, admin_url( 'admin.php' ) );
        if ( empty( $redirect_url ) ) {
            $redirect_url = admin_url( 'admin.php?page=pmcpc_automations' );
        }

        wp_safe_redirect( $redirect_url );
        exit;
    }


    /**
     * Force the latest cart for an email into abandoned state.
     *
     * @return void
     */
    public function handle_manual_force_abandoned_cart() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_pro_force_abandoned_cart' );

        $email = isset( $_POST['pmcpc_pro_debug_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_pro_debug_email'] ) ) : '';
        $notice = $this->update_latest_cart_debug_state( $email, 'force_abandoned' );

        $redirect_url = add_query_arg(
            array(
                'page'                => 'pmcpc_automations',
                'pmcpc_ab_cart_debug' => 1,
                'debug_email'         => rawurlencode( (string) $email ),
                'pmcpc_test_tab'      => 'cart_inspector',
                'pmcpc_notice'        => rawurlencode( (string) $notice ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect_url );
        exit;
    }

    /**
     * Force the latest abandoned-cart recovery sequence to start now.
     *
     * @return void
     */
    public function handle_manual_start_abandoned_recovery() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_pro_start_abandoned_recovery' );

        $email  = isset( $_POST['pmcpc_pro_debug_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_pro_debug_email'] ) ) : '';
        $notice = $this->update_latest_cart_debug_state( $email, 'start_recovery_now' );

        if ( class_exists( 'PMCPC_Abandoned_Carts' ) && method_exists( 'PMCPC_Abandoned_Carts', 'process_recovery_queue' ) ) {
            PMCPC_Abandoned_Carts::process_recovery_queue();
        }

        $redirect_url = add_query_arg(
            array(
                'page'                => 'pmcpc_automations',
                'pmcpc_ab_cart_debug' => 1,
                'debug_email'         => rawurlencode( (string) $email ),
                'pmcpc_test_tab'      => 'cart_inspector',
                'pmcpc_notice'        => rawurlencode( (string) $notice ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect_url );
        exit;
    }


    /**
     * Queue the next abandoned-cart step immediately for the latest cart row.
     *
     * @return void
     */
    public function handle_manual_queue_abandoned_step_now() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_pro_queue_abandoned_step_now' );

        $email  = isset( $_POST['pmcpc_pro_debug_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_pro_debug_email'] ) ) : '';
        $notice = $this->update_latest_cart_debug_state( $email, 'queue_step_now' );

        if ( class_exists( 'PMCPC_Abandoned_Carts' ) && method_exists( 'PMCPC_Abandoned_Carts', 'process_recovery_queue' ) ) {
            PMCPC_Abandoned_Carts::process_recovery_queue();
        }

        $redirect_url = add_query_arg(
            array(
                'page'                => 'pmcpc_automations',
                'pmcpc_ab_cart_debug' => 1,
                'debug_email'         => rawurlencode( (string) $email ),
                'pmcpc_test_tab'      => 'cart_inspector',
                'pmcpc_notice'        => rawurlencode( (string) $notice ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect_url );
        exit;
    }

    /**
     * Adjust the testing-center time offset and optionally run follow-up processors.
     *
     * @return void
     */
    public function handle_manual_adjust_testing_time() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_pro_adjust_testing_time' );

        $direction = isset( $_POST['pmcpc_time_direction'] ) ? sanitize_key( wp_unslash( $_POST['pmcpc_time_direction'] ) ) : 'forward';
        $minutes   = isset( $_POST['pmcpc_time_minutes'] ) ? absint( wp_unslash( $_POST['pmcpc_time_minutes'] ) ) : 0;
        $current   = (int) get_option( 'pmcpc_testing_time_offset_minutes', 0 );

        if ( 'reset' === $direction ) {
            $current = 0;
        } elseif ( $minutes > 0 ) {
            $current += ( 'backward' === $direction ? -1 : 1 ) * $minutes;
        }

        update_option( 'pmcpc_testing_time_offset_minutes', (int) $current, false );

        if ( class_exists( 'PMCPC_Abandoned_Carts' ) ) {
            if ( method_exists( 'PMCPC_Abandoned_Carts', 'sweep_abandoned' ) ) {
                PMCPC_Abandoned_Carts::sweep_abandoned();
            }
            if ( method_exists( 'PMCPC_Abandoned_Carts', 'process_recovery_queue' ) ) {
                PMCPC_Abandoned_Carts::process_recovery_queue();
            }
        }
        if ( class_exists( 'PMCPC_Queue_Processor' ) && method_exists( 'PMCPC_Queue_Processor', 'process_queue' ) ) {
            PMCPC_Queue_Processor::process_queue();
        }

        $notice = 0 === $current
            ? __( 'Automation Time Travel was reset to real time.', 'product-mailer-campaigns' )
            : sprintf( __( 'Automation Time Travel is now %s from real time.', 'product-mailer-campaigns' ), $this->format_time_offset_minutes( $current ) );

        $redirect_url = add_query_arg(
            array(
                'page'           => 'pmcpc_automations',
                'pmcpc_test_tab' => 'time_travel',
                'pmcpc_notice'   => rawurlencode( (string) $notice ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect_url );
        exit;
    }


    /**
     * Run the queue processor from the testing center.
     *
     * @return void
     */
    public function handle_manual_run_queue_processor() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_pro_run_queue_processor' );

        $notice = __( 'The email queue processor ran once. Refresh the queue inspector below to see the latest statuses.', 'product-mailer-campaigns' );
        if ( class_exists( 'PMCPC_Queue_Processor' ) && method_exists( 'PMCPC_Queue_Processor', 'process_queue' ) ) {
            PMCPC_Queue_Processor::process_queue();
        } else {
            $notice = __( 'Queue processor class is not available on this request.', 'product-mailer-campaigns' );
        }

        $redirect_url = add_query_arg(
            array(
                'page'           => 'pmcpc_automations',
                'pmcpc_test_tab' => 'email_queue',
                'pmcpc_notice'   => rawurlencode( (string) $notice ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect_url );
        exit;
    }


    /**
     * Run a birthday / anniversary trigger scan immediately from the testing center.
     *
     * Supports scanning all matching subscribers for a trigger, or a single subscriber when an email is supplied.
     *
     * @return void
     */
    public function handle_manual_run_profile_trigger_scan() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_pro_run_profile_trigger_scan' );

        $trigger = isset( $_POST['pmcpc_profile_scan_trigger'] ) ? sanitize_key( wp_unslash( $_POST['pmcpc_profile_scan_trigger'] ) ) : 'subscriber_birthday';
        $email   = isset( $_POST['pmcpc_profile_scan_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_profile_scan_email'] ) ) : '';

        if ( ! in_array( $trigger, array( 'subscriber_birthday', 'subscriber_anniversary' ), true ) ) {
            $trigger = 'subscriber_birthday';
        }

        $queued = 0;
        if ( ! empty( $email ) ) {
            $queued = $this->run_core_trigger_scan_for_subscriber( $trigger, $email );
            $notice = $queued > 0
                ? sprintf(
                    /* translators: 1: trigger label, 2: count, 3: email */
                    __( '%1$s scan queued %2$d email(s) for %3$s. You can now run the queue processor or review the queue below.', 'product-mailer-campaigns' ),
                    $this->get_profile_trigger_scan_label( $trigger ),
                    (int) $queued,
                    $email
                )
                : sprintf(
                    /* translators: 1: trigger label, 2: email */
                    __( '%1$s scan found nothing to queue for %2$s right now. Check the trigger match first, then run the scan again.', 'product-mailer-campaigns' ),
                    $this->get_profile_trigger_scan_label( $trigger ),
                    $email
                );
        } else {
            $queued = (int) $this->run_core_trigger_scan( $trigger );
            $notice = $queued > 0
                ? sprintf(
                    /* translators: 1: trigger label, 2: count */
                    __( '%1$s scan queued %2$d email(s). You can now run the queue processor or review the queue below.', 'product-mailer-campaigns' ),
                    $this->get_profile_trigger_scan_label( $trigger ),
                    (int) $queued
                )
                : sprintf(
                    /* translators: %s: trigger label */
                    __( '%s scan found nothing to queue right now.', 'product-mailer-campaigns' ),
                    $this->get_profile_trigger_scan_label( $trigger )
                );
        }

        $redirect_url = add_query_arg(
            array(
                'page'           => 'pmcpc_automations',
                'pmcpc_test_tab' => 'email_queue',
                'pmcpc_notice'   => rawurlencode( (string) $notice ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect_url );
        exit;
    }

    /**
     * Run a birthday / anniversary scan for one subscriber email.
     *
     * @param string $trigger Supported core trigger key.
     * @param string $email   Subscriber email.
     * @return int
     */
    protected function run_core_trigger_scan_for_subscriber( $trigger, $email ) {
        global $wpdb;

        if ( ! class_exists( 'PMCPC_Campaign_Manager' ) ) {
            return 0;
        }

        $trigger = sanitize_key( (string) $trigger );
        $email   = sanitize_email( (string) $email );
        if ( empty( $trigger ) || empty( $email ) || ! is_email( $email ) ) {
            return 0;
        }

        $subscriber = $this->get_subscriber_by_email( $email );
        if ( ! $subscriber || empty( $subscriber->id ) ) {
            return 0;
        }

        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        $campaigns = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM %i WHERE automation_trigger = %s AND status = %s ORDER BY id ASC',
                $campaigns_table,
                $trigger,
                'active'
            )
        );

        if ( empty( $campaigns ) || ! is_array( $campaigns ) ) {
            return 0;
        }

        $queued = 0;
        foreach ( $campaigns as $campaign ) {
            $event_ts = $this->get_core_trigger_event_timestamp( $trigger, $subscriber, $campaign );
            if ( ! $event_ts ) {
                continue;
            }
            if ( $this->maybe_queue_core_trigger_campaign( $trigger, $campaign, $subscriber, $event_ts ) ) {
                $queued++;
            }
        }

        if ( class_exists( 'PMCPC_Automation_Debug_Log' ) ) {
            PMCPC_Automation_Debug_Log::log(
                'core_trigger_scan',
                sprintf( 'Manual profile/date trigger scan completed: %s queued %d item(s) for %s.', str_replace( '_', ' ', $trigger ), (int) $queued, $email ),
                array(
                    'trigger' => $trigger,
                    'queued'  => (string) $queued,
                    'email'   => $email,
                )
            );
        }

        return $queued;
    }

    /**
     * Get a friendly label for a profile/date trigger scan.
     *
     * @param string $trigger Trigger key.
     * @return string
     */
    protected function get_profile_trigger_scan_label( $trigger ) {
        $labels = array(
            'subscriber_birthday'    => __( 'Birthday', 'product-mailer-campaigns' ),
            'subscriber_anniversary' => __( 'Anniversary', 'product-mailer-campaigns' ),
        );

        return isset( $labels[ $trigger ] ) ? $labels[ $trigger ] : __( 'Profile/date', 'product-mailer-campaigns' );
    }

    /**
     * Update the latest abandoned-cart row for a given email.
     *
     * @param string $email Customer email.
     * @param string $mode  Action mode.
     * @return string
     */
    protected function update_latest_cart_debug_state( $email, $mode ) {
        global $wpdb;

        $table = $wpdb->prefix . 'pmcpc_abandoned_carts';
        $email = sanitize_email( $email );
        $mode  = sanitize_key( $mode );

        if ( empty( $email ) || ! is_email( $email ) ) {
            return __( 'Please enter a valid customer email address first.', 'product-mailer-campaigns' );
        }

        $cart_id = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . $table . ' WHERE email = %s ORDER BY updated_at DESC, id DESC LIMIT 1', $email ) );
        if ( $cart_id <= 0 ) {
            return __( 'No cart row was found for that email address.', 'product-mailer-campaigns' );
        }

        $now = $this->get_testing_now_mysql();
        $data = array(
            'status'                => 'abandoned',
            'abandoned_at'          => $now,
            'updated_at'            => $now,
            'recovered_at'          => null,
            'recovery_step'         => 0,
            'recovery_completed_at' => null,
        );
        $formats = array( '%s', '%s', '%s', '%s', '%d', '%s' );

        if ( 'start_recovery_now' === $mode ) {
            $data['recovery_status']     = 'in_progress';
            $data['recovery_next_at']    = $now;
            $data['recovery_started_at'] = $now;
            $formats[] = '%s';
            $formats[] = '%s';
            $formats[] = '%s';
        } elseif ( 'queue_step_now' === $mode ) {
            $data['recovery_status']     = 'in_progress';
            $data['recovery_next_at']    = $now;
            $data['recovery_started_at'] = $now;
            $formats[] = '%s';
            $formats[] = '%s';
            $formats[] = '%s';
        } else {
            $data['recovery_status']     = 'none';
            $data['recovery_next_at']    = null;
            $data['recovery_started_at'] = null;
            $formats[] = '%s';
            $formats[] = '%s';
            $formats[] = '%s';
        }

        $wpdb->update( $table, $data, array( 'id' => $cart_id ), $formats, array( '%d' ) );

        if ( class_exists( 'PMCPC_Abandoned_Carts' ) && method_exists( 'PMCPC_Abandoned_Carts', 'process_recovery_queue' ) && 'force_abandoned' === $mode ) {
            PMCPC_Abandoned_Carts::process_recovery_queue();
        }

        if ( 'start_recovery_now' === $mode ) {
            return __( 'Recovery was started for the latest cart row. If Step 1 is active, it should now be eligible to queue.', 'product-mailer-campaigns' );
        }
        if ( 'queue_step_now' === $mode ) {
            return __( 'The next abandoned-cart step was made eligible right now and the recovery processor was run once.', 'product-mailer-campaigns' );
        }
        return __( 'The latest cart row was marked as abandoned. The normal recovery timing now applies from this point.', 'product-mailer-campaigns' );
    }

    /**
     * Return the active testing-center tab.
     *
     * @return string
     */
    protected function get_automation_test_center_active_tab() {
        $tab = isset( $_GET['pmcpc_test_tab'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_test_tab'] ) ) : '';
        $allowed = array( 'quick_test', 'cart_inspector', 'trigger_simulator', 'customer_scan', 'email_queue', 'diagnostics', 'customer_simulation', 'time_travel', 'activity_feed' );
        if ( in_array( $tab, $allowed, true ) ) {
            return $tab;
        }
        if ( isset( $_GET['pmcpc_ab_cart_debug'] ) ) {
            return 'cart_inspector';
        }
        if ( isset( $_GET['pmcpc_customer_simulation'] ) ) {
            return 'customer_simulation';
        }
        if ( isset( $_GET['pmcpc_pro_scan'] ) ) {
            return 'customer_scan';
        }
        if ( isset( $_GET['pmcpc_pro_sim'] ) ) {
            return 'quick_test';
        }
        return 'quick_test';
    }


    /**
     * Render the all-in-one automation testing center.
     *
     * @return void
     */
    protected function render_testing_center_panel() {
        $active_tab             = $this->get_automation_test_center_active_tab();
        $debug_email            = isset( $_GET['debug_email'] ) ? sanitize_email( wp_unslash( $_GET['debug_email'] ) ) : '';
        $debug_error            = isset( $_GET['debug_error'] ) ? sanitize_text_field( wp_unslash( $_GET['debug_error'] ) ) : '';
        $customer_sim_email     = isset( $_GET['pmcpc_sim_customer_email'] ) ? sanitize_email( wp_unslash( $_GET['pmcpc_sim_customer_email'] ) ) : '';
        $automation_notice      = isset( $_GET['pmcpc_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['pmcpc_notice'] ) ) : '';
        $details                = array();
        $has_breakdown          = false;
        $queue_rows             = $this->get_recent_automation_queue_rows( 10 );
        $diagnostics            = $this->get_automation_diagnostics_rows();
        $customer_simulation    = null;
        $customer_profile_test  = null;
        $profile_test_trigger   = isset( $_GET['pmcpc_profile_trigger'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_profile_trigger'] ) ) : 'subscriber_birthday';
        $profile_test_birthday  = isset( $_GET['pmcpc_profile_birthday'] ) ? sanitize_text_field( wp_unslash( $_GET['pmcpc_profile_birthday'] ) ) : '';
        $profile_test_anniv     = isset( $_GET['pmcpc_profile_anniversary'] ) ? sanitize_text_field( wp_unslash( $_GET['pmcpc_profile_anniversary'] ) ) : '';
        $profile_test_eval_date = isset( $_GET['pmcpc_profile_eval_date'] ) ? sanitize_text_field( wp_unslash( $_GET['pmcpc_profile_eval_date'] ) ) : gmdate( 'Y-m-d' );

        if ( isset( $_GET['details_key'] ) ) {
            $details_key = sanitize_text_field( wp_unslash( $_GET['details_key'] ) );
            if ( $details_key ) {
                $details = get_transient( $details_key );
                if ( is_array( $details ) ) {
                    $has_breakdown = true;
                }
            }
        }

        if ( $customer_sim_email ) {
            $customer_simulation = $this->get_customer_simulation_data( $customer_sim_email );
            if ( isset( $_GET['pmcpc_run_profile_test'] ) ) {
                $customer_profile_test = $this->get_profile_trigger_test_data( $customer_sim_email, $profile_test_trigger, $profile_test_birthday, $profile_test_anniv, $profile_test_eval_date );
            }
        }

        $tabs = array(
            'quick_test' => array( 'label' => __( 'Quick Test', 'product-mailer-campaigns' ), 'icon' => '🧪' ),
            'cart_inspector' => array( 'label' => __( 'Cart Inspector', 'product-mailer-campaigns' ), 'icon' => '🛒' ),
            'trigger_simulator' => array( 'label' => __( 'Trigger Simulator', 'product-mailer-campaigns' ), 'icon' => '⚙' ),
            'customer_scan' => array( 'label' => __( 'Customer Scan', 'product-mailer-campaigns' ), 'icon' => '📉' ),
            'email_queue' => array( 'label' => __( 'Waiting to Send', 'product-mailer-campaigns' ), 'icon' => '📬' ),
            'diagnostics' => array( 'label' => __( 'Diagnostics', 'product-mailer-campaigns' ), 'icon' => '🔍' ),
            'customer_simulation' => array( 'label' => __( 'Customer Simulation', 'product-mailer-campaigns' ), 'icon' => '🧍' ),
            'time_travel' => array( 'label' => __( 'Time Travel', 'product-mailer-campaigns' ), 'icon' => '⏩' ),
            'activity_feed' => array( 'label' => __( 'Activity Feed', 'product-mailer-campaigns' ), 'icon' => '🕘' ),
        );

        echo '<div class="card pmcpc-card pmcpc-testing-center" data-pmcpc-testing-center="1">';
        echo '<div class="pmcpc-testing-center__header">';
        echo '<div class="pmcpc-testing-center__header-main">';
        echo '<div class="pmcpc-testing-center__heading">';
        echo '<h2 class="pmcpc-testing-center__title">' . esc_html__( 'Automation Testing Center', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p class="pmcpc-testing-center__intro">' . esc_html__( 'Test automation triggers, inspect abandoned carts, run customer scans, and diagnose queued emails from one place. Keep this panel collapsed until you need it, then open the exact tool you need.', 'product-mailer-campaigns' ) . '</p>';
        echo '</div>';
        echo '<button type="button" class="button button-secondary pmcpc-testing-center__toggle" aria-expanded="true">' . esc_html__( 'Collapse testing center', 'product-mailer-campaigns' ) . '</button>';
        echo '</div>';
        echo '<p class="pmcpc-testing-center__collapsed-note" hidden>' . esc_html__( 'Testing tools are collapsed. Expand the center to run a test or inspect a customer.', 'product-mailer-campaigns' ) . '</p>';
        echo '</div>';

        echo '<div class="pmcpc-testing-center__body">';
        echo '<div class="pmcpc-testing-center__tabs" role="tablist" aria-label="' . esc_attr__( 'Automation testing tabs', 'product-mailer-campaigns' ) . '">';
        foreach ( $tabs as $tab_key => $tab ) {
            $is_active = $active_tab === $tab_key;
            echo '<a href="#pmcpc-tool-' . esc_attr( $tab_key ) . '" class="pmcpc-testing-center__tab' . ( $is_active ? ' is-active' : '' ) . '" data-pmcpc-tab="' . esc_attr( $tab_key ) . '" role="tab" aria-selected="' . ( $is_active ? 'true' : 'false' ) . '">';
            echo '<span class="pmcpc-testing-center__tab-icon">' . esc_html( $tab['icon'] ) . '</span>';
            echo '<span>' . esc_html( $tab['label'] ) . '</span>';
            echo '</a>';
        }
        echo '</div>';

        echo '<div class="pmcpc-testing-center__panes">';

        // Quick test pane.
        echo '<section id="pmcpc-tool-quick_test" class="pmcpc-testing-center__pane' . ( 'quick_test' === $active_tab ? ' is-active' : '' ) . '" data-pmcpc-pane="quick_test">';
        echo '<h3>' . esc_html__( 'Quick Automation Test', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="description">' . esc_html__( 'Send or simulate a single automation email for one subscriber. This is the fastest way to verify that a template, audience rule, and queue handoff all work together.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="pmcpc-testing-center__form-grid">';
        echo '<input type="hidden" name="action" value="pmcpc_pro_simulate_trigger" />';
        echo '<input type="hidden" name="pmcpc_test_tab" value="quick_test" />';
        wp_nonce_field( 'pmcpc_pro_simulate_trigger' );
        echo '<p><label><strong>' . esc_html__( 'Subscriber email', 'product-mailer-campaigns' ) . '</strong></label><input type="email" class="regular-text pmcpc-email-autocomplete" name="pmcpc_pro_sim_email" list="pmcpc_pro_subscriber_suggestions" placeholder="name@example.com" required /></p>';
        echo '<p><label><strong>' . esc_html__( 'Automation step', 'product-mailer-campaigns' ) . '</strong></label>';
        echo '<select name="pmcpc_pro_sim_trigger">';
        $selected        = isset( $_GET['trigger'] ) ? sanitize_key( wp_unslash( $_GET['trigger'] ) ) : 'post_purchase';
        $trigger_options = $this->get_selectable_and_disabled_trigger_options( 'quick_test' );
        foreach ( $trigger_options['selectable'] as $trigger_key => $trigger_label ) {
            echo '<option value="' . esc_attr( $trigger_key ) . '"' . selected( $selected, $trigger_key, false ) . '>' . esc_html( $trigger_label ) . '</option>';
        }
        if ( ! empty( $trigger_options['disabled'] ) ) {
            echo '<optgroup label="' . esc_attr__( 'Unavailable in Quick Test', 'product-mailer-campaigns' ) . '">';
            foreach ( $trigger_options['disabled'] as $trigger_key => $trigger_label ) {
                echo '<option value="' . esc_attr( $trigger_key ) . '" disabled="disabled"' . selected( $selected, $trigger_key, false ) . '>' . esc_html( $trigger_label ) . '</option>';
            }
            echo '</optgroup>';
        }
        echo '</select>';
        echo '<span class="description" style="display:block;margin-top:6px;">' . esc_html__( 'Quick Test only lets you pick triggers that can be meaningfully tested here. Use Customer Simulation for birthday or anniversary tests, Customer Scan / Time Travel for inactivity checks, and scheduled campaigns / Time Travel for date-based sends.', 'product-mailer-campaigns' ) . '</span></p>';
        echo '<div class="pmcpc-testing-center__actions"><button type="submit" class="button" name="pmcpc_pro_sim_mode" value="dry">' . esc_html__( 'Preview result', 'product-mailer-campaigns' ) . '</button><button type="submit" class="button button-primary" name="pmcpc_pro_sim_mode" value="queue">' . esc_html__( 'Send test email', 'product-mailer-campaigns' ) . '</button></div>';
        echo '</form>';
        echo '<p class="description">' . esc_html__( 'Dry run shows what would happen. Send test email queues the selected automation for this subscriber only.', 'product-mailer-campaigns' ) . '</p>';
        if ( isset( $_GET['pmcpc_pro_sim'] ) && 'quick_test' === $active_tab ) {
            $this->render_simulation_result_box();
            $this->render_simulation_breakdown_box( $details, $has_breakdown );
        }
        echo '</section>';

        // Cart inspector pane.
        echo '<section id="pmcpc-tool-cart_inspector" class="pmcpc-testing-center__pane' . ( 'cart_inspector' === $active_tab ? ' is-active' : '' ) . '" data-pmcpc-pane="cart_inspector">';
        echo '<h3>' . esc_html__( 'Cart Inspector', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="description">' . esc_html__( 'Inspect a customer’s latest cart, see when it is expected to become abandoned, and optionally force a test state without waiting.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="pmcpc-testing-center__form-grid pmcpc-testing-center__form-grid--cart">';
        echo '<input type="hidden" name="action" value="pmcpc_pro_debug_abandoned_cart" />';
        wp_nonce_field( 'pmcpc_pro_debug_abandoned_cart' );
        echo '<p><label><strong>' . esc_html__( 'Customer email', 'product-mailer-campaigns' ) . '</strong></label><input type="email" class="regular-text pmcpc-email-autocomplete" name="pmcpc_pro_debug_email" value="' . esc_attr( $debug_email ) . '" list="pmcpc_pro_subscriber_suggestions" placeholder="name@example.com" required /></p>';
        echo '<div class="pmcpc-testing-center__actions"><button type="submit" class="button button-secondary">' . esc_html__( 'Check cart', 'product-mailer-campaigns' ) . '</button></div>';
        echo '</form>';
        if ( $debug_email && 'cart_inspector' === $active_tab && $automation_notice ) {
            $this->render_testing_tool_result_box( 'success', __( 'Cart action completed.', 'product-mailer-campaigns' ), array( $automation_notice ) );
        }
        if ( $debug_email ) {
            echo '<div class="pmcpc-testing-center__actions" style="margin-top:8px;">';
            echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
            echo '<input type="hidden" name="action" value="pmcpc_pro_force_abandoned_cart" />';
            echo '<input type="hidden" name="pmcpc_pro_debug_email" value="' . esc_attr( $debug_email ) . '" />';
            wp_nonce_field( 'pmcpc_pro_force_abandoned_cart' );
            echo '<button type="submit" class="button">' . esc_html__( 'Force mark abandoned', 'product-mailer-campaigns' ) . '</button>';
            echo '</form>';
            echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
            echo '<input type="hidden" name="action" value="pmcpc_pro_start_abandoned_recovery" />';
            echo '<input type="hidden" name="pmcpc_pro_debug_email" value="' . esc_attr( $debug_email ) . '" />';
            wp_nonce_field( 'pmcpc_pro_start_abandoned_recovery' );
            echo '<button type="submit" class="button button-secondary">' . esc_html__( 'Start recovery now', 'product-mailer-campaigns' ) . '</button>';
            echo '</form>';
            echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
            echo '<input type="hidden" name="action" value="pmcpc_pro_queue_abandoned_step_now" />';
            echo '<input type="hidden" name="pmcpc_pro_debug_email" value="' . esc_attr( $debug_email ) . '" />';
            wp_nonce_field( 'pmcpc_pro_queue_abandoned_step_now' );
            echo '<button type="submit" class="button button-primary">' . esc_html__( 'Queue step now', 'product-mailer-campaigns' ) . '</button>';
            echo '</form>';
            echo '</div>';
        }
        if ( $debug_error ) {
            echo '<div class="notice notice-error inline"><p>' . esc_html( $debug_error ) . '</p></div>';
        }
        if ( $debug_email && ! $debug_error ) {
            $data = $this->get_abandoned_cart_debug_data( $debug_email );
            if ( ! empty( $data['error'] ) ) {
                echo '<div class="notice notice-error inline"><p>' . esc_html( $data['error'] ) . '</p></div>';
            } else {
                if ( ! empty( $data['summary_html'] ) ) {
                    echo '<div class="pmcpc-summary-box">' . wp_kses_post( $data['summary_html'] ) . '</div>';
                }
                if ( ! empty( $data['timeline_html'] ) ) {
                    echo '<div class="pmcpc-summary-box pmcpc-summary-box--timeline">' . wp_kses_post( $data['timeline_html'] ) . '</div>';
                }
                if ( ! empty( $data['copy_report'] ) ) {
                    echo '<div class="pmcpc-testing-center__actions pmcpc-testing-center__actions--tight">';
                    echo '<button type="button" class="button button-secondary pmcpc-copy-debug-report" data-debug-report="' . esc_attr( $data['copy_report'] ) . '">' . esc_html__( 'Copy debug report', 'product-mailer-campaigns' ) . '</button>';
                    echo '<span class="pmcpc-copy-debug-report__status" aria-live="polite"></span>';
                    echo '</div>';
                }
                echo '<table class="widefat striped pmcpc-debug-table"><tbody>';
                foreach ( $data['rows'] as $row ) {
                    echo '<tr><th style="width:240px;">' . esc_html( $row['label'] ) . '</th><td>' . wp_kses_post( $row['value'] ) . '</td></tr>';
                }
                echo '</tbody></table>';
                if ( ! empty( $data['queue_rows'] ) ) {
                    echo '<h4>' . esc_html__( 'Recent abandoned-cart emails', 'product-mailer-campaigns' ) . '</h4>';
                    echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Scheduled', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Trigger', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
                    foreach ( $data['queue_rows'] as $item ) {
                        echo '<tr><td>' . esc_html( $this->format_debug_datetime( $item['scheduled_at'] ) ) . '</td><td>' . esc_html( $item['campaign_name'] ) . '</td><td>' . esc_html( $item['automation_trigger'] ) . '</td><td>' . esc_html( $item['status'] ) . '</td></tr>';
                    }
                    echo '</tbody></table>';
                }
            }
        }
        echo '</section>';

        // Trigger simulator pane.
        echo '<section id="pmcpc-tool-trigger_simulator" class="pmcpc-testing-center__pane' . ( 'trigger_simulator' === $active_tab ? ' is-active' : '' ) . '" data-pmcpc-pane="trigger_simulator">';
        echo '<h3>' . esc_html__( 'Trigger Simulator', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="description">' . esc_html__( 'Use this when you want to think about the trigger first. It checks which campaigns match right now for a subscriber without creating a real order, signup, or cart.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="pmcpc-testing-center__form-grid">';
        echo '<input type="hidden" name="action" value="pmcpc_pro_simulate_trigger" />';
        echo '<input type="hidden" name="pmcpc_test_tab" value="trigger_simulator" />';
        wp_nonce_field( 'pmcpc_pro_simulate_trigger' );
        echo '<p><label><strong>' . esc_html__( 'Subscriber email', 'product-mailer-campaigns' ) . '</strong></label><input type="email" class="regular-text pmcpc-email-autocomplete" name="pmcpc_pro_sim_email" list="pmcpc_pro_subscriber_suggestions" placeholder="name@example.com" required /></p>';
        echo '<p><label><strong>' . esc_html__( 'Trigger', 'product-mailer-campaigns' ) . '</strong></label>';
        echo '<select name="pmcpc_pro_sim_trigger">';
        $selected        = isset( $_GET['trigger'] ) ? sanitize_key( wp_unslash( $_GET['trigger'] ) ) : 'post_purchase';
        $trigger_options = $this->get_selectable_and_disabled_trigger_options( 'trigger_simulator' );
        foreach ( $trigger_options['selectable'] as $trigger_key => $trigger_label ) {
            echo '<option value="' . esc_attr( $trigger_key ) . '"' . selected( $selected, $trigger_key, false ) . '>' . esc_html( $trigger_label ) . '</option>';
        }
        if ( ! empty( $trigger_options['disabled'] ) ) {
            echo '<optgroup label="' . esc_attr__( 'Use a different testing tool', 'product-mailer-campaigns' ) . '">';
            foreach ( $trigger_options['disabled'] as $trigger_key => $trigger_label ) {
                echo '<option value="' . esc_attr( $trigger_key ) . '" disabled="disabled"' . selected( $selected, $trigger_key, false ) . '>' . esc_html( $trigger_label ) . '</option>';
            }
            echo '</optgroup>';
        }
        echo '</select></p>';
        echo '<div class="pmcpc-testing-center__actions"><button type="submit" class="button" name="pmcpc_pro_sim_mode" value="dry">' . esc_html__( 'Dry run', 'product-mailer-campaigns' ) . '</button><button type="submit" class="button button-primary" name="pmcpc_pro_sim_mode" value="queue">' . esc_html__( 'Queue automation email', 'product-mailer-campaigns' ) . '</button></div>';
        echo '</form>';
        if ( isset( $_GET['pmcpc_pro_sim'] ) && 'trigger_simulator' === $active_tab ) {
            $this->render_simulation_result_box();
            $this->render_simulation_breakdown_box( $details, $has_breakdown );
        }
        echo '</section>';

        // Customer scan pane.
        echo '<section id="pmcpc-tool-customer_scan" class="pmcpc-testing-center__pane' . ( 'customer_scan' === $active_tab ? ' is-active' : '' ) . '" data-pmcpc-pane="customer_scan">';
        echo '<h3>' . esc_html__( 'Inactive Customer Scan', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="description">' . esc_html__( 'Run the win-back scan manually instead of waiting for WP-Cron. Use dry run first on live shops so you can check the numbers before any emails are queued.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="pmcpc_pro_run_inactive_scan" />';
        wp_nonce_field( 'pmcpc_pro_run_inactive_scan' );
        echo '<label style="display:block; margin:0 0 10px 0;"><input type="checkbox" name="pmcpc_pro_inactive_reset" value="1" /> ' . esc_html__( 'Restart scan from beginning', 'product-mailer-campaigns' ) . '</label>';
        echo '<label style="display:block; margin:0 0 10px 0;"><input type="checkbox" name="pmcpc_pro_inactive_dry_run" value="1" /> ' . esc_html__( 'Dry run (report only)', 'product-mailer-campaigns' ) . '</label>';
        echo '<p><label><strong>' . esc_html__( 'Max emails to queue', 'product-mailer-campaigns' ) . '</strong></label><br /><input type="number" min="0" max="200" step="1" name="pmcpc_pro_inactive_max_queue" value="25" style="width:90px;" /> <span class="description">' . esc_html__( '0 removes the cap. Use with care on live stores.', 'product-mailer-campaigns' ) . '</span></p>';
        echo '<div class="pmcpc-testing-center__actions"><button type="submit" class="button button-secondary">' . esc_html__( 'Run scan', 'product-mailer-campaigns' ) . '</button></div>';
        echo '</form>';
        if ( isset( $_GET['pmcpc_pro_scan'] ) && 'customer_scan' === $active_tab ) {
            $this->render_scan_result_box();
        }
        echo '</section>';

        // Email queue pane.
        echo '<section id="pmcpc-tool-email_queue" class="pmcpc-testing-center__pane' . ( 'email_queue' === $active_tab ? ' is-active' : '' ) . '" data-pmcpc-pane="email_queue">';
        echo '<h3>' . esc_html__( 'Waiting Emails Inspector', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="description">' . esc_html__( 'Review the latest automation emails waiting to send or already processed. This is often the fastest way to confirm whether a trigger worked but delivery is still pending.', 'product-mailer-campaigns' ) . '</p>';
        if ( 'email_queue' === $active_tab && $automation_notice ) {
            $this->render_testing_tool_result_box( 'success', __( 'Queue action completed.', 'product-mailer-campaigns' ), array( $automation_notice ) );
        }
        echo '<div class="pmcpc-testing-center__actions">';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="pmcpc_pro_run_queue_processor" />';
        wp_nonce_field( 'pmcpc_pro_run_queue_processor' );
        echo '<button type="submit" class="button button-secondary">' . esc_html__( 'Run queue processor now', 'product-mailer-campaigns' ) . '</button></form>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="pmcpc_pro_run_profile_trigger_scan" /><input type="hidden" name="pmcpc_profile_scan_trigger" value="subscriber_birthday" />';
        wp_nonce_field( 'pmcpc_pro_run_profile_trigger_scan' );
        echo '<button type="submit" class="button">' . esc_html__( 'Run birthday scan now', 'product-mailer-campaigns' ) . '</button></form>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="pmcpc_pro_run_profile_trigger_scan" /><input type="hidden" name="pmcpc_profile_scan_trigger" value="subscriber_anniversary" />';
        wp_nonce_field( 'pmcpc_pro_run_profile_trigger_scan' );
        echo '<button type="submit" class="button">' . esc_html__( 'Run anniversary scan now', 'product-mailer-campaigns' ) . '</button></form>';
        echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_queue' ) ) . '">' . esc_html__( 'Open full queue page', 'product-mailer-campaigns' ) . '</a>';
        echo '</div>';
        echo '<p class="description" style="margin-top:8px;">' . esc_html__( 'Birthday and anniversary emails are discovered by a trigger scan first, then sent by the queue processor. If you set a birthday to today, run the relevant scan before running the queue processor.', 'product-mailer-campaigns' ) . '</p>';
        if ( empty( $queue_rows ) ) {
            echo '<p class="description">' . esc_html__( 'No recent automation queue rows were found.', 'product-mailer-campaigns' ) . '</p>';
        } else {
            echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Scheduled', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Email', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Automation', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Attempts', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
            foreach ( $queue_rows as $item ) {
                echo '<tr><td>' . esc_html( $this->format_debug_datetime( $item['scheduled_at'] ) ) . '</td><td>' . esc_html( $item['to_email'] ) . '</td><td>' . esc_html( $item['campaign_name'] ) . '</td><td>' . esc_html( $item['status'] ) . '</td><td>' . esc_html( (string) $item['attempt_count'] ) . '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</section>';

        // Activity feed pane.
        echo '<section id="pmcpc-tool-activity_feed" class="pmcpc-testing-center__pane' . ( 'activity_feed' === $active_tab ? ' is-active' : '' ) . '" data-pmcpc-pane="activity_feed">';
        echo '<h3>' . esc_html__( 'Automation Activity Feed', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="description">' . esc_html__( 'Live-style activity helps explain what happened between cart capture, queueing, and sending. Use this together with Cart Inspector when a step looks overdue.', 'product-mailer-campaigns' ) . '</p>';
        $activity_items = class_exists( 'PMCPC_Activity_Feed' ) ? PMCPC_Activity_Feed::get_items() : array();
        if ( ! empty( $debug_email ) ) {
            $activity_items = array_values( array_filter( (array) $activity_items, function( $item ) use ( $debug_email ) {
                $message = isset( $item['m'] ) ? strtolower( (string) $item['m'] ) : '';
                return '' !== $message && false !== strpos( $message, strtolower( $debug_email ) );
            } ) );
        }
        if ( empty( $activity_items ) ) {
            echo '<p class="description">' . esc_html__( 'No matching activity was logged yet. Run Queue step now, Start recovery now, or the queue processor to create entries here.', 'product-mailer-campaigns' ) . '</p>';
        } else {
            echo '<ul class="pmcpc-activity-feed">';
            foreach ( $activity_items as $item ) {
                $time = isset( $item['t'] ) ? (int) $item['t'] : 0;
                $message = isset( $item['m'] ) ? (string) $item['m'] : '';
                if ( '' === $message ) {
                    continue;
                }
                echo '<li class="pmcpc-activity-feed__item"><span class="pmcpc-activity-feed__time">' . esc_html( $time ? wp_date( 'H:i:s', $time, wp_timezone() ) : '—' ) . '</span><span class="pmcpc-activity-feed__message">' . esc_html( $message ) . '</span></li>';
            }
            echo '</ul>';
        }
        echo '</section>';

        // Diagnostics pane.
        echo '<section id="pmcpc-tool-diagnostics" class="pmcpc-testing-center__pane' . ( 'diagnostics' === $active_tab ? ' is-active' : '' ) . '" data-pmcpc-pane="diagnostics">';
        echo '<h3>' . esc_html__( 'Automation Diagnostics', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="description">' . esc_html__( 'Use this quick health check before deeper debugging. It highlights the most common reasons automations do not move from trigger to queue to sent email.', 'product-mailer-campaigns' ) . '</p>';
        echo '<div class="pmcpc-kpi-grid">';
        foreach ( $diagnostics as $item ) {
            echo '<div class="pmcpc-kpi pmcpc-kpi--' . esc_attr( $item['state'] ) . '"><strong>' . esc_html( $item['label'] ) . '</strong><span>' . esc_html( $item['value'] ) . '</span><small>' . esc_html( $item['help'] ) . '</small></div>';
        }
        echo '</div>';
        echo '</section>';

        // Time travel pane.
        echo '<section id="pmcpc-tool-time_travel" class="pmcpc-testing-center__pane' . ( 'time_travel' === $active_tab ? ' is-active' : '' ) . '" data-pmcpc-pane="time_travel">';
        echo '<h3>' . esc_html__( 'Automation Time Travel', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="description">' . esc_html__( 'Move the testing clock forward for this plugin so you can trigger delayed automations without waiting in real time. This is intended for admin testing only.', 'product-mailer-campaigns' ) . '</p>';
        $time_offset_minutes = (int) get_option( 'pmcpc_testing_time_offset_minutes', 0 );
        $testing_now_utc      = $this->get_testing_now_mysql();
        echo '<div class="pmcpc-summary-box"><div class="pmcpc-summary-box__grid">';
        echo '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Testing clock', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( $this->format_debug_datetime( $testing_now_utc ) ) . '</strong></div>';
        echo '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Offset from real time', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( $this->format_time_offset_minutes( $time_offset_minutes ) ) . '</strong></div>';
        echo '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'What updates when you travel', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html__( 'Cart sweep, recovery runner, queue processor', 'product-mailer-campaigns' ) . '</strong></div>';
        echo '</div></div>';
        echo '<div class="pmcpc-testing-center__actions">';
        foreach ( array( 15, 60, 1440 ) as $jump_minutes ) {
            echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
            echo '<input type="hidden" name="action" value="pmcpc_pro_adjust_testing_time" />';
            echo '<input type="hidden" name="pmcpc_time_direction" value="forward" />';
            echo '<input type="hidden" name="pmcpc_time_minutes" value="' . esc_attr( (string) $jump_minutes ) . '" />';
            wp_nonce_field( 'pmcpc_pro_adjust_testing_time' );
            $label = 1440 === $jump_minutes ? __( '+24 hours', 'product-mailer-campaigns' ) : sprintf( __( '+%d minutes', 'product-mailer-campaigns' ), $jump_minutes );
            if ( 60 === $jump_minutes ) {
                $label = __( '+1 hour', 'product-mailer-campaigns' );
            }
            echo '<button type="submit" class="button button-secondary">' . esc_html( $label ) . '</button>';
            echo '</form>';
        }
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="pmcpc_pro_adjust_testing_time" />';
        echo '<input type="hidden" name="pmcpc_time_direction" value="reset" />';
        wp_nonce_field( 'pmcpc_pro_adjust_testing_time' );
        echo '<button type="submit" class="button">' . esc_html__( 'Reset to real time', 'product-mailer-campaigns' ) . '</button>';
        echo '</form>';
        echo '</div>';
        echo '<p class="description">' . esc_html__( 'Tip: after jumping forward, return to Cart Inspector or Waiting to Send to confirm which automation step became due.', 'product-mailer-campaigns' ) . '</p>';
        echo '</section>';

        // Customer simulation pane.
        echo '<section id="pmcpc-tool-customer_simulation" class="pmcpc-testing-center__pane' . ( 'customer_simulation' === $active_tab ? ' is-active' : '' ) . '" data-pmcpc-pane="customer_simulation">';
        echo '<h3>' . esc_html__( 'Customer Automation Simulation', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="description">' . esc_html__( 'Enter one customer email to see a joined-up view of their subscriber record, order history, cart state, recent queued emails, and which automations match them right now.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '" class="pmcpc-testing-center__form-grid">';
        echo '<input type="hidden" name="page" value="pmcpc_automations" />';
        echo '<input type="hidden" name="pmcpc_customer_simulation" value="1" />';
        echo '<input type="hidden" name="pmcpc_test_tab" value="customer_simulation" />';
        echo '<p><label><strong>' . esc_html__( 'Customer email', 'product-mailer-campaigns' ) . '</strong></label><input type="email" class="regular-text pmcpc-email-autocomplete" name="pmcpc_sim_customer_email" value="' . esc_attr( $customer_sim_email ) . '" list="pmcpc_pro_subscriber_suggestions" placeholder="name@example.com" required /></p>';
        echo '<div class="pmcpc-testing-center__actions"><button type="submit" class="button button-primary">' . esc_html__( 'Run simulation', 'product-mailer-campaigns' ) . '</button></div>';
        echo '</form>';
        echo '<div class="pmcpc-summary-box" style="margin-top:16px;">';
        echo '<h4 style="margin-top:0;">' . esc_html__( 'Profile / Date Trigger Test', 'product-mailer-campaigns' ) . '</h4>';
        echo '<p class="description" style="margin-top:0;">' . esc_html__( 'Use this to preview birthday, anniversary, and specific-date triggers by supplying the profile/date values those triggers depend on.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '" class="pmcpc-testing-center__form-grid">';
        echo '<input type="hidden" name="page" value="pmcpc_automations" />';
        echo '<input type="hidden" name="pmcpc_customer_simulation" value="1" />';
        echo '<input type="hidden" name="pmcpc_test_tab" value="customer_simulation" />';
        echo '<input type="hidden" name="pmcpc_run_profile_test" value="1" />';
        echo '<p><label><strong>' . esc_html__( 'Customer email', 'product-mailer-campaigns' ) . '</strong></label><input type="email" class="regular-text pmcpc-email-autocomplete" name="pmcpc_sim_customer_email" value="' . esc_attr( $customer_sim_email ) . '" list="pmcpc_pro_subscriber_suggestions" placeholder="name@example.com" required /></p>';
        echo '<p><label><strong>' . esc_html__( 'Trigger to test', 'product-mailer-campaigns' ) . '</strong></label><select name="pmcpc_profile_trigger" class="pmcpc-profile-trigger-select">';
        foreach ( $this->get_profile_test_trigger_options() as $profile_key => $profile_label ) {
            echo '<option value="' . esc_attr( $profile_key ) . '"' . selected( $profile_test_trigger, $profile_key, false ) . '>' . esc_html( $profile_label ) . '</option>';
        }
        echo '</select><span class="description pmcpc-profile-trigger-help" style="display:block;margin-top:6px;">' . esc_html( $this->get_profile_trigger_test_help_text( $profile_test_trigger ) ) . '</span></p>';
        echo '<p class="pmcpc-profile-field-wrap pmcpc-profile-field-wrap--birthday"><label><strong>' . esc_html__( 'Birthday (optional)', 'product-mailer-campaigns' ) . '</strong></label><input type="date" name="pmcpc_profile_birthday" class="pmcpc-profile-field-birthday" value="' . esc_attr( $profile_test_birthday ) . '" /></p>';
        echo '<p class="pmcpc-profile-field-wrap pmcpc-profile-field-wrap--anniversary"><label><strong>' . esc_html__( 'Anniversary / join date (optional)', 'product-mailer-campaigns' ) . '</strong></label><input type="date" name="pmcpc_profile_anniversary" class="pmcpc-profile-field-anniversary" value="' . esc_attr( $profile_test_anniv ) . '" /></p>';
        echo '<p><label><strong>' . esc_html__( 'Evaluate as of date', 'product-mailer-campaigns' ) . '</strong></label><input type="date" name="pmcpc_profile_eval_date" value="' . esc_attr( $profile_test_eval_date ) . '" required /></p>';
        echo '<div class="pmcpc-testing-center__actions"><button type="submit" class="button button-secondary">' . esc_html__( 'Preview trigger match', 'product-mailer-campaigns' ) . '</button></div>';
        echo '</form>';
        if ( is_array( $customer_profile_test ) ) {
            if ( ! empty( $customer_profile_test['error'] ) ) {
                echo '<div class="notice notice-error inline"><p>' . esc_html( $customer_profile_test['error'] ) . '</p></div>';
            } else {
                echo '<div class="pmcpc-summary-box" style="margin-top:12px;">';
                echo '<h4 style="margin-top:0;">' . esc_html__( 'Trigger test result', 'product-mailer-campaigns' ) . '</h4>';
                echo '<div class="notice ' . ( ! empty( $customer_profile_test['matched'] ) ? 'notice-success' : 'notice-info' ) . ' inline"><p><strong>' . esc_html( $customer_profile_test['headline'] ) . '</strong><br />' . esc_html( $customer_profile_test['summary'] ) . '</p></div>';
                echo '<div class="pmcpc-summary-box__grid">';
                echo '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Trigger tested', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( $customer_profile_test['trigger_label'] ) . '</strong></div>';
                echo '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Evaluation date', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( $customer_profile_test['evaluation_label'] ) . '</strong></div>';
                echo '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Customer', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( $customer_profile_test['email'] ) . '</strong></div>';
                echo '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Trigger condition', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( ! empty( $customer_profile_test['trigger_condition_match'] ) ? __( 'Match', 'product-mailer-campaigns' ) : __( 'No match', 'product-mailer-campaigns' ) ) . '</strong></div>';
                echo '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Campaigns using trigger', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( (string) absint( isset( $customer_profile_test['campaign_count'] ) ? $customer_profile_test['campaign_count'] : 0 ) ) . '</strong></div>';
                echo '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Overall result', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( ! empty( $customer_profile_test['matched'] ) ? __( 'Email would queue', 'product-mailer-campaigns' ) : __( 'No email would queue', 'product-mailer-campaigns' ) ) . '</strong></div>';
                echo '</div>';
                if ( ! empty( $customer_profile_test['details'] ) ) {
                    echo '<ul style="list-style:disc;margin:12px 0 0 20px;">';
                    foreach ( (array) $customer_profile_test['details'] as $detail_line ) {
                        echo '<li>' . esc_html( $detail_line ) . '</li>';
                    }
                    echo '</ul>';
                }
                if ( ! empty( $customer_profile_test['campaigns'] ) ) {
                    echo '<h5 style="margin:12px 0 8px;">' . esc_html__( 'Matching campaigns', 'product-mailer-campaigns' ) . '</h5>';
                    echo '<ul style="list-style:disc;margin:0 0 0 20px;">';
                    foreach ( (array) $customer_profile_test['campaigns'] as $campaign_label ) {
                        echo '<li>' . esc_html( $campaign_label ) . '</li>';
                    }
                    echo '</ul>';
                }
                if ( ! empty( $customer_profile_test['trigger_condition_match'] ) && in_array( $profile_test_trigger, array( 'subscriber_birthday', 'subscriber_anniversary' ), true ) && ! empty( $customer_sim_email ) ) {
                    echo '<div class="pmcpc-testing-center__actions" style="margin-top:12px;">';
                    echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
                    echo '<input type="hidden" name="action" value="pmcpc_pro_run_profile_trigger_scan" />';
                    echo '<input type="hidden" name="pmcpc_profile_scan_trigger" value="' . esc_attr( $profile_test_trigger ) . '" />';
                    echo '<input type="hidden" name="pmcpc_profile_scan_email" value="' . esc_attr( $customer_sim_email ) . '" />';
                    wp_nonce_field( 'pmcpc_pro_run_profile_trigger_scan' );
                    echo '<button type="submit" class="button button-secondary">' . esc_html__( 'Queue matching email now', 'product-mailer-campaigns' ) . '</button>';
                    echo '</form>';
                    echo '</div>';
                    echo '<p class="description" style="margin-top:6px;">' . esc_html__( 'This queues the matching birthday or anniversary automation for this subscriber right now using today\'s live date. After that, run the queue processor to send it.', 'product-mailer-campaigns' ) . '</p>';
                }
                $this->render_profile_test_debug_panel( $customer_profile_test );
                echo '</div>';
            }
        }
        echo '</div>';
        if ( is_array( $customer_simulation ) ) {
            if ( ! empty( $customer_simulation['error'] ) ) {
                echo '<div class="notice notice-error inline"><p>' . esc_html( $customer_simulation['error'] ) . '</p></div>';
            } else {
                echo '<div class="pmcpc-kpi-grid">';
                echo '<div class="pmcpc-kpi pmcpc-kpi--neutral"><strong>' . esc_html__( 'Subscriber', 'product-mailer-campaigns' ) . '</strong><span>' . esc_html( $customer_simulation['subscriber_label'] ) . '</span><small>' . esc_html__( 'Shows whether this email already exists in your subscriber list.', 'product-mailer-campaigns' ) . '</small></div>';
                echo '<div class="pmcpc-kpi pmcpc-kpi--neutral"><strong>' . esc_html__( 'Orders found', 'product-mailer-campaigns' ) . '</strong><span>' . esc_html( (string) $customer_simulation['order_count'] ) . '</span><small>' . esc_html( $customer_simulation['order_help'] ) . '</small></div>';
                echo '<div class="pmcpc-kpi pmcpc-kpi--neutral"><strong>' . esc_html__( 'Recent queued emails', 'product-mailer-campaigns' ) . '</strong><span>' . esc_html( (string) count( $customer_simulation['queue_rows'] ) ) . '</span><small>' . esc_html__( 'Latest automation queue activity for this email.', 'product-mailer-campaigns' ) . '</small></div>';
                echo '</div>';
                if ( ! empty( $customer_simulation['cart_summary'] ) ) {
                    echo '<div class="notice notice-info inline"><p><strong>' . esc_html__( 'Cart summary:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $customer_simulation['cart_summary'] ) . '</p></div>';
                }
                if ( ! empty( $customer_simulation['matched_triggers'] ) ) {
                    echo '<h4>' . esc_html__( 'Automations matching right now', 'product-mailer-campaigns' ) . '</h4><ul style="list-style:disc;margin-left:20px;">';
                    foreach ( $customer_simulation['matched_triggers'] as $match ) {
                        echo '<li><strong>' . esc_html( $match['label'] ) . '</strong> — ' . esc_html( $match['summary'] ) . '</li>';
                    }
                    echo '</ul>';
                } else {
                    echo '<p class="description">' . esc_html__( 'No active automation campaigns matched this customer during the simulation.', 'product-mailer-campaigns' ) . '</p>';
                }
                if ( ! empty( $customer_simulation['queue_rows'] ) ) {
                    echo '<h4>' . esc_html__( 'Latest queue activity for this customer', 'product-mailer-campaigns' ) . '</h4>';
                    echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Scheduled', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Automation', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
                    foreach ( $customer_simulation['queue_rows'] as $item ) {
                        echo '<tr><td>' . esc_html( $this->format_debug_datetime( $item['scheduled_at'] ) ) . '</td><td>' . esc_html( $item['campaign_name'] ) . '</td><td>' . esc_html( $item['status'] ) . '</td></tr>';
                    }
                    echo '</tbody></table>';
                }
                $this->render_customer_activity_timeline( $customer_simulation['email'], $profile_test_trigger );
            }
        }
        echo '</section>';

        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

    /**
     * Render structured debug data for a profile/date trigger test.
     *
     * @param array $customer_profile_test
     * @return void
     */
    protected function render_profile_test_debug_panel( $customer_profile_test ) {
        if ( ! is_array( $customer_profile_test ) || empty( $customer_profile_test['email'] ) ) {
            return;
        }

        $trigger   = ! empty( $customer_profile_test['trigger_key'] ) ? sanitize_key( (string) $customer_profile_test['trigger_key'] ) : '';
        $log_items = class_exists( 'PMCPC_Automation_Debug_Log' ) ? PMCPC_Automation_Debug_Log::get_items(
            array(
                'email'   => (string) $customer_profile_test['email'],
                'trigger' => $trigger,
                'limit'   => 8,
            )
        ) : array();

        echo '<div style="margin-top:14px;padding-top:12px;border-top:1px solid #e2e4e7;">';
        echo '<h5 style="margin:0 0 8px;">' . esc_html__( 'Automation trigger log', 'product-mailer-campaigns' ) . '</h5>';
        echo '<p class="description" style="margin-top:0;">' . esc_html__( 'This shows the latest structured checks for this customer and trigger, so you can see whether the rule matched, whether a campaign was found, and why queueing was skipped or allowed.', 'product-mailer-campaigns' ) . '</p>';
        if ( empty( $log_items ) ) {
            echo '<p class="description">' . esc_html__( 'No structured trigger logs were found yet for this customer/trigger.', 'product-mailer-campaigns' ) . '</p>';
        } else {
            echo '<ul class="pmcpc-activity-feed">';
            foreach ( $log_items as $item ) {
                $time    = isset( $item['t'] ) ? (int) $item['t'] : 0;
                $message = isset( $item['m'] ) ? (string) $item['m'] : '';
                $context = isset( $item['c'] ) && is_array( $item['c'] ) ? $item['c'] : array();
                $meta    = array();
                foreach ( array( 'condition_match', 'campaigns', 'source', 'result' ) as $ctx_key ) {
                    if ( isset( $context[ $ctx_key ] ) && '' !== (string) $context[ $ctx_key ] ) {
                        $label = ucwords( str_replace( '_', ' ', $ctx_key ) );
                        $meta[] = $label . ': ' . (string) $context[ $ctx_key ];
                    }
                }
                echo '<li class="pmcpc-activity-feed__item"><span class="pmcpc-activity-feed__time">' . esc_html( $time ? wp_date( 'H:i:s', $time, wp_timezone() ) : '—' ) . '</span><span class="pmcpc-activity-feed__message">' . esc_html( $message );
                if ( ! empty( $meta ) ) {
                    echo '<br /><small>' . esc_html( implode( ' • ', $meta ) ) . '</small>';
                }
                echo '</span></li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }

    /**
     * Render a unified activity timeline for one customer.
     *
     * @param string $email
     * @param string $trigger
     * @return void
     */
    protected function render_customer_activity_timeline( $email, $trigger = '' ) {
        $email = sanitize_email( (string) $email );
        if ( '' === $email ) {
            return;
        }

        $timeline = array();

        if ( class_exists( 'PMCPC_Automation_Debug_Log' ) ) {
            $log_items = PMCPC_Automation_Debug_Log::get_items(
                array(
                    'email' => $email,
                    'limit' => 12,
                )
            );
            foreach ( $log_items as $item ) {
                $timeline[] = array(
                    'time'    => isset( $item['t'] ) ? (int) $item['t'] : 0,
                    'source'  => __( 'Trigger log', 'product-mailer-campaigns' ),
                    'message' => isset( $item['m'] ) ? (string) $item['m'] : '',
                );
            }
        }

        if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
            $feed_items = PMCPC_Activity_Feed::get_items();
            foreach ( (array) $feed_items as $item ) {
                $message = isset( $item['m'] ) ? (string) $item['m'] : '';
                if ( '' === $message || false === strpos( strtolower( $message ), strtolower( $email ) ) ) {
                    continue;
                }
                $timeline[] = array(
                    'time'    => isset( $item['t'] ) ? (int) $item['t'] : 0,
                    'source'  => __( 'Activity feed', 'product-mailer-campaigns' ),
                    'message' => $message,
                );
            }
        }

        usort( $timeline, function( $a, $b ) {
            return (int) $b['time'] <=> (int) $a['time'];
        } );
        $timeline = array_slice( $timeline, 0, 12 );

        echo '<div style="margin-top:16px;">';
        echo '<h4>' . esc_html__( 'Automation activity timeline', 'product-mailer-campaigns' ) . '</h4>';
        echo '<p class="description" style="margin-top:0;">' . esc_html__( 'A single view of recent trigger checks and activity feed events for this email, to help explain whether the customer matched, queued, or was skipped.', 'product-mailer-campaigns' ) . '</p>';
        if ( empty( $timeline ) ) {
            echo '<p class="description">' . esc_html__( 'No timeline items were found yet for this email.', 'product-mailer-campaigns' ) . '</p>';
        } else {
            echo '<ul class="pmcpc-activity-feed">';
            foreach ( $timeline as $row ) {
                echo '<li class="pmcpc-activity-feed__item"><span class="pmcpc-activity-feed__time">' . esc_html( ! empty( $row['time'] ) ? wp_date( 'H:i:s', (int) $row['time'], wp_timezone() ) : '—' ) . '</span><span class="pmcpc-activity-feed__message"><strong>' . esc_html( $row['source'] ) . ':</strong> ' . esc_html( $row['message'] ) . '</span></li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }

    /**
     * Trigger labels used across the testing center.
     *
     * @return array<string,string>
     */
    protected function get_all_testable_trigger_options() {
        return array(
            'post_purchase' => __( 'Post-purchase (after order)', 'product-mailer-campaigns' ),
            'review_request' => __( 'Review request (after order)', 'product-mailer-campaigns' ),
            'new_customer' => __( 'First order', 'product-mailer-campaigns' ),
            'repeat_customer' => __( 'Repeat customer', 'product-mailer-campaigns' ),
            'high_value' => __( 'High-value customer (crosses threshold)', 'product-mailer-campaigns' ),
            'lapsed_high_value_customer' => __( 'Lapsed high-value customer', 'product-mailer-campaigns' ),
            'vip_customer' => __( 'VIP customer (crosses VIP threshold)', 'product-mailer-campaigns' ),
            'customer_inactive' => __( 'Customer inactive / win-back', 'product-mailer-campaigns' ),
            'new_subscriber' => __( 'New subscriber (signup)', 'product-mailer-campaigns' ),
            'welcome_follow_up' => __( 'Welcome follow-up', 'product-mailer-campaigns' ),
            'abandoned_cart_step_1' => __( 'Abandoned cart (Step 1)', 'product-mailer-campaigns' ),
            'abandoned_cart_step_2' => __( 'Abandoned cart (Step 2)', 'product-mailer-campaigns' ),
            'abandoned_cart_step_3' => __( 'Abandoned cart (Step 3)', 'product-mailer-campaigns' ),
            'lead_magnet_download' => __( 'Lead magnet delivery', 'product-mailer-campaigns' ),
            'subscriber_inactive' => __( 'Subscriber inactive', 'product-mailer-campaigns' ),
        );
    }

    protected function get_simulatable_trigger_options() {
        return array(
            'post_purchase' => __( 'Post-purchase (after order)', 'product-mailer-campaigns' ),
            'review_request' => __( 'Review request (after order)', 'product-mailer-campaigns' ),
            'new_customer' => __( 'First order', 'product-mailer-campaigns' ),
            'repeat_customer' => __( 'Repeat customer', 'product-mailer-campaigns' ),
            'high_value' => __( 'High-value customer (crosses threshold)', 'product-mailer-campaigns' ),
            'lapsed_high_value_customer' => __( 'Lapsed high-value customer', 'product-mailer-campaigns' ),
            'vip_customer' => __( 'VIP customer (crosses VIP threshold)', 'product-mailer-campaigns' ),
            'customer_inactive' => __( 'Customer inactive / win-back', 'product-mailer-campaigns' ),
            'new_subscriber' => __( 'New subscriber (signup)', 'product-mailer-campaigns' ),
            'welcome_follow_up' => __( 'Welcome follow-up', 'product-mailer-campaigns' ),
            'abandoned_cart_step_1' => __( 'Abandoned cart (Step 1)', 'product-mailer-campaigns' ),
            'abandoned_cart_step_2' => __( 'Abandoned cart (Step 2)', 'product-mailer-campaigns' ),
            'abandoned_cart_step_3' => __( 'Abandoned cart (Step 3)', 'product-mailer-campaigns' ),
        );
    }

    protected function get_disabled_quick_test_trigger_hints() {
        return array(
            'lead_magnet_download' => __( 'Lead magnet delivery (use Customer Scan / form event)', 'product-mailer-campaigns' ),
            'subscriber_inactive' => __( 'Subscriber inactive (use Customer Scan / Time Travel)', 'product-mailer-campaigns' ),
            'welcome_follow_up' => __( 'Welcome follow-up (use Customer Simulation)', 'product-mailer-campaigns' ),
            'subscriber_birthday' => __( 'Subscriber birthday (use Customer Simulation)', 'product-mailer-campaigns' ),
            'subscriber_anniversary' => __( 'Subscriber anniversary (use Customer Simulation)', 'product-mailer-campaigns' ),
            'specific_date' => __( 'On a specific date (use Time Travel or scheduled campaigns)', 'product-mailer-campaigns' ),
        );
    }

    protected function get_selectable_and_disabled_trigger_options( $tool = 'quick_test' ) {
        $tool          = sanitize_key( (string) $tool );
        $selectable    = array();
        $disabled      = array();
        $base_options  = in_array( $tool, array( 'quick_test', 'trigger_simulator' ), true ) ? $this->get_simulatable_trigger_options() : $this->get_all_testable_trigger_options();
        $hint_options  = 'quick_test' === $tool ? $this->get_disabled_quick_test_trigger_hints() : $this->get_non_simulatable_trigger_hints();

        foreach ( $base_options as $trigger_key => $trigger_label ) {
            $count = $this->count_campaigns_for_trigger( $trigger_key, 'active' );
            if ( $count > 0 ) {
                $selectable[ $trigger_key ] = sprintf(
                    /* translators: 1: trigger label, 2: number of active campaigns */
                    __( '%1$s', 'product-mailer-campaigns' ),
                    $trigger_label,
                    $count
                );
            } else {
                $disabled[ $trigger_key ] = sprintf(
                    /* translators: %s: trigger label */
                    __( '%s — no active campaign using this trigger', 'product-mailer-campaigns' ),
                    $trigger_label
                );
            }
        }

        foreach ( $hint_options as $trigger_key => $trigger_label ) {
            $disabled[ $trigger_key ] = $trigger_label;
        }

        return array(
            'selectable' => $selectable,
            'disabled'   => $disabled,
        );
    }

    /**
     * Triggers visible in Quick Test but routed to a more appropriate tool.
     *
     * @return array<string,string>
     */
    protected function get_profile_test_trigger_options() {
        return array(
            'subscriber_birthday'    => __( 'Subscriber birthday', 'product-mailer-campaigns' ),
            'subscriber_anniversary' => __( 'Subscriber anniversary', 'product-mailer-campaigns' ),
            'specific_date'          => __( 'On a specific date', 'product-mailer-campaigns' ),
        );
    }

    protected function get_profile_trigger_test_help_text( $trigger ) {
        switch ( sanitize_key( (string) $trigger ) ) {
            case 'subscriber_anniversary':
                return __( 'Anniversary triggers fire when the subscriber join date month/day matches the evaluation date. The year is ignored.', 'product-mailer-campaigns' );
            case 'specific_date':
                return __( 'Specific-date triggers fire when a scheduled campaign is due on the evaluation date.', 'product-mailer-campaigns' );
            case 'subscriber_birthday':
            default:
                return __( 'Birthday triggers fire when the subscriber birthday month/day matches the evaluation date. The year is ignored.', 'product-mailer-campaigns' );
        }
    }

    protected function get_non_simulatable_trigger_hints() {
        return array(
            'lead_magnet_download'   => __( 'Lead magnet delivery (requires a form / opt-in event)', 'product-mailer-campaigns' ),
            'subscriber_inactive'    => __( 'Subscriber inactive (use Customer Scan / Time Travel)', 'product-mailer-campaigns' ),
            'subscriber_birthday'    => __( 'Subscriber birthday (use Customer Simulation)', 'product-mailer-campaigns' ),
            'subscriber_anniversary' => __( 'Subscriber anniversary (use Customer Simulation)', 'product-mailer-campaigns' ),
            'specific_date'          => __( 'On a specific date (use Time Travel or scheduled campaigns)', 'product-mailer-campaigns' ),
        );
    }


    /**
     * Render a consistent inline result box inside a testing tool.
     *
     * @param string $state   success|error|warning|info.
     * @param string $title   Result title.
     * @param array  $lines   Message lines.
     * @return void
     */
    protected function render_testing_tool_result_box( $state, $title, $lines = array() ) {
        $allowed_states = array( 'success', 'error', 'warning', 'info' );
        if ( ! in_array( $state, $allowed_states, true ) ) {
            $state = 'info';
        }
        $lines = array_values( array_filter( array_map( 'strval', (array) $lines ) ) );
        if ( '' === (string) $title && empty( $lines ) ) {
            return;
        }

        echo '<div class="pmcpc-testing-center__result pmcpc-testing-center__result--' . esc_attr( $state ) . '" style="margin-top:12px;">';
        if ( '' !== (string) $title ) {
            echo '<p class="pmcpc-testing-center__result-title"><strong>' . esc_html( $title ) . '</strong></p>';
        }
        if ( ! empty( $lines ) ) {
            echo '<ul class="pmcpc-testing-center__result-list">';
            foreach ( $lines as $line ) {
                echo '<li>' . esc_html( $line ) . '</li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }

    /**
     * Render the trigger simulator / quick test result summary.
     *
     * @return void
     */
    protected function render_simulation_result_box() {
        if ( ! isset( $_GET['pmcpc_pro_sim'] ) ) {
            return;
        }

        $sim_trigger   = isset( $_GET['trigger'] ) ? sanitize_key( wp_unslash( $_GET['trigger'] ) ) : '';
        $sim_email     = isset( $_GET['email'] ) ? sanitize_email( wp_unslash( $_GET['email'] ) ) : '';
        $sim_campaigns = isset( $_GET['campaigns'] ) ? absint( $_GET['campaigns'] ) : 0;
        $sim_eligible  = isset( $_GET['eligible'] ) ? absint( $_GET['eligible'] ) : 0;
        $sim_queued    = isset( $_GET['queued'] ) ? absint( $_GET['queued'] ) : 0;
        $sim_dry_run   = ! empty( $_GET['dry_run'] );
        $sim_error     = isset( $_GET['error'] ) ? sanitize_text_field( wp_unslash( $_GET['error'] ) ) : '';

        if ( $sim_error ) {
            $lines = array( $sim_error );
            if ( false !== strpos( $sim_error, 'profile data' ) ) {
                $lines[] = __( 'Use Customer Simulation to test birthday or anniversary triggers with subscriber profile fields.', 'product-mailer-campaigns' );
            } elseif ( false !== strpos( $sim_error, 'date-based' ) ) {
                $lines[] = __( 'Use scheduled campaigns or Time Travel to test date-based sends.', 'product-mailer-campaigns' );
            } elseif ( false !== strpos( $sim_error, 'cannot be simulated in Quick Test' ) ) {
                $lines[] = __( 'Use Trigger Simulator for supported event triggers, Customer Simulation for subscriber profile triggers, and Customer Scan / Time Travel for inactivity-style checks.', 'product-mailer-campaigns' );
            }
            $this->render_testing_tool_result_box(
                'error',
                __( 'Simulation could not be completed.', 'product-mailer-campaigns' ),
                $lines
            );
            return;
        }

        $title = $sim_dry_run
            ? __( 'Simulation completed (dry run).', 'product-mailer-campaigns' )
            : __( 'Simulation completed.', 'product-mailer-campaigns' );

        $lines = array(
            sprintf( __( 'Trigger: %s', 'product-mailer-campaigns' ), $sim_trigger ),
            sprintf( __( 'Subscriber: %s', 'product-mailer-campaigns' ), $sim_email ),
            sprintf( __( 'Matched campaigns: %d', 'product-mailer-campaigns' ), $sim_campaigns ),
            sprintf( __( 'Eligible right now: %d', 'product-mailer-campaigns' ), $sim_eligible ),
            sprintf(
                $sim_dry_run ? __( 'Would queue: %d', 'product-mailer-campaigns' ) : __( 'Queued now: %d', 'product-mailer-campaigns' ),
                $sim_queued
            ),
        );
        $this->render_testing_tool_result_box( 'success', $title, $lines );
    }

    /**
     * Render the inactive customer scan result summary.
     *
     * @return void
     */
    protected function render_scan_result_box() {
        if ( ! isset( $_GET['pmcpc_pro_scan'] ) ) {
            return;
        }

        $processed     = isset( $_GET['processed'] ) ? absint( $_GET['processed'] ) : 0;
        $queued        = isset( $_GET['queued'] ) ? absint( $_GET['queued'] ) : 0;
        $offset_before = isset( $_GET['offset_before'] ) ? absint( $_GET['offset_before'] ) : 0;
        $offset_after  = isset( $_GET['offset_after'] ) ? absint( $_GET['offset_after'] ) : 0;
        $done          = ! empty( $_GET['done'] );
        $dry_run       = ! empty( $_GET['dry_run'] );
        $max_queue     = isset( $_GET['max_queue'] ) ? absint( $_GET['max_queue'] ) : 0;

        $title = $dry_run
            ? __( 'Inactive scan completed (single batch, dry run).', 'product-mailer-campaigns' )
            : __( 'Inactive scan completed (single batch).', 'product-mailer-campaigns' );

        $lines = array(
            sprintf( __( 'Subscribers processed: %d', 'product-mailer-campaigns' ), $processed ),
            sprintf( $dry_run ? __( 'Would queue: %d', 'product-mailer-campaigns' ) : __( 'Queued now: %d', 'product-mailer-campaigns' ), $queued ),
            sprintf( __( 'Offset moved: %1$d → %2$d', 'product-mailer-campaigns' ), $offset_before, $offset_after ),
        );
        if ( $done ) {
            $lines[] = __( 'Reached the end of the customer list and reset the scan offset to 0.', 'product-mailer-campaigns' );
        }
        if ( $max_queue > 0 ) {
            $lines[] = sprintf( __( 'Max queue cap used: %d', 'product-mailer-campaigns' ), $max_queue );
        }

        $this->render_testing_tool_result_box( 'success', $title, $lines );
    }

    /**
     * Render the common simulation breakdown box.
     *
     * @param array $details Breakdown details.
     * @param bool  $has_breakdown Whether details are available.
     * @return void
     */
    protected function render_simulation_breakdown_box( $details, $has_breakdown ) {
        if ( $has_breakdown ) {
            echo '<div class="pmcpc-testing-center__result pmcpc-testing-center__result--info" style="margin-top:12px;">';
            echo '<p class="pmcpc-testing-center__result-title"><strong>' . esc_html__( 'Matched campaigns', 'product-mailer-campaigns' ) . '</strong></p>';
            if ( empty( $details ) ) {
                echo '<p class="description">' . esc_html__( 'No campaigns matched this trigger, or none were eligible for the chosen subscriber.', 'product-mailer-campaigns' ) . '</p>';
            } else {
                echo '<ul style="list-style:disc;margin-left:20px;">';
                foreach ( $details as $d ) {
                    $title  = isset( $d['title'] ) ? (string) $d['title'] : '';
                    $action = isset( $d['action'] ) ? (string) $d['action'] : 'skip';
                    $reason = isset( $d['reason'] ) ? (string) $d['reason'] : '';
                    if ( 'queued' === $action ) {
                        $label = __( 'Queued', 'product-mailer-campaigns' );
                    } elseif ( 'would_queue' === $action ) {
                        $label = __( 'Would queue (dry run)', 'product-mailer-campaigns' );
                    } else {
                        $label = __( 'Skipped', 'product-mailer-campaigns' );
                    }
                    echo '<li><strong>' . esc_html( $title ) . '</strong> — ' . esc_html( $label );
                    if ( $reason ) {
                        echo ' <span class="description">(' . esc_html( $reason ) . ')</span>';
                    }
                    echo '</li>';
                }
                echo '</ul>';
            }
            echo '</div>';
        } elseif ( isset( $_GET['pmcpc_pro_sim'] ) && 0 === ( isset( $_GET['campaigns'] ) ? absint( $_GET['campaigns'] ) : 0 ) ) {
            echo '<p class="description" style="margin-top:12px;">' . esc_html__( 'Tip: create at least one campaign using this trigger to see it listed here.', 'product-mailer-campaigns' ) . '</p>';
        }

        $history_key = isset( $_GET['history_key'] ) ? sanitize_key( wp_unslash( $_GET['history_key'] ) ) : '';
        if ( $history_key ) {
            $history = get_transient( $history_key );
            delete_transient( $history_key );
            if ( ! empty( $history ) && is_array( $history ) ) {
                echo '<div class="pmcpc-testing-center__result pmcpc-testing-center__result--info" style="margin-top:12px;">';
                echo '<p class="pmcpc-testing-center__result-title"><strong>' . esc_html__( 'Recent trigger history for this subscriber', 'product-mailer-campaigns' ) . '</strong></p>';
                echo '<ul style="list-style:disc;margin-left:20px;">';
                foreach ( $history as $item ) {
                    $campaign_name = isset( $item['campaign_name'] ) ? (string) $item['campaign_name'] : __( '(Unknown campaign)', 'product-mailer-campaigns' );
                    $trigger_name  = isset( $item['automation_trigger'] ) ? (string) $item['automation_trigger'] : '';
                    $status_name   = isset( $item['status'] ) ? (string) $item['status'] : '';
                    $date_value    = '';
                    if ( ! empty( $item['scheduled_at'] ) ) {
                        $date_value = mysql2date( 'j M Y g:i a', $item['scheduled_at'] );
                    } elseif ( ! empty( $item['created_at'] ) ) {
                        $date_value = mysql2date( 'j M Y g:i a', $item['created_at'] );
                    }
                    echo '<li><strong>' . esc_html( $campaign_name ) . '</strong>';
                    if ( $trigger_name ) {
                        echo ' <span class="description">(' . esc_html( $trigger_name ) . ')</span>';
                    }
                    if ( $status_name ) {
                        echo ' — ' . esc_html( ucfirst( $status_name ) );
                    }
                    if ( $date_value ) {
                        echo ' <span class="description">' . esc_html( $date_value ) . '</span>';
                    }
                    echo '</li>';
                }
                echo '</ul>';
                echo '</div>';
            }
        }
    }

    /**
     * Return recent automation queue rows.
     *
     * @param int    $limit Limit.
     * @param string $email Optional email filter.
     * @return array
     */
    protected function get_recent_automation_queue_rows( $limit = 10, $email = '' ) {
        global $wpdb;
        $queue_table = $wpdb->prefix . 'pmcpc_email_queue';
        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        $limit = max( 1, min( 50, absint( $limit ) ) );
        $email = sanitize_email( $email );

        $queue_columns = $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $queue_table ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
        $queue_columns = is_array( $queue_columns ) ? array_map( 'strval', $queue_columns ) : array();
        $attempt_count_select = in_array( 'attempt_count', $queue_columns, true ) ? 'q.attempt_count' : '0 AS attempt_count';

        $sql = 'SELECT q.scheduled_at, q.to_email, q.status, ' . $attempt_count_select . ', c.name AS campaign_name, c.automation_trigger FROM ' . $queue_table . ' q LEFT JOIN ' . $campaigns_table . ' c ON c.id = q.campaign_id WHERE c.automation_trigger <> ""';
        if ( $email ) {
            $sql .= $wpdb->prepare( ' AND q.to_email = %s', $email );
        }
        $sql .= $wpdb->prepare( ' ORDER BY q.created_at DESC, q.id DESC LIMIT %d', $limit );
        $rows = $wpdb->get_results( $sql, ARRAY_A );
        return is_array( $rows ) ? $rows : array();
    }

    /**
     * Diagnostics cards for the testing center.
     *
     * @return array
     */
    protected function get_automation_diagnostics_rows() {
        global $wpdb;
        $rows = array();
        $rows[] = array(
            'label' => __( 'WooCommerce', 'product-mailer-campaigns' ),
            'value' => class_exists( 'WooCommerce' ) ? __( 'Loaded', 'product-mailer-campaigns' ) : __( 'Missing', 'product-mailer-campaigns' ),
            'help'  => __( 'Automation triggers that depend on orders or carts need WooCommerce active.', 'product-mailer-campaigns' ),
            'state' => class_exists( 'WooCommerce' ) ? 'good' : 'warn',
        );
        $rows[] = array(
            'label' => __( 'Automation licence gate', 'product-mailer-campaigns' ),
            'value' => ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) ? __( 'Enabled', 'product-mailer-campaigns' ) : __( 'Disabled', 'product-mailer-campaigns' ),
            'help'  => __( 'If this is disabled, WooCommerce automations will not run.', 'product-mailer-campaigns' ),
            'state' => ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) ? 'good' : 'warn',
        );
        $rows[] = array(
            'label' => __( 'Email queue cron', 'product-mailer-campaigns' ),
            'value' => wp_next_scheduled( 'pmcpc_process_email_queue' ) ? __( 'Scheduled', 'product-mailer-campaigns' ) : __( 'Not scheduled', 'product-mailer-campaigns' ),
            'help'  => __( 'Processes queued emails in the background.', 'product-mailer-campaigns' ),
            'state' => wp_next_scheduled( 'pmcpc_process_email_queue' ) ? 'good' : 'warn',
        );
        $rows[] = array(
            'label' => __( 'Abandoned cart sweep', 'product-mailer-campaigns' ),
            'value' => wp_next_scheduled( 'pmcpc_abandoned_cart_sweep' ) ? __( 'Scheduled', 'product-mailer-campaigns' ) : __( 'Not scheduled', 'product-mailer-campaigns' ),
            'help'  => __( 'Moves quiet carts from active to abandoned.', 'product-mailer-campaigns' ),
            'state' => wp_next_scheduled( 'pmcpc_abandoned_cart_sweep' ) ? 'good' : 'warn',
        );
        $rows[] = array(
            'label' => __( 'Recovery processor', 'product-mailer-campaigns' ),
            'value' => wp_next_scheduled( 'pmcpc_abandoned_cart_sweep' ) ? __( 'Runs with sweep', 'product-mailer-campaigns' ) : __( 'Not scheduled', 'product-mailer-campaigns' ),
            'help'  => __( 'Queues the next abandoned-cart email when it becomes due. This now runs through the abandoned-cart sweep hook.', 'product-mailer-campaigns' ),
            'state' => wp_next_scheduled( 'pmcpc_abandoned_cart_sweep' ) ? 'good' : 'warn',
        );
        $table = $wpdb->prefix . 'pmcpc_email_queue';
        $queue_count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $table . ' WHERE status = "pending"' );
        $rows[] = array(
            'label' => __( 'Pending queue', 'product-mailer-campaigns' ),
            'value' => (string) $queue_count,
            'help'  => __( 'A growing pending queue can indicate cron or mail transport delays.', 'product-mailer-campaigns' ),
            'state' => $queue_count < 50 ? 'neutral' : 'warn',
        );
        return $rows;
    }

    /**
     * Build a full customer automation simulation.
     *
     * @param string $email Customer email.
     * @return array
     */
    protected function get_customer_simulation_data( $email ) {
        $email = sanitize_email( $email );
        if ( empty( $email ) || ! is_email( $email ) ) {
            return array( 'error' => __( 'Please enter a valid customer email address.', 'product-mailer-campaigns' ) );
        }

        $subscriber = $this->get_subscriber_by_email( $email );
        $subscriber_label = $subscriber ? __( 'Found in subscriber list', 'product-mailer-campaigns' ) : __( 'Not yet in subscriber list', 'product-mailer-campaigns' );
        $order_ids = array();
        if ( class_exists( 'WooCommerce' ) && function_exists( 'wc_get_orders' ) ) {
            $order_ids = wc_get_orders( array(
                'billing_email' => $email,
                'limit'         => 20,
                'return'        => 'ids',
                'status'        => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
            ) );
        }
        $order_count = is_array( $order_ids ) ? count( $order_ids ) : 0;
        $order_help  = 0 === $order_count ? __( 'No recent WooCommerce orders were found for this email.', 'product-mailer-campaigns' ) : sprintf( _n( '%d recent WooCommerce order found.', '%d recent WooCommerce orders found.', $order_count, 'product-mailer-campaigns' ), $order_count );
        $cart_data   = $this->get_abandoned_cart_debug_data( $email );
        $matched     = array();
        if ( $subscriber ) {
            foreach ( $this->get_simulatable_trigger_options() as $trigger_key => $trigger_label ) {
                $result = $this->simulate_trigger_for_subscriber( $trigger_key, $subscriber, true );
                if ( ! empty( $result['eligible'] ) ) {
                    $matched[] = array(
                        'label'   => $trigger_label,
                        'summary' => sprintf( __( '%1$d campaign(s) matched, %2$d would queue right now.', 'product-mailer-campaigns' ), (int) $result['campaigns'], (int) $result['eligible'] ),
                    );
                }
            }
        }
        return array(
            'error'            => '',
            'subscriber_label' => $subscriber_label,
            'order_count'      => $order_count,
            'order_help'       => $order_help,
            'cart_summary'     => isset( $cart_data['summary'] ) ? (string) $cart_data['summary'] : '',
            'matched_triggers' => $matched,
            'queue_rows'       => $this->get_recent_automation_queue_rows( 5, $email ),
        );
    }

    /**
     * Normalize an automation campaign row into a display label for admin test output.
     *
     * @param array  $campaign_row Campaign DB row.
     * @param string $fallback     Fallback label when no name/subject exists.
     * @return string
     */
    protected function get_automation_test_campaign_label( array $campaign_row, $fallback ) {
        if ( ! empty( $campaign_row['campaign_name'] ) ) {
            return (string) $campaign_row['campaign_name'];
        }

        if ( ! empty( $campaign_row['subject'] ) ) {
            return (string) $campaign_row['subject'];
        }

        return (string) $fallback;
    }

    /**
     * Load scheduled campaigns due on the supplied evaluation date.
     *
     * @param string $campaigns_table Campaign table name.
     * @param string $name_col        Campaign name column.
     * @param int    $eval_ts         Evaluation timestamp.
     * @return array
     */
    protected function get_specific_date_test_campaign_rows( $campaigns_table, $name_col, $eval_ts ) {
        global $wpdb;

        $eval_day_start = gmdate( 'Y-m-d 00:00:00', $eval_ts );
        $eval_day_end   = gmdate( 'Y-m-d 23:59:59', $eval_ts );

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT {$name_col} AS campaign_name, subject
                FROM {$campaigns_table}
                WHERE schedule_type IN (%s,%s)
                    AND status IN (%s,%s,%s)
                    AND COALESCE(NULLIF(next_run_at,''), NULLIF(schedule_datetime,'')) BETWEEN %s AND %s
                ORDER BY COALESCE(NULLIF(next_run_at,''), NULLIF(schedule_datetime,'')) ASC
                LIMIT 10",
                'one_time',
                'recurring',
                'scheduled',
                'active',
                'draft',
                $eval_day_start,
                $eval_day_end
            ),
            ARRAY_A
        );
    }

    /**
     * Load campaigns that match a profile trigger for admin testing.
     *
     * @param string $campaigns_table Campaign table name.
     * @param string $name_col        Campaign name column.
     * @param string $trigger         Trigger key.
     * @return array
     */
    protected function get_profile_trigger_campaign_rows( $campaigns_table, $name_col, $trigger ) {
        global $wpdb;

        $automation_hints = array(
            'subscriber_birthday'    => array( 'subscriber birthday automation', 'birthday automation' ),
            'subscriber_anniversary' => array( 'subscriber anniversary automation', 'anniversary automation' ),
        );
        $aliases      = $this->get_trigger_aliases( $trigger );
        $where_parts  = array();
        $prepare_args = array( 'active', 'scheduled' );

        if ( ! empty( $aliases ) ) {
            $where_parts[] = 'automation_trigger IN (' . implode( ', ', array_fill( 0, count( $aliases ), '%s' ) ) . ')';
            $prepare_args  = array_merge( $prepare_args, $aliases );
        }

        $hints = isset( $automation_hints[ $trigger ] ) ? $automation_hints[ $trigger ] : array();
        foreach ( $hints as $hint ) {
            $where_parts[] = "LOWER(COALESCE({$name_col}, subject, '')) LIKE %s";
            $prepare_args[] = '%' . strtolower( $hint ) . '%';
        }

        $sql = "SELECT {$name_col} AS campaign_name, subject, automation_trigger
            FROM {$campaigns_table}
            WHERE status IN (%s,%s)";
        if ( ! empty( $where_parts ) ) {
            $sql .= ' AND (' . implode( ' OR ', $where_parts ) . ')';
        }
        $sql .= ' ORDER BY id DESC LIMIT 10';

        return $wpdb->get_results( $wpdb->prepare( $sql, $prepare_args ), ARRAY_A );
    }

    protected function get_profile_trigger_test_data( $email, $trigger, $birthday, $anniversary, $evaluation_date ) {
        global $wpdb;

        $email = sanitize_email( $email );
        if ( empty( $email ) || ! is_email( $email ) ) {
            return array( 'error' => __( 'Please enter a valid customer email address.', 'product-mailer-campaigns' ) );
        }

        $trigger = sanitize_key( (string) $trigger );
        if ( ! isset( $this->get_profile_test_trigger_options()[ $trigger ] ) ) {
            return array( 'error' => __( 'Please choose a supported profile/date trigger.', 'product-mailer-campaigns' ) );
        }

        $eval_ts = strtotime( (string) $evaluation_date );
        if ( ! $eval_ts ) {
            return array( 'error' => __( 'Please choose a valid evaluation date.', 'product-mailer-campaigns' ) );
        }
        $eval_md = gmdate( 'm-d', $eval_ts );

        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        $subscriber      = $this->get_subscriber_by_email( $email );
        $name_col        = $this->get_campaign_name_column();
        $details = array();
        $campaigns = array();
        $matched = false;
        $profile_source = '';
        $trigger_condition_match = false;
        $campaign_count = 0;
        $headline = __( 'Trigger would not fire.', 'product-mailer-campaigns' );
        $summary = __( 'No matching rule was found for the supplied profile/date values.', 'product-mailer-campaigns' );
        $trigger_labels = $this->get_profile_test_trigger_options();

        if ( 'specific_date' === $trigger ) {
            $campaign_rows = $this->get_specific_date_test_campaign_rows( $campaigns_table, $name_col, $eval_ts );
            $campaign_count = is_array( $campaign_rows ) ? count( $campaign_rows ) : 0;
            if ( ! empty( $campaign_rows ) ) {
                foreach ( $campaign_rows as $campaign_row ) {
                    $campaigns[] = $this->get_automation_test_campaign_label( $campaign_row, __( 'Scheduled campaign', 'product-mailer-campaigns' ) );
                }
            }
            $trigger_condition_match = $campaign_count > 0;
            $details[] = sprintf( __( 'Evaluation date: %s', 'product-mailer-campaigns' ), gmdate( 'j M Y', $eval_ts ) );
            $details[] = sprintf( _n( '%d scheduled campaign is due on that date.', '%d scheduled campaigns are due on that date.', $campaign_count, 'product-mailer-campaigns' ), $campaign_count );
            if ( $trigger_condition_match ) {
                $matched = true;
                $headline = __( 'Specific-date send would match.', 'product-mailer-campaigns' );
                $summary = __( 'At least one scheduled campaign is due on the chosen evaluation date.', 'product-mailer-campaigns' );
            }
        } else {
            $campaign_rows = $this->get_profile_trigger_campaign_rows( $campaigns_table, $name_col, $trigger );
            $campaign_count = is_array( $campaign_rows ) ? count( $campaign_rows ) : 0;
            if ( ! empty( $campaign_rows ) ) {
                foreach ( $campaign_rows as $campaign_row ) {
                    $campaigns[] = $this->get_automation_test_campaign_label( $campaign_row, __( 'Automation campaign', 'product-mailer-campaigns' ) );
                }
            }

            if ( 'subscriber_birthday' === $trigger ) {
                $birthday_source = 'manual';
                $birthday_ts = strtotime( (string) $birthday );
                if ( ! $birthday_ts && $subscriber ) {
                    $birthday_parts = $this->get_subscriber_birthday_parts( $subscriber );
                    if ( ! empty( $birthday_parts['month'] ) && ! empty( $birthday_parts['day'] ) ) {
                        $birthday_ts     = strtotime( sprintf( '2000-%02d-%02d', (int) $birthday_parts['month'], (int) $birthday_parts['day'] ) );
                        $birthday_source = 'subscriber';
                    }
                }
                if ( ! $birthday_ts ) {
                    return array( 'error' => __( 'Add a birthday to test the birthday trigger.', 'product-mailer-campaigns' ) );
                }
                $birth_md = gmdate( 'm-d', $birthday_ts );
                $trigger_condition_match = ( $birth_md === $eval_md );
                $details[] = sprintf( __( 'Birthday month/day: %s', 'product-mailer-campaigns' ), gmdate( 'j M', $birthday_ts ) );
                $profile_source = $birthday_source;
                if ( 'subscriber' === $birthday_source ) {
                    $details[] = __( 'Birthday source: subscriber profile record.', 'product-mailer-campaigns' );
                }
                $details[] = sprintf( __( 'Evaluation date: %s', 'product-mailer-campaigns' ), gmdate( 'j M Y', $eval_ts ) );
                $details[] = sprintf( _n( '%d active birthday campaign found.', '%d active birthday campaigns found.', $campaign_count, 'product-mailer-campaigns' ), $campaign_count );
                if ( $trigger_condition_match && $campaign_count > 0 ) {
                    $matched = true;
                    $headline = __( 'Birthday trigger would fire.', 'product-mailer-campaigns' );
                    $summary = __( 'The birthday date matches the evaluation date and a birthday campaign is active.', 'product-mailer-campaigns' );
                } elseif ( ! $trigger_condition_match ) {
                    $headline = __( 'Birthday date does not match.', 'product-mailer-campaigns' );
                    $summary = __( 'The birthday month/day does not match the evaluation date.', 'product-mailer-campaigns' );
                } else {
                    $headline = __( 'Birthday rule matches, but no campaign is ready.', 'product-mailer-campaigns' );
                    $summary = __( 'The birthday date matches, but no active birthday campaign was found for this trigger.', 'product-mailer-campaigns' );
                }
            } else {
                $anniversary_source = 'manual';
                $anniv_ts = 0;
                if ( $subscriber && ! empty( $subscriber->created_at ) ) {
                    $anniv_ts = strtotime( (string) $subscriber->created_at );
                    if ( $anniv_ts ) {
                        $anniversary_source = 'subscriber_created_at';
                    }
                }
                if ( ! $anniv_ts ) {
                    $anniv_ts = strtotime( (string) $anniversary );
                }
                if ( ! $anniv_ts ) {
                    return array( 'error' => __( 'Add an anniversary / join date to test the anniversary trigger.', 'product-mailer-campaigns' ) );
                }
                $anniv_md = gmdate( 'm-d', $anniv_ts );
                $trigger_condition_match = ( $anniv_md === $eval_md );
                $details[] = sprintf( __( 'Anniversary month/day: %s', 'product-mailer-campaigns' ), gmdate( 'j M', $anniv_ts ) );
                $profile_source = $anniversary_source;
                if ( 'subscriber_created_at' === $anniversary_source ) {
                    $details[] = __( 'Anniversary source: subscriber join date (created_at).', 'product-mailer-campaigns' );
                }
                $details[] = sprintf( __( 'Evaluation date: %s', 'product-mailer-campaigns' ), gmdate( 'j M Y', $eval_ts ) );
                $details[] = sprintf( _n( '%d active anniversary campaign found.', '%d active anniversary campaigns found.', $campaign_count, 'product-mailer-campaigns' ), $campaign_count );
                if ( $trigger_condition_match && $campaign_count > 0 ) {
                    $matched = true;
                    $headline = __( 'Anniversary trigger would fire.', 'product-mailer-campaigns' );
                    $summary = __( 'The anniversary month/day matches the evaluation date and an anniversary campaign is active.', 'product-mailer-campaigns' );
                } elseif ( ! $trigger_condition_match ) {
                    $headline = __( 'Anniversary date does not match.', 'product-mailer-campaigns' );
                    $summary = __( 'The anniversary month/day does not match the evaluation date.', 'product-mailer-campaigns' );
                } else {
                    $headline = __( 'Anniversary rule matches, but no campaign is ready.', 'product-mailer-campaigns' );
                    $summary = __( 'The anniversary date matches, but no active anniversary campaign was found for this trigger.', 'product-mailer-campaigns' );
                }
            }
        }

        array_unshift( $details, sprintf( __( 'Customer email: %s', 'product-mailer-campaigns' ), $email ) );

        if ( class_exists( 'PMCPC_Automation_Debug_Log' ) ) {
            PMCPC_Automation_Debug_Log::log(
                'profile_trigger_test',
                sprintf( 'Profile trigger test: %s for %s.', str_replace( '_', ' ', $trigger ), $email ),
                array(
                    'email'           => $email,
                    'trigger'         => $trigger,
                    'condition_match' => $trigger_condition_match ? 'yes' : 'no',
                    'campaigns'       => (string) $campaign_count,
                    'source'          => (string) $profile_source,
                    'result'          => $matched ? 'would_queue' : 'no_queue',
                    'evaluation_date' => gmdate( 'Y-m-d', $eval_ts ),
                )
            );
        }

        return array(
            'error'                   => '',
            'matched'                 => $matched,
            'trigger_condition_match' => $trigger_condition_match,
            'campaign_count'          => $campaign_count,
            'headline'                => $headline,
            'summary'                 => $summary,
            'details'                 => $details,
            'campaigns'               => $campaigns,
            'trigger_label'           => isset( $trigger_labels[ $trigger ] ) ? $trigger_labels[ $trigger ] : $trigger,
            'trigger_key'             => $trigger,
            'evaluation_label'        => gmdate( 'j M Y', $eval_ts ),
            'email'                   => $email,
        );
    }

    /**
     * Render the abandoned cart debugger panel.
     *
     * @return void
     */
    protected function render_abandoned_cart_debugger_panel() {
        $debug_email = isset( $_GET['debug_email'] ) ? sanitize_email( wp_unslash( $_GET['debug_email'] ) ) : '';
        $debug_error = isset( $_GET['debug_error'] ) ? sanitize_text_field( wp_unslash( $_GET['debug_error'] ) ) : '';

        echo '<div class="card pmcpc-card pmcpc-card--full">';
        echo '<h2 style="margin-top:0;">' . esc_html__( 'Abandoned Cart Debugger', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p style="margin:0 0 12px 0;">' . esc_html__( 'Look up one customer email to see whether a cart was captured, when it became abandoned, what recovery step is due next, and whether any abandoned-cart emails were queued.', 'product-mailer-campaigns' ) . '</p>';

        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:0 0 12px 0;">';
        echo '<input type="hidden" name="action" value="pmcpc_pro_debug_abandoned_cart" />';
        wp_nonce_field( 'pmcpc_pro_debug_abandoned_cart' );
        echo '<p style="margin:0 0 10px 0;">';
        echo '<label style="display:block; margin: 0 0 6px 0;"><strong>' . esc_html__( 'Customer email', 'product-mailer-campaigns' ) . '</strong></label>';
        echo '<input type="email" class="regular-text" name="pmcpc_pro_debug_email" placeholder="name@example.com" value="' . esc_attr( $debug_email ) . '" required /> ';
        echo '<button type="submit" class="button button-secondary">' . esc_html__( 'Check abandoned cart status', 'product-mailer-campaigns' ) . '</button>';
        echo '</p>';
        echo '</form>';

        if ( $debug_error ) {
            echo '<div class="notice notice-error inline"><p>' . esc_html( $debug_error ) . '</p></div>';
        }

        if ( $debug_email && ! $debug_error ) {
            $data = $this->get_abandoned_cart_debug_data( $debug_email );

            if ( ! empty( $data['error'] ) ) {
                echo '<div class="notice notice-error inline"><p>' . esc_html( $data['error'] ) . '</p></div>';
            } else {
                if ( ! empty( $data['summary'] ) ) {
                    echo '<div class="notice notice-info inline"><p><strong>' . esc_html__( 'Summary:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $data['summary'] ) . '</p></div>';
                }

                echo '<table class="widefat striped" style="max-width:960px; margin-top:12px;">';
                echo '<tbody>';
                foreach ( $data['rows'] as $row ) {
                    echo '<tr>';
                    echo '<th style="width:240px;">' . esc_html( $row['label'] ) . '</th>';
                    echo '<td>' . wp_kses_post( $row['value'] ) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';

                if ( ! empty( $data['queue_rows'] ) ) {
                    echo '<h3 style="margin:16px 0 8px 0;">' . esc_html__( 'Recent queue entries', 'product-mailer-campaigns' ) . '</h3>';
                    echo '<table class="widefat striped" style="max-width:960px;">';
                    echo '<thead><tr>';
                    echo '<th>' . esc_html__( 'Scheduled', 'product-mailer-campaigns' ) . '</th>';
                    echo '<th>' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
                    echo '<th>' . esc_html__( 'Trigger', 'product-mailer-campaigns' ) . '</th>';
                    echo '<th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
                    echo '<th>' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</th>';
                    echo '</tr></thead><tbody>';
                    foreach ( $data['queue_rows'] as $item ) {
                        echo '<tr>';
                        echo '<td>' . esc_html( $this->format_debug_datetime( $item['scheduled_at'] ) ) . '</td>';
                        echo '<td>' . esc_html( $item['campaign_name'] ) . '</td>';
                        echo '<td>' . esc_html( $item['automation_trigger'] ) . '</td>';
                        echo '<td>' . esc_html( $item['status'] ) . '</td>';
                        echo '<td>' . esc_html( $item['subject'] ) . '</td>';
                        echo '</tr>';
                    }
                    echo '</tbody></table>';
                }
            }
        }

        echo '</div>';
    }

    /**
     * Return the testing clock in UTC MySQL format.
     *
     * @return string
     */
    protected function get_testing_now_mysql() {
        $offset_minutes = (int) get_option( 'pmcpc_testing_time_offset_minutes', 0 );
        $timestamp      = current_time( 'timestamp', true ) + ( $offset_minutes * MINUTE_IN_SECONDS );
        return gmdate( 'Y-m-d H:i:s', $timestamp );
    }

    /**
     * Format an offset in minutes for human display.
     *
     * @param int $offset_minutes Offset in minutes.
     * @return string
     */
    protected function format_time_offset_minutes( $offset_minutes ) {
        $offset_minutes = (int) $offset_minutes;
        if ( 0 === $offset_minutes ) {
            return __( 'Real time', 'product-mailer-campaigns' );
        }

        $absolute = abs( $offset_minutes );
        $hours    = intdiv( $absolute, 60 );
        $minutes  = $absolute % 60;
        $parts    = array();

        if ( $hours > 0 ) {
            $parts[] = sprintf( _n( '%d hour', '%d hours', $hours, 'product-mailer-campaigns' ), $hours );
        }
        if ( $minutes > 0 ) {
            $parts[] = sprintf( _n( '%d minute', '%d minutes', $minutes, 'product-mailer-campaigns' ), $minutes );
        }

        if ( empty( $parts ) ) {
            $parts[] = __( '0 minutes', 'product-mailer-campaigns' );
        }

        return sprintf(
            $offset_minutes > 0 ? __( '%s ahead', 'product-mailer-campaigns' ) : __( '%s behind', 'product-mailer-campaigns' ),
            implode( ' ', $parts )
        );
    }


    /**
     * Format a MySQL datetime string for the debugger.
     *
     * @param string $mysql_datetime Datetime in UTC.
     * @return string
     */
    protected function format_debug_datetime( $mysql_datetime ) {
        $mysql_datetime = (string) $mysql_datetime;
        if ( '' === $mysql_datetime || '0000-00-00 00:00:00' === $mysql_datetime ) {
            return '—';
        }

        $timestamp = strtotime( $mysql_datetime . ' UTC' );
        if ( ! $timestamp ) {
            return $mysql_datetime;
        }

        return wp_date( 'Y-m-d H:i:s', $timestamp, wp_timezone() );
    }

    /**
     * Return a human-readable duration between now and a datetime.
     *
     * @param string $mysql_datetime Datetime in UTC.
     * @return string
     */
    protected function describe_time_until( $mysql_datetime ) {
        $mysql_datetime = (string) $mysql_datetime;
        if ( '' === $mysql_datetime || '0000-00-00 00:00:00' === $mysql_datetime ) {
            return '—';
        }

        $target = strtotime( $mysql_datetime . ' UTC' );
        if ( ! $target ) {
            return '—';
        }

        $now = current_time( 'timestamp', true ) + ( (int) get_option( 'pmcpc_testing_time_offset_minutes', 0 ) * MINUTE_IN_SECONDS );
        $diff = $target - $now;
        $human = human_time_diff( $now, $target );

        if ( $diff > 0 ) {
            return sprintf( __( 'In %s', 'product-mailer-campaigns' ), $human );
        }
        if ( $diff < 0 ) {
            return sprintf( __( 'Overdue by %s', 'product-mailer-campaigns' ), $human );
        }

        return __( 'Now', 'product-mailer-campaigns' );
    }

    /**
     * Build abandoned cart debug data for one email address.
     *
     * @param string $email Email address to inspect.
     * @return array<string,mixed>
     */

    protected function get_abandoned_cart_next_email_prediction( $status, $recovery_status, $recovery_step, $expected_abandon_at, $abandoned_at, $recovery_next_at ) {
        $label = '';
        $time  = '';
        if ( '' === (string) $recovery_status ) {
            $recovery_status = 'none';
        }

        if ( 'active' === $status ) {
            $label = __( 'Abandoned cart (Step 1)', 'product-mailer-campaigns' );
            if ( ! empty( $expected_abandon_at ) ) {
                $delay_minutes = 60;
                if ( class_exists( 'PMCPC_Abandoned_Carts' ) && method_exists( 'PMCPC_Abandoned_Carts', 'get_recovery_delay_minutes_for_step' ) ) {
                    $delay_minutes = (int) PMCPC_Abandoned_Carts::get_recovery_delay_minutes_for_step( 1 );
                }
                $time = gmdate( 'Y-m-d H:i:s', strtotime( $expected_abandon_at . ' UTC' ) + ( max( 0, $delay_minutes ) * 60 ) );
            }
        } elseif ( 'abandoned' === $status ) {
            if ( 'none' === $recovery_status || '' === $recovery_status ) {
                $label = __( 'Abandoned cart (Step 1)', 'product-mailer-campaigns' );
                if ( ! empty( $abandoned_at ) ) {
                    $delay_minutes = 60;
                    if ( class_exists( 'PMCPC_Abandoned_Carts' ) && method_exists( 'PMCPC_Abandoned_Carts', 'get_recovery_delay_minutes_for_step' ) ) {
                        $delay_minutes = (int) PMCPC_Abandoned_Carts::get_recovery_delay_minutes_for_step( 1 );
                    }
                    $time = gmdate( 'Y-m-d H:i:s', strtotime( $abandoned_at . ' UTC' ) + ( max( 0, $delay_minutes ) * 60 ) );
                }
            } elseif ( 'in_progress' === $recovery_status && ! empty( $recovery_next_at ) ) {
                $next_step = min( 3, max( 1, (int) $recovery_step + 1 ) );
                $label = sprintf( __( 'Abandoned cart (Step %d)', 'product-mailer-campaigns' ), $next_step );
                $time  = $recovery_next_at;
            }
        }

        if ( 'completed' === $recovery_status && ! empty( $recovery_step ) && (int) $recovery_step >= 3 ) {
            $label = __( 'Recovery complete', 'product-mailer-campaigns' );
            $time  = '';
        }

        return array(
            'label' => $label,
            'time'  => $time,
        );
    }

    protected function build_abandoned_cart_summary_html( $status, $recovery_status, $recovery_step, $prediction ) {
        $status_label = $status ? $status : '—';
        $status_class = 'pmcpc-status--neutral';
        $status_icon  = '⚪';
        if ( 'active' === $status ) {
            $status_class = 'pmcpc-status--active';
            $status_icon  = '🟢';
            $status_label = __( 'Active', 'product-mailer-campaigns' );
        } elseif ( 'abandoned' === $status ) {
            $status_class = 'pmcpc-status--abandoned';
            $status_icon  = '🔴';
            $status_label = __( 'Abandoned', 'product-mailer-campaigns' );
        }

        $recovery_label = $recovery_status ? $recovery_status : __( 'Not started', 'product-mailer-campaigns' );
        if ( 'none' === $recovery_status ) {
            $recovery_label = __( 'Not started', 'product-mailer-campaigns' );
        } elseif ( 'in_progress' === $recovery_status ) {
            $recovery_label = __( 'In progress', 'product-mailer-campaigns' );
        } elseif ( 'completed' === $recovery_status ) {
            $recovery_label = __( 'Completed', 'product-mailer-campaigns' );
        }

        $next_step = ! empty( $prediction['label'] ) ? $prediction['label'] : __( 'No further emails scheduled', 'product-mailer-campaigns' );
        if ( ! empty( $prediction['time'] ) ) {
            $remaining_text = $this->describe_time_until( $prediction['time'] );
            if ( false !== stripos( $remaining_text, 'Overdue by' ) && 'completed' !== $recovery_status ) {
                $next_step .= ' — ' . __( 'ready to queue', 'product-mailer-campaigns' );
            }
        }
        $html  = '<div class="pmcpc-summary-box__grid">';
        $html .= '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Cart status', 'product-mailer-campaigns' ) . '</span><strong class="' . esc_attr( $status_class ) . '">' . esc_html( $status_icon . ' ' . $status_label ) . '</strong></div>';
        $html .= '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Recovery', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( $recovery_label ) . '</strong></div>';
        $html .= '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Next step', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( $next_step ) . '</strong></div>';
        if ( ! empty( $prediction['time'] ) ) {
            $html .= '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Scheduled', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( $this->format_debug_datetime( $prediction['time'] ) ) . '</strong></div>';
        }
        if ( ! empty( $prediction['time'] ) && 'completed' !== $recovery_status ) {
            $html .= '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Time remaining', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( $this->describe_time_until( $prediction['time'] ) ) . '</strong></div>';
        }
        $html .= '<div><span class="pmcpc-summary-box__label">' . esc_html__( 'Current step', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html( (string) (int) $recovery_step ) . '</strong></div>';
        $html .= '</div>';

        return $html;
    }


    protected function get_abandoned_cart_step_delay_minutes( $step ) {
        $step = (int) $step;
        if ( $step < 1 || $step > 3 ) {
            return 0;
        }

        if ( class_exists( 'PMCPC_Abandoned_Carts' ) && method_exists( 'PMCPC_Abandoned_Carts', 'get_recovery_delay_minutes_for_step' ) ) {
            return max( 0, (int) PMCPC_Abandoned_Carts::get_recovery_delay_minutes_for_step( $step ) );
        }

        if ( 1 === $step ) {
            return 60;
        }
        if ( 2 === $step ) {
            return 1440;
        }
        return 4320;
    }

    protected function get_abandoned_cart_queue_row_for_step( $queue_rows, $step ) {
        $trigger = 'abandoned_cart_step_' . (int) $step;
        if ( ! is_array( $queue_rows ) ) {
            return null;
        }

        foreach ( $queue_rows as $queue_row ) {
            if ( isset( $queue_row['automation_trigger'] ) && $trigger === (string) $queue_row['automation_trigger'] ) {
                return $queue_row;
            }
        }

        return null;
    }

    protected function build_abandoned_cart_timeline_html( $status, $recovery_status, $recovery_step, $expected_abandon_at, $abandoned_at, $queue_rows ) {
        $steps = array();
        $anchor_time = '';

        if ( 'active' === $status ) {
            $anchor_time = $expected_abandon_at;
        } elseif ( 'abandoned' === $status || 'completed' === $recovery_status || 'in_progress' === $recovery_status || 'none' === $recovery_status ) {
            $anchor_time = $abandoned_at;
        }

        if ( empty( $anchor_time ) || '0000-00-00 00:00:00' === $anchor_time ) {
            return '';
        }

        $schedule_time = $anchor_time;
        for ( $step = 1; $step <= 3; $step++ ) {
            $delay_minutes = $this->get_abandoned_cart_step_delay_minutes( $step );
            $schedule_time = gmdate( 'Y-m-d H:i:s', strtotime( $schedule_time . ' UTC' ) + ( max( 0, $delay_minutes ) * 60 ) );
            $queue_row     = $this->get_abandoned_cart_queue_row_for_step( $queue_rows, $step );
            $label         = sprintf( __( 'Step %d', 'product-mailer-campaigns' ), $step );
            $state_icon    = '⏳';
            $state_label   = __( 'Scheduled', 'product-mailer-campaigns' );
            $is_due        = strtotime( $schedule_time . ' UTC' ) <= ( current_time( 'timestamp', true ) + ( (int) get_option( 'pmcpc_testing_time_offset_minutes', 0 ) * MINUTE_IN_SECONDS ) );

            if ( $queue_row ) {
                $queue_status = isset( $queue_row['status'] ) ? (string) $queue_row['status'] : '';
                if ( in_array( $queue_status, array( 'sent', 'processing' ), true ) ) {
                    $state_icon  = '✅';
                    $state_label = __( 'Sent or processing', 'product-mailer-campaigns' );
                } elseif ( 'pending' === $queue_status ) {
                    $state_icon  = '📬';
                    $state_label = __( 'Queued', 'product-mailer-campaigns' );
                } elseif ( 'failed' === $queue_status ) {
                    $state_icon  = '⚠️';
                    $state_label = __( 'Failed', 'product-mailer-campaigns' );
                }
            } elseif ( 'active' === $status ) {
                $state_label = __( 'Waiting for the cart to become abandoned', 'product-mailer-campaigns' );
            } elseif ( $step <= (int) $recovery_step ) {
                $state_icon  = '✅';
                $state_label = __( 'Already processed', 'product-mailer-campaigns' );
            } elseif ( 'completed' === $recovery_status ) {
                $state_label = __( 'Sequence finished', 'product-mailer-campaigns' );
            } elseif ( $is_due ) {
                $state_icon  = '⚠️';
                $state_label = __( 'Ready to queue', 'product-mailer-campaigns' );
            } elseif ( 1 === $step && 'none' === $recovery_status ) {
                $state_label = __( 'Waiting for Step 1 delay', 'product-mailer-campaigns' );
            } elseif ( $step === ( (int) $recovery_step + 1 ) && 'in_progress' === $recovery_status ) {
                $state_label = __( 'Next step due on schedule', 'product-mailer-campaigns' );
            }

            $steps[] = array(
                'label'        => $label,
                'status_icon'  => $state_icon,
                'status_label' => $state_label,
                'scheduled_at' => $schedule_time,
                'delay_minutes'=> $delay_minutes,
            );
        }

        $html  = '<div class="pmcpc-recovery-timeline">';
        $html .= '<h4>' . esc_html__( 'Recovery timeline', 'product-mailer-campaigns' ) . '</h4>';
        $html .= '<p class="description">' . esc_html__( 'This shows the planned abandoned-cart sequence for this customer so you can see what happens next and when each step becomes due.', 'product-mailer-campaigns' ) . '</p>';
        $html .= '<ol class="pmcpc-recovery-timeline__list">';

        foreach ( $steps as $step ) {
            $html .= '<li class="pmcpc-recovery-timeline__item">';
            $html .= '<div class="pmcpc-recovery-timeline__title"><strong>' . esc_html( $step['label'] ) . '</strong><span>' . esc_html( $step['status_icon'] . ' ' . $step['status_label'] ) . '</span></div>';
            $html .= '<div class="pmcpc-recovery-timeline__meta">';
            if ( 'Step 1' === $step['label'] ) {
                $html .= '<span>' . esc_html__( 'Campaign delay', 'product-mailer-campaigns' ) . ': ' . esc_html( sprintf( _n( '%d minute', '%d minutes', $step['delay_minutes'], 'product-mailer-campaigns' ), $step['delay_minutes'] ) ) . '</span>';
            } else {
                $html .= '<span>' . esc_html__( 'Delay', 'product-mailer-campaigns' ) . ': ' . esc_html( sprintf( _n( '%d minute', '%d minutes', $step['delay_minutes'], 'product-mailer-campaigns' ), $step['delay_minutes'] ) ) . '</span>';
            }
            $html .= '<span>' . esc_html__( 'Scheduled', 'product-mailer-campaigns' ) . ': ' . esc_html( $this->format_debug_datetime( $step['scheduled_at'] ) ) . '</span>';
            $html .= '<span>' . esc_html__( 'Remaining', 'product-mailer-campaigns' ) . ': ' . esc_html( $this->describe_time_until( $step['scheduled_at'] ) ) . '</span>';
            $html .= '</div>';
            $html .= '</li>';
        }

        $html .= '</ol></div>';

        return $html;
    }

    protected function get_abandoned_cart_debug_data( $email ) {
        global $wpdb;

        $table      = $wpdb->prefix . 'pmcpc_abandoned_carts';
        $queue_table = $wpdb->prefix . 'pmcpc_email_queue';
        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';

        $table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
        if ( $table_exists !== $table ) {
            return array(
                'error' => __( 'The abandoned carts table does not exist yet on this site.', 'product-mailer-campaigns' ),
            );
        }

        $columns = $wpdb->get_col( 'SHOW COLUMNS FROM ' . $table, 0 );
        if ( ! is_array( $columns ) ) {
            $columns = array();
        }

        $select_fields = array( 'id', 'session_key', 'email', 'status', 'created_at', 'updated_at', 'last_activity_at', 'abandoned_at', 'recovered_at' );
        foreach ( array( 'cart_total', 'currency', 'recovery_status', 'recovery_step', 'recovery_next_at', 'recovery_started_at', 'recovery_completed_at' ) as $optional_field ) {
            if ( in_array( $optional_field, $columns, true ) ) {
                $select_fields[] = $optional_field;
            }
        }

        $cart = $wpdb->get_row( $wpdb->prepare( 'SELECT ' . implode( ', ', $select_fields ) . ' FROM ' . $table . ' WHERE email = %s ORDER BY updated_at DESC, id DESC LIMIT 1', $email ), ARRAY_A );

        $queue_rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT q.scheduled_at, q.status, q.subject, c.name AS campaign_name, c.automation_trigger
                 FROM ' . $queue_table . ' q
                 LEFT JOIN ' . $campaigns_table . ' c ON c.id = q.campaign_id
                 WHERE q.to_email = %s
                   AND c.automation_trigger IN (%s, %s, %s)
                 ORDER BY q.created_at DESC, q.id DESC
                 LIMIT 5',
                $email,
                'abandoned_cart_step_1',
                'abandoned_cart_step_2',
                'abandoned_cart_step_3'
            ),
            ARRAY_A
        );
        if ( ! is_array( $queue_rows ) ) {
            $queue_rows = array();
        }

        $rows = array();
        $summary = '';

        if ( empty( $cart ) ) {
            $summary = __( 'No abandoned cart row was found for this email. That usually means the shopper never reached the point where their email was captured, or the cart capture logic did not run yet.', 'product-mailer-campaigns' );
            $rows[] = array(
                'label' => __( 'Cart found', 'product-mailer-campaigns' ),
                'value' => esc_html__( 'No', 'product-mailer-campaigns' ),
            );
            $rows[] = array(
                'label' => __( 'Reason not sent', 'product-mailer-campaigns' ),
                'value' => esc_html__( 'No cart record exists yet for this email address.', 'product-mailer-campaigns' ),
            );

            return array(
                'summary'      => $summary,
                'summary_html' => '<div class="pmcpc-summary-box__grid"><div><span class="pmcpc-summary-box__label">' . esc_html__( 'Cart status', 'product-mailer-campaigns' ) . '</span><strong class="pmcpc-status--neutral">⚪ ' . esc_html__( 'Not found', 'product-mailer-campaigns' ) . '</strong></div><div><span class="pmcpc-summary-box__label">' . esc_html__( 'Next step', 'product-mailer-campaigns' ) . '</span><strong>' . esc_html__( 'No cart captured yet', 'product-mailer-campaigns' ) . '</strong></div></div>',
                'copy_report'  => 'Email: ' . $email . "
" . 'Cart status: not found' . "
" . 'Reason not sent: No cart record exists yet for this email address.',
                'rows'         => $rows,
                'queue_rows'   => $queue_rows,
                'timeline_html'=> '',
            );
        }

        $status = isset( $cart['status'] ) ? (string) $cart['status'] : '';
        $recovery_status = isset( $cart['recovery_status'] ) ? (string) $cart['recovery_status'] : '';
        if ( '' === $recovery_status ) {
            $recovery_status = 'none';
        }
        $recovery_step = isset( $cart['recovery_step'] ) ? (int) $cart['recovery_step'] : 0;
        $recovery_next_at = isset( $cart['recovery_next_at'] ) ? (string) $cart['recovery_next_at'] : '';
        $abandoned_at = isset( $cart['abandoned_at'] ) ? (string) $cart['abandoned_at'] : '';
        $last_activity_at = isset( $cart['last_activity_at'] ) ? (string) $cart['last_activity_at'] : '';
        $abandon_window_minutes = (int) get_option( 'pmcpc_cart_abandon_minutes', 60 );
        if ( $abandon_window_minutes < 10 ) {
            $abandon_window_minutes = 10;
        }
        $expected_abandon_at = '';
        if ( ! empty( $last_activity_at ) && '0000-00-00 00:00:00' !== $last_activity_at ) {
            $expected_abandon_at = gmdate( 'Y-m-d H:i:s', strtotime( $last_activity_at . ' UTC' ) + ( $abandon_window_minutes * 60 ) );
        }

        $reason_not_sent = '';
        $next_prediction = $this->get_abandoned_cart_next_email_prediction( $status, $recovery_status, $recovery_step, $expected_abandon_at, $abandoned_at, $recovery_next_at );
        if ( empty( $cart['email'] ) ) {
            $reason_not_sent = __( 'Cart exists, but no email address was stored on it.', 'product-mailer-campaigns' );
        } elseif ( 'active' === $status ) {
            if ( ! empty( $abandoned_at ) || ( 'none' !== $recovery_status && '' !== $recovery_status ) || $recovery_step > 0 ) {
                $reason_not_sent = __( 'This customer has an active cart right now. The row also contains older abandoned-cart recovery data, which means the shopper returned and became active again after a previous recovery cycle.', 'product-mailer-campaigns' );
            } else {
                $reason_not_sent = __( 'Cart is still marked active, so the abandoned-cart recovery sequence has not started yet.', 'product-mailer-campaigns' );
            }
        } elseif ( 'abandoned' === $status && empty( $queue_rows ) && 'none' === $recovery_status ) {
            if ( ! empty( $next_prediction['time'] ) ) {
                $delay_text = $this->describe_time_until( $next_prediction['time'] );
                if ( false !== stripos( $delay_text, 'Overdue by' ) ) {
                    $reason_not_sent = sprintf( __( 'Step 1 is already due, but no queue row exists yet. This usually means the recovery runner did not process the cart, or the automation could not queue the email. Expected queue time: %s.', 'product-mailer-campaigns' ), $this->format_debug_datetime( $next_prediction['time'] ) );
                } else {
                    $reason_not_sent = sprintf( __( 'Email not queued yet. Waiting for the Step 1 delay to finish. Expected queue time: %s.', 'product-mailer-campaigns' ), $this->format_debug_datetime( $next_prediction['time'] ) );
                }
            } else {
                $reason_not_sent = __( 'Cart is abandoned, but the recovery runner has not started the sequence yet.', 'product-mailer-campaigns' );
            }
        } elseif ( 'abandoned' === $status && empty( $queue_rows ) && 'in_progress' === $recovery_status && ! empty( $recovery_next_at ) ) {
            $delay_text = $this->describe_time_until( $recovery_next_at );
            if ( false !== stripos( $delay_text, 'Overdue by' ) ) {
                $reason_not_sent = sprintf( __( 'The next recovery step is due, but no queue row exists yet. Scheduled time was %s.', 'product-mailer-campaigns' ), $this->format_debug_datetime( $recovery_next_at ) );
            } else {
                $reason_not_sent = sprintf( __( 'Recovery is in progress. The next step is scheduled for %s.', 'product-mailer-campaigns' ), $this->format_debug_datetime( $recovery_next_at ) );
            }
        } elseif ( 'completed' === $recovery_status && empty( $queue_rows ) ) {
            $reason_not_sent = __( 'Recovery sequence shows as completed, but no queue row was found for this email. Check queue cleanup or campaign configuration.', 'product-mailer-campaigns' );
        } elseif ( ! empty( $queue_rows ) ) {
            $latest_status = isset( $queue_rows[0]['status'] ) ? (string) $queue_rows[0]['status'] : '';
            $reason_not_sent = sprintf( __( 'At least one abandoned-cart email was queued. Latest queue status: %s.', 'product-mailer-campaigns' ), $latest_status );
        } else {
            $reason_not_sent = __( 'No obvious blocker detected. If recovery emails are not sending, check that WP-Cron is running and that the email queue processor is active.', 'product-mailer-campaigns' );
        }

        $summary = sprintf( __( 'Cart status: %1$s. Recovery status: %2$s. Current step: %3$d.', 'product-mailer-campaigns' ), $status ? $status : '—', $recovery_status ? $recovery_status : '—', $recovery_step );
        $summary_html = $this->build_abandoned_cart_summary_html( $status, $recovery_status, $recovery_step, $next_prediction );
        $timeline_html = $this->build_abandoned_cart_timeline_html( $status, $recovery_status, $recovery_step, $expected_abandon_at, $abandoned_at, $queue_rows );

        $rows[] = array( 'label' => __( 'Cart found', 'product-mailer-campaigns' ), 'value' => esc_html__( 'Yes', 'product-mailer-campaigns' ) );
        $rows[] = array( 'label' => __( 'Customer email', 'product-mailer-campaigns' ), 'value' => esc_html( (string) $cart['email'] ) );
        $rows[] = array( 'label' => __( 'Cart status', 'product-mailer-campaigns' ), 'value' => esc_html( $status ? $status : '—' ) );
        if ( isset( $cart['cart_total'] ) ) {
            $rows[] = array( 'label' => __( 'Cart total', 'product-mailer-campaigns' ), 'value' => esc_html( (string) $cart['cart_total'] . ( ! empty( $cart['currency'] ) ? ' ' . (string) $cart['currency'] : '' ) ) );
        }
        $rows[] = array( 'label' => __( 'Last activity', 'product-mailer-campaigns' ), 'value' => esc_html( $this->format_debug_datetime( $last_activity_at ) ) );
        $rows[] = array( 'label' => __( 'Abandon window', 'product-mailer-campaigns' ), 'value' => esc_html( sprintf( _n( '%d minute', '%d minutes', $abandon_window_minutes, 'product-mailer-campaigns' ), $abandon_window_minutes ) ) );
        $rows[] = array( 'label' => __( 'Expected abandon at', 'product-mailer-campaigns' ), 'value' => esc_html( $this->format_debug_datetime( $expected_abandon_at ) ) );
        if ( 'active' === $status && $expected_abandon_at ) {
            $rows[] = array( 'label' => __( 'Time until abandon', 'product-mailer-campaigns' ), 'value' => esc_html( $this->describe_time_until( $expected_abandon_at ) ) );
        }
        $rows[] = array( 'label' => __( 'Abandoned at', 'product-mailer-campaigns' ), 'value' => esc_html( $this->format_debug_datetime( $abandoned_at ) ) );
        $rows[] = array( 'label' => __( 'Recovery status', 'product-mailer-campaigns' ), 'value' => esc_html( $recovery_status ? $recovery_status : '—' ) );
        $rows[] = array( 'label' => __( 'Recovery step sent', 'product-mailer-campaigns' ), 'value' => esc_html( (string) $recovery_step ) );
        $rows[] = array( 'label' => __( 'Recovery eligible at', 'product-mailer-campaigns' ), 'value' => esc_html( $this->format_debug_datetime( $recovery_next_at ) ) );
        if ( ! empty( $next_prediction['label'] ) ) {
            $rows[] = array( 'label' => __( 'Next email', 'product-mailer-campaigns' ), 'value' => esc_html( $next_prediction['label'] ) );
        }
        if ( ! empty( $next_prediction['time'] ) ) {
            $rows[] = array( 'label' => __( 'Next email scheduled', 'product-mailer-campaigns' ), 'value' => esc_html( $this->format_debug_datetime( $next_prediction['time'] ) ) );
            $rows[] = array( 'label' => __( 'Delay remaining', 'product-mailer-campaigns' ), 'value' => esc_html( $this->describe_time_until( $next_prediction['time'] ) ) );
        }
        if ( isset( $cart['recovery_started_at'] ) ) {
            $rows[] = array( 'label' => __( 'Recovery started at', 'product-mailer-campaigns' ), 'value' => esc_html( $this->format_debug_datetime( ! empty( $cart['recovery_started_at'] ) ? (string) $cart['recovery_started_at'] : '' ) ) );
        }
        if ( isset( $cart['recovery_completed_at'] ) ) {
            $rows[] = array( 'label' => __( 'Recovery completed at', 'product-mailer-campaigns' ), 'value' => esc_html( $this->format_debug_datetime( ! empty( $cart['recovery_completed_at'] ) ? (string) $cart['recovery_completed_at'] : '' ) ) );
        }
        $rows[] = array( 'label' => __( 'Recent abandoned-cart queue rows', 'product-mailer-campaigns' ), 'value' => esc_html( (string) count( $queue_rows ) ) );
        $rows[] = array( 'label' => __( 'Reason not sent', 'product-mailer-campaigns' ), 'value' => esc_html( $reason_not_sent ) );

        $copy_lines = array(
            'Email: ' . (string) $cart['email'],
            'Cart status: ' . ( $status ? $status : '—' ),
            'Last activity: ' . $this->format_debug_datetime( $last_activity_at ),
            'Abandoned at: ' . $this->format_debug_datetime( $abandoned_at ),
            'Recovery status: ' . ( $recovery_status ? $recovery_status : '—' ),
            'Recovery step: ' . (string) $recovery_step,
            'Next email: ' . ( ! empty( $next_prediction['label'] ) ? $next_prediction['label'] : '—' ),
            'Next scheduled: ' . ( ! empty( $next_prediction['time'] ) ? $this->format_debug_datetime( $next_prediction['time'] ) : '—' ),
            'Queue rows: ' . (string) count( $queue_rows ),
            'Reason not sent: ' . wp_strip_all_tags( $reason_not_sent ),
        );

        return array(
            'summary'      => $summary,
            'summary_html' => $summary_html,
            'timeline_html'=> $timeline_html,
            'copy_report'  => implode( "
", $copy_lines ),
            'rows'         => $rows,
            'queue_rows'   => $queue_rows,
        );
    }

}
