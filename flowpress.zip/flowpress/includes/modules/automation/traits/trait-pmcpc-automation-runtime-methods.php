<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Runtime trigger and delivery methods for FlowPress automations.
 */
trait PMCPC_Automation_Runtime_Methods {
    /**
     * Register runtime hooks used for Pro automation triggers.
     */
    public function register_runtime_hooks() {
        // Core subscriber-based automations should keep working without WooCommerce.
        // Use single events to avoid recurring cron reschedule/unschedule noise on
        // restricted hosts.
        $this->cleanup_legacy_automation_recurring_events_once();
        $this->ensure_automation_single_event( self::CRON_HOOK_CORE, 5 * MINUTE_IN_SECONDS );

        // Requires WooCommerce to be installed/active for runtime automation triggers.
        // NOTE: do not require PMCPC_Campaign_Manager here. On some setups the campaign manager
        // class is loaded later in the request lifecycle, which would prevent cron scheduling.
        // Handlers below perform their own safety checks.
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        // Only register WooCommerce runtime hooks when ecommerce automation is enabled
        // (trial or active license).
        if ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() ) {
            return;
        }

        // WooCommerce event-based triggers.
        add_action( 'woocommerce_order_status_completed', array( $this, 'handle_wc_order_completed' ), 20, 1 );

        // Schedule cron for inactive/win-back checks.
        // Start a few minutes in the future to avoid running on activation spikes.
        $this->ensure_automation_single_event( self::CRON_HOOK_INACTIVE, 5 * MINUTE_IN_SECONDS );
    }

    /**
     * Handle WooCommerce order completion for Pro triggers.
     *
     * Triggers supported:
     * - new_customer: first completed order
     * - high_value: crosses lifetime spend threshold (fires once per campaign per subscriber)
     *
     * @param int $order_id
     */
    public function handle_wc_order_completed( $order_id ) {
        // If ecommerce automation is not enabled, do nothing (extra safety).
        if ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() ) {
            return;
        }

        // Safety: if WooCommerce helper functions aren't available, bail.
        if ( ! function_exists( 'wc_get_order' ) ) {
            return;
        }
        // Safety: if the campaign manager isn't available, we can't queue campaigns.
        if ( ! class_exists( 'PMCPC_Campaign_Manager' ) ) {
            return;
        }

        $order_id = absint( $order_id );
        if ( ! $order_id ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $email = sanitize_email( $order->get_billing_email() );
        if ( empty( $email ) ) {
            return;
        }

        $subscriber = $this->get_subscriber_by_email( $email );
        if ( ! $subscriber ) {
            return;
        }

        // Context passed to template vars / downstream filters.
        $context = array(
            'order_id' => $order_id,
        );

        // POST-PURCHASE: fire for every completed order.
        if ( class_exists( 'PMCPC_Automation_Dispatcher' ) ) {
            PMCPC_Automation_Dispatcher::dispatch( 'post_purchase', $email, $context );
            PMCPC_Automation_Dispatcher::dispatch( 'review_request', $email, $context );
        } else {
            $this->queue_automation_campaigns_for_subscriber( 'post_purchase', $subscriber );
            $this->queue_automation_campaigns_for_subscriber( 'review_request', $subscriber );
        }

        // REPEAT CUSTOMER: second (or later) completed order.
        if ( $this->get_completed_order_count_for_order( $order ) >= 2 ) {
            if ( class_exists( 'PMCPC_Automation_Dispatcher' ) ) {
                PMCPC_Automation_Dispatcher::dispatch( 'repeat_customer', $email, $context );
            } else {
                $this->queue_automation_campaigns_for_subscriber( 'repeat_customer', $subscriber );
            }
        }

        // NEW CUSTOMER: first completed order.
        if ( $this->is_first_completed_order_for_customer( $order ) ) {
			if ( class_exists( 'PMCPC_Automation_Dispatcher' ) ) {
				PMCPC_Automation_Dispatcher::dispatch( 'new_customer', $email, $context );
			} else {
				$this->queue_automation_campaigns_for_subscriber( 'new_customer', $subscriber );
			}
        }

        // HIGH VALUE: crosses the configured threshold from below to at/above.
        if ( $this->did_customer_cross_high_value_threshold( $order ) ) {
			if ( class_exists( 'PMCPC_Automation_Dispatcher' ) ) {
				PMCPC_Automation_Dispatcher::dispatch( 'high_value', $email, $context );
			} else {
				$this->queue_automation_campaigns_for_subscriber( 'high_value', $subscriber );
			}
        }

        // VIP: crosses the configured VIP threshold from below to at/above.
        if ( $this->did_customer_cross_vip_threshold( $order ) ) {
            if ( class_exists( 'PMCPC_Automation_Dispatcher' ) ) {
                PMCPC_Automation_Dispatcher::dispatch( 'vip_customer', $email, $context );
            } else {
                $this->queue_automation_campaigns_for_subscriber( 'vip_customer', $subscriber );
            }
        }
    }

    /**
     * Get completed order count for the customer who placed the given order.
     *
     * @param WC_Order $order
     * @return int
     */
    protected function get_completed_order_count_for_order( $order ) {
        if ( ! $order || ! is_object( $order ) ) {
            return 0;
        }

        // Logged-in customers: use WooCommerce helper.
        $user_id = absint( $order->get_user_id() );
        if ( $user_id && function_exists( 'wc_get_customer_order_count' ) ) {
            return (int) wc_get_customer_order_count( $user_id );
        }

        // Guest customers: best-effort by billing email.
        $email = sanitize_email( $order->get_billing_email() );
        if ( empty( $email ) || ! function_exists( 'wc_get_orders' ) ) {
            return 0;
        }

        $ids = wc_get_orders( array(
            'limit'         => 2,
            'status'        => array( 'wc-completed' ),
            'billing_email' => $email,
            'return'        => 'ids',
            'orderby'       => 'date',
            'order'         => 'DESC',
        ) );

        if ( empty( $ids ) || ! is_array( $ids ) ) {
            return 0;
        }

        return count( $ids );
    }

    /**
     * Cron: find inactive customers and queue win-back campaigns.
     */
    public function cron_check_inactive_customers() {
        // Self-reschedule as a single event. The current event has already been
        // removed by wp-cron when this callback runs.
        $this->ensure_automation_single_event( self::CRON_HOOK_INACTIVE, HOUR_IN_SECONDS );

        // Single batch run (same logic as the manual testing tool).
        $this->run_inactive_scan_batch( false );
    }

    /**
     * Schedule an automation cron hook as a single event when it is missing.
     *
     * @param string $hook  Cron hook name.
     * @param int    $delay Delay in seconds.
     * @return void
     */
    protected function ensure_automation_single_event( $hook, $delay ) {
        $hook = (string) $hook;
        if ( '' === $hook || wp_next_scheduled( $hook ) ) {
            return;
        }

        wp_schedule_single_event( time() + absint( $delay ), $hook );
    }

    /**
     * Remove legacy recurring automation events once; leave single events alone.
     *
     * @return void
     */
    protected function cleanup_legacy_automation_recurring_events_once() {
        if ( 'yes' === (string) get_option( 'pmcpc_automation_single_event_cron_migrated', 'no' ) ) {
            return;
        }

        $this->remove_recurring_automation_events_for_hook( self::CRON_HOOK_CORE );
        $this->remove_recurring_automation_events_for_hook( self::CRON_HOOK_INACTIVE );

        update_option( 'pmcpc_automation_single_event_cron_migrated', 'yes', false );
    }

    /**
     * Directly remove recurring cron entries for a hook without touching single events.
     *
     * @param string $hook Cron hook name.
     * @return void
     */
    protected function remove_recurring_automation_events_for_hook( $hook ) {
        if ( ! function_exists( '_get_cron_array' ) || ! function_exists( '_set_cron_array' ) ) {
            return;
        }

        $crons   = _get_cron_array();
        $changed = false;

        if ( empty( $crons ) || ! is_array( $crons ) ) {
            return;
        }

        foreach ( $crons as $timestamp => $hooks ) {
            if ( empty( $hooks[ $hook ] ) || ! is_array( $hooks[ $hook ] ) ) {
                continue;
            }

            foreach ( $hooks[ $hook ] as $key => $event ) {
                if ( ! empty( $event['schedule'] ) ) {
                    unset( $crons[ $timestamp ][ $hook ][ $key ] );
                    $changed = true;
                }
            }

            if ( empty( $crons[ $timestamp ][ $hook ] ) ) {
                unset( $crons[ $timestamp ][ $hook ] );
            }
            if ( empty( $crons[ $timestamp ] ) ) {
                unset( $crons[ $timestamp ] );
            }
        }

        if ( $changed ) {
            _set_cron_array( $crons );
        }
    }

    /**
     * Run a single batch of inactive customer scanning.
     *
     * This is used by both WP-Cron and the manual admin tool.
     *
     * @param bool $reset   Whether to reset the batch offset before scanning.
     * @param bool $dry_run If true, do not queue emails; only report how many would be queued.
     * @return array{processed:int,queued:int,offset_before:int,offset_after:int,done:bool}
     */
    protected function run_inactive_scan_batch( $reset = false, $dry_run = false, $max_queue = 0 ) {
        $reset     = (bool) $reset;
        $dry_run   = (bool) $dry_run;
        $max_queue = absint( $max_queue );

        if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
            return array( 'processed' => 0, 'queued' => 0, 'offset_before' => 0, 'offset_after' => 0, 'done' => true );
        }
        if ( ! class_exists( 'PMCPC_Campaign_Manager' ) ) {
            return array( 'processed' => 0, 'queued' => 0, 'offset_before' => 0, 'offset_after' => 0, 'done' => true );
        }

        // Pull lapsed-days from the free plugin settings.
        $lapsed_days = 180;
        if ( class_exists( 'PMCPC_Settings' ) ) {
            $lapsed_days = absint( PMCPC_Settings::get( 'lifecycle_lapsed_days', '180' ) );
        }
        if ( $lapsed_days <= 0 ) {
            return array( 'processed' => 0, 'queued' => 0, 'offset_before' => 0, 'offset_after' => 0, 'done' => true );
        }

        $high_value_threshold = 0.0;
        if ( class_exists( 'PMCPC_Settings' ) ) {
            $high_value_threshold = (float) PMCPC_Settings::get( 'lifecycle_high_value_threshold', '0' );
        }
        $lapsed_high_value_days = (int) apply_filters( 'pmcpc_lapsed_high_value_days', 90 );
        if ( $lapsed_high_value_days <= 0 ) {
            $lapsed_high_value_days = 90;
        }

        $cutoff_ts = strtotime( '-' . $lapsed_days . ' days', time() );
        if ( ! $cutoff_ts ) {
            return array( 'processed' => 0, 'queued' => 0, 'offset_before' => 0, 'offset_after' => 0, 'done' => true );
        }
        $high_value_cutoff_ts = strtotime( '-' . $lapsed_high_value_days . ' days', time() );
        if ( ! $high_value_cutoff_ts ) {
            $high_value_cutoff_ts = $cutoff_ts;
        }

        global $wpdb;
        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
        $batch_size        = 200;

        if ( $reset ) {
            update_option( 'pmcpc_pro_inactive_offset', 0, false );
        }

        $offset_before = absint( get_option( 'pmcpc_pro_inactive_offset', 0 ) );
        $queued        = 0;
        $processed     = 0;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $subs = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM %i WHERE status = %s ORDER BY id ASC LIMIT %d OFFSET %d',
                $subscribers_table,
                'active',
                $batch_size,
                $offset_before
            )
        );

        if ( empty( $subs ) ) {
            // Reset for next run.
            update_option( 'pmcpc_pro_inactive_offset', 0, false );
            return array(
                'processed'     => 0,
                'queued'        => 0,
                'offset_before' => $offset_before,
                'offset_after'  => 0,
                'done'          => true,
            );
        }

        foreach ( $subs as $sub ) {
            if ( $max_queue > 0 && $queued >= $max_queue ) {
                break;
            }
            if ( empty( $sub->email ) ) {
                continue;
            }
            $email = sanitize_email( $sub->email );
            if ( empty( $email ) ) {
                continue;
            }

            $processed++;

            $last_ts = $this->get_last_completed_order_timestamp_by_email( $email );
            if ( ! $last_ts ) {
                continue;
            }
            if ( $last_ts <= $cutoff_ts ) {
                if ( $dry_run ) {
                    $would = $this->count_queueable_campaigns_for_subscriber( 'customer_inactive', $sub );
                    if ( $max_queue > 0 ) {
                        $would = min( $would, max( 0, $max_queue - $queued ) );
                    }
                    $queued += $would;
                } else {
                    $before = $this->get_queue_count_for_subscriber( (int) $sub->id );
                    $this->queue_automation_campaigns_for_subscriber( 'customer_inactive', $sub );
                    $after = $this->get_queue_count_for_subscriber( (int) $sub->id );
                    if ( $after > $before ) {
                        $added = ( $after - $before );
                        if ( $max_queue > 0 ) {
                            $added = min( $added, max( 0, $max_queue - $queued ) );
                        }
                        $queued += $added;
                    }
                }
            }

            if ( $high_value_threshold > 0 && $last_ts <= $high_value_cutoff_ts ) {
                $total_spent = (float) $this->get_total_spent_by_email( $email );
                if ( $total_spent >= $high_value_threshold ) {
                    if ( $dry_run ) {
                        $would = $this->count_queueable_campaigns_for_subscriber( 'lapsed_high_value_customer', $sub );
                        if ( $max_queue > 0 ) {
                            $would = min( $would, max( 0, $max_queue - $queued ) );
                        }
                        $queued += $would;
                    } else {
                        $before = $this->get_queue_count_for_subscriber( (int) $sub->id );
                        $this->queue_automation_campaigns_for_subscriber( 'lapsed_high_value_customer', $sub );
                        $after = $this->get_queue_count_for_subscriber( (int) $sub->id );
                        if ( $after > $before ) {
                            $added = ( $after - $before );
                            if ( $max_queue > 0 ) {
                                $added = min( $added, max( 0, $max_queue - $queued ) );
                            }
                            $queued += $added;
                        }
                    }
                }
            }
        }

        $offset_after = $offset_before + $batch_size;
        update_option( 'pmcpc_pro_inactive_offset', $offset_after, false );

        return array(
            'processed'     => $processed,
            'queued'        => $queued,
            'offset_before' => $offset_before,
            'offset_after'  => $offset_after,
            'done'          => false,
        );
    }

    /**
     * Best-effort helper: count current queued rows for a subscriber.
     * Used only for manual scan stats; it doesn't affect send logic.
     */
    protected function get_queue_count_for_subscriber( $subscriber_id ) {
        global $wpdb;
        $subscriber_id = absint( $subscriber_id );
        if ( ! $subscriber_id ) {
            return 0;
        }
        // Queue table is pmcpc_email_queue (legacy-safe). Some earlier builds referenced pmcpc_queue.
        $queue_table = $wpdb->prefix . 'pmcpc_email_queue';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(1) FROM %i WHERE subscriber_id = %d', $queue_table, $subscriber_id ) );
    }

    /**
     * Dry-run helper: count how many campaigns would be queued for a subscriber for a given trigger.
     *
     * Mirrors the free plugin's de-dupe logic (pending/sent) without inserting into the queue.
     *
     * @param string $trigger
     * @param object $subscriber
     * @return int
     */
    protected function count_queueable_campaigns_for_subscriber( $trigger, $subscriber ) {
        global $wpdb;

        $trigger = sanitize_key( (string) $trigger );
        if ( empty( $trigger ) || empty( $subscriber ) || empty( $subscriber->id ) ) {
            return 0;
        }

        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        $queue_table     = $wpdb->prefix . 'pmcpc_email_queue';

        $campaigns = $this->get_matching_campaigns_for_simulation( $trigger, $campaigns_table );

        if ( empty( $campaigns ) ) {
            return 0;
        }

        $count = 0;

        foreach ( $campaigns as $campaign ) {
            $candidates = array( $subscriber );
            $filtered   = apply_filters( 'pmcpc_campaign_subscribers', $candidates, $campaign );
            if ( empty( $filtered ) || ! is_array( $filtered ) ) {
                continue;
            }
            $target = reset( $filtered );
            if ( empty( $target ) ) {
                continue;
            }

            // Mirror free plugin de-dupe: pending/sent means it would not queue.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $existing_id = (int) $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT id FROM %i WHERE subscriber_id = %d AND campaign_id = %d AND status IN (\'pending\', \'sent\') LIMIT 1',
                    $queue_table,
                    (int) $target->id,
                    (int) $campaign->id
                )
            );
            if ( $existing_id > 0 ) {
                continue;
            }

            $count++;
        }

        return $count;
    }

    /**
     * Get subscriber row for an email.
     *
     * @param string $email
     * @return object|null
     */
    protected function get_subscriber_by_email( $email ) {
        global $wpdb;
        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
        $email             = sanitize_email( $email );
        if ( empty( $email ) ) {
            return null;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $subscriber = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM %i WHERE email = %s', $subscribers_table, $email )
        );

        return $subscriber ? $subscriber : null;
    }

    /**
     * Queue all campaigns that use a given Pro automation trigger for a single subscriber.
     *
     * Uses the free plugin's queue logic (includes de-dupe).
     *
     * @param string $trigger
     * @param object $subscriber
     */
    protected function queue_automation_campaigns_for_subscriber( $trigger, $subscriber ) {
        global $wpdb;
        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        $trigger         = sanitize_key( (string) $trigger );
        if ( empty( $trigger ) || empty( $subscriber ) || empty( $subscriber->id ) ) {
            return;
        }

        $campaigns = $this->get_matching_campaigns_for_simulation( $trigger, $campaigns_table );

        if ( empty( $campaigns ) ) {
            return;
        }

        foreach ( $campaigns as $campaign ) {
            // Prefer the canonical trigger delay so multi-step workflows can stagger each email.
            if ( isset( $campaign->trigger_delay_minutes ) && absint( $campaign->trigger_delay_minutes ) > 0 ) {
                $delay = absint( $campaign->trigger_delay_minutes );
            } else {
                $delay = isset( $campaign->broadcast_delay_minutes ) ? absint( $campaign->broadcast_delay_minutes ) : 0;
            }

            $candidates = array( $subscriber );
            $filtered   = apply_filters( 'pmcpc_campaign_subscribers', $candidates, $campaign );
            if ( empty( $filtered ) || ! is_array( $filtered ) ) {
                continue;
            }

            $target = reset( $filtered );
            if ( empty( $target ) ) {
                continue;
            }

            // Queue (free plugin handles de-dupe per campaign+subscriber).
            PMCPC_Campaign_Manager::queue_campaign_for_subscriber( $campaign, $target, $delay );
        }
    }



    protected function get_simulation_trigger_aliases( $trigger ) {
        return $this->get_trigger_aliases( $trigger );
    }

    protected function get_matching_campaigns_for_simulation( $trigger, $campaigns_table ) {
        global $wpdb;

        $aliases = $this->get_simulation_trigger_aliases( $trigger );
        $where   = array();
        $args    = array();

        foreach ( $aliases as $alias ) {
            $where[] = 'automation_trigger = %s';
            $args[]  = $alias;
        }

        if ( 'new_subscriber' === $trigger ) {
            $where[] = 'is_welcome = 1';
        }
        if ( 'post_purchase' === $trigger ) {
            $where[] = 'is_post_purchase = 1';
        }

        if ( empty( $where ) ) {
            return array();
        }

        $sql      = "SELECT * FROM {$campaigns_table} WHERE status = 'active' AND (" . implode( ' OR ', $where ) . ')';
        $prepared = ! empty( $args ) ? $wpdb->prepare( $sql, $args ) : $sql;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->get_results( $prepared );
    }

    protected function get_simulation_existing_delivery( $queue_table, $campaign_id, $subscriber_id ) {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, status, scheduled_at, created_at FROM {$queue_table} WHERE subscriber_id = %d AND campaign_id = %d AND status IN ('pending', 'sent') ORDER BY id DESC LIMIT 1",
                (int) $subscriber_id,
                (int) $campaign_id
            )
        );

        if ( empty( $row ) ) {
            return null;
        }

        return $row;
    }

    protected function get_recent_simulation_history_for_subscriber( $subscriber, $limit = 6 ) {
        global $wpdb;

        if ( empty( $subscriber ) || empty( $subscriber->id ) ) {
            return array();
        }

        $limit           = max( 1, min( 10, (int) $limit ) );
        $queue_table     = $wpdb->prefix . 'pmcpc_email_queue';
        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT q.status, q.scheduled_at, q.created_at, c.name AS campaign_name, c.automation_trigger
                 FROM {$queue_table} q
                 LEFT JOIN {$campaigns_table} c ON c.id = q.campaign_id
                 WHERE q.subscriber_id = %d
                 ORDER BY q.id DESC
                 LIMIT %d",
                (int) $subscriber->id,
                $limit
            ),
            ARRAY_A
        );

        return is_array( $rows ) ? $rows : array();
    }

    /**
     * Simulate a trigger for a single subscriber.
     *
     * This uses the same campaign matching + segment filtering as live sends, but can run as a dry run.
     *
     * @param string $trigger
     * @param object $subscriber
     * @param bool   $dry_run
     * @return array{campaigns:int,eligible:int,queued:int,error:string}
     */
    protected function simulate_trigger_for_subscriber( $trigger, $subscriber, $dry_run = false ) {
        global $wpdb;

        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        $trigger         = sanitize_key( (string) $trigger );
        $dry_run         = (bool) $dry_run;

        if ( empty( $trigger ) || empty( $subscriber ) || empty( $subscriber->id ) ) {
            return array( 'campaigns' => 0, 'eligible' => 0, 'queued' => 0, 'error' => __( 'Invalid trigger or subscriber.', 'product-mailer-campaigns' ) );
        }

		// Only allow the triggers we support for simulation.
		// Note: simulation does not fabricate orders/thresholds; it only checks which
		// campaigns would be eligible for the selected subscriber right now.
		$allowed = array(
			'post_purchase',
			'review_request',
			'new_customer',
			'high_value',
			'lapsed_high_value_customer',
			'customer_inactive',
			'new_subscriber',
			'welcome_follow_up',
			'repeat_customer',
			'vip_customer',
			'abandoned_cart_step_1',
			'abandoned_cart_step_2',
			'abandoned_cart_step_3',
		);
        if ( ! in_array( $trigger, $allowed, true ) ) {
            if ( in_array( $trigger, array( 'subscriber_birthday', 'subscriber_anniversary' ), true ) ) {
                return array( 'campaigns' => 0, 'eligible' => 0, 'queued' => 0, 'error' => __( 'This trigger depends on subscriber profile data and cannot be simulated in Quick Test.', 'product-mailer-campaigns' ) );
            }
            if ( in_array( $trigger, array( 'specific_date', 'one_time', 'recurring' ), true ) ) {
                return array( 'campaigns' => 0, 'eligible' => 0, 'queued' => 0, 'error' => __( 'This is a date-based send and cannot be simulated in Quick Test.', 'product-mailer-campaigns' ) );
            }
            return array( 'campaigns' => 0, 'eligible' => 0, 'queued' => 0, 'error' => __( 'That trigger cannot be simulated in Quick Test.', 'product-mailer-campaigns' ) );
        }

        $campaigns = $this->get_matching_campaigns_for_simulation( $trigger, $campaigns_table );

        if ( empty( $campaigns ) ) {
            return array( 'campaigns' => 0, 'eligible' => 0, 'queued' => 0, 'error' => '' );
        }

        $campaign_count = 0;
        $eligible_count = 0;
        $queued_count   = 0;
        $details        = array();

        $queue_table = $wpdb->prefix . 'pmcpc_email_queue';

        foreach ( $campaigns as $campaign ) {
            $campaign_count++;
            $detail = array(
                'campaign_id' => isset( $campaign->id ) ? absint( $campaign->id ) : 0,
                'title'       => isset( $campaign->name ) ? (string) $campaign->name : ( isset( $campaign->title ) ? (string) $campaign->title : (string) __( '(Untitled campaign)', 'product-mailer-campaigns' ) ),
                'eligible'    => false,
                'action'      => $dry_run ? 'skip' : 'skip',
                'reason'      => '',
            );

            // Apply Pro segment filters via the free plugin filter hook.
            $candidates = array( $subscriber );
            $filtered   = apply_filters( 'pmcpc_campaign_subscribers', $candidates, $campaign );
            if ( empty( $filtered ) || ! is_array( $filtered ) ) {
                $detail['reason'] = __( 'Filtered out by audience rules (segment/tags).', 'product-mailer-campaigns' );
                $details[]        = $detail;
                continue;
            }

            $target = reset( $filtered );
            if ( empty( $target ) || empty( $target->id ) ) {
                $detail['reason'] = __( 'Filtered out by audience rules (segment/tags).', 'product-mailer-campaigns' );
                $details[]        = $detail;
                continue;
            }

            $detail['eligible'] = true;
            $eligible_count++;

            // Mirror free plugin de-dupe: pending/sent means it would not queue.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $existing_id = (int) $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT id FROM %i WHERE subscriber_id = %d AND campaign_id = %d AND status IN (\'pending\', \'sent\') LIMIT 1',
                    $queue_table,
                    (int) $target->id,
                    (int) $campaign->id
                )
            );
            if ( $existing_id > 0 ) {
                $detail['reason'] = __( 'Already queued or sent for this subscriber.', 'product-mailer-campaigns' );
                $details[]        = $detail;
                continue;
            }

            if ( $dry_run ) {
                $detail['action'] = 'would_queue';
                $queued_count++;
                $details[] = $detail;
                continue;
            }

            $delay = isset( $campaign->broadcast_delay_minutes ) ? absint( $campaign->broadcast_delay_minutes ) : 0;
            PMCPC_Campaign_Manager::queue_campaign_for_subscriber( $campaign, $target, $delay );
            $detail['action'] = 'queued';
            $queued_count++;
            $details[] = $detail;
        }

        return array(
            'campaigns' => (int) $campaign_count,
            'eligible'  => (int) $eligible_count,
            'queued'    => (int) $queued_count,
            'details'   => $details,
            'error'     => '',
        );
    }

    /**
     * Determine if this is the customer's first completed order.
     *
     * @param WC_Order $order
     * @return bool
     */
    protected function is_first_completed_order_for_customer( $order ) {
        if ( ! $order || ! is_object( $order ) ) {
            return false;
        }
        $user_id = absint( $order->get_user_id() );
        $email   = sanitize_email( $order->get_billing_email() );

        $args = array(
            'limit'   => 2,
            'status'  => array( 'wc-completed' ),
            'return'  => 'ids',
            'orderby' => 'date',
            'order'   => 'DESC',
        );
        if ( $user_id ) {
            $args['customer_id'] = $user_id;
        } elseif ( $email ) {
            $args['billing_email'] = $email;
        } else {
            return false;
        }

        $ids = wc_get_orders( $args );
        if ( empty( $ids ) || ! is_array( $ids ) ) {
            return false;
        }

        // If there is exactly one completed order, this is the first.
        return ( 1 === count( $ids ) );
    }

    /**
     * Check if customer crossed the high-value threshold with this order.
     *
     * Fires only when moving from below -> at/above threshold.
     *
     * @param WC_Order $order
     * @return bool
     */
    protected function did_customer_cross_high_value_threshold( $order ) {
        if ( ! $order || ! is_object( $order ) ) {
            return false;
        }

        $threshold = 0.0;
        if ( class_exists( 'PMCPC_Settings' ) ) {
            $threshold = (float) PMCPC_Settings::get( 'lifecycle_high_value_threshold', '0' );
        }
        if ( $threshold <= 0 ) {
            return false;
        }

        $user_id = absint( $order->get_user_id() );
        $email   = sanitize_email( $order->get_billing_email() );

        // Best effort lifetime spend after completion.
        $after = 0.0;
        if ( $user_id && function_exists( 'wc_get_customer_total_spent' ) ) {
            $after = (float) wc_get_customer_total_spent( $user_id );
        } elseif ( $email ) {
            // For guest checkouts, approximate by summing recent completed orders for this email.
            $after = (float) $this->get_total_spent_by_email( $email );
        }

        $order_total = (float) $order->get_total();
        $before      = max( 0.0, $after - $order_total );

        return ( $before < $threshold && $after >= $threshold );
    }

    /**
     * VIP: did this order cause the customer to cross the VIP threshold?
     *
     * @param WC_Order $order
     * @return bool
     */
    protected function did_customer_cross_vip_threshold( $order ) {
        if ( ! $order || ! is_object( $order ) ) {
            return false;
        }

        $threshold = 0.0;
        if ( class_exists( 'PMCPC_Settings' ) ) {
            $threshold = (float) PMCPC_Settings::get( 'lifecycle_vip_threshold', '0' );
        }
        if ( $threshold <= 0 ) {
            return false;
        }

        $user_id = absint( $order->get_user_id() );
        $email   = sanitize_email( $order->get_billing_email() );

        // Best effort lifetime spend after completion.
        $after = 0.0;
        if ( $user_id && function_exists( 'wc_get_customer_total_spent' ) ) {
            $after = (float) wc_get_customer_total_spent( $user_id );
        } elseif ( $email ) {
            $after = (float) $this->get_total_spent_by_email( $email );
        }

        $order_total = (float) $order->get_total();
        $before      = max( 0.0, $after - $order_total );

        return ( $before < $threshold && $after >= $threshold );
    }

    /**
     * Get the timestamp of the most recent completed order for an email.
     *
     * @param string $email
     * @return int
     */
    protected function get_last_completed_order_timestamp_by_email( $email ) {
        $email = sanitize_email( $email );
        if ( empty( $email ) ) {
            return 0;
        }

        $ids = wc_get_orders( array(
            'limit'         => 1,
            'status'        => array( 'wc-completed' ),
            'billing_email' => $email,
            'return'        => 'ids',
            'orderby'       => 'date',
            'order'         => 'DESC',
        ) );

        if ( empty( $ids ) || ! is_array( $ids ) ) {
            return 0;
        }

        $order = wc_get_order( (int) $ids[0] );
        if ( ! $order || ! $order->get_date_created() ) {
            return 0;
        }

        return (int) $order->get_date_created()->getTimestamp();
    }

    /**
     * Approximate total spent for guest checkout emails.
     *
     * @param string $email
     * @return float
     */
    protected function get_total_spent_by_email( $email ) {
        $email = sanitize_email( $email );
        if ( empty( $email ) ) {
            return 0.0;
        }

        $ids = wc_get_orders( array(
            'limit'         => 200,
            'status'        => array( 'wc-completed' ),
            'billing_email' => $email,
            'return'        => 'ids',
            'orderby'       => 'date',
            'order'         => 'DESC',
        ) );
        if ( empty( $ids ) || ! is_array( $ids ) ) {
            return 0.0;
        }

        $sum = 0.0;
        foreach ( $ids as $id ) {
            $o = wc_get_order( (int) $id );
            if ( $o ) {
                $sum += (float) $o->get_total();
            }
        }
        return $sum;
    }

}
