<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Admin page and reporting methods for FlowPress automations.
 */
trait PMCPC_Automation_Admin_Methods {

    /**
     * Ensure the free Product Mailer Campaigns plugin is active and compatible.
     */
    public function check_dependencies() {
        // Free plugin must be active and define the helper or main class.
        $has_free = function_exists( 'pmcpc_is_pro_active' ) || class_exists( 'PMCPC_Plugin' );

        if ( ! $has_free ) {
            add_action( 'admin_notices', array( $this, 'admin_notice_missing_free' ) );
            return;
        }

        // Optional: version check, if free exposes PMCPC_PLUGIN_VERSION.
        if ( defined( 'PMCPC_PLUGIN_VERSION' ) && false ) {
            add_action( 'admin_notices', array( $this, 'admin_notice_old_free' ) );
        }
    }

    /**
     * Add Pro-specific submenu pages under the Product Mailer menu.
     */
    public function register_menus() {
        // Let the admin workspace own visible navigation when available.
        if ( ( class_exists( 'PMCPC_Admin_UI_Service' ) || class_exists( 'PMCPC_Admin_UI' ) ) ) {
            return;
        }

        // Only users who can manage options should see these.
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // The main Product Mailer menu slug is "pmcpc_dashboard".
        add_submenu_page(
            'pmcpc_dashboard',
            __( 'Automations', 'product-mailer-campaigns' ),
            __( 'Automations', 'product-mailer-campaigns' ),
            'manage_options',
            'pmcpc_automations',
            array( $this, 'render_automations_page' )
        );

        add_submenu_page(
            'pmcpc_dashboard',
            __( 'Segments', 'product-mailer-campaigns' ),
            __( 'Segments', 'product-mailer-campaigns' ),
            'manage_options',
            'pmcpc_segments',
            array( $this, 'render_segments_page' )
        );

        add_submenu_page(
            'pmcpc_dashboard',
            __( 'Email Template', 'product-mailer-campaigns' ),
            __( 'Email Template', 'product-mailer-campaigns' ),
            'manage_options',
            'pmcpc_email_template',
            array( $this, 'render_email_template_page' )
        );

    }

    /**
     * Admin notice shown when the free plugin is missing.
     */
    public function admin_notice_missing_free() {
        if ( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }

        echo '<div class="notice notice-error"><p>';
        echo esc_html__( 'Product Mailer Campaigns Pro requires the free Product Mailer Campaigns plugin to be installed and active.', 'product-mailer-campaigns' );
        echo '</p></div>';
    }

    /**
     * Admin notice shown when the free plugin is too old.
     */
    public function admin_notice_old_free() {
        if ( ! current_user_can( 'update_plugins' ) ) {
            return;
        }

        echo '<div class="notice notice-warning"><p>';
        printf(
            /* translators: 1: required version, 2: current version */
            esc_html__( 'Product Mailer Campaigns Pro requires Product Mailer Campaigns version %1$s or higher. You are running %2$s.', 'product-mailer-campaigns' ),
            esc_html( PMCPC_PLUGIN_VERSION ),
            esc_html( defined( 'PMCPC_PLUGIN_VERSION' ) ? PMCPC_PLUGIN_VERSION : 'unknown' )
        );
        echo '</p></div>';
    }

    /**
     * Render the Automations admin page.
     *
     * For now this focuses on analysing your WooCommerce order history and
     * showing concrete numbers for win-back and post-purchase opportunities.
     */
    public function render_automations_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        global $wpdb;

        if ( class_exists( 'PMCPC_Activator' ) && method_exists( 'PMCPC_Activator', 'maybe_upgrade' ) ) {
            PMCPC_Activator::maybe_upgrade();
        }

        $hide_paid_features = function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features();

        echo '<div class="wrap">';
        if ( class_exists( 'PMCPC_Admin' ) ) {
            PMCPC_Admin::render_app_header(
                __( 'Automations', 'product-mailer-campaigns' ),
                array(
                    array(
                        'label' => __( 'New Campaign', 'product-mailer-campaigns' ),
                        'url'   => admin_url( 'admin.php?page=pmcpc_campaigns&action=new' ),
                        'class' => 'button-primary',
                    ),
                    array(
                        'label' => __( 'Custom Step Workflow', 'product-mailer-campaigns' ),
                        'url'   => admin_url( 'admin.php?page=pmcpc_automations&pmcpc_workflow_builder=1' ),
                    ),
                )
            );
        }

        if ( class_exists( 'PMCPC_Admin' ) ) {
            PMCPC_Admin::render_page_intro(
                __( 'Create emails that send automatically', 'product-mailer-campaigns' ),
                __( 'Use Automations for trigger-based emails like welcome messages, post-purchase follow-ups, win-back emails, and other timed journeys.', 'product-mailer-campaigns' ),
                array(
                    array( 'label' => __( 'Trigger-based journeys', 'product-mailer-campaigns' ), 'icon' => 'dashicons-controls-repeat' ),
                    array( 'label' => __( 'Built-in testing tools', 'product-mailer-campaigns' ), 'icon' => 'dashicons-saved' ),
                    array( 'label' => __( 'Quick setup options', 'product-mailer-campaigns' ), 'icon' => 'dashicons-admin-tools' ),
                )
            );
            PMCPC_Admin::render_support_panels(
                array(
                    array(
                        'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-editor-help',
                        'title'   => __( 'Build one automation at a time', 'product-mailer-campaigns' ),
                        'items'   => array(
                            __( 'Choose the trigger first.', 'product-mailer-campaigns' ),
                            __( 'Review the audience and delay.', 'product-mailer-campaigns' ),
                            __( 'Use the testing tools before turning it on.', 'product-mailer-campaigns' ),
                        ),
                    ),
                    array(
                        'eyebrow' => __( 'Test and check', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-saved',
                        'title'   => __( 'Keep automations easy to trust', 'product-mailer-campaigns' ),
                        'actions' => array(
                            array( 'label' => __( 'Custom Step Workflow', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_automations&pmcpc_workflow_builder=1' ), 'class' => 'button button-primary' ),
                            array( 'label' => __( 'Open Health Check', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_diagnostics' ), 'class' => 'button' ),
                        ),
                    ),
                )
            );
        }

        // One-click setup result for Core/WooCommerce starter buttons.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( isset( $_GET['pmcpc_setup_done'] ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $setup_group = isset( $_GET['pmcpc_setup_group'] ) ? sanitize_key( (string) wp_unslash( $_GET['pmcpc_setup_group'] ) ) : 'all';
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $created = isset( $_GET['pmcpc_created'] ) ? absint( $_GET['pmcpc_created'] ) : 0;
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $skipped = isset( $_GET['pmcpc_skipped'] ) ? absint( $_GET['pmcpc_skipped'] ) : 0;
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $errors  = isset( $_GET['pmcpc_setup_errors'] ) ? absint( $_GET['pmcpc_setup_errors'] ) : 0;

            $setup_group_label = __( 'automations', 'product-mailer-campaigns' );
            if ( 'core' === $setup_group ) {
                $setup_group_label = __( 'Core automations', 'product-mailer-campaigns' );
            } elseif ( 'woocommerce' === $setup_group ) {
                $setup_group_label = __( 'WooCommerce automations', 'product-mailer-campaigns' );
            } elseif ( 'abandoned_cart' === $setup_group ) {
                $setup_group_label = __( 'Abandoned cart recovery', 'product-mailer-campaigns' );
            } elseif ( 'welcome_series' === $setup_group ) {
                $setup_group_label = __( 'New subscriber welcome series', 'product-mailer-campaigns' );
            } elseif ( 'post_purchase_sequence' === $setup_group ) {
                $setup_group_label = __( 'Post-purchase follow-up sequence', 'product-mailer-campaigns' );
            } elseif ( 'customer_winback_sequence' === $setup_group ) {
                $setup_group_label = __( 'Customer win-back sequence', 'product-mailer-campaigns' );
            }

            echo '<div class="notice notice-success inline" style="margin:12px 0 16px 0;"><p>';
            echo esc_html( sprintf( __( '%1$s setup complete. Created %2$d, skipped %3$d, errors %4$d.', 'product-mailer-campaigns' ), $setup_group_label, (int) $created, (int) $skipped, (int) $errors ) );
            echo '</p></div>';
        }

        // Custom workflow builder result.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( isset( $_GET['pmcpc_workflow_created'] ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $created_steps = isset( $_GET['pmcpc_created'] ) ? absint( $_GET['pmcpc_created'] ) : 0;
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $workflow_errors = isset( $_GET['pmcpc_workflow_errors'] ) ? absint( $_GET['pmcpc_workflow_errors'] ) : 0;
            echo '<div class="notice notice-success inline" style="margin:12px 0 16px 0;"><p>';
            echo esc_html( sprintf( __( 'Step workflow created. Created %1$d email steps, errors %2$d.', 'product-mailer-campaigns' ), (int) $created_steps, (int) $workflow_errors ) );
            echo '</p></div>';
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( isset( $_GET['pmcpc_workflow_error'] ) ) {
            echo '<div class="notice notice-error inline" style="margin:12px 0 16px 0;"><p>';
            echo esc_html__( 'That workflow requires WooCommerce to be active.', 'product-mailer-campaigns' );
            echo '</p></div>';
        }

        // Starter set / quick setup lives here (not the Dashboard).
        $setup_core_url           = wp_nonce_url( add_query_arg( array( 'action' => 'pmcpc_setup_store_automation', 'pmcpc_setup_group' => 'core' ), admin_url( 'admin-post.php' ) ), 'pmcpc_setup_store_automation' );
        $setup_wc_url             = wp_nonce_url( add_query_arg( array( 'action' => 'pmcpc_setup_store_automation', 'pmcpc_setup_group' => 'woocommerce' ), admin_url( 'admin-post.php' ) ), 'pmcpc_setup_store_automation' );
        $setup_abandoned_cart_url = wp_nonce_url( add_query_arg( array( 'action' => 'pmcpc_setup_store_automation', 'pmcpc_setup_group' => 'abandoned_cart' ), admin_url( 'admin-post.php' ) ), 'pmcpc_setup_store_automation' );
        $setup_welcome_series_url = wp_nonce_url( add_query_arg( array( 'action' => 'pmcpc_setup_store_automation', 'pmcpc_setup_group' => 'welcome_series' ), admin_url( 'admin-post.php' ) ), 'pmcpc_setup_store_automation' );
        $setup_post_purchase_sequence_url = wp_nonce_url( add_query_arg( array( 'action' => 'pmcpc_setup_store_automation', 'pmcpc_setup_group' => 'post_purchase_sequence' ), admin_url( 'admin-post.php' ) ), 'pmcpc_setup_store_automation' );
        $setup_customer_winback_sequence_url = wp_nonce_url( add_query_arg( array( 'action' => 'pmcpc_setup_store_automation', 'pmcpc_setup_group' => 'customer_winback_sequence' ), admin_url( 'admin-post.php' ) ), 'pmcpc_setup_store_automation' );

        // Starter setup URLs are used by the rows in the Available Automations table.
        // Keep the top of the page focused: activate listed automations from the table,
        // and use the header button only for custom step workflows or one-off campaigns.

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( isset( $_GET['pmcpc_workflow_builder'] ) ) {
            $this->render_custom_step_workflow_builder();
        }

        echo '<h2>' . esc_html__( 'Available Automations', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p class="pmcpc-automation-lede">' . esc_html( $hide_paid_features ? __( 'Activate a built-in automation from the list. Edit the email afterwards from the Campaigns page.', 'product-mailer-campaigns' ) : __( 'Activate a built-in automation from the list. Edit subjects, content, delays, and tests from the Campaigns page after it is created.', 'product-mailer-campaigns' ) ) . '</p>';

        if ( ! $hide_paid_features && class_exists( 'WooCommerce' ) && function_exists( 'pmcpc_wc_automation_enabled' ) && ! pmcpc_wc_automation_enabled() ) {
            echo '<div class="notice notice-warning inline" style="margin:12px 0 16px 0;"><p>'
                . esc_html__( 'Your trial has ended. WooCommerce automations are paused. Core email campaigns and subscriber tools remain available.', 'product-mailer-campaigns' )
                . '</p></div>';
        }

        // Core trigger catalogue.
        $triggers = array(
            array(
                'key'          => 'new_subscriber',
                'label'        => __( 'New subscriber', 'product-mailer-campaigns' ),
                'when'         => __( 'When someone joins your mailing list.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Welcome series, lead magnet delivery.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'new_subscriber',
                    'automation_hint' => 'welcome_new_subscriber',
                ) ),
            ),
            array(
                'key'            => 'workflow_welcome_series',
                'label'          => __( 'New subscriber welcome series', 'product-mailer-campaigns' ),
                'when'           => __( 'When someone joins your mailing list.', 'product-mailer-campaigns' ),
                'common_use'     => __( '3-step onboarding workflow: welcome, best pieces, and subscriber nurture.', 'product-mailer-campaigns' ),
                'action_label'   => __( 'Create workflow', 'product-mailer-campaigns' ),
                'create_url'     => $setup_welcome_series_url,
                'workflow_key'   => 'welcome_series',
                'workflow_steps' => 3,
                'automation_trigger' => 'new_subscriber',
            ),
            array(
                'key'          => 'welcome_follow_up',
                'label'        => __( 'Welcome follow-up', 'product-mailer-campaigns' ),
                'when'         => __( 'A few days after someone joins your mailing list.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Warm up new subscribers with best content and next steps.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'welcome_follow_up',
                    'automation_hint' => 'welcome_follow_up',
                ) ),
            ),
            array(
                'key'          => 'lead_magnet_download',
                'label'        => __( 'Lead magnet delivery', 'product-mailer-campaigns' ),
                'when'         => __( 'When a subscriber joins via a lead magnet or opt-in offer.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Deliver downloads, guides, and signup incentives.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'lead_magnet_download',
                    'automation_hint' => 'lead_magnet_delivery',
                ) ),
            ),
            array(
                'key'          => 'subscriber_inactive',
                'label'        => __( 'Subscriber inactive', 'product-mailer-campaigns' ),
                'when'         => __( 'When a subscriber has not engaged for a chosen number of days.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Re-engagement campaigns, reminders, and list cleaning.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'subscriber_inactive',
                    'automation_hint' => 'subscriber_inactive',
                ) ),
            ),
            array(
                'key'          => 'subscriber_anniversary',
                'label'        => __( 'Subscriber anniversary', 'product-mailer-campaigns' ),
                'when'         => __( 'On the anniversary of when someone joined your mailing list.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Thank-you notes, loyalty nudges, and anniversary offers.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'subscriber_anniversary',
                    'automation_hint' => 'subscriber_anniversary',
                ) ),
            ),
            array(
                'key'          => 'subscriber_birthday',
                'label'        => __( 'Subscriber birthday', 'product-mailer-campaigns' ),
                'when'         => __( 'On a subscriber birthday when that profile field is available.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Birthday greetings, special offers, and celebratory messages.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'subscriber_birthday',
                    'automation_hint' => 'subscriber_birthday',
                ) ),
            ),
            array(
                'key'          => 'new_customer',
                'label'        => __( 'First order', 'product-mailer-campaigns' ),
                'when'         => __( 'When a customer places their first WooCommerce order.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'New customer welcome / onboarding.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'new_customer',
                    // This automation is about a first order, so preselect the matching segment.
                    'pro_segment_key' => 'new_customers',
                    'automation_hint' => 'welcome_new_customer',
                ) ),
            ),
            
            array(
                'key'          => 'repeat_customer',
                'label'        => __( 'Repeat customer', 'product-mailer-campaigns' ),
                'when'         => __( 'When a customer completes their second WooCommerce order.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Loyalty thank-you, early access, cross-sell.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'repeat_customer',
                    'automation_hint' => 'repeat_customer',
                ) ),
            ),
array(
                'key'            => 'workflow_post_purchase_sequence',
                'label'          => __( 'Post-purchase follow-up sequence', 'product-mailer-campaigns' ),
                'when'           => __( 'When a WooCommerce order is completed.', 'product-mailer-campaigns' ),
                'common_use'     => __( '3-step workflow: thank-you, review request, and complementary products.', 'product-mailer-campaigns' ),
                'action_label'   => __( 'Create workflow', 'product-mailer-campaigns' ),
                'create_url'     => $setup_post_purchase_sequence_url,
                'workflow_key'   => 'post_purchase_sequence',
                'workflow_steps' => 3,
                'automation_trigger' => 'post_purchase',
            ),
array(
                'key'          => 'post_purchase',
                'label'        => __( 'Post-purchase (after order)', 'product-mailer-campaigns' ),
                'when'         => __( 'When a WooCommerce order is completed.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Thank-you emails, review requests, cross-sell.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'post_purchase',
                    'pro_segment_key' => 'customers',
                    'automation_hint' => 'post_purchase',
                ) ),
            ),

            array(
                'key'          => 'abandoned_cart',
                'label'        => __( 'Abandoned cart recovery', 'product-mailer-campaigns' ),
                'when'         => __( 'When a cart has been left without checkout.', 'product-mailer-campaigns' ),
                'common_use'   => __( '3-step recovery sequence: gentle reminder, follow-up, and final reminder.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create workflow', 'product-mailer-campaigns' ),
                'create_url'   => $setup_abandoned_cart_url,
            ),
            
            array(
                'key'          => 'review_request',
                'label'        => __( 'Review request', 'product-mailer-campaigns' ),
                'when'         => __( 'After a purchase, ask for a review once the item has arrived.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Increase reviews and social proof.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    // Review request must be its own trigger so users can build separate flows.
                    'trigger'         => 'review_request',
                    'automation_hint' => 'review_request',
                ) ),
            ),
array(
                'key'            => 'workflow_customer_winback_sequence',
                'label'          => __( 'Customer win-back sequence', 'product-mailer-campaigns' ),
                'when'           => __( 'When a customer has not ordered for a chosen number of days.', 'product-mailer-campaigns' ),
                'common_use'     => __( '2-step workflow: re-engagement note and final reminder.', 'product-mailer-campaigns' ),
                'action_label'   => __( 'Create workflow', 'product-mailer-campaigns' ),
                'create_url'     => $setup_customer_winback_sequence_url,
                'workflow_key'   => 'customer_winback_sequence',
                'workflow_steps' => 2,
                'automation_trigger' => 'customer_inactive',
            ),
array(
                'key'          => 'customer_inactive',
                'label'        => __( 'Customer inactive', 'product-mailer-campaigns' ),
                'when'         => __( 'When a customer has not ordered for a chosen number of days.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Win-back campaigns and reminders.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    // Must match the free plugin trigger key so it saves correctly.
                    'trigger'         => 'customer_inactive',
                    'pro_segment_key' => 'lapsed',
                    'automation_hint' => 'winback',
                ) ),
            ),
            array(
                'key'          => 'high_value',
                'label'        => __( 'High-value customer', 'product-mailer-campaigns' ),
                'when'         => __( 'Customer lifetime spend exceeds your high-value threshold.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'VIP offers, early access, special perks.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'high_value',
                    'pro_segment_key' => 'high_value',
                    'automation_hint' => 'vip_offer',
                ) ),
            ),
            array(
                'key'          => 'lapsed_high_value_customer',
                'label'        => __( 'Lapsed high-value customer', 'product-mailer-campaigns' ),
                'when'         => __( 'When a high-value customer has not ordered for 90+ days.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Win back your best past buyers with a tailored re-engagement email.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'lapsed_high_value_customer',
                    'pro_segment_key' => 'high_value',
                    'automation_hint' => 'lapsed_high_value_customer',
                ) ),
            ),
            array(
                'key'          => 'vip_customer',
                'label'        => __( 'VIP customer', 'product-mailer-campaigns' ),
                'when'         => __( 'Customer lifetime spend exceeds your VIP threshold.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Top-spender rewards, concierge offers, and VIP-only perks.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'vip_customer',
                    'pro_segment_key' => 'vip',
                    'automation_hint' => 'vip_customer',
                ) ),
            ),
            array(
                'key'          => 'date',
                'label'        => __( 'On a specific date', 'product-mailer-campaigns' ),
                'when'         => __( 'On a chosen calendar date.', 'product-mailer-campaigns' ),
                'common_use'   => __( 'Sales events, announcements, seasonal campaigns.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create automation', 'product-mailer-campaigns' ),
                'create_url'   => $this->build_create_campaign_url( array(
                    'trigger'         => 'date',
                    'automation_hint' => 'date_based',
                ) ),
            ),
        );

        $custom_workflow_rows = $this->get_custom_step_workflow_catalogue_rows();
        if ( ! empty( $custom_workflow_rows ) ) {
            $triggers = array_merge( $custom_workflow_rows, $triggers );
        }

        if ( $hide_paid_features && function_exists( 'pmcpc_is_premium_wc_trigger' ) ) {
            $triggers = array_values(
                array_filter(
                    $triggers,
                    static function ( $trigger ) {
                        $key = isset( $trigger['key'] ) ? (string) $trigger['key'] : '';
                        return ! pmcpc_is_premium_wc_trigger( $key );
                    }
                )
            );
        }

        $metrics = null;
        if ( ! $hide_paid_features && class_exists( 'WooCommerce' ) && function_exists( 'wc_get_orders' ) ) {
            try {
                $metrics = $this->calculate_automation_metrics();
            } catch ( \Throwable $e ) {
                if ( class_exists( 'PMCPC_Logger' ) ) {
                    PMCPC_Logger::exception(
                        'automation_metrics',
                        'Failed to calculate automation metrics.',
                        $e,
                        array(
                            'screen' => 'automation_ideas',
                        )
                    );
                }
            }
        }

        // Compute per-trigger "recommended" badges from store metrics.
        // We support multiple badges per trigger so the table can show, for example,
        // both "new customers" and "repeat customers" for post‑purchase automations.
        $opportunities = array();
        if ( is_array( $metrics ) ) {
            $recent = isset( $metrics['recent_customers'] ) ? (int) $metrics['recent_customers'] : 0;
            $repeat = isset( $metrics['repeat_customers_60'] ) ? (int) $metrics['repeat_customers_60'] : 0;
            $lapsed = isset( $metrics['lapsed_customers'] ) ? (int) $metrics['lapsed_customers'] : 0;
            $vip    = isset( $metrics['vip_customers'] ) ? (int) $metrics['vip_customers'] : 0;
	        $vip_lapsed = isset( $metrics['vip_lapsed'] ) ? (int) $metrics['vip_lapsed'] : 0;

            // New customer flows.
            if ( $recent > 0 ) {
                $opportunities['new_customer'] = array(
                    'badges' => array(
                        array(
                            'count' => $recent,
                            'label' => __( 'New (7d)', 'product-mailer-campaigns' ),
                            'note'  => sprintf( _n( '%d new customer in the last 7 days', '%d new customers in the last 7 days', $recent, 'product-mailer-campaigns' ), $recent ),
                        ),
                    ),
                );
            }
            if ( $recent > 0 ) {
                $opportunities['welcome_follow_up'] = array(
                    'badges' => array(
                        array(
                            'count' => $recent,
                            'label' => __( 'New (7d)', 'product-mailer-campaigns' ),
                            'note'  => sprintf( _n( '%d new subscriber in the last 7 days', '%d new subscribers in the last 7 days', $recent, 'product-mailer-campaigns' ), $recent ),
                        ),
                    ),
                );
            }

            // Post‑purchase works for both new and repeat customers.
            $post_badges = array();
            if ( $recent > 0 ) {
                $post_badges[] = array(
                    'count' => $recent,
                    'label' => __( 'New (7d)', 'product-mailer-campaigns' ),
                    'note'  => sprintf( _n( '%d new customer in the last 7 days', '%d new customers in the last 7 days', $recent, 'product-mailer-campaigns' ), $recent ),
                );
            }
            if ( $repeat > 0 ) {
                $post_badges[] = array(
                    'count' => $repeat,
                    'label' => __( 'Repeat (60d)', 'product-mailer-campaigns' ),
                    'note'  => sprintf( _n( '%d repeat customer in the last 60 days', '%d repeat customers in the last 60 days', $repeat, 'product-mailer-campaigns' ), $repeat ),
                );
            }
            if ( ! empty( $post_badges ) ) {
                $opportunities['post_purchase'] = array( 'badges' => $post_badges );
            }

            // Repeat customer (second order).
            if ( $repeat > 0 ) {
                $opportunities['repeat_customer'] = array(
                    'badges' => array(
                        array(
                            'count' => $repeat,
                            'label' => __( 'Repeat (60d)', 'product-mailer-campaigns' ),
                            'note'  => sprintf( _n( '%d repeat customer in the last 60 days', '%d repeat customers in the last 60 days', $repeat, 'product-mailer-campaigns' ), $repeat ),
                        ),
                    ),
                );
            }

            // Review request uses the same purchase volume as post-purchase.
            if ( ! empty( $post_badges ) ) {
                $opportunities['review_request'] = array( 'badges' => $post_badges );
            }


	            // Win‑back.
	            $inactive_badges = array();
	            $lapsed_days     = (int) ( function_exists( 'pmcpc_get_setting' ) ? pmcpc_get_setting( 'lifecycle_lapsed_days', 90 ) : 90 );
	            if ( $lapsed > 0 ) {
	                $inactive_badges[] = array(
	                    'count' => $lapsed,
	                    'label' => sprintf( __( 'Lapsed (%dd+)', 'product-mailer-campaigns' ), $lapsed_days ),
	                    'note'  => sprintf( _n( '%d lapsed customer (%d+ days)', '%d lapsed customers (%d+ days)', $lapsed, 'product-mailer-campaigns' ), $lapsed, $lapsed_days ),
	                );
	            }
            if ( $vip_lapsed > 0 ) {
                $inactive_badges[] = array(
                    'count' => $vip_lapsed,
                    'label' => __( 'VIP lapsed', 'product-mailer-campaigns' ),
	                    'note'  => sprintf( _n( '%d high-value customer inactive (%d+ days)', '%d high-value customers inactive (%d+ days)', $vip_lapsed, 'product-mailer-campaigns' ), $vip_lapsed, $lapsed_days ),
                );
            }
            if ( ! empty( $inactive_badges ) ) {
                $opportunities['customer_inactive'] = array( 'badges' => $inactive_badges );
            }

            // VIP / high-value.
            $vip_badges = array();
            if ( $vip > 0 ) {
                $vip_badges[] = array(
                    'count' => $vip,
                    'label' => __( 'VIP', 'product-mailer-campaigns' ),
                    'note'  => sprintf( _n( '%d high-value customer (top spenders)', '%d high-value customers (top spenders)', $vip, 'product-mailer-campaigns' ), $vip ),
                );
            }
            if ( $vip_lapsed > 0 ) {
                $vip_badges[] = array(
                    'count' => $vip_lapsed,
                    'label' => __( 'VIP lapsed', 'product-mailer-campaigns' ),
                    'note'  => sprintf( _n( '%d high-value customer inactive (60+ days)', '%d high-value customers inactive (60+ days)', $vip_lapsed, 'product-mailer-campaigns' ), $vip_lapsed ),
                );
            }
            if ( ! empty( $vip_badges ) ) {
                $opportunities['high_value'] = array( 'badges' => $vip_badges );
            }
            if ( $vip_lapsed > 0 ) {
                $opportunities['lapsed_high_value_customer'] = array(
                    'badges' => array(
                        array(
                            'count' => $vip_lapsed,
                            'label' => __( 'VIP lapsed', 'product-mailer-campaigns' ),
                            'note'  => sprintf( _n( '%d high-value customer inactive (%d+ days)', '%d high-value customers inactive (%d+ days)', $vip_lapsed, 'product-mailer-campaigns' ), $vip_lapsed, max( 90, $lapsed_days ) ),
                        ),
                    ),
                );
            }
        }

        $this->render_automation_ideas_table( $triggers, $opportunities );

            // Pro campaign revenue (beta).
            $revenue_metrics = null;
            if ( ! $hide_paid_features ) {
                try {
                    $revenue_metrics = $this->calculate_campaign_revenue_metrics();
                } catch ( \Throwable $e ) {
                    if ( class_exists( 'PMCPC_Logger' ) ) {
                        PMCPC_Logger::exception(
                            'automation_revenue',
                            'Failed to calculate campaign revenue metrics.',
                            $e,
                            array(
                                'screen' => 'automation_ideas',
                            )
                        );
                    }
                }
            }

            if ( ! $hide_paid_features && is_array( $revenue_metrics ) && ! empty( $revenue_metrics['campaigns'] ) ) {
                echo '<div class="pmcpc-card">';
                echo '<h2>' . esc_html__( 'Campaign revenue (last 30 days, beta)', 'product-mailer-campaigns' ) . '</h2>';
                echo '<p class="description">' . esc_html__( 'Revenue is attributed using a simple last-touch model. Treat these numbers as directional rather than exact accounting figures.', 'product-mailer-campaigns' ) . '</p>';
                echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
                echo '<table class="widefat striped pmcpc-wide-table">';
                echo '<thead><tr>';
                echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
                echo '<th class="pmcpc-col-compare">' . esc_html__( 'Orders', 'product-mailer-campaigns' ) . '</th>';
                echo '<th class="pmcpc-col-compare">' . esc_html__( 'Revenue', 'product-mailer-campaigns' ) . '</th>';
                echo '</tr></thead><tbody>';

                $campaign_ids   = array_keys( $revenue_metrics['campaigns'] );
                $campaign_ids   = array_map( 'intval', $campaign_ids );
                $campaign_ids   = array_filter( $campaign_ids );
                $campaign_posts = array();

                if ( ! empty( $campaign_ids ) ) {
                    $name_col     = $this->get_campaign_name_column();
                    $placeholders = implode( ',', array_fill( 0, count( $campaign_ids ), '%d' ) );
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                    $sql = "SELECT id, {$name_col} AS campaign_name FROM {$wpdb->prefix}pmcpc_campaigns WHERE id IN ({$placeholders})";
                    $campaign_posts = $wpdb->get_results( $wpdb->prepare( $sql, $campaign_ids ) );
                }

                $names = array();
                if ( ! empty( $campaign_posts ) ) {
                    foreach ( $campaign_posts as $cp ) {
                        $names[ (int) $cp->id ] = $cp->campaign_name;
                    }
                }

                foreach ( $revenue_metrics['campaigns'] as $campaign_id => $data ) {
                    $name    = isset( $names[ $campaign_id ] ) ? $names[ $campaign_id ] : sprintf( __( 'Campaign #%d', 'product-mailer-campaigns' ), $campaign_id );
                    $orders  = isset( $data['orders'] ) ? (int) $data['orders'] : 0;
                    $revenue = isset( $data['revenue'] ) ? (float) $data['revenue'] : 0.0;

                    echo '<tr>';
                    echo '<td>' . esc_html( $name ) . '</td>';
                    echo '<td>' . intval( $orders ) . '</td>';
                    echo '<td>' . wp_kses_post( wc_price( $revenue ) ) . '</td>';
                    echo '</tr>';
                }

                echo '</tbody></table></div></div></div>';
            }

        if ( ! $hide_paid_features ) {

            echo '<div class="pmcpc-automation-testing-bottom" style="margin-top:24px;">';
            $this->render_testing_center_panel();
            echo '</div>';
        }

        echo '</div>';
        ?>
        <script type="text/javascript">
        jQuery(function($){
            $('.pmcpc-show-segment-examples').on('click', function(e){
                e.preventDefault();
                var $btn    = $(this);
                var target  = $btn.data('target');
                var $panel  = $(target);

                if ( !$panel.length ) {
                    return;
                }

                $panel.toggle();
                var isVisible = $panel.is(':visible');
                $btn.attr('aria-expanded', isVisible ? 'true' : 'false');

                if ( isVisible ) {
                    $btn.text('<?php echo esc_js( __( 'Hide examples', 'product-mailer-campaigns' ) ); ?>');
                } else {
                    $btn.text('<?php echo esc_js( __( 'Show examples', 'product-mailer-campaigns' ) ); ?>');
                }
            });
        });
        </script>
        <?php
    }

    /**
     * Render the simple custom step workflow builder.
     *
     * @return void
     */
    protected function render_custom_step_workflow_builder() {
        $allowed_triggers = class_exists( 'PMCPC_Automation_Quick_Setup' ) && method_exists( 'PMCPC_Automation_Quick_Setup', 'get_custom_workflow_allowed_triggers' )
            ? PMCPC_Automation_Quick_Setup::get_custom_workflow_allowed_triggers()
            : array(
                'new_subscriber' => array( 'label' => __( 'New subscriber joins list', 'product-mailer-campaigns' ), 'requires_woocommerce' => false ),
            );

        echo '<div class="card pmcpc-card" id="pmcpc-custom-workflow-builder" style="padding:16px;margin:18px 0;max-width:1100px;">';
        echo '<h2 style="margin-top:0;">' . esc_html__( 'Create custom step workflow', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p class="description" style="max-width:820px;">' . esc_html__( 'Create a simple multi-step automation. FlowPress will create one editable email per step, grouped together as a workflow with shared trigger and separate delays.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="pmcpc_create_step_workflow" />';
        wp_nonce_field( 'pmcpc_create_step_workflow', 'pmcpc_create_step_workflow_nonce' );
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th><label for="pmcpc_workflow_name">' . esc_html__( 'Workflow name', 'product-mailer-campaigns' ) . '</label></th><td>';
        echo '<input type="text" class="regular-text" id="pmcpc_workflow_name" name="workflow_name" value="' . esc_attr__( 'New subscriber welcome sequence', 'product-mailer-campaigns' ) . '" required />';
        echo '<p class="description">' . esc_html__( 'Example: New subscriber welcome sequence, Post-purchase nurture, VIP reactivation.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th><label for="pmcpc_workflow_trigger">' . esc_html__( 'Trigger', 'product-mailer-campaigns' ) . '</label></th><td>';
        echo '<select id="pmcpc_workflow_trigger" name="workflow_trigger">';
        foreach ( $allowed_triggers as $key => $info ) {
            $key      = sanitize_key( (string) $key );
            $label    = isset( $info['label'] ) ? (string) $info['label'] : $key;
            $requires = ! empty( $info['requires_woocommerce'] );
            $disabled = $requires && ! class_exists( 'WooCommerce' );
            echo '<option value="' . esc_attr( $key ) . '"' . disabled( $disabled, true, false ) . '>' . esc_html( $label . ( $disabled ? ' — ' . __( 'Install WooCommerce', 'product-mailer-campaigns' ) : '' ) ) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__( 'All steps in the workflow use the same trigger; the delay controls when each email sends after that trigger.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th><label for="pmcpc_workflow_steps">' . esc_html__( 'Number of steps', 'product-mailer-campaigns' ) . '</label></th><td>';
        echo '<select id="pmcpc_workflow_steps" name="workflow_steps">';
        for ( $i = 2; $i <= 5; $i++ ) {
            echo '<option value="' . esc_attr( $i ) . '"' . selected( 3, $i, false ) . '>' . esc_html( sprintf( _n( '%d step', '%d steps', $i, 'product-mailer-campaigns' ), $i ) ) . '</option>';
        }
        echo '</select>';
        echo '</td></tr>';
        echo '</table>';

        echo '<h3>' . esc_html__( 'Workflow steps', 'product-mailer-campaigns' ) . '</h3>';
        echo '<table class="widefat striped" style="max-width:1000px;">';
        echo '<thead><tr><th style="width:80px;">' . esc_html__( 'Step', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</th><th style="width:220px;">' . esc_html__( 'Delay after trigger', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
        $default_subjects = array(
            1 => __( 'Welcome — so pleased you joined us', 'product-mailer-campaigns' ),
            2 => __( 'A few pieces you may have missed', 'product-mailer-campaigns' ),
            3 => __( 'A private note for our subscribers', 'product-mailer-campaigns' ),
            4 => __( 'Still thinking it over?', 'product-mailer-campaigns' ),
            5 => __( 'One final note', 'product-mailer-campaigns' ),
        );
        $default_amounts = array( 1 => 0, 2 => 2, 3 => 5, 4 => 10, 5 => 14 );
        for ( $i = 1; $i <= 5; $i++ ) {
            echo '<tr data-pmcpc-workflow-step-row="' . esc_attr( $i ) . '">';
            echo '<td><strong>' . esc_html( sprintf( __( 'Step %d', 'product-mailer-campaigns' ), $i ) ) . '</strong></td>';
            echo '<td><input type="text" class="regular-text" style="width:100%;max-width:520px;" name="workflow_step_subject[' . esc_attr( $i ) . ']" value="' . esc_attr( $default_subjects[ $i ] ) . '" /></td>';
            echo '<td><input type="number" min="0" step="1" style="width:75px;" name="workflow_step_delay_amount[' . esc_attr( $i ) . ']" value="' . esc_attr( $default_amounts[ $i ] ) . '" /> ';
            echo '<select name="workflow_step_delay_unit[' . esc_attr( $i ) . ']">';
            echo '<option value="minutes">' . esc_html__( 'minutes', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="hours">' . esc_html__( 'hours', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="days" selected>' . esc_html__( 'days', 'product-mailer-campaigns' ) . '</option>';
            echo '</select></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        echo '<p class="description">' . esc_html__( 'Only the first selected number of steps will be created. You can edit each email afterwards from Campaigns.', 'product-mailer-campaigns' ) . '</p>';
        echo '<p><button type="submit" class="button button-primary">' . esc_html__( 'Create workflow emails', 'product-mailer-campaigns' ) . '</button> ';
        echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_automations' ) ) . '">' . esc_html__( 'Cancel', 'product-mailer-campaigns' ) . '</a></p>';
        echo '</form>';
        echo '<script>(function(){var select=document.getElementById("pmcpc_workflow_steps");if(!select)return;function sync(){var max=parseInt(select.value||"3",10);document.querySelectorAll("[data-pmcpc-workflow-step-row]").forEach(function(row){var n=parseInt(row.getAttribute("data-pmcpc-workflow-step-row")||"0",10);row.style.display=n<=max?"":"none";});}select.addEventListener("change",sync);sync();})();</script>';
        echo '</div>';
    }

    /**
     * Load saved custom workflow rows for the Automations catalogue.
     *
     * @return array
     */
    protected function get_custom_step_workflow_catalogue_rows() {
        global $wpdb;
        if ( ! isset( $wpdb ) || ! $wpdb instanceof \wpdb ) {
            return array();
        }

        $table = $wpdb->prefix . 'pmcpc_campaigns';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $has_column = $wpdb->get_var( $wpdb->prepare( 'SHOW COLUMNS FROM %i LIKE %s', $table, 'workflow_key' ) );
        if ( ! $has_column ) {
            return array();
        }

        $built_in = array( 'welcome_series', 'post_purchase_sequence', 'customer_winback_sequence' );
        $placeholders = implode( ',', array_fill( 0, count( $built_in ), '%s' ) );
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $sql = "SELECT workflow_key, MAX(workflow_name) AS workflow_name, MIN(automation_trigger) AS automation_trigger, COUNT(*) AS step_count, MAX(workflow_step) AS max_step, MAX(updated_at) AS updated_at
                FROM {$table}
                WHERE workflow_key IS NOT NULL
                  AND workflow_key <> ''
                  AND workflow_key NOT IN ({$placeholders})
                  AND status IN ('active','draft','paused','scheduled','queued')
                GROUP BY workflow_key
                ORDER BY MAX(updated_at) DESC
                LIMIT 25";
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $built_in ) );
        if ( empty( $rows ) || ! is_array( $rows ) ) {
            return array();
        }

        $out = array();
        foreach ( $rows as $row ) {
            $workflow_key = isset( $row->workflow_key ) ? sanitize_key( (string) $row->workflow_key ) : '';
            if ( '' === $workflow_key ) {
                continue;
            }
            $trigger = isset( $row->automation_trigger ) ? sanitize_key( (string) $row->automation_trigger ) : 'new_subscriber';
            $steps   = max( 1, max( absint( $row->step_count ?? 0 ), absint( $row->max_step ?? 0 ) ) );
            $label   = ! empty( $row->workflow_name ) ? (string) $row->workflow_name : ucwords( str_replace( '_', ' ', $workflow_key ) );
            $out[] = array(
                'key'            => 'workflow_' . $workflow_key,
                'label'          => $label,
                'when'           => $this->get_custom_workflow_trigger_description( $trigger ),
                'common_use'     => sprintf( _n( '%d-step custom workflow.', '%d-step custom workflow.', $steps, 'product-mailer-campaigns' ), $steps ),
                'action_label'   => __( 'Edit workflow', 'product-mailer-campaigns' ),
                'create_url'     => '',
                'workflow_key'   => $workflow_key,
                'workflow_steps' => $steps,
                'automation_trigger' => $trigger,
                'scope'          => $this->get_custom_workflow_scope_for_trigger( $trigger ),
            );
        }

        return $out;
    }

    /**
     * @param string $trigger Trigger key.
     * @return string
     */
    protected function get_custom_workflow_trigger_description( $trigger ) {
        $trigger = sanitize_key( (string) $trigger );
        $map = array(
            'new_subscriber'        => __( 'When someone joins your mailing list.', 'product-mailer-campaigns' ),
            'lead_magnet_download'  => __( 'When a subscriber joins via a lead magnet or opt-in offer.', 'product-mailer-campaigns' ),
            'subscriber_inactive'   => __( 'When a subscriber has not engaged for a chosen number of days.', 'product-mailer-campaigns' ),
            'post_purchase'         => __( 'When a WooCommerce order is completed.', 'product-mailer-campaigns' ),
            'repeat_customer'       => __( 'When a customer completes their second WooCommerce order.', 'product-mailer-campaigns' ),
            'customer_inactive'     => __( 'When a customer has not ordered for a chosen number of days.', 'product-mailer-campaigns' ),
        );
        return isset( $map[ $trigger ] ) ? $map[ $trigger ] : __( 'When the selected trigger fires.', 'product-mailer-campaigns' );
    }

    /**
     * @param string $trigger Trigger key.
     * @return string
     */
    protected function get_custom_workflow_scope_for_trigger( $trigger ) {
        $trigger = sanitize_key( (string) $trigger );
        return in_array( $trigger, array( 'post_purchase', 'repeat_customer', 'customer_inactive', 'new_customer', 'high_value', 'vip_customer' ), true ) ? 'woocommerce' : 'core';
    }

    /**
     * Calculate basic automation metrics from WooCommerce orders.
     *
     * @return array {
     *   @type int $recent_customers  Unique customers with orders in last 7 days.
     *   @type int $lapsed_customers  Unique customers whose last order was 60+ days ago.
     *   @type int $vip_customers     Approximate count of top 10% spenders.
     * }
     */
protected function calculate_automation_metrics() {
    $metrics = array(
        'recent_customers'      => 0,
        'lapsed_customers'      => 0,
        'vip_customers'         => 0,
        'repeat_customers_60'   => 0,
        'high_value_lapsed'     => 0,
    );

    if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
        return $metrics;
    }

	    // Fetch a reasonable sample of orders (you can tune this later).
	    // Note: WooCommerce order statuses are typically passed without the `wc-` prefix.
	    $args = array(
	        'limit'   => 500,
	        'status'  => array( 'completed', 'processing' ),
	        'return'  => 'ids',
	        'orderby' => 'date',
	        'order'   => 'DESC',
	    );

    $orders = wc_get_orders( $args );

    if ( empty( $orders ) ) {
        return $metrics;
    }

	    $now           = time();
	    $recent_cutoff = strtotime( '-7 days', $now );
	    $lapsed_days   = absint( function_exists( 'pmcpc_get_setting' ) ? pmcpc_get_setting( 'lifecycle_lapsed_days', 90 ) : 90 );
	    $lapsed_cutoff = strtotime( sprintf( '-%d days', max( 1, $lapsed_days ) ), $now );
	    $recent_keys   = array();
    $customer_totals      = array();
    $customer_last_ts     = array();
    $customer_order_counts = array();

    foreach ( $orders as $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            continue;
        }

        // Skip refunds or non-standard order types.
        if ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) {
            continue;
        }

        $customer_id = $order->get_customer_id();
        $email       = $order->get_billing_email();

        // Use customer ID if available, otherwise fall back to email as a key.
        $key = $customer_id ? 'c_' . $customer_id : 'e_' . strtolower( $email );

        $order_ts = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : false;

        if ( ! $order_ts ) {
            continue;
        }

        if ( ! isset( $customer_totals[ $key ] ) ) {
            $customer_totals[ $key ]  = 0;
            $customer_last_ts[ $key ] = 0;
            $customer_order_counts[ $key ] = 0;
        }

        $customer_order_counts[ $key ]++;
        $customer_totals[ $key ] += (float) $order->get_total();
        if ( $order_ts > $customer_last_ts[ $key ] ) {
            $customer_last_ts[ $key ] = $order_ts;
        }

	        if ( $order_ts >= $recent_cutoff ) {
	            $recent_keys[ $key ] = true;
	        }
    }

	// Finalize unique recent customer count.
	$metrics['recent_customers'] = count( $recent_keys );

	// Determine lapsed customers.
    $lapsed = 0;
    foreach ( $customer_last_ts as $key => $last_ts ) {
        if ( $last_ts <= $lapsed_cutoff ) {
            $lapsed++;
        }
    }

    $metrics['lapsed_customers'] = $lapsed;

    // Repeat customers with 2+ orders whose last order was within the last 60 days.
    $repeat_recent = 0;
    $repeat_cutoff = strtotime( '-60 days', $now );
    foreach ( $customer_order_counts as $key => $order_count ) {
        if ( (int) $order_count >= 2 && isset( $customer_last_ts[ $key ] ) && $customer_last_ts[ $key ] >= $repeat_cutoff ) {
            $repeat_recent++;
        }
    }
    $metrics['repeat_customers_60'] = $repeat_recent;

    // High-value but inactive customers: above threshold spend and lapsed.
    $threshold = 0;
    if ( function_exists( 'pmcpc_get_setting' ) ) {
        $threshold = (float) pmcpc_get_setting( 'lifecycle_high_value_threshold', 0 );
    }
    if ( $threshold > 0 ) {
        $high_value_lapsed = 0;
        foreach ( $customer_totals as $key => $total_spent ) {
            if ( $total_spent >= $threshold && isset( $customer_last_ts[ $key ] ) && $customer_last_ts[ $key ] <= $lapsed_cutoff ) {
                $high_value_lapsed++;
            }
        }
        $metrics['high_value_lapsed'] = $high_value_lapsed;
    }

	    // VIPs: top ~10% by spend (minimum 1).
	    if ( ! empty( $customer_totals ) ) {
	        arsort( $customer_totals );
	        $total_customers = count( $customer_totals );
	        $vip_count       = max( 1, (int) ceil( $total_customers * 0.1 ) );
	        $vip_count       = min( $vip_count, $total_customers );
	
	        $metrics['vip_customers'] = $vip_count;

	        // VIP lapsed = VIP customers whose last order is older than the lapsed cutoff.
	        $vip_lapsed = 0;
	        $vip_keys   = array_slice( array_keys( $customer_totals ), 0, $vip_count );
	        foreach ( $vip_keys as $key ) {
	            if ( isset( $customer_last_ts[ $key ] ) && $customer_last_ts[ $key ] <= $lapsed_cutoff ) {
	                $vip_lapsed++;
	            }
	        }
	        $metrics['vip_lapsed'] = $vip_lapsed;
	    }

    return $metrics;
}
    /**
     * Render the Segments admin page.
     *
     * This page builds dynamic segments from your subscriber and WooCommerce data.
     */
    public function render_segments_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $hide_paid_features = function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features();

        echo '<div class="wrap">';
        if ( class_exists( 'PMCPC_Admin' ) ) {
            PMCPC_Admin::render_app_header(
                __( 'Segments', 'product-mailer-campaigns' ),
                array(
                    array(
                        'label' => __( 'New Campaign', 'product-mailer-campaigns' ),
                        'url'   => admin_url( 'admin.php?page=pmcpc_campaigns&action=new' ),
                        'class' => 'button-primary',
                    ),
                    array(
                        'label' => __( 'New Automation', 'product-mailer-campaigns' ),
                        'url'   => $this->build_new_automation_url(),
                    ),
                )
            );
        }
        if ( class_exists( 'PMCPC_Admin' ) ) {
            PMCPC_Admin::render_page_intro(
                __( 'Subscriber groups for better targeting', 'product-mailer-campaigns' ),
                __( 'Use these ready-made segments to find customer groups worth targeting, then jump straight into a campaign or automation from the rows below.', 'product-mailer-campaigns' ),
                array(
                    array(
                        'label' => __( 'Audience segments from behaviour and value', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-filter',
                    ),
                    array(
                        'label' => __( 'Create campaigns from any row', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-megaphone',
                    ),
                )
            );
        }

        if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
            echo '<p>' . esc_html__( 'WooCommerce does not appear to be active. Behaviour-based segments use WooCommerce order data.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            return;
        }

        global $wpdb;
        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';

        // Check if the free plugin's subscriber table exists.
        $table_exists = $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $wpdb->esc_like( $subscribers_table )
            )
        );

        if ( ! $table_exists ) {
            echo '<p>' . esc_html__( 'No Product Mailer subscriber data found yet. Try creating a few campaigns and collecting subscribers first.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            return;
        }

        $segments = null;
        try {
            $segments = $this->calculate_segments( $subscribers_table );
        } catch ( \Throwable $e ) {
            if ( class_exists( 'PMCPC_Logger' ) ) {
                PMCPC_Logger::exception(
                    'automation_segments',
                    'Failed to calculate subscriber segments.',
                    $e,
                    array(
                        'screen' => 'segments',
                    )
                );
            }
        }

        if ( ! is_array( $segments ) ) {
            echo '<p>' . esc_html__( 'We could not calculate segments due to an unexpected error. Please check your debug log for details.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            return;
        }

        if ( class_exists( 'PMCPC_Admin' ) ) {
            PMCPC_Admin::render_support_panels(
                array(
                    array(
                        'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-editor-help',
                        'title'   => __( 'Find a group, then act on it', 'product-mailer-campaigns' ),
                        'items'   => array(
                            __( 'Review the segment size first.', 'product-mailer-campaigns' ),
                            __( 'Choose a segment that matches your goal.', 'product-mailer-campaigns' ),
                            __( 'Jump into a campaign or automation from the right row.', 'product-mailer-campaigns' ),
                        ),
                    ),
                )
            );
            PMCPC_Admin::render_stats_strip(
                array(
                    array(
                        'label' => __( 'Key segments', 'product-mailer-campaigns' ),
                        'value' => '9',
                        'meta'  => __( 'Reusable audience groups', 'product-mailer-campaigns' ),
                    ),
                    array(
                        'label' => __( 'All subscribers', 'product-mailer-campaigns' ),
                        'value' => (string) intval( $segments['all'] ),
                        'meta'  => __( 'Active subscriber base', 'product-mailer-campaigns' ),
                    ),
                    array(
                        'label' => __( 'Customers', 'product-mailer-campaigns' ),
                        'value' => (string) intval( $segments['customers'] ),
                        'meta'  => __( 'At least one order', 'product-mailer-campaigns' ),
                    ),
                    array(
                        'label' => __( 'VIP + high-value', 'product-mailer-campaigns' ),
                        'value' => (string) ( intval( $segments['vip'] ) + intval( $segments['high_value'] ) ),
                        'meta'  => __( 'Top-spend groups', 'product-mailer-campaigns' ),
                    ),
                )
            );
        }

echo '<div class="pmcpc-card">';
echo '<h2>' . esc_html__( 'Key segments', 'product-mailer-campaigns' ) . '</h2>';
echo '<p class="description">' . esc_html__( 'These built-in customer groups give you fast starting points for targeted campaigns without building a segment from scratch every time.', 'product-mailer-campaigns' ) . '</p>';
echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
echo '<table class="widefat striped pmcpc-wide-table">';
echo '<thead><tr>';
echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Segment', 'product-mailer-campaigns' ) . '</th>';
echo '<th class="pmcpc-col-compare">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</th>';
echo '<th class="pmcpc-col-meta">' . esc_html__( 'Description', 'product-mailer-campaigns' ) . '</th>';
echo '<th class="pmcpc-col-actions">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
echo '</tr></thead><tbody>';

// All subscribers.
$create_all_url = $this->build_create_campaign_url( array(
    'pro_segment_key' => '',
) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'All subscribers', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Broadest audience starting point', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['all'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Every active subscriber managed by FlowPress.', 'product-mailer-campaigns' ) . '</span></div></td>';
        echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_all_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
if ( ! empty( $segments['all_samples'] ) ) {
    echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-all">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
}
echo '</div></td>';
echo '</tr>';

// Active customers (have at least one order).
$create_customers_url = $this->build_create_campaign_url( array(
        'pro_segment_key' => 'customers',
    ) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'Customers (at least one order)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Bought once or more', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['customers'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Subscribers who have placed at least one completed WooCommerce order.', 'product-mailer-campaigns' ) . '</span></div></td>';
        echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_customers_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
if ( ! empty( $segments['customer_samples'] ) ) {
    echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-customers">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
}
echo '</div></td>';
echo '</tr>';

// New customers (first order only).
$create_new_customers_seg_url = $this->build_create_campaign_url( array(
        'pro_segment_key' => 'new_customers',
    ) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'New customers (first order only)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'First-purchase audience', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['new_customers'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Subscribers who have placed exactly one WooCommerce order so far.', 'product-mailer-campaigns' ) . '</span></div></td>';
        echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_new_customers_seg_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
if ( ! empty( $segments['new_customer_samples'] ) ) {
    echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-new-customers">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
}

echo '</div></td>';
echo '</tr>';

// Repeat customers (2+ orders).
$create_repeat_customers_seg_url = $this->build_create_campaign_url( array(
        'pro_segment_key' => 'repeat_customers',
    ) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'Repeat customers (2+ orders)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Returning buyers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['repeat_customers'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Subscribers who have placed two or more WooCommerce orders.', 'product-mailer-campaigns' ) . '</span></div></td>';
        echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_repeat_customers_seg_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
if ( ! empty( $segments['repeat_customer_samples'] ) ) {
    echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-repeat-customers">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
}

echo '</div></td>';
echo '</tr>';

// Recent customers (last 30 days).
$create_recent_seg_url = $this->build_create_campaign_url( array(
        'pro_segment_key' => 'recent',
    ) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'Recent customers (last 30 days)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Fresh purchase activity', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['recent'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Customers whose last order was within the last 30 days.', 'product-mailer-campaigns' ) . '</span></div></td>';
        echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_recent_seg_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
if ( ! empty( $segments['recent_samples'] ) ) {
    echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-recent">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
}

echo '</div></td>';
echo '</tr>';


// Recent customers (last 7 days).
$create_recent_7_seg_url = $this->build_create_campaign_url( array(
        'pro_segment_key' => 'recent_7',
    ) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'Recent customers (last 7 days)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Very recent activity', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['recent_7'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Customers whose last order was within the last 7 days.', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_recent_7_seg_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-recent-7">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
echo '</div></td>';
echo '</tr>';

// At-risk customers (60+ days since last order).
$create_at_risk_60_seg_url = $this->build_create_campaign_url( array(
        'pro_segment_key' => 'at_risk_60',
    ) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'At-risk customers (60+ days)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Needs re-engagement', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['at_risk_60'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Customers who have not ordered in 60+ days (but are not yet lapsed).', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_at_risk_60_seg_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-at-risk-60">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
echo '</div></td>';
echo '</tr>';


// High-value customers (over threshold).
$create_high_value_seg_url = $this->build_create_campaign_url( array(
        'pro_segment_key' => 'high_value',
    ) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'High-value customers (over threshold)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Above your spend threshold', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['high_value'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Customers whose lifetime spend is above your configured high-value threshold.', 'product-mailer-campaigns' ) . '</span></div></td>';
        echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_high_value_seg_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
if ( ! empty( $segments['high_value_samples'] ) ) {
    echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-high-value">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
}

echo '</div></td>';
echo '</tr>';

// VIPs.
$create_vip_url = $this->build_create_campaign_url( array(
        'pro_segment_key' => 'vip',
    ) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'VIP customers', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Top 10% of spenders', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['vip'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Subscribers whose lifetime spend is among the top 10% of your customer list.', 'product-mailer-campaigns' ) . '</span></div></td>';
        echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_vip_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
if ( ! empty( $segments['vip_samples'] ) ) {
    echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-vip">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
}
echo '</div></td>';
echo '</tr>';

// Lapsed.
$create_lapsed_url = $this->build_create_campaign_url( array(
        'pro_segment_key' => 'lapsed',
    ) );
echo '<tr>';
echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html__( 'Lapsed customers (90+ days)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Win-back audience', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $segments['lapsed'] ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</span></div></td>';
echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html__( 'Subscribers whose last order was more than 90 days ago.', 'product-mailer-campaigns' ) . '</span></div></td>';
        echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><div class="pmcpc-table-actions__primary">';
$this->render_create_campaign_with_template_picker( $create_lapsed_url, __( 'Create campaign', 'product-mailer-campaigns' ) );
echo '</div>';
if ( ! empty( $segments['lapsed_samples'] ) ) {
    echo '<div class="pmcpc-table-actions__secondary"><a href="#" class="button button-secondary button-small pmcpc-show-segment-examples" data-target="#pmcpc-segment-examples-lapsed">' . esc_html__( 'Show examples', 'product-mailer-campaigns' ) . '</a></div>';
}
echo '</div></td>';
echo '</tr>';

echo '</tbody></table>';
echo '</div></div></div>';

                // Hidden example tables for each segment; toggled via "Show examples" buttons.
        if ( ! empty( $segments['all_samples'] ) ) {
            echo '<div id="pmcpc-segment-examples-all" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
            $this->render_segment_samples_table(
                __( 'Example “All subscribers”', 'product-mailer-campaigns' ),
                $segments['all_samples'],
                isset( $segments['all'] ) ? (int) $segments['all'] : count( $segments['all_samples'] )
            );
            echo '</div>';
        }

        if ( ! empty( $segments['customer_samples'] ) ) {
            echo '<div id="pmcpc-segment-examples-customers" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
            $this->render_segment_samples_table(
                __( 'Example customers (at least one order)', 'product-mailer-campaigns' ),
                $segments['customer_samples'],
                isset( $segments['customers'] ) ? (int) $segments['customers'] : count( $segments['customer_samples'] )
            );
            echo '</div>';
        }


        if ( ! empty( $segments['new_customer_samples'] ) ) {
            echo '<div id="pmcpc-segment-examples-new-customers" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
            $this->render_segment_samples_table(
                __( 'Example new customers (first order only)', 'product-mailer-campaigns' ),
                $segments['new_customer_samples'],
                isset( $segments['new_customers'] ) ? (int) $segments['new_customers'] : count( $segments['new_customer_samples'] )
            );
            echo '</div>';
        }

        if ( ! empty( $segments['repeat_customer_samples'] ) ) {
            echo '<div id="pmcpc-segment-examples-repeat-customers" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
            $this->render_segment_samples_table(
                __( 'Example repeat customers (2+ orders)', 'product-mailer-campaigns' ),
                $segments['repeat_customer_samples'],
                isset( $segments['repeat_customers'] ) ? (int) $segments['repeat_customers'] : count( $segments['repeat_customer_samples'] )
            );
            echo '</div>';
        }

        echo '<div id="pmcpc-segment-examples-recent" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
        $this->render_segment_samples_table(
            __( 'Example recent customers (last 30 days)', 'product-mailer-campaigns' ),
            $segments['recent_samples'],
            isset( $segments['recent'] ) ? (int) $segments['recent'] : count( $segments['recent_samples'] )
        );
        echo '</div>';

        echo '<div id="pmcpc-segment-examples-recent-7" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
        $this->render_segment_samples_table(
            __( 'Example recent customers (last 7 days)', 'product-mailer-campaigns' ),
            $segments['recent_7_samples'],
            isset( $segments['recent_7'] ) ? (int) $segments['recent_7'] : count( $segments['recent_7_samples'] )
        );
        echo '</div>';

        echo '<div id="pmcpc-segment-examples-at-risk-60" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
        $this->render_segment_samples_table(
            __( 'Example at-risk customers (60+ days)', 'product-mailer-campaigns' ),
            $segments['at_risk_60_samples'],
            isset( $segments['at_risk_60'] ) ? (int) $segments['at_risk_60'] : count( $segments['at_risk_60_samples'] )
        );
        echo '</div>';

        if ( ! empty( $segments['high_value_samples'] ) ) {
            echo '<div id="pmcpc-segment-examples-high-value" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
            $this->render_segment_samples_table(
                __( 'Example high-value customers', 'product-mailer-campaigns' ),
                $segments['high_value_samples'],
                isset( $segments['high_value'] ) ? (int) $segments['high_value'] : count( $segments['high_value_samples'] )
            );
            echo '</div>';
        }

        if ( ! empty( $segments['vip_samples'] ) ) {
            echo '<div id="pmcpc-segment-examples-vip" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
            $this->render_segment_samples_table(
                __( 'Example VIP customers', 'product-mailer-campaigns' ),
                $segments['vip_samples'],
                isset( $segments['vip'] ) ? (int) $segments['vip'] : count( $segments['vip_samples'] )
            );
            echo '</div>';
        }

        if ( ! empty( $segments['lapsed_samples'] ) ) {
            echo '<div id="pmcpc-segment-examples-lapsed" class="pmcpc-segment-examples" style="display:none; margin-top:20px;">';
            $this->render_segment_samples_table(
                __( 'Example lapsed customers (90+ days)', 'product-mailer-campaigns' ),
                $segments['lapsed_samples'],
                isset( $segments['lapsed'] ) ? (int) $segments['lapsed'] : count( $segments['lapsed_samples'] )
            );
            echo '</div>';
        }

// Pro campaign revenue (beta).
            $revenue_metrics = null;
            if ( ! $hide_paid_features ) {
                try {
                    $revenue_metrics = $this->calculate_campaign_revenue_metrics();
                } catch ( \Throwable $e ) {
                if ( class_exists( 'PMCPC_Logger' ) ) {
                    PMCPC_Logger::exception(
                        'automation_revenue',
                        'Failed to calculate campaign revenue metrics.',
                        $e,
                        array(
                            'screen' => 'segments',
                        )
                    );
                }
            }

            }

            if ( ! $hide_paid_features && is_array( $revenue_metrics ) && ! empty( $revenue_metrics['campaigns'] ) ) {
                echo '<div class="pmcpc-card">';
                echo '<h2>' . esc_html__( 'Campaign revenue (last 30 days, beta)', 'product-mailer-campaigns' ) . '</h2>';
                echo '<p class="description">' . esc_html__( 'Revenue is attributed using a simple last-touch model. Treat these numbers as directional rather than exact accounting figures.', 'product-mailer-campaigns' ) . '</p>';
                echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
                echo '<table class="widefat striped pmcpc-wide-table">';
                echo '<thead><tr>';
                echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
                echo '<th class="pmcpc-col-compare">' . esc_html__( 'Orders', 'product-mailer-campaigns' ) . '</th>';
                echo '<th class="pmcpc-col-compare">' . esc_html__( 'Revenue', 'product-mailer-campaigns' ) . '</th>';
                echo '</tr></thead><tbody>';

                $campaign_ids   = array_keys( $revenue_metrics['campaigns'] );
                $campaign_ids   = array_map( 'intval', $campaign_ids );
                $campaign_ids   = array_filter( $campaign_ids );
                $campaign_posts = array();

                if ( ! empty( $campaign_ids ) ) {
                    $name_col     = $this->get_campaign_name_column();
                    $placeholders = implode( ',', array_fill( 0, count( $campaign_ids ), '%d' ) );
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                    $sql = "SELECT id, {$name_col} AS campaign_name FROM {$wpdb->prefix}pmcpc_campaigns WHERE id IN ({$placeholders})";
                    $campaign_posts = $wpdb->get_results( $wpdb->prepare( $sql, $campaign_ids ) );
                }

                $names = array();
                if ( ! empty( $campaign_posts ) ) {
                    foreach ( $campaign_posts as $cp ) {
                        $names[ (int) $cp->id ] = $cp->campaign_name;
                    }
                }

                foreach ( $revenue_metrics['campaigns'] as $campaign_id => $data ) {
                    $name    = isset( $names[ $campaign_id ] ) ? $names[ $campaign_id ] : sprintf( __( 'Campaign #%d', 'product-mailer-campaigns' ), $campaign_id );
                    $orders  = isset( $data['orders'] ) ? (int) $data['orders'] : 0;
                    $revenue = isset( $data['revenue'] ) ? (float) $data['revenue'] : 0.0;

                    echo '<tr>';
                    echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( $name ) . '</span><span class="pmcpc-table-record__meta">' . sprintf( esc_html__( 'Campaign #%d', 'product-mailer-campaigns' ), $campaign_id ) . '</span></div></td>';
                    echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . intval( $orders ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Orders', 'product-mailer-campaigns' ) . '</span></div></td>';
                    echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . wp_kses_post( wc_price( $revenue ) ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Attributed revenue', 'product-mailer-campaigns' ) . '</span></div></td>';
                    echo '</tr>';
                }

                echo '</tbody></table>';
                echo '</div></div>';
                echo '</div>';
            }

    echo '<p class="description">' . esc_html__( 'Use these segments as a starting point for targeted campaigns (for example, VIP offers or a lapsed customer win-back series).', 'product-mailer-campaigns' ) . '</p>';

    echo '</div>';

    // Inline JS: toggle example segments tables.
    echo '<script type="text/javascript">jQuery(function($){'
        . '$(".pmcpc-show-segment-examples").on("click", function(e){'
        . 'e.preventDefault();'
        . 'var $btn = $(this);'
        . 'var target = $btn.data("target");'
        . 'var $panel = $(target);'
        . 'if (!$panel.length) { return; }'
        . '$panel.toggle();'
        . 'var isVisible = $panel.is(":visible");'
        . '$btn.attr("aria-expanded", isVisible ? "true" : "false");'
        . 'if (isVisible) {'
            . '$btn.text("' . esc_js( __( 'Hide examples', 'product-mailer-campaigns' ) ) . '");'
        . '} else {'
            . '$btn.text("' . esc_js( __( 'Show examples', 'product-mailer-campaigns' ) ) . '");'
        . '}'
        . '});'
        . '});</script>';
}

    /**
     * Public helper for diagnostics: get the current segment summary and example rows.
     *
     * @return array
     */
    public function get_segments_overview_for_debug() {
        global $wpdb;

        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';

        return $this->calculate_segments( $subscribers_table );
    }

    /**
     * Render a small sample table for a segment (if rows exist).
     *
     * @param string $heading          Heading text.
     * @param array  $rows             Sample rows with 'email', 'total_spent' and optional 'last_order_ts'.
     * @param int    $total_in_segment Total subscribers in this segment.
     */
    protected function render_segment_samples_table( $heading, $rows, $total_in_segment ) {
        if ( ! is_array( $rows ) ) {
            $rows = array();
        }

        // Show at most 3 rows for a compact UI.
        $max_rows     = 3;
        $rows_to_show = array_slice( $rows, 0, $max_rows );
        $shown_count  = count( $rows_to_show );

        echo '<h2>' . esc_html( $heading ) . '</h2>';
        if ( empty( $rows_to_show ) ) {
            echo '<div class="notice inline notice-info" style="margin:12px 0 0; padding:12px 14px;"><p style="margin:0;">' .
                esc_html__( 'No current example subscribers were found for this segment yet.', 'product-mailer-campaigns' ) .
            '</p></div>';
        } else {
        echo '<table class="widefat striped" style="width:100%;">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__( 'Email', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Estimated lifetime value', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Last order', 'product-mailer-campaigns' ) . '</th>';
        echo '</tr></thead><tbody>';

        foreach ( $rows_to_show as $row ) {
            $email       = isset( $row['email'] ) ? $row['email'] : '';
            $total_spent = isset( $row['total_spent'] ) ? (float) $row['total_spent'] : 0.0;
            $last_order  = ( isset( $row['last_order_ts'] ) && $row['last_order_ts'] )
                ? date_i18n( get_option( 'date_format' ), (int) $row['last_order_ts'] )
                : '—';

            echo '<tr>';
            echo '<td>' . esc_html( $email ) . '</td>';

            if ( function_exists( 'wc_price' ) ) {
                $formatted = wc_price( $total_spent );
            } else {
                $formatted = esc_html( number_format_i18n( $total_spent, 2 ) );
            }

            echo '<td>' . wp_kses_post( $formatted ) . '</td>';
            echo '<td>' . esc_html( $last_order ) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        }

        echo '<p style="margin-top:8px; color:#555;">';
        printf(
            /* translators: 1: shown count, 2: total in segment */
            esc_html__( 'Showing %1$d of %2$d subscribers in this segment.', 'product-mailer-campaigns' ),
            (int) $shown_count,
            (int) $total_in_segment
        );
        echo '<br />' . esc_html__(
            'These examples help you check that the segment is picking up the right subscribers.',
            'product-mailer-campaigns'
        );
        echo '</p>';
    }

    /**
     * Build simple dynamic segments from the Product Mailer subscribers table
     * and WooCommerce orders.
     *
     * @param string $subscribers_table Table name for subscribers.
     * @return array
     */
    protected function calculate_segments( $subscribers_table ) {
        global $wpdb;

        $segments = array(
            'all'              => 0,
            'customers'        => 0,
            'new_customers'    => 0,
            'repeat_customers'     => 0,
            'recent'               => 0,
            'high_value'           => 0,
            'vip'                  => 0,
            'lapsed'               => 0,
            'vip_samples'          => array(),
            'all_samples'          => array(),
            'customer_samples'     => array(),
            'lapsed_samples'       => array(),
            'new_customer_samples' => array(),
            'repeat_customer_samples' => array(),
            'recent_samples'       => array(),
            'recent_7_samples'     => array(),
            'at_risk_60_samples'   => array(),
            'high_value_samples'   => array(),
        );

        // Count all active subscribers.
        $segments['all'] = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$subscribers_table} WHERE status = 'active'"
        );

        if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
            return $segments;
        }

        // Build a map of subscriber email -> ID.
        $subscriber_rows = $wpdb->get_results(
            "SELECT id, email FROM {$subscribers_table} WHERE status = 'active'",
            ARRAY_A
        );

        if ( empty( $subscriber_rows ) ) {
            return $segments;
        }

        $email_to_subscriber = array();
        foreach ( $subscriber_rows as $row ) {
            $email_to_subscriber[ strtolower( $row['email'] ) ] = (int) $row['id'];
        }

        // Fetch a sample of orders and aggregate by subscriber.
        $args = array(
            'limit'  => 1000,
            'status' => array( 'wc-completed', 'wc-processing' ),
            'return' => 'ids',
            'orderby' => 'date',
            'order'   => 'DESC',
        );

        $orders = wc_get_orders( $args );

        if ( empty( $orders ) ) {
            return $segments;
        }

        $ninety_days_ago = strtotime( '-90 days' );

        $subscriber_totals  = array();
        $subscriber_last_ts = array();

        $subscriber_order_counts = array();
        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) {
                continue;
            }

            // Skip refunds or non-standard order types.
            if ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) {
                continue;
            }

            $email = strtolower( $order->get_billing_email() );
            if ( ! $email || ! isset( $email_to_subscriber[ $email ] ) ) {
                continue;
            }

            $subscriber_id = $email_to_subscriber[ $email ];
            $order_ts      = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : false;

            if ( ! $order_ts ) {
                continue;
            }

            if ( ! isset( $subscriber_totals[ $subscriber_id ] ) ) {
                $subscriber_totals[ $subscriber_id ]  = 0;
                $subscriber_last_ts[ $subscriber_id ] = 0;
            }

            if ( ! isset( $subscriber_order_counts[ $subscriber_id ] ) ) {
                $subscriber_order_counts[ $subscriber_id ] = 0;
            }
            $subscriber_order_counts[ $subscriber_id ]++;


            $subscriber_totals[ $subscriber_id ] += (float) $order->get_total();
            if ( $order_ts > $subscriber_last_ts[ $subscriber_id ] ) {
                $subscriber_last_ts[ $subscriber_id ] = $order_ts;
            }
        }

        if ( empty( $subscriber_totals ) ) {
            return $segments;
        }

        // Customers segment: any subscriber with at least one order.
        $segments['customers'] = count( $subscriber_totals );
        $new_customers    = 0;
        $repeat_customers = 0;
        if ( ! empty( $subscriber_order_counts ) ) {
            foreach ( $subscriber_order_counts as $subscriber_id => $order_count ) {
                $order_count = (int) $order_count;
                if ( 1 === $order_count ) {
                    $new_customers++;
                } elseif ( $order_count >= 2 ) {
                    $repeat_customers++;
                }
            }
        }
        $segments['new_customers']    = $new_customers;
        $segments['repeat_customers'] = $repeat_customers;

        // Lapsed: last order > 90 days.
        $lapsed_ids = array();
        foreach ( $subscriber_last_ts as $subscriber_id => $last_ts ) {
            if ( $last_ts <= $ninety_days_ago ) {
                $lapsed_ids[ $subscriber_id ] = $last_ts;
            }
        }
        $segments['lapsed'] = count( $lapsed_ids );

        // Recent buyers: last order within the last 30 days.
        $thirty_days_ago      = strtotime( '-30 days' );
        $seven_days_ago       = strtotime( '-7 days' );
        $sixty_days_ago       = strtotime( '-60 days' );

        $recent_buyers        = 0;
        $recent_buyers_7      = 0;
        $at_risk_buyers_60    = 0;

        foreach ( $subscriber_last_ts as $subscriber_id => $last_ts ) {
            if ( $last_ts > $thirty_days_ago ) {
                $recent_buyers++;
            }
            if ( $last_ts > $seven_days_ago ) {
                $recent_buyers_7++;
            }
            // At-risk: no completed order in 60+ days, but not yet lapsed (90+ days).
            if ( $last_ts <= $sixty_days_ago && $last_ts > $ninety_days_ago ) {
                $at_risk_buyers_60++;
            }
        }

        $segments['recent']    = $recent_buyers;
        $segments['recent_7']  = $recent_buyers_7;
        $segments['at_risk_60']= $at_risk_buyers_60;

        // High-value customers: lifetime spend above the configured high-value threshold.
        $high_value_count = 0;
        $threshold        = 0;

        if ( function_exists( 'pmcpc_get_setting' ) ) {
            $threshold = (float) pmcpc_get_setting( 'lifecycle_high_value_threshold', 0 );
        }

        if ( $threshold > 0 ) {
            foreach ( $subscriber_totals as $subscriber_id => $total_spent ) {
                if ( $total_spent >= $threshold ) {
                    $high_value_count++;
                }
            }
        }

        $segments['high_value'] = $high_value_count;

        // Sort totals once for sampling.
        arsort( $subscriber_totals );
        $total_customers = count( $subscriber_totals );

        // Map subscriber_id -> email for quick lookups.
        $subscriber_email_map = array();
        foreach ( $subscriber_rows as $row ) {
            $subscriber_email_map[ (int) $row['id'] ] = $row['email'];
        }

        $lookup_email = function( $subscriber_id ) use ( $subscriber_email_map ) {
            $subscriber_id = (int) $subscriber_id;
            return isset( $subscriber_email_map[ $subscriber_id ] ) ? $subscriber_email_map[ $subscriber_id ] : '';
        };

        // Customers: take up to 5 highest-spending customers as samples.
        $segments['customer_samples'] = array();
        if ( $total_customers > 0 ) {
            $customer_samples = array_slice( $subscriber_totals, 0, 5, true );

            foreach ( $customer_samples as $subscriber_id => $total_spent ) {
                $email = $lookup_email( $subscriber_id );
                if ( ! $email ) {
                    continue;
                }

                $segments['customer_samples'][] = array(
                    'subscriber_id' => (int) $subscriber_id,
                    'email'         => $email,
                    'total_spent'   => (float) $total_spent,
                    'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
                );
            }
        }

        // VIP: top 10% by spend, and collect a few sample rows.
        $vip_count       = $total_customers > 0 ? max( 1, (int) ceil( $total_customers * 0.1 ) ) : 0;
        $segments['vip'] = $vip_count;

        $segments['vip_samples'] = array();
        if ( $vip_count > 0 ) {
            $vip_samples = array_slice( $subscriber_totals, 0, min( 5, $vip_count ), true );
            foreach ( $vip_samples as $subscriber_id => $total_spent ) {
                $email = $lookup_email( $subscriber_id );
                if ( ! $email ) {
                    continue;
                }

                $segments['vip_samples'][] = array(
                    'subscriber_id' => (int) $subscriber_id,
                    'email'         => $email,
                    'total_spent'   => (float) $total_spent,
                    'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
                );
            }
        }

        // Lapsed samples (90+ days since last order).
        $segments['lapsed_samples'] = array();
        if ( ! empty( $lapsed_ids ) ) {
            // Most recently active lapsed customers first.
            arsort( $lapsed_ids );
            $lapsed_sample_ids = array_slice( array_keys( $lapsed_ids ), 0, 5 );

            foreach ( $lapsed_sample_ids as $subscriber_id ) {
                $email = $lookup_email( $subscriber_id );
                if ( ! $email ) {
                    continue;
                }

                $segments['lapsed_samples'][] = array(
                    'subscriber_id' => (int) $subscriber_id,
                    'email'         => $email,
                    'total_spent'   => isset( $subscriber_totals[ $subscriber_id ] ) ? (float) $subscriber_totals[ $subscriber_id ] : 0.0,
                    'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
                );
            }
        }

        

        // New customers (first order only) sample.
        $segments['new_customer_samples'] = array();
        if ( ! empty( $subscriber_order_counts ) ) {
            $new_ids = array();
            foreach ( $subscriber_order_counts as $subscriber_id => $order_count ) {
                if ( (int) $order_count === 1 ) {
                    $new_ids[] = (int) $subscriber_id;
                }
            }
            if ( ! empty( $new_ids ) ) {
                $new_ids = array_slice( $new_ids, 0, 5 );
                foreach ( $new_ids as $subscriber_id ) {
                    $email = $lookup_email( $subscriber_id );
                    if ( ! $email ) {
                        continue;
                    }
                    $segments['new_customer_samples'][] = array(
                        'subscriber_id' => (int) $subscriber_id,
                        'email'         => $email,
                        'total_spent'   => isset( $subscriber_totals[ $subscriber_id ] ) ? (float) $subscriber_totals[ $subscriber_id ] : 0.0,
                        'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
                    );
                }
            }
        }

        // Repeat customers (2+ orders) sample.
        $segments['repeat_customer_samples'] = array();
        if ( ! empty( $subscriber_order_counts ) ) {
            $repeat_ids = array();
            foreach ( $subscriber_order_counts as $subscriber_id => $order_count ) {
                if ( (int) $order_count >= 2 ) {
                    $repeat_ids[] = (int) $subscriber_id;
                }
            }
            if ( ! empty( $repeat_ids ) ) {
                $repeat_ids = array_slice( $repeat_ids, 0, 5 );
                foreach ( $repeat_ids as $subscriber_id ) {
                    $email = $lookup_email( $subscriber_id );
                    if ( ! $email ) {
                        continue;
                    }
                    $segments['repeat_customer_samples'][] = array(
                        'subscriber_id' => (int) $subscriber_id,
                        'email'         => $email,
                        'total_spent'   => isset( $subscriber_totals[ $subscriber_id ] ) ? (float) $subscriber_totals[ $subscriber_id ] : 0.0,
                        'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
                    );
                }
            }
        }

        // Recent customers (last 30 days) sample.
        $segments['recent_samples'] = array();
        if ( ! empty( $subscriber_last_ts ) ) {
            $recent_ids = array();
            foreach ( $subscriber_last_ts as $subscriber_id => $last_ts ) {
                if ( $last_ts > $thirty_days_ago ) {
                    $recent_ids[] = (int) $subscriber_id;
                }
            }
            if ( ! empty( $recent_ids ) ) {
                $recent_ids = array_slice( $recent_ids, 0, 5 );
                foreach ( $recent_ids as $subscriber_id ) {
                    $email = $lookup_email( $subscriber_id );
                    if ( ! $email ) {
                        continue;
                    }
                    $segments['recent_samples'][] = array(
                        'subscriber_id' => (int) $subscriber_id,
                        'email'         => $email,
                        'total_spent'   => isset( $subscriber_totals[ $subscriber_id ] ) ? (float) $subscriber_totals[ $subscriber_id ] : 0.0,
                        'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
                    );
                }
            }
        }

        // Recent customers (last 7 days) sample.
        $segments['recent_7_samples'] = array();
        if ( ! empty( $subscriber_last_ts ) ) {
            $recent_7_ids = array();
            foreach ( $subscriber_last_ts as $subscriber_id => $last_ts ) {
                if ( $last_ts > $seven_days_ago ) {
                    $recent_7_ids[] = (int) $subscriber_id;
                }
            }
            if ( ! empty( $recent_7_ids ) ) {
                $recent_7_ids = array_slice( $recent_7_ids, 0, 5 );
                foreach ( $recent_7_ids as $subscriber_id ) {
                    $email = $lookup_email( $subscriber_id );
                    if ( ! $email ) {
                        continue;
                    }
                    $segments['recent_7_samples'][] = array(
                        'subscriber_id' => (int) $subscriber_id,
                        'email'         => $email,
                        'total_spent'   => isset( $subscriber_totals[ $subscriber_id ] ) ? (float) $subscriber_totals[ $subscriber_id ] : 0.0,
                        'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
                    );
                }
            }
        }

        // At-risk customers (60+ days, but not yet lapsed) sample.
        $segments['at_risk_60_samples'] = array();
        if ( ! empty( $subscriber_last_ts ) ) {
            $at_risk_60_ids = array();
            foreach ( $subscriber_last_ts as $subscriber_id => $last_ts ) {
                if ( $last_ts <= $sixty_days_ago && $last_ts > $ninety_days_ago ) {
                    $at_risk_60_ids[] = (int) $subscriber_id;
                }
            }
            if ( ! empty( $at_risk_60_ids ) ) {
                $at_risk_60_ids = array_slice( $at_risk_60_ids, 0, 5 );
                foreach ( $at_risk_60_ids as $subscriber_id ) {
                    $email = $lookup_email( $subscriber_id );
                    if ( ! $email ) {
                        continue;
                    }
                    $segments['at_risk_60_samples'][] = array(
                        'subscriber_id' => (int) $subscriber_id,
                        'email'         => $email,
                        'total_spent'   => isset( $subscriber_totals[ $subscriber_id ] ) ? (float) $subscriber_totals[ $subscriber_id ] : 0.0,
                        'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
                    );
                }
            }
        }

        // High-value customers sample.
        $segments['high_value_samples'] = array();
        if ( $threshold > 0 ) {
            $hv_ids = array();
            foreach ( $subscriber_totals as $subscriber_id => $total_spent ) {
                if ( (float) $total_spent >= $threshold ) {
                    $hv_ids[] = (int) $subscriber_id;
                }
            }
            if ( ! empty( $hv_ids ) ) {
                $hv_ids = array_slice( $hv_ids, 0, 5 );
                foreach ( $hv_ids as $subscriber_id ) {
                    $email = $lookup_email( $subscriber_id );
                    if ( ! $email ) {
                        continue;
                    }
                    $segments['high_value_samples'][] = array(
                        'subscriber_id' => (int) $subscriber_id,
                        'email'         => $email,
                        'total_spent'   => isset( $subscriber_totals[ $subscriber_id ] ) ? (float) $subscriber_totals[ $subscriber_id ] : 0.0,
                        'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
                    );
                }
            }
        }

// All-subscribers sample (active subscribers, regardless of orders).
        $segments['all_samples'] = array();
        $max_all_samples         = 5;
        $count                   = 0;

        foreach ( $subscriber_rows as $row ) {
            $subscriber_id = (int) $row['id'];

            $segments['all_samples'][] = array(
                'subscriber_id' => $subscriber_id,
                'email'         => $row['email'],
                'total_spent'   => isset( $subscriber_totals[ $subscriber_id ] ) ? (float) $subscriber_totals[ $subscriber_id ] : 0.0,
                'last_order_ts' => isset( $subscriber_last_ts[ $subscriber_id ] ) ? (int) $subscriber_last_ts[ $subscriber_id ] : null,
            );

            $count++;
            if ( $count >= $max_all_samples ) {
                break;
            }
        }

        return $segments;
    }

}
