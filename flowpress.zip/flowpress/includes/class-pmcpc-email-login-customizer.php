<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Admin settings + runtime hooks for:
 * - Double opt-in email subject/body
 * - WP password reset subject/body
 * - Login page styling (logo/bg/button) + message
 */
class PMCPC_Email_Login_Customizer {

    const OPTION_KEY = 'pmcpc_email_login_options';
    const MENU_SLUG  = 'pmcpc-email-login-settings';

    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );

        add_filter( 'pmcpc_double_opt_in_subject', array( __CLASS__, 'filter_double_subject' ) );
        add_filter( 'pmcpc_double_opt_in_message', array( __CLASS__, 'filter_double_message' ), 10, 2 );

        add_filter( 'retrieve_password_title', array( __CLASS__, 'filter_reset_subject' ), 10, 3 );
        add_filter( 'retrieve_password_message', array( __CLASS__, 'filter_reset_message' ), 10, 4 );

        add_action( 'login_enqueue_scripts', array( __CLASS__, 'login_enqueue_scripts' ) );
        add_filter( 'login_message', array( __CLASS__, 'login_message' ) );
    }

    /**
     * Default option values. Keep these blank so the UI can distinguish
     * between custom templates and built-in fallback templates.
     *
     * @return array<string,string>
     */
    private static function get_default_options() {
        return array(
            'double_subject'  => '',
            'double_body'     => '',
            'reset_subject'   => '',
            'reset_body'      => '',
            'login_logo'      => '',
            'login_bg_color'  => '',
            'login_btn_color' => '',
            'login_message'   => '',
        );
    }

    public static function get_options() {
        $options = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $options ) ) {
            $options = array();
        }

        return array_merge( self::get_default_options(), $options );
    }

    public static function register_menu() {
        if ( ( class_exists( 'PMCPC_Admin_UI_Service' ) || class_exists( 'PMCPC_Admin_UI' ) ) ) {
            return;
        }

        add_submenu_page(
            'pmcpc_dashboard',
            __( 'Email & Login Customization', 'product-mailer-campaigns' ),
            __( 'Email & Login', 'product-mailer-campaigns' ),
            'manage_options',
            self::MENU_SLUG,
            array( __CLASS__, 'render_settings_page' )
        );

        // Back-compat: earlier builds linked to page=pmcpc_email_login.
        add_submenu_page(
            'pmcpc_dashboard',
            __( 'Email & Login Customization', 'product-mailer-campaigns' ),
            __( 'Email & Login Customization', 'product-mailer-campaigns' ),
            'manage_options',
            'pmcpc_email_login',
            array( __CLASS__, 'render_settings_page' )
        );

        remove_submenu_page( 'pmcpc_dashboard', 'pmcpc_email_login' );
    }

    public static function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $options = self::get_options();

        $tab = isset( $_GET['tab'] ) ? sanitize_key( (string) $_GET['tab'] ) : 'double_optin';
        $allowed_tabs = array( 'double_optin', 'password_reset', 'login' );
        if ( ! in_array( $tab, $allowed_tabs, true ) ) {
            $tab = 'double_optin';
        }

        $double_subject = isset( $options['double_subject'] ) ? (string) $options['double_subject'] : '';
        $double_body    = isset( $options['double_body'] ) ? (string) $options['double_body'] : '';

        // Default templates (used when fields are empty).
        $site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
        $default_double_subject = sprintf(
            /* translators: %s: Site name */
            __( 'Please confirm your subscription to %s', 'product-mailer-campaigns' ),
            $site_name
        );
        $default_double_body = implode( "\n\n", array(
            __( 'Hi,', 'product-mailer-campaigns' ),
            sprintf(
                /* translators: %s: Site name */
                __( 'Thanks for subscribing to %s.', 'product-mailer-campaigns' ),
                $site_name
            ),
            __( 'Please confirm your subscription by clicking the link below:', 'product-mailer-campaigns' ),
            '{confirm_url}',
            __( 'If you didn\'t request this, you can safely ignore this email.', 'product-mailer-campaigns' ),
        ) );

        if ( '' === trim( $double_subject ) ) {
            $double_subject = $default_double_subject;
        }
        if ( '' === trim( $double_body ) ) {
            $double_body = $default_double_body;
        }

        $reset_subject  = isset( $options['reset_subject'] ) ? (string) $options['reset_subject'] : '';
        $reset_body     = isset( $options['reset_body'] ) ? (string) $options['reset_body'] : '';

        // Default password reset templates (used when fields are empty).
        $default_reset_subject = sprintf(
            /* translators: %s: Site name */
            __( 'Password Reset for %s', 'product-mailer-campaigns' ),
            $site_name
        );
        $default_reset_body = implode( "\n\n", array(
            __( 'Hi {username},', 'product-mailer-campaigns' ),
            sprintf(
                /* translators: %s: Site name */
                __( 'We received a request to reset your password on %s.', 'product-mailer-campaigns' ),
                $site_name
            ),
            __( 'You can reset it by clicking this link:', 'product-mailer-campaigns' ),
            '{reset_url}',
            __( "If you didn't request this, you can safely ignore this email.", 'product-mailer-campaigns' ),
        ) );

        if ( '' === trim( $reset_subject ) ) {
            $reset_subject = $default_reset_subject;
        }
        if ( '' === trim( $reset_body ) ) {
            $reset_body = $default_reset_body;
        }

        $login_logo     = isset( $options['login_logo'] ) ? (string) $options['login_logo'] : '';
        $login_bg_color = isset( $options['login_bg_color'] ) ? (string) $options['login_bg_color'] : '';
        $login_btn_color= isset( $options['login_btn_color'] ) ? (string) $options['login_btn_color'] : '';
        $login_message  = isset( $options['login_message'] ) ? (string) $options['login_message'] : '';
// Handle saves.
        if ( isset( $_POST['pmcpc_email_login_save'] ) ) {
            check_admin_referer( 'pmcpc_email_login_save', 'pmcpc_email_login_nonce' );

            $options['double_subject'] = isset( $_POST['double_subject'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['double_subject'] ) ) : '';
            $options['double_body']    = isset( $_POST['double_body'] ) ? wp_kses_post( (string) wp_unslash( $_POST['double_body'] ) ) : '';

            $options['reset_subject']  = isset( $_POST['reset_subject'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['reset_subject'] ) ) : '';
            $options['reset_body']     = isset( $_POST['reset_body'] ) ? wp_kses_post( (string) wp_unslash( $_POST['reset_body'] ) ) : '';

            $options['login_logo']     = isset( $_POST['login_logo'] ) ? esc_url_raw( (string) wp_unslash( $_POST['login_logo'] ) ) : '';
            $options['login_bg_color'] = isset( $_POST['login_bg_color'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['login_bg_color'] ) ) : '';
            $options['login_btn_color']= isset( $_POST['login_btn_color'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['login_btn_color'] ) ) : '';
            $options['login_message']  = isset( $_POST['login_message'] ) ? wp_kses_post( (string) wp_unslash( $_POST['login_message'] ) ) : '';

            update_option( self::OPTION_KEY, $options );

            $double_subject = (string) $options['double_subject'];
            $double_body    = (string) $options['double_body'];
            $reset_subject  = (string) $options['reset_subject'];
            $reset_body     = (string) $options['reset_body'];
            $login_logo     = (string) $options['login_logo'];
            $login_bg_color = (string) $options['login_bg_color'];
            $login_btn_color= (string) $options['login_btn_color'];
            $login_message  = (string) $options['login_message'];

            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        // Send test emails.
        if ( isset( $_POST['pmcpc_send_test_double'] ) ) {
            check_admin_referer( 'pmcpc_email_login_save', 'pmcpc_email_login_nonce' );
            do_action( 'pmcpc_send_test_double_opt_in_email' );
            echo '<div class="notice notice-info is-dismissible"><p>' . esc_html__( 'Test double opt-in email requested. Check your inbox.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        if ( isset( $_POST['pmcpc_send_test_reset'] ) ) {
            check_admin_referer( 'pmcpc_email_login_save', 'pmcpc_email_login_nonce' );
            do_action( 'pmcpc_send_test_password_reset_email' );
            echo '<div class="notice notice-info is-dismissible"><p>' . esc_html__( 'Test password reset email requested. Check your inbox.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        $tabs = array(
            'double_optin'    => __( 'Double Opt-In', 'product-mailer-campaigns' ),
            'password_reset'  => __( 'Password Reset', 'product-mailer-campaigns' ),
            'login'           => __( 'Login Page', 'product-mailer-campaigns' ),
        );
        ?>
        <div class="wrap">
            <?php
            if ( class_exists( 'PMCPC_Admin' ) && method_exists( 'PMCPC_Admin', 'render_app_header' ) ) {
                PMCPC_Admin::render_app_header( __( 'Email & Login', 'product-mailer-campaigns' ) );
            }
            if ( class_exists( 'PMCPC_Admin' ) && method_exists( 'PMCPC_Admin', 'render_page_intro' ) ) {
                PMCPC_Admin::render_page_intro(
                    __( 'Customize subscriber emails and your branded login experience', 'product-mailer-campaigns' ),
                    __( 'Manage double opt-in emails, password reset emails, and the WordPress login page from one place while keeping the underlying delivery flow unchanged.', 'product-mailer-campaigns' ),
                    array(
                        array(
                            'label' => __( 'Double opt-in copy', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-email-alt2',
                        ),
                        array(
                            'label' => __( 'Password reset templates', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-lock',
                        ),
                        array(
                            'label' => __( 'Branded login page', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-admin-users',
                        ),
                    )
                );
                PMCPC_Admin::render_support_panels(
                    array(
                        array(
                            'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                            'icon'    => 'dashicons-editor-help',
                            'title'   => __( 'Keep branded emails easy to verify', 'product-mailer-campaigns' ),
                            'items'   => array(
                                __( 'Update the message or branding for one section at a time.', 'product-mailer-campaigns' ),
                                __( 'Use the placeholders shown on the page instead of hard-coding links.', 'product-mailer-campaigns' ),
                                __( 'Send yourself a test whenever you change email copy.', 'product-mailer-campaigns' ),
                            ),
                        ),
                    )
                );
                PMCPC_Admin::render_stats_strip(
                    array(
                        array(
                            'label' => __( 'Current section', 'product-mailer-campaigns' ),
                            'value' => isset( $tabs[ $tab ] ) ? $tabs[ $tab ] : __( 'Double Opt-In', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Active configuration view', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Double opt-in', 'product-mailer-campaigns' ),
                            'value' => '' !== trim( (string) $options['double_subject'] ) ? __( 'Custom', 'product-mailer-campaigns' ) : __( 'Default', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Subject/body template state', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Password reset', 'product-mailer-campaigns' ),
                            'value' => '' !== trim( (string) $options['reset_subject'] ) ? __( 'Custom', 'product-mailer-campaigns' ) : __( 'Default', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Subject/body template state', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Login branding', 'product-mailer-campaigns' ),
                            'value' => ( $login_logo || $login_bg_color || $login_btn_color || $login_message ) ? __( 'Configured', 'product-mailer-campaigns' ) : __( 'Default', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Logo, colours, or message', 'product-mailer-campaigns' ),
                        ),
                    )
                );
            }
            ?>
            <style>
            .pmcpc-email-login-card{padding:18px 20px;border:1px solid #dcdcde;border-radius:14px;background:#fff;box-shadow:0 1px 1px rgba(0,0,0,.03);}
            .pmcpc-email-login-card .nav-tab-wrapper{margin-top:0;margin-bottom:18px;}
            .pmcpc-email-login-card h2{margin-top:0;}
            .pmcpc-email-login-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:18px;align-items:center;}
            .pmcpc-email-login-preview{margin-top:12px;padding:20px;border:1px solid #dcdcde;border-radius:12px;background:#f6f7f7;max-width:420px;}
            </style>
            <div class="pmcpc-email-login-card">
            <h2 class="nav-tab-wrapper">
                <?php foreach ( $tabs as $tab_key => $tab_label ) : ?>
                    <?php
                    $url = add_query_arg( array( 'page' => self::MENU_SLUG, 'tab' => $tab_key ), admin_url( 'admin.php' ) );
                    $classes = 'nav-tab' . ( $tab === $tab_key ? ' nav-tab-active' : '' );
                    ?>
                    <a href="<?php echo esc_url( $url ); ?>" class="<?php echo esc_attr( $classes ); ?>"><?php echo esc_html( $tab_label ); ?></a>
                <?php endforeach; ?>
            </h2>



            <form method="post">
                <?php wp_nonce_field( 'pmcpc_email_login_save', 'pmcpc_email_login_nonce' ); ?>

                <?php if ( 'double_optin' === $tab ) : ?>

                <h2><?php esc_html_e( 'Double Opt-In Email', 'product-mailer-campaigns' ); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="double_subject"><?php esc_html_e( 'Subject', 'product-mailer-campaigns' ); ?></label></th>
                        <td><input type="text" class="regular-text" name="double_subject" id="double_subject" value="<?php echo esc_attr( $double_subject ); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="double_body"><?php esc_html_e( 'Body', 'product-mailer-campaigns' ); ?></label></th>
                        <td>
                            <p class="description"><?php esc_html_e( 'Use {confirm_url} in the message body.', 'product-mailer-campaigns' ); ?></p>
                            <textarea name="double_body" id="double_body" rows="8" class="large-text code"><?php echo esc_textarea( $double_body ); ?></textarea>
                        </td>
                    </tr>
                </table>

                <?php endif; ?>

                <?php if ( 'password_reset' === $tab ) : ?>

                <h2><?php esc_html_e( 'Password Reset Email', 'product-mailer-campaigns' ); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="reset_subject"><?php esc_html_e( 'Subject', 'product-mailer-campaigns' ); ?></label></th>
                        <td>
                            <p class="description"><?php esc_html_e( 'Use {site_name} and {username}.', 'product-mailer-campaigns' ); ?></p>
                            <input type="text" class="regular-text" name="reset_subject" id="reset_subject" value="<?php echo esc_attr( $reset_subject ); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="reset_body"><?php esc_html_e( 'Body', 'product-mailer-campaigns' ); ?></label></th>
                        <td>
                            <p class="description"><?php esc_html_e( 'Use {reset_url}, {site_name}, and {username}.', 'product-mailer-campaigns' ); ?></p>
                            <textarea name="reset_body" id="reset_body" rows="10" class="large-text code"><?php echo esc_textarea( $reset_body ); ?></textarea>
                        </td>
                    </tr>
                </table>

                <?php endif; ?>

                <?php if ( 'login' === $tab ) : ?>

                <h2><?php esc_html_e( 'Login Page', 'product-mailer-campaigns' ); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="login_logo"><?php esc_html_e( 'Logo URL', 'product-mailer-campaigns' ); ?></label></th>
                        <td><input type="url" class="regular-text" name="login_logo" id="login_logo" value="<?php echo esc_attr( $login_logo ); ?>" placeholder="https://"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="login_bg_color"><?php esc_html_e( 'Background Color', 'product-mailer-campaigns' ); ?></label></th>
                        <td><input type="text" class="regular-text" name="login_bg_color" id="login_bg_color" value="<?php echo esc_attr( $login_bg_color ); ?>" placeholder="#f0f0f0"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="login_btn_color"><?php esc_html_e( 'Button Color', 'product-mailer-campaigns' ); ?></label></th>
                        <td><input type="text" class="regular-text" name="login_btn_color" id="login_btn_color" value="<?php echo esc_attr( $login_btn_color ); ?>" placeholder="#2271b1"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="login_message"><?php esc_html_e( 'Login Message', 'product-mailer-campaigns' ); ?></label></th>
                        <td>
                            <textarea name="login_message" id="login_message" rows="4" class="large-text code"><?php echo esc_textarea( $login_message ); ?></textarea>
                        </td>
                    </tr>
                </table>

                <h2><?php esc_html_e( 'Login Preview', 'product-mailer-campaigns' ); ?></h2>
                <p><?php esc_html_e( 'Rough preview of the login page look.', 'product-mailer-campaigns' ); ?></p>
                <div class="pmcpc-email-login-preview" style="background:<?php echo $login_bg_color ? esc_attr( $login_bg_color ) : '#f0f0f0'; ?>;">
                    <div style="text-align:center;margin-bottom:20px;">
                        <?php if ( $login_logo ) : ?>
                            <img src="<?php echo esc_url( $login_logo ); ?>" alt="Logo" style="max-width:180px;height:auto;" />
                        <?php else : ?>
                            <div style="font-size:20px;font-weight:bold;"><?php bloginfo( 'name' ); ?></div>
                        <?php endif; ?>
                    </div>
                    <?php if ( $login_message ) : ?>
                        <p style="margin-bottom:15px;"><?php echo wp_kses_post( $login_message ); ?></p>
                    <?php endif; ?>
                    <p><input type="text" placeholder="<?php esc_attr_e( 'Username or Email Address', 'product-mailer-campaigns' ); ?>" style="width:100%;padding:8px;margin-bottom:10px;" /></p>
                    <p><input type="password" placeholder="<?php esc_attr_e( 'Password', 'product-mailer-campaigns' ); ?>" style="width:100%;padding:8px;margin-bottom:10px;" /></p>
                    <p><button type="button" style="width:100%;padding:8px;border:none;border-radius:3px;background:<?php echo $login_btn_color ? esc_attr( $login_btn_color ) : '#2271b1'; ?>;color:#fff;"><?php esc_html_e( 'Log In', 'product-mailer-campaigns' ); ?></button></p>
                </div>

                <?php endif; ?>

                <div class="pmcpc-email-login-actions">
                    <?php submit_button( __( 'Save Changes', 'product-mailer-campaigns' ), 'primary', 'pmcpc_email_login_save', false ); ?>
                    <?php if ( 'login' !== $tab ) : ?>
                    <?php submit_button( __( 'Send Test Double Opt-In Email', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_send_test_double', false ); ?>
                    <?php submit_button( __( 'Send Test Password Reset Email', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_send_test_reset', false ); ?>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( wp_login_url() ); ?>" class="button"><?php esc_html_e( 'Open Login Page', 'product-mailer-campaigns' ); ?></a>
                </div>
            </form>
            </div>
        </div>
        <?php
    }

    public static function filter_double_subject( $subject ) {
        $options = self::get_options();
        return ! empty( $options['double_subject'] ) ? (string) $options['double_subject'] : $subject;
    }

    public static function filter_double_message( $message, $confirm_url ) {
        $options = self::get_options();
        if ( empty( $options['double_body'] ) ) {
            return $message;
        }

        $tpl = (string) $options['double_body'];
        return str_replace( '{confirm_url}', $confirm_url, $tpl );
    }

    public static function filter_reset_subject( $title, $user_login, $user_data ) {
        $options = self::get_options();
        if ( empty( $options['reset_subject'] ) ) {
            return $title;
        }

        $site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
        return strtr(
            (string) $options['reset_subject'],
            array(
                '{site_name}' => $site_name,
                '{username}'  => (string) $user_login,
            )
        );
    }

    public static function filter_reset_message( $message, $key, $user_login, $user_data ) {
        $options = self::get_options();
        if ( empty( $options['reset_body'] ) ) {
            return $message;
        }

        $site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
        $reset_url = network_site_url( 'wp-login.php?action=rp&key=' . rawurlencode( $key ) . '&login=' . rawurlencode( $user_login ), 'login' );

        return strtr(
            (string) $options['reset_body'],
            array(
                '{reset_url}' => $reset_url,
                '{site_name}' => $site_name,
                '{username}'  => (string) $user_login,
            )
        );
    }

    public static function login_enqueue_scripts() {
        $options = self::get_options();
        $logo    = isset( $options['login_logo'] ) ? (string) $options['login_logo'] : '';
        $bg      = isset( $options['login_bg_color'] ) ? (string) $options['login_bg_color'] : '';
        $btn     = isset( $options['login_btn_color'] ) ? (string) $options['login_btn_color'] : '';

        if ( ! $logo && ! $bg && ! $btn ) {
            return;
        }

        $css = '';
        if ( $logo ) {
            $css .= '#login h1 a{background-image:url(' . esc_url( $logo ) . ')!important;background-size:contain!important;width:100%!important;}';
        }
        if ( $bg ) {
            $css .= 'body.login{background-color:' . esc_attr( $bg ) . '!important;}';
        }
        if ( $btn ) {
            $css .= '.login .button-primary{background-color:' . esc_attr( $btn ) . '!important;border-color:' . esc_attr( $btn ) . '!important;}';
        }

        wp_register_style( 'pmcpc-login-inline', false, array(), PMCPC_PLUGIN_VERSION );
        wp_enqueue_style( 'pmcpc-login-inline' );
        wp_add_inline_style( 'pmcpc-login-inline', $css );
    }

    public static function login_message( $message ) {
        $options = self::get_options();
        if ( empty( $options['login_message'] ) ) {
            return $message;
        }

        $custom = wp_kses_post( (string) $options['login_message'] );
        return '<p class="pmcpc-login-message">' . $custom . '</p>' . $message;
    }
}
