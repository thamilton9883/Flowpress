<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PMCPC_Reviews {
    const TABLE = 'pmcpc_reviews';

    public static function init() {
        add_action( 'init', array( __CLASS__, 'maybe_upgrade' ) );
        add_shortcode( 'pmcpc_reviews', array( __CLASS__, 'render_reviews_shortcode' ) );
        add_shortcode( 'pmcpc_product_reviews', array( __CLASS__, 'render_product_reviews_shortcode' ) );
        add_shortcode( 'pmcpc_all_reviews', array( __CLASS__, 'render_all_reviews_shortcode' ) );
        add_filter( 'pmcpc_campaign_template_vars', array( __CLASS__, 'filter_campaign_template_vars' ), 10, 4 );

        if ( class_exists( 'WooCommerce' ) ) {
            add_action( 'woocommerce_after_single_product_summary', array( __CLASS__, 'maybe_render_product_reviews_on_product_page' ), 15 );
        }
    }

    public static function table_name() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function maybe_upgrade() {
        static $done = false;
        if ( $done ) {
            return;
        }
        $done = true;
        self::ensure_table();
    }

    public static function ensure_table() {
        global $wpdb;
        $table = self::table_name();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
        if ( $exists === $table ) {
            return;
        }
        $charset = $wpdb->get_charset_collate();

        // Do not use dbDelta() here. Some shared hosts disable set_time_limit(),
        // and dbDelta() can call it internally, which creates noisy PHP warnings.
        // This table only needs to be created when missing, so a direct
        // CREATE TABLE IF NOT EXISTS is safer for restricted hosting.
        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            review_type VARCHAR(32) NOT NULL DEFAULT 'review',
            product_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            product_name TEXT NULL,
            reviewer_name TEXT NULL,
            reviewer_email VARCHAR(190) NOT NULL DEFAULT '',
            rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
            review_title TEXT NULL,
            review_text LONGTEXT NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'pending',
            verified_buyer TINYINT(1) NOT NULL DEFAULT 0,
            source VARCHAR(100) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY status (status),
            KEY review_type (review_type),
            KEY reviewer_email (reviewer_email(190)),
            KEY product_id (product_id)
        ) {$charset};";
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
        $wpdb->query( $sql );
    }

    public static function insert_review( $data ) {
        global $wpdb;
        self::ensure_table();
        $table = self::table_name();
        $now   = current_time( 'mysql' );
        $row   = array(
            'form_id'         => isset( $data['form_id'] ) ? absint( $data['form_id'] ) : 0,
            'review_type'     => isset( $data['review_type'] ) ? sanitize_key( (string) $data['review_type'] ) : 'review',
            'product_id'      => isset( $data['product_id'] ) ? absint( $data['product_id'] ) : 0,
            'product_name'    => isset( $data['product_name'] ) ? sanitize_text_field( (string) $data['product_name'] ) : '',
            'reviewer_name'   => isset( $data['reviewer_name'] ) ? sanitize_text_field( (string) $data['reviewer_name'] ) : '',
            'reviewer_email'  => isset( $data['reviewer_email'] ) ? sanitize_email( (string) $data['reviewer_email'] ) : '',
            'rating'          => isset( $data['rating'] ) ? max( 0, min( 5, absint( $data['rating'] ) ) ) : 0,
            'review_title'    => isset( $data['review_title'] ) ? sanitize_text_field( (string) $data['review_title'] ) : '',
            'review_text'     => isset( $data['review_text'] ) ? wp_kses_post( (string) $data['review_text'] ) : '',
            'status'          => isset( $data['status'] ) ? sanitize_key( (string) $data['status'] ) : 'pending',
            'verified_buyer'  => ! empty( $data['verified_buyer'] ) ? 1 : 0,
            'source'          => isset( $data['source'] ) ? sanitize_text_field( (string) $data['source'] ) : '',
            'created_at'      => $now,
            'updated_at'      => $now,
        );
        $formats = array( '%d', '%s', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s' );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $ok = $wpdb->insert( $table, $row, $formats );
        return $ok ? (int) $wpdb->insert_id : 0;
    }

    public static function update_status( $id, $status ) {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->update(
            self::table_name(),
            array(
                'status'     => sanitize_key( (string) $status ),
                'updated_at' => current_time( 'mysql' ),
            ),
            array( 'id' => absint( $id ) ),
            array( '%s', '%s' ),
            array( '%d' )
        );
    }

    public static function delete_review( $id ) {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->delete( self::table_name(), array( 'id' => absint( $id ) ), array( '%d' ) );
    }

    public static function count_reviews( $filters = array() ) {
        global $wpdb;
        self::ensure_table();
        $where = self::build_where_clause( $filters );
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $sql = "SELECT COUNT(*) FROM " . self::table_name() . $where['sql'];

        if ( empty( $where['args'] ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            return (int) $wpdb->get_var( $sql );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (int) $wpdb->get_var( $wpdb->prepare( $sql, $where['args'] ) );
    }

    public static function get_reviews( $filters = array(), $per_page = 50, $offset = 0 ) {
        global $wpdb;
        self::ensure_table();
        $where = self::build_where_clause( $filters );
        $per_page = max( 1, absint( $per_page ) );
        $offset   = max( 0, absint( $offset ) );
        $args     = $where['args'];
        $args[]   = $per_page;
        $args[]   = $offset;
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $sql = "SELECT * FROM " . self::table_name() . $where['sql'] . ' ORDER BY created_at DESC, id DESC LIMIT %d OFFSET %d';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (array) $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
    }

    protected static function build_where_clause( $filters ) {
        $filters = is_array( $filters ) ? $filters : array();
        $where = array();
        $args  = array();
        if ( ! empty( $filters['status'] ) ) {
            $where[] = 'status = %s';
            $args[]  = sanitize_key( (string) $filters['status'] );
        }
        if ( ! empty( $filters['review_type'] ) ) {
            $where[] = 'review_type = %s';
            $args[]  = sanitize_key( (string) $filters['review_type'] );
        }
        if ( ! empty( $filters['product_id'] ) ) {
            $where[] = 'product_id = %d';
            $args[]  = absint( $filters['product_id'] );
        }
        if ( isset( $filters['min_rating'] ) && '' !== $filters['min_rating'] ) {
            $where[] = 'rating >= %d';
            $args[]  = max( 0, min( 5, absint( $filters['min_rating'] ) ) );
        }
        if ( isset( $filters['verified_buyer'] ) && '' !== $filters['verified_buyer'] ) {
            $where[] = 'verified_buyer = %d';
            $args[]  = ! empty( $filters['verified_buyer'] ) ? 1 : 0;
        }
        if ( ! empty( $filters['s'] ) ) {
            $like = '%' . self::esc_like( (string) $filters['s'] ) . '%';
            $where[] = '(reviewer_name LIKE %s OR reviewer_email LIKE %s OR review_text LIKE %s OR product_name LIKE %s)';
            array_push( $args, $like, $like, $like, $like );
        }
        $sql = '';
        if ( ! empty( $where ) ) {
            $sql = ' WHERE ' . implode( ' AND ', $where );
        }
        return array( 'sql' => $sql, 'args' => $args );
    }

    protected static function esc_like( $text ) {
        global $wpdb;
        return $wpdb->esc_like( $text );
    }

    public static function detect_verified_buyer( $email, $product_id = 0 ) {
        if ( ! class_exists( 'WooCommerce' ) || empty( $email ) ) {
            return false;
        }

        $user    = get_user_by( 'email', $email );
        $user_id = $user ? (int) $user->ID : 0;

        if ( $product_id > 0 && function_exists( 'wc_customer_bought_product' ) ) {
            return wc_customer_bought_product( $email, $user_id, $product_id );
        }

        if ( ! function_exists( 'wc_get_orders' ) ) {
            return false;
        }

        $statuses = array( 'wc-completed', 'wc-processing', 'wc-on-hold' );
        $orders   = wc_get_orders(
            array(
                'billing_email' => $email,
                'customer_id'   => $user_id,
                'status'        => $statuses,
                'limit'         => 1,
                'return'        => 'ids',
            )
        );

        return ! empty( $orders );
    }

    public static function get_product_name( $product_id ) {
        $product_id = absint( $product_id );
        if ( $product_id <= 0 ) {
            return '';
        }
        if ( function_exists( 'get_the_title' ) ) {
            return (string) get_the_title( $product_id );
        }
        return '';
    }

    public static function guess_review_page_url() {
        $saved = get_option( 'pmcpc_review_page_url', '' );
        if ( is_string( $saved ) && '' !== trim( $saved ) ) {
            return esc_url_raw( trim( $saved ) );
        }

        $posts = get_posts(
            array(
                'post_type'      => 'page',
                'post_status'    => 'publish',
                'posts_per_page' => 20,
                'orderby'        => 'menu_order title',
                'order'          => 'ASC',
                's'              => 'review',
            )
        );

        foreach ( (array) $posts as $post ) {
            $content = (string) $post->post_content;
            if ( false !== strpos( $content, '[pmcpc_reviews' ) || false !== strpos( $content, '[pmcpc_product_reviews' ) || false !== strpos( $content, '[pmcpc_all_reviews' ) || false !== strpos( $content, '[pmcpc_form' ) ) {
                return get_permalink( $post );
            }
        }

        return apply_filters( 'pmcpc_default_review_page_url', home_url( '/review/' ) );
    }

    public static function build_review_request_url( $args = array() ) {
        $base = self::guess_review_page_url();
        $query = array();
        if ( ! empty( $args['product_id'] ) ) {
            $query['product'] = absint( $args['product_id'] );
        }
        if ( ! empty( $args['order_id'] ) ) {
            $query['order'] = absint( $args['order_id'] );
        }
        if ( ! empty( $args['email'] ) ) {
            $query['email'] = sanitize_email( (string) $args['email'] );
        }
        if ( ! empty( $args['name'] ) ) {
            $query['name'] = sanitize_text_field( (string) $args['name'] );
        }
        if ( isset( $args['rating'] ) && '' !== (string) $args['rating'] ) {
            $query['rating'] = max( 1, min( 5, absint( $args['rating'] ) ) );
        }
        return add_query_arg( $query, $base );
    }

    public static function build_review_stars_block( $args = array() ) {
        $links = array();
        for ( $rating = 5; $rating >= 1; $rating-- ) {
            $url = self::build_review_request_url( array_merge( $args, array( 'rating' => $rating ) ) );
            $label = str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating );
            $links[] = '<a href="' . esc_url( $url ) . '" style="display:inline-block;margin:0 8px 8px 0;padding:8px 12px;border:1px solid rgba(0,0,0,.12);border-radius:999px;text-decoration:none;color:#111;">' . esc_html( $label ) . '</a>';
        }
        return '<div class="pmcpc-review-stars-block"><p style="margin:0 0 10px 0;"><strong>' . esc_html__( 'How was your purchase?', 'product-mailer-campaigns' ) . '</strong></p>' . implode( '', $links ) . '</div>';
    }

    public static function find_existing_review( $email, $product_id = 0 ) {
        global $wpdb;
        self::ensure_table();
        $email = sanitize_email( (string) $email );
        if ( '' === $email ) {
            return array();
        }
        $product_id = absint( $product_id );
        $sql = 'SELECT * FROM ' . self::table_name() . ' WHERE reviewer_email = %s';
        $args = array( $email );
        if ( $product_id > 0 ) {
            $sql .= ' AND product_id = %d';
            $args[] = $product_id;
        } else {
            $sql .= ' AND review_type = %s';
            $args[] = 'review';
        }
        $sql .= " AND status IN ('pending','approved','private_feedback') ORDER BY id DESC LIMIT 1";
        return (array) $wpdb->get_row( $wpdb->prepare( $sql, $args ), ARRAY_A );
    }

    public static function filter_campaign_template_vars( $vars, $campaign, $subscriber, $context ) {
        $trigger = isset( $campaign->automation_trigger ) ? sanitize_key( (string) $campaign->automation_trigger ) : '';

        $product_id = 0;
        $order_id   = ! empty( $context['order_id'] ) ? absint( $context['order_id'] ) : 0;
        if ( $order_id > 0 && function_exists( 'wc_get_order' ) ) {
            $order = wc_get_order( $order_id );
            if ( $order ) {
                foreach ( $order->get_items() as $item ) {
                    if ( is_object( $item ) && method_exists( $item, 'get_product_id' ) ) {
                        $product_id = absint( $item->get_product_id() );
                        if ( $product_id > 0 ) {
                            break;
                        }
                    }
                }
            }
        }

        $name = '';
        if ( is_object( $subscriber ) ) {
            $name = trim( (string) ( $subscriber->first_name ?? '' ) . ' ' . (string) ( $subscriber->last_name ?? '' ) );
            if ( '' === $name ) {
                $name = (string) ( $subscriber->first_name ?? '' );
            }
        }

        $review_args = array(
            'product_id' => $product_id,
            'order_id'   => $order_id,
            'email'      => is_object( $subscriber ) ? (string) ( $subscriber->email ?? '' ) : '',
            'name'       => $name,
        );

        $vars['review_page_url'] = self::guess_review_page_url();
        $vars['reviews_block']   = self::build_reviews_email_block(
            array(
                'limit'       => 3,
                'min_rating'  => 5,
                'product_id'  => $product_id,
                'empty_html'  => '',
            )
        );

        if ( 'review_request' !== $trigger ) {
            return $vars;
        }

        $vars['review_url']         = self::build_review_request_url( $review_args );
        $vars['review_page_url']    = self::guess_review_page_url();
        $vars['review_stars_block'] = self::build_review_stars_block( $review_args );
        for ( $i = 1; $i <= 5; $i++ ) {
            $vars[ 'review_url_' . $i ] = self::build_review_request_url( array_merge( $review_args, array( 'rating' => $i ) ) );
        }

        return $vars;
    }



    public static function build_reviews_email_block( $args = array() ) {
        $args = wp_parse_args(
            is_array( $args ) ? $args : array(),
            array(
                'limit'      => 3,
                'min_rating' => 5,
                'product_id' => 0,
                'title'      => __( 'What customers are saying', 'product-mailer-campaigns' ),
                'empty_html' => '',
            )
        );

        $filters = array(
            'status'     => 'approved',
            'min_rating' => $args['min_rating'],
        );
        if ( ! empty( $args['product_id'] ) ) {
            $filters['product_id'] = absint( $args['product_id'] );
        }

        $reviews = self::get_reviews( $filters, max( 1, absint( $args['limit'] ) ), 0 );
        if ( empty( $reviews ) && ! empty( $args['product_id'] ) ) {
            unset( $filters['product_id'] );
            $reviews = self::get_reviews( $filters, max( 1, absint( $args['limit'] ) ), 0 );
        }
        if ( empty( $reviews ) ) {
            return (string) $args['empty_html'];
        }

        $cards = array();
        foreach ( $reviews as $review ) {
            $rating = isset( $review['rating'] ) ? max( 0, min( 5, absint( $review['rating'] ) ) ) : 0;
            $stars  = str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating );
            $name   = ! empty( $review['reviewer_name'] ) ? sanitize_text_field( (string) $review['reviewer_name'] ) : __( 'Verified customer', 'product-mailer-campaigns' );
            $text   = ! empty( $review['review_text'] ) ? wp_strip_all_tags( (string) $review['review_text'] ) : '';
            $title  = ! empty( $review['review_title'] ) ? sanitize_text_field( (string) $review['review_title'] ) : '';
            if ( mb_strlen( $text ) > 180 ) {
                $text = trim( mb_substr( $text, 0, 177 ) ) . '…';
            }

            $body = '';
            if ( '' !== $title ) {
                $body .= '<p style="margin:0 0 8px 0;font-weight:600;color:#111;">' . esc_html( $title ) . '</p>';
            }
            if ( '' !== $text ) {
                $body .= '<p style="margin:0 0 10px 0;color:#444;line-height:1.6;">“' . esc_html( $text ) . '”</p>';
            }
            $body .= '<p style="margin:0;color:#6b7280;font-size:13px;">— ' . esc_html( $name ) . '</p>';

            $cards[] = '<td style="padding:0 0 12px 0;">'
                . '<div style="border:1px solid #e5e7eb;border-radius:12px;padding:16px;background:#fafafa;">'
                . '<div style="margin:0 0 10px 0;font-size:16px;color:#111;letter-spacing:1px;">' . esc_html( $stars ) . '</div>'
                . $body
                . '</div>'
                . '</td>';
        }

        return '<div class="pmcpc-email-reviews-block" style="margin:18px 0;">'
            . '<p style="margin:0 0 12px 0;font-weight:600;color:#111;">' . esc_html( (string) $args['title'] ) . '</p>'
            . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="width:100%;border-collapse:separate;border-spacing:0 0;">'
            . '<tr><td style="padding:0;">'
            . implode( '', $cards )
            . '</td></tr>'
            . '</table>'
            . '</div>';
    }

    public static function inject_reviews_block_into_content( $content, $args = array() ) {
        $content = (string) $content;
        if ( '' === $content ) {
            return $content;
        }

        if ( false === strpos( $content, '{{reviews_block}}' ) && false === strpos( $content, '{{reviews}}' ) ) {
            return $content;
        }

        $block_html = self::build_reviews_email_block( is_array( $args ) ? $args : array() );
        return str_replace( array( '{{reviews_block}}', '{{reviews}}' ), $block_html, $content );
    }

    public static function render_reviews_shortcode( $atts = array() ) {
        $atts = shortcode_atts(
            array(
                'limit'         => 10,
                'min_rating'    => '',
                'show_summary'  => 'yes',
                'show_title'    => 'yes',
                'show_pagination' => 'yes',
                'title'         => __( 'Customer reviews', 'product-mailer-campaigns' ),
                'empty_message' => __( 'No reviews yet.', 'product-mailer-campaigns' ),
            ),
            $atts,
            'pmcpc_reviews'
        );

        return self::render_reviews_list(
            array(
                'status'      => 'approved',
                'review_type' => 'review',
                'min_rating'  => $atts['min_rating'],
            ),
            array(
                'limit'         => absint( $atts['limit'] ),
                'show_summary'  => 'yes' === strtolower( (string) $atts['show_summary'] ),
                'show_title'    => 'yes' === strtolower( (string) $atts['show_title'] ),
                'title'         => (string) $atts['title'],
                'empty_message' => (string) $atts['empty_message'],
                'show_pagination' => 'yes' === strtolower( (string) $atts['show_pagination'] ),
                'context'       => 'general',
            )
        );
    }

    public static function render_all_reviews_shortcode( $atts = array() ) {
        $atts = shortcode_atts(
            array(
                'limit'         => 10,
                'min_rating'    => '',
                'show_summary'  => 'yes',
                'show_title'    => 'yes',
                'show_pagination' => 'yes',
                'title'         => __( 'Customer reviews', 'product-mailer-campaigns' ),
                'empty_message' => __( 'No reviews yet.', 'product-mailer-campaigns' ),
            ),
            $atts,
            'pmcpc_all_reviews'
        );

        return self::render_reviews_list(
            array(
                'status'      => 'approved',
                'min_rating'  => $atts['min_rating'],
            ),
            array(
                'limit'         => absint( $atts['limit'] ),
                'show_summary'  => 'yes' === strtolower( (string) $atts['show_summary'] ),
                'show_title'    => 'yes' === strtolower( (string) $atts['show_title'] ),
                'title'         => (string) $atts['title'],
                'empty_message' => (string) $atts['empty_message'],
                'show_pagination' => 'yes' === strtolower( (string) $atts['show_pagination'] ),
                'context'       => 'all',
            )
        );
    }

    public static function render_product_reviews_shortcode( $atts = array() ) {
        $atts = shortcode_atts(
            array(
                'product'       => 0,
                'limit'         => 10,
                'min_rating'    => '',
                'show_summary'  => 'yes',
                'show_title'    => 'yes',
                'show_pagination' => 'yes',
                'title'         => __( 'Product reviews', 'product-mailer-campaigns' ),
                'empty_message' => __( 'No product reviews yet.', 'product-mailer-campaigns' ),
            ),
            $atts,
            'pmcpc_product_reviews'
        );

        $product_id = absint( $atts['product'] );
        if ( $product_id <= 0 && function_exists( 'get_the_ID' ) ) {
            $product_id = absint( get_the_ID() );
        }
        if ( $product_id <= 0 && function_exists( 'is_singular' ) && is_singular( 'product' ) ) {
            $product_id = absint( get_queried_object_id() );
        }

        return self::render_reviews_list(
            array(
                'status'      => 'approved',
                'review_type' => 'product_review',
                'product_id'  => $product_id,
                'min_rating'  => $atts['min_rating'],
            ),
            array(
                'limit'         => absint( $atts['limit'] ),
                'show_summary'  => 'yes' === strtolower( (string) $atts['show_summary'] ),
                'show_title'    => 'yes' === strtolower( (string) $atts['show_title'] ),
                'title'         => (string) $atts['title'],
                'empty_message' => (string) $atts['empty_message'],
                'show_pagination' => 'yes' === strtolower( (string) $atts['show_pagination'] ),
                'context'       => 'product',
                'product_id'    => $product_id,
            )
        );
    }

    public static function maybe_render_product_reviews_on_product_page() {
        if ( ! function_exists( 'is_product' ) || ! is_product() ) {
            return;
        }

        $enabled = apply_filters( 'pmcpc_auto_render_product_reviews', true );
        if ( ! $enabled ) {
            return;
        }

        $product_id = absint( get_the_ID() );
        if ( $product_id <= 0 ) {
            return;
        }

        echo self::render_reviews_list(
            array(
                'status'      => 'approved',
                'review_type' => 'product_review',
                'product_id'  => $product_id,
            ),
            array(
                'limit'         => (int) apply_filters( 'pmcpc_auto_render_product_reviews_limit', 8 ),
                'show_summary'  => true,
                'show_title'    => true,
                'title'         => __( 'Customer reviews', 'product-mailer-campaigns' ),
                'empty_message' => '',
                'show_pagination' => false,
                'context'       => 'product',
                'product_id'    => $product_id,
            )
        );
    }

    protected static function render_reviews_list( $filters, $args ) {
        $limit       = isset( $args['limit'] ) ? max( 1, absint( $args['limit'] ) ) : 10;
        $show_paging = ! empty( $args['show_pagination'] );
        $page_var    = 'product' === ( isset( $args['context'] ) ? $args['context'] : 'general' ) ? 'pmcpc_product_reviews_page' : 'pmcpc_reviews_page';
        $paged       = isset( $_GET[ $page_var ] ) ? max( 1, absint( wp_unslash( $_GET[ $page_var ] ) ) ) : 1;
        $offset      = ( $paged - 1 ) * $limit;
        $count       = self::count_reviews( $filters );
        $reviews     = self::get_reviews( $filters, $limit, $offset );

        if ( empty( $reviews ) && empty( $args['empty_message'] ) ) {
            return '';
        }

        self::output_review_styles_once();

        ob_start();
        echo '<div class="pmcpc-reviews-wrap pmcpc-reviews-context-' . esc_attr( isset( $args['context'] ) ? $args['context'] : 'general' ) . '">';

        if ( ! empty( $args['show_title'] ) && ! empty( $args['title'] ) ) {
            echo '<h3 class="pmcpc-reviews-title">' . esc_html( $args['title'] ) . '</h3>';
        }

        if ( ! empty( $args['show_summary'] ) && $count > 0 ) {
            echo self::render_summary( $filters, $count );
        }

        if ( empty( $reviews ) ) {
            echo '<p class="pmcpc-reviews-empty">' . esc_html( $args['empty_message'] ) . '</p>';
            echo '</div>';
            return ob_get_clean();
        }

        echo '<div class="pmcpc-reviews-grid">';
        foreach ( $reviews as $review ) {
            $rating      = isset( $review['rating'] ) ? absint( $review['rating'] ) : 0;
            $name        = ! empty( $review['reviewer_name'] ) ? $review['reviewer_name'] : __( 'Verified customer', 'product-mailer-campaigns' );
            $date        = ! empty( $review['created_at'] ) ? mysql2date( get_option( 'date_format' ), $review['created_at'] ) : '';
            $is_product   = ! empty( $review['product_id'] ) || ( isset( $review['review_type'] ) && 'product_review' === $review['review_type'] );
            $review_label = $is_product ? __( 'Purchased item review', 'product-mailer-campaigns' ) : __( 'Store review', 'product-mailer-campaigns' );
            echo '<article class="pmcpc-review-card">';
            echo '<div class="pmcpc-review-card-head">';
            echo '<div class="pmcpc-review-rating" aria-label="' . esc_attr( sprintf( __( '%d out of 5 stars', 'product-mailer-campaigns' ), $rating ) ) . '">' . self::render_stars( $rating ) . '</div>';
            echo '<div class="pmcpc-review-card-badges">';
            echo '<span class="pmcpc-review-type-badge">' . esc_html( $review_label ) . '</span>';
            if ( ! empty( $review['verified_buyer'] ) ) {
                $badge = $is_product ? __( 'Verified buyer', 'product-mailer-campaigns' ) : __( 'Verified customer', 'product-mailer-campaigns' );
                echo '<span class="pmcpc-review-badge">' . esc_html( $badge ) . '</span>';
            }
            echo '</div>';
            echo '</div>';
            if ( ! empty( $review['review_title'] ) ) {
                echo '<h4 class="pmcpc-review-card-title">' . esc_html( $review['review_title'] ) . '</h4>';
            }
            if ( ! empty( $review['review_text'] ) ) {
                echo '<div class="pmcpc-review-card-body">' . wpautop( wp_kses_post( $review['review_text'] ) ) . '</div>';
            }
            if ( ! empty( $review['product_name'] ) && 'general' === ( isset( $args['context'] ) ? $args['context'] : 'general' ) ) {
                echo '<div class="pmcpc-review-product-line"><strong>' . esc_html__( 'Reviewed piece:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $review['product_name'] ) . '</div>';
            }
            echo '<div class="pmcpc-review-card-meta">';
            echo '<span class="pmcpc-review-author">' . esc_html( $name ) . '</span>';
            if ( $date ) {
                echo '<span class="pmcpc-review-date">' . esc_html( $date ) . '</span>';
            }
            echo '</div>';
            echo '</article>';
        }
        echo '</div>';

        if ( $show_paging && $count > $limit ) {
            echo self::render_pagination( $count, $limit, $paged, $page_var );
        }

        echo self::render_schema( $filters, $reviews, $count, $args );
        echo '</div>';
        return ob_get_clean();
    }

    protected static function render_summary( $filters, $count ) {
        global $wpdb;

        $where = self::build_where_clause( $filters );
        $sql   = 'SELECT AVG(rating) FROM ' . self::table_name() . $where['sql'];
        $avg   = (float) $wpdb->get_var( $wpdb->prepare( $sql, $where['args'] ) );
        $avg   = $avg > 0 ? round( $avg, 1 ) : 0;

        ob_start();
        echo '<div class="pmcpc-review-summary">';
        echo '<div class="pmcpc-review-summary-score">' . esc_html( number_format_i18n( $avg, 1 ) ) . '</div>';
        echo '<div class="pmcpc-review-summary-meta">';
        echo '<div class="pmcpc-review-rating" aria-hidden="true">' . self::render_stars( (int) round( $avg ) ) . '</div>';
        echo '<div class="pmcpc-review-summary-count">' . esc_html( sprintf( _n( '%s review', '%s reviews', $count, 'product-mailer-campaigns' ), number_format_i18n( $count ) ) ) . '</div>';
        echo '</div>';
        echo '</div>';
        return ob_get_clean();
    }

    protected static function render_stars( $rating ) {
        $rating = max( 0, min( 5, absint( $rating ) ) );
        $out = '';
        for ( $i = 1; $i <= 5; $i++ ) {
            $out .= $i <= $rating ? '★' : '☆';
        }
        return '<span class="pmcpc-stars">' . esc_html( $out ) . '</span>';
    }


    protected static function render_pagination( $count, $per_page, $paged, $page_var ) {
        $total_pages = (int) ceil( $count / max( 1, $per_page ) );
        if ( $total_pages <= 1 ) {
            return '';
        }

        $links = array();
        for ( $i = 1; $i <= $total_pages; $i++ ) {
            $url = self::build_paged_url( $page_var, $i );
            if ( $i === $paged ) {
                $links[] = '<span class="pmcpc-page-number is-current">' . esc_html( number_format_i18n( $i ) ) . '</span>';
            } else {
                $links[] = '<a class="pmcpc-page-number" href="' . esc_url( $url ) . '">' . esc_html( number_format_i18n( $i ) ) . '</a>';
            }
        }

        return '<nav class="pmcpc-reviews-pagination" aria-label="' . esc_attr__( 'Reviews pagination', 'product-mailer-campaigns' ) . '">' . implode( '', $links ) . '</nav>';
    }

    protected static function build_paged_url( $page_var, $page ) {
        $page = max( 1, absint( $page ) );
        $base = remove_query_arg( array( $page_var ) );
        return add_query_arg( $page_var, $page, $base );
    }

    protected static function render_schema( $filters, $reviews, $count, $args ) {
        if ( empty( $reviews ) || $count <= 0 ) {
            return '';
        }

        global $wpdb;
        $where = self::build_where_clause( $filters );
        $sql   = 'SELECT AVG(rating) FROM ' . self::table_name() . $where['sql'];
        $avg   = (float) $wpdb->get_var( $wpdb->prepare( $sql, $where['args'] ) );
        $avg   = $avg > 0 ? round( $avg, 1 ) : 0;

        $item = array();
        if ( 'product' === ( isset( $args['context'] ) ? $args['context'] : 'general' ) && ! empty( $args['product_id'] ) ) {
            $product_id   = absint( $args['product_id'] );
            $product_name = self::get_product_name( $product_id );
            $item = array(
                '@context' => 'https://schema.org',
                '@type'    => 'Product',
                'name'     => $product_name ? $product_name : get_bloginfo( 'name' ),
                'url'      => get_permalink( $product_id ),
                'aggregateRating' => array(
                    '@type'       => 'AggregateRating',
                    'ratingValue' => (string) $avg,
                    'reviewCount' => (string) $count,
                ),
                'review' => array(),
            );
        } else {
            $item = array(
                '@context' => 'https://schema.org',
                '@type'    => 'Organization',
                'name'     => get_bloginfo( 'name' ),
                'url'      => home_url( '/' ),
                'aggregateRating' => array(
                    '@type'       => 'AggregateRating',
                    'ratingValue' => (string) $avg,
                    'reviewCount' => (string) $count,
                ),
                'review' => array(),
            );
        }

        foreach ( array_slice( $reviews, 0, 5 ) as $review ) {
            $review_name = ! empty( $review['reviewer_name'] ) ? $review['reviewer_name'] : __( 'Customer', 'product-mailer-campaigns' );
            $entry = array(
                '@type'         => 'Review',
                'author'        => array(
                    '@type' => 'Person',
                    'name'  => $review_name,
                ),
                'reviewRating'  => array(
                    '@type'       => 'Rating',
                    'ratingValue' => (string) absint( $review['rating'] ),
                    'bestRating'  => '5',
                ),
                'reviewBody'    => wp_strip_all_tags( (string) $review['review_text'] ),
                'datePublished' => ! empty( $review['created_at'] ) ? mysql2date( 'c', $review['created_at'], false ) : '',
            );
            if ( ! empty( $review['review_title'] ) ) {
                $entry['name'] = wp_strip_all_tags( (string) $review['review_title'] );
            }
            $item['review'][] = $entry;
        }

        return '<script type="application/ld+json">' . wp_json_encode( $item, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
    }

    protected static function output_review_styles_once() {
        static $done = false;
        if ( $done ) {
            return;
        }
        $done = true;

        echo '<style>
        .pmcpc-reviews-wrap{margin:28px 0;}
        .pmcpc-reviews-title{margin:0 0 18px;font-weight:500;letter-spacing:.02em;}
        .pmcpc-review-summary{display:flex;align-items:center;gap:16px;padding:18px 20px;border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.88);backdrop-filter:blur(2px);margin:0 0 18px;box-shadow:0 6px 18px rgba(0,0,0,.03);}
        .pmcpc-review-summary-score{font-size:36px;font-weight:700;line-height:1;color:#111;}
        .pmcpc-review-summary-meta{display:flex;flex-direction:column;gap:5px;}
        .pmcpc-review-summary-count{font-size:14px;opacity:.75;}
        .pmcpc-reviews-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:18px;}
        .pmcpc-review-card{padding:20px;border:1px solid rgba(0,0,0,.08);border-radius:16px;background:rgba(255,255,255,.92);box-shadow:0 6px 18px rgba(0,0,0,.04);}
        .pmcpc-review-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:12px;}
        .pmcpc-review-rating{font-size:18px;line-height:1;color:#b8860b;}
        .pmcpc-review-card-badges{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:8px;}
        .pmcpc-review-badge,.pmcpc-review-type-badge{display:inline-flex;align-items:center;padding:5px 9px;border-radius:999px;font-size:12px;font-weight:600;line-height:1.2;}
        .pmcpc-review-badge{background:rgba(17,17,17,.08);color:#111;}
        .pmcpc-review-type-badge{background:rgba(184,134,11,.12);color:#7b5a00;}
        .pmcpc-review-card-title{margin:0 0 10px;font-size:18px;font-weight:500;line-height:1.35;}
        .pmcpc-review-card-body{font-size:15px;line-height:1.7;color:#2b2b2b;}
        .pmcpc-review-card-body p:first-child{margin-top:0;}
        .pmcpc-review-card-body p:last-child{margin-bottom:0;}
        .pmcpc-review-product-line{margin-top:12px;padding-top:12px;border-top:1px solid rgba(0,0,0,.06);font-size:13px;line-height:1.5;opacity:.82;}
        .pmcpc-review-card-meta{display:flex;flex-wrap:wrap;gap:8px 12px;margin-top:14px;font-size:13px;opacity:.78;}
        .pmcpc-review-author{font-weight:600;color:#111;opacity:1;}
        .pmcpc-reviews-empty{opacity:.8;}
        .pmcpc-reviews-pagination{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px;}
        .pmcpc-page-number{display:inline-flex;align-items:center;justify-content:center;min-width:38px;height:38px;padding:0 10px;border:1px solid rgba(0,0,0,.12);border-radius:999px;background:#fff;text-decoration:none;transition:all .15s ease;}
        .pmcpc-page-number:hover{border-color:#111;transform:translateY(-1px);}
        .pmcpc-page-number.is-current{background:#111;color:#fff;border-color:#111;}
        </style>';
    }

}
