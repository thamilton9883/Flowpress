<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Diagnostics and debug checks for FlowPress.
 *
 * This is a lightweight framework so we can run simple health checks
 * (queue, cron, segments, etc.) directly from the WordPress admin.
 */
class PMCPC_Diagnostics {

    /**
     * Expected table schemas (minimum required columns).
     *
     * Used for integrity checks and a lightweight self-repair.
     * Keep this conservative: only include columns the plugin relies on.
     *
     * @return array<string, string[]> Map: unprefixed table name => required columns.
     */
    private static function get_expected_table_columns() {
        return array(
            'pmcpc_subscribers' => array(
                'id', 'email', 'status', 'lifetime_opens', 'lifetime_clicks', 'created_at', 'updated_at',
            ),
            'pmcpc_campaigns' => array(
                'id', 'name', 'campaign_type', 'subject', 'from_name', 'from_email', 'content', 'status',
                'schedule_type', 'next_run_at', 'created_at', 'updated_at',
            ),
            // NOTE: queue table name is pmcpc_email_queue (not pmcpc_queue).
            'pmcpc_email_queue' => array(
                'id', 'subscriber_id', 'campaign_id', 'to_email', 'subject', 'body_html', 'scheduled_at', 'status', 'created_at', 'updated_at',
            ),
            // Subscriber preference/source/lifecycle tags. (created_at is optional and may not exist on older installs)
            'pmcpc_subscriber_tags' => array(
                'id', 'subscriber_id', 'tag',
            ),
            'pmcpc_email_log' => array(
                'id', 'campaign_id', 'to_email', 'subject', 'status', 'created_at',
            ),
            'pmcpc_email_events' => array(
                'id', 'queue_id', 'event_type', 'created_at',
            ),
            // Raw tracking logs (only used when tracking debug is enabled). Keep this aligned to activator schema.
            'pmcpc_email_event_logs' => array(
                'id', 'queue_id', 'event_type', 'created_at',
                'ip_hash', 'ua_hash', 'user_agent', 'referrer', 'is_bot', 'is_proxy',
            ),
            // Lightweight block log for spam/bounce helpers.
            'pmcpc_block_log' => array(
                'id', 'email', 'domain', 'ip_hash', 'reason', 'context', 'created_at',
            ),
            'pmcpc_spam_submissions' => array(
                'id', 'email', 'created_at',
            ),
        );
    }

    /**
     * Check table presence + required columns.
     *
     * @return array{missing_tables:string[], missing_columns:array<string,string[]>}
     */
    private static function get_table_integrity_report() {
        global $wpdb;

        $expected = self::get_expected_table_columns();
        $missing_tables  = array();
        $missing_columns = array();

        foreach ( $expected as $unprefixed => $cols ) {
            $table = $wpdb->prefix . $unprefixed;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
            if ( empty( $exists ) ) {
                $missing_tables[] = $table;
                continue;
            }

            $present = array();
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $rows = $wpdb->get_results( "SHOW COLUMNS FROM {$table}" );
            if ( is_array( $rows ) ) {
                foreach ( $rows as $r ) {
                    if ( isset( $r->Field ) ) {
                        $present[] = (string) $r->Field;
                    }
                }
            }

            $need_missing = array();
            foreach ( $cols as $c ) {
                if ( ! in_array( $c, $present, true ) ) {
                    $need_missing[] = $c;
                }
            }
            if ( ! empty( $need_missing ) ) {
                $missing_columns[ $table ] = $need_missing;
            }
        }

        return array(
            'missing_tables'  => $missing_tables,
            'missing_columns' => $missing_columns,
        );
    }

    /**
     * Format integrity issues into human-readable bullet lines.
     *
     * @param string[] $missing_tables
     * @param array<string, string[]> $missing_columns
     * @return string[]
     */
    private static function format_table_integrity_details( $missing_tables, $missing_columns ) {
        $lines = array();

        if ( ! empty( $missing_tables ) ) {
            foreach ( (array) $missing_tables as $t ) {
                $lines[] = sprintf( 'Missing table: %s', $t );
            }
        }

        if ( ! empty( $missing_columns ) ) {
            foreach ( (array) $missing_columns as $table => $cols ) {
                if ( empty( $cols ) ) {
                    continue;
                }
                $lines[] = sprintf( 'Missing columns in %s: %s', $table, implode( ', ', array_map( 'sanitize_key', (array) $cols ) ) );
            }
        }

        return $lines;
    }

    /**
     * Handle the "Self-repair" POST action.
     *
     * Runs the plugin's table creation / schema routines and re-checks integrity.
     */
    private static function handle_repair_tables_request() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to perform this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_repair_tables', 'pmcpc_repair_tables_nonce' );

        // Ensure activator is loaded.
        if ( ! class_exists( 'PMCPC_Activator' ) ) {
            $path = dirname( __FILE__ ) . '/class-pmcpc-activator.php';
            if ( file_exists( $path ) ) {
                require_once $path;
            }
        }

        if ( class_exists( 'PMCPC_Activator' ) && is_callable( array( 'PMCPC_Activator', 'activate' ) ) ) {
            PMCPC_Activator::activate();
        }

        $report = self::get_table_integrity_report();
        $ok = empty( $report['missing_tables'] ) && empty( $report['missing_columns'] );

        $url = add_query_arg(
            array(
                'page' => 'pmcpc_diagnostics',
                'pmcpc_repaired' => 1,
                'pmcpc_repair_status' => $ok ? 'ok' : 'fail',
            ),
            admin_url( 'admin.php' )
        );
        wp_safe_redirect( $url );
        exit;
    }


    /**
     * Handle the "Send test email" POST action.
     *
     * Sends a simple test message to the site admin email to confirm delivery.
     */
    private static function handle_send_test_email_request() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to perform this action.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_send_test_email', 'pmcpc_send_test_email_nonce' );

        $to = get_option( 'admin_email' );
        $to = is_string( $to ) ? sanitize_email( $to ) : '';

        $subject = sprintf(
            /* translators: %s: site name */
            __( '[%s] Product Mailer: Test email', 'product-mailer-campaigns' ),
            wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES )
        );

        $body = __( "This is a test email from FlowPress. 

If you received this, WordPress is able to send mail from your site.", 'product-mailer-campaigns' );

        $ok = false;
        $msg = '';

        if ( empty( $to ) || ! is_email( $to ) ) {
            $ok  = false;
            $msg = __( 'Admin email address is not set or is invalid.', 'product-mailer-campaigns' );
        } else {
            // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.wp_mail_wp_mail
            $ok = (bool) wp_mail( $to, $subject, $body );
            $msg = $ok
                ? sprintf( __( 'Test email sent to %s.', 'product-mailer-campaigns' ), $to )
                : __( 'wp_mail() returned false. Check your mail configuration (SMTP/plugin) and server logs.', 'product-mailer-campaigns' );
        }

        $url = add_query_arg(
            array(
                'page'              => 'pmcpc_diagnostics',
                'pmcpc_test_sent'   => 1,
                'pmcpc_test_status' => $ok ? 'ok' : 'fail',
                'pmcpc_test_msg'    => rawurlencode( $msg ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    /**
     * Run a best-effort repair of plugin tables.
     *
     * @return array{ok:bool,message:string}
     */
    private static function repair_tables() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return array( 'ok' => false, 'message' => __( 'You do not have permission to run repairs.', 'product-mailer-campaigns' ) );
        }

        if ( class_exists( 'PMCPC_Activator' ) ) {
            // This is idempotent (CREATE TABLE IF NOT EXISTS) and restores missing schema.
            PMCPC_Activator::activate();
        }

        // Re-check.
        $report = self::get_table_integrity_report();
        $missing_tables  = ! empty( $report['missing_tables'] ) ? (array) $report['missing_tables'] : array();
        $missing_columns = ! empty( $report['missing_columns'] ) ? (array) $report['missing_columns'] : array();

        if ( empty( $missing_tables ) && empty( $missing_columns ) ) {
            return array( 'ok' => true, 'message' => __( 'Self-repair completed. All tables look healthy.', 'product-mailer-campaigns' ) );
        }

        return array( 'ok' => false, 'message' => __( 'Self-repair ran, but some table issues remain. See “Database tables” details below.', 'product-mailer-campaigns' ) );
    }

    /**
     * Attempt a self-repair by re-running the plugin table creation logic.
     *
     * @return array{status:string, message:string, details:string[]}
     */
    private static function self_repair_tables() {
        $details = array();
        if ( ! class_exists( 'PMCPC_Activator' ) ) {
            return array(
                'status'  => 'fail',
                'message' => __( 'Repair failed: activator not available.', 'product-mailer-campaigns' ),
                'details' => array(),
            );
        }

        // Re-run table creation and scheduling.
        try {
            PMCPC_Activator::activate();
            $details[] = __( 'Re-ran plugin activation table creation.', 'product-mailer-campaigns' );
        } catch ( \Throwable $e ) {
            return array(
                'status'  => 'fail',
                'message' => __( 'Repair failed while creating tables.', 'product-mailer-campaigns' ),
                'details' => array( $e->getMessage() ),
            );
        }

        $report = self::get_table_integrity_report();
        if ( empty( $report['missing_tables'] ) && empty( $report['missing_columns'] ) ) {
            return array(
                'status'  => 'pass',
                'message' => __( 'Repair completed. All required tables/columns are present.', 'product-mailer-campaigns' ),
                'details' => $details,
            );
        }

        foreach ( (array) $report['missing_tables'] as $t ) {
            $details[] = sprintf( __( 'Missing table: %s', 'product-mailer-campaigns' ), $t );
        }
        foreach ( (array) $report['missing_columns'] as $t => $cols ) {
            $details[] = sprintf( __( 'Missing columns in %1$s: %2$s', 'product-mailer-campaigns' ), $t, implode( ', ', (array) $cols ) );
        }

        return array(
            'status'  => 'fail',
            'message' => __( 'Repair ran, but one or more tables/columns are still missing. This may indicate database permission limits.', 'product-mailer-campaigns' ),
            'details' => $details,
        );
    }

    /**
     * High-level setup checks for a quick "is everything configured?" view.
     *
     * @return array[]
     */
    public static function get_setup_checks() {
        $checks = array();

        // DB tables + integrity.
        $report = self::get_table_integrity_report();
        $missing_tables  = ! empty( $report['missing_tables'] ) ? (array) $report['missing_tables'] : array();
        $missing_columns = ! empty( $report['missing_columns'] ) ? (array) $report['missing_columns'] : array();

        if ( empty( $missing_tables ) && empty( $missing_columns ) ) {
            $checks['tables'] = array(
                'status'  => 'pass',
                'label'   => __( 'Database tables', 'product-mailer-campaigns' ),
                'message' => __( 'All required Product Mailer tables and columns are present.', 'product-mailer-campaigns' ),
            );
        } else {
            $status = empty( $missing_tables ) ? 'warn' : 'fail';
            $checks['tables'] = array(
                'status'  => $status,
                'label'   => __( 'Database tables', 'product-mailer-campaigns' ),
                'message' => ( 'fail' === $status )
                    ? __( 'One or more Product Mailer tables are missing. Use self-repair to recreate them.', 'product-mailer-campaigns' )
                    : __( 'Some Product Mailer table columns are missing. Use self-repair to restore the schema.', 'product-mailer-campaigns' ),
                'details' => self::format_table_integrity_details( $missing_tables, $missing_columns ),
                'can_repair' => current_user_can( 'manage_options' ),
            );
        }

        // Cron scheduling.
        $next_queue     = wp_next_scheduled( 'pmcpc_process_email_queue' );
        $next_campaigns = wp_next_scheduled( 'pmcpc_process_scheduled_campaigns' );
        $cron_ok        = ( false !== $next_queue ) && ( false !== $next_campaigns );

        if ( $cron_ok ) {
            $checks['cron'] = array(
                'status'  => 'pass',
                'label'   => __( 'WP-Cron scheduling', 'product-mailer-campaigns' ),
                'message' => __( 'Queue + scheduled campaigns tasks are scheduled.', 'product-mailer-campaigns' ),
                'meta'    => array(
                    'next_queue'     => $next_queue,
                    'next_campaigns' => $next_campaigns,
                ),
            );
        } else {
            $checks['cron'] = array(
                'status'       => 'fail',
                'label'        => __( 'WP-Cron scheduling', 'product-mailer-campaigns' ),
                'message'      => __( 'One or more Product Mailer cron tasks are not scheduled. Automated sending may not run.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Open settings', 'product-mailer-campaigns' ),
                'action_url'   => add_query_arg( array( 'page' => 'pmcpc_settings', 'tab' => 'advanced' ), admin_url( 'admin.php' ) ),
            );
        }

        // Sending pause.
        $paused = ( class_exists( 'PMCPC_Settings' ) && 'yes' === PMCPC_Settings::get( 'pause_sending', 'no' ) );
        if ( $paused ) {
            $checks['pause'] = array(
                'status'       => 'warn',
                'label'        => __( 'Sending status', 'product-mailer-campaigns' ),
                'message'      => __( 'Sending is currently paused. Queue processing will not send any emails.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Unpause sending', 'product-mailer-campaigns' ),
                'action_url'   => add_query_arg( array( 'page' => 'pmcpc_settings', 'tab' => 'email' ), admin_url( 'admin.php' ) ),
            );
        } else {
            $checks['pause'] = array(
                'status'  => 'pass',
                'label'   => __( 'Sending status', 'product-mailer-campaigns' ),
                'message' => __( 'Sending is enabled.', 'product-mailer-campaigns' ),
            );
        }

        // From identity.
        $from_name  = class_exists( 'PMCPC_Settings' ) ? trim( (string) PMCPC_Settings::get( 'from_name_default', '' ) ) : '';
        $from_email = class_exists( 'PMCPC_Settings' ) ? trim( (string) PMCPC_Settings::get( 'from_email_default', '' ) ) : '';

        if ( '' !== $from_name && '' !== $from_email && is_email( $from_email ) ) {
            $checks['from'] = array(
                'status'  => 'pass',
                'label'   => __( 'Default sender', 'product-mailer-campaigns' ),
                'message' => sprintf(
                    /* translators: 1: from name, 2: from email */
                    __( 'Default From is set to %1$s <%2$s>.', 'product-mailer-campaigns' ),
                    $from_name,
                    $from_email
                ),
            );
        } else {
            $checks['from'] = array(
                'status'       => 'warn',
                'label'        => __( 'Default sender', 'product-mailer-campaigns' ),
                'message'      => __( 'Default From Name/Email is not fully configured. New campaigns may use the site admin email.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Configure sender', 'product-mailer-campaigns' ),
                'action_url'   => add_query_arg( array( 'page' => 'pmcpc_settings', 'tab' => 'email' ), admin_url( 'admin.php' ) ),
            );
        }

        // Preferences / manage URL.
        $prefs_url = class_exists( 'PMCPC_Settings' ) ? trim( (string) PMCPC_Settings::get( 'email_prefs_url', '' ) ) : '';
        if ( '' !== $prefs_url && wp_http_validate_url( $prefs_url ) ) {
            $checks['prefs'] = array(
                'status'  => 'pass',
                'label'   => __( 'Manage Preferences URL', 'product-mailer-campaigns' ),
                'message' => __( 'The manage-preferences page URL is set.', 'product-mailer-campaigns' ),
            );
        } else {
            $checks['prefs'] = array(
                'status'       => 'warn',
                'label'        => __( 'Manage Preferences URL', 'product-mailer-campaigns' ),
                'message'      => __( 'Manage Preferences URL is not set. Preference links in emails may not work as expected.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Set URL', 'product-mailer-campaigns' ),
                'action_url'   => add_query_arg( array( 'page' => 'pmcpc_settings', 'tab' => 'email' ), admin_url( 'admin.php' ) ),
            );
        }

        // Forms presence.
        $forms = get_option( PMCPC_Forms::OPTION_KEY, array() );
        $forms_total = is_array( $forms ) ? count( $forms ) : 0;
        if ( $forms_total > 0 ) {
            $checks['forms'] = array(
                'status'  => 'pass',
                'label'   => __( 'Forms', 'product-mailer-campaigns' ),
                'message' => sprintf(
                    /* translators: %d: number of forms */
                    __( '%d form(s) configured.', 'product-mailer-campaigns' ),
                    (int) $forms_total
                ),
                'action_label' => __( 'Manage forms', 'product-mailer-campaigns' ),
                'action_url'   => admin_url( 'admin.php?page=pmcpc_forms' ),
            );
        } else {
            $checks['forms'] = array(
                'status'       => 'warn',
                'label'        => __( 'Forms', 'product-mailer-campaigns' ),
                'message'      => __( 'No forms configured yet. If you use popups/shortcodes, create at least one form.', 'product-mailer-campaigns' ),
                'action_label' => __( 'Create form', 'product-mailer-campaigns' ),
                'action_url'   => admin_url( 'admin.php?page=pmcpc_forms' ),
            );
        }



        // Email delivery (quick check + send test).
        $admin_email = get_option( 'admin_email' );
        $admin_email = is_string( $admin_email ) ? sanitize_email( $admin_email ) : '';
        $mail_status = ( ! empty( $admin_email ) && is_email( $admin_email ) ) ? 'pass' : 'warn';
        $checks['mail_test'] = array(
            'status'  => $mail_status,
            'label'   => __( 'Email delivery', 'product-mailer-campaigns' ),
            'message' => ( 'pass' === $mail_status )
                ? __( 'Send a test email to confirm WordPress can deliver mail from your site.', 'product-mailer-campaigns' )
                : __( 'Admin email address is missing/invalid. Fix this first, then send a test email.', 'product-mailer-campaigns' ),
            'action_type'  => 'form',
            'action_label' => __( 'Send test email', 'product-mailer-campaigns' ),
        );

        // Email templates (placeholder integrity).
        $tpl_warnings = array();
        $email_login_opts = get_option( 'pmcpc_email_login_options', array() );
        $double_body = isset( $email_login_opts['double_body'] ) && is_string( $email_login_opts['double_body'] ) ? $email_login_opts['double_body'] : '';
        $reset_body  = isset( $email_login_opts['reset_body'] ) && is_string( $email_login_opts['reset_body'] ) ? $email_login_opts['reset_body'] : '';

        // Only warn if a custom template is provided but the required placeholder is missing.
        if ( ! empty( trim( $double_body ) ) && false === strpos( $double_body, '{confirm_url}' ) ) {
            $tpl_warnings[] = __( 'Double opt-in email is missing {confirm_url}.', 'product-mailer-campaigns' );
        }
        if ( ! empty( trim( $reset_body ) ) && false === strpos( $reset_body, '{reset_url}' ) ) {
            $tpl_warnings[] = __( 'Password reset email is missing {reset_url}.', 'product-mailer-campaigns' );
        }

        $checks['templates'] = array(
            'status'       => empty( $tpl_warnings ) ? 'pass' : 'warn',
            'label'        => __( 'Email templates', 'product-mailer-campaigns' ),
            'message'      => empty( $tpl_warnings )
                ? __( 'Email templates look OK (required placeholders present).', 'product-mailer-campaigns' )
                : __( 'One or more email templates may not work as expected.', 'product-mailer-campaigns' ),
            'details'      => $tpl_warnings,
            'action_label' => __( 'Review templates', 'product-mailer-campaigns' ),
            'action_url'   => admin_url( 'admin.php?page=pmcpc-email-login-settings' ),
        );

        // Queue health (stuck/past-due items).
        global $wpdb;
        $queue_table = $wpdb->prefix . 'pmcpc_email_queue';
        $queue_exists = ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $queue_table ) ) === $queue_table );
        if ( $queue_exists ) {
            $pending = (int) $wpdb->get_var( "SELECT COUNT(1) FROM {$queue_table} WHERE status='pending'" );
            $failed  = (int) $wpdb->get_var( "SELECT COUNT(1) FROM {$queue_table} WHERE status='failed'" );
            // Oldest scheduled item that is already due.
            $oldest_due = $wpdb->get_var( "SELECT MIN(scheduled_at) FROM {$queue_table} WHERE status='pending' AND scheduled_at <= NOW()" );

            $q_details = array();
            $q_status  = 'pass';
            if ( $failed > 0 ) {
                $q_status    = 'warn';
                $q_details[] = sprintf(
                    /* translators: %d: number of failed queued emails. */
                    __( '%d queued email(s) are marked as failed.', 'product-mailer-campaigns' ),
                    (int) $failed
                );
            }

            // Past-due pending items usually indicate cron not running or a mail failure loop.
            if ( $pending > 0 && ! empty( $oldest_due ) ) {
                $due_ts = strtotime( (string) $oldest_due );
                if ( $due_ts && ( time() - $due_ts ) > 15 * MINUTE_IN_SECONDS ) {
                    $q_status    = 'warn';
                    $q_details[] = __( 'There are pending emails past their scheduled send time. This usually means WP-Cron is not running reliably.', 'product-mailer-campaigns' );
                }
            }

            $checks['queue'] = array(
                'status'       => $q_status,
                'label'        => __( 'Queue health', 'product-mailer-campaigns' ),
                'message'      => ( 'warn' === $q_status )
                    ? __( 'Queue needs attention.', 'product-mailer-campaigns' )
                    : __( 'No stuck or past-due queue items detected.', 'product-mailer-campaigns' ),
                'details'      => $q_details,
                'action_label' => __( 'View queue', 'product-mailer-campaigns' ),
                'action_url'   => admin_url( 'admin.php?page=pmcpc_queue' ),
            );
        }

        $system_errors = self::get_recent_system_errors();
        if ( ! empty( $system_errors ) ) {
            $latest_error = reset( $system_errors );
            $checks['system_errors'] = array(
                'status'       => 'warn',
                'label'        => __( 'Plugin error log', 'product-mailer-campaigns' ),
                'message'      => sprintf(
                    /* translators: 1: number of logged errors, 2: latest error channel */
                    __( '%1$d recent plugin error(s) were recorded. Latest channel: %2$s.', 'product-mailer-campaigns' ),
                    count( $system_errors ),
                    isset( $latest_error['h'] ) ? (string) $latest_error['h'] : __( 'general', 'product-mailer-campaigns' )
                ),
                'details'      => self::get_recent_system_error_lines( $system_errors ),
                'action_label' => __( 'Review details', 'product-mailer-campaigns' ),
                'action_url'   => add_query_arg( array( 'page' => 'pmcpc_diagnostics', 'pmcpc_show_all' => '1' ), admin_url( 'admin.php' ) ) . '#pmcpc-system-log',
            );
        } else {
            $checks['system_errors'] = array(
                'status'  => 'pass',
                'label'   => __( 'Plugin error log', 'product-mailer-campaigns' ),
                'message' => __( 'No recent plugin errors have been recorded.', 'product-mailer-campaigns' ),
            );
        }

        // Tracking / logs.
        $tracking = ( class_exists( 'PMCPC_Settings' ) && 'yes' === PMCPC_Settings::get( 'tracking_debug', 'no' ) ) ? 'on' : 'off';
        $checks['tracking'] = array(
            'status'  => 'pass',
            'label'   => __( 'Tracking logs', 'product-mailer-campaigns' ),
            'message' => ( 'on' === $tracking )
                ? __( 'Tracking logs are enabled (useful for troubleshooting).', 'product-mailer-campaigns' )
                : __( 'Tracking logs are disabled (recommended unless debugging).', 'product-mailer-campaigns' ),
            'action_label' => __( 'Tracking settings', 'product-mailer-campaigns' ),
            'action_url'   => add_query_arg( array( 'page' => 'pmcpc_settings', 'tab' => 'advanced' ), admin_url( 'admin.php' ) ),
        );
        // WooCommerce.
        if ( class_exists( 'WooCommerce' ) ) {
            $checks['wc'] = array(
                'status'  => 'pass',
                'label'   => __( 'WooCommerce', 'product-mailer-campaigns' ),
                'message' => __( 'WooCommerce is active (product blocks and customer tagging enabled).', 'product-mailer-campaigns' ),
            );
        } else {
            $checks['wc'] = array(
                'status'  => 'warn',
                'label'   => __( 'WooCommerce', 'product-mailer-campaigns' ),
                'message' => __( 'WooCommerce is not active. Product blocks and customer tagging features may be limited.', 'product-mailer-campaigns' ),
            );
        }

        return $checks;
    }

    /**
     * Return recent plugin error log items.
     *
     * @return array
     */
    private static function get_recent_system_errors() {
        if ( ! class_exists( 'PMCPC_Logger' ) ) {
            return array();
        }

        $items = PMCPC_Logger::get_items( 5 );
        return is_array( $items ) ? $items : array();
    }

    /**
     * Build compact error lines for the setup overview card.
     *
     * @param array $items Error log items.
     * @return array
     */
    private static function get_recent_system_error_lines( $items ) {
        $lines = array();

        foreach ( (array) $items as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }

            $channel = isset( $item['h'] ) && '' !== (string) $item['h'] ? (string) $item['h'] : __( 'general', 'product-mailer-campaigns' );
            $message = isset( $item['m'] ) ? (string) $item['m'] : '';
            if ( '' === $message ) {
                continue;
            }

            $lines[] = sprintf( '[%1$s] %2$s', $channel, $message );
        }

        return $lines;
    }

    /**
     * Render a compact setup overview section.
     */
    private static function render_setup_overview() {
        $checks = self::get_setup_checks();
        if ( empty( $checks ) ) {
            return;
        }

        // Diagnostics is primarily an error checker. By default, hide "all-good" cards
        // except for the core system checks (DB/Cron/Sending).
        $show_all = ( isset( $_GET['pmcpc_show_all'] ) && '1' === (string) $_GET['pmcpc_show_all'] );
        $essential_keys = array( 'db_tables', 'cron', 'sending' );

        // Derive an overall status.
        $overall = 'pass';
        foreach ( $checks as $check ) {
            if ( isset( $check['status'] ) && 'fail' === $check['status'] ) {
                $overall = 'fail';
                break;
            }
            if ( isset( $check['status'] ) && 'warn' === $check['status'] ) {
                $overall = ( 'fail' === $overall ) ? 'fail' : 'warn';
            }
        }

        $overall_label = ( 'fail' === $overall )
            ? __( 'Action needed', 'product-mailer-campaigns' )
            : ( ( 'warn' === $overall ) ? __( 'Review recommended', 'product-mailer-campaigns' ) : __( 'All good', 'product-mailer-campaigns' ) );

        $overall_msg = ( 'fail' === $overall )
            ? __( 'One or more core requirements are not met. Fix the items below to restore automated sending and admin tools.', 'product-mailer-campaigns' )
            : ( ( 'warn' === $overall ) ? __( 'Core functions work, but a few items could be configured to improve deliverability and usability.', 'product-mailer-campaigns' ) : __( 'Everything important looks configured correctly.', 'product-mailer-campaigns' ) );

        // Use full admin content width (no fixed max-width) so cards fill the page.
        echo '<div class="pmcpc-setup-overview" style="width:100%; margin:12px 0 18px;">';

        $bar_color = ( 'fail' === $overall ) ? '#dc3232' : ( ( 'warn' === $overall ) ? '#ffb900' : '#46b450' );
        echo '<div style="background:#fff; border:1px solid #ccd0d4; border-left:4px solid ' . esc_attr( $bar_color ) . '; border-radius:6px; padding:12px 14px;">';
        echo '<div style="display:flex; align-items:center; justify-content:space-between; gap:12px;">';
        echo '<strong>' . esc_html__( 'Setup overview', 'product-mailer-campaigns' ) . '</strong>';
        $toggle_url = add_query_arg(
            array(
                'page' => 'pmcpc_diagnostics',
                'pmcpc_show_all' => $show_all ? '0' : '1',
            ),
            admin_url( 'admin.php' )
        );
        echo '<a href="' . esc_url( $toggle_url ) . '" class="button button-small" style="white-space:nowrap;">' . esc_html( $show_all ? __( 'Show only issues', 'product-mailer-campaigns' ) : __( 'Show all checks', 'product-mailer-campaigns' ) ) . '</a>';
        echo '</div>';
        echo '<div style="margin-top:6px;">';
        echo '<span style="font-weight:600;">' . esc_html__( 'Status:', 'product-mailer-campaigns' ) . '</span> ' . esc_html( $overall_label );
        echo '<div style="margin-top:6px;">' . esc_html( $overall_msg ) . '</div>';
        echo '</div>';
        echo '</div>';

        echo '<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); gap:12px; margin-top:12px;">';
        foreach ( $checks as $key => $check ) {
            $status = isset( $check['status'] ) ? (string) $check['status'] : 'unknown';

            if ( ! $show_all && 'pass' === $status && ! in_array( (string) $key, $essential_keys, true ) ) {
                continue;
            }

            $label  = isset( $check['label'] ) ? (string) $check['label'] : (string) $key;
            $msg    = isset( $check['message'] ) ? (string) $check['message'] : '';

            $badge_bg = ( 'fail' === $status ) ? '#dc3232' : ( ( 'warn' === $status ) ? '#ffb900' : '#46b450' );
            $badge_fg = ( 'warn' === $status ) ? '#222' : '#fff';
            $badge_tx = ( 'fail' === $status ) ? __( 'Fail', 'product-mailer-campaigns' ) : ( ( 'warn' === $status ) ? __( 'Warning', 'product-mailer-campaigns' ) : __( 'OK', 'product-mailer-campaigns' ) );

            echo '<div style="background:#fff; border:1px solid #ccd0d4; border-radius:6px; padding:10px 12px;">';
            echo '<div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">';
            echo '<div style="font-weight:600;">' . esc_html( $label ) . '</div>';
            echo '<span style="display:inline-block; padding:2px 8px; border-radius:999px; background:' . esc_attr( $badge_bg ) . '; color:' . esc_attr( $badge_fg ) . '; font-size:12px;">' . esc_html( $badge_tx ) . '</span>';
            echo '</div>';
            if ( $msg ) {
                echo '<div style="margin-top:6px; color:#50575e;">' . esc_html( $msg ) . '</div>';
            }

            if ( ! empty( $check['meta'] ) && is_array( $check['meta'] ) && ( $show_all || 'pass' !== $status ) ) {
                if ( isset( $check['meta']['next_queue'] ) && $check['meta']['next_queue'] ) {
                    echo '<div style="margin-top:6px; font-size:12px; color:#646970;">' . esc_html__( 'Next queue run:', 'product-mailer-campaigns' ) . ' ' . esc_html( wp_date( 'Y-m-d H:i:s', (int) $check['meta']['next_queue'] ) ) . '</div>';
                }
                if ( isset( $check['meta']['next_campaigns'] ) && $check['meta']['next_campaigns'] ) {
                    echo '<div style="font-size:12px; color:#646970;">' . esc_html__( 'Next campaigns run:', 'product-mailer-campaigns' ) . ' ' . esc_html( wp_date( 'Y-m-d H:i:s', (int) $check['meta']['next_campaigns'] ) ) . '</div>';
                }

                // Generic meta lines (for additional setup cards).
                $lines = array();
                if ( isset( $check['meta']['lines'] ) && is_array( $check['meta']['lines'] ) ) {
                    $lines = $check['meta']['lines'];
                } else {
                    if ( isset( $check['meta']['pending'] ) ) {
                        $lines[] = sprintf( __( 'Queue pending: %d', 'product-mailer-campaigns' ), (int) $check['meta']['pending'] );
                    }
                    if ( isset( $check['meta']['failed'] ) ) {
                        $lines[] = sprintf( __( 'Queue failed: %d', 'product-mailer-campaigns' ), (int) $check['meta']['failed'] );
                    }
                    if ( ! empty( $check['meta']['oldest_pending'] ) ) {
                        $lines[] = sprintf( __( 'Oldest pending: %s', 'product-mailer-campaigns' ), (string) $check['meta']['oldest_pending'] );
                    }
                }

                foreach ( $lines as $line ) {
                    echo '<div style="margin-top:6px; font-size:12px; color:#646970;">' . esc_html( $line ) . '</div>';
                }
            }

            if ( ! empty( $check['details'] ) && is_array( $check['details'] ) ) {
                echo '<details style="margin-top:6px;">';
                echo '<summary style="cursor:pointer;">' . esc_html__( 'Details', 'product-mailer-campaigns' ) . '</summary>';
                echo '<ul style="margin:6px 0 0 18px; list-style:disc;">';
                foreach ( $check['details'] as $d ) {
                    echo '<li>' . esc_html( $d ) . '</li>';
                }
                echo '</ul>';
                echo '</details>';
            }

            if ( ! empty( $check['action_url'] ) && ! empty( $check['action_label'] ) ) {
                echo '<div style="margin-top:10px;">';
                echo '<a class="button button-small" href="' . esc_url( $check['action_url'] ) . '">' . esc_html( $check['action_label'] ) . '</a>';
                echo '</div>';
            }

            // Send a quick delivery test email.
            if ( 'mail_test' === $key ) {
                echo '<div style="margin-top:10px;">';
                echo '<form method="post" style="display:inline;">';
                wp_nonce_field( 'pmcpc_send_test_email', 'pmcpc_send_test_email_nonce' );
                echo '<input type="hidden" name="pmcpc_send_test_email" value="1" />';
                echo '<button type="submit" class="button button-primary button-small">' . esc_html__( 'Send test email', 'product-mailer-campaigns' ) . '</button>';
                echo '</form>';
                echo '</div>';
            }

            // Self-repair action (tables + schema).
            if ( 'tables' === $key && ! empty( $check['can_repair'] ) && 'pass' !== $status ) {
                echo '<div style="margin-top:10px;">';
                echo '<form method="post" style="display:inline;">';
                wp_nonce_field( 'pmcpc_repair_tables', 'pmcpc_repair_tables_nonce' );
                echo '<input type="hidden" name="pmcpc_repair_tables" value="1" />';
                echo '<button type="submit" class="button button-primary button-small">' . esc_html__( 'Self-repair (recreate tables)', 'product-mailer-campaigns' ) . '</button>';
                echo '</form>';
                echo '</div>';
            }
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';
    }

    /**
     * Return a list of diagnostic tests.
     *
     * Each test is an array with:
     * - label    Human-readable name.
     * - callback Callable returning an array with 'status', 'message', and optional 'details'.
     * - group    Logical group (e.g. 'segments', 'queue').
     *
     * @return array
     */
    public static function get_tests() {
        $tests = array();

        // Segments / Pro integration tests.
        $tests['segments_overview_runs'] = array(
            'label'    => __( 'Segments: overview calculation (Commerce)', 'product-mailer-campaigns' ),
            'callback' => array( __CLASS__, 'test_segments_overview_runs' ),
            'group'    => 'segments',
        );

        $tests['segments_samples_consistent'] = array(
            'label'    => __( 'Segments: examples match segment counts (Commerce)', 'product-mailer-campaigns' ),
            'callback' => array( __CLASS__, 'test_segments_samples_consistent' ),
            'group'    => 'segments',
        );

        $tests['campaign_admin_audience'] = array(
            'label'    => __( 'Campaigns: admin subscriber matches tags/segments (dry run)', 'product-mailer-campaigns' ),
            'callback' => array( __CLASS__, 'test_campaign_admin_audience' ),
            'group'    => 'campaigns',
        );
$tests['campaign_trigger_segment_combos'] = array(
    'label'    => __( 'Campaigns: trigger vs segment combinations', 'product-mailer-campaigns' ),
    'callback' => array( __CLASS__, 'test_campaign_trigger_segment_combos' ),
    'group'    => 'campaigns',
);

        return $tests;
    }

    /**
     * Render a standard admin notice.
     *
     * @param string $type    Notice type.
     * @param string $message Notice message.
     * @param bool   $dismissible Whether the notice is dismissible.
     * @return void
     */
    private static function render_admin_notice( $type, $message, $dismissible = false ) {
        $classes = array( 'notice', 'notice-' . sanitize_html_class( $type ) );

        if ( $dismissible ) {
            $classes[] = 'is-dismissible';
        }

        echo '<div class="' . esc_attr( implode( ' ', $classes ) ) . '"><p>' . esc_html( $message ) . '</p></div>';
    }

    /**
     * Render redirect-based diagnostics notices.
     *
     * @return void
     */
    private static function render_result_notices() {
        if ( isset( $_GET['pmcpc_repaired'] ) ) {
            $status = isset( $_GET['pmcpc_repair_status'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_repair_status'] ) ) : '';

            if ( 'ok' === $status ) {
                self::render_admin_notice( 'success', __( 'Self-repair completed. Tables and schema were checked.', 'product-mailer-campaigns' ), true );
            } elseif ( 'fail' === $status ) {
                self::render_admin_notice( 'error', __( 'Self-repair ran, but some database issues remain. See the Database tables card for details.', 'product-mailer-campaigns' ) );
            }
        }

        if ( isset( $_GET['pmcpc_test_sent'] ) ) {
            $status = isset( $_GET['pmcpc_test_status'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_test_status'] ) ) : '';
            $msg    = isset( $_GET['pmcpc_test_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['pmcpc_test_msg'] ) ) : '';

            if ( empty( $msg ) ) {
                $msg = ( 'ok' === $status )
                    ? __( 'Test email sent.', 'product-mailer-campaigns' )
                    : __( 'Test email could not be sent. Check your mail configuration.', 'product-mailer-campaigns' );
            }

            self::render_admin_notice( 'ok' === $status ? 'success' : 'error', $msg, 'ok' === $status );
        }
    }

    /**
     * Render the diagnostics summary card.
     *
     * @param int   $total  Total number of tests.
     * @param array $counts Status counts.
     * @return void
     */
    private static function render_summary_card( $total, $counts ) {
        echo '<div class="pmcpc-diag-summary" style="padding:14px 16px; margin:0 0 16px; background:#fff; border:1px solid #dcdcde; border-radius:10px; box-sizing:border-box;">';
        echo '<strong>' . esc_html__( 'Summary', 'product-mailer-campaigns' ) . '</strong>';
        echo '<div style="margin-top:8px; display:flex; gap:10px; flex-wrap:wrap;">';
        /* translators: %d: number of tests run. */
        echo '<span>' . sprintf( esc_html__( 'Tests run: %d', 'product-mailer-campaigns' ), (int) $total ) . '</span>';
        /* translators: %d: number of passing tests. */
        echo '<span class="pmcpc-status-pass" style="padding:2px 8px; border-radius:999px;">' . sprintf( esc_html__( 'Passed: %d', 'product-mailer-campaigns' ), (int) $counts['pass'] ) . '</span>';
        /* translators: %d: number of warning tests. */
        echo '<span class="pmcpc-status-warn" style="padding:2px 8px; border-radius:999px;">' . sprintf( esc_html__( 'Warnings: %d', 'product-mailer-campaigns' ), (int) $counts['warn'] ) . '</span>';
        /* translators: %d: number of failing tests. */
        echo '<span class="pmcpc-status-fail" style="padding:2px 8px; border-radius:999px;">' . sprintf( esc_html__( 'Failed: %d', 'product-mailer-campaigns' ), (int) $counts['fail'] ) . '</span>';
        echo '</div>';
        echo '</div>';
    }

    /**
     * Normalize a diagnostics status into label/class data.
     *
     * @param string $status Raw status value.
     * @return array{label:string,class:string}
     */
    private static function get_status_badge_data( $status ) {
        $status = (string) $status;

        if ( 'pass' === $status ) {
            return array(
                'label' => __( 'Pass', 'product-mailer-campaigns' ),
                'class' => 'pmcpc-status-pass',
            );
        }

        if ( 'fail' === $status ) {
            return array(
                'label' => __( 'Fail', 'product-mailer-campaigns' ),
                'class' => 'pmcpc-status-fail',
            );
        }

        if ( 'warn' === $status || 'warning' === $status ) {
            return array(
                'label' => __( 'Warning', 'product-mailer-campaigns' ),
                'class' => 'pmcpc-status-warn',
            );
        }

        return array(
            'label' => __( 'Unknown', 'product-mailer-campaigns' ),
            'class' => 'pmcpc-status-unknown',
        );
    }

    /**
     * Render a diagnostics details list.
     *
     * @param array $details Detail lines.
     * @return void
     */
    private static function render_result_details( $details ) {
        if ( empty( $details ) ) {
            return;
        }

        $details_count = count( $details );

        // Keep the page scannable: long detail lists are collapsed behind a toggle.
        if ( $details_count > 6 ) {
            echo '<details class="pmcpc-diag-details" style="margin-top:6px;">';
            echo '<summary style="cursor:pointer;">' . sprintf(
                /* translators: %d: number of detail lines. */
                esc_html__( 'Show list (%d)', 'product-mailer-campaigns' ),
                (int) $details_count
            ) . '</summary>';
            echo '<ul class="pmcpc-diagnostics-details" style="margin-top:6px;">';
            foreach ( $details as $detail ) {
                echo '<li>' . esc_html( $detail ) . '</li>';
            }
            echo '</ul>';
            echo '</details>';
            return;
        }

        echo '<ul class="pmcpc-diagnostics-details">';
        foreach ( $details as $detail ) {
            echo '<li>' . esc_html( $detail ) . '</li>';
        }
        echo '</ul>';
    }

    /**
     * Render the diagnostics results table.
     *
     * @param array $tests   Registered tests.
     * @param array $results Test results keyed by test ID.
     * @return void
     */
    private static function render_results_table( $tests, $results ) {
        echo '<table class="widefat striped" style="width:100%;">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__( 'Test', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Group', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Details', 'product-mailer-campaigns' ) . '</th>';
        echo '</tr></thead><tbody>';

        foreach ( $tests as $key => $test ) {
            $label   = isset( $test['label'] ) ? $test['label'] : $key;
            $group   = isset( $test['group'] ) ? $test['group'] : '';
            $result  = isset( $results[ $key ] ) ? $results[ $key ] : array();
            $status  = isset( $result['status'] ) ? (string) $result['status'] : 'unknown';
            $message = isset( $result['message'] ) ? (string) $result['message'] : '';
            $details = ( ! empty( $result['details'] ) && is_array( $result['details'] ) ) ? $result['details'] : array();
            $badge   = self::get_status_badge_data( $status );

            echo '<tr>';
            echo '<td>' . esc_html( $label ) . '</td>';
            echo '<td>' . esc_html( $group ) . '</td>';
            echo '<td><span class="' . esc_attr( $badge['class'] ) . '">' . esc_html( $badge['label'] ) . '</span></td>';
            echo '<td>';

            if ( $message ) {
                echo '<p style="margin:0 0 6px;">' . esc_html( $message ) . '</p>';
            }

            self::render_result_details( $details );

            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    /**
     * Register diagnostics inline styles.
     *
     * @return void
     */
    private static function register_inline_styles() {
        wp_add_inline_style(
            'pmcpc-admin-inline',
            '.pmcpc-status-pass { display:inline-block; padding:2px 6px; border-radius:3px; background:#46b450; color:#fff; }
            .pmcpc-status-fail { display:inline-block; padding:2px 6px; border-radius:3px; background:#dc3232; color:#fff; }
            .pmcpc-status-warn { display:inline-block; padding:2px 6px; border-radius:3px; background:#ffb900; color:#222; }
            .pmcpc-status-unknown { display:inline-block; padding:2px 6px; border-radius:3px; background:#ccd0d4; color:#444; }
            .pmcpc-diagnostics-details { margin:4px 0 0 16px; list-style:disc; }'
        );
    }

    /**
     * Format system-log context values into detail lines.
     *
     * @param array $context Log context array.
     * @return array
     */
    private static function get_system_log_context_lines( $context ) {
        $context_lines = array();

        foreach ( $context as $key => $value ) {
            $context_lines[] = sprintf( '%1$s: %2$s', sanitize_key( (string) $key ), (string) $value );
        }

        return $context_lines;
    }

    /**
     * Render system-log context markup for a row.
     *
     * @param array $context Log context array.
     * @return void
     */
    private static function render_system_log_context( $context ) {
        if ( empty( $context ) ) {
            echo '&mdash;';
            return;
        }

        self::render_result_details( self::get_system_log_context_lines( $context ) );
    }

    /**
     * Render a single system-log row.
     *
     * @param array $row Log row payload.
     * @return void
     */
    private static function render_system_log_row( $row ) {
        $timestamp = isset( $row['t'] ) ? absint( $row['t'] ) : 0;
        $channel   = isset( $row['h'] ) ? (string) $row['h'] : '';
        $message   = isset( $row['m'] ) ? (string) $row['m'] : '';
        $context   = isset( $row['c'] ) && is_array( $row['c'] ) ? $row['c'] : array();

        echo '<tr>';
        echo '<td>' . esc_html( $timestamp ? wp_date( 'Y-m-d H:i:s', $timestamp ) : '' ) . '</td>';
        echo '<td>' . esc_html( '' !== $channel ? $channel : __( 'general', 'product-mailer-campaigns' ) ) . '</td>';
        echo '<td>' . esc_html( $message ) . '</td>';
        echo '<td>';
        self::render_system_log_context( $context );
        echo '</td>';
        echo '</tr>';
    }

    /**
     * Execute registered diagnostics tests and count their outcomes.
     *
     * @param array $tests Registered diagnostics tests.
     * @return array{results:array,counts:array<string,int>,total:int}
     */
    private static function run_tests( $tests ) {
        $results = array();
        $counts  = array(
            'pass'    => 0,
            'warn'    => 0,
            'fail'    => 0,
            'unknown' => 0,
        );

        foreach ( $tests as $key => $test ) {
            $result = array(
                'status'  => 'unknown',
                'message' => '',
                'details' => array(),
            );

            if ( is_callable( $test['callback'] ) ) {
                try {
                    $res = call_user_func( $test['callback'] );
                    if ( is_array( $res ) ) {
                        $result = array_merge( $result, $res );
                    }
                } catch ( \Throwable $e ) {
                    $result['status']  = 'fail';
                    $result['message'] = $e->getMessage();
                }
            } else {
                $result['status']  = 'fail';
                $result['message'] = __( 'Callback is not callable.', 'product-mailer-campaigns' );
            }

            $status = isset( $result['status'] ) ? (string) $result['status'] : 'unknown';
            if ( ! isset( $counts[ $status ] ) ) {
                $status = 'unknown';
            }

            $counts[ $status ]++;
            $results[ $key ] = $result;
        }

        return array(
            'results' => $results,
            'counts'  => $counts,
            'total'   => count( $tests ),
        );
    }

    /**
     * Render the Diagnostics admin page.
     */
    public static function render_page() {
        // Handle "send test email" action (setup card).
        if ( isset( $_POST["pmcpc_send_test_email"] ) ) {
            self::handle_send_test_email_request();
        }

        // Handle self-repair action.
        if ( isset( $_POST['pmcpc_repair_tables'] ) ) {
            self::handle_repair_tables_request();
        }

        self::render_result_notices();

        $tests = self::get_tests();

        // High-level overview (with links to fix common setup issues).
        if ( empty( $tests ) ) {
            if ( class_exists( 'PMCPC_Admin' ) ) {
                PMCPC_Admin::render_page_intro(
                    __( 'Check setup, sending, and recoverable errors', 'product-mailer-campaigns' ),
                    __( 'Run these checks to confirm your FlowPress setup is healthy and to find the next fix when something is wrong.', 'product-mailer-campaigns' ),
                    array(
                        array(
                            'label' => __( 'Health checks', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-chart-pie',
                        ),
                        array(
                            'label' => __( 'Sending and database checks', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-admin-tools',
                        ),
                        array(
                            'label' => __( 'Recent errors', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-warning',
                        ),
                    )
                );
            }
            echo '<p>' . esc_html__( 'No health checks are registered.', 'product-mailer-campaigns' ) . '</p>';
            return;
        }

        $test_run = self::run_tests( $tests );

        if ( class_exists( 'PMCPC_Admin' ) ) {
            PMCPC_Admin::render_page_intro(
                __( 'Check setup, sending, and recoverable errors', 'product-mailer-campaigns' ),
                __( 'Run these checks to confirm your FlowPress setup is healthy and to find the next fix when something is wrong.', 'product-mailer-campaigns' ),
                array(
                    array(
                        'label' => __( 'Health checks', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-chart-pie',
                    ),
                    array(
                        'label' => __( 'Sending and database checks', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-admin-tools',
                    ),
                    array(
                        'label' => __( 'Recent errors', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-warning',
                    ),
                )
            );
            PMCPC_Admin::render_support_panels(
                array(
                    array(
                        'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-editor-help',
                        'title'   => __( 'Work from top to bottom', 'product-mailer-campaigns' ),
                        'items'   => array(
                            __( 'Read the warnings before changing anything.', 'product-mailer-campaigns' ),
                            __( 'Fix the first failing item, then run the checks again.', 'product-mailer-campaigns' ),
                            __( 'Use logs only after the quick checks point you there.', 'product-mailer-campaigns' ),
                        ),
                    ),
                    array(
                        'eyebrow' => __( 'Useful shortcuts', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-admin-tools',
                        'title'   => __( 'Move straight to related tools', 'product-mailer-campaigns' ),
                        'actions' => array(
                            array( 'label' => __( 'Open Settings', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_settings' ), 'class' => 'button' ),
                            array( 'label' => __( 'Open Waiting to Send', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=queue' ), 'class' => 'button' ),
                        ),
                    ),
                )
            );
            PMCPC_Admin::render_stats_strip(
                array(
                    array(
                        'label' => __( 'Tests run', 'product-mailer-campaigns' ),
                        'value' => (string) (int) $test_run['total'],
                        'meta'  => __( 'Registered health checks', 'product-mailer-campaigns' ),
                    ),
                    array(
                        'label' => __( 'Passed', 'product-mailer-campaigns' ),
                        'value' => (string) (int) $test_run['counts']['pass'],
                        'meta'  => __( 'Healthy checks', 'product-mailer-campaigns' ),
                    ),
                    array(
                        'label' => __( 'Warnings', 'product-mailer-campaigns' ),
                        'value' => (string) (int) $test_run['counts']['warn'],
                        'meta'  => __( 'Needs review soon', 'product-mailer-campaigns' ),
                    ),
                    array(
                        'label' => __( 'Failed', 'product-mailer-campaigns' ),
                        'value' => (string) (int) $test_run['counts']['fail'],
                        'meta'  => __( 'Action needed', 'product-mailer-campaigns' ),
                    ),
                )
            );
        }

        echo '<div class="pmcpc-card" style="margin:0 0 18px;">';
        self::render_setup_overview();
        echo '</div>';

        echo '<div class="pmcpc-card" style="margin:0 0 18px;">';
        self::render_summary_card( $test_run['total'], $test_run['counts'] );
        echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
        self::render_results_table( $tests, $test_run['results'] );
        echo '</div></div>';
        echo '</div>';

        self::register_inline_styles();

        // Optional tracking debug log output.
        if ( class_exists( 'PMCPC_Settings' ) && 'yes' === PMCPC_Settings::get( 'tracking_debug', 'no' ) ) {
            self::render_tracking_log_excerpt();
        }

        if ( ! empty( self::get_recent_system_errors() ) ) {
            self::render_system_log_excerpt();
        }
    }

    /**
     * Show recent plugin errors captured by the shared logger.
     *
     * @return void
     */
    protected static function render_system_log_excerpt() {
        $rows = self::get_recent_system_errors();
        if ( empty( $rows ) ) {
            return;
        }

        echo '<div class="pmcpc-card" style="margin:0 0 18px;">';
        echo '<h2 id="pmcpc-system-log">' . esc_html__( 'Recent errors', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p class="description">' . esc_html__( 'These are recoverable plugin-side errors captured during queue, automation, and admin operations.', 'product-mailer-campaigns' ) . '</p>';
        echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
        echo '<table class="widefat striped pmcpc-wide-table">';
        echo '<thead><tr>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Time', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Channel', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Message', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-meta">' . esc_html__( 'Context', 'product-mailer-campaigns' ) . '</th>';
        echo '</tr></thead><tbody>';

        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            self::render_system_log_row( $row );
        }

        echo '</tbody></table>';
        echo '</div></div>';
        echo '</div>';
    }


    /**
     * Show the last few tracking hits (opens/clicks/views) to troubleshoot "0 opens" issues.
     */
    protected static function render_tracking_log_excerpt() {
        global $wpdb;
		// Internal plugin table name (not user input).
		$logs_table = $wpdb->prefix . 'pmcpc_email_event_logs';


// Table name is internal plugin constant (not user input).
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $logs_table ) );
if ( $exists !== $logs_table ) {
	return;
}

// Diagnostic query; table name is plugin-controlled.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
$rows = $wpdb->get_results(
	$wpdb->prepare(
		"SELECT id, queue_id, event_type, created_at, is_bot, is_proxy, user_agent
		 FROM {$logs_table}
		 ORDER BY id DESC
		 LIMIT %d",
		50
	),
	ARRAY_A
);
// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
echo '<div class="pmcpc-card" style="margin:0 0 18px;">';
echo '<h2 style="margin-top:0;">' . esc_html__( 'Recent tracking hits (debug)', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p class="description">' . esc_html__( 'This is only shown when Tracking debug logging is enabled in Settings.', 'product-mailer-campaigns' ) . '</p>';

        if ( empty( $rows ) ) {
            echo '<p>' . esc_html__( 'No tracking hits logged yet.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            return;
        }

        echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
        echo '<table class="widefat striped pmcpc-wide-table">';
        echo '<thead><tr>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Time', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Queue ID', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Event', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Bot?', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Proxy?', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-anchor">' . esc_html__( 'User agent', 'product-mailer-campaigns' ) . '</th>';
        echo '</tr></thead><tbody>';

        foreach ( $rows as $r ) {
            echo '<tr>';
            echo '<td>' . esc_html( $r['created_at'] ) . '</td>';
            echo '<td>' . esc_html( $r['queue_id'] ) . '</td>';
            echo '<td>' . esc_html( $r['event_type'] ) . '</td>';
            echo '<td>' . ( ! empty( $r['is_bot'] ) ? esc_html__( 'Yes', 'product-mailer-campaigns' ) : esc_html__( 'No', 'product-mailer-campaigns' ) ) . '</td>';
            echo '<td>' . ( ! empty( $r['is_proxy'] ) ? esc_html__( 'Yes', 'product-mailer-campaigns' ) : esc_html__( 'No', 'product-mailer-campaigns' ) ) . '</td>';
            echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $r['user_agent'] ) . '</span></div></td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div></div>';
        echo '</div>';
    }

    /**
     * Simple smoke test: can we calculate the Pro segments overview without errors?
     *
     * This does NOT deeply validate the contents; it just ensures that:
     * - Pro is active, and
     * - PMCPC_Pro_Bootstrap::get_segments_overview_for_debug() returns an array.
     *
     * @return array
     */
    public static function test_segments_overview_runs() {
        // If Pro class is missing, skip gracefully.
        if ( ! pmcpc_is_pro_active() ) {
            return array(
                'status'  => 'pass',
                'message' => __( 'Commerce is not active; segments overview test skipped.', 'product-mailer-campaigns' ),
            );
        }

        // Pro appears active but the bootstrap class is not loaded (load order / autoload mismatch).
        if ( ! class_exists( 'PMCPC_Pro_Bootstrap' ) ) {
            return array(
                'status'  => 'fail',
                'message' => __( 'Commerce appears active, but its bootstrap class could not be found. Try re-saving permalinks or re-uploading the Commerce add-on.', 'product-mailer-campaigns' ),
            );
        }

        // Get Pro instance (adjust if singleton uses a different method).
        if ( method_exists( 'PMCPC_Pro_Bootstrap', 'instance' ) ) {
            $pro = PMCPC_Pro_Bootstrap::instance();
        } else {
            $pro = new PMCPC_Pro_Bootstrap();
        }

        if ( ! method_exists( $pro, 'get_segments_overview_for_debug' ) ) {
            return array(
                'status'  => 'fail',
                'message' => __( 'PMCPC_Pro_Bootstrap::get_segments_overview_for_debug() is missing.', 'product-mailer-campaigns' ),
            );
        }

        try {
            $segments = $pro->get_segments_overview_for_debug();
        } catch ( \Throwable $e ) {
            return array(
                'status'  => 'fail',
	                'message' => sprintf(
	                    /* translators: %s: error message. */
	                    __( 'Error while calculating segments overview: %s', 'product-mailer-campaigns' ),
	                    $e->getMessage()
	                ),
            );
        }

        if ( ! is_array( $segments ) || empty( $segments ) ) {
            return array(
                'status'  => 'fail',
                'message' => __( 'Segments overview is empty or not an array.', 'product-mailer-campaigns' ),
            );
        }

        $keys_count = count( $segments );

        return array(
            'status'  => 'pass',
            'message' => sprintf(
                /* translators: %d: number of keys in segments overview */
                __( 'Segments overview calculated successfully (%d keys).', 'product-mailer-campaigns' ),
                (int) $keys_count
            ),
        );
    }

    /**
     * Check that Pro segments + example rows look sane.
     *
     * @return array
     */
    public static function test_segments_samples_consistent() {
        // If Pro class is missing, skip gracefully.
        if ( ! class_exists( 'PMCPC_Pro_Bootstrap' ) ) {
            return array(
                'status'  => 'pass',
                'message' => __( 'Commerce is not active; segments diagnostics skipped.', 'product-mailer-campaigns' ),
            );
        }

        // Get Pro instance.
        if ( method_exists( 'PMCPC_Pro_Bootstrap', 'instance' ) ) {
            $pro = PMCPC_Pro_Bootstrap::instance();
        } else {
            $pro = new PMCPC_Pro_Bootstrap();
        }

        if ( ! method_exists( $pro, 'get_segments_overview_for_debug' ) ) {
            return array(
                'status'  => 'fail',
                'message' => __( 'PMCPC_Pro_Bootstrap::get_segments_overview_for_debug() is missing.', 'product-mailer-campaigns' ),
            );
        }

        try {
            $segments = $pro->get_segments_overview_for_debug();
        } catch ( \Throwable $e ) {
            return array(
                'status'  => 'fail',
	                'message' => sprintf(
	                    /* translators: %s: error message. */
	                    __( 'Error while calculating segments: %s', 'product-mailer-campaigns' ),
	                    $e->getMessage()
	                ),
            );
        }

        if ( ! is_array( $segments ) || empty( $segments ) ) {
            return array(
                'status'  => 'fail',
                'message' => __( 'Segments overview is empty or not an array.', 'product-mailer-campaigns' ),
            );
        }

        $issues = array();

        // Expected main segments and their sample arrays.
        $map = array(
            'all'       => 'all_samples',
            'customers' => 'customer_samples',
            'vip'       => 'vip_samples',
            'lapsed'    => 'lapsed_samples',
        );

        foreach ( $map as $segment_key => $samples_key ) {
            $count   = isset( $segments[ $segment_key ] ) ? (int) $segments[ $segment_key ] : 0;
            $samples = isset( $segments[ $samples_key ] ) && is_array( $segments[ $samples_key ] )
                ? $segments[ $samples_key ]
                : array();

            // If count is 0, samples should be empty.
            if ( $count === 0 && ! empty( $samples ) ) {
                $issues[] = sprintf(
                    /* translators: 1: segment key, 2: samples count */
                    __( 'Segment "%1$s" has 0 subscribers but %2$d example row(s).', 'product-mailer-campaigns' ),
                    $segment_key,
                    count( $samples )
                );
            }

            // If count > 0, ideally we have at least one sample.
            if ( $count > 0 && empty( $samples ) ) {
                $issues[] = sprintf(
                    /* translators: 1: segment key, 2: count */
                    __( 'Segment "%1$s" has %2$d subscribers but no example rows.', 'product-mailer-campaigns' ),
                    $segment_key,
                    $count
                );
                continue;
            }

            // Check structure of up to three example rows.
            $sample_check = array_slice( $samples, 0, 3 );
            foreach ( $sample_check as $idx => $row ) {
                if ( ! is_array( $row ) ) {
	                    $issues[] = sprintf(
	                        /* translators: 1: row number, 2: segment key. */
	                        __( 'Example row %1$d in segment "%2$s" is not an array.', 'product-mailer-campaigns' ),
                        $idx,
                        $segment_key
                    );
                    continue;
                }

                $required_keys = array( 'subscriber_id', 'email', 'total_spent' );
                foreach ( $required_keys as $key ) {
                    if ( ! array_key_exists( $key, $row ) ) {
	                            $issues[] = sprintf(
	                                /* translators: 1: row number, 2: segment key, 3: missing key name. */
	                                __( 'Example row %1$d in segment "%2$s" is missing key "%3$s".', 'product-mailer-campaigns' ),
                            $idx,
                            $segment_key,
                            $key
                        );
                    }
                }

                if ( isset( $row['total_spent'] ) && (float) $row['total_spent'] < 0 ) {
	                    $issues[] = sprintf(
	                        /* translators: 1: row number, 2: segment key. */
	                        __( 'Example row %1$d in segment "%2$s" has negative total_spent.', 'product-mailer-campaigns' ),
                        $idx,
                        $segment_key
                    );
                }

					if ( empty( $row['email'] ) ) {
						$issues[] = sprintf(
							/* translators: 1: row number, 2: segment key. */
							__( 'Example row %1$d in segment "%2$s" has an empty email.', 'product-mailer-campaigns' ),
							$idx,
							$segment_key
						);
					}
            }
        }

        if ( empty( $issues ) ) {
            return array(
                'status'  => 'pass',
                'message' => __( 'Segments and example rows look consistent.', 'product-mailer-campaigns' ),
            );
        }

        return array(
            'status'  => 'fail',
            'message' => __( 'One or more issues were detected in segment examples.', 'product-mailer-campaigns' ),
            'details' => $issues,
        );
    }
/**
 * Warn about suspicious combinations of automation trigger + recipient segment,
 * for example "Welcome (new subscribers)" combined with customer-only segments.
 *
 * This is a soft warning only; campaigns will still run, but the admin can
 * review and adjust them if needed.
 *
 * @return array
 */
public static function test_campaign_trigger_segment_combos() {
    global $wpdb;

    if ( ! function_exists( 'pmcpc_is_pro_active' ) || ! pmcpc_is_pro_active() ) {
        return array(
            'status'  => 'pass',
            'message' => __( 'Commerce is not active; trigger and segment combination test skipped.', 'product-mailer-campaigns' ),
        );
    }

    $table = $wpdb->prefix . 'pmcpc_campaigns';

		// Cache group for diagnostics (plugin-specific to avoid collisions).
		$cache_group = 'pmcpc';

	$columns_cache_key = 'diag_campaigns_columns';
	$columns           = wp_cache_get( $columns_cache_key, $cache_group );
	if ( false === $columns ) {
		// Diagnostic query (cached); table name is plugin-controlled.
		// Avoid non-core %i placeholders in wpdb::prepare.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
		$columns = $wpdb->get_col( 'SHOW COLUMNS FROM ' . esc_sql( $table ) );
		wp_cache_set( $columns_cache_key, $columns, $cache_group, 300 );
	}

	$campaigns_cache_key = 'diag_campaigns_list';
	$campaigns           = wp_cache_get( $campaigns_cache_key, $cache_group );
	if ( false === $campaigns ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$campaigns = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, name, automation_trigger, pro_segment_key FROM {$table} ORDER BY created_at DESC LIMIT %d",
				200
			),
			ARRAY_A
		);
		wp_cache_set( $campaigns_cache_key, $campaigns, $cache_group, 300 );
	}
if ( empty( $campaigns ) ) {
        return array(
            'status'  => 'pass',
            'message' => __( 'No campaigns found to check for trigger/segment combinations.', 'product-mailer-campaigns' ),
        );
    }

    $order_based_segments = array( 'customers', 'recent', 'high_value', 'vip', 'lapsed' );
    $segment_labels       = array(
        'customers'   => __( 'Customers (at least one order)', 'product-mailer-campaigns' ),
        'recent'      => __( 'Recent customers (last 30 days)', 'product-mailer-campaigns' ),
        'high_value'  => __( 'High value customers (over threshold)', 'product-mailer-campaigns' ),
        'vip'         => __( 'VIP customers (top spenders)', 'product-mailer-campaigns' ),
        'lapsed'      => __( 'Lapsed customers (90+ days without orders)', 'product-mailer-campaigns' ),
    );

    $issues = array();

    foreach ( $campaigns as $campaign ) {
        $trigger = isset( $campaign['automation_trigger'] ) ? $campaign['automation_trigger'] : '';
        $segment = isset( $campaign['pro_segment_key'] ) ? $campaign['pro_segment_key'] : '';

        if ( 'welcome' === $trigger && in_array( $segment, $order_based_segments, true ) ) {
            $label = isset( $segment_labels[ $segment ] ) ? $segment_labels[ $segment ] : $segment;

            $issues[] = sprintf(
                /* translators: 1: campaign name, 2: campaign ID, 3: segment label */
                __( 'Campaign "%1$s" (ID %2$d) uses the "Welcome (new subscribers)" trigger together with the "%3$s" recipient segment. Consider using a post-purchase trigger instead of a welcome trigger for this segment.', 'product-mailer-campaigns' ),
                isset( $campaign['name'] ) ? $campaign['name'] : '#' . (int) $campaign['id'],
                (int) $campaign['id'],
                $label
            );
        }
    }

    if ( empty( $issues ) ) {
        return array(
            'status'  => 'pass',
            'message' => __( 'No suspicious trigger/segment combinations found.', 'product-mailer-campaigns' ),
        );
    }

    return array(
        'status'  => 'warn',
        'message' => __( 'One or more campaigns combine welcome triggers with customer-only segments. Review these combinations to avoid confusing behaviour.', 'product-mailer-campaigns' ),
        'details' => $issues,
    );
}

    /**
     * Dry-run audience test: for each campaign, check whether the current admin's
     * subscriber record would be included after tags and Pro segments/triggers.
     *
     * This does not send any email or modify data.
     *
     * @return array
     */
    public static function test_campaign_admin_audience() {
        if ( ! class_exists( 'PMCPC_Campaign_Manager' ) ) {
            return array(
                'status'  => 'pass',
                'message' => __( 'Campaign manager not available; skipping campaign audience test.', 'product-mailer-campaigns' ),
            );
        }

        $current_user = wp_get_current_user();
        if ( ! $current_user || ! $current_user->user_email ) {
            return array(
                'status'  => 'fail',
                'message' => __( 'Could not determine the current admin email address.', 'product-mailer-campaigns' ),
            );
        }

        $email = sanitize_email( $current_user->user_email );

		global $wpdb;
		$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
		$campaigns_table   = $wpdb->prefix . 'pmcpc_campaigns';
		$tags_table        = $wpdb->prefix . 'pmcpc_subscriber_tags';

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$subscriber = $wpdb->get_row(
				// Table name is plugin-controlled (internal). Avoid non-core %i placeholders.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"SELECT * FROM {$subscribers_table} WHERE email = %s",
					$email
				)
			);

        if ( ! $subscriber || empty( $subscriber->id ) ) {
            return array(
                'status'  => 'warning',
                'message' => __( 'Your admin email is not currently a Product Mailer subscriber, so no campaigns would include you. Add yourself as a subscriber to use this test.', 'product-mailer-campaigns' ),
            );
        }

			$campaigns_cache_key = 'pmcpc_diag_latest_campaigns_50';
				$campaigns           = wp_cache_get( $campaigns_cache_key, 'pmcpc' );
			if ( false === $campaigns ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$campaigns = $wpdb->get_results(
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
					$wpdb->prepare(
						"SELECT * FROM {$campaigns_table} ORDER BY created_at DESC LIMIT %d",
						50
					)
				);
					wp_cache_set( $campaigns_cache_key, $campaigns, 'pmcpc', 5 * MINUTE_IN_SECONDS );
			}
        if ( empty( $campaigns ) ) {
            return array(
                'status'  => 'warning',
                'message' => __( 'No campaigns found to test.', 'product-mailer-campaigns' ),
            );
        }

        $details        = array();
        $included_count = 0;

        foreach ( $campaigns as $campaign ) {
            $name = isset( $campaign->name ) && $campaign->name
                ? $campaign->name
                : sprintf( /* translators: %d: campaign ID. */
				__( 'Campaign #%d', 'product-mailer-campaigns' ), (int) $campaign->id );

            // Build combined target tags (normal, source, lifecycle).
            $target_tag            = isset( $campaign->target_tag ) ? trim( $campaign->target_tag ) : '';
            $target_source_tags    = isset( $campaign->target_source_tags ) ? trim( $campaign->target_source_tags ) : '';
            $target_lifecycle_tags = isset( $campaign->target_lifecycle_tags ) ? trim( $campaign->target_lifecycle_tags ) : '';

            $all_tags = array();

            if ( '' !== $target_tag ) {
                $parts = array_filter( array_map( 'trim', explode( ',', $target_tag ) ) );
                if ( ! empty( $parts ) ) {
                    $all_tags = array_merge( $all_tags, $parts );
                }
            }

            if ( '' !== $target_source_tags ) {
                $parts = array_filter( array_map( 'trim', explode( ',', $target_source_tags ) ) );
                if ( ! empty( $parts ) ) {
                    $all_tags = array_merge( $all_tags, $parts );
                }
            }

            if ( '' !== $target_lifecycle_tags ) {
                $parts = array_filter( array_map( 'trim', explode( ',', $target_lifecycle_tags ) ) );
                if ( ! empty( $parts ) ) {
                    $all_tags = array_merge( $all_tags, $parts );
                }
            }

            $all_tags = array_values( array_unique( $all_tags ) );

            $matches_tags = false;

            if ( empty( $all_tags ) ) {
                // No tags means "all active subscribers".
                $matches_tags = ( 'active' === $subscriber->status );
			} else {
				// Sanitize tags (stored tags are treated as plain text values).
				$all_tags = array_values(
					array_filter(
						array_map(
							static function ( $tag ) {
								return sanitize_text_field( (string) $tag );
							},
							(array) $all_tags
						)
					)
				);


				// Build a dynamic IN() clause safely (each tag uses a %s placeholder).
				$in_clause = implode( ',', array_fill( 0, count( $all_tags ), '%s' ) );

				// Prepare query with a variable number of placeholders.
				// Table name is plugin-controlled (internal). Avoid non-core %i placeholders.
				$query  = "SELECT COUNT(*) FROM {$tags_table} WHERE subscriber_id = %d AND tag IN ({$in_clause})";
				$params = array_merge( array( (int) $subscriber->id ), $all_tags );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
				$count = (int) $wpdb->get_var( $wpdb->prepare( $query, ...$params ) );

$matches_tags = $count > 0;
			}

            if ( ! $matches_tags ) {
                $details[] = sprintf(
                    /* translators: 1: campaign name */
                    __( 'Campaign "%1$s": your admin subscriber does not match the campaign tags.', 'product-mailer-campaigns' ),
                    $name
                );
                continue;
            }

            // Build candidate list and let Pro segments / triggers filter it.
            $candidates = array( $subscriber );
            /**
             * Filter the list of subscribers for a campaign (dry run).
             *
             * We re-use the same filter as real sends so segments / automations
             * can include or exclude the admin subscriber.
             *
             * @param array  $subscribers List of subscriber rows.
             * @param object $campaign    Campaign object.
             */
            $filtered = apply_filters( 'pmcpc_campaign_subscribers', $candidates, $campaign );

            if ( empty( $filtered ) ) {
                $details[] = sprintf(
                    /* translators: 1: campaign name */
                    __( 'Campaign "%1$s": your admin subscriber was filtered out by segments or automation rules.', 'product-mailer-campaigns' ),
                    $name
                );
            } else {
                $included_count++;
                $details[] = sprintf(
                    /* translators: 1: campaign name */
                    __( 'Campaign "%1$s": would include your admin subscriber based on current tags and segments.', 'product-mailer-campaigns' ),
                    $name
                );
            }
        }

        $status = 'pass';
        $message = sprintf(
            /* translators: 1: number of campaigns checked, 2: number that include admin */
            __( 'Checked %1$d campaign(s) for your admin subscriber; %2$d would currently include you.', 'product-mailer-campaigns' ),
            count( $campaigns ),
            $included_count
        );

        return array(
            'status'  => $status,
            'message' => $message,
            'details' => $details,
        );
    }
}
