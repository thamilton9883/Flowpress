<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/tracking/class-pmcpc-tracking-controller.php';

/**
 * Tracking facade (back-compat).
 */
class PMCPC_Tracking {

    /** @var PMCPC_Tracking_Controller|null */
    private static $controller = null;

    /**
     * @return PMCPC_Tracking_Controller
     */
    private static function controller() {
        if ( self::$controller instanceof PMCPC_Tracking_Controller ) {
            return self::$controller;
        }

        $c = function_exists( 'pmcpc_container' ) ? pmcpc_container() : null;
        if ( $c && method_exists( $c, 'has' ) && $c->has( 'controller.tracking' ) ) {
            $svc = $c->get( 'controller.tracking' );
            if ( $svc instanceof PMCPC_Tracking_Controller ) {
                self::$controller = $svc;
                return self::$controller;
            }
        }

        self::$controller = new PMCPC_Tracking_Controller();
        return self::$controller;
    }

    /**
     * Back-compat initializer.
     *
     * Older builds call PMCPC_Tracking::init() to register public endpoints.
     * Keep this method even as the implementation moves to controllers.
     */
    public static function init() {
        static $did_init = false;
        if ( $did_init ) {
            return;
        }
        $did_init = true;

        // Query-var endpoints (non-ajax).
        add_action( 'init', array( __CLASS__, 'handle_requests' ), 1 );

        // Public admin-ajax endpoints used in emails.
        add_action( 'wp_ajax_nopriv_pmcpc_open', array( __CLASS__, 'ajax_open' ) );
        add_action( 'wp_ajax_pmcpc_open', array( __CLASS__, 'ajax_open' ) );

        add_action( 'wp_ajax_nopriv_pmcpc_click', array( __CLASS__, 'ajax_click' ) );
        add_action( 'wp_ajax_pmcpc_click', array( __CLASS__, 'ajax_click' ) );

        add_action( 'wp_ajax_nopriv_pmcpc_unsub', array( __CLASS__, 'ajax_unsub' ) );
        add_action( 'wp_ajax_pmcpc_unsub', array( __CLASS__, 'ajax_unsub' ) );

        add_action( 'wp_ajax_nopriv_pmcpc_view', array( __CLASS__, 'ajax_view' ) );
        add_action( 'wp_ajax_pmcpc_view', array( __CLASS__, 'ajax_view' ) );
    }

    // Static wrappers for existing calls.
    public static function __callStatic( $name, $arguments ) {
        $controller = self::controller();
        if ( is_callable( array( $controller, $name ) ) ) {
            return call_user_func_array( array( $controller, $name ), $arguments );
        }
        trigger_error( 'Call to undefined method ' . __CLASS__ . '::' . $name . '()', E_USER_ERROR );
        return null;
    }
}
