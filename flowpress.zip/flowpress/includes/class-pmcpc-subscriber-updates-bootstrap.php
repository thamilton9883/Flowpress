<?php
/**
 * Subscriber Updates bootstrap helpers.
 *
 * @package ProductMailerCampaigns
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Handles Subscriber Updates bootstrap behavior.
 */
class PMCPC_Subscriber_Updates_Bootstrap {

    /**
     * Rewrite flush marker option.
     */
    const REWRITE_VERSION_OPTION = 'pmcpc_sub_updates_rewrite_version';

    /**
     * Current rewrite version.
     */
    const REWRITE_VERSION = '2';

    /**
     * Backfill marker option.
     */
    const BACKFILL_VERSION_OPTION = 'pmcpc_sub_updates_backfill_version';

    /**
     * Current backfill version.
     */
    const BACKFILL_VERSION = '2';

    /**
     * Register plugin hooks.
     *
     * @return void
     */
    public static function register_hooks() {
        add_action( 'init', array( __CLASS__, 'register_content' ), 9 );
        add_action( 'admin_init', array( __CLASS__, 'maybe_flush_rewrite_rules' ) );
        add_action( 'admin_init', array( __CLASS__, 'maybe_backfill_update_metadata' ) );
        add_action( 'save_post_pmcpc_sub_update', array( __CLASS__, 'flush_cache' ) );
        add_action( 'deleted_post', array( __CLASS__, 'flush_cache' ) );
        add_action( 'trashed_post', array( __CLASS__, 'flush_cache' ) );
        add_action( 'template_redirect', 'pmcpc_track_subscriber_update_view' );
        add_action( 'template_redirect', array( __CLASS__, 'maybe_redirect_legacy_single_update_slug' ), 2 );
        add_filter( 'the_content', 'pmcpc_filter_subscriber_update_single_content' );
        add_action( 'transition_post_status', 'pmcpc_maybe_publish_new_product_arrival_update', 20, 3 );
        add_action( 'pmcpc_daily_commerce_update', 'pmcpc_publish_daily_commerce_update' );
        add_action( 'template_redirect', 'pmcpc_maybe_handle_subscriber_update_product_click', 1 );
        add_action( 'woocommerce_checkout_order_processed', 'pmcpc_capture_order_product_click_attribution', 20 );
    }

    /**
     * Register the post type and taxonomy used for website subscriber updates created by automations.
     *
     * @return void
     */
    public static function register_content() {
        register_post_type(
            'pmcpc_sub_update',
            array(
                'labels' => array(
                    'name'               => __( 'Updates', 'product-mailer-campaigns' ),
                    'singular_name'      => __( 'Subscriber Update', 'product-mailer-campaigns' ),
                    'menu_name'          => __( 'Updates', 'product-mailer-campaigns' ),
                    'add_new_item'       => __( 'Add Subscriber Update', 'product-mailer-campaigns' ),
                    'edit_item'          => __( 'Edit Subscriber Update', 'product-mailer-campaigns' ),
                    'new_item'           => __( 'New Subscriber Update', 'product-mailer-campaigns' ),
                    'view_item'          => __( 'View Subscriber Update', 'product-mailer-campaigns' ),
                    'search_items'       => __( 'Search Updates', 'product-mailer-campaigns' ),
                    'not_found'          => __( 'No subscriber updates found.', 'product-mailer-campaigns' ),
                    'not_found_in_trash' => __( 'No subscriber updates found in Trash.', 'product-mailer-campaigns' ),
                ),
                'public'             => true,
                'show_ui'            => true,
                'show_in_menu'       => false,
                'supports'           => array( 'title', 'editor', 'excerpt', 'revisions', 'thumbnail' ),
                // Keep the dedicated /subscriber-updates/ page as the public feed entrypoint.
                'has_archive'        => false,
                'rewrite'            => array( 'slug' => 'subscriber-update' ),
                'show_in_rest'       => true,
                'publicly_queryable' => true,
                'menu_icon'          => 'dashicons-megaphone',
                'menu_position'      => 58,
            )
        );

        register_taxonomy(
            'pmcpc_update_topic',
            'pmcpc_sub_update',
            array(
                'labels'            => array(
                    'name'          => __( 'Update Topics', 'product-mailer-campaigns' ),
                    'singular_name' => __( 'Update Topic', 'product-mailer-campaigns' ),
                ),
                'public'            => true,
                'show_ui'           => true,
                'show_in_rest'      => true,
                'hierarchical'      => true,
                'show_admin_column' => true,
                'rewrite'           => array( 'slug' => 'subscriber-update-topic' ),
            )
        );
    }

    /**
     * Flush Subscriber Updates cached feed output after content changes.
     *
     * @param int $post_id Post ID.
     * @return void
     */
    public static function flush_cache( $post_id ) {
        if ( $post_id && 'pmcpc_sub_update' !== get_post_type( $post_id ) ) {
            return;
        }

        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_pmcpc_sub_updates_%' OR option_name LIKE '_transient_timeout_pmcpc_sub_updates_%'" );
    }

    /**
     * Flush rewrite rules one time when the subscriber update rewrite changes.
     *
     * @return void
     */
    public static function maybe_flush_rewrite_rules() {
        if ( get_option( self::REWRITE_VERSION_OPTION ) === self::REWRITE_VERSION ) {
            return;
        }

        flush_rewrite_rules( false );
        update_option( self::REWRITE_VERSION_OPTION, self::REWRITE_VERSION, false );
    }

    /**
     * Redirect old single update slugs to the current published post when the base/slug changed.
     *
     * @return void
     */
    public static function maybe_redirect_legacy_single_update_slug() {
        if ( ! is_404() ) {
            return;
        }

        $request_path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
        $request_path = $request_path ? wp_parse_url( $request_path, PHP_URL_PATH ) : '';
        $request_path = is_string( $request_path ) ? trim( $request_path, '/' ) : '';

        if ( '' === $request_path || 0 !== strpos( $request_path, 'subscriber-update/' ) ) {
            return;
        }

        $slug = trim( substr( $request_path, strlen( 'subscriber-update/' ) ), '/' );
        if ( '' === $slug ) {
            return;
        }

        $normalize_target_path = static function ( $url ) {
            if ( ! is_string( $url ) || '' === $url ) {
                return '';
            }

            $path = wp_parse_url( $url, PHP_URL_PATH );

            return is_string( $path ) ? trim( $path, '/' ) : '';
        };

        $post = get_page_by_path( $slug, OBJECT, 'pmcpc_sub_update' );
        if ( $post instanceof WP_Post && 'publish' === $post->post_status ) {
            $target_url  = get_permalink( $post );
            $target_path = $normalize_target_path( $target_url );
            if ( '' !== $target_path && $target_path !== $request_path ) {
                wp_safe_redirect( $target_url, 301 );
                exit;
            }

            return;
        }

        global $wpdb;
        $like  = $wpdb->esc_like( $slug ) . '-%';
        $found = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish' AND (post_name = %s OR post_name LIKE %s) ORDER BY post_date DESC, ID DESC LIMIT 1",
                'pmcpc_sub_update',
                $slug,
                $like
            )
        );

        $found = absint( $found );
        if ( $found > 0 ) {
            $target_url  = get_permalink( $found );
            $target_path = $normalize_target_path( $target_url );
            if ( '' !== $target_path && $target_path !== $request_path ) {
                wp_safe_redirect( $target_url, 301 );
                exit;
            }
        }
    }

    /**
     * Backfill missing subscriber update metadata for older published posts.
     *
     * @return void
     */
    public static function maybe_backfill_update_metadata() {
        if ( get_option( self::BACKFILL_VERSION_OPTION ) === self::BACKFILL_VERSION ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) || ! function_exists( 'get_posts' ) ) {
            return;
        }

        $updates = get_posts(
            array(
                'post_type'      => 'pmcpc_sub_update',
                'post_status'    => array( 'publish', 'draft', 'private' ),
                'posts_per_page' => 250,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'fields'         => 'ids',
            )
        );

        if ( ! empty( $updates ) ) {
            foreach ( $updates as $update_id ) {
                self::backfill_single_update_metadata( (int) $update_id );
            }
        }

        update_option( self::BACKFILL_VERSION_OPTION, self::BACKFILL_VERSION, false );
    }

    /**
     * Repair one subscriber update post when older metadata is missing.
     *
     * @param int $update_id Update post id.
     * @return void
     */
    protected static function backfill_single_update_metadata( $update_id ) {
        $update_id = absint( $update_id );
        if ( $update_id <= 0 || 'pmcpc_sub_update' !== get_post_type( $update_id ) ) {
            return;
        }

        $existing_product_ids = self::read_product_ids_from_meta( $update_id );
        $needs_product_ids    = empty( $existing_product_ids );
        $needs_image          = '' === (string) get_post_meta( $update_id, '_pmcpc_image_url', true ) && ! has_post_thumbnail( $update_id );

        if ( ! $needs_product_ids && ! $needs_image ) {
            return;
        }

        $recovered_product_ids = $existing_product_ids;
        if ( empty( $recovered_product_ids ) ) {
            $recovered_product_ids = self::infer_product_ids_for_update( $update_id );
            if ( ! empty( $recovered_product_ids ) ) {
                update_post_meta( $update_id, '_pmcpc_product_ids', implode( ',', $recovered_product_ids ) );
            }
        }

        if ( $needs_image ) {
            $hero_url = self::resolve_primary_image_for_update( $update_id, $recovered_product_ids );
            if ( '' !== $hero_url ) {
                update_post_meta( $update_id, '_pmcpc_image_url', esc_url_raw( $hero_url ) );
            }
        }
    }

    /**
     * Read stored product ids from update metadata.
     *
     * @param int $update_id Update post id.
     * @return int[]
     */
    protected static function read_product_ids_from_meta( $update_id ) {
        $raw = (string) get_post_meta( $update_id, '_pmcpc_product_ids', true );
        if ( '' === $raw ) {
            return array();
        }

        return array_values(
            array_unique(
                array_filter(
                    array_map( 'absint', array_map( 'trim', explode( ',', $raw ) ) )
                )
            )
        );
    }

    /**
     * Attempt to infer missing product ids from legacy update content and CTA urls.
     *
     * @param int $update_id Update post id.
     * @return int[]
     */
    protected static function infer_product_ids_for_update( $update_id ) {
        $product_ids = array();

        $new_arrival_id = absint( get_post_meta( $update_id, '_pmcpc_new_arrival_product_id', true ) );
        if ( $new_arrival_id > 0 && 'product' === get_post_type( $new_arrival_id ) ) {
            $product_ids[] = $new_arrival_id;
        }

        $cta_url = (string) get_post_meta( $update_id, '_pmcpc_cta_url', true );
        if ( '' !== $cta_url ) {
            $cta_product_id = self::resolve_product_id_from_url( $cta_url );
            if ( $cta_product_id > 0 ) {
                $product_ids[] = $cta_product_id;
            }
        }

        $content = (string) get_post_field( 'post_content', $update_id );
        if ( '' !== $content ) {
            preg_match_all( '/https?:\/\/[^\s"\'<>]+/i', $content, $matches );
            if ( ! empty( $matches[0] ) ) {
                foreach ( $matches[0] as $url ) {
                    $product_id = self::resolve_product_id_from_url( $url );
                    if ( $product_id > 0 ) {
                        $product_ids[] = $product_id;
                    }
                }
            }
        }

        $product_ids = array_values( array_unique( array_filter( array_map( 'absint', $product_ids ) ) ) );

        if ( ! empty( $product_ids ) ) {
            return $product_ids;
        }

        $publish_key  = (string) get_post_meta( $update_id, '_pmcpc_publish_key', true );
        $source_type  = (string) get_post_meta( $update_id, '_pmcpc_source_type', true );
        $legacy_title = (string) get_post_field( 'post_title', $update_id );
        if ( 'commerce_automation' === $source_type || 0 === strpos( $publish_key, 'woo-' ) || false !== stripos( $legacy_title, 'selection from the shop' ) || false !== stripos( $legacy_title, 'new arrivals' ) ) {
            $product_ids = self::infer_commerce_products_for_update( $update_id, $publish_key );
            if ( ! empty( $product_ids ) ) {
                return $product_ids;
            }
        }

        return array();
    }

    /**
     * Rebuild likely product ids for older commerce-generated updates.
     *
     * @param int    $update_id    Update post id.
     * @param string $publish_key  Stored publish key.
     * @return int[]
     */
    protected static function infer_commerce_products_for_update( $update_id, $publish_key = '' ) {
        if ( ! function_exists( 'get_posts' ) ) {
            return array();
        }

        $settings_key = class_exists( 'PMCPC_Subscriber_Updates_Settings' ) ? PMCPC_Subscriber_Updates_Settings::OPTION_KEY : 'pmcpc_sub_updates_settings';
        $settings = get_option( $settings_key, array() );
        $settings = is_array( $settings ) ? $settings : array();
        $limit    = isset( $settings['commerce_limit'] ) ? max( 1, min( 12, absint( $settings['commerce_limit'] ) ) ) : 4;
        $mode     = 'latest';

        $publish_key = (string) $publish_key;
        if ( 0 === strpos( $publish_key, 'woo-featured-' ) ) {
            $mode = 'featured';
        }

        $date_query = array();
        $post_obj   = get_post( $update_id );
        if ( $post_obj instanceof WP_Post ) {
            $date_query[] = array(
                'before'    => $post_obj->post_date,
                'inclusive' => true,
            );
        }

        $query_args = array(
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
            'fields'         => 'ids',
            'date_query'     => $date_query,
        );

        if ( 'featured' === $mode ) {
            $query_args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_visibility',
                    'field'    => 'name',
                    'terms'    => array( 'featured' ),
                ),
            );
        } else {
            $query_args['orderby'] = 'date';
            $query_args['order']   = 'DESC';
        }

        $product_ids = get_posts( $query_args );
        if ( empty( $product_ids ) ) {
            return array();
        }

        return array_values( array_unique( array_filter( array_map( 'absint', $product_ids ) ) ) );
    }

    /**
     * Convert a front-end URL into a product id when possible.
     *
     * @param string $url Candidate URL.
     * @return int
     */
    protected static function resolve_product_id_from_url( $url ) {
        $url = esc_url_raw( (string) $url );
        if ( '' === $url || ! function_exists( 'url_to_postid' ) ) {
            return 0;
        }

        $post_id = absint( url_to_postid( $url ) );
        if ( $post_id > 0 && 'product' === get_post_type( $post_id ) ) {
            return $post_id;
        }

        return 0;
    }

    /**
     * Resolve a hero image URL for an update from recovered products.
     *
     * @param int   $update_id    Update post id.
     * @param int[] $product_ids  Related product ids.
     * @return string
     */
    protected static function resolve_primary_image_for_update( $update_id, $product_ids ) {
        $update_id   = absint( $update_id );
        $product_ids = array_values( array_filter( array_map( 'absint', (array) $product_ids ) ) );

        if ( ! empty( $product_ids ) ) {
            foreach ( $product_ids as $product_id ) {
                $image = get_the_post_thumbnail_url( $product_id, 'large' );
                if ( $image ) {
                    return (string) $image;
                }
            }
        }

        $new_arrival_id = absint( get_post_meta( $update_id, '_pmcpc_new_arrival_product_id', true ) );
        if ( $new_arrival_id > 0 ) {
            $image = get_the_post_thumbnail_url( $new_arrival_id, 'large' );
            if ( $image ) {
                return (string) $image;
            }
        }

        return '';
    }
}
