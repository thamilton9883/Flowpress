<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PMCPC_Settings {

    /**
     * Read the plugin settings option as a normalized array.
     *
     * @return array
     */
    public static function all() {
        $option = get_option( 'pmcpc_settings', array() );

        if ( ! is_array( $option ) ) {
            return array();
        }

        return $option;
    }

    public static function get( $key, $default = '' ) {
        $option = self::all();

        if ( isset( $option[ $key ] ) ) {
            return $option[ $key ];
        }

        return $default;
    }

    public static function update( $values ) {
        if ( ! is_array( $values ) ) {
            return self::all();
        }

        $option = self::all();
        $option = array_merge( $option, $values );
        update_option( 'pmcpc_settings', $option );

        return $option;
    }

    /**
     * Read a multiline text setting as a unique list of trimmed strings.
     *
     * @param string $key Setting key.
     * @return string[]
     */
    public static function get_multiline_list( $key ) {
        $value = self::get( $key, '' );

        if ( ! is_string( $value ) || '' === trim( $value ) ) {
            return array();
        }

        $lines = preg_split( '/\r\n|\r|\n/', $value );
        if ( ! is_array( $lines ) ) {
            return array();
        }

        $lines = array_map(
            static function ( $line ) {
                return trim( (string) $line );
            },
            $lines
        );

        $lines = array_filter(
            $lines,
            static function ( $line ) {
                return '' !== $line;
            }
        );

        return array_values( array_unique( $lines ) );
    }

    /**
     * Persist a multiline text setting from an array of string values.
     *
     * @param string $key    Setting key.
     * @param array  $values Setting values.
     * @return array
     */
    public static function update_multiline_list( $key, $values ) {
        if ( ! is_array( $values ) ) {
            $values = array();
        }

        $values = array_map(
            static function ( $value ) {
                return trim( (string) $value );
            },
            $values
        );

        $values = array_filter(
            $values,
            static function ( $value ) {
                return '' !== $value;
            }
        );

        return self::update(
            array(
                $key => implode( "\n", array_values( array_unique( $values ) ) ),
            )
        );
    }
}


if ( ! function_exists( 'pmcpc_get_setting' ) ) {
    /**
     * Helper to fetch Product Mailer Campaigns settings.
     *
     * Used by the Pro add-on to read values like the high-value customer threshold.
     *
     * @param string $key
     * @param mixed  $default
     * @return mixed
     */
    function pmcpc_get_setting( $key, $default = '' ) {
        return PMCPC_Settings::get( $key, $default );
    }
}
