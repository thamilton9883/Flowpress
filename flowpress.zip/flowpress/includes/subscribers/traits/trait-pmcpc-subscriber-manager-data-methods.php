<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Subscriber_Manager_Data_Methods {
    protected function add_subscriber_from_form() {
            $form_data  = self::pmcpc_get_manual_subscriber_form_data();
            $email      = $form_data['email'];
            $first_name = $form_data['first_name'];
            $last_name  = $form_data['last_name'];
            $birthday   = $form_data['birthday'];
    		$tags_raw   = $form_data['tags_raw'];

            if ( ! is_email( $email ) ) {
                add_settings_error( 'pmcpc_subscribers', 'pmcpc_invalid_email', __( 'Invalid email address.', 'product-mailer-campaigns' ), 'error' );
                return;
            }

            $is_new = self::upsert_subscriber( $email, $first_name, $last_name, 'active' );

            $subscriber = self::get_subscriber_by_email( $email );
    		if ( $subscriber && '' !== trim( $tags_raw ) ) {
    			$tags = self::pmcpc_parse_manual_tags( $tags_raw );
                self::set_tags_for_subscriber( $subscriber->id, $tags );
    		}

            $subscriber = self::get_subscriber_by_email( $email );
            if ( $subscriber ) {
                self::set_subscriber_birthday( (int) $subscriber->id, $birthday );
            }

            if ( $is_new ) {
                PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );
            }

            add_settings_error( 'pmcpc_subscribers', 'pmcpc_subscriber_saved', __( 'Subscriber saved.', 'product-mailer-campaigns' ), 'updated' );
        }

        public static function upsert_subscriber( $email, $first_name = '', $last_name = '', $status = 'active' ) {
            return self::pmcpc_persist_subscriber( $email, $first_name, $last_name, $status );
        }

        
        /**
         * Get a subscriber row by ID.
         *
         * @param int $subscriber_id Subscriber ID.
         * @return object|null
         */
        public static function get_subscriber( $subscriber_id ) {
            global $wpdb;
            $table         = $wpdb->prefix . 'pmcpc_subscribers';
            $subscriber_id = absint( $subscriber_id );

            if ( ! $subscriber_id ) {
                return null;
            }

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    	    return $wpdb->get_row(
    	        $wpdb->prepare(
    	            'SELECT * FROM %i WHERE id = %d',
    	            $table,
    	            $subscriber_id
    	        )
    	    );
        }

    public static function get_subscriber_by_email( $email ) {
            global $wpdb;
    	    $table = $wpdb->prefix . 'pmcpc_subscribers';
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    	    return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE email = %s', $table, $email ) );
        }

        
        /**
         * Update lifecycle tags for a subscriber based on WooCommerce order history.
         *
         * This is called from the WooCommerce integration when an order is completed.
         *
         * @param string $email Billing email from the order.
         * @return void
         */
        
        /**
         * Update derived "health" tag for a subscriber based on engagement + lifecycle.
         *
         * Health tags are stored as a single tag with prefix "health:" to allow filtering.
         *
         * Rules (simple + explainable):
         * - If unsubscribed or pending: health:cold
         * - Otherwise:
         *   - Engaged (opened in last 30 days): hot (unless lapsed-customer => warm)
         *   - At risk (opened in last 90 days): warm (unless lapsed-customer => slipping)
         *   - No recent opens / no opens: cold
         *
         * @param string $email Subscriber email.
         * @return void
         */
        public static function update_health_for_email( $email ) {
            $email = sanitize_email( $email );
            if ( ! $email || ! is_email( $email ) ) {
                return;
            }

            $subscriber = self::get_subscriber_by_email( $email );
            if ( ! $subscriber || empty( $subscriber->id ) ) {
                return;
            }

            $health_tag = self::calculate_health_tag_for_subscriber( $subscriber );
            self::set_health_tag_for_subscriber( (int) $subscriber->id, $health_tag );
        }

        /**
         * Calculate the health tag for a subscriber row.
         *
         * @param object $subscriber Subscriber row (pmcpc_subscribers).
         * @return string health:* tag.
         */
        protected static function calculate_health_tag_for_subscriber( $subscriber ) {
            $status = isset( $subscriber->status ) ? (string) $subscriber->status : '';
            if ( 'active' !== $status ) {
                return 'health:cold';
            }

            $opens = isset( $subscriber->lifetime_opens ) ? (int) $subscriber->lifetime_opens : 0;

            $last_engaged_at = isset( $subscriber->last_engaged_at ) ? (string) $subscriber->last_engaged_at : '';
            $is_engaged_30   = false;
            $is_engaged_90   = false;

            if ( ! empty( $last_engaged_at ) ) {
                $ts = strtotime( $last_engaged_at );
                if ( $ts ) {
                    $age_days = ( time() - $ts ) / DAY_IN_SECONDS;
                    $is_engaged_30 = ( $age_days <= 30 );
                    $is_engaged_90 = ( $age_days <= 90 );
                }
            }

            // Get lifecycle tags from the tags table (if present).
            $lifecycle_tags = array();
            if ( isset( $subscriber->id ) ) {
                $all_tags = self::get_tags_for_subscriber( (int) $subscriber->id );
                if ( is_array( $all_tags ) ) {
                    foreach ( $all_tags as $tag ) {
                        $tag = (string) $tag;
                        if ( 'lapsed-customer' === $tag || 'recent-buyer' === $tag || 'vip' === $tag || 'repeat-customer' === $tag || 'new-customer' === $tag || 'high-value' === $tag ) {
                            $lifecycle_tags[] = $tag;
                        }
                    }
                }
            }

            $is_lapsed = in_array( 'lapsed-customer', $lifecycle_tags, true );
            $is_buyer  = ( in_array( 'recent-buyer', $lifecycle_tags, true ) || in_array( 'repeat-customer', $lifecycle_tags, true ) || in_array( 'new-customer', $lifecycle_tags, true ) || in_array( 'high-value', $lifecycle_tags, true ) || in_array( 'vip', $lifecycle_tags, true ) );

            if ( $opens <= 0 && empty( $last_engaged_at ) ) {
                return 'health:cold';
            }

            if ( $is_engaged_30 ) {
                return $is_lapsed ? 'health:warm' : 'health:hot';
            }

            if ( $is_engaged_90 ) {
                return $is_lapsed ? 'health:slipping' : 'health:warm';
            }

            // If they are a buyer but not opening recently, flag as slipping.
            if ( $is_buyer ) {
                return 'health:slipping';
            }

            return 'health:cold';
        }

        /**
         * Ensure exactly one health:* tag exists for a subscriber.
         *
         * @param int    $subscriber_id Subscriber ID.
         * @param string $health_tag    Health tag.
         * @return void
         */
        protected static function set_health_tag_for_subscriber( $subscriber_id, $health_tag ) {
            $subscriber_id = absint( $subscriber_id );
            if ( ! $subscriber_id ) {
                return;
            }
            $health_tag = sanitize_text_field( (string) $health_tag );
            if ( empty( $health_tag ) || 0 !== strpos( $health_tag, 'health:' ) ) {
                $health_tag = 'health:cold';
            }

            $tags = self::get_tags_for_subscriber( $subscriber_id );
            if ( ! is_array( $tags ) ) {
                $tags = array();
            }
            $tags = array_values(
                array_filter(
                    $tags,
                    static function ( $tag ) {
                        return 0 !== strpos( (string) $tag, 'health:' );
                    }
                )
            );
            $tags[] = $health_tag;

            self::set_tags_for_subscriber( $subscriber_id, array_values( array_unique( $tags ) ) );
        }

    public static function update_lifecycle_for_email( $email ) {
            $email = sanitize_email( $email );
            if ( ! $email || ! is_email( $email ) ) {
                return;
            }

            if ( ! class_exists( 'PMCPC_Settings' ) ) {
                return;
            }

            $auto_enabled = PMCPC_Settings::get( 'lifecycle_auto_enabled', 'no' );
            if ( 'yes' !== $auto_enabled ) {
                return;
            }

            $subscriber = self::get_subscriber_by_email( $email );
            if ( ! $subscriber || empty( $subscriber->id ) ) {
                return;
            }

            $wc_stats          = self::get_wc_purchase_stats_for_email( $email );
            $order_count       = isset( $wc_stats['order_count'] ) ? (int) $wc_stats['order_count'] : 0;
            $total_spend       = isset( $wc_stats['total_spend'] ) ? (float) $wc_stats['total_spend'] : 0.0;
            $last_completed_ts = isset( $wc_stats['last_completed_ts'] ) ? (int) $wc_stats['last_completed_ts'] : 0;

            $now_ts = time();

            $catalogs          = self::get_tag_catalogs();
            $lifecycle_catalog = isset( $catalogs['lifecycle'] ) ? $catalogs['lifecycle'] : array();

            // Map logical lifecycle states to tag slugs.
            $map = self::get_lifecycle_tag_map();

            // Lifecycle tags we manage automatically (only if present in the lifecycle catalog).
            $managed = array();
            foreach ( array( 'new_customer', 'repeat_customer', 'high_value', 'vip_customer', 'recent_buyer', 'lapsed_customer' ) as $state_key ) {
                if ( ! empty( $map[ $state_key ] ) && in_array( $map[ $state_key ], $lifecycle_catalog, true ) ) {
                    $managed[ $state_key ] = $map[ $state_key ];
                }
            }

            if ( empty( $managed ) ) {
                return;
            }

            $managed_values = array_values( $managed );

            $existing_tags = self::get_tags_for_subscriber( $subscriber->id );

            // Remove managed lifecycle tags before re-applying based on current stats.
            $new_tags = array();
            foreach ( $existing_tags as $tag ) {
                if ( ! in_array( $tag, $managed_values, true ) ) {
                    $new_tags[] = $tag;
                }
            }

            // Determine the PRIMARY lifecycle state (mutually exclusive).
            // Only one of: new_customer, repeat_customer, lapsed_customer should be present.
            $primary_state = '';
            if ( $order_count >= 2 && isset( $managed['repeat_customer'] ) ) {
                $primary_state = 'repeat_customer';
            } elseif ( $order_count >= 1 && isset( $managed['new_customer'] ) ) {
                $primary_state = 'new_customer';
            }

            // Lapsed overrides new/repeat (only if there has been at least one completed order).
            $lapsed_days = absint( PMCPC_Settings::get( 'lifecycle_lapsed_days', '180' ) );
            if ( $lapsed_days > 0 && $last_completed_ts > 0 && ( $now_ts - $last_completed_ts ) >= ( $lapsed_days * DAY_IN_SECONDS ) && isset( $managed['lapsed_customer'] ) ) {
                $primary_state = 'lapsed_customer';
            }

            if ( $primary_state && isset( $managed[ $primary_state ] ) ) {
                $new_tags[] = $managed[ $primary_state ];
            }

            $threshold_raw = PMCPC_Settings::get( 'lifecycle_high_value_threshold', '0' );
            $threshold     = (float) $threshold_raw;
            if ( $threshold > 0 && $total_spend >= $threshold && isset( $managed['high_value'] ) ) {
                $new_tags[] = $managed['high_value'];
            }

            // VIP: higher lifetime spend threshold.
            $vip_threshold_raw = PMCPC_Settings::get( 'lifecycle_vip_threshold', '0' );
            $vip_threshold     = (float) $vip_threshold_raw;
            if ( $vip_threshold > 0 && $total_spend >= $vip_threshold && isset( $managed['vip_customer'] ) ) {
                $new_tags[] = $managed['vip_customer'];
            }

            // Recent buyer is an ATTRIBUTE tag (can coexist with the primary state),
            // but it should never coexist with the lapsed primary state.
            $recent_days = absint( PMCPC_Settings::get( 'lifecycle_recent_days', '90' ) );
            if ( 'lapsed_customer' !== $primary_state && $recent_days > 0 && $last_completed_ts > 0 && ( $now_ts - $last_completed_ts ) <= ( $recent_days * DAY_IN_SECONDS ) && isset( $managed['recent_buyer'] ) ) {
                $new_tags[] = $managed['recent_buyer'];
            }

            // Ensure no conflicting primary state tags remain (defensive; managed tags were removed earlier).
            if ( isset( $managed['new_customer'], $managed['repeat_customer'], $managed['lapsed_customer'] ) ) {
                $state_tags = array_filter(
                    array(
                        $managed['new_customer'] ?? null,
                        $managed['repeat_customer'] ?? null,
                        $managed['lapsed_customer'] ?? null,
                    )
                );
                // If more than one slipped in, keep only the chosen primary state.
                if ( $primary_state && isset( $managed[ $primary_state ] ) ) {
                    $keep = $managed[ $primary_state ];
                    foreach ( $state_tags as $st ) {
                        if ( $st !== $keep ) {
                            $new_tags = array_diff( $new_tags, array( $st ) );
                        }
                    }
                }
            }

            $new_tags = array_values( array_unique( $new_tags ) );

            if ( method_exists( __CLASS__, 'set_tags_for_subscriber' ) ) {
                self::set_tags_for_subscriber( $subscriber->id, $new_tags );
            }
        }

        /**
         * Force-update lifecycle tags for a subscriber, bypassing the "auto enabled" setting.
         *
         * Intended for use by admin repair tools (backfills).
         */
        public static function update_lifecycle_for_email_force( $email ) {
            $email = sanitize_email( $email );
            if ( ! $email || ! is_email( $email ) ) {
                return;
            }

            // Use WooCommerce APIs to derive order stats.
            if ( ! function_exists( 'wc_get_orders' ) ) {
                return;
            }

            $subscriber = self::get_subscriber_by_email( $email );
            if ( ! $subscriber || empty( $subscriber->id ) ) {
                return;
            }

            // Fetch all completed orders for this billing email.
            $orders = wc_get_orders(
                array(
                    'status'        => array( 'completed' ),
                    'limit'         => -1,
                    'billing_email' => $email,
                    'return'        => 'ids',
                )
            );

            if ( ! is_array( $orders ) ) {
                $orders = array();
            }

            $order_count = count( $orders );
            $total_spend = 0.0;
            $last_completed_ts = 0;

            foreach ( $orders as $order_id ) {
                $order = wc_get_order( $order_id );
                if ( ! $order ) {
                    continue;
                }
                $total_spend += (float) $order->get_total();

                // Track the most recent completed date.
                $completed = $order->get_date_completed();
                if ( $completed ) {
                    $ts = (int) $completed->getTimestamp();
                    if ( $ts > $last_completed_ts ) {
                        $last_completed_ts = $ts;
                    }
                }
            }

            $now_ts = time();

            $catalogs          = self::get_tag_catalogs();
            $lifecycle_catalog = isset( $catalogs['lifecycle'] ) ? $catalogs['lifecycle'] : array();

            // Map logical lifecycle states to tag slugs.
            $map = self::get_lifecycle_tag_map();

            $managed = array();
            foreach ( array( 'new_customer', 'repeat_customer', 'high_value', 'vip_customer', 'recent_buyer', 'lapsed_customer' ) as $state_key ) {
                if ( ! empty( $map[ $state_key ] ) && in_array( $map[ $state_key ], $lifecycle_catalog, true ) ) {
                    $managed[ $state_key ] = $map[ $state_key ];
                }
            }
            if ( empty( $managed ) ) {
                return;
            }

            $managed_values = array_values( $managed );
            $existing_tags  = self::get_tags_for_subscriber( $subscriber->id );

            // Remove managed lifecycle tags before re-applying based on current stats.
            $new_tags = array();
            foreach ( $existing_tags as $tag ) {
                if ( ! in_array( $tag, $managed_values, true ) ) {
                    $new_tags[] = $tag;
                }
            }

            // Determine the PRIMARY lifecycle state (mutually exclusive).
            // Only one of: new_customer, repeat_customer, lapsed_customer should be present.
            $primary_state = '';
            if ( $order_count >= 2 && isset( $managed['repeat_customer'] ) ) {
                $primary_state = 'repeat_customer';
            } elseif ( $order_count >= 1 && isset( $managed['new_customer'] ) ) {
                $primary_state = 'new_customer';
            }

            // Lapsed overrides new/repeat (only if there has been at least one completed order).
            $lapsed_days = absint( PMCPC_Settings::get( 'lifecycle_lapsed_days', '180' ) );
            if ( $lapsed_days > 0 && $last_completed_ts > 0 && ( $now_ts - $last_completed_ts ) >= ( $lapsed_days * DAY_IN_SECONDS ) && isset( $managed['lapsed_customer'] ) ) {
                $primary_state = 'lapsed_customer';
            }

            if ( $primary_state && isset( $managed[ $primary_state ] ) ) {
                $new_tags[] = $managed[ $primary_state ];
            }

            $threshold = 0.0;
            if ( class_exists( 'PMCPC_Settings' ) ) {
                $threshold_raw = PMCPC_Settings::get( 'lifecycle_high_value_threshold', '0' );
                $threshold     = (float) $threshold_raw;
            }

            if ( $threshold > 0 && $total_spend >= $threshold && isset( $managed['high_value'] ) ) {
                $new_tags[] = $managed['high_value'];
            }

            // VIP: higher lifetime spend threshold.
            $vip_threshold_raw = PMCPC_Settings::get( 'lifecycle_vip_threshold', '0' );
            $vip_threshold     = (float) $vip_threshold_raw;
            if ( $vip_threshold > 0 && $total_spend >= $vip_threshold && isset( $managed['vip_customer'] ) ) {
                $new_tags[] = $managed['vip_customer'];
            }

            // Recent buyer is an ATTRIBUTE tag (can coexist with the primary state),
            // but it should never coexist with the lapsed primary state.
            $recent_days = absint( PMCPC_Settings::get( 'lifecycle_recent_days', '90' ) );
            if ( 'lapsed_customer' !== $primary_state && $recent_days > 0 && $last_completed_ts > 0 && ( $now_ts - $last_completed_ts ) <= ( $recent_days * DAY_IN_SECONDS ) && isset( $managed['recent_buyer'] ) ) {
                $new_tags[] = $managed['recent_buyer'];
            }

            // Ensure no conflicting primary state tags remain (defensive; managed tags were removed earlier).
            if ( isset( $managed['new_customer'], $managed['repeat_customer'], $managed['lapsed_customer'] ) ) {
                $state_tags = array_filter(
                    array(
                        $managed['new_customer'] ?? null,
                        $managed['repeat_customer'] ?? null,
                        $managed['lapsed_customer'] ?? null,
                    )
                );
                if ( $primary_state && isset( $managed[ $primary_state ] ) ) {
                    $keep = $managed[ $primary_state ];
                    foreach ( $state_tags as $st ) {
                        if ( $st !== $keep ) {
                            $new_tags = array_diff( $new_tags, array( $st ) );
                        }
                    }
                }
            }

            $new_tags = array_values( array_unique( $new_tags ) );
            if ( method_exists( __CLASS__, 'set_tags_for_subscriber' ) ) {
                self::set_tags_for_subscriber( $subscriber->id, $new_tags );
            }
        }

    public static function set_tags_for_subscriber( $subscriber_id, $tags ) {
            global $wpdb;
    		$tags_table        = $wpdb->prefix . 'pmcpc_subscriber_tags';

    	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $wpdb->delete( $tags_table, array( 'subscriber_id' => $subscriber_id ), array( '%d' ) );

            if ( empty( $tags ) ) {
                return;
            }

            foreach ( $tags as $tag ) {
                if ( '' === $tag ) {
                    continue;
                }
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
                $wpdb->insert(
                    $tags_table,
                    array(
                        'subscriber_id' => $subscriber_id,
                        'tag'           => $tag,
                    ),
                    array( '%d', '%s' )
                );
            }
        }

        /**
         * Append tags for a subscriber without removing existing ones.
         *
         * @param int          $subscriber_id Subscriber ID.
         * @param string|array $tags          Tags to add.
         * @return void
         */
        public static function add_tags_for_subscriber( $subscriber_id, $tags ) {
            $subscriber_id = absint( $subscriber_id );
            if ( ! $subscriber_id || empty( $tags ) ) {
                return;
            }

            if ( ! is_array( $tags ) ) {
                $tags = array( $tags );
            }

            // Normalise tags to strings and drop empties.
            $tags = array_filter( array_map( 'strval', $tags ) );
            if ( empty( $tags ) ) {
                return;
            }

            $existing = self::get_tags_for_subscriber( $subscriber_id );
            if ( ! is_array( $existing ) ) {
                $existing = array();
            }

            $merged = array_unique( array_merge( $existing, $tags ) );
            self::set_tags_for_subscriber( $subscriber_id, $merged );
        }

        /**
         * Centralised helper for handling opt-ins from different contexts
         * (subscribe forms, checkout, contact/selling forms, etc).
         *
         * This does not send any emails itself – callers are responsible for
         * sending double opt-in or welcome emails. It only handles the subscriber
         * record and tagging.
         *
         * @param array $args Arguments: email (required), first_name, last_name,
         *                    context (subscribe|checkout|contact), status,
         *                    tags (array of extra tags).
         * @return bool True if this created a brand new subscriber, false otherwise.
         */
        public static function handle_opt_in( $args = array() ) {
            $defaults = array(
                'email'      => '',
                'first_name' => '',
                'last_name'  => '',
                'context'    => 'subscribe',
                'status'     => '',       // If empty, defaults to 'active'.
                'tags'       => array(),  // Additional tags to merge in.
    			'skip_spam' => false,
    			'honeypot'  => '',
            );

            if ( function_exists( 'wp_parse_args' ) ) {
                $args = wp_parse_args( $args, $defaults );
            } else {
                $args = array_merge( $defaults, $args );
            }

            $email = isset( $args['email'] ) ? sanitize_email( $args['email'] ) : '';
            if ( ! $email || ! is_email( $email ) ) {
                return false;
            }

            $first_name = isset( $args['first_name'] ) ? self::clean_name( sanitize_text_field( $args['first_name'] ) ) : '';
            $last_name  = isset( $args['last_name'] ) ? self::clean_name( sanitize_text_field( $args['last_name'] ) ) : '';
            $context    = isset( $args['context'] ) ? $args['context'] : 'subscribe';
            $status     = isset( $args['status'] ) ? $args['status'] : '';
    		$skip_spam  = ! empty( $args['skip_spam'] ) || in_array( $context, array( 'admin', 'import' ), true );

    		if ( ! $skip_spam && 'yes' === self::get_spam_setting( 'spam_protection_enabled', 'yes' ) ) {
    			// Honeypot check (only if caller passes it).
    			if ( 'yes' === self::get_spam_setting( 'spam_honeypot_enabled', 'yes' ) && ! empty( $args['honeypot'] ) ) {
    				self::record_spam_block( $email, 'honeypot', $context );
    				return false;
    			}

    			// Rate limiting.
    			if ( self::is_rate_limited() ) {
    				self::record_spam_block( $email, 'rate_limit', $context );
    				return false;
    			}

    			// Blocked domains (user-configured + filters).
    			if ( class_exists( 'PMCPC_Shortcodes' ) && method_exists( 'PMCPC_Shortcodes', 'is_blocked_email_domain' ) ) {
    				if ( PMCPC_Shortcodes::is_blocked_email_domain( $email ) ) {
    					self::record_spam_block( $email, 'blocked_domain', $context );
    					return false;
    				}
    			}

    			// Suspicious TLD.
    			if ( self::is_suspicious_tld( $email ) ) {
    				self::record_spam_block( $email, 'suspicious_tld', $context );
    				return false;
    			}

    			// Name heuristics.
    			if ( ( $first_name || $last_name ) && self::is_spammy_name( $first_name, $last_name ) ) {
    				$policy = self::get_spam_setting( 'spam_name_policy', 'blank' );
    				if ( 'block' === $policy ) {
    					self::record_spam_block( $email, 'spammy_name', $context );
    					return false;
    				}
    				// Otherwise blank the name fields but allow the subscription.
    				$first_name = '';
    				$last_name  = '';
    				self::record_spam_block( $email, 'name_stripped', $context );
    			}
    		}

            if ( '' === $status ) {
                // For now, all contexts that call this helper use immediate active status.
                // Double opt-in flows (e.g. front-end subscribe forms) continue to manage
                // their own 'pending' status + confirmation emails.
                $status = 'active';
            }

            // Create or update subscriber.
            $is_new = self::upsert_subscriber( $email, $first_name, $last_name, $status );

            // Attach tags if we have a subscriber record.
            $subscriber = self::get_subscriber_by_email( $email );
            if ( $subscriber ) {
                $tags = array();

                // Context-based defaults.
                if ( 'checkout' === $context ) {
                    $tags[] = 'checkout-optin';
                    $tags[] = 'customer';
                } elseif ( 'contact' === $context ) {
                    $tags[] = 'contact-optin';
                } elseif ( 'subscribe' === $context ) {
                    $tags[] = 'signup-form';
                }

                // Merge in any explicit tags.
                if ( ! empty( $args['tags'] ) ) {
                    if ( is_array( $args['tags'] ) ) {
                        $tags = array_merge( $tags, $args['tags'] );
                    } else {
                        $tags[] = $args['tags'];
                    }
                }

                if ( ! empty( $tags ) && method_exists( __CLASS__, 'add_tags_for_subscriber' ) ) {
                    self::add_tags_for_subscriber( $subscriber->id, $tags );
                }
            }

            return $is_new;
        }

        public static function get_tags_for_subscriber( $subscriber_id ) {
            global $wpdb;
    		$tags_table        = $wpdb->prefix . 'pmcpc_subscriber_tags';

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    		$rows = $wpdb->get_col(
    			$wpdb->prepare(
    				'SELECT tag FROM %i WHERE subscriber_id = %d ORDER BY tag ASC',
    				$tags_table,
    				$subscriber_id
    			)
    		);

            return $rows ? $rows : array();
        }

        /**
         * Get the standard tag catalogs used for classification in the UI.
         *
         * @return array {
         *     @type array $interest  Tags that represent subscriber interests / preferences.
         *     @type array $source    Tags that represent acquisition / source.
         *     @type array $lifecycle Tags that represent customer lifecycle state.
         * }
         */
        protected static function get_tag_catalogs() {
            // Base catalogs for interests and source. These are currently static but can be filtered.
            $interest = array( 'newsletter', 'product-updates', 'tips' );
            // "Source" tags represent acquisition source (non-origin tags).
            // Keep this list conservative and add new sources as we introduce them.
            $source   = array( 'checkout-optin', 'signup-form', 'email-prefs', 'imported', 'contact-optin', 'wc-registration' );

            // Lifecycle tags can be managed from the settings screen.
            $lifecycle_default = "new-customer\nrepeat-customer\nhigh-value";
            $lifecycle = array();

            if ( class_exists( 'PMCPC_Settings' ) ) {
                $raw = PMCPC_Settings::get( 'lifecycle_tags', $lifecycle_default );
                if ( is_string( $raw ) && '' !== trim( $raw ) ) {
                    $pieces = preg_split( '/[\r\n,]+/', $raw );
                    if ( is_array( $pieces ) ) {
                        foreach ( $pieces as $piece ) {
                            $piece = trim( strtolower( $piece ) );
                            if ( '' !== $piece ) {
                                $lifecycle[] = $piece;
                            }
                        }
                    }
                }
            }

            if ( empty( $lifecycle ) ) {
                $lifecycle = array( 'new-customer', 'repeat-customer', 'high-value', 'vip', 'recent-buyer', 'lapsed-customer' );
            }

            // Origin tags are technical provenance tags (audit trail) stored as `origin:*`.
            // We keep them separate from "source" so acquisition stays clean and filterable.
            $origin = array();

            // Enrich origin catalog with any existing origin tags from the database.
            global $wpdb;
            if ( isset( $wpdb ) ) {
    		$tags_table        = $wpdb->prefix . 'pmcpc_subscriber_tags';
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    			$origin_like = $wpdb->esc_like( 'origin:' ) . '%';
    			$form_like   = $wpdb->esc_like( 'form-' ) . '%';
    			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter, PluginCheck.Security.DirectDB.UnescapedDBParameter
    			$origin_rows = $wpdb->get_col(
    				$wpdb->prepare(
    					"SELECT DISTINCT tag FROM {$tags_table} WHERE tag LIKE %s ORDER BY tag ASC",
    					$origin_like
    				)
    			);
    			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter, PluginCheck.Security.DirectDB.UnescapedDBParameter
    			$form_rows = $wpdb->get_col(
    				$wpdb->prepare(
    					"SELECT DISTINCT tag FROM {$tags_table} WHERE tag LIKE %s ORDER BY tag ASC",
    					$form_like
    				)
    			);

    			$origin_rows = array_merge( (array) $origin_rows, (array) $form_rows );
                if ( ! empty( $origin_rows ) && is_array( $origin_rows ) ) {
                    foreach ( $origin_rows as $origin_tag ) {
                        $origin_tag = sanitize_text_field( $origin_tag );
                        if ( '' !== $origin_tag ) {
                            $origin[] = $origin_tag;
                        }
                    }
                }
            }

            $interest  = array_values( array_unique( $interest ) );
            $source    = array_values( array_unique( $source ) );
            $lifecycle = array_values( array_unique( $lifecycle ) );
            $origin    = array_values( array_unique( $origin ) );

            // Health tags (derived classification).
            $health = array( 'health:hot', 'health:warm', 'health:slipping', 'health:cold' );
            $health = array_values( array_unique( $health ) );

            /**
             * Filter the tag catalogs used throughout the UI.
             *
             * @param array $catalogs {
             *     @type array $interest
             *     @type array $source
             *     @type array $lifecycle
             *     @type array $origin
             * }
             */
            $catalogs = apply_filters(
                'pmcpc_tag_catalogs',
                array(
                    'interest'  => $interest,
                    'source'    => $source,
                    'lifecycle' => $lifecycle,
                    'health'    => $health,
                    'origin'    => $origin,
                )
            );

            return $catalogs;
        }

    	/**
    	 * Split a tag list into buckets used by the Subscribers UI.
    	 *
    	 * Interest tags are user-facing email preference choices and are the only
    	 * tags intended to be edited directly. Source/Lifecycle/Origin/Health are
    	 * system-managed and should be preserved when admins update preferences.
    	 *
    	 * @param array $tags
    	 * @return array{
    	 *   interest:array,
    	 *   source:array,
    	 *   origin:array,
    	 *   lifecycle:array,
    	 *   health:array,
    	 *   profile:array,
    	 *   other:array
    	 * }
    	 */
    	protected static function split_tags( $tags ) {
    		$tags = is_array( $tags ) ? array_values( array_filter( array_map( 'strval', $tags ) ) ) : array();
    		$tags = array_values( array_unique( $tags ) );

    		$catalogs = self::get_tag_catalogs();
    		$interest_catalog  = isset( $catalogs['interest'] ) ? (array) $catalogs['interest'] : array();
    		$source_catalog    = isset( $catalogs['source'] ) ? (array) $catalogs['source'] : array();
    		$lifecycle_catalog = isset( $catalogs['lifecycle'] ) ? (array) $catalogs['lifecycle'] : array();
    		$health_catalog    = isset( $catalogs['health'] ) ? (array) $catalogs['health'] : array();

    		$interest  = array();
    		$source    = array();
    		$origin    = array();
    		$lifecycle = array();
    		$health    = array();
    		$profile   = array();
    		$other     = array();

    		foreach ( $tags as $t ) {
    			$tag = trim( $t );
    			if ( $tag === '' ) {
    				continue;
    			}

    			// Origin tags are technical provenance and signup detail.
    			// - origin:* records a high-level provenance (audit trail)
    			// - form-* records a more specific signup detail (eg which form)
    			if ( strpos( $tag, 'origin:' ) === 0 || strpos( $tag, 'form-' ) === 0 ) {
    				$origin[] = $tag;
    				continue;
    			}

    			// Health tags are stored with a "health:" prefix.
    			if ( strpos( $tag, 'health:' ) === 0 ) {
    				$health[] = $tag;
    				continue;
    			}

    			// Birthday is profile data used by birthday automations, not a preference tag.
    			if ( strpos( strtolower( $tag ), 'birthday:' ) === 0 ) {
    				$profile[] = $tag;
    				continue;
    			}

    			if ( in_array( $tag, $interest_catalog, true ) ) {
    				$interest[] = $tag;
    				continue;
    			}

    			if ( in_array( $tag, $lifecycle_catalog, true ) ) {
    				$lifecycle[] = $tag;
    				continue;
    			}

    			// Source tags (e.g. signup-form) describe how they joined.
    			if ( in_array( $tag, $source_catalog, true ) ) {
    				$source[] = $tag;
    				continue;
    			}

    			// Any remaining tag in the health catalog but without prefix still counts as health.
    			if ( in_array( $tag, $health_catalog, true ) ) {
    				$health[] = $tag;
    				continue;
    			}

    			$other[] = $tag;
    		}

    		// Prevent confusing duplicates where a tag would appear both as a system tag and
    		// as a plain tag (which would then show up under "Other tags").
    		//
    		// Examples:
    		// - origin:spam-release + spam-release
    		// - health:hot + hot
    		// - lifecycle:new-customer + new-customer
    		// - source:contact-form + contact-form
    		if ( ! empty( $other ) ) {
    			$system_norm = array();
    			foreach ( array_merge( $origin, $health, $lifecycle, $source ) as $sys_tag ) {
    				$plain = (string) $sys_tag;
    				$plain = preg_replace( '/^(origin:|health:|lifecycle:|source:)/', '', $plain );
    				$plain = strtolower( trim( $plain ) );
    				if ( $plain !== '' ) {
    					$system_norm[ $plain ] = true;
    				}
    			}

    			if ( ! empty( $system_norm ) ) {
    				$other = array_values(
    					array_filter(
    						$other,
    						static function ( $val ) use ( $system_norm ) {
    							$norm = strtolower( trim( (string) $val ) );
    							return $norm === '' ? false : empty( $system_norm[ $norm ] );
    						}
    					)
    				);
    			}
    		}

    		return array(
    			'interest'  => array_values( array_unique( $interest ) ),
    			'source'    => array_values( array_unique( $source ) ),
    			'origin'    => array_values( array_unique( $origin ) ),
    			'lifecycle' => array_values( array_unique( $lifecycle ) ),
    			'health'    => array_values( array_unique( $health ) ),
    			'profile'   => array_values( array_unique( $profile ) ),
    			'other'     => array_values( array_unique( $other ) ),
    		);
    	}

        /**
         * Map logical lifecycle states to tag slugs based on the Lifecycle tags setting.
         *
         * The first three lines of the Lifecycle tags setting correspond to:
         *  - line 1: new customer
         *  - line 2: repeat customer
         *  - line 3: high-value customer
         *
         * Any additional lines are treated as extra lifecycle tags without
         * built-in automation rules.
         *
         * @return array {
         *     @type string $new_customer
         *     @type string $repeat_customer
         *     @type string $high_value
         *     @type array  $other
         * }
         */
        protected static function get_lifecycle_tag_map() {
            $defaults = array(
                'new_customer'    => 'new-customer',
                'repeat_customer' => 'repeat-customer',
                'high_value'      => 'high-value',
                'vip_customer'     => 'vip',
                'recent_buyer'     => 'recent-buyer',
                'lapsed_customer'  => 'lapsed-customer',
            );

            $catalogs          = self::get_tag_catalogs();
            $lifecycle_catalog = isset( $catalogs['lifecycle'] ) ? $catalogs['lifecycle'] : array();

            $map = array(
                'new_customer'    => $defaults['new_customer'],
                'repeat_customer' => $defaults['repeat_customer'],
                'high_value'      => $defaults['high_value'],
                'vip_customer'    => $defaults['vip_customer'],
                'recent_buyer'    => $defaults['recent_buyer'],
                'lapsed_customer' => $defaults['lapsed_customer'],
                'other'           => array(),
            );

            if ( ! empty( $lifecycle_catalog ) && is_array( $lifecycle_catalog ) ) {
                if ( isset( $lifecycle_catalog[0] ) && '' !== $lifecycle_catalog[0] ) {
                    $map['new_customer'] = $lifecycle_catalog[0];
                }
                if ( isset( $lifecycle_catalog[1] ) && '' !== $lifecycle_catalog[1] ) {
                    $map['repeat_customer'] = $lifecycle_catalog[1];
                }
                if ( isset( $lifecycle_catalog[2] ) && '' !== $lifecycle_catalog[2] ) {
                    $map['high_value'] = $lifecycle_catalog[2];
                }
                if ( isset( $lifecycle_catalog[3] ) && '' !== $lifecycle_catalog[3] ) {
                    $map['vip_customer'] = $lifecycle_catalog[3];
                }
                if ( isset( $lifecycle_catalog[4] ) && '' !== $lifecycle_catalog[4] ) {
                    $map['recent_buyer'] = $lifecycle_catalog[4];
                }
                if ( isset( $lifecycle_catalog[5] ) && '' !== $lifecycle_catalog[5] ) {
                    $map['lapsed_customer'] = $lifecycle_catalog[5];
                }
                if ( count( $lifecycle_catalog ) > 6 ) {
                    $map['other'] = array_slice( $lifecycle_catalog, 6 );
                }
            }

            return $map;
        }

    	/**
    	 * Lightweight KPI snapshot for the Subscribers list page.
    	 *
    	 * Uses a short-lived cache to avoid extra load on every refresh.
    	 *
    	 * @return array<int,array{label:string,value:string,sub?:string}>
    	 */
    	
    	
    	protected static function get_subscriber_kpis() {
    		$cache_key = 'pmcpc_subscriber_kpis_' . get_current_blog_id();

    		$cached = wp_cache_get( $cache_key, 'pmcpc' );
    		if ( is_array( $cached ) ) {
    			return $cached;
    		}

    		$transient_key = $cache_key;
    		$cached_t      = get_transient( $transient_key );
    		if ( is_array( $cached_t ) ) {
    			wp_cache_set( $cache_key, $cached_t, 'pmcpc', 120 );
    			return $cached_t;
    		}

    		global $wpdb;
    		$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
    		$tags_table        = $wpdb->prefix . 'pmcpc_subscriber_tags';

    		$lifecycle_map  = self::get_lifecycle_tag_map();
    		$lifecycle_tags = array_values(
    			array_filter(
    				array_unique(
    					array_merge(
    						array(
    							(string) $lifecycle_map['new_customer'],
    							(string) $lifecycle_map['repeat_customer'],
    							(string) $lifecycle_map['high_value'],
    							(string) $lifecycle_map['vip_customer'],
    							(string) $lifecycle_map['recent_buyer'],
    							(string) $lifecycle_map['lapsed_customer'],
    						),
    						(array) $lifecycle_map['other']
    					)
    				)
    			)
    		);

    		// Cutoffs.
    		$cutoff_30d = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
    		$cutoff_60d = gmdate( 'Y-m-d H:i:s', time() - 60 * DAY_IN_SECONDS );
    		$cutoff_90d = gmdate( 'Y-m-d H:i:s', time() - 90 * DAY_IN_SECONDS );

    		// Totals.
    		$total   = (int) $wpdb->get_var( "SELECT COUNT(1) FROM {$subscribers_table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    		$active  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(1) FROM {$subscribers_table} WHERE status = %s", 'active' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    		$pending = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(1) FROM {$subscribers_table} WHERE status = %s", 'pending' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    		$unsub   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(1) FROM {$subscribers_table} WHERE status = %s", 'unsubscribed' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

    		// New subscribers.
    		$new_30d = (int) $wpdb->get_var(
    			$wpdb->prepare(
    				"SELECT COUNT(1) FROM {$subscribers_table} WHERE created_at >= %s",
    				$cutoff_30d
    			)
    		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

    		$new_prev_30d = (int) $wpdb->get_var(
    			$wpdb->prepare(
    				"SELECT COUNT(1) FROM {$subscribers_table} WHERE created_at >= %s AND created_at < %s",
    				$cutoff_60d,
    				$cutoff_30d
    			)
    		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

    		// Engaged.
    		$engaged_30d = (int) $wpdb->get_var(
    			$wpdb->prepare(
    				"SELECT COUNT(1) FROM {$subscribers_table} WHERE status = %s AND last_engaged_at IS NOT NULL AND last_engaged_at >= %s",
    				'active',
    				$cutoff_30d
    			)
    		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

    		$engaged_prev_30d = (int) $wpdb->get_var(
    			$wpdb->prepare(
    				"SELECT COUNT(1) FROM {$subscribers_table} WHERE status = %s AND last_engaged_at IS NOT NULL AND last_engaged_at >= %s AND last_engaged_at < %s",
    				'active',
    				$cutoff_60d,
    				$cutoff_30d
    			)
    		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

    		// Inactive (90d).
    		$inactive_90d = (int) $wpdb->get_var(
    			$wpdb->prepare(
    				"SELECT COUNT(1) FROM {$subscribers_table} WHERE status = %s AND ( last_engaged_at IS NULL OR last_engaged_at < %s )",
    				'active',
    				$cutoff_90d
    			)
    		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

    		// Unsubs (30d) - relies on updated_at.
    		$unsubs_30d = 0;
    		$col_exists = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$subscribers_table} LIKE %s", 'updated_at' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    		if ( ! empty( $col_exists ) ) {
    			$unsubs_30d = (int) $wpdb->get_var(
    				$wpdb->prepare(
    					"SELECT COUNT(1) FROM {$subscribers_table} WHERE status = %s AND updated_at >= %s",
    					'unsubscribed',
    					$cutoff_30d
    				)
    			); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    		}

    		// Customers.
    		$customers = 0;
    		if ( ! empty( $lifecycle_tags ) ) {
    			$placeholders = implode( ',', array_fill( 0, count( $lifecycle_tags ), '%s' ) );
    			$sql          = "SELECT COUNT(DISTINCT subscriber_id) FROM {$tags_table} WHERE tag IN ({$placeholders})";
    			$prepared     = $wpdb->prepare( $sql, $lifecycle_tags ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    			$customers    = (int) $wpdb->get_var( $prepared ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    		}

    		// Health snapshot.
    		$hot  = 0;
    		$warm = 0;
    		$cold = 0;
    		$health_rows = $wpdb->get_results(
    			$wpdb->prepare(
    				"SELECT tag, COUNT(DISTINCT subscriber_id) AS c FROM {$tags_table} WHERE tag IN (%s,%s,%s,%s) GROUP BY tag",
    				'health:hot',
    				'health:warm',
    				'health:slipping',
    				'health:cold'
    			),
    			ARRAY_A
    		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    		if ( is_array( $health_rows ) ) {
    			foreach ( $health_rows as $row ) {
    				$tag = isset( $row['tag'] ) ? (string) $row['tag'] : '';
    				$c   = isset( $row['c'] ) ? (int) $row['c'] : 0;
    				if ( 'health:hot' === $tag ) {
    					$hot = $c;
    				} elseif ( 'health:warm' === $tag || 'health:slipping' === $tag ) {
    					$warm += $c;
    				} elseif ( 'health:cold' === $tag ) {
    					$cold = $c;
    				}
    			}
    		}

    		// Back-compat aliases used by earlier KPI templates.
    		$hot_total  = $hot;
    		$warm_total = $warm;
    		$cold_total = $cold;

    		$trend_meta = static function( $current, $previous ) {
    			$current  = (int) $current;
    			$previous = (int) $previous;
    			$delta    = $current - $previous;

    			$sign = ( 0 === $delta ) ? '→' : ( $delta > 0 ? '↑' : '↓' );
    			$abs  = abs( $delta );
    			$pct  = ( $previous > 0 ) ? round( ( $delta / $previous ) * 100 ) : ( $current > 0 ? 100 : 0 );

    			return sprintf(
    				/* translators: 1: arrow, 2: absolute change, 3: percent */
    				__( '%1$s %2$s (%3$s%%) vs prev 30d', 'product-mailer-campaigns' ),
    				$sign,
    				number_format_i18n( $abs ),
    				esc_html( (string) $pct )
    			);
    		};

    		$new_trend    = $trend_meta( $new_30d, $new_prev_30d );
    		$eng_trend    = $trend_meta( $engaged_30d, $engaged_prev_30d );

    		$base_url = admin_url( 'admin.php?page=pmcpc_subscribers' );

    		$kpis = array(
    			array(
    				'label' => __( 'Total contacts', 'product-mailer-campaigns' ),
    				'value' => number_format_i18n( $total ),
    				'sub'   => sprintf( __( 'Active %1$s · Pending %2$s · Unsub %3$s', 'product-mailer-campaigns' ), number_format_i18n( $active ), number_format_i18n( $pending ), number_format_i18n( $unsub ) ),
    				'link'  => $base_url,
    			),
    			array(
    				'label' => __( 'New contacts (30d)', 'product-mailer-campaigns' ),
    				'value' => number_format_i18n( $new_30d ),
    				'sub'   => $new_trend,
    				'link'  => add_query_arg( array( 'pmcpc_quick_filter' => 'new_30' ), $base_url ),
    			),
    			array(
    				'label' => __( 'Customers', 'product-mailer-campaigns' ),
    				'value' => number_format_i18n( $customers ),
    				'sub'   => __( 'Based on lifecycle tags', 'product-mailer-campaigns' ),
    				'link'  => add_query_arg( array( 'pmcpc_customer_type' => 'customer' ), $base_url ),
    			),
    			array(
    				'label' => __( 'Engaged (30d)', 'product-mailer-campaigns' ),
    				'value' => number_format_i18n( $engaged_30d ),
    				'sub'   => $eng_trend,
    				'link'  => add_query_arg( array( 'pmcpc_quick_filter' => 'engaged_30' ), $base_url ),
    			),
    			array(
    				'label' => __( 'Inactive (90d)', 'product-mailer-campaigns' ),
    				'value' => number_format_i18n( $inactive_90d ),
    				'sub'   => __( 'Active but no engagement', 'product-mailer-campaigns' ),
    				'link'  => add_query_arg( array( 'pmcpc_quick_filter' => 'at_risk_90' ), $base_url ),
    			),
    			array(
    				'label' => __( 'Unsubscribed (30d)', 'product-mailer-campaigns' ),
    				'value' => number_format_i18n( $unsubs_30d ),
    				'sub'   => __( 'Status changed to unsubscribed', 'product-mailer-campaigns' ),
    				'link'  => add_query_arg( array( 'pmcpc_quick_filter' => 'unsubs_30' ), $base_url ),
    			),
    			array(
    				'label' => __( 'Health: Hot', 'product-mailer-campaigns' ),
    				'value' => number_format_i18n( $hot ),
    				'sub'   => sprintf( __( 'Warm %1$s · Cold %2$s', 'product-mailer-campaigns' ), number_format_i18n( $warm ), number_format_i18n( $cold ) ),
    				'link'  => add_query_arg( array( 'pmcpc_health' => 'health:hot' ), $base_url ),
    			),
    		);

    		wp_cache_set( $cache_key, $kpis, 'pmcpc', 120 );
    		set_transient( $transient_key, $kpis, 120 );

    		return $kpis;
    	}

}
