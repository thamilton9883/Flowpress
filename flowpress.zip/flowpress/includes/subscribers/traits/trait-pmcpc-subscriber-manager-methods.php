<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/trait-pmcpc-subscriber-manager-spam-methods.php';
require_once __DIR__ . '/trait-pmcpc-subscriber-manager-admin-methods.php';
require_once __DIR__ . '/trait-pmcpc-subscriber-manager-crm-methods.php';
require_once __DIR__ . '/trait-pmcpc-subscriber-manager-data-methods.php';
require_once __DIR__ . '/trait-pmcpc-subscriber-manager-render-methods.php';
require_once __DIR__ . '/trait-pmcpc-subscriber-manager-maintenance-methods.php';

trait PMCPC_Subscriber_Manager_Methods {
    use PMCPC_Subscriber_Manager_Spam_Methods;
    use PMCPC_Subscriber_Manager_Admin_Methods;
    use PMCPC_Subscriber_Manager_Crm_Methods;
    use PMCPC_Subscriber_Manager_Data_Methods;
    use PMCPC_Subscriber_Manager_Render_Methods;
    use PMCPC_Subscriber_Manager_Maintenance_Methods;
}
