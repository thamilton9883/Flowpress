<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Subscriber_Manager_Crm_Methods {
        /**
         * Parse a birthday-like value into canonical parts.
         *
         * Accepted input examples:
         * - 2022-12-07
         * - 07/12/2022
         * - 07/12
         * - 12-07
         * - 07 Dec
         * - 7 December 2022
         * - December 7 2022
         *
         * Returned month/day are always integers. Missing years are normalised to 2000.
         *
         * @param string $raw Raw birthday value.
         * @return array{year:int,month:int,day:int,time:string}
         */
        public static function parse_birthday_parts( $raw ) {
            $result = array(
                'year'  => 0,
                'month' => 0,
                'day'   => 0,
                'time'  => '09:00:00',
            );

            $raw = trim( (string) $raw );
            if ( '' === $raw ) {
                return $result;
            }

            $raw = preg_replace( '/\s+/', ' ', $raw );

            $match = static function( $year, $month, $day, $time = '09:00:00' ) use ( &$result ) {
                $year  = (int) $year;
                $month = (int) $month;
                $day   = (int) $day;
                if ( $year <= 0 ) {
                    $year = 2000;
                }
                if ( checkdate( $month, $day, $year ) ) {
                    $result['year']  = $year;
                    $result['month'] = $month;
                    $result['day']   = $day;
                    if ( is_string( $time ) && preg_match( '/^\d{2}:\d{2}:\d{2}$/', $time ) ) {
                        $result['time'] = $time;
                    }
                }
                return $result;
            };

            if ( preg_match( '/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{2}:\d{2}:\d{2}))?$/', $raw, $m ) ) {
                return $match( $m[1], $m[2], $m[3], ! empty( $m[4] ) ? $m[4] : '09:00:00' );
            }

            if ( preg_match( '/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $raw, $m ) ) {
                return $match( $m[3], $m[2], $m[1] );
            }

            if ( preg_match( '/^(\d{1,2})\/(\d{1,2})$/', $raw, $m ) ) {
                return $match( 2000, $m[2], $m[1] );
            }

            if ( preg_match( '/^(\d{1,2})-(\d{1,2})$/', $raw, $m ) ) {
                return $match( 2000, $m[1], $m[2] );
            }

            if ( preg_match( '/^(\d{1,2})\s+([A-Za-z]{3,9})(?:\s+(\d{4}))?$/', $raw, $m ) ) {
                $parsed = date_parse( '1 ' . $m[2] . ' 2000' );
                if ( ! empty( $parsed['month'] ) ) {
                    return $match( ! empty( $m[3] ) ? $m[3] : 2000, $parsed['month'], $m[1] );
                }
            }

            if ( preg_match( '/^([A-Za-z]{3,9})\s+(\d{1,2})(?:,?\s+(\d{4}))?$/', $raw, $m ) ) {
                $parsed = date_parse( '1 ' . $m[1] . ' 2000' );
                if ( ! empty( $parsed['month'] ) ) {
                    return $match( ! empty( $m[3] ) ? $m[3] : 2000, $parsed['month'], $m[2] );
                }
            }

            $timestamp = strtotime( $raw );
            if ( $timestamp ) {
                return $match( gmdate( 'Y', $timestamp ), gmdate( 'n', $timestamp ), gmdate( 'j', $timestamp ), gmdate( 'H:i:s', $timestamp ) );
            }

            return $result;
        }

        /**
         * Normalise a birthday value to YYYY-MM-DD.
         *
         * @param string $raw Raw posted value.
         * @return string
         */
        protected static function sanitize_birthday_value( $raw ) {
            $parts = self::parse_birthday_parts( $raw );
            if ( empty( $parts['month'] ) || empty( $parts['day'] ) ) {
                return '';
            }
            return sprintf( '%04d-%02d-%02d', (int) $parts['year'], (int) $parts['month'], (int) $parts['day'] );
        }

        /**
         * Return the saved birthday for a subscriber, if available.
         *
         * @param int $subscriber_id Subscriber ID.
         * @return string
         */
        public static function get_subscriber_birthday( $subscriber_id ) {
            $subscriber_id = absint( $subscriber_id );
            if ( ! $subscriber_id ) {
                return '';
            }

            $tags = self::get_tags_for_subscriber( $subscriber_id );
            if ( is_array( $tags ) ) {
                foreach ( $tags as $tag ) {
                    $tag = trim( (string) $tag );
                    if ( 0 !== strpos( strtolower( $tag ), 'birthday:' ) ) {
                        continue;
                    }

                    $birthday = self::sanitize_birthday_value( substr( $tag, 9 ) );
                    if ( '' !== $birthday ) {
                        return $birthday;
                    }
                }
            }

            global $wpdb;
            $subs_table = $wpdb->prefix . 'pmcpc_subscribers';
            $email      = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT email FROM %i WHERE id = %d', $subs_table, $subscriber_id ) );
            if ( $email && function_exists( 'get_user_by' ) ) {
                $user = get_user_by( 'email', $email );
                if ( $user && ! empty( $user->ID ) ) {
                    foreach ( array( 'pmcpc_birthday', 'birthday', 'birthdate' ) as $meta_key ) {
                        $birthday = self::sanitize_birthday_value( (string) get_user_meta( (int) $user->ID, $meta_key, true ) );
                        if ( '' !== $birthday ) {
                            return $birthday;
                        }
                    }
                }
            }

            return '';
        }

        /**
         * Persist the birthday for a subscriber using a birthday tag and matching user meta.
         *
         * @param int    $subscriber_id Subscriber ID.
         * @param string $birthday      Birthday string.
         * @return bool
         */
        public static function set_subscriber_birthday( $subscriber_id, $birthday ) {
            $subscriber_id = absint( $subscriber_id );
            if ( ! $subscriber_id ) {
                return false;
            }

            $birthday = self::sanitize_birthday_value( $birthday );
            $tags     = self::get_tags_for_subscriber( $subscriber_id );
            if ( ! is_array( $tags ) ) {
                $tags = array();
            }

            $tags = array_values(
                array_filter(
                    array_map( 'trim', $tags ),
                    static function( $tag ) {
                        return '' !== (string) $tag && 0 !== strpos( strtolower( (string) $tag ), 'birthday:' );
                    }
                )
            );

            if ( '' !== $birthday ) {
                $tags[] = 'birthday:' . $birthday;
            }

            self::set_tags_for_subscriber( $subscriber_id, array_values( array_unique( $tags ) ) );

            global $wpdb;
            $subs_table = $wpdb->prefix . 'pmcpc_subscribers';
            $email      = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT email FROM %i WHERE id = %d', $subs_table, $subscriber_id ) );
            if ( $email && function_exists( 'get_user_by' ) ) {
                $user = get_user_by( 'email', $email );
                if ( $user && ! empty( $user->ID ) ) {
                    if ( '' === $birthday ) {
                        delete_user_meta( (int) $user->ID, 'pmcpc_birthday' );
                    } else {
                        update_user_meta( (int) $user->ID, 'pmcpc_birthday', $birthday );
                    }
                }
            }

            return true;
        }

        /**
         * Parse editable CRM tags from the subscriber form.
         *
         * @param string $tags Raw CSV tags.
         * @return array
         */
        protected static function pmcpc_get_crm_form_tags( $tags ) {
            if ( '' === trim( (string) $tags ) ) {
                return array();
            }

            return array_values(
                array_filter(
                    array_map(
                        static function ( $tag ) {
                            return sanitize_text_field( (string) $tag );
                        },
                        array_map( 'trim', explode( ',', (string) $tags ) )
                    )
                )
            );
        }

        /**
         * Merge editable CRM tags with preserved system-managed tags.
         *
         * @param int   $subscriber_id Subscriber ID.
         * @param array $tags_arr      Editable admin tags.
         * @return array
         */
        protected static function pmcpc_merge_crm_tags_with_preserved_tags( $subscriber_id, array $tags_arr ) {
            if ( ! method_exists( __CLASS__, 'get_tags_for_subscriber' ) || ! method_exists( __CLASS__, 'split_tags' ) ) {
                return $tags_arr;
            }

            $existing_tags = self::get_tags_for_subscriber( $subscriber_id );
            $buckets       = self::split_tags( $existing_tags );
            $preserve      = array_merge(
                $buckets['interest'],
                $buckets['source'],
                $buckets['origin'],
                $buckets['lifecycle'],
                $buckets['health'],
                $buckets['profile']
            );

            return array_values( array_unique( array_merge( $preserve, $tags_arr ) ) );
        }

        /**
         * Handle updates from the CRM-style subscriber screen (status + tags).
         *
         * @param int $subscriber_id Subscriber ID.
         */
        protected function handle_subscriber_crm_update( $subscriber_id ) {
            if ( ! current_user_can( 'manage_options' ) || ! $subscriber_id ) {
                return;
            }

    		$status   = isset( $_POST['pmcpc_status'] ) ? self::pmcpc_normalize_subscriber_status( wp_unslash( $_POST['pmcpc_status'] ) ) : '';
    		$tags     = isset( $_POST['pmcpc_tags'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_tags'] ) ) : '';
    		$birthday = isset( $_POST['pmcpc_birthday'] ) ? self::sanitize_birthday_value( sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_birthday'] ) ) ) : '';

            if ( $status ) {
                self::update_status( $subscriber_id, $status );
            }

            $tags_arr = self::pmcpc_get_crm_form_tags( $tags );
            $tags_arr = self::pmcpc_merge_crm_tags_with_preserved_tags( $subscriber_id, $tags_arr );

            if ( method_exists( __CLASS__, 'set_tags_for_subscriber' ) ) {
                self::set_tags_for_subscriber( $subscriber_id, $tags_arr );
            }

            self::set_subscriber_birthday( $subscriber_id, $birthday );

            add_settings_error(
                'pmcpc_subscribers',
                'pmcpc_subscriber_crm_updated',
                __( 'Subscriber updated.', 'product-mailer-campaigns' ),
                'updated'
            );
        }

        /**
         * Import WordPress users as subscribers.
         *
         * Creates or updates PMCPC subscribers based on existing WP users.
         */
        protected function import_wp_users() {
            if ( ! current_user_can( 'list_users' ) ) {
                return;
            }

            if ( ! class_exists( 'WP_User_Query' ) ) {
                return;
            }

            $roles = array();

    			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized in the loop below.
    			$roles_raw = isset( $_POST['pmcpc_import_roles'] ) ? (array) wp_unslash( $_POST['pmcpc_import_roles'] ) : array();
    			if ( is_array( $roles_raw ) ) {
    				foreach ( $roles_raw as $role ) {
    					$role = sanitize_key( wp_unslash( (string) $role ) );
    					if ( '' !== $role ) {
    						$roles[] = $role;
    					}
    				}
    			}

            if ( empty( $roles ) ) {
                $roles = array( 'customer', 'subscriber' );
            }

            /**
             * Filter the roles that will be imported as subscribers.
             *
             * @param array $roles Role slugs to include in the import.
             */
            $roles = apply_filters( 'pmcpc_import_user_roles', $roles );

            $args = array(
                'role__in' => $roles,
                'fields'   => array( 'ID', 'user_email', 'display_name' ),
                'number'   => -1,
            );

            $user_query = new WP_User_Query( $args );
            $users      = $user_query->get_results();

            if ( empty( $users ) ) {
                add_settings_error(
                    'pmcpc_subscribers',
                    'pmcpc_import_no_users',
                    __( 'No matching WordPress users found for import.', 'product-mailer-campaigns' ),
                    'updated'
                );
                return;
            }

            $created = 0;
            $updated = 0;
            $skipped = 0;

            foreach ( $users as $user ) {
                $email = isset( $user->user_email ) ? sanitize_email( $user->user_email ) : '';

                if ( ! $email || ! is_email( $email ) ) {
                    $skipped++;
                    continue;
                }

                $first_name = get_user_meta( $user->ID, 'first_name', true );
                $last_name  = get_user_meta( $user->ID, 'last_name', true );

                if ( '' === $first_name && '' === $last_name ) {
                    $first_name = $user->display_name;
                }

                $is_new = self::upsert_subscriber( $email, $first_name, $last_name, 'active' );

                $subscriber = self::get_subscriber_by_email( $email );
                if ( $subscriber && ! empty( $subscriber->id ) && method_exists( __CLASS__, 'get_tags_for_subscriber' ) && method_exists( __CLASS__, 'set_tags_for_subscriber' ) ) {
                    $existing_tags = self::get_tags_for_subscriber( $subscriber->id );
                    if ( ! in_array( 'imported', $existing_tags, true ) ) {
                        $existing_tags[] = 'imported';
                        self::set_tags_for_subscriber( $subscriber->id, $existing_tags );
                    }
                }

                if ( $is_new ) {
                    $created++;
                } else {
                    $updated++;
                }
            }

    	        $message = sprintf(
    	            /* translators: 1: number of created subscribers, 2: updated, 3: skipped. */
    	            __( 'Import complete: %1$d created, %2$d updated, %3$d skipped.', 'product-mailer-campaigns' ),
                $created,
                $updated,
                $skipped
            );

            add_settings_error(
                'pmcpc_subscribers',
                'pmcpc_import_users_done',
                $message,
                'updated'
            );
        }

        /**
         * Backfill "source" tags from existing origin:... tags.
         *
         * This is primarily a safety net for legacy installs and imported subscribers
         * where only origin tags were stored.
         *
         * Mapping rules (defaults):
         *  - origin:checkout        -> checkout-optin
         *  - origin:subscribe-form  -> signup-form
         *  - origin:contact-form    -> contact-optin
         *  - origin:wc-registration -> wc-registration
         *  - origin:XYZ             -> XYZ (fallback)
         */
        protected function backfill_source_tags_from_origin() {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            global $wpdb;
    		$subs_table = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );
    		$tags_table = esc_sql( $wpdb->prefix . 'pmcpc_subscriber_tags' );

            // Fetch all origin tags joined to subscribers.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter
                "SELECT t.subscriber_id, t.tag FROM {$tags_table} t INNER JOIN {$subs_table} s ON s.id = t.subscriber_id WHERE t.tag LIKE 'origin:%'"
            );

            if ( empty( $rows ) ) {
                add_settings_error( 'pmcpc_subscribers', 'pmcpc_backfill_source_none', __( 'No origin tags found to backfill.', 'product-mailer-campaigns' ), 'updated' );
                return;
            }

            $map = array(
                'origin:checkout'        => 'checkout-optin',
                'origin:subscribe-form'  => 'signup-form',
                'origin:contact-form'    => 'contact-optin',
                'origin:wc-registration' => 'wc-registration',
            );

            /**
             * Filter the origin->source mapping used by the backfill tool.
             *
             * @param array $map
             */
            $map = apply_filters( 'pmcpc_origin_to_source_map', $map );

            $added   = 0;
            $skipped = 0;

            foreach ( $rows as $row ) {
                $subscriber_id = isset( $row->subscriber_id ) ? absint( $row->subscriber_id ) : 0;
                $origin_tag    = isset( $row->tag ) ? sanitize_text_field( (string) $row->tag ) : '';

                if ( ! $subscriber_id || '' === $origin_tag ) {
                    continue;
                }

                $derived = '';
                if ( isset( $map[ $origin_tag ] ) ) {
                    $derived = sanitize_text_field( (string) $map[ $origin_tag ] );
                } elseif ( 0 === strpos( $origin_tag, 'origin:' ) ) {
                    $derived = sanitize_text_field( substr( $origin_tag, strlen( 'origin:' ) ) );
                }

                $derived = trim( strtolower( $derived ) );
                if ( '' === $derived ) {
                    continue;
                }

                // Ensure the derived source tag exists for the subscriber.
                if ( method_exists( __CLASS__, 'get_tags_for_subscriber' ) && method_exists( __CLASS__, 'add_tags_for_subscriber' ) ) {
                    $existing = self::get_tags_for_subscriber( $subscriber_id );
                    if ( in_array( $derived, $existing, true ) ) {
                        $skipped++;
                        continue;
                    }
                    self::add_tags_for_subscriber( $subscriber_id, array( $derived ) );
                    $added++;
                }
            }

            $message = sprintf(
                /* translators: 1: number of tags added, 2: number skipped */
                __( 'Backfill complete: %1$d source tags added, %2$d already present.', 'product-mailer-campaigns' ),
                (int) $added,
                (int) $skipped
            );

            add_settings_error( 'pmcpc_subscribers', 'pmcpc_backfill_source_done', $message, 'updated' );
        }

        /**
         * Recalculate lifecycle tags for all existing subscribers.
         *
         * @param bool $force If true, run even if lifecycle automation is disabled in settings.
         */
        protected function recalculate_health_tags_for_all( $silent = false ) {
            if ( ! $silent && ! current_user_can( 'manage_options' ) ) {
                return 0;
            }

            global $wpdb;
            $subs_table = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $emails = $wpdb->get_col( "SELECT email FROM {$subs_table} WHERE email <> ''" );
            if ( empty( $emails ) ) {
                if ( ! $silent ) {
                    add_settings_error( 'pmcpc_subscribers', 'pmcpc_recalc_health_none', __( 'No subscribers found to process.', 'product-mailer-campaigns' ), 'updated' );
                }
                update_option( 'pmcpc_health_recalculation_last_run', current_time( 'mysql' ), false );
                update_option( 'pmcpc_health_recalculation_last_count', 0, false );
                return 0;
            }

            $processed = 0;
            foreach ( $emails as $email ) {
                $email = sanitize_email( (string) $email );
                if ( ! $email || ! is_email( $email ) ) {
                    continue;
                }
                self::update_health_for_email( $email );
                $processed++;
            }

            $message = sprintf(
                /* translators: %d: processed subscriber count */
                __( 'Health recalculation complete: %d subscribers processed.', 'product-mailer-campaigns' ),
                (int) $processed
            );
            update_option( 'pmcpc_health_recalculation_last_run', current_time( 'mysql' ), false );
            update_option( 'pmcpc_health_recalculation_last_count', (int) $processed, false );
            if ( ! $silent ) {
                add_settings_error( 'pmcpc_subscribers', 'pmcpc_recalc_health_done', $message, 'updated' );
            }
            return (int) $processed;
        }

        protected function recalculate_lifecycle_tags_for_all( $force = false, $silent = false ) {
            if ( ! $silent && ! current_user_can( 'manage_options' ) ) {
                return 0;
            }

            if ( ! function_exists( 'wc_get_orders' ) ) {
                if ( ! $silent ) {
                    add_settings_error( 'pmcpc_subscribers', 'pmcpc_recalc_lifecycle_no_wc', __( 'WooCommerce is required to recalculate lifecycle tags.', 'product-mailer-campaigns' ), 'error' );
                }
                update_option( 'pmcpc_lifecycle_recalculation_last_run', current_time( 'mysql' ), false );
                update_option( 'pmcpc_lifecycle_recalculation_last_count', 0, false );
                return 0;
            }

            global $wpdb;
    		$subs_table = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $emails = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter
                "SELECT email FROM {$subs_table} WHERE email <> ''" );
            if ( empty( $emails ) ) {
                if ( ! $silent ) {
                    add_settings_error( 'pmcpc_subscribers', 'pmcpc_recalc_lifecycle_none', __( 'No subscribers found to process.', 'product-mailer-campaigns' ), 'updated' );
                }
                update_option( 'pmcpc_lifecycle_recalculation_last_run', current_time( 'mysql' ), false );
                update_option( 'pmcpc_lifecycle_recalculation_last_count', 0, false );
                return 0;
            }

            $processed = 0;
            foreach ( $emails as $email ) {
                $email = sanitize_email( (string) $email );
                if ( ! $email || ! is_email( $email ) ) {
                    continue;
                }
                if ( $force ) {
                    self::update_lifecycle_for_email_force( $email );
                } else {
                    self::update_lifecycle_for_email( $email );
                }
                $processed++;
            }

            $message = sprintf(
                /* translators: %d: processed subscriber count */
                __( 'Lifecycle recalculation complete: %d subscribers processed.', 'product-mailer-campaigns' ),
                (int) $processed
            );
            update_option( 'pmcpc_lifecycle_recalculation_last_run', current_time( 'mysql' ), false );
            update_option( 'pmcpc_lifecycle_recalculation_last_count', (int) $processed, false );
            if ( ! $silent ) {
                add_settings_error( 'pmcpc_subscribers', 'pmcpc_recalc_lifecycle_done', $message, 'updated' );
            }
            return (int) $processed;
        }

}
