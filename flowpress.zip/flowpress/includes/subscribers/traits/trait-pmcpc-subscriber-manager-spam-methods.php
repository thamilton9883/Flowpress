<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Subscriber_Manager_Spam_Methods {
    	/**
    	 * Evaluate spam checks without creating/updating subscribers.
    	 *
    	 * @param array $args { email, first_name, last_name, context, honeypot }
    	 * @return array { allowed: bool, action: string, reason: string }
    	 */
    	public static function evaluate_spam( $args = array() ) {
    		$defaults = array(
    			'email'      => '',
    			'first_name' => '',
    			'last_name'  => '',
    			'context'    => 'subscribe',
    			'honeypot'   => '',
    		);
    		$args  = wp_parse_args( $args, $defaults );
    		$email = sanitize_email( $args['email'] );
    		if ( ! $email || ! is_email( $email ) ) {
    			return array(
    				'allowed' => false,
    				'action'  => 'blocked',
    				'reason'  => 'invalid_email',
    			);
    		}

    		// Allowlist: bypass email/domain/message-scoring blocks for known-good senders.
    		// (Still subject to form integrity checks like honeypots/timing tokens in the shortcode handlers.)
    		if ( self::is_allowlisted_sender( $email ) ) {
    			return array(
    				'allowed' => true,
    				'action'  => 'allowed',
    				'reason'  => 'allowlisted',
    			);
    		}

    		// Explicit email-level block list.
    		if ( self::is_blocked_email_address( $email ) ) {
    			return array(
    				'allowed' => false,
    				'action'  => 'blocked',
    				'reason'  => 'blocked_email',
    			);
    		}

    		$first_name = self::clean_name( sanitize_text_field( $args['first_name'] ) );
    		$last_name  = self::clean_name( sanitize_text_field( $args['last_name'] ) );
    		$context    = sanitize_key( $args['context'] );

    		if ( 'yes' !== self::get_spam_setting( 'spam_protection_enabled', 'yes' ) ) {
    			return array( 'allowed' => true, 'action' => 'allowed', 'reason' => '' );
    		}

    		if ( 'yes' === self::get_spam_setting( 'spam_honeypot_enabled', 'yes' ) && ! empty( $args['honeypot'] ) ) {
    			return array( 'allowed' => false, 'action' => 'blocked', 'reason' => 'honeypot' );
    		}

    		if ( self::peek_rate_limited() ) {
    			return array( 'allowed' => false, 'action' => 'blocked', 'reason' => 'rate_limit' );
    		}

    		if ( class_exists( 'PMCPC_Shortcodes' ) && method_exists( 'PMCPC_Shortcodes', 'is_blocked_email_domain' ) ) {
    			if ( PMCPC_Shortcodes::is_blocked_email_domain( $email ) ) {
    				return array( 'allowed' => false, 'action' => 'blocked', 'reason' => 'blocked_domain' );
    			}
    		}

    		if ( self::is_suspicious_tld( $email ) ) {
    			return array( 'allowed' => false, 'action' => 'blocked', 'reason' => 'suspicious_tld' );
    		}

    			if ( ( $first_name || $last_name ) && self::is_spammy_name( $first_name, $last_name ) ) {
    				$policy = self::get_spam_setting( 'spam_name_policy', 'blank' );
    				if ( 'block' === $policy ) {
    					return array( 'allowed' => false, 'action' => 'blocked', 'reason' => 'spammy_name' );
    				}

    				// For subscribe flows, identical first/last names are a common bot pattern.
    				// Hold these for review instead of sending confirmation emails immediately.
    				if ( 'subscribe' === $context && $first_name && $last_name && strtolower( $first_name ) === strtolower( $last_name ) ) {
    					return array( 'allowed' => false, 'action' => 'held', 'reason' => 'spammy_name' );
    				}

    				return array( 'allowed' => true, 'action' => 'name_stripped', 'reason' => 'spammy_name' );
    			}

    		return array( 'allowed' => true, 'action' => 'allowed', 'reason' => '' );
    	}

    /**
     * Evaluate the message content for spam signals (primarily for contact/selling forms).
     *
     * This complements evaluate_spam() which focuses on email/domain/name + rate limits.
     *
     * @param string $subject Subject line (may be empty).
     * @param string $message Message body.
     * @param string $context Context label, e.g. 'contact' or 'selling'.
     * @return array { allowed: bool, action: string, reason: string, score: int, details: array }
     */
    public static function evaluate_message_spam( $subject, $message, $context = 'contact' ) {
    	$subject = (string) $subject;
    	$message = (string) $message;
    	$context = sanitize_key( (string) $context );

    	// Allow site owners to disable message scoring entirely.
    	if ( class_exists( 'PMCPC_Settings' ) ) {
    		$enabled = PMCPC_Settings::get( 'spam_message_scoring_enabled', 'yes' );
    		if ( 'yes' !== $enabled ) {
    			return array(
    				'allowed' => true,
    				'action'  => 'allowed',
    				'reason'  => '',
    				'score'   => 0,
    				'details' => array( 'disabled' ),
    			);
    		}
    	}

    	$text   = strtolower( wp_strip_all_tags( $subject . "\n" . $message ) );
    	$len    = strlen( $text );
    	$score  = 0;
    	$detail = array();

    	// Link count is one of the strongest predictors of contact-form spam.
    	$links = 0;
    	if ( preg_match_all( '/https?:\\/\\/|www\\./i', $text, $m ) ) {
    		$links = count( $m[0] );
    	}
    	$max_links = 1;
    	if ( class_exists( 'PMCPC_Settings' ) ) {
    		$max_links = (int) PMCPC_Settings::get( 'spam_message_max_links', 1 );
    	}
    	$max_links = (int) apply_filters( 'pmcpc_spam_message_max_links', $max_links, $context );
    	if ( $links > $max_links ) {
    		$score += 4;
    		$detail[] = 'links:' . $links;
    	}

    	// Simple keyword list (filterable) for common adult/seo/casino pitches.
    	// Includes a few high-frequency non-English terms seen in form spam.
    	$keywords = array(
    		'escort', 'sex', 'porn', 'viagra', 'casino', 'bet', 'backlink', 'seo', 'guest post',
    		// Cyrillic casino spam (e.g. "онлайн казино").
    		'казино', 'онлайн казино', 'слоты', 'букмекер', 'ставки',
    		// Common spam tool / footprint.
    		'xrumer', 'xrum',
    	);
    	if ( class_exists( 'PMCPC_Settings' ) ) {
    		$enabled = PMCPC_Settings::get( 'spam_message_keywords_enabled', 'yes' );
    		if ( 'yes' === $enabled ) {
    			$raw = (string) PMCPC_Settings::get( 'spam_message_keywords', '' );
    			$lines = preg_split( '/\r\n|\r|\n/', $raw );
    			$lines = is_array( $lines ) ? array_map( 'trim', $lines ) : array();
    			$lines = array_filter( $lines, function( $v ) { return '' !== $v; } );
    			if ( ! empty( $lines ) ) {
    				$keywords = array_values( $lines );
    			}
    		}
    	}
    	$keywords = (array) apply_filters( 'pmcpc_spam_message_keywords', $keywords, $context );
    	$kw_hit = '';
    	foreach ( $keywords as $kw ) {
    		$kw = strtolower( trim( (string) $kw ) );
    		if ( '' === $kw ) {
    			continue;
    		}
    		if ( false !== strpos( $text, $kw ) ) {
    			$score += 4;
    			$detail[] = 'kw:' . $kw;
    			$kw_hit = $kw;
    			break;
    		}
    	}

    	// High non-ASCII ratio can indicate obfuscation or certain bulk spam patterns.
    	// We evaluate even for relatively short messages, since many casino/SEO bots send ~2 short lines.
    	if ( $len > 10 ) {
    		$ascii = strlen( preg_replace( '/[^\\x20-\\x7E]/', '', $text ) );
    		$ratio = 1 - ( $ascii / max( 1, $len ) );
    		$threshold = 0.30;
    		if ( class_exists( 'PMCPC_Settings' ) ) {
    			$threshold = (float) PMCPC_Settings::get( 'spam_message_non_ascii_threshold', 0.30 );
    		}
    		$threshold = (float) apply_filters( 'pmcpc_spam_message_non_ascii_ratio_threshold', $threshold, $context );
    		if ( $ratio > $threshold ) {
    			// Non-ascii alone is a weak signal; combined with links/keywords it becomes stronger.
    			$score += ( $links > 0 ) ? 3 : 1;
    			if ( '' !== $kw_hit ) {
    				$score += 2;
    				$detail[] = 'kw_non_ascii:' . $kw_hit;
    			}
    			$detail[] = 'non_ascii:' . round( $ratio, 2 );
    		}
    	}

    	// BBCode / markup patterns common in spam, e.g. [url=https://...]...[/url]
    	$markup_enabled = 'yes';
    	if ( class_exists( 'PMCPC_Settings' ) ) {
    		$markup_enabled = PMCPC_Settings::get( 'spam_message_suspicious_markup_enabled', 'yes' );
    	}
    	if ( 'yes' === $markup_enabled ) {
    		if ( false !== strpos( $text, '[url=' ) || false !== strpos( $text, '[/url]' ) ) {
    			$score += 3;
    			$detail[] = 'bbcode_url';
    		}
    		if ( false !== strpos( $text, 'href=' ) ) {
    			$score += 3;
    			$detail[] = 'href';
    		}
    	}

    	// Very short messages are often low-effort spam or failed bots.
    	if ( $len > 0 && $len < 20 ) {
    		$score += 1;
    		$detail[] = 'too_short';
    	}

    	$hold_at  = 3;
    	$block_at = 6;
    	if ( class_exists( 'PMCPC_Settings' ) ) {
    		$hold_at  = (int) PMCPC_Settings::get( 'spam_message_hold_score', 3 );
    		$block_at = (int) PMCPC_Settings::get( 'spam_message_block_score', 6 );
    	}
    	$hold_at  = (int) apply_filters( 'pmcpc_spam_message_hold_score', $hold_at, $context );
    	$block_at = (int) apply_filters( 'pmcpc_spam_message_block_score', $block_at, $context );

    	// False-positive control: if the only strong signal is high non-Latin content, prefer holding for review.
    	$prefer_hold = false;
    	if ( class_exists( 'PMCPC_Settings' ) ) {
    		$prefer_hold = ( PMCPC_Settings::get( 'spam_message_prefer_hold_on_non_ascii_only', 'yes' ) === 'yes' );
    	}
    	$prefer_hold = (bool) apply_filters( 'pmcpc_spam_message_prefer_hold_on_non_ascii_only', $prefer_hold, $context, $detail, $score );
    	if ( $prefer_hold && $score >= $block_at ) {
    		$has_non_ascii = false;
    		$has_strong   = false;
    		foreach ( $detail as $d ) {
    			$d = (string) $d;
    			if ( 0 === strpos( $d, 'non_ascii:' ) ) {
    				$has_non_ascii = true;
    			}
    			if ( 0 === strpos( $d, 'links:' ) || 0 === strpos( $d, 'kw:' ) || 0 === strpos( $d, 'kw_non_ascii:' ) || 'bbcode_url' === $d || 'href' === $d ) {
    				$has_strong = true;
    			}
    		}
    		if ( $has_non_ascii && ! $has_strong ) {
    			return array(
    				'allowed' => false,
    				'action'  => 'held',
    				'reason'  => 'message_scored',
    				'score'   => $score,
    				'details' => array_merge( $detail, array( 'prefer_hold_non_ascii' ) ),
    			);
    		}
    	}

    	// Optional global false-positive control: prefer holding for review instead of blocking
    	// when message scoring trips the block threshold.
    	$prefer_hold_over_block = false;
    	if ( class_exists( 'PMCPC_Settings' ) ) {
    		$prefer_hold_over_block = ( PMCPC_Settings::get( 'spam_message_prefer_hold_over_block', 'no' ) === 'yes' );
    	}
    	$prefer_hold_over_block = (bool) apply_filters( 'pmcpc_spam_message_prefer_hold_over_block', $prefer_hold_over_block, $context, $detail, $score );
    	if ( $prefer_hold_over_block && $score >= $block_at ) {
    		return array(
    			'allowed' => false,
    			'action'  => 'held',
    			'reason'  => 'message_scored',
    			'score'   => $score,
    			'details' => array_merge( $detail, array( 'prefer_hold_over_block' ) ),
    		);
    	}

    	if ( $score >= $block_at ) {
    		return array(
    			'allowed' => false,
    			'action'  => 'blocked',
    			'reason'  => 'message_scored',
    			'score'   => $score,
    			'details' => $detail,
    		);
    	}

    	if ( $score >= $hold_at ) {
    		// "Hold" is treated as non-allowed for contact email sending, but keeps UX friendly.
    		return array(
    			'allowed' => false,
    			'action'  => 'held',
    			'reason'  => 'message_scored',
    			'score'   => $score,
    			'details' => $detail,
    		);
    	}

    	return array(
    		'allowed' => true,
    		'action'  => 'allowed',
    		'reason'  => '',
    		'score'   => $score,
    		'details' => $detail,
    	);
    }

    	public static function is_suspicious_tld( $email ) {
    		if ( 'yes' !== self::get_spam_setting( 'spam_suspicious_tlds_enabled', 'yes' ) ) {
    			return false;
    		}
    		$email = sanitize_email( (string) $email );
    		if ( ! $email || strpos( $email, '@' ) === false ) {
    			return false;
    		}
    		$domain = strtolower( trim( substr( strrchr( $email, '@' ), 1 ) ) );
    		if ( ! $domain || strpos( $domain, '.' ) === false ) {
    			return false;
    		}
    		$tld = strtolower( trim( substr( strrchr( $domain, '.' ), 1 ) ) );
    		$list = (string) self::get_spam_setting( 'spam_suspicious_tlds', '' );
    		$items = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $list ) ) );
    		return $tld && in_array( $tld, $items, true );
    	}

        /**
         * Read and verify a POST nonce.
         *
         * @param string $field  Nonce field name.
         * @param string $action Nonce action.
         * @return bool
         */
        protected static function pmcpc_verify_post_nonce( $field, $action ) {
            $nonce = isset( $_POST[ $field ] ) ? sanitize_text_field( (string) wp_unslash( $_POST[ $field ] ) ) : '';

            return ( ! empty( $nonce ) && wp_verify_nonce( $nonce, $action ) );
        }

        /**
         * Read and verify a GET nonce.
         *
         * @param string $field  Nonce field name.
         * @param string $action Nonce action.
         * @return bool
         */
        protected static function pmcpc_verify_get_nonce( $field, $action ) {
            $nonce = isset( $_GET[ $field ] ) ? sanitize_text_field( (string) wp_unslash( $_GET[ $field ] ) ) : '';

            return ( ! empty( $nonce ) && wp_verify_nonce( $nonce, $action ) );
        }

}
