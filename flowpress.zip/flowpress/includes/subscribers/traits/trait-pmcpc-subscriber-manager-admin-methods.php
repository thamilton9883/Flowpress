<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Subscriber_Manager_Admin_Methods {
        /**
         * Redirect back to the subscribers screen without handled action args.
         *
         * @param array $args Args to remove from the URL.
         * @return void
         */
        protected static function pmcpc_redirect_subscribers_page( $args ) {
            $base     = wp_get_referer();
            $base     = is_string( $base ) && '' !== $base ? $base : admin_url( 'admin.php?page=pmcpc_subscribers' );
            $redirect = remove_query_arg( (array) $args, $base );
            $redirect = is_string( $redirect ) && '' !== $redirect ? $redirect : admin_url( 'admin.php?page=pmcpc_subscribers' );

            wp_safe_redirect( $redirect );
            exit;
        }

        /**
         * Normalize a manual subscriber form submission.
         *
         * @return array<string,string>
         */
        protected static function pmcpc_get_manual_subscriber_form_data() {
            return array(
                'email'      => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '',
                'first_name' => isset( $_POST['first_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['first_name'] ) ) : '',
                'last_name'  => isset( $_POST['last_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['last_name'] ) ) : '',
                'birthday'   => isset( $_POST['pmcpc_birthday'] ) ? self::sanitize_birthday_value( sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_birthday'] ) ) ) : '',
                'tags_raw'   => isset( $_POST['tags'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['tags'] ) ) : '',
            );
        }

        /**
         * Parse manual/admin-editable subscriber tags from a CSV string.
         *
         * @param string $tags_raw Raw CSV tags.
         * @return array
         */
        protected static function pmcpc_parse_manual_tags( $tags_raw ) {
            $tags_raw = sanitize_text_field( (string) $tags_raw );
            if ( '' === trim( $tags_raw ) ) {
                return array();
            }

            $tags = array_values(
                array_unique(
                    array_filter(
                        array_map(
                            static function ( $tag ) {
                                return sanitize_text_field( (string) $tag );
                            },
                            array_map( 'trim', explode( ',', $tags_raw ) )
                        )
                    )
                )
            );

            $catalogs          = self::get_tag_catalogs();
            $lifecycle_catalog = isset( $catalogs['lifecycle'] ) ? (array) $catalogs['lifecycle'] : array();
            $source_catalog    = isset( $catalogs['source'] ) ? (array) $catalogs['source'] : array();

            return array_values(
                array_filter(
                    $tags,
                    static function ( $tag ) use ( $lifecycle_catalog, $source_catalog ) {
                        $tag = (string) $tag;
                        if ( '' === $tag ) {
                            return false;
                        }
                        if ( 0 === strpos( $tag, 'health:' ) ) {
                            return false;
                        }
                        if ( 0 === strpos( $tag, 'origin:' ) || 0 === strpos( $tag, 'form-' ) ) {
                            return false;
                        }
                        if ( in_array( $tag, $lifecycle_catalog, true ) ) {
                            return false;
                        }
                        if ( in_array( $tag, $source_catalog, true ) ) {
                            return false;
                        }
                        return true;
                    }
                )
            );
        }

        /**
         * Normalize subscriber status before persistence.
         *
         * @param string $status Raw status.
         * @return string
         */
        protected static function pmcpc_normalize_subscriber_status( $status ) {
            $status = sanitize_key( (string) $status );

            return in_array( $status, array( 'active', 'pending', 'unsubscribed' ), true ) ? $status : 'active';
        }

        /**
         * Persist a subscriber row by email.
         *
         * @param string $email      Email address.
         * @param string $first_name First name.
         * @param string $last_name  Last name.
         * @param string $status     Subscriber status.
         * @return bool
         */
        protected static function pmcpc_persist_subscriber( $email, $first_name, $last_name, $status ) {
            global $wpdb;

            $table      = $wpdb->prefix . 'pmcpc_subscribers';
            $email      = sanitize_email( (string) $email );
            $first_name = sanitize_text_field( (string) $first_name );
            $last_name  = sanitize_text_field( (string) $last_name );
            $status     = self::pmcpc_normalize_subscriber_status( $status );

            if ( empty( $email ) ) {
                return false;
            }

            $now = current_time( 'mysql' );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $existing = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE email = %s', $table, $email ) );

            if ( $existing ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
                $wpdb->update(
                    $table,
                    array(
                        'first_name' => $first_name,
                        'last_name'  => $last_name,
                        'updated_at' => $now,
                        'status'     => $status,
                    ),
                    array( 'id' => $existing->id ),
                    array( '%s', '%s', '%s', '%s' ),
                    array( '%d' )
                );

                return false;
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $wpdb->insert(
                $table,
                array(
                    'email'      => $email,
                    'first_name' => $first_name,
                    'last_name'  => $last_name,
                    'status'     => $status,
                    'created_at' => $now,
                    'updated_at' => $now,
                ),
                array( '%s', '%s', '%s', '%s', '%s', '%s' )
            );

            return true;
        }

        protected function maybe_handle_subscriber_manual_admin_actions() {
            if ( self::pmcpc_verify_post_nonce( 'pmcpc_add_subscriber_nonce', 'pmcpc_add_subscriber' ) ) {
                $this->add_subscriber_from_form();
            }

            if ( self::pmcpc_verify_post_nonce( 'pmcpc_import_users_nonce', 'pmcpc_import_users' ) ) {
                $this->import_wp_users();
            }

            if ( self::pmcpc_verify_post_nonce( 'pmcpc_cleanup_subscribers_nonce', 'pmcpc_cleanup_subscribers' ) ) {
                $this->handle_cleanup_request();
            }

            if ( self::pmcpc_verify_post_nonce( 'pmcpc_backfill_source_tags_nonce', 'pmcpc_backfill_source_tags' ) ) {
                $this->backfill_source_tags_from_origin();
            }

            if ( self::pmcpc_verify_post_nonce( 'pmcpc_recalc_lifecycle_tags_nonce', 'pmcpc_recalc_lifecycle_tags' ) ) {
                $this->recalculate_lifecycle_tags_for_all( true );
            }

            if ( self::pmcpc_verify_post_nonce( 'pmcpc_recalc_health_tags_nonce', 'pmcpc_recalc_health_tags' ) ) {
                $this->recalculate_health_tags_for_all();
            }
        }

        protected function maybe_handle_subscriber_bulk_actions() {
            if (
                ! isset( $_POST['pmcpc_bulk_delete_subscribers_nonce'], $_POST['pmcpc_subscriber_ids'] )
                || ! wp_verify_nonce(
                    sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_bulk_delete_subscribers_nonce'] ) ),
                    'pmcpc_bulk_delete_subscribers'
                )
            ) {
                return;
            }

            $ids = array_map( 'absint', (array) $_POST['pmcpc_subscriber_ids'] );
            $ids = array_filter( $ids );

            if ( empty( $ids ) ) {
                return;
            }

            $bulk_action = isset( $_POST['pmcpc_bulk_action'] ) ? sanitize_key( (string) wp_unslash( $_POST['pmcpc_bulk_action'] ) ) : '';

            if ( ! empty( $_POST['pmcpc_bulk_delete_subscribers'] ) ) {
                $bulk_action = 'delete';
            } elseif ( ! empty( $_POST['pmcpc_bulk_add_tag'] ) ) {
                $bulk_action = 'add_tag';
            } elseif ( ! empty( $_POST['pmcpc_bulk_remove_tag'] ) ) {
                $bulk_action = 'remove_tag';
            }

            if ( 'delete' === $bulk_action ) {
                $this->bulk_delete_subscribers( $ids );
                return;
            }

            if ( 'unsubscribe' === $bulk_action ) {
                $this->bulk_update_subscriber_status( $ids, 'unsubscribed' );
                return;
            }

            if ( 'resubscribe' === $bulk_action ) {
                $this->bulk_update_subscriber_status( $ids, 'active' );
                return;
            }

            if ( 'block_domain' === $bulk_action ) {
                $this->bulk_block_domains_for_subscribers( $ids );
                return;
            }

            if ( ( 'add_tag' === $bulk_action || 'remove_tag' === $bulk_action ) && ! empty( $_POST['pmcpc_bulk_tag'] ) ) {
                $tag = sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_bulk_tag'] ) );
                if ( '' === $tag ) {
                    return;
                }

                if ( 'add_tag' === $bulk_action ) {
                    $this->bulk_add_tag_to_subscribers( $ids, $tag );
                } else {
                    $this->bulk_remove_tag_from_subscribers( $ids, $tag );
                }
            }
        }

        protected function bulk_update_subscriber_status( array $ids, $status ) {
            $status = sanitize_key( (string) $status );

            if ( '' === $status ) {
                return;
            }

            foreach ( $ids as $sid ) {
                $sid = absint( $sid );
                if ( $sid ) {
                    self::update_status( $sid, $status );
                }
            }
        }

        protected function bulk_block_domains_for_subscribers( array $ids ) {
            $domains = array();

            foreach ( $ids as $sid ) {
                $sid = absint( $sid );

                if ( ! $sid ) {
                    continue;
                }

                $subscriber = self::get_subscriber( $sid );

                if ( $subscriber && ! empty( $subscriber->email ) ) {
                    $at_pos = strpos( (string) $subscriber->email, '@' );

                    if ( false !== $at_pos ) {
                        $domain = strtolower( trim( substr( (string) $subscriber->email, $at_pos + 1 ) ) );

                        if ( '' !== $domain ) {
                            $domains[] = $domain;
                        }
                    }
                }

                self::update_status( $sid, 'unsubscribed' );
            }

            $domains = array_values( array_unique( array_filter( $domains ) ) );

            if ( empty( $domains ) || ! class_exists( 'PMCPC_Settings' ) ) {
                return;
            }

            $auto_add = PMCPC_Settings::get( 'blocked_domains_auto_add', 'yes' );

            if ( 'yes' !== $auto_add ) {
                return;
            }

            $existing = PMCPC_Settings::get( 'blocked_email_domains', '' );
            $current  = preg_split( '/[\r\n,]+/', (string) $existing );
            $current  = array_filter( array_map( 'trim', (array) $current ) );

            foreach ( $domains as $domain ) {
                if ( ! in_array( $domain, $current, true ) ) {
                    $current[] = $domain;
                }
            }

            $current = array_values( array_unique( array_filter( $current ) ) );
            sort( $current );

            $new_value = implode( "\n", $current );

            if ( method_exists( 'PMCPC_Settings', 'update' ) ) {
                PMCPC_Settings::update(
                    array(
                        'blocked_email_domains' => $new_value,
                    )
                );
            } else {
                update_option( 'pmcpc_blocked_email_domains', $new_value );
            }
        }

        protected function maybe_handle_subscriber_row_actions() {
            if ( isset( $_GET['pmcpc_delete_subscriber'], $_GET['pmcpc_delete_nonce'] ) ) {
                $subscriber_id = absint( wp_unslash( $_GET['pmcpc_delete_subscriber'] ) );
                if ( $subscriber_id && self::pmcpc_verify_get_nonce( 'pmcpc_delete_nonce', 'pmcpc_delete_subscriber_' . $subscriber_id ) ) {
                    $this->bulk_delete_subscribers( array( $subscriber_id ) );
                    self::pmcpc_redirect_subscribers_page( array( 'pmcpc_delete_subscriber', 'pmcpc_delete_nonce' ) );
                }
            }

            if ( isset( $_GET['pmcpc_unsub_subscriber'], $_GET['pmcpc_unsub_nonce'] ) ) {
                $subscriber_id = absint( wp_unslash( $_GET['pmcpc_unsub_subscriber'] ) );
                if ( $subscriber_id && self::pmcpc_verify_get_nonce( 'pmcpc_unsub_nonce', 'pmcpc_unsub_subscriber_' . $subscriber_id ) ) {
                    self::update_status( $subscriber_id, 'unsubscribed' );
                    self::pmcpc_redirect_subscribers_page( array( 'pmcpc_unsub_subscriber', 'pmcpc_unsub_nonce' ) );
                }
            }

            if ( isset( $_GET['pmcpc_resub_subscriber'], $_GET['pmcpc_resub_nonce'] ) ) {
                $subscriber_id = absint( wp_unslash( $_GET['pmcpc_resub_subscriber'] ) );
                if ( $subscriber_id && self::pmcpc_verify_get_nonce( 'pmcpc_resub_nonce', 'pmcpc_resub_subscriber_' . $subscriber_id ) ) {
                    self::update_status( $subscriber_id, 'active' );
                    self::pmcpc_redirect_subscribers_page( array( 'pmcpc_resub_subscriber', 'pmcpc_resub_nonce' ) );
                }
            }

            if ( isset( $_GET['pmcpc_block_domain'], $_GET['pmcpc_block_domain_nonce'] ) ) {
                $subscriber_id = absint( wp_unslash( $_GET['pmcpc_block_domain'] ) );
                $nonce         = sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_block_domain_nonce'] ) );

                if ( $subscriber_id && wp_verify_nonce( $nonce, 'pmcpc_block_domain_' . $subscriber_id ) ) {
                    $subscriber = self::get_subscriber( $subscriber_id );

                    if ( $subscriber && ! empty( $subscriber->email ) ) {
                        $email  = $subscriber->email;
                        $at_pos = strpos( $email, '@' );
                        if ( false !== $at_pos ) {
                            $domain = strtolower( substr( $email, $at_pos + 1 ) );

                            if ( $domain && class_exists( 'PMCPC_Settings' ) ) {
                                $auto_add = PMCPC_Settings::get( 'blocked_domains_auto_add', 'yes' );
                                if ( 'yes' === $auto_add ) {
                                    $existing = PMCPC_Settings::get( 'blocked_email_domains', '' );
                                    $domains  = preg_split( '/[\r\n,]+/', (string) $existing );
                                    $domains  = array_filter( array_map( 'trim', (array) $domains ) );

                                    if ( ! in_array( $domain, $domains, true ) ) {
                                        $domains[] = $domain;
                                        sort( $domains );
                                        $new_value = implode( "\n", $domains );

                                        if ( method_exists( 'PMCPC_Settings', 'update' ) ) {
                                            PMCPC_Settings::update(
                                                array(
                                                    'blocked_email_domains' => $new_value,
                                                )
                                            );
                                        } else {
                                            update_option( 'pmcpc_blocked_email_domains', $new_value );
                                        }
                                    }
                                }
                            }
                        }
                    }

                    self::update_status( $subscriber_id, 'unsubscribed' );

                    $base     = wp_get_referer();
                    $base     = is_string( $base ) && '' !== $base ? $base : admin_url( 'admin.php?page=pmcpc_subscribers' );
                    $redirect = remove_query_arg( array( 'pmcpc_block_domain', 'pmcpc_block_domain_nonce' ), $base );
                    $redirect = is_string( $redirect ) && '' !== $redirect ? $redirect : admin_url( 'admin.php?page=pmcpc_subscribers' );
                    wp_safe_redirect( $redirect );
                    exit;
                }
            }
        }

        protected function maybe_handle_subscriber_crm_request() {
            if ( ! isset( $_POST['pmcpc_save_subscriber'], $_POST['pmcpc_update_subscriber_tags_nonce'], $_POST['pmcpc_subscriber_id'] ) ) {
                return;
            }

            $subscriber_id = absint( $_POST['pmcpc_subscriber_id'] );
            $nonce         = isset( $_POST['pmcpc_update_subscriber_tags_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_update_subscriber_tags_nonce'] ) ) : '';

            if ( $subscriber_id && ! empty( $nonce ) && wp_verify_nonce( $nonce, 'pmcpc_update_subscriber_tags_' . $subscriber_id ) ) {
                $this->handle_subscriber_crm_update( $subscriber_id );
            }
        }

            public function handle_request() {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            $this->maybe_handle_subscriber_manual_admin_actions();
            $this->maybe_handle_subscriber_bulk_actions();
            $this->maybe_handle_subscriber_row_actions();
            $this->maybe_handle_subscriber_crm_request();
        }

}
