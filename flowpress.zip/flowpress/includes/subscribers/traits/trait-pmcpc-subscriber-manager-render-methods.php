<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Subscriber_Manager_Render_Methods {
        public function render_page() {
            if ( isset( $_GET['subscriber_id'] ) ) {
                $this->render_subscriber_timeline( absint( wp_unslash( $_GET['subscriber_id'] ) ) );
                return;
            }

            global $wpdb;

    		$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
    		$tags_table        = $wpdb->prefix . 'pmcpc_subscriber_tags';
            // Note: Cleanup must be based on subscriber lifetime stats, not queue/event tables,
            // because queue cleanup/pruning should not reset or affect subscriber management.

            $status_filter     = isset( $_GET['pmcpc_status'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_status'] ) ) : '';
            $quick_filter     = isset( $_GET['pmcpc_quick_filter'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_quick_filter'] ) ) : '';
            $interest_filter  = isset( $_GET['pmcpc_interest'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_interest'] ) ) : '';
            $source_filter    = isset( $_GET['pmcpc_source'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_source'] ) ) : '';
            $lifecycle_filter = isset( $_GET['pmcpc_lifecycle'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_lifecycle'] ) ) : '';
    			$health_filter    = isset( $_GET['pmcpc_health'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_health'] ) ) : '';
            $origin_filter    = isset( $_GET['pmcpc_origin'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_origin'] ) ) : '';
            $other_filter     = isset( $_GET['pmcpc_other_tag'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_other_tag'] ) ) : '';
            $search_query     = isset( $_GET['pmcpc_search'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_search'] ) ) : '';
            $name_query       = isset( $_GET['pmcpc_name'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_name'] ) ) : '';
            $customer_filter  = isset( $_GET['pmcpc_customer'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_customer'] ) ) : '';
            $created_after    = isset( $_GET['pmcpc_created_after'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_created_after'] ) ) : '';
            $created_before   = isset( $_GET['pmcpc_created_before'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_created_before'] ) ) : '';

            $created_after_mysql  = '';
            $created_before_mysql = '';
            if ( $created_after && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $created_after ) ) {
                $created_after_mysql = $created_after . ' 00:00:00';
            }
            if ( $created_before && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $created_before ) ) {
                $created_before_mysql = $created_before . ' 23:59:59';
            }

            // Date filters must never pass an empty string into a DATETIME comparison.
            // MySQL in strict mode throws: "Incorrect DATETIME value: ''".
            $apply_created_after  = ( '' !== $created_after_mysql ) ? 1 : 0;
            $apply_created_before = ( '' !== $created_before_mysql ) ? 1 : 0;

            // Provide safe sentinel values for the prepared placeholders.
            // They will only be used when the corresponding apply flag is 1.
            $created_after_safe  = ( '' !== $created_after_mysql ) ? $created_after_mysql : '1970-01-01 00:00:00';
            $created_before_safe = ( '' !== $created_before_mysql ) ? $created_before_mysql : '9999-12-31 23:59:59';


    		// Engagement filter (new): pmcpc_engagement = no_opens | has_opens.
    		$engagement_filter = isset( $_GET['pmcpc_engagement'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_engagement'] ) ) : '';

    		// Back-compat: older URLs used pmcpc_no_opens / pmcpc_has_opens checkboxes.
    		if ( 'no_opens' === $engagement_filter ) {
    			$no_open_filter  = true;
    			$has_open_filter = false;
    		} elseif ( 'has_opens' === $engagement_filter ) {
    			$no_open_filter  = false;
    			$has_open_filter = true;
    		} else {
    			$no_open_filter  = isset( $_GET['pmcpc_no_opens'] ) ? (bool) absint( wp_unslash( $_GET['pmcpc_no_opens'] ) ) : false;
    			$has_open_filter = isset( $_GET['pmcpc_has_opens'] ) ? (bool) absint( wp_unslash( $_GET['pmcpc_has_opens'] ) ) : false;
    		}
    $apply_no_open  = ( $no_open_filter && ! $has_open_filter ) ? 1 : 0;
    		$apply_has_open = ( $has_open_filter && ! $no_open_filter ) ? 1 : 0;

            $apply_engaged_30 = ( 'engaged_30' === $quick_filter ) ? 1 : 0;
            $apply_at_risk_90 = ( 'at_risk_90' === $quick_filter ) ? 1 : 0;
            $apply_new_30    = ( 'new_30' === $quick_filter ) ? 1 : 0;
            $apply_unsubs_30 = ( 'unsubs_30' === $quick_filter ) ? 1 : 0;
            $dt_30_mysql = gmdate( 'Y-m-d H:i:s', time() - ( 30 * DAY_IN_SECONDS ) );
            $dt_90_mysql = gmdate( 'Y-m-d H:i:s', time() - ( 90 * DAY_IN_SECONDS ) );

            // Unsubs quick filter relies on updated_at existing.
            $pmcpc_has_updated_at = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$subscribers_table} LIKE %s", 'updated_at' ) );
            if ( empty( $pmcpc_has_updated_at ) ) {
                $apply_unsubs_30 = 0;
            }
    		
    		$use_search = ( '' !== $search_query ) ? 1 : 0;
    		$like       = '%' . $wpdb->esc_like( $search_query ) . '%';

    		$use_name_search = ( '' !== $name_query ) ? 1 : 0;
    		$name_like       = '%' . $wpdb->esc_like( $name_query ) . '%';

            // Tag catalogs (needed for customer/subscriber filter).
            $catalogs_for_query  = self::get_tag_catalogs();
            $lifecycle_catalog_q = isset( $catalogs_for_query['lifecycle'] ) ? (array) $catalogs_for_query['lifecycle'] : array();
            $lifecycle_catalog_q = array_values( array_filter( array_map( 'strval', $lifecycle_catalog_q ) ) );
            if ( empty( $lifecycle_catalog_q ) ) {
                $lifecycle_catalog_q = array( '__none__' );
            }
            $lifecycle_in_placeholders = implode( ',', array_fill( 0, count( $lifecycle_catalog_q ), '%s' ) );


    // Prepare the subscribers query (table names are internal plugin tables, not user input).
    // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    		// Prepare the subscribers query (table names are internal plugin tables, not user input).
    		
            // Pagination.
            $per_page     = (int) apply_filters( 'pmcpc_admin_subscribers_per_page', 20 );
            if ( $per_page < 5 ) {
                $per_page = 5;
            }
            $current_page = isset( $_GET['pmcpc_paged'] ) ? max( 1, absint( wp_unslash( $_GET['pmcpc_paged'] ) ) ) : 1;
            $offset       = ( $current_page - 1 ) * $per_page;

            $sql = "SELECT s.*
                    FROM %i s
                    WHERE ( %s = '' OR s.status = %s )
                    AND ( %d = 0 OR s.email LIKE %s OR s.first_name LIKE %s OR s.last_name LIKE %s )
                    AND ( %d = 0 OR s.first_name LIKE %s OR s.last_name LIKE %s )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_interest
                        WHERE t_interest.subscriber_id = s.id AND t_interest.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_source
                        WHERE t_source.subscriber_id = s.id AND t_source.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_lifecycle
                        WHERE t_lifecycle.subscriber_id = s.id AND t_lifecycle.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_health
                        WHERE t_health.subscriber_id = s.id AND t_health.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_other
                        WHERE t_other.subscriber_id = s.id AND t_other.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_origin
                        WHERE t_origin.subscriber_id = s.id AND t_origin.tag = %s
                    ) )
                    AND ( %s = '' OR (
                        ( %s = 'customer' AND EXISTS (
                            SELECT 1 FROM %i t_cust
                            WHERE t_cust.subscriber_id = s.id AND t_cust.tag IN (" . $lifecycle_in_placeholders . ")
                        ) )
                        OR
                        ( %s = 'subscriber' AND NOT EXISTS (
                            SELECT 1 FROM %i t_cust2
                            WHERE t_cust2.subscriber_id = s.id AND t_cust2.tag IN (" . $lifecycle_in_placeholders . ")
                        ) )
                    ) )
                    AND ( %d = 0 OR s.created_at >= %s )
                    AND ( %d = 0 OR s.created_at <= %s )
                    AND ( %d = 0 OR COALESCE(s.lifetime_opens, 0) = 0 )
                    AND ( %d = 0 OR COALESCE(s.lifetime_opens, 0) > 0 )
                    AND ( %d = 0 OR ( s.status = 'active' AND s.last_engaged_at IS NOT NULL AND s.last_engaged_at >= %s ) )
                    AND ( %d = 0 OR ( s.status = 'active' AND ( s.last_engaged_at IS NULL OR s.last_engaged_at < %s ) ) )
                    AND ( %d = 0 OR s.created_at >= %s )
                    AND ( %d = 0 OR ( s.status = 'unsubscribed' AND s.updated_at IS NOT NULL AND s.updated_at >= %s ) )
                    ORDER BY s.created_at DESC
                    LIMIT %d OFFSET %d";

            $args = array(
                $subscribers_table,
                $status_filter,
                $status_filter,
                $use_search,
                $like,
                $like,
                $like,
                $use_name_search,
                $name_like,
                $name_like,
                $interest_filter,
                $tags_table,
                $interest_filter,
                $source_filter,
                $tags_table,
                $source_filter,
                $lifecycle_filter,
                $tags_table,
                $lifecycle_filter,
                $health_filter,
                $tags_table,
                $health_filter,
                $other_filter,
                $tags_table,
                $other_filter,
                $origin_filter,
                $tags_table,
                $origin_filter,
                $customer_filter,
                $customer_filter,
                $tags_table,
            );

            $args = array_merge( $args, $lifecycle_catalog_q );

            $args = array_merge(
                $args,
                array(
                    $customer_filter,
                    $tags_table,
                )
            );

            $args = array_merge( $args, $lifecycle_catalog_q );

            $args = array_merge(
                $args,
                array(
                    $apply_created_after,
                    $created_after_safe,
                    $apply_created_before,
                    $created_before_safe,
                    $apply_no_open,
                    $apply_has_open,
                    $apply_engaged_30,
                    $dt_30_mysql,
                    $apply_at_risk_90,
                    $dt_90_mysql,
                    $apply_new_30,
                    $dt_30_mysql,
                    $apply_unsubs_30,
                    $dt_30_mysql,
                    $per_page,
                    $offset,
                )
            );

            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $prepared_sql = call_user_func_array( array( $wpdb, 'prepare' ), array_merge( array( $sql ), $args ) );



    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.NotPrepared
    		
            // Total rows for pagination (same filters, no LIMIT).
            // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                    $count_sql = "SELECT COUNT(1)
                    FROM %i s
                    WHERE ( %s = '' OR s.status = %s )
                    AND ( %d = 0 OR s.email LIKE %s OR s.first_name LIKE %s OR s.last_name LIKE %s )
                    AND ( %d = 0 OR s.first_name LIKE %s OR s.last_name LIKE %s )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_interest
                        WHERE t_interest.subscriber_id = s.id AND t_interest.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_source
                        WHERE t_source.subscriber_id = s.id AND t_source.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_lifecycle
                        WHERE t_lifecycle.subscriber_id = s.id AND t_lifecycle.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_health
                        WHERE t_health.subscriber_id = s.id AND t_health.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_other
                        WHERE t_other.subscriber_id = s.id AND t_other.tag = %s
                    ) )
                    AND ( %s = '' OR EXISTS (
                        SELECT 1 FROM %i t_origin
                        WHERE t_origin.subscriber_id = s.id AND t_origin.tag = %s
                    ) )
                    AND ( %s = '' OR (
                        ( %s = 'customer' AND EXISTS (
                            SELECT 1 FROM %i t_cust
                            WHERE t_cust.subscriber_id = s.id AND t_cust.tag IN (" . $lifecycle_in_placeholders . ")
                        ) )
                        OR
                        ( %s = 'subscriber' AND NOT EXISTS (
                            SELECT 1 FROM %i t_cust2
                            WHERE t_cust2.subscriber_id = s.id AND t_cust2.tag IN (" . $lifecycle_in_placeholders . ")
                        ) )
                    ) )
                    AND ( %d = 0 OR s.created_at >= %s )
                    AND ( %d = 0 OR s.created_at <= %s )
                    AND ( %d = 0 OR COALESCE(s.lifetime_opens, 0) = 0 )
                    AND ( %d = 0 OR COALESCE(s.lifetime_opens, 0) > 0 )
                    AND ( %d = 0 OR ( s.status = 'active' AND s.last_engaged_at IS NOT NULL AND s.last_engaged_at >= %s ) )
                    AND ( %d = 0 OR ( s.status = 'active' AND ( s.last_engaged_at IS NULL OR s.last_engaged_at < %s ) ) )
                    AND ( %d = 0 OR s.created_at >= %s )
                    AND ( %d = 0 OR ( s.status = 'unsubscribed' AND s.updated_at IS NOT NULL AND s.updated_at >= %s ) )";

            $count_args = array(
                $subscribers_table,
                $status_filter,
                $status_filter,
                $use_search,
                $like,
                $like,
                $like,
                $use_name_search,
                $name_like,
                $name_like,
                $interest_filter,
                $tags_table,
                $interest_filter,
                $source_filter,
                $tags_table,
                $source_filter,
                $lifecycle_filter,
                $tags_table,
                $lifecycle_filter,
                $health_filter,
                $tags_table,
                $health_filter,
                $other_filter,
                $tags_table,
                $other_filter,
                $origin_filter,
                $tags_table,
                $origin_filter,
                $customer_filter,
                $customer_filter,
                $tags_table,
            );

            $count_args = array_merge( $count_args, $lifecycle_catalog_q );

            $count_args = array_merge(
                $count_args,
                array(
                    $customer_filter,
                    $tags_table,
                )
            );

            $count_args = array_merge( $count_args, $lifecycle_catalog_q );

            $count_args = array_merge(
                $count_args,
                array(
                    $apply_created_after,
                    $created_after_safe,
                    $apply_created_before,
                    $created_before_safe,
                    $apply_no_open,
                    $apply_has_open,
                    $apply_engaged_30,
                    $dt_30_mysql,
                    $apply_at_risk_90,
                    $dt_90_mysql,
                    $apply_new_30,
                    $dt_30_mysql,
                    $apply_unsubs_30,
                    $dt_30_mysql,
                )
            );

            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $prepared_count_sql = call_user_func_array( array( $wpdb, 'prepare' ), array_merge( array( $count_sql ), $count_args ) );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.NotPrepared
            $pmcpc_total_subscribers = (int) $wpdb->get_var( $prepared_count_sql );
            // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

    $subscribers = $wpdb->get_results( $prepared_sql );
    // Tag catalogs for the filter dropdowns.
    		        $catalogs = self::get_tag_catalogs();
    		
    		        $interest_options  = array();
    				$source_options    = array();
    				$lifecycle_options = array();
    				$health_options    = array(
    					'health:hot',
    					'health:warm',
    					'health:slipping',
    					'health:cold',
    				);
    				$other_tag_options = array();
    		
    		        if ( ! empty( $catalogs['interest'] ) && is_array( $catalogs['interest'] ) ) {
    		            $interest_options = array_values( array_unique( $catalogs['interest'] ) );
    		        }
    		
    		        if ( ! empty( $catalogs['source'] ) && is_array( $catalogs['source'] ) ) {
    		            foreach ( $catalogs['source'] as $tag ) {
    		                // Skip origin-style tags here; they have their own filter.
    		                // Health tags have their own filter; do not include them in Other tags.
    		                if ( 0 === strpos( $tag, 'health:' ) ) {
    		                	continue;
    		                }
    		                if ( 0 === strpos( $tag, 'origin:' ) || 0 === strpos( $tag, 'form-' ) ) {
    		                    continue;
    		                }
    		                $source_options[] = $tag;
    		            }
    		            $source_options = array_values( array_unique( $source_options ) );
    		        }
    		
    		        if ( ! empty( $catalogs['lifecycle'] ) && is_array( $catalogs['lifecycle'] ) ) {
    		            $lifecycle_options = array_values( array_unique( $catalogs['lifecycle'] ) );
    		        }
    		
    		        // Other (manually-added) tags are discovered from existing subscriber tags
    		        // that are not part of the interest, source, lifecycle or origin catalogs.
    		        $cache_key    = 'pmcpc_all_tags_' . get_current_blog_id();
    		        $all_tag_rows = wp_cache_get( $cache_key, 'pmcpc' );

    		        if ( false === $all_tag_rows ) {
    		            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter
    					$all_tag_rows = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT tag FROM %i ORDER BY tag ASC', $tags_table ) );
    		            wp_cache_set( $cache_key, $all_tag_rows, 'pmcpc', 300 );
    		        }
    		        if ( ! empty( $all_tag_rows ) && is_array( $all_tag_rows ) ) {
    		            foreach ( $all_tag_rows as $tag ) {
    		                $tag = sanitize_text_field( $tag );
    		                if ( '' === $tag ) {
    		                    continue;
    		                }
    		
    		                if ( in_array( $tag, $interest_options, true ) ) {
    		                    continue;
    		                }
    		                if ( in_array( $tag, $source_options, true ) ) {
    		                    continue;
    		                }
    		                if ( in_array( $tag, $lifecycle_options, true ) ) {
    		                    continue;
    		                }
    		                // Health tags have their own filter; do not include them in Other tags.
    		                if ( 0 === strpos( $tag, 'health:' ) ) {
    		                    continue;
    		                }
    		                if ( 0 === strpos( $tag, 'origin:' ) || 0 === strpos( $tag, 'form-' ) ) {
    		                    continue;
    		                }
    		
    		                $other_tag_options[] = $tag;
    		            }
    		
    		            $other_tag_options = array_values( array_unique( $other_tag_options ) );
    		        }
    		
    		        // Origin tag options are discovered from existing subscriber tags (tag prefix "origin:").
    		        $origin_options = array();
    		        $origin_like = $wpdb->esc_like( 'origin:' ) . '%';
    		        $cache_key   = 'pmcpc_origin_tags_' . get_current_blog_id();
    		        $origin_rows = wp_cache_get( $cache_key, 'pmcpc' );

    		        if ( false === $origin_rows ) {
    		            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter
    					$origin_rows = $wpdb->get_col(
    		                $wpdb->prepare(
    		                    "SELECT DISTINCT tag FROM {$tags_table} WHERE tag LIKE %s ORDER BY tag ASC",
    		                    $origin_like
    		                )
    		            );
    		            wp_cache_set( $cache_key, $origin_rows, 'pmcpc', 300 );
    		        }
    		        if ( ! empty( $origin_rows ) && is_array( $origin_rows ) ) {
    		            foreach ( $origin_rows as $origin_tag ) {
    		                $origin_tag = sanitize_text_field( $origin_tag );
    		                if ( '' !== $origin_tag ) {
    		                    $origin_options[] = $origin_tag;
    		                }
    		            }
    		            $origin_options = array_values( array_unique( $origin_options ) );

    			
    			// Remove duplicates: if a value exists as an Origin label, do not show it under "Other tags".
    			if ( ! empty( $origin_options ) && ! empty( $other_tag_options ) ) {
    				$origin_label_set  = array_fill_keys( array_map( 'strval', $origin_options ), true );
    				$other_tag_options = array_values(
    					array_filter(
    						$other_tag_options,
    						function ( $tag ) use ( $origin_label_set ) {
    							$tag = (string) $tag;
    							return ! isset( $origin_label_set[ $tag ] );
    						}
    					)
    				);
    			}



    		        }
    		
    		        settings_errors( 'pmcpc_subscribers' );

    			$kpis = self::get_subscriber_kpis();
    			$stats_items = array();
    			foreach ( array_slice( (array) $kpis, 0, 4 ) as $kpi ) {
    				$stats_items[] = array(
    					'label' => isset( $kpi['label'] ) ? (string) $kpi['label'] : '',
    					'value' => isset( $kpi['value'] ) ? (string) $kpi['value'] : '',
    					'meta'  => isset( $kpi['sub'] ) ? (string) $kpi['sub'] : '',
    				);
    			}

    			PMCPC_Admin::render_page_intro(
    				__( 'Subscribers', 'product-mailer-campaigns' ),
    				__( 'Manage your audience, search and filter subscribers, and handle imports or clean-up tools from one place.', 'product-mailer-campaigns' ),
    				array(
    					array(
    						'label' => __( 'Add and update contacts', 'product-mailer-campaigns' ),
    						'icon'  => 'dashicons-groups',
    					),
    					array(
    						'label' => __( 'Filter segments quickly', 'product-mailer-campaigns' ),
    						'icon'  => 'dashicons-filter',
    					),
    					array(
    						'label' => __( 'Import and maintenance tools below', 'product-mailer-campaigns' ),
    						'icon'  => 'dashicons-admin-tools',
    					),
    				)
    			);
				PMCPC_Admin::render_support_panels(
					array(
						array(
							'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
							'icon'    => 'dashicons-editor-help',
							'title'   => __( 'Keep subscriber management simple', 'product-mailer-campaigns' ),
							'items'   => array(
								__( 'Add or import contacts when you need to grow the list.', 'product-mailer-campaigns' ),
								__( 'Use filters to review subscriber status, source, tags, and lifecycle.', 'product-mailer-campaigns' ),
								__( 'Open Forms or Inbox when you need to test capture flows.', 'product-mailer-campaigns' ),
							),
						),
						array(
							'eyebrow' => __( 'Shortcuts', 'product-mailer-campaigns' ),
							'icon'    => 'dashicons-saved',
							'title'   => __( 'Common audience tasks', 'product-mailer-campaigns' ),
							'actions' => array(
								array( 'label' => __( 'Add Subscriber', 'product-mailer-campaigns' ), 'url' => '#TB_inline?width=620&height=430&inlineId=pmcpc-add-subscriber-modal', 'class' => 'button button-primary thickbox' ),
								array( 'label' => __( 'Open Forms', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_forms' ), 'class' => 'button' ),
								array( 'label' => __( 'Open Inbox', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_inbox' ), 'class' => 'button' ),
							),
						),
					)
				);
    			PMCPC_Admin::render_stats_strip( $stats_items );

    			// Modal content (Thickbox inline) for Add Subscriber.
    			echo '<div id="pmcpc-add-subscriber-modal" style="display:none;">';
    			echo '<div style="padding:12px 14px;">';
    			echo '<h2 style="margin-top:0;">' . esc_html__( 'Add Subscriber', 'product-mailer-campaigns' ) . '</h2>';
    			echo '<form method="post">';
    			wp_nonce_field( 'pmcpc_add_subscriber', 'pmcpc_add_subscriber_nonce' );
    			echo '<table class="form-table" style="margin-top:0;">';
    			echo '<tr><th><label for="pmcpc_email">' . esc_html__( 'Email', 'product-mailer-campaigns' ) . '</label></th>';
    			echo '<td><input name="email" type="email" id="pmcpc_email" class="regular-text" required></td></tr>';
    			echo '<tr><th><label for="pmcpc_first_name">' . esc_html__( 'First Name', 'product-mailer-campaigns' ) . '</label></th>';
    			echo '<td><input name="first_name" type="text" id="pmcpc_first_name" class="regular-text"></td></tr>';
    			echo '<tr><th><label for="pmcpc_last_name">' . esc_html__( 'Last Name', 'product-mailer-campaigns' ) . '</label></th>';
    			echo '<td><input name="last_name" type="text" id="pmcpc_last_name" class="regular-text"></td></tr>';
    			echo '<tr><th><label for="pmcpc_tags">' . esc_html__( 'Preference tags', 'product-mailer-campaigns' ) . '</label></th>';
    			echo '<td><input name="tags" type="text" id="pmcpc_tags" class="regular-text">';
    			echo '<p class="description" style="margin:6px 0 0;">' . esc_html__( 'Optional. Enter preference/other tags separated by commas (e.g. newsletter, VIP). Do not add lifecycle/health/source tags here.', 'product-mailer-campaigns' ) . '</p></td></tr>';
    			echo '</table>';
    			submit_button( __( 'Save Subscriber', 'product-mailer-campaigns' ) );
    			echo '</form>';
    			// Close modal wrappers.
    			echo '</div>';
    			echo '</div>';
    	            echo '<style>
    .pmcpc-subscribers-actionbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:0 0 18px;}
    .pmcpc-subscribers-actionbar__hint{margin:0;color:#646970;font-size:13px;line-height:1.5;max-width:520px;}
    .pmcpc-subscribers-main{display:grid;gap:14px;margin-bottom:22px;}
    .pmcpc-subscribers-secondary{margin:22px 0 0;}
    .pmcpc-subscribers-section{background:#fff;border:1px solid #dcdcde;border-radius:16px;padding:18px;box-shadow:0 10px 24px rgba(15,23,42,.04);margin:0 0 18px;}
    .pmcpc-subscribers-section h2{margin:0 0 8px;}
    .pmcpc-subscribers-section__intro{margin:0 0 14px;color:#646970;max-width:820px;}
    .pmcpc-subscribers-filter-shell{margin:0 0 14px;}
    .pmcpc-subscribers-table-shell{display:grid;gap:10px;}
    .pmcpc-subscribers-sections{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:10px 14px;background:#fff;border:1px solid #dcdcde;border-radius:12px;box-shadow:0 1px 1px rgba(0,0,0,.03);}
    .pmcpc-subscribers-sections__title{font-size:12px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#646970;}
    .pmcpc-subscribers-sections__toggles{display:flex;gap:8px;flex-wrap:wrap;}
    .pmcpc-subscribers-sections__toggles label{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border:1px solid #dcdcde;border-radius:999px;background:#fff;color:#1d2327;font-size:12px;line-height:1.2;cursor:pointer;}
    .pmcpc-subscribers-sections__toggles input{margin:0;}
    .pmcpc-table-card{background:#fff;border:1px solid #ccd0d4;margin:0;border-radius:16px;overflow:hidden;box-shadow:0 10px 24px rgba(15,23,42,.04);}
    .pmcpc-table-scroll{overflow-x:auto; max-width:100%; -webkit-overflow-scrolling:touch;}
    .pmcpc-table-scroll .pmcpc-subscribers-table{width:max-content; min-width:100%; table-layout:fixed; border-collapse:separate; border-spacing:0;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-check{width:42px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-email{width:190px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-name{width:150px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-status{width:88px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-type{width:92px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-birthday{width:95px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-opens{width:70px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-engagement{width:118px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-health{width:82px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-spend{width:96px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-last{width:104px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-lifecycle{width:108px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-source,
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-origin,
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-interest,
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-preference{width:126px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-created{width:118px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table col.pmcpc-col-actions{width:92px;}
    .pmcpc-table-scroll .pmcpc-subscribers-table th,
    .pmcpc-table-scroll .pmcpc-subscribers-table td{vertical-align:top; box-sizing:border-box;}
    /* Default: allow wrapping so the table fits gracefully within fixed columns. */
    .pmcpc-table-scroll .pmcpc-subscribers-table td{white-space:normal; overflow-wrap:anywhere;}
    /* Compact columns stay on one line. */
    .pmcpc-table-scroll .pmcpc-subscribers-table td.pmcpc-col-num,
    .pmcpc-table-scroll .pmcpc-subscribers-table th.pmcpc-col-num,
    .pmcpc-table-scroll .pmcpc-subscribers-table td:nth-child(4),
    .pmcpc-table-scroll .pmcpc-subscribers-table td:nth-child(5),
    .pmcpc-table-scroll .pmcpc-subscribers-table td:nth-child(6),
    .pmcpc-table-scroll .pmcpc-subscribers-table td:nth-child(17),
    .pmcpc-table-scroll .pmcpc-subscribers-table td:nth-child(18){white-space:nowrap; overflow-wrap:normal;}
    /* Email can wrap, but do not compress the whole table to make it happen. */
    .pmcpc-table-scroll .pmcpc-subscribers-table td:nth-child(2){word-break:break-word;}
    .pmcpc-table-scroll .pmcpc-subscribers-table td:nth-child(2){font-weight:600;color:#1d2327;line-height:1.45;}
    .pmcpc-table-scroll .pmcpc-subscribers-table td:nth-child(3){color:#50575e;line-height:1.45;}
    .pmcpc-subscriber-cell-record{display:flex;flex-direction:column;gap:4px;min-width:0;}
    .pmcpc-subscriber-cell-record__title{display:block;font-weight:600;color:#1d2327;line-height:1.45;word-break:break-word;}
    .pmcpc-subscriber-cell-record__meta{display:block;color:#646970;font-size:12px;line-height:1.45;}
    .pmcpc-subscriber-cell-record__meta--empty{font-style:italic;}
    .pmcpc-subscriber-cell-list{color:#50575e;font-size:12px;line-height:1.45;}
    .pmcpc-subscriber-cell-list .pmcpc-subscriber-cell-record__meta{margin:0;}
    .pmcpc-subscriber-cell-value{display:block;color:#1d2327;line-height:1.45;}
    .pmcpc-subscriber-cell-value--muted{color:#8c8f94;font-style:italic;}
    /* Tags wrap nicely. */
    .pmcpc-table-scroll .pmcpc-subscribers-table td.pmcpc-col-tags,
    .pmcpc-table-scroll .pmcpc-subscribers-table th.pmcpc-col-tags{white-space:normal; min-width:120px;}
    .pmcpc-badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;line-height:1.4;font-weight:600;}
    .pmcpc-badge--green{background:#e6f4ea;color:#137333;}
    .pmcpc-badge--amber{background:#fff4e5;color:#8a4b00;}
    .pmcpc-badge--red{background:#fce8e6;color:#a50e0e;}
    .pmcpc-badge--gray{background:#f1f3f4;color:#3c4043;}
    .pmcpc-group-row{display:table-row;}
    .pmcpc-group-row th{border-bottom:1px solid #dcdcde;font-size:11px;text-transform:uppercase;letter-spacing:.08em;text-align:center !important;vertical-align:middle;padding:11px 0 !important;color:#50575e;background:#f8f9fa;font-weight:700;}
    .pmcpc-group-row th.pmcpc-group--subscriber,
    .pmcpc-group-row th.pmcpc-group--engagement,
    .pmcpc-group-row th.pmcpc-group--customer,
    .pmcpc-group-row th.pmcpc-group--tags,
    .pmcpc-group-row th.pmcpc-group--system{background:#f8f9fa;}
    /* Subtle group guides on the main header + body columns (keeps it obvious which columns belong together) */
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(-n+5),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(-n+5){background:#fbfcfe;}
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(6),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(6){background:#fcfdff;}
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(n+7):nth-child(-n+9),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(n+7):nth-child(-n+9){background:#fbfdfb;}
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(n+10):nth-child(-n+12),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(n+10):nth-child(-n+12){background:#fffef9;}
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(n+13):nth-child(-n+16),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(n+13):nth-child(-n+16){background:#fcfbff;}
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(n+17),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(n+17){background:#f8f9fa;}
    /* Vertical separators at real group boundaries */
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(5),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(5),
    table.pmcpc-subscribers-table tbody td:nth-child(5){border-right:1px solid #dcdcde;}
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(6),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(6),
    table.pmcpc-subscribers-table tbody td:nth-child(6){border-right:1px solid #dcdcde;}
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(9),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(9),
    table.pmcpc-subscribers-table tbody td:nth-child(9){border-right:1px solid #dcdcde;}
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(12),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(12),
    table.pmcpc-subscribers-table tbody td:nth-child(12){border-right:1px solid #dcdcde;}
    table.pmcpc-subscribers-table thead tr:nth-child(2) th:nth-child(16),
    table.pmcpc-subscribers-table thead tr.pmcpc-filters-row th:nth-child(16),
    table.pmcpc-subscribers-table tbody td:nth-child(16){border-right:1px solid #dcdcde;}

    .pmcpc-col-num{text-align:right;}
    .pmcpc-col-tags{max-width:220px;white-space:normal;}

    .pmcpc-filters-row th{vertical-align:top; background:#fafafa; padding-top:12px; padding-bottom:12px;}
    .pmcpc-filter-input{width:100%; box-sizing:border-box; max-width:190px;}
    .pmcpc-filter-select{width:100%; box-sizing:border-box; max-width:148px;}
    .pmcpc-filter-input,.pmcpc-filter-select{min-height:36px;}
    .pmcpc-filters-row .button{white-space:nowrap;}
    .pmcpc-help-box{background:#fff; border:1px solid #dcdcde; border-radius:12px; margin:0; box-shadow:0 1px 1px rgba(0,0,0,.03); overflow:hidden;}
    .pmcpc-help-box summary{list-style:none; display:flex; align-items:center; justify-content:space-between; gap:12px; padding:10px 14px; background:#f8fafc; color:#1d2327;}
    .pmcpc-help-box summary::-webkit-details-marker{display:none;}
    .pmcpc-help-box summary{cursor:pointer; font-weight:600;}
    .pmcpc-help-box summary::after{content:"Show"; font-size:11px; font-weight:700; letter-spacing:.04em; text-transform:uppercase; color:#646970;}
    .pmcpc-help-box details[open] summary::after{content:"Hide";}
    .pmcpc-help-box__content{padding:12px 14px 14px; border-top:1px solid #eef0f2; background:#fff;}
    .pmcpc-help-box__content ul{margin:0 0 10px 18px; list-style:disc;}
    .pmcpc-help-box__content p{margin:0;color:#50575e;}
    .pmcpc-admin-tools{border-left:4px solid #72aee6 !important; padding:12px 14px !important;}
    .pmcpc-admin-tools strong{display:inline-block; margin-right:8px;}
    .pmcpc-bulk-actions{margin-top:10px;display:flex;align-items:flex-start;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:12px 14px;background:#fff;border:1px solid #dcdcde;border-radius:12px;box-shadow:0 1px 1px rgba(0,0,0,.03);}
    .pmcpc-bulk-actions__group,.pmcpc-bulk-actions__meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
    .pmcpc-bulk-actions__meta{color:#646970;font-size:12px;}
    .pmcpc-subscriber-row-actions{display:flex;justify-content:flex-end;min-width:0;}
    .pmcpc-subscriber-row-actions__primary{display:none;}
    .pmcpc-subscriber-row-actions__menu{position:relative;display:flex;justify-content:flex-end;width:100%;}
    .pmcpc-subscriber-row-actions__menu summary{list-style:none;display:inline-flex;align-items:center;justify-content:center;min-width:74px;padding:0 8px;min-height:30px;border:1px solid #2271b1;border-radius:4px;background:#fff;color:#135e96;font-size:12px;line-height:1.2;cursor:pointer;}
    .pmcpc-subscriber-row-actions__menu summary::-webkit-details-marker{display:none;}
    .pmcpc-subscriber-row-actions__menu[open] summary{background:#f0f6fc;}
    .pmcpc-subscriber-row-actions__popover{position:absolute;top:calc(100% + 6px);right:0;z-index:20;display:grid;gap:6px;min-width:156px;padding:10px;border:1px solid #dcdcde;border-radius:10px;background:#fff;box-shadow:0 12px 24px rgba(15,23,42,.12);}
    .pmcpc-subscriber-row-actions__popover a{color:#1d2327;text-decoration:none;font-size:12px;line-height:1.35;}
    .pmcpc-subscriber-row-actions__popover a:hover{color:#135e96;}
    .pmcpc-subscriber-row-actions__popover a.pmcpc-subscriber-row-actions__danger{color:#b32d2e;}
    .pmcpc-table-scroll .pmcpc-subscribers-table tbody tr:hover td{background:#fcfdff;}
    .pmcpc-subscribers-table-shell.pmcpc-hide-profile col:nth-child(6),
    .pmcpc-subscribers-table-shell.pmcpc-hide-profile thead tr:nth-child(2) th:nth-child(6),
    .pmcpc-subscribers-table-shell.pmcpc-hide-profile thead tr.pmcpc-filters-row th:nth-child(6),
    .pmcpc-subscribers-table-shell.pmcpc-hide-profile tbody td:nth-child(6){display:none;}
    .pmcpc-subscribers-table-shell.pmcpc-hide-engagement col:nth-child(n+7):nth-child(-n+9),
    .pmcpc-subscribers-table-shell.pmcpc-hide-engagement thead tr:nth-child(2) th:nth-child(n+7):nth-child(-n+9),
    .pmcpc-subscribers-table-shell.pmcpc-hide-engagement thead tr.pmcpc-filters-row th:nth-child(n+7):nth-child(-n+9),
    .pmcpc-subscribers-table-shell.pmcpc-hide-engagement tbody td:nth-child(n+7):nth-child(-n+9){display:none;}
    .pmcpc-subscribers-table-shell.pmcpc-hide-customer col:nth-child(n+10):nth-child(-n+12),
    .pmcpc-subscribers-table-shell.pmcpc-hide-customer thead tr:nth-child(2) th:nth-child(n+10):nth-child(-n+12),
    .pmcpc-subscribers-table-shell.pmcpc-hide-customer thead tr.pmcpc-filters-row th:nth-child(n+10):nth-child(-n+12),
    .pmcpc-subscribers-table-shell.pmcpc-hide-customer tbody td:nth-child(n+10):nth-child(-n+12){display:none;}
    .pmcpc-subscribers-table-shell.pmcpc-hide-tags col:nth-child(n+13):nth-child(-n+16),
    .pmcpc-subscribers-table-shell.pmcpc-hide-tags thead tr:nth-child(2) th:nth-child(n+13):nth-child(-n+16),
    .pmcpc-subscribers-table-shell.pmcpc-hide-tags thead tr.pmcpc-filters-row th:nth-child(n+13):nth-child(-n+16),
    .pmcpc-subscribers-table-shell.pmcpc-hide-tags tbody td:nth-child(n+13):nth-child(-n+16){display:none;}
    .pmcpc-subscribers-table-shell.pmcpc-hide-system col:nth-child(n+17):nth-child(-n+18),
    .pmcpc-subscribers-table-shell.pmcpc-hide-system thead tr:nth-child(2) th:nth-child(n+17):nth-child(-n+18),
    .pmcpc-subscribers-table-shell.pmcpc-hide-system thead tr.pmcpc-filters-row th:nth-child(n+17):nth-child(-n+18),
    .pmcpc-subscribers-table-shell.pmcpc-hide-system tbody td:nth-child(n+17):nth-child(-n+18){display:none;}
    .pmcpc-subscribers-table-shell.pmcpc-hide-profile .pmcpc-group-row .pmcpc-group--profile,
    .pmcpc-subscribers-table-shell.pmcpc-hide-engagement .pmcpc-group-row .pmcpc-group--engagement,
    .pmcpc-subscribers-table-shell.pmcpc-hide-customer .pmcpc-group-row .pmcpc-group--customer,
    .pmcpc-subscribers-table-shell.pmcpc-hide-tags .pmcpc-group-row .pmcpc-group--tags,
    .pmcpc-subscribers-table-shell.pmcpc-hide-system .pmcpc-group-row .pmcpc-group--system{display:none;}
    .pmcpc-crm-card{background:#fff;border:1px solid #dcdcde;border-radius:16px;padding:18px;box-shadow:0 10px 24px rgba(15,23,42,.04);margin:0 0 18px;}
    .pmcpc-crm-card h2,.pmcpc-crm-card h3{margin-top:0;}
    .pmcpc-crm-card__intro{margin:-4px 0 14px;color:#50575e;font-size:13px;}
    .pmcpc-crm-card__stack{display:grid;gap:10px;}
    .pmcpc-crm-definition-list{display:grid;grid-template-columns:minmax(140px,180px) minmax(0,1fr);gap:10px 16px;margin:0;}
    .pmcpc-crm-definition-list dt{margin:0;font-weight:600;color:#1d2327;}
    .pmcpc-crm-definition-list dd{margin:0;color:#2c3338;}
    .pmcpc-crm-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;}
    .pmcpc-crm-field{display:grid;gap:6px;}
    .pmcpc-crm-field label{font-weight:600;color:#1d2327;}
    .pmcpc-crm-field .description{margin:0;color:#646970;}
    .pmcpc-crm-field input[type="text"],.pmcpc-crm-field input[type="date"],.pmcpc-crm-field select{max-width:none;width:100%;}
    .pmcpc-crm-activity-table{margin-top:10px;}
    .pmcpc-crm-activity-table table{min-width:760px;}
    .pmcpc-crm-activity-table th,.pmcpc-crm-activity-table td{vertical-align:top;}
    .pmcpc-crm-activity-table th:nth-child(1),.pmcpc-crm-activity-table td:nth-child(1){width:20%;white-space:nowrap;}
    .pmcpc-crm-activity-table th:nth-child(2),.pmcpc-crm-activity-table td:nth-child(2){width:14%;white-space:nowrap;}
    .pmcpc-crm-activity-table th:nth-child(3),.pmcpc-crm-activity-table td:nth-child(3){width:30%;}
    .pmcpc-crm-activity-table th:nth-child(4),.pmcpc-crm-activity-table td:nth-child(4){width:36%;}
    .pmcpc-crm-backlink{margin:14px 0 0;}
    @media (max-width:782px){
        .pmcpc-subscribers-actionbar{flex-direction:column;align-items:stretch;}
        .pmcpc-subscribers-actionbar .button{width:100%;justify-content:center;}
        .pmcpc-bulk-actions{align-items:stretch;}
        .pmcpc-bulk-actions__group,.pmcpc-bulk-actions__meta{width:100%;}
        .pmcpc-bulk-actions .button,.pmcpc-bulk-actions .button-secondary,.pmcpc-bulk-actions .button-link-delete{width:100%;justify-content:center;}
        .pmcpc-bulk-actions input[type="text"]{width:100% !important;max-width:none;}
        .pmcpc-subscriber-row-actions{min-width:0;}
        .pmcpc-crm-definition-list{grid-template-columns:1fr;}
    }
    </style>';

    	        echo '<div class="pmcpc-subscribers-actionbar">';
    	        echo '<a href="#TB_inline?width=640&height=520&inlineId=pmcpc-add-subscriber-modal" class="button button-primary thickbox">' . esc_html__( 'Add Subscriber', 'product-mailer-campaigns' ) . '</a>';
    	        echo '<a href="#pmcpc-subscriber-import-tools" class="button">' . esc_html__( 'Import Users', 'product-mailer-campaigns' ) . '</a>';
    	        echo '<p class="pmcpc-subscribers-actionbar__hint">' . esc_html__( 'Use filters and bulk actions to manage the subscriber table first. Import and maintenance tools stay available lower on the page.', 'product-mailer-campaigns' ) . '</p>';
    	        echo '</div>';

    	        echo '<div class="pmcpc-subscribers-main">';

    	        // Help / legend for the Subscribers table columns.
    	        // NOTE: We intentionally avoid using the WP "notice" classes because some admin themes/plugins
    	        // auto-dismiss notices after a few seconds, which makes this legend disappear.
    	        echo '<div class="pmcpc-help-box">';
    	        echo '<details>';
    	        echo '<summary>' . esc_html__( 'Column guide', 'product-mailer-campaigns' ) . '</summary>';
    	        echo '<div class="pmcpc-help-box__content">';
    	                echo '<ul>';
            echo '<li><strong>' . esc_html__( 'Email', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'The unique identifier for the subscriber.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Name', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Optional first/last name captured from forms, WooCommerce billing details, or entered by an admin.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Active subscribers can receive campaigns. Pending are awaiting double opt-in confirmation (if enabled). Unsubscribed will not receive emails.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Opens', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Lifetime tracked opens for this subscriber (from campaign tracking).', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Engagement', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'A quick badge based on recent opens (e.g. Engaged in the last 30 days).', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Health', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Deliverability / attention indicator derived from recent engagement (Hot/Warm/Slipping/Cold). Use “Filter by health” to segment.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Total spend', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Lifetime total from WooCommerce completed orders for this billing email. Blank if WooCommerce is not active or there are no completed orders.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Last purchase', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'The date of the most recent WooCommerce completed order for this billing email.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Lifecycle', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Auto-managed purchase-behaviour tags derived from WooCommerce orders (when enabled), such as new-customer, repeat-customer, VIP, or lapsed-customer.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Source', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'How they joined your list (e.g. signup-form, wc-registration, contact-optin, imported, admin).', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Origin', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Technical audit trail for where the record was created, stored internally as origin:* tags (shown without the prefix). Mainly for troubleshooting.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Interest', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Content/intent tags (what they want to receive), such as newsletter or product-updates.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Preference', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Admin-defined tags used for segmentation (e.g. VIP, trade, showroom). Profile data such as birthday is shown separately and is not treated as a preference tag.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Birthday', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Profile field used by the Subscriber birthday automation. Stored separately from preference tags so segmentation stays clean.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Created', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'When the subscriber record was created (useful for auditing imports and signup spikes).', 'product-mailer-campaigns' ) . '</li>';
            echo '<li><strong>' . esc_html__( 'Selected actions', 'product-mailer-campaigns' ) . '</strong> — ' . esc_html__( 'Tick one or more subscribers, then use the action bar outside the table to add/remove tags, unsubscribe/resubscribe, block domains, or delete.', 'product-mailer-campaigns' ) . '</li>';
            echo '</ul>';
    	        echo '<p>' . esc_html__( 'Tip: Use Interest tags to target what people want, Source to segment acquisition, Lifecycle to target purchase behaviour, and Health to spot who is drifting before they unsubscribe.', 'product-mailer-campaigns' ) . '</p>';
    	        echo '</div>';
    	        echo '</details>';
    	        echo '</div>';
    		
    		        echo '<form id="pmcpc_subscribers_filters" method="get" style="margin:0; padding:0;">';
    		        echo '<input type="hidden" name="page" value="pmcpc_subscribers">';
    		        echo '</form>';
    		
    		        if ( $subscribers ) {
    		            echo '<form method="post">';
    		            wp_nonce_field( 'pmcpc_bulk_delete_subscribers', 'pmcpc_bulk_delete_subscribers_nonce' );
    		            echo '<div class="pmcpc-subscribers-table-shell pmcpc-subscribers-view-essential" id="pmcpc-subscribers-table-shell">';
    		            echo '<div class="pmcpc-subscribers-sections">';
    		            echo '<div class="pmcpc-subscribers-sections__title">' . esc_html__( 'Table view', 'product-mailer-campaigns' ) . '</div>';
    		            echo '<div class="pmcpc-subscribers-viewmode" role="group" aria-label="' . esc_attr__( 'Subscriber table view', 'product-mailer-campaigns' ) . '">';
    		            echo '<button type="button" class="button pmcpc-subscribers-viewmode-button" data-view="essential">' . esc_html__( 'Essential', 'product-mailer-campaigns' ) . '</button>';
    		            echo '<button type="button" class="button pmcpc-subscribers-viewmode-button" data-view="full">' . esc_html__( 'Full', 'product-mailer-campaigns' ) . '</button>';
    		            echo '</div>';
    		            echo '<div class="pmcpc-subscribers-sections__toggles" aria-label="' . esc_attr__( 'Full view sections', 'product-mailer-campaigns' ) . '">';
    		            echo '<label><input type="checkbox" class="pmcpc-subscribers-section-toggle" data-section="profile" checked="checked" />' . esc_html__( 'Profile', 'product-mailer-campaigns' ) . '</label>';
    		            echo '<label><input type="checkbox" class="pmcpc-subscribers-section-toggle" data-section="engagement" checked="checked" />' . esc_html__( 'Engagement', 'product-mailer-campaigns' ) . '</label>';
    		            echo '<label><input type="checkbox" class="pmcpc-subscribers-section-toggle" data-section="customer" checked="checked" />' . esc_html__( 'Customer', 'product-mailer-campaigns' ) . '</label>';
    		            echo '<label><input type="checkbox" class="pmcpc-subscribers-section-toggle" data-section="tags" checked="checked" />' . esc_html__( 'Tags & Source', 'product-mailer-campaigns' ) . '</label>';
    		            echo '<label><input type="checkbox" class="pmcpc-subscribers-section-toggle" data-section="system" checked="checked" />' . esc_html__( 'System', 'product-mailer-campaigns' ) . '</label>';
    		            echo '</div></div>';
    		            echo '<div class="pmcpc-subscribers-filter-actions">';
    		            echo '<button form="pmcpc_subscribers_filters" type="submit" class="button button-secondary">' . esc_html__( 'Apply filters', 'product-mailer-campaigns' ) . '</button>';
    		            echo '<a class="button button-link-delete" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_subscribers' ) ) . '">' . esc_html__( 'Reset filters', 'product-mailer-campaigns' ) . '</a>';
    		            echo '<span class="description">' . esc_html__( 'Essential view keeps the day-to-day columns visible; Full view unlocks every section.', 'product-mailer-campaigns' ) . '</span>';
    		            echo '</div>';
    		            echo '<div class="pmcpc-table-card"><div class="pmcpc-table-scroll">';
    		            echo '<table class="widefat striped pmcpc-subscribers-table">';
    		            echo '<colgroup>';
    		            echo '<col class="pmcpc-col-check" />';
    		            echo '<col class="pmcpc-col-email" />';
    		            echo '<col class="pmcpc-col-name" />';
    		            echo '<col class="pmcpc-col-status" />';
    		            echo '<col class="pmcpc-col-type" />';
    		            echo '<col class="pmcpc-col-birthday" />';
    		            echo '<col class="pmcpc-col-opens" />';
    		            echo '<col class="pmcpc-col-engagement" />';
    		            echo '<col class="pmcpc-col-health" />';
    		            echo '<col class="pmcpc-col-spend" />';
    		            echo '<col class="pmcpc-col-last" />';
    		            echo '<col class="pmcpc-col-lifecycle" />';
    		            echo '<col class="pmcpc-col-source" />';
    		            echo '<col class="pmcpc-col-origin" />';
    		            echo '<col class="pmcpc-col-interest" />';
    		            echo '<col class="pmcpc-col-preference" />';
    		            echo '<col class="pmcpc-col-created" />';
    		            echo '</colgroup>';
    		            echo '<thead>';
    					echo '<tr class="pmcpc-group-row">';
    					echo '<th class="pmcpc-group pmcpc-group--subscriber" colspan="5">' . esc_html__( 'Subscriber', 'product-mailer-campaigns' ) . '</th>';
    					echo '<th class="pmcpc-group pmcpc-group--profile" colspan="1">' . esc_html__( 'Profile', 'product-mailer-campaigns' ) . '</th>';
    					echo '<th class="pmcpc-group pmcpc-group--engagement" colspan="3">' . esc_html__( 'Engagement', 'product-mailer-campaigns' ) . '</th>';
    					echo '<th class="pmcpc-group pmcpc-group--customer" colspan="3">' . esc_html__( 'Customer', 'product-mailer-campaigns' ) . '</th>';
    					echo '<th class="pmcpc-group pmcpc-group--tags" colspan="4">' . esc_html__( 'Tags & Source', 'product-mailer-campaigns' ) . '</th>';
    					echo '<th class="pmcpc-group pmcpc-group--system" colspan="1">' . esc_html__( 'System', 'product-mailer-campaigns' ) . '</th>';
    					echo '</tr>';
    					echo '<tr>';
    		            echo '<th class="check-column"><input type="checkbox" id="pmcpc-subscribers-select-all" /></th>';
    		            echo '<th>' . esc_html__( 'Email', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th>' . esc_html__( 'Name', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th>' . esc_html__( 'Type', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th>' . esc_html__( 'Birthday', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th class="pmcpc-col-num">' . esc_html__( 'Opens', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th>' . esc_html__( 'Engagement', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th>' . esc_html__( 'Health', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th class="pmcpc-col-num">' . esc_html__( 'Total spend', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th>' . esc_html__( 'Last purchase', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th>' . esc_html__( 'Lifecycle', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th class="pmcpc-col-tags">' . esc_html__( 'Source', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th class="pmcpc-col-tags">' . esc_html__( 'Origin', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th class="pmcpc-col-tags">' . esc_html__( 'Interest', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th class="pmcpc-col-tags">' . esc_html__( 'Preference', 'product-mailer-campaigns' ) . '</th>';
    		            echo '<th>' . esc_html__( 'Created', 'product-mailer-campaigns' ) . '</th>';

    					// Close the column header row before outputting the filters row.
    					echo '</tr>';
    					echo '<tr class="pmcpc-filters-row">';
    					echo '<th class="check-column"></th>';
    					// Email search.
    					echo '<th><input form="pmcpc_subscribers_filters" type="search" name="pmcpc_search" value="' . esc_attr( $search_query ) . '" placeholder="' . esc_attr__( 'Search email or name…', 'product-mailer-campaigns' ) . '" class="pmcpc-filter-input" /></th>';
    					// Name.
    					echo '<th><input form="pmcpc_subscribers_filters" type="search" name="pmcpc_name" value="' . esc_attr( $name_query ) . '" placeholder="' . esc_attr__( 'Name…', 'product-mailer-campaigns' ) . '" class="pmcpc-filter-input" /></th>';
    					// Status.
    					echo '<th><select form="pmcpc_subscribers_filters" name="pmcpc_status" class="pmcpc-filter-select">';
    					echo '<option value="">' . esc_html__( 'All', 'product-mailer-campaigns' ) . '</option>';
    					echo '<option value="pending"' . selected( 'pending', $status_filter, false ) . '>' . esc_html__( 'Pending', 'product-mailer-campaigns' ) . '</option>';
    					echo '<option value="active"' . selected( 'active', $status_filter, false ) . '>' . esc_html__( 'Active', 'product-mailer-campaigns' ) . '</option>';
    					echo '<option value="unsubscribed"' . selected( 'unsubscribed', $status_filter, false ) . '>' . esc_html__( 'Unsubscribed', 'product-mailer-campaigns' ) . '</option>';
    					echo '</select></th>';
    					// Type (Subscriber vs Customer).
    					echo '<th><select form="pmcpc_subscribers_filters" name="pmcpc_customer" class="pmcpc-filter-select">';
    					echo '<option value="">' . esc_html__( 'Any', 'product-mailer-campaigns' ) . '</option>';
    					echo '<option value="subscriber"' . selected( 'subscriber', $customer_filter, false ) . '>' . esc_html__( 'Subscriber', 'product-mailer-campaigns' ) . '</option>';
    					echo '<option value="customer"' . selected( 'customer', $customer_filter, false ) . '>' . esc_html__( 'Customer', 'product-mailer-campaigns' ) . '</option>';
    					echo '</select></th>';
    					// Birthday (no filter yet).
    					echo '<th></th>';
    					// Opens (no filter).
    					echo '<th></th>';
    					// Engagement (select replaces the two checkboxes).
    					echo '<th><select form="pmcpc_subscribers_filters" name="pmcpc_engagement" class="pmcpc-filter-select">';
    					echo '<option value="">' . esc_html__( 'Any', 'product-mailer-campaigns' ) . '</option>';
    					echo '<option value="no_opens"' . selected( 'no_opens', $engagement_filter, false ) . '>' . esc_html__( 'No opens', 'product-mailer-campaigns' ) . '</option>';
    					echo '<option value="has_opens"' . selected( 'has_opens', $engagement_filter, false ) . '>' . esc_html__( 'Has opens', 'product-mailer-campaigns' ) . '</option>';
    					echo '</select></th>';
    					// Health.
    					echo '<th><select form="pmcpc_subscribers_filters" name="pmcpc_health" class="pmcpc-filter-select">';
    					echo '<option value="">' . esc_html__( 'All', 'product-mailer-campaigns' ) . '</option>';
    					foreach ( $health_options as $tag ) {
    						$label = isset( $health_labels[ $tag ] ) ? $health_labels[ $tag ] : $tag;
    						echo '<option value="' . esc_attr( $tag ) . '"' . selected( $health_filter, $tag, false ) . '>' . esc_html( $label ) . '</option>';
    					}
    					echo '</select></th>';
    					// Total spend.
    					echo '<th></th>';
    					// Last purchase.
    					echo '<th></th>';
    					// Lifecycle.
    					echo '<th><select form="pmcpc_subscribers_filters" name="pmcpc_lifecycle" class="pmcpc-filter-select">';
    					echo '<option value="">' . esc_html__( 'All', 'product-mailer-campaigns' ) . '</option>';
    					foreach ( $lifecycle_options as $tag ) {
    						echo '<option value="' . esc_attr( $tag ) . '"' . selected( $lifecycle_filter, $tag, false ) . '>' . esc_html( $tag ) . '</option>';
    					}
    					echo '</select></th>';
    					// Source.
    					echo '<th><select form="pmcpc_subscribers_filters" name="pmcpc_source" class="pmcpc-filter-select">';
    					echo '<option value="">' . esc_html__( 'All', 'product-mailer-campaigns' ) . '</option>';
    					foreach ( $source_options as $tag ) {
    						echo '<option value="' . esc_attr( $tag ) . '"' . selected( $source_filter, $tag, false ) . '>' . esc_html( $tag ) . '</option>';
    					}
    					echo '</select></th>';
    					// Origin.
    					echo '<th><select form="pmcpc_subscribers_filters" name="pmcpc_origin" class="pmcpc-filter-select">';
    					echo '<option value="">' . esc_html__( 'All', 'product-mailer-campaigns' ) . '</option>';
    					foreach ( $origin_options as $origin_tag ) {
    						$origin_label = preg_replace( '/^origin:/', '', (string) $origin_tag );
    						echo '<option value="' . esc_attr( $origin_tag ) . '"' . selected( $origin_filter, $origin_tag, false ) . '>' . esc_html( $origin_label ) . '</option>';
    					}
    					echo '</select></th>';
    					// Interest.
    					echo '<th><select form="pmcpc_subscribers_filters" name="pmcpc_interest" class="pmcpc-filter-select">';
    					echo '<option value="">' . esc_html__( 'All', 'product-mailer-campaigns' ) . '</option>';
    					foreach ( $interest_options as $tag ) {
    						echo '<option value="' . esc_attr( $tag ) . '"' . selected( $interest_filter, $tag, false ) . '>' . esc_html( $tag ) . '</option>';
    					}
    					echo '</select></th>';
    					// Other tags.
    					echo '<th><select form="pmcpc_subscribers_filters" name="pmcpc_other_tag" class="pmcpc-filter-select">';
    					echo '<option value="">' . esc_html__( 'All', 'product-mailer-campaigns' ) . '</option>';
    					foreach ( $other_tag_options as $tag ) {
    						echo '<option value="' . esc_attr( $tag ) . '"' . selected( $other_filter, $tag, false ) . '>' . esc_html( $tag ) . '</option>';
    					}
    					echo '</select></th>';
    					// Created.
    					echo '<th>';
    					echo '<input form="pmcpc_subscribers_filters" type="date" name="pmcpc_created_after" value="' . esc_attr( $created_after ) . '" class="pmcpc-filter-input" style="max-width:160px; margin-bottom:4px;" />';
    					echo '<input form="pmcpc_subscribers_filters" type="date" name="pmcpc_created_before" value="' . esc_attr( $created_before ) . '" class="pmcpc-filter-input" style="max-width:160px;" />';
    					echo '</th>';
    					echo '</tr>';

    		            echo '</thead><tbody>';
    		
    		            foreach ( $subscribers as $sub ) {
    		                $name      = trim( $sub->first_name . ' ' . $sub->last_name );
    		                		                $timeline_url = admin_url( 'admin.php?page=pmcpc_subscribers&subscriber_id=' . (int) $sub->id );
    		                $tags     = self::get_tags_for_subscriber( $sub->id );
    		                $bucketed = self::split_tags( $tags );
    		
    		                $delete_url = wp_nonce_url(
    		                    add_query_arg(
    		                        array(
    		                            'page'                  => 'pmcpc_subscribers',
    		                            'pmcpc_delete_subscriber' => (int) $sub->id,
    		                        ),
    		                        admin_url( 'admin.php' )
    		                    ),
    		                    'pmcpc_delete_subscriber_' . (int) $sub->id,
    		                    'pmcpc_delete_nonce'
    		                );
    		
    		                $unsub_url = wp_nonce_url(
    		                    add_query_arg(
    		                        array(
    		                            'page'                 => 'pmcpc_subscribers',
    		                            'pmcpc_unsub_subscriber' => (int) $sub->id,
    		                        ),
    		                        admin_url( 'admin.php' )
    		                    ),
    		                    'pmcpc_unsub_subscriber_' . (int) $sub->id,
    		                    'pmcpc_unsub_nonce'
    		                );
    		
    		
    		                $block_domain_url = wp_nonce_url(
    		                    add_query_arg(
    		                        array(
    		                            'page'             => 'pmcpc_subscribers',
    		                            'pmcpc_block_domain' => (int) $sub->id,
    		                        ),
    		                        admin_url( 'admin.php' )
    		                    ),
    		                    'pmcpc_block_domain_' . (int) $sub->id,
    		                    'pmcpc_block_domain_nonce'
    		                );
    		
    		                echo '<tr>';
    		                echo '<td class="check-column"><input type="checkbox" class="pmcpc-subscriber-checkbox" name="pmcpc_subscriber_ids[]" value="' . (int) $sub->id . '" /></td>';
    		                echo '<td><div class="pmcpc-subscriber-cell-record"><a class="pmcpc-subscriber-cell-record__title pmcpc-subscriber-email-link" href="' . esc_url( $timeline_url ) . '">' . esc_html( $sub->email ) . '</a></div></td>';
    		                echo '<td><div class="pmcpc-subscriber-cell-record">' . ( '' !== $name ? '<span class="pmcpc-subscriber-cell-record__title">' . esc_html( $name ) . '</span>' : '<span class="pmcpc-subscriber-cell-record__meta pmcpc-subscriber-cell-record__meta--empty">' . esc_html__( 'No name on file', 'product-mailer-campaigns' ) . '</span>' ) . '</div></td>';
    		                $pmcpc_status_class = 'pmcpc-badge--gray';
    		                if ( 'active' === $sub->status ) {
    		                    $pmcpc_status_class = 'pmcpc-badge--green';
    		                } elseif ( 'pending' === $sub->status ) {
    		                    $pmcpc_status_class = 'pmcpc-badge--amber';
    		                } elseif ( 'unsubscribed' === $sub->status ) {
    		                    $pmcpc_status_class = 'pmcpc-badge--gray';
    		                }
    		                echo '<td><span class="pmcpc-badge ' . esc_attr( $pmcpc_status_class ) . '">' . esc_html( ucfirst( (string) $sub->status ) ) . '</span></td>';
    						$pmcpc_is_customer = ! empty( $bucketed['lifecycle'] );
    						$pmcpc_type_label  = $pmcpc_is_customer ? __( 'Customer', 'product-mailer-campaigns' ) : __( 'Subscriber', 'product-mailer-campaigns' );
    						$pmcpc_type_class  = $pmcpc_is_customer ? 'pmcpc-badge--green' : 'pmcpc-badge--gray';
    						echo '<td><span class="pmcpc-badge ' . esc_attr( $pmcpc_type_class ) . '">' . esc_html( $pmcpc_type_label ) . '</span></td>';
    		                $birthday_value = self::get_subscriber_birthday( (int) $sub->id );
    		                $birthday_display = '';
    		                if ( '' !== $birthday_value ) {
    		                    $birthday_ts = strtotime( $birthday_value );
    		                    $birthday_display = $birthday_ts ? date_i18n( 'd M', $birthday_ts ) : '';
    		                    if ( '' === $birthday_display ) {
    		                        $parts = explode( '-', $birthday_value );
    		                        if ( 3 === count( $parts ) && checkdate( (int) $parts[1], (int) $parts[2], 2000 ) ) {
    		                            $birthday_display = date_i18n( 'd M', mktime( 0, 0, 0, (int) $parts[1], (int) $parts[2], 2000 ) );
    		                        } else {
    		                            $birthday_display = $birthday_value;
    		                        }
    		                    }
    		                }
    		                echo '<td><span class="pmcpc-subscriber-cell-value' . ( '' === $birthday_display ? ' pmcpc-subscriber-cell-value--muted' : '' ) . '">' . esc_html( '' !== $birthday_display ? $birthday_display : '—' ) . '</span></td>';
    		                echo '<td class="pmcpc-col-num">' . esc_html( number_format_i18n( (int) $sub->lifetime_opens ) ) . '</td>';

    		                // Engagement badge (email opens + recency).
    		                $pmcpc_engagement_label = '';
    		                $pmcpc_now_ts  = (int) current_time( 'timestamp' );
    		                $pmcpc_last_ts = ! empty( $sub->last_engaged_at ) ? (int) strtotime( (string) $sub->last_engaged_at ) : 0;
    		                $pmcpc_days    = ( $pmcpc_last_ts > 0 ) ? (int) floor( ( $pmcpc_now_ts - $pmcpc_last_ts ) / DAY_IN_SECONDS ) : 9999;

    		                if ( 'active' !== $sub->status ) {
    		                    $pmcpc_engagement_label = __( 'Not active', 'product-mailer-campaigns' );
    		                } elseif ( (int) $sub->lifetime_opens <= 0 ) {
    		                    $pmcpc_engagement_label = __( 'No opens', 'product-mailer-campaigns' );
    		                } elseif ( $pmcpc_days <= 30 ) {
    		                    $pmcpc_engagement_label = __( 'Engaged (30d)', 'product-mailer-campaigns' );
    		                } elseif ( $pmcpc_days <= 60 ) {
    		                    $pmcpc_engagement_label = __( 'Warm (60d)', 'product-mailer-campaigns' );
    		                } elseif ( $pmcpc_days <= 90 ) {
    		                    $pmcpc_engagement_label = __( 'Cold (90d)', 'product-mailer-campaigns' );
    		                } else {
    		                    $pmcpc_engagement_label = __( 'Inactive (90d+)', 'product-mailer-campaigns' );
    		                }

    		                $pmcpc_badge_class = 'pmcpc-badge--gray';
    		                if ( false !== strpos( $pmcpc_engagement_label, 'Engaged' ) ) {
    		                    $pmcpc_badge_class = 'pmcpc-badge--green';
    		                } elseif ( false !== strpos( $pmcpc_engagement_label, 'Warm' ) ) {
    		                    $pmcpc_badge_class = 'pmcpc-badge--amber';
    		                } elseif ( false !== strpos( $pmcpc_engagement_label, 'Cold' ) ) {
    		                    $pmcpc_badge_class = 'pmcpc-badge--red';
    		                } elseif ( false !== strpos( $pmcpc_engagement_label, 'No opens' ) || false !== strpos( $pmcpc_engagement_label, 'Inactive' ) ) {
    		                    $pmcpc_badge_class = 'pmcpc-badge--gray';
    		                }

    		                echo '<td><span class="pmcpc-badge ' . esc_attr( $pmcpc_badge_class ) . '">' . esc_html( $pmcpc_engagement_label ) . '</span></td>';

    		                // Health badge (derived from stored health:* tags).
    		                $pmcpc_health_label = '';
    		                $pmcpc_health_class = 'pmcpc-badge--gray';
    		                $pmcpc_health_tag   = '';

    		                // Tags are used below for segmentation; grab them early for health, too.
    		                if ( ! empty( $tags ) && is_array( $tags ) ) {
    		                    foreach ( $tags as $t ) {
    		                        if ( 0 === strpos( $t, 'health:' ) ) {
    		                            $pmcpc_health_tag = $t;
    		                            break;
    		                        }
    		                    }
    		                }

    		                if ( 'health:hot' === $pmcpc_health_tag ) {
    		                    $pmcpc_health_label = __( 'Hot', 'product-mailer-campaigns' );
    		                    $pmcpc_health_class = 'pmcpc-badge--green';
    		                } elseif ( 'health:warm' === $pmcpc_health_tag ) {
    		                    $pmcpc_health_label = __( 'Warm', 'product-mailer-campaigns' );
    		                    $pmcpc_health_class = 'pmcpc-badge--amber';
    		                } elseif ( 'health:cold' === $pmcpc_health_tag ) {
    		                    $pmcpc_health_label = __( 'Cold', 'product-mailer-campaigns' );
    		                    $pmcpc_health_class = 'pmcpc-badge--red';
    		                } elseif ( '' !== $pmcpc_health_tag ) {
    		                    // Fallback for any other health:* value.
    		                    $pmcpc_health_label = str_replace( 'health:', '', $pmcpc_health_tag );
    		                    $pmcpc_health_class = 'pmcpc-badge--gray';
    		                } else {
    		                    $pmcpc_health_label = '';
    		                }

    		                echo '<td>' . ( '' !== $pmcpc_health_label ? '<span class="pmcpc-badge ' . esc_attr( $pmcpc_health_class ) . '">' . esc_html( $pmcpc_health_label ) . '</span>' : '' ) . '</td>';

    		                // WooCommerce purchase summary (if WooCommerce is active).
    		                $wc_stats = self::get_wc_purchase_stats_for_email( $sub->email );
    		                $spend    = isset( $wc_stats['total_spend'] ) ? (float) $wc_stats['total_spend'] : 0.0;
    		                $last_ts  = isset( $wc_stats['last_completed_ts'] ) ? (int) $wc_stats['last_completed_ts'] : 0;

    		                if ( function_exists( 'wc_price' ) ) {
    		                    $spend_display = $spend > 0 ? wc_price( $spend ) : '';
    		                } else {
    		                    $spend_display = $spend > 0 ? number_format_i18n( $spend, 2 ) : '';
    		                }

    		                $last_display = $last_ts > 0 ? date_i18n( get_option( 'date_format' ), $last_ts ) : '';

    		                echo '<td class="pmcpc-col-num"><span class="pmcpc-subscriber-cell-value' . ( '' === wp_strip_all_tags( $spend_display ) ? ' pmcpc-subscriber-cell-value--muted' : '' ) . '">' . ( '' !== $spend_display ? wp_kses_post( $spend_display ) : esc_html__( '—', 'product-mailer-campaigns' ) ) . '</span></td>';
    		                echo '<td><span class="pmcpc-subscriber-cell-value' . ( '' === $last_display ? ' pmcpc-subscriber-cell-value--muted' : '' ) . '">' . esc_html( '' !== $last_display ? $last_display : '—' ) . '</span></td>';

    		                // Split tags into categories for table display.
    								$bucketed = self::split_tags( $tags );

    								$interest_values  = $bucketed['interest'];
    								$source_values    = $bucketed['source'];
    								$origin_values    = $bucketed['origin'];
    								$lifecycle_values = $bucketed['lifecycle'];
    								$health_values    = $bucketed['health'];
    								$other_values     = $bucketed['other'];

    								// Prepare origin labels for display (strip "origin:" prefix where present).
    		                $origin_labels = array();
    		                foreach ( $origin_values as $origin_tag ) {
    		                    if ( 0 === strpos( $origin_tag, 'origin:' ) ) {
    		                        $origin_labels[] = substr( $origin_tag, 7 );
    		                    } else {
    		                        $origin_labels[] = $origin_tag;
    		                    }
    		                }
    		                $origin_labels = array_values( array_unique( $origin_labels ) );

    		                echo '<td><span class="pmcpc-subscriber-cell-list">' . esc_html( $lifecycle_values ? implode( ', ', $lifecycle_values ) : '—' ) . '</span></td>';
    		                echo '<td><span class="pmcpc-subscriber-cell-list">' . esc_html( $source_values ? implode( ', ', $source_values ) : '—' ) . '</span></td>';
    		                echo '<td><span class="pmcpc-subscriber-cell-list">' . esc_html( $origin_labels ? implode( ', ', $origin_labels ) : '—' ) . '</span></td>';
    		                echo '<td><span class="pmcpc-subscriber-cell-list">' . esc_html( $interest_values ? implode( ', ', $interest_values ) : '—' ) . '</span></td>';
    		                echo '<td><span class="pmcpc-subscriber-cell-list">' . esc_html( $other_values ? implode( ', ', $other_values ) : '—' ) . '</span></td>';
    						echo '<td><span class="pmcpc-subscriber-cell-value">' . esc_html( $sub->created_at ) . '</span></td>';

    		
    		                echo '</tr>';
    		            }
    		
    		            echo '</tbody></table>';
    		            echo '</div>';
    		            echo '</div>';
    		            echo '</div>';
    		
    		            echo '<div class="pmcpc-bulk-actions pmcpc-selected-actions">';
    		            echo '<div class="pmcpc-bulk-actions__group">';
    		            echo '<label for="pmcpc_bulk_action" class="screen-reader-text">' . esc_html__( 'Selected subscriber action', 'product-mailer-campaigns' ) . '</label>';
    		            echo '<select name="pmcpc_bulk_action" id="pmcpc_bulk_action" class="pmcpc-filter-select">';
    		            echo '<option value="">' . esc_html__( 'Choose action…', 'product-mailer-campaigns' ) . '</option>';
    		            echo '<option value="add_tag">' . esc_html__( 'Add tag', 'product-mailer-campaigns' ) . '</option>';
    		            echo '<option value="remove_tag">' . esc_html__( 'Remove tag', 'product-mailer-campaigns' ) . '</option>';
    		            echo '<option value="unsubscribe">' . esc_html__( 'Unsubscribe selected', 'product-mailer-campaigns' ) . '</option>';
    		            echo '<option value="resubscribe">' . esc_html__( 'Resubscribe selected', 'product-mailer-campaigns' ) . '</option>';
    		            echo '<option value="block_domain">' . esc_html__( 'Block selected domains', 'product-mailer-campaigns' ) . '</option>';
    		            echo '<option value="delete">' . esc_html__( 'Delete selected', 'product-mailer-campaigns' ) . '</option>';
    		            echo '</select>';
    		            echo '<label for="pmcpc_bulk_tag" class="pmcpc-bulk-tag-label">' . esc_html__( 'Tag:', 'product-mailer-campaigns' ) . '</label>';
    		            echo '<input type="text" name="pmcpc_bulk_tag" id="pmcpc_bulk_tag" class="regular-text" placeholder="' . esc_attr__( 'Tag name', 'product-mailer-campaigns' ) . '" />';
    		            submit_button( __( 'Apply to selected', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_bulk_apply', false );
    		            echo '</div>';
    		            echo '<div class="pmcpc-bulk-actions__meta"><span>' . esc_html__( 'Select rows in the first column, then apply an action here. Email addresses open the subscriber record.', 'product-mailer-campaigns' ) . '</span></div>';
    		            echo '</div>';
    		
    		            echo '<script>(function(){'
    		                . 'var selectAll=document.getElementById("pmcpc-subscribers-select-all");'
    		                . 'if(selectAll){selectAll.addEventListener("change",function(){var boxes=document.querySelectorAll(".pmcpc-subscriber-checkbox");for(var i=0;i<boxes.length;i++){boxes[i].checked=selectAll.checked;}});}'
    		                . 'var shell=document.getElementById("pmcpc-subscribers-table-shell");'
    		                . 'if(!shell){return;}'
    		                . 'var table=shell.querySelector(".pmcpc-subscribers-table");'
    		                . 'var toggles=shell.querySelectorAll(".pmcpc-subscribers-section-toggle");'
    		                . 'var viewButtons=shell.querySelectorAll(".pmcpc-subscribers-viewmode-button");'
    		                . 'if(!table){return;}'
    		                . 'var sectionStorageKey="pmcpc_subscribers_hidden_sections";'
    		                . 'var viewStorageKey="pmcpc_subscribers_table_view_v1";'
    		                . 'var hidden={};'
    		                . 'try{hidden=JSON.parse(window.localStorage.getItem(sectionStorageKey)||"{}")||{};}catch(err){hidden={};}'
    		                . 'var currentView="essential";'
    		                . 'try{currentView=window.localStorage.getItem(viewStorageKey)||"essential";}catch(err){currentView="essential";}'
    		                . 'if(currentView!=="full"){currentView="essential";}'
    		                . 'var sectionMap={profile:[6],engagement:[7,8,9],customer:[10,11,12],tags:[13,14,15,16],system:[17]};'
    		                . 'var groupMap={profile:".pmcpc-group--profile",engagement:".pmcpc-group--engagement",customer:".pmcpc-group--customer",tags:".pmcpc-group--tags",system:".pmcpc-group--system"};'
    		                . 'function setColumns(indices, visible){var rows=table.rows;for(var r=0;r<rows.length;r++){if(rows[r].classList&&rows[r].classList.contains("pmcpc-group-row")){continue;}for(var i=0;i<indices.length;i++){var cell=rows[r].cells[indices[i]-1];if(cell){cell.style.display=visible?"":"none";}}}}'
    		                . 'function setSection(section, visible){var indices=sectionMap[section]||[];setColumns(indices, visible);if(shell&&shell.classList){shell.classList.toggle("pmcpc-hide-"+section,!visible);}var group=table.querySelector(groupMap[section]||"");if(group){group.style.display=visible?"table-cell":"none";}}'
    		                . 'function applySections(){for(var i=0;i<toggles.length;i++){var section=toggles[i].getAttribute("data-section");if(!section){continue;}if(hidden[section]){toggles[i].checked=false;}setSection(section, toggles[i].checked);}}'
    		                . 'function applyView(view){currentView=(view==="full")?"full":"essential";shell.classList.toggle("pmcpc-subscribers-view-essential",currentView==="essential");shell.classList.toggle("pmcpc-subscribers-view-full",currentView==="full");for(var b=0;b<viewButtons.length;b++){var active=viewButtons[b].getAttribute("data-view")===currentView;viewButtons[b].classList.toggle("is-active",active);viewButtons[b].setAttribute("aria-pressed",active?"true":"false");}for(var t=0;t<toggles.length;t++){toggles[t].disabled=(currentView==="essential");}if(currentView==="essential"){setSection("profile",true);setSection("engagement",true);setSection("customer",true);setSection("tags",true);setSection("system",true);}else{applySections();}try{window.localStorage.setItem(viewStorageKey,currentView);}catch(err){}if(window.pmcpcRefreshResizableTables){window.pmcpcRefreshResizableTables();}}'
    		                . 'for(var i=0;i<toggles.length;i++){(function(toggle){var section=toggle.getAttribute("data-section");if(!section){return;}toggle.addEventListener("change",function(){setSection(section, toggle.checked);hidden[section]=!toggle.checked;try{window.localStorage.setItem(sectionStorageKey, JSON.stringify(hidden));}catch(err){}if(window.pmcpcRefreshResizableTables){window.pmcpcRefreshResizableTables();}});})(toggles[i]);}'
    		                . 'for(var v=0;v<viewButtons.length;v++){viewButtons[v].addEventListener("click",function(){applyView(this.getAttribute("data-view"));});}'
    		                . 'applySections();applyView(currentView);'
    		                . 'var bulkAction=document.getElementById("pmcpc_bulk_action");var bulkForm=bulkAction?bulkAction.closest("form"):null;'
    		                . 'if(bulkForm&&bulkAction){bulkForm.addEventListener("submit",function(e){if(!bulkAction.value){return;}var checked=document.querySelectorAll(".pmcpc-subscriber-checkbox:checked").length;if(!checked){alert("' . esc_js( __( 'Please select at least one subscriber first.', 'product-mailer-campaigns' ) ) . '");e.preventDefault();return;}if((bulkAction.value==="delete"||bulkAction.value==="block_domain")&&!confirm("' . esc_js( __( 'Are you sure you want to apply this action to the selected subscribers?', 'product-mailer-campaigns' ) ) . '")){e.preventDefault();}});}'
    		                . '})();</script>';
    		            echo '</form>';
    		        } else {
    		            echo '<p>' . esc_html__( 'No subscribers found.', 'product-mailer-campaigns' ) . '</p>';
    		        }
    		        echo '</div>';
    		        // Secondary subscriber tools.
		        echo '<div class="pmcpc-subscribers-secondary">';
		        echo '<div class="pmcpc-subscribers-section" id="pmcpc-subscriber-import-tools">';
    		        echo '<h2>' . esc_html__( 'Import WordPress users', 'product-mailer-campaigns' ) . '</h2>';
    		        echo '<p class="pmcpc-subscribers-section__intro">' . esc_html__( 'Create or update subscribers from existing WordPress users such as WooCommerce customers or WordPress subscribers.', 'product-mailer-campaigns' ) . '</p>';
    		        echo '<form method="post" style="margin-top:10px;width:100%;">';
    		        wp_nonce_field( 'pmcpc_import_users', 'pmcpc_import_users_nonce' );
    		        echo '<table class="form-table">';
    		        echo '<tr>';
    		        echo '<th scope="row">' . esc_html__( 'User roles to import', 'product-mailer-campaigns' ) . '</th>';
    		        echo '<td>';
    		        echo '<label><input type="checkbox" name="pmcpc_import_roles[]" value="customer" checked> ' . esc_html__( 'WooCommerce customers', 'product-mailer-campaigns' ) . '</label><br>';
    		        echo '<label><input type="checkbox" name="pmcpc_import_roles[]" value="subscriber" checked> ' . esc_html__( 'WordPress subscribers', 'product-mailer-campaigns' ) . '</label>';
    		        echo '<p class="description">' . esc_html__( 'You can adjust roles with the pmcpc_import_user_roles filter if needed.', 'product-mailer-campaigns' ) . '</p>';
    		        echo '</td>';
    		        echo '</tr>';
    		        echo '</table>';
    		        submit_button( __( 'Import users as subscribers', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_import_users', false );
    		        echo '</form>';
    		
    		        echo '</div>';
    		        echo '<div class="pmcpc-subscribers-section" id="pmcpc-subscriber-maintenance-tools">';
    		        echo '<h2>' . esc_html__( 'Maintenance tools', 'product-mailer-campaigns' ) . '</h2>';
    		        echo '<p class="pmcpc-subscribers-section__intro">' . esc_html__( 'Lifecycle tags refresh daily automatically and health tags refresh every six hours. Use these tools when you want to run maintenance immediately after imports, upgrades, or manual data changes.', 'product-mailer-campaigns' ) . '</p>';
		        $pmcpc_lifecycle_next = wp_next_scheduled( 'pmcpc_recalculate_lifecycle_tags' );
		        $pmcpc_health_next    = wp_next_scheduled( 'pmcpc_recalculate_health_tags' );
		        $pmcpc_lifecycle_last = (string) get_option( 'pmcpc_lifecycle_recalculation_last_run', '' );
		        $pmcpc_health_last    = (string) get_option( 'pmcpc_health_recalculation_last_run', '' );
		        echo '<p class="description" style="margin:0 0 14px;">';
		        echo esc_html__( 'Automatic maintenance:', 'product-mailer-campaigns' ) . ' ';
		        echo esc_html( sprintf( __( 'Lifecycle daily%s; Health every six hours%s. Source tag backfill remains manual.', 'product-mailer-campaigns' ), $pmcpc_lifecycle_next ? ' — ' . wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $pmcpc_lifecycle_next ) : '', $pmcpc_health_next ? ' — ' . wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $pmcpc_health_next ) : '' ) );
		        if ( '' !== $pmcpc_lifecycle_last || '' !== $pmcpc_health_last ) {
		            echo '<br>';
		            echo esc_html( sprintf( __( 'Last runs: Lifecycle %s; Health %s.', 'product-mailer-campaigns' ), '' !== $pmcpc_lifecycle_last ? $pmcpc_lifecycle_last : __( 'not yet', 'product-mailer-campaigns' ), '' !== $pmcpc_health_last ? $pmcpc_health_last : __( 'not yet', 'product-mailer-campaigns' ) ) );
		        }
		        echo '</p>';
    		        echo '<div class="pmcpc-admin-tools" style="margin:0 0 15px; background:#fff; border:1px solid #ccd0d4;">';
    		        echo '<strong>' . esc_html__( 'Quick maintenance actions', 'product-mailer-campaigns' ) . '</strong>';
    		        echo '<span class="description" style="margin-left:6px; vertical-align:middle;">' . esc_html__( 'Useful after imports or older upgrades.', 'product-mailer-campaigns' ) . '</span>';
    		        echo '<form method="post" style="display:inline-block; margin-right:8px;">';
    		        wp_nonce_field( 'pmcpc_backfill_source_tags', 'pmcpc_backfill_source_tags_nonce' );
    		        submit_button( __( 'Backfill source tags', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_backfill_source_tags', false );
    		        echo '</form>';
    		        echo '<form method="post" style="display:inline-block; margin-right:8px;">';
    		        wp_nonce_field( 'pmcpc_recalc_lifecycle_tags', 'pmcpc_recalc_lifecycle_tags_nonce' );
    		        submit_button( __( 'Recalculate lifecycle tags', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_recalc_lifecycle_tags', false );
    		        echo '</form>';
    		        echo '<form method="post" style="display:inline-block; margin-right:8px;">';
    		        wp_nonce_field( 'pmcpc_recalc_health_tags', 'pmcpc_recalc_health_tags_nonce' );
    		        submit_button( __( 'Recalculate health tags', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_recalc_health_tags', false );
    		        echo '</form>';
    		        echo '</div>';
    		        echo '<form method="post" style="margin-top:10px;width:100%;">';
    		        wp_nonce_field( 'pmcpc_cleanup_subscribers', 'pmcpc_cleanup_subscribers_nonce' );
    		        echo '<table class="form-table">';
    		        echo '<tr>';
    		        echo '<th scope="row">' . esc_html__( 'Unsubscribed subscribers', 'product-mailer-campaigns' ) . '</th>';
    		        echo '<td>';
    		        echo '<label><input type="checkbox" name="pmcpc_delete_unsubscribed" value="1"> ' . esc_html__( 'Delete all unsubscribed subscribers', 'product-mailer-campaigns' ) . '</label>';
    		        echo '</td>';
    		        echo '</tr>';
    		
    		        echo '<tr>';
    		        echo '<th scope="row">' . esc_html__( 'Inactive subscribers', 'product-mailer-campaigns' ) . '</th>';
    		        echo '<td>';
    		        echo '<label><input type="checkbox" name="pmcpc_delete_inactive" value="1"> ' . esc_html__( 'Delete subscribers with no lifetime engagement and older than X days', 'product-mailer-campaigns' ) . '</label><br>';
    		        echo '<label>' . esc_html__( 'Days since last engagement (or since subscribe if never engaged):', 'product-mailer-campaigns' ) . ' <input type="number" name="pmcpc_inactive_days" value="180" min="1" style="width:80px;"></label>';
    		        echo '<p class="description">' . esc_html__( 'We recommend at least 90–180 days to avoid removing people who simply have not had a chance to engage yet.', 'product-mailer-campaigns' ) . '</p>';
    		        echo '</td>';
    		        echo '</tr>';
    		
    		        echo '</table>';
    		        submit_button( __( 'Run Cleanup', 'product-mailer-campaigns' ), 'delete' );
    		        echo '</form>';
    		        echo '</div>';
    		        echo '</div>';

    			// Wrapper is handled by the admin page renderer (PMCPC_Admin::render_subscribers_page).
    		    }

    		
    		    protected function render_subscriber_timeline( $subscriber_id ) {
    		        global $wpdb;
    		
    			$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
    			// Queue table is pmcpc_email_queue (legacy-safe). Some earlier builds referenced pmcpc_queue.
    			$queue_table       = $wpdb->prefix . 'pmcpc_email_queue';
    			$events_table      = $wpdb->prefix . 'pmcpc_tracking_events';
    			$campaigns_table   = $wpdb->prefix . 'pmcpc_campaigns';
    		
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    			$subscriber = $wpdb->get_row(
    				$wpdb->prepare(
    					'SELECT * FROM %i WHERE id = %d',
    					$subscribers_table,
    					$subscriber_id
    				)
    			);
    		
    		        if ( ! $subscriber ) {
    		            echo '<div class="wrap"><h1>' . esc_html__( 'Subscriber not found', 'product-mailer-campaigns' ) . '</h1></div>';
    		            return;
    		        }
    		
    		        // Load tags, linked user and basic engagement info.
    		        $tags = self::get_tags_for_subscriber( $subscriber_id );
    		
    		        // For the editable tags field on this screen we only want user-facing
    		        // Interest tags (email preferences). All system-managed tags (source/
    		        // origin/lifecycle/health) must be preserved but not exposed here.
    				$buckets      = self::split_tags( is_array( $tags ) ? $tags : array() );

    				// Tag catalogs define which tags are user-facing vs system-managed.
    				// Coerce to arrays so in_array() never receives NULL.
    				$catalogs          = self::get_tag_catalogs();
    				$interest_catalog  = isset( $catalogs['interest'] ) ? (array) $catalogs['interest'] : array();
    				$source_catalog    = isset( $catalogs['source'] ) ? (array) $catalogs['source'] : array();
    				$lifecycle_catalog = isset( $catalogs['lifecycle'] ) ? (array) $catalogs['lifecycle'] : array();
    				$origin_catalog    = isset( $catalogs['origin'] ) ? (array) $catalogs['origin'] : array();
    				$health_catalog    = isset( $catalogs['health'] ) ? (array) $catalogs['health'] : array();
    		        $tags_for_edit = $buckets['interest'];
    		        $tags_str      = $tags_for_edit ? implode( ', ', $tags_for_edit ) : '';
    						$interest_str  = ! empty( $buckets['interest'] ) ? implode( ', ', (array) $buckets['interest'] ) : '';
    		
    		        $user = get_user_by( 'email', $subscriber->email );
    		
    		        // Engagement metrics.
    		        // Prefer lifetime stats stored on the subscriber row so they are not affected by queue cleanup.
    		        $has_lifetime_cols = isset( $subscriber->lifetime_opens ) || isset( $subscriber->last_opened_at );
    		
    		        if ( $has_lifetime_cols ) {
    		            $last_opened = ( ! empty( $subscriber->last_opened_at ) ) ? $subscriber->last_opened_at : __( 'Never', 'product-mailer-campaigns' );
    		            $total_opens = isset( $subscriber->lifetime_opens ) ? (int) $subscriber->lifetime_opens : 0;
    		            $last_clicked = ( ! empty( $subscriber->last_clicked_at ) ) ? $subscriber->last_clicked_at : __( 'Never', 'product-mailer-campaigns' );
    		            $total_clicks  = isset( $subscriber->lifetime_clicks ) ? (int) $subscriber->lifetime_clicks : 0;
    		            $last_engaged  = ( ! empty( $subscriber->last_engaged_at ) ) ? $subscriber->last_engaged_at : __( 'Never', 'product-mailer-campaigns' );
    		        } else {
    		            // Back-compat: derive from event logs if upgrading from older versions.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    				$engagement = $wpdb->get_row(
    					$wpdb->prepare(
    						"SELECT MAX(e.created_at) AS last_opened, COUNT(*) AS total_opens
    						 FROM %i e
    						 INNER JOIN %i q ON q.id = e.queue_id
    						 WHERE q.subscriber_id = %d
    						   AND e.event_type = 'opened'",
    						$events_table,
    						$queue_table,
    						$subscriber_id
    					)
    				);
    		
    		            $last_opened = ( $engagement && $engagement->last_opened ) ? $engagement->last_opened : __( 'Never', 'product-mailer-campaigns' );
    		            $total_opens = ( $engagement && $engagement->total_opens ) ? (int) $engagement->total_opens : 0;
    		            $last_clicked = __( 'Never', 'product-mailer-campaigns' );
    		            $total_clicks = 0;
    		            $last_engaged = $last_opened;
    		        }
    		        $full_name = trim( $subscriber->first_name . ' ' . $subscriber->last_name );
    		        $crm_lifecycle = ! empty( $buckets['lifecycle'] ) ? implode( ', ', (array) $buckets['lifecycle'] ) : __( 'No lifecycle tags', 'product-mailer-campaigns' );
    		        $crm_manual_tag_count = count( (array) $tags_for_edit );

    		        echo '<style>
    		        .pmcpc-subscriber-crm .pmcpc-crm-card{background:#fff;border:1px solid #dcdcde;border-radius:16px;padding:20px;box-shadow:0 10px 24px rgba(15,23,42,.04);margin:0 0 18px;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-card h2,.pmcpc-subscriber-crm .pmcpc-crm-card h3{margin-top:0;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-card__intro{margin:-4px 0 16px;color:#50575e;font-size:13px;line-height:1.55;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-definition-list{display:grid;grid-template-columns:minmax(140px,180px) minmax(0,1fr);gap:12px 18px;margin:0;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-definition-list dt{margin:0;font-weight:600;color:#1d2327;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-definition-list dd{margin:0;color:#2c3338;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-field{display:grid;gap:6px;align-content:start;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-field label{font-weight:600;color:#1d2327;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-field .description{margin:0;color:#646970;line-height:1.5;}
    		        .pmcpc-subscriber-crm .pmcpc-crm-field input[type="text"],.pmcpc-subscriber-crm .pmcpc-crm-field input[type="date"],.pmcpc-subscriber-crm .pmcpc-crm-field select{max-width:none;width:100%;}
    		        .pmcpc-subscriber-crm .pmcpc-subscriber-layout{display:grid;grid-template-columns:minmax(0,1fr);gap:20px;align-items:start;margin-top:12px;}
    		        .pmcpc-subscriber-crm .pmcpc-col-left,.pmcpc-subscriber-crm .pmcpc-col-right{min-width:0;}
    		        .pmcpc-subscriber-crm form.pmcpc-crm-card{height:100%;}
    		        .pmcpc-subscriber-crm .pmcpc-tag-inspector{height:100%;display:flex;flex-direction:column;justify-content:flex-start;}
    		        .pmcpc-subscriber-crm .pmcpc-tag-inspector__grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;align-items:start;}
    		        .pmcpc-subscriber-crm .pmcpc-tag-inspector__section{min-width:0;background:#f8f9fa;border:1px solid #eceef0;border-radius:12px;padding:14px 15px;}
    		        .pmcpc-subscriber-crm .pmcpc-tag-inspector__section h3{margin:0 0 10px;font-size:13px;font-weight:700;color:#1d2327;}
    		        .pmcpc-subscriber-crm .pmcpc-tag-inspector__section ul{margin:0;padding-left:18px;}
    		        .pmcpc-subscriber-crm .pmcpc-tag-inspector__section li{line-height:1.55;}
    		        .pmcpc-subscriber-crm .pmcpc-tag-inspector__section p{margin:0;line-height:1.6;color:#50575e;}
    		        .pmcpc-subscriber-crm .pmcpc-tag-inspector__section .description{margin-top:10px;line-height:1.6;color:#646970;}
    		        .pmcpc-subscriber-crm .pmcpc-subscriber-summary{grid-column:1 / -1;margin:0;}
    		        .pmcpc-subscriber-crm .pmcpc-summary-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px 24px;}
    		        .pmcpc-subscriber-crm .pmcpc-summary-grid .pmcpc-crm-definition-list{grid-template-columns:minmax(120px,170px) minmax(0,1fr);}
    		        .pmcpc-subscriber-crm .pmcpc-subscriber-activity{clear:both;margin-top:24px;}
    		        .pmcpc-subscriber-crm .pmcpc-subscriber-activity table{max-width:960px;}
    		        @media (max-width:1400px){.pmcpc-subscriber-crm .pmcpc-crm-grid{grid-template-columns:repeat(2,minmax(0,1fr));}.pmcpc-subscriber-crm .pmcpc-tag-inspector__grid{grid-template-columns:repeat(2,minmax(0,1fr));}}
    		        @media (max-width:782px){.pmcpc-subscriber-crm .pmcpc-subscriber-layout{grid-template-columns:1fr;}.pmcpc-subscriber-crm .pmcpc-crm-grid,.pmcpc-subscriber-crm .pmcpc-tag-inspector__grid,.pmcpc-subscriber-crm .pmcpc-summary-grid{grid-template-columns:1fr;}.pmcpc-subscriber-crm .pmcpc-subscriber-summary{margin-top:18px;}.pmcpc-subscriber-crm .pmcpc-crm-definition-list,.pmcpc-subscriber-crm .pmcpc-summary-grid .pmcpc-crm-definition-list{grid-template-columns:minmax(110px,150px) minmax(0,1fr);}}
    		        </style>';
    		        echo '<div class="wrap pmcpc-subscriber-crm">';
    		        PMCPC_Admin::render_page_intro(
    		        	__( 'Subscriber profile', 'product-mailer-campaigns' ),
    		        	__( 'Review this subscriber, update their status or manual tags, and keep system-managed tag context and activity close by for reference.', 'product-mailer-campaigns' ),
    		        	array(
    		        		array(
    		        			'label' => $subscriber->email,
    		        			'icon'  => 'dashicons-email',
    		        		),
    		        		array(
    		        			'label' => __( 'Editable profile at the top', 'product-mailer-campaigns' ),
    		        			'icon'  => 'dashicons-admin-users',
    		        		),
    		        		array(
    		        			'label' => __( 'System tags and history below', 'product-mailer-campaigns' ),
    		        			'icon'  => 'dashicons-list-view',
    		        		),
    		        	)
    		        );
    		        PMCPC_Admin::render_stats_strip(
    		        	array(
    		        		array(
    		        			'label' => __( 'Status', 'product-mailer-campaigns' ),
    		        			'value' => ucfirst( (string) $subscriber->status ),
    		        			'meta'  => __( 'Controls whether campaigns can send', 'product-mailer-campaigns' ),
    		        		),
    		        		array(
    		        			'label' => __( 'Manual tags', 'product-mailer-campaigns' ),
    		        			'value' => (string) $crm_manual_tag_count,
    		        			'meta'  => __( 'Only manual tags are editable here', 'product-mailer-campaigns' ),
    		        		),
    		        		array(
    		        			'label' => __( 'Lifecycle', 'product-mailer-campaigns' ),
    		        			'value' => $crm_lifecycle,
    		        			'meta'  => __( 'System-managed customer state', 'product-mailer-campaigns' ),
    		        		),
    		        	)
    		        );

    				// Two-column layout for the details pane.
    				echo '<div class="pmcpc-subscriber-layout">';
    				echo '<div class="pmcpc-col pmcpc-col-left">';
    		
    		        echo '<form method="post" class="pmcpc-crm-card" style="width:100%;">';
    		        wp_nonce_field( 'pmcpc_update_subscriber_tags_' . $subscriber_id, 'pmcpc_update_subscriber_tags_nonce' );
    		        echo '<h2>' . esc_html__( 'Editable profile details', 'product-mailer-campaigns' ) . '</h2>';
    		        echo '<p class="pmcpc-crm-card__intro">' . esc_html__( 'Update status, manual tags, and birthday here. System-managed tags are preserved automatically.', 'product-mailer-campaigns' ) . '</p>';
    		        echo '<div class="pmcpc-crm-grid">';
    		        echo '<div class="pmcpc-crm-field"><label for="pmcpc-status-field">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</label>';
    		        echo '<select id="pmcpc-status-field" name="pmcpc_status">';
    		        foreach ( array( 'active', 'pending', 'unsubscribed' ) as $st ) {
    		            echo '<option value="' . esc_attr( $st ) . '" ' . selected( $subscriber->status, $st, false ) . '>' . esc_html( ucfirst( $st ) ) . '</option>';
    		        }
    		        echo '</select></div>';
    		        echo '<div class="pmcpc-crm-field"><label for="pmcpc-tags-field">' . esc_html__( 'Preference tags', 'product-mailer-campaigns' ) . '</label>';
    		        echo '<input id="pmcpc-tags-field" type="text" name="pmcpc_tags" class="regular-text" value="' . esc_attr( $tags_str ) . '"/>';
    		        echo '<p class="description">' . esc_html__( 'Edit your manual tags here. Separate multiple tags with commas, for example VIP, trade, or showroom.', 'product-mailer-campaigns' ) . '</p>';
    		        echo '</div>';
    		        $birthday_value = self::get_subscriber_birthday( $subscriber_id );
    		        echo '<div class="pmcpc-crm-field"><label for="pmcpc-birthday-field">' . esc_html__( 'Birthday', 'product-mailer-campaigns' ) . '</label>';
    		        echo '<input id="pmcpc-birthday-field" type="date" name="pmcpc_birthday" class="regular-text" value="' . esc_attr( $birthday_value ) . '"/>';
    		        echo '<p class="description">' . esc_html__( 'Optional. Used by the Subscriber birthday automation.', 'product-mailer-campaigns' ) . '</p>';
    		        echo '</div>';
    		        echo '</div>';
    		        echo '<input type="hidden" name="pmcpc_subscriber_id" value="' . esc_attr( $subscriber_id ) . '"/>';
    		        submit_button( __( 'Save subscriber settings', 'product-mailer-campaigns' ), 'primary', 'pmcpc_save_subscriber' );
    		        echo '</form>';
    				echo '</div>';
    				echo '<div class="pmcpc-col pmcpc-col-right">';

    				// Tag Inspector panel.
    		        // We classify tags the same way as the Subscribers list, so the details page reads consistently.
    		        $all_tags = is_array( $tags ) ? $tags : self::get_tags_for_subscriber( $subscriber_id );
    		        if ( ! is_array( $all_tags ) ) {
    		            $all_tags = array();
    		        }
    		        $all_tags = array_values( array_unique( array_filter( array_map( 'trim', $all_tags ) ) ) );

    		        // Tag Inspector panel.

    				$interest_tags   = ! empty( $buckets['interest'] ) ? array_values( array_unique( (array) $buckets['interest'] ) ) : array();
    				$source_tags     = ! empty( $buckets['source'] ) ? array_values( array_unique( (array) $buckets['source'] ) ) : array();
    				$origin_tags     = ! empty( $buckets['origin'] ) ? array_values( array_unique( (array) $buckets['origin'] ) ) : array();
    				$lifecycle_tags  = ! empty( $buckets['lifecycle'] ) ? array_values( array_unique( (array) $buckets['lifecycle'] ) ) : array();
    				$health_tags     = ! empty( $buckets['health'] ) ? array_values( array_unique( (array) $buckets['health'] ) ) : array();
    				$preference_tags = ! empty( $buckets['other'] ) ? array_values( array_unique( (array) $buckets['other'] ) ) : array();
    				sort( $preference_tags );

    				$origin_tags_display = array();
    				foreach ( $origin_tags as $origin_tag ) {
    					$origin_tags_display[] = ( 0 === strpos( $origin_tag, 'origin:' ) ) ? substr( $origin_tag, 7 ) : $origin_tag;
    				}
    				$origin_tags_display = array_values( array_unique( array_filter( $origin_tags_display ) ) );

    				$health_display = array();
    				foreach ( $health_tags as $health_tag ) {
    					$health_display[] = ( 0 === strpos( $health_tag, 'health:' ) ) ? substr( $health_tag, 7 ) : $health_tag;
    				}
    				$health_display = array_values( array_unique( array_filter( $health_display ) ) );

    				$profile_birthday = self::get_subscriber_birthday( $subscriber_id );

    				echo '<div class="pmcpc-tag-inspector pmcpc-crm-card">';
    				echo '<h2>' . esc_html__( 'System tag context', 'product-mailer-campaigns' ) . '</h2>';
    				echo '<div class="pmcpc-tag-inspector__grid">';
    				echo '<div class="pmcpc-tag-inspector__section">';
    				echo '<h3>' . esc_html__( 'Profile data', 'product-mailer-campaigns' ) . '</h3>';
    				echo '<ul>';
    				echo '<li><strong>' . esc_html__( 'Birthday:', 'product-mailer-campaigns' ) . '</strong> ' . ( $profile_birthday ? esc_html( mysql2date( get_option( 'date_format' ), $profile_birthday ) ) : '<em>' . esc_html__( 'None', 'product-mailer-campaigns' ) . '</em>' ) . '</li>';
    				echo '</ul>';
    				echo '</div>';
    				echo '<div class="pmcpc-tag-inspector__section">';
    				echo '<h3>' . esc_html__( 'System tags', 'product-mailer-campaigns' ) . '</h3>';
    				echo '<ul>';
    				echo '<li><strong>' . esc_html__( 'Signup source:', 'product-mailer-campaigns' ) . '</strong> ' . ( $source_tags ? esc_html( implode( ', ', $source_tags ) ) : '<em>' . esc_html__( 'Unknown', 'product-mailer-campaigns' ) . '</em>' ) . '</li>';
    				echo '<li><strong>' . esc_html__( 'Origin:', 'product-mailer-campaigns' ) . '</strong> ' . ( $origin_tags_display ? esc_html( implode( ', ', $origin_tags_display ) ) : '<em>' . esc_html__( 'None', 'product-mailer-campaigns' ) . '</em>' ) . '</li>';
    				echo '<li><strong>' . esc_html__( 'Lifecycle:', 'product-mailer-campaigns' ) . '</strong> ' . ( $lifecycle_tags ? esc_html( implode( ', ', $lifecycle_tags ) ) : '<em>' . esc_html__( 'None', 'product-mailer-campaigns' ) . '</em>' ) . '</li>';
    				echo '<li><strong>' . esc_html__( 'Health:', 'product-mailer-campaigns' ) . '</strong> ' . ( $health_display ? esc_html( implode( ', ', $health_display ) ) : '<em>' . esc_html__( 'None', 'product-mailer-campaigns' ) . '</em>' ) . '</li>';
    				echo '</ul>';
    				echo '</div>';
    				echo '<div class="pmcpc-tag-inspector__section">';
    				echo '<h3>' . esc_html__( 'Preference tags', 'product-mailer-campaigns' ) . '</h3>';
    				if ( $preference_tags ) {
    					echo '<p>' . esc_html( implode( ', ', $preference_tags ) ) . '</p>';
    				} else {
    					echo '<p><em>' . esc_html__( 'None', 'product-mailer-campaigns' ) . '</em></p>';
    				}
    				echo '<p class="description">' . esc_html__( 'Preference tags are the only tags you edit manually. System tags are maintained automatically for filtering and reporting.', 'product-mailer-campaigns' ) . '</p>';
    				echo '</div>';
    				echo '</div>';
    				echo '</div>';
    				echo '</div>';
    		        
    		        echo '<div class="pmcpc-subscriber-summary pmcpc-crm-card">';
    		        echo '<h2>' . esc_html__( 'Subscriber overview', 'product-mailer-campaigns' ) . '</h2>';
    		        echo '<p class="pmcpc-crm-card__intro">' . esc_html__( 'Use this summary to confirm the subscriber before making changes below.', 'product-mailer-campaigns' ) . '</p>';
    		        echo '<div class="pmcpc-summary-grid">';
    		        echo '<dl class="pmcpc-crm-definition-list">';
    		        echo '<dt>' . esc_html__( 'Email', 'product-mailer-campaigns' ) . '</dt><dd>' . esc_html( $subscriber->email ) . '</dd>';
    		        if ( $full_name ) {
    		            echo '<dt>' . esc_html__( 'Name', 'product-mailer-campaigns' ) . '</dt><dd>' . esc_html( $full_name ) . '</dd>';
    		        }
    		        echo '<dt>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</dt><dd>' . esc_html( ucfirst( $subscriber->status ) ) . '</dd>';
    						echo '<dt>' . esc_html__( 'Email preferences', 'product-mailer-campaigns' ) . '</dt><dd>' . ( $interest_str ? esc_html( $interest_str ) : esc_html__( '(none)', 'product-mailer-campaigns' ) ) . '</dd>';
    						echo '<dt>' . esc_html__( 'Preference tags', 'product-mailer-campaigns' ) . '</dt><dd>' . ( $tags_str ? esc_html( $tags_str ) : esc_html__( '(none)', 'product-mailer-campaigns' ) ) . '</dd>';
    		        echo '<dt>' . esc_html__( 'Date added', 'product-mailer-campaigns' ) . '</dt><dd>' . esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $subscriber->created_at ) ) . '</dd>';
    		        echo '</dl>';
    		        echo '<dl class="pmcpc-crm-definition-list">';
    		        echo '<dt>' . esc_html__( 'Last opened', 'product-mailer-campaigns' ) . '</dt><dd>' . esc_html( $last_opened ) . ' - ' . sprintf( esc_html__( 'Total opens: %s', 'product-mailer-campaigns' ), esc_html( $total_opens ) ) . '</dd>';
    		        echo '<dt>' . esc_html__( 'Last clicked', 'product-mailer-campaigns' ) . '</dt><dd>' . esc_html( $last_clicked ) . ' - ' . sprintf( esc_html__( 'Total clicks: %s', 'product-mailer-campaigns' ), esc_html( $total_clicks ) ) . '</dd>';
    		        echo '<dt>' . esc_html__( 'Last engaged', 'product-mailer-campaigns' ) . '</dt><dd>' . esc_html( $last_engaged ) . '</dd>';
    		        if ( $user ) {
    		            $edit_link = get_edit_user_link( $user->ID );
    		            echo '<dt>' . esc_html__( 'WordPress user', 'product-mailer-campaigns' ) . '</dt><dd>';
    		            if ( $edit_link ) {
    		                echo '<a href= . esc_url( $edit_link ) . >' . esc_html( $user->user_login ) . '</a>';
    		            } else {
    		                echo esc_html( $user->user_login );
    		            }
    		            echo '</dd>';
    		        } else {
    		            echo '<dt>' . esc_html__( 'WordPress user', 'product-mailer-campaigns' ) . '</dt><dd>' . esc_html__( 'None linked', 'product-mailer-campaigns' ) . '</dd>';
    		        }
    		        echo '</dl>';
    		        echo '</div>';
    		        echo '</div>';
    		        echo '</div>';
    						echo '</div>'; // .pmcpc-subscriber-layout

    						echo '<div class="pmcpc-subscriber-activity pmcpc-crm-card">';

    						// Email activity.
    $email_log_table       = $wpdb->prefix . 'pmcpc_email_log';
    $tracking_events_table = $wpdb->prefix . 'pmcpc_tracking_events';
    $legacy_events_table   = $wpdb->prefix . 'pmcpc_email_events';

    // Prefer the newer tracking table if present; otherwise fall back to the legacy events table.
    $events_table_use = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tracking_events_table ) );
    if ( ! $events_table_use ) {
    	$events_table_use = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $legacy_events_table ) );
    }
    if ( ! $events_table_use ) {
    	$events_table_use = $tracking_events_table; // Safe default; queries below will just return empty.
    }

    // 1) Sent / attempted emails (from the email log).
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    $sent_rows = $wpdb->get_results(
    	$wpdb->prepare(
    		"SELECT l.*, c.name AS campaign_name
    		 FROM %i l
    		 LEFT JOIN %i c ON c.id = l.campaign_id
    		 WHERE ( l.subscriber_id = %d OR l.to_email = %s )
    		 ORDER BY COALESCE(l.sent_at, l.created_at) DESC
    		 LIMIT 200",
    		$email_log_table,
    		$campaigns_table,
    		$subscriber_id,
    		$subscriber->email
    	)
    );

    // 2) Engagement events (opens/clicks) if tracking is enabled.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    $events = $wpdb->get_results(
    	$wpdb->prepare(
    		"SELECT e.event_type, e.created_at, q.subject, c.name AS campaign_name
    		 FROM %i e
    		 INNER JOIN %i q ON q.id = e.queue_id
    		 LEFT JOIN %i c ON c.id = q.campaign_id
    		 WHERE q.subscriber_id = %d
    		 ORDER BY e.created_at DESC
    		 LIMIT 200",
    		$events_table_use,
    		$queue_table,
    		$campaigns_table,
    		$subscriber_id
    	)
    );

    echo '<h2>' . esc_html__( 'Email Activity', 'product-mailer-campaigns' ) . '</h2>';
    echo '<p class="pmcpc-crm-card__intro">' . esc_html__( 'Use this history to confirm what has been sent, opened, and clicked before making follow-up decisions.', 'product-mailer-campaigns' ) . '</p>';
    PMCPC_Admin::render_stats_strip(
    	array(
    		array(
    			'label' => __( 'Emails sent', 'product-mailer-campaigns' ),
    			'value' => number_format_i18n( count( $sent_rows ) ),
    			'help'  => __( 'Recent delivery records', 'product-mailer-campaigns' ),
    		),
    		array(
    			'label' => __( 'Tracked events', 'product-mailer-campaigns' ),
    			'value' => number_format_i18n( count( $events ) ),
    			'help'  => __( 'Opens and clicks logged', 'product-mailer-campaigns' ),
    		),
    		array(
    			'label' => __( 'Lifetime opens', 'product-mailer-campaigns' ),
    			'value' => number_format_i18n( $total_opens ),
    			'help'  => __( 'Subscriber engagement total', 'product-mailer-campaigns' ),
    		),
    		array(
    			'label' => __( 'Lifetime clicks', 'product-mailer-campaigns' ),
    			'value' => number_format_i18n( $total_clicks ),
    			'help'  => __( 'Tracked click total', 'product-mailer-campaigns' ),
    		),
    	)
    );

    if ( $sent_rows ) {
    	echo '<h3 style="margin:18px 0 10px;">' . esc_html__( 'Sent emails', 'product-mailer-campaigns' ) . '</h3>';
    	echo '<div class="pmcpc-table-wrap pmcpc-crm-activity-table"><div class="pmcpc-table-wrap__scroll">';
    	echo '<table class="widefat striped pmcpc-wide-table">';
    	echo '<thead><tr>';
    	echo '<th class="pmcpc-col-compare">' . esc_html__( 'Sent at', 'product-mailer-campaigns' ) . '</th>';
    	echo '<th class="pmcpc-col-compare">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
    	echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
    	echo '<th class="pmcpc-col-meta">' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</th>';
    	echo '</tr></thead><tbody>';
    	foreach ( $sent_rows as $row ) {
    		$sent_at = $row->sent_at ? $row->sent_at : ( $row->created_at ? $row->created_at : '' );
    		echo '<tr>';
    		echo '<td>' . esc_html( $sent_at ? $sent_at : '—' ) . '</td>';
    		echo '<td>' . esc_html( $row->status ? $row->status : '—' ) . '</td>';
    		echo '<td>' . esc_html( $row->campaign_name ? $row->campaign_name : '—' ) . '</td>';
    		echo '<td>' . esc_html( $row->subject ? $row->subject : '—' ) . '</td>';
    		echo '</tr>';
    	}
    	echo '</tbody></table></div></div>';
    } else {
    	echo '<div class="pmcpc-card" style="margin-top:18px;"><p style="margin:0;">' . esc_html__( 'No sent email records found for this subscriber yet.', 'product-mailer-campaigns' ) . '</p></div>';
    }

    if ( $events ) {
    	echo '<h3 style="margin:18px 0 10px;">' . esc_html__( 'Opens & clicks', 'product-mailer-campaigns' ) . '</h3>';
    	echo '<div class="pmcpc-table-wrap pmcpc-crm-activity-table"><div class="pmcpc-table-wrap__scroll">';
    	echo '<table class="widefat striped pmcpc-wide-table">';
    	echo '<thead><tr>';
    	echo '<th class="pmcpc-col-compare">' . esc_html__( 'Event time', 'product-mailer-campaigns' ) . '</th>';
    	echo '<th class="pmcpc-col-compare">' . esc_html__( 'Event', 'product-mailer-campaigns' ) . '</th>';
    	echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
    	echo '<th class="pmcpc-col-meta">' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</th>';
    	echo '</tr></thead><tbody>';
    	foreach ( $events as $event ) {
    		echo '<tr>';
    		echo '<td>' . esc_html( $event->created_at ) . '</td>';
    		echo '<td>' . esc_html( $event->event_type ) . '</td>';
    		echo '<td>' . esc_html( $event->campaign_name ? $event->campaign_name : '—' ) . '</td>';
    		echo '<td>' . esc_html( $event->subject ? $event->subject : '—' ) . '</td>';
    		echo '</tr>';
    	}
    	echo '</tbody></table></div></div>';
    }
    echo '<p class="pmcpc-crm-backlink"><a href="' . esc_url( admin_url( 'admin.php?page=pmcpc_subscribers' ) ) . '">&larr; ' . esc_html__( 'Back to subscribers', 'product-mailer-campaigns' ) . '</a></p>';
    echo '</div>';
    echo '<div style="clear:both;"></div>';
    		        echo '</div>';
    		    }

}
