<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Subscriber_Manager_Maintenance_Methods {
    		public static function update_status( $subscriber_id, $status ) {
    		        global $wpdb;
    		        $table = $wpdb->prefix . 'pmcpc_subscribers';
    		        $subscriber_id = absint( $subscriber_id );
    		        if ( ! $subscriber_id ) {
    		            return;
    		        }
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    		        $wpdb->update(
    		            $table,
    		            array(
    		                'status'     => $status,
    		                'updated_at' => current_time( 'mysql' ),
    		            ),
    		            array( 'id' => $subscriber_id ),
    		            array( '%s', '%s' ),
    		            array( '%d' )
    		        );
    		
    		        /**
    		         * Fired when a PMCPC subscriber status is updated.
    		         *
    		         * @param int    $subscriber_id Subscriber ID.
    		         * @param string $status        New status.
    		         */
    		        do_action( 'pmcpc_subscriber_status_updated', $subscriber_id, $status );
    		    }

    		
    		
    		
    		    /**
    		     * Handle bulk subscriber cleanup actions.
    		     *
    		     * - Delete all unsubscribed subscribers.
    		     * - Delete inactive subscribers older than X days with no opens.
    		     */
    		
    		    /**
    		     * Delete one or more subscribers and their related data.
    		     *
    		     * @param int[] $subscriber_ids Subscriber IDs to delete.
    		     */
    		
    		    /**
    		     * Bulk add a tag to the given subscribers.
    		     *
    		     * @param int[]  $subscriber_ids Subscriber IDs.
    		     * @param string $tag            Tag to add.
    		     */
    		    protected function bulk_add_tag_to_subscribers( $subscriber_ids, $tag ) {
    		        if ( ! current_user_can( 'manage_options' ) ) {
    		            return;
    		        }
    		
    		        $subscriber_ids = array_filter( array_map( 'absint', (array) $subscriber_ids ) );
    		        $tag            = sanitize_text_field( (string) $tag );
    		
    		        if ( empty( $subscriber_ids ) || '' === $tag ) {
    		            return;
    		        }
    		
    		        $updated = 0;
    		        foreach ( $subscriber_ids as $subscriber_id ) {
    		            self::add_tags_for_subscriber( $subscriber_id, $tag );
    		            $updated++;
    		        }
    		
    		        if ( $updated > 0 ) {
    		            $message = sprintf(
    		                /* translators: 1: tag name, 2: number of subscribers updated. */
    		                _n(
    		                    'Added tag "%1$s" to %2$d subscriber.',
    		                    'Added tag "%1$s" to %2$d subscribers.',
    		                    $updated,
    		                    'product-mailer-campaigns'
    		                ),
    		                $tag,
    		                $updated
    		            );
    		
    		            add_settings_error(
    		                'pmcpc_subscribers',
    		                'pmcpc_bulk_add_tag_done',
    		                $message,
    		                'updated'
    		            );
    		        }
    		    }

    		
    		    /**
    		     * Bulk remove a tag from the given subscribers.
    		     *
    		     * @param int[]  $subscriber_ids Subscriber IDs.
    		     * @param string $tag            Tag to remove.
    		     */
    		    protected function bulk_remove_tag_from_subscribers( $subscriber_ids, $tag ) {
    		        if ( ! current_user_can( 'manage_options' ) ) {
    		            return;
    		        }
    		
    		        $subscriber_ids = array_filter( array_map( 'absint', (array) $subscriber_ids ) );
    		        $tag            = sanitize_text_field( (string) $tag );
    		
    		        if ( empty( $subscriber_ids ) || '' === $tag ) {
    		            return;
    		        }
    		
    		        $updated = 0;
    		        foreach ( $subscriber_ids as $subscriber_id ) {
    		            $existing = self::get_tags_for_subscriber( $subscriber_id );
    		            if ( ! is_array( $existing ) || empty( $existing ) ) {
    		                continue;
    		            }
    		
    		            $new_tags = array();
    		            foreach ( $existing as $existing_tag ) {
    		                if ( $existing_tag === $tag ) {
    		                    continue;
    		                }
    		                $new_tags[] = $existing_tag;
    		            }
    		
    		            // If nothing changed, skip.
    		            $sorted_existing = $existing;
    		            sort( $sorted_existing );
    		            $sorted_new = $new_tags;
    		            sort( $sorted_new );
    		            if ( $sorted_existing === $sorted_new ) {
    		                continue;
    		            }
    		
    		            self::set_tags_for_subscriber( $subscriber_id, $new_tags );
    		            $updated++;
    		        }
    		
    		        if ( $updated > 0 ) {
    		            $message = sprintf(
    		                /* translators: 1: tag name, 2: number of subscribers updated. */
    		                _n(
    		                    'Removed tag "%1$s" from %2$d subscriber.',
    		                    'Removed tag "%1$s" from %2$d subscribers.',
    		                    $updated,
    		                    'product-mailer-campaigns'
    		                ),
    		                $tag,
    		                $updated
    		            );
    		
    		            add_settings_error(
    		                'pmcpc_subscribers',
    		                'pmcpc_bulk_remove_tag_done',
    		                $message,
    		                'updated'
    		            );
    		        }
    		    }

    		
    		protected function bulk_delete_subscribers( $subscriber_ids ) {
    		        if ( ! current_user_can( 'manage_options' ) ) {
    		            return;
    		        }
    		
    		        $subscriber_ids = array_filter( array_map( 'absint', (array) $subscriber_ids ) );
    		        if ( empty( $subscriber_ids ) ) {
    		            return;
    		        }
    		
    		        global $wpdb;
    		
    		$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
    		$tags_table        = $wpdb->prefix . 'pmcpc_subscriber_tags';
    		        $queue_table       = $wpdb->prefix . 'pmcpc_email_queue';
    		        $events_table      = $wpdb->prefix . 'pmcpc_email_events';
    		
    		        $placeholders = implode( ',', array_fill( 0, count( $subscriber_ids ), '%d' ) );
    		
    		        // Find queue rows for these subscribers.
    		        // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    				$queue_params = array_merge( array( $queue_table ), $subscriber_ids );

    				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    				$queue_ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM %i WHERE subscriber_id IN ($placeholders)", ...$queue_params ) );
    		
    		        if ( $queue_ids ) {
    		            $queue_placeholders = implode( ',', array_fill( 0, count( $queue_ids ), '%d' ) );
    		
    		            // Delete events.
    		            // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    					$event_params = array_merge( array( $events_table ), $queue_ids );

    					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    					$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE queue_id IN ($queue_placeholders)", ...$event_params ) );
    		
    		            // Delete queue rows.
    		            // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    					$queue_del_params = array_merge( array( $queue_table ), $queue_ids );

    					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    					$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE id IN ($queue_placeholders)", ...$queue_del_params ) );
    		        }
    		
    		        // Delete tags.
    		        // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    			$tag_del_params = array_merge( array( $tags_table ), $subscriber_ids );

    			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    			$wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE subscriber_id IN ($placeholders)", ...$tag_del_params ) );
    		
    		        // Finally delete subscribers.
    		        // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    			        $deleted = (int) $wpdb->query(
    			            $wpdb->prepare(
    			                "DELETE FROM %i WHERE id IN ($placeholders)",
    			                array_merge( array( $subscribers_table ), $subscriber_ids )
    			            )
    			        );
    		
    		        if ( $deleted > 0 ) {
    		            /* translators: %d is the number of subscribers deleted. */
    		            $message = sprintf(
    		                /* translators: 1: tag name, 2: number of subscribers updated. */
    		                _n(
    		                    'Deleted %d subscriber.',
    		                    'Deleted %d subscribers.',
    		                    $deleted,
    		                    'product-mailer-campaigns'
    		                ),
    		                $deleted
    		            );
    		
    		            add_settings_error(
    		                'pmcpc_subscribers',
    		                'pmcpc_bulk_delete_done',
    		                $message,
    		                'updated'
    		            );
    		        }
    		    }

    		
    		    protected function handle_cleanup_request() {
    		        if ( ! current_user_can( 'manage_options' ) ) {
    		            return;
    		        }
    		
    				$cleanup_nonce = isset( $_POST['pmcpc_cleanup_subscribers_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_cleanup_subscribers_nonce'] ) ) : '';
    				if ( empty( $cleanup_nonce ) || ! wp_verify_nonce( $cleanup_nonce, 'pmcpc_cleanup_subscribers' ) ) {
    		            return;
    		        }
    		
    		        global $wpdb;
    		
    		$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
    		        $queue_table       = $wpdb->prefix . 'pmcpc_email_queue';
    		        $events_table      = $wpdb->prefix . 'pmcpc_email_events';
    		
    		        $delete_unsubscribed = isset( $_POST['pmcpc_delete_unsubscribed'] ) && '1' === sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_delete_unsubscribed'] ) );
    		        $delete_inactive     = ! empty( $_POST['pmcpc_delete_inactive'] );
    		        $inactive_days       = isset( $_POST['pmcpc_inactive_days'] ) ? absint( $_POST['pmcpc_inactive_days'] ) : 0;
    		
    		        if ( ! $delete_unsubscribed && ! $delete_inactive ) {
    		            add_settings_error(
    		                'pmcpc_subscribers',
    		                'pmcpc_cleanup_no_action',
    		                __( 'Please select at least one cleanup option.', 'product-mailer-campaigns' ),
    		                'error'
    		            );
    		            return;
    		        }
    		
    		        if ( $inactive_days <= 0 ) {
    		            $inactive_days = 180;
    		        }
    		
    		        $deleted = 0;
    		
    		        // Delete all unsubscribed subscribers.
    				if ( $delete_unsubscribed ) {
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    					$deleted += (int) $wpdb->query(
    						$wpdb->prepare( 'DELETE FROM %i WHERE status = %s', $subscribers_table, 'unsubscribed' )
    					);
    				}
    		
    		        // Delete inactive subscribers based on lifetime engagement (not affected by queue cleanup).
    		        if ( $delete_inactive && $inactive_days > 0 ) {
    		            // Safe default: only remove subscribers who have *no lifetime engagement* AND are older than X days.
    		            // We treat any engagement (open/view/click) as activity via last_engaged_at.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    					$inactive_ids = $wpdb->get_col(
    						$wpdb->prepare(
    							"SELECT s.id
    							 FROM %i s
    		                     WHERE s.created_at < DATE_SUB( UTC_TIMESTAMP(), INTERVAL %d DAY )
    		                       AND s.status IN ('active','pending')
    		                       AND (
    		                            ( (s.last_engaged_at IS NULL OR s.last_engaged_at = '0000-00-00 00:00:00')
    		                              AND COALESCE(s.lifetime_opens, 0) = 0
    		                              AND COALESCE(s.lifetime_clicks, 0) = 0
    		                            )
    		                            OR ( s.last_engaged_at < DATE_SUB( UTC_TIMESTAMP(), INTERVAL %d DAY )
    		                                 AND COALESCE(s.lifetime_clicks, 0) = 0
    		                            )
    									   )",
    							$subscribers_table,
    							$inactive_days,
    							$inactive_days
    						)
    					);
    		
    		            if ( ! empty( $inactive_ids ) ) {
    		                $placeholders = implode( ',', array_fill( 0, count( $inactive_ids ), '%d' ) );
    		
    						// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    						$inactive_params = array_merge( array( $subscribers_table ), $inactive_ids );

    						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
    						$deleted += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM %i WHERE id IN ($placeholders)", ...$inactive_params ) );
    		            }
    		        }
    		
    		        if ( $deleted > 0 ) {
    		            /* translators: %d is the number of subscribers deleted. */
    		            $message = sprintf(
    		                /* translators: 1: tag name, 2: number of subscribers updated. */
    		                _n(
    		                    'Cleanup complete. %d subscriber removed.',
    		                    'Cleanup complete. %d subscribers removed.',
    		                    $deleted,
    		                    'product-mailer-campaigns'
    		                ),
    		                $deleted
    		            );
    		        } else {
    		            $message = __( 'Cleanup complete. No subscribers matched the selected criteria.', 'product-mailer-campaigns' );
    		        }
    		
    		        add_settings_error(
    		            'pmcpc_subscribers',
    		            'pmcpc_cleanup_done',
    		            $message,
    		            'updated'
    		        );
    		    }


            /**
             * Schedule recurring subscriber tag maintenance.
             *
             * Lifecycle tags refresh daily. Health tags refresh every six hours.
             * Source tag backfills stay manual because they are migration-style cleanup.
             *
             * @return void
             */
            public static function ensure_scheduled_subscriber_maintenance() {
                if ( ! wp_next_scheduled( 'pmcpc_recalculate_lifecycle_tags' ) ) {
                    wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'pmcpc_recalculate_lifecycle_tags' );
                }

                if ( ! wp_next_scheduled( 'pmcpc_recalculate_health_tags' ) ) {
                    wp_schedule_event( time() + ( 2 * HOUR_IN_SECONDS ), 'pmcpc_every_six_hours', 'pmcpc_recalculate_health_tags' );
                }
            }

            /**
             * Clear scheduled subscriber tag maintenance events.
             *
             * @return void
             */
            public static function clear_scheduled_subscriber_maintenance() {
                wp_clear_scheduled_hook( 'pmcpc_recalculate_lifecycle_tags' );
                wp_clear_scheduled_hook( 'pmcpc_recalculate_health_tags' );
            }

            /**
             * Run the scheduled lifecycle recalculation.
             *
             * @return int Number of subscribers processed.
             */
            public static function run_scheduled_lifecycle_recalculation() {
                if ( get_transient( 'pmcpc_lifecycle_recalculation_lock' ) ) {
                    return 0;
                }

                set_transient( 'pmcpc_lifecycle_recalculation_lock', 1, 30 * MINUTE_IN_SECONDS );
                $processed = 0;

                try {
                    $manager   = new self();
                    $processed = (int) $manager->recalculate_lifecycle_tags_for_all( false, true );
                } catch ( Throwable $e ) {
                    update_option( 'pmcpc_lifecycle_recalculation_last_error', $e->getMessage(), false );
                }

                delete_transient( 'pmcpc_lifecycle_recalculation_lock' );
                return $processed;
            }

            /**
             * Run the scheduled health recalculation.
             *
             * @return int Number of subscribers processed.
             */
            public static function run_scheduled_health_recalculation() {
                if ( get_transient( 'pmcpc_health_recalculation_lock' ) ) {
                    return 0;
                }

                set_transient( 'pmcpc_health_recalculation_lock', 1, 30 * MINUTE_IN_SECONDS );
                $processed = 0;

                try {
                    $manager   = new self();
                    $processed = (int) $manager->recalculate_health_tags_for_all( true );
                } catch ( Throwable $e ) {
                    update_option( 'pmcpc_health_recalculation_last_error', $e->getMessage(), false );
                }

                delete_transient( 'pmcpc_health_recalculation_lock' );
                return $processed;
            }

}
