<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/subscribers/traits/trait-pmcpc-subscriber-manager-methods.php';

/**
 * Instance-first subscribers controller (preferred for DI).
 * Legacy code can continue using PMCPC_Subscriber_Manager.
 */
class PMCPC_Subscribers_Controller {

	/**
	 * Cache for Woo stats during a request.
	 * @var array<string,array>
	 */
	protected static $wc_stats_cache = array();

	// --- Back-compat helpers for spam evaluation (controller refactor) ---

	public static function clean_name( $value ) {
			$value = wp_strip_all_tags( (string) $value );
			$value = preg_replace( "/[^\\p{L}\\p{M} '\\-]/u", '', $value );
			$value = trim( preg_replace( '/\s+/', ' ', (string) $value ) );
			return (string) $value;
		}


	public static function get_default_spam_settings() {
			return array(
				'spam_protection_enabled' => 'yes',
				// Spam handling mode (Inbox noise control).
				'spam_handling_mode'    => 'review_all',
				'spam_honeypot_enabled'   => 'yes',
				// Signed timing token + minimum submit time (contact/selling forms).
				'spam_form_timing_enabled' => 'yes',
				'spam_min_submit_seconds'  => 4,
				'spam_rate_limit_enabled' => 'yes',
				'spam_rate_limit_max'     => 5,
				'spam_rate_limit_window'  => 600, // seconds.
				'spam_suspicious_tlds_enabled' => 'yes',
				'spam_suspicious_tlds'    => "ru\nxyz\ntop\nclub\nsite\nclick\nlink\nfit\nrest\nmonster\nwork\nbiz",
				// Auto-add domains to the blocked domains list after repeated blocked attempts.
				'spam_auto_block_domains_enabled'  => 'yes',
				'spam_auto_block_domains_threshold' => 3,
				'spam_auto_block_domains_window'    => 86400, // seconds.
				'spam_name_policy'        => 'blank', // blank|block
				'spam_log_enabled'         => 'yes',
	
				// Email sanity checks.
				// When enabled we treat domains with no MX or A records as blocked.
				'spam_email_dns_enabled'   => 'yes',
	
				// Message/content scoring (primarily for contact/selling forms).
				'spam_message_scoring_enabled' => 'yes',
				'spam_message_max_links'        => 1,
				'spam_message_keywords_enabled' => 'yes',
				'spam_message_keywords'         => "seo\nbacklink\nbacklinks\nlink building\nguest post\nwrite for us\n\ncasino\npoker\nbetting\nloan\ncrypto\ntelegram\nwhatsapp\n\nказино\nонлайн казино\nслоты\nбукмекер\nставки\n\nxrumer\nxrum\n\n\"best service\"\n\"promote your site\"\n\"website promotion\"",
				'spam_message_non_ascii_threshold' => 0.30,
				'spam_message_suspicious_markup_enabled' => 'yes',
				// Scores: >= hold => held, >= block => blocked.
				'spam_message_hold_score'  => 3,
				'spam_message_block_score' => 6,
			);
		}


	public static function get_spam_setting( $key, $fallback = '' ) {
			$defaults = self::get_default_spam_settings();
			$default  = array_key_exists( $key, $defaults ) ? $defaults[ $key ] : $fallback;
			if ( class_exists( 'PMCPC_Settings' ) ) {
				return PMCPC_Settings::get( $key, $default );
			}
			$all = get_option( 'pmcpc_settings', array() );
			return isset( $all[ $key ] ) ? $all[ $key ] : $default;
		}


	public static function peek_rate_limited() {
			if ( 'yes' !== self::get_spam_setting( 'spam_rate_limit_enabled', 'yes' ) ) {
				return false;
			}
			$ip = '';
			if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.
				$ip = sanitize_text_field( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
			}
			if ( ! $ip ) {
				return false;
			}
			$key    = 'pmcpc_rl_' . substr( hash( 'sha256', $ip ), 0, 20 );
			$max    = (int) self::get_spam_setting( 'spam_rate_limit_max', 5 );
			$count  = (int) get_transient( $key );
			return ( $count >= $max );
		}


	public static function record_spam_block( $email, $reason, $context = 'subscribe' ) {
			$email  = sanitize_email( (string) $email );
			$reason = sanitize_key( (string) $reason );
			$context = sanitize_key( (string) $context );
			$domain = '';
			if ( $email && strpos( $email, '@' ) !== false ) {
				$parts  = explode( '@', $email );
				$domain = strtolower( trim( end( $parts ) ) );
			}
	
			// Update aggregated stats.
			$stats = get_option( 'pmcpc_spam_stats', array() );
			if ( ! is_array( $stats ) ) {
				$stats = array();
			}
			$stats['total'] = isset( $stats['total'] ) ? (int) $stats['total'] + 1 : 1;
			$today_key = gmdate( 'Ymd' );
			if ( ! isset( $stats['daily'] ) || ! is_array( $stats['daily'] ) ) {
				$stats['daily'] = array();
			}
			$stats['daily'][ $today_key ] = isset( $stats['daily'][ $today_key ] ) ? (int) $stats['daily'][ $today_key ] + 1 : 1;
			if ( ! isset( $stats['reasons'] ) || ! is_array( $stats['reasons'] ) ) {
				$stats['reasons'] = array();
			}
			$stats['reasons'][ $reason ] = isset( $stats['reasons'][ $reason ] ) ? (int) $stats['reasons'][ $reason ] + 1 : 1;
	
			// Track domains for reporting.
			if ( $domain ) {
				if ( ! isset( $stats['domains'] ) || ! is_array( $stats['domains'] ) ) {
					$stats['domains'] = array();
				}
				$stats['domains'][ $domain ] = isset( $stats['domains'][ $domain ] ) ? (int) $stats['domains'][ $domain ] + 1 : 1;
			}
			update_option( 'pmcpc_spam_stats', $stats, false );
	
			// Ensure spam blocks are visible in the admin review UI.
			// If record_spam_submission() was used, it already inserted a row.
			if ( ! self::$pmcpc_in_record_submission ) {
				global $wpdb;
				// Table names are plugin-controlled (not user input). esc_sql() is used to satisfy static analyzers.
				$table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
				if ( $exists === $table ) {
					$ip = '';
					if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
						// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
						$ip = sanitize_text_field( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
					}
					$ip_hash = $ip ? hash( 'sha256', $ip ) : null;
	
					$store_status = self::should_auto_discard_spam_entry( $reason, $context ) ? 'discarded' : 'blocked';
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
					$wpdb->insert(
						$table,
						array(
							'email'      => $email ? $email : null,
							'domain'     => $domain ? $domain : null,
							'ip_hash'    => $ip_hash,
							'reason'     => $reason,
							'context'    => $context,
							'status'     => $store_status,
							'subject'    => null,
							'message'    => null,
							'created_at' => current_time( 'mysql' ),
						),
						array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
					);
				}
			}
	
			// Optionally auto-add repeat offender domains to the blocked domains list.
			if ( $domain && 'yes' === self::get_spam_setting( 'spam_auto_block_domains_enabled', 'yes' ) && ! self::is_domain_in_blocked_list( $domain ) ) {
				// Never auto-block common shared email providers. Blocking these would
				// prevent legitimate users from subscribing.
				$protected_domains = array(
					'gmail.com',
					'googlemail.com',
					'yahoo.com',
					'hotmail.com',
					'outlook.com',
					'live.com',
					'icloud.com',
					'gmx.com',
				);
	
				// Site-configured protected domains (one per line in settings).
				$extra_protected = self::get_spam_setting( 'spam_auto_block_protected_domains', '' );
				if ( is_string( $extra_protected ) && '' !== trim( $extra_protected ) ) {
					$lines = preg_split( '/\r\n|\r|\n/', $extra_protected );
					if ( is_array( $lines ) ) {
						foreach ( $lines as $line ) {
							$d = strtolower( trim( (string) $line ) );
							$d = ltrim( $d, "@ \t" );
							if ( '' === $d ) {
								continue;
							}
							// Basic allowlist validation (letters, numbers, dots, hyphens).
							if ( ! preg_match( '/^[a-z0-9][a-z0-9\-\.]*\.[a-z0-9\-\.]+$/', $d ) ) {
								continue;
							}
							$protected_domains[] = $d;
						}
					}
				}
	
				$protected_domains = array_values( array_unique( array_filter( $protected_domains ) ) );
	
				/**
				 * Domains that should never be auto-blocked.
				 *
				 * Site owners can add/remove domains via a filter.
				 *
				 * @param array  $protected_domains Default protected domains.
				 * @param string $domain            Domain being evaluated.
				 * @param string $reason            Spam reason.
				 * @param string $context           Context of the submission.
				 */
				$protected_domains = apply_filters( 'pmcpc_auto_block_protected_domains', $protected_domains, $domain, $reason, $context );
	
				$skip_auto_block = false;
				foreach ( (array) $protected_domains as $protected ) {
					$protected = strtolower( trim( (string) $protected ) );
					if ( '' === $protected ) {
						continue;
					}
					$pattern = '/(^|\.)' . preg_quote( $protected, '/' ) . '$/';
					if ( preg_match( $pattern, $domain ) ) {
						$skip_auto_block = true;
						break;
					}
				}
	
				/**
				 * Allow overriding whether a domain should be auto-blocked.
				 *
				 * Return true to skip auto-blocking for the given domain.
				 *
				 * @param bool   $skip_auto_block Whether to skip auto-blocking.
				 * @param string $domain          Domain being evaluated.
				 * @param string $reason          Spam reason.
				 * @param string $context         Context of the submission.
				 */
				$skip_auto_block = (bool) apply_filters( 'pmcpc_skip_auto_block_domain', $skip_auto_block, $domain, $reason, $context );
	
				if ( $skip_auto_block ) {
					// Record a reason bucket for visibility.
					$stats = get_option( 'pmcpc_spam_stats', array() );
					if ( ! is_array( $stats ) ) {
						$stats = array();
					}
					if ( ! isset( $stats['reasons'] ) || ! is_array( $stats['reasons'] ) ) {
						$stats['reasons'] = array();
					}
					$stats['reasons']['auto_domain_skipped'] = isset( $stats['reasons']['auto_domain_skipped'] ) ? (int) $stats['reasons']['auto_domain_skipped'] + 1 : 1;
					update_option( 'pmcpc_spam_stats', $stats, false );
	
					// Set a short-lived admin notice flag.
					set_transient( 'pmcpc_notice_auto_block_skipped', $domain, HOUR_IN_SECONDS );
					do_action( 'pmcpc_auto_block_domain_skipped', $domain, $reason, $context );
				} else {
					$threshold = (int) self::get_spam_setting( 'spam_auto_block_domains_threshold', 3 );
					$window    = (int) self::get_spam_setting( 'spam_auto_block_domains_window', 86400 );
					if ( $threshold < 2 ) {
						$threshold = 2;
					}
					if ( $window < 300 ) {
						$window = 300;
					}
					$k = 'pmcpc_abd_' . substr( hash( 'sha256', $domain ), 0, 20 );
					$c = (int) get_transient( $k );
					$c++;
					set_transient( $k, $c, $window );
					if ( $c >= $threshold ) {
						$added = self::add_domain_to_blocked_list( $domain );
						if ( $added ) {
							// Record a separate reason bucket for visibility.
							$stats = get_option( 'pmcpc_spam_stats', array() );
							if ( ! is_array( $stats ) ) {
								$stats = array();
							}
							if ( ! isset( $stats['reasons'] ) || ! is_array( $stats['reasons'] ) ) {
								$stats['reasons'] = array();
							}
							$stats['reasons']['auto_domain_blocked'] = isset( $stats['reasons']['auto_domain_blocked'] ) ? (int) $stats['reasons']['auto_domain_blocked'] + 1 : 1;
							update_option( 'pmcpc_spam_stats', $stats, false );
						}
					}
				}
			}
	
			// Optional lightweight log.
			if ( 'yes' !== self::get_spam_setting( 'spam_log_enabled', 'yes' ) ) {
				return;
			}
	
			global $wpdb;
			$table = esc_sql( $wpdb->prefix . 'pmcpc_block_log' );
			$ip = '';
			if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.
				$ip = sanitize_text_field( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
			}
			$ip_hash = $ip ? hash( 'sha256', $ip ) : null;
	
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->insert(
				$table,
				array(
					'email'      => $email ? $email : null,
					'domain'     => $domain ? $domain : null,
					'ip_hash'    => $ip_hash,
					'reason'     => $reason,
					'context'    => $context,
					'created_at' => current_time( 'mysql' ),
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s' )
			);
		}

    use PMCPC_Subscriber_Manager_Methods;

/**
 * Get allowlisted emails (lowercased).
 *
 * Option key: pmcpc_allowlisted_emails
 *
 * @return string[]
 */
public static function get_allowlisted_emails() {
    $raw = get_option( 'pmcpc_allowlisted_emails', array() );

    if ( is_string( $raw ) ) {
        // Support comma / newline separated lists.
        $raw = preg_split( '/[\s,]+/', $raw );
    }

    if ( ! is_array( $raw ) ) {
        $raw = array();
    }

    $out = array();
    foreach ( $raw as $item ) {
        $email = sanitize_email( (string) $item );
        if ( $email ) {
            $out[] = strtolower( $email );
        }
    }

    $out = array_values( array_unique( $out ) );
    return $out;
}

/**
 * Get allowlisted email domains (lowercased).
 *
 * Option key: pmcpc_allowlisted_email_domains
 *
 * @return string[]
 */
public static function get_allowlisted_email_domains() {
    $raw = get_option( 'pmcpc_allowlisted_email_domains', array() );

    if ( is_string( $raw ) ) {
        $raw = preg_split( '/[\s,]+/', $raw );
    }

    if ( ! is_array( $raw ) ) {
        $raw = array();
    }

    $out = array();
    foreach ( $raw as $item ) {
        $domain = strtolower( trim( (string) $item ) );
        $domain = preg_replace( '/^@/', '', $domain );
        if ( $domain ) {
            $out[] = $domain;
        }
    }

    $out = array_values( array_unique( $out ) );
    return $out;
}


    /**
     * Back-compat: check if a sender (email or domain) is allowlisted.
     *
     * Legacy shortcode/message handling calls this helper. It existed on the
     * old subscriber manager class, but the instance-first controller initially
     * only imported the spam evaluation trait.
     *
     * @param string $email Email address.
     * @return bool
     */

    public static function is_allowlisted_email_address( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email ) {
			return false;
		}
		$allowed = self::get_allowlisted_emails();
		return in_array( strtolower( $email ), $allowed, true );
	}

	public static function is_allowlisted_sender( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email || strpos( $email, '@' ) === false ) {
			return false;
		}
		if ( self::is_allowlisted_email_address( $email ) ) {
			return true;
		}
		$parts  = explode( '@', $email );
		$domain = strtolower( trim( end( $parts ) ) );
		if ( '' === $domain ) {
			return false;
		}
		foreach ( self::get_allowlisted_email_domains() as $allowed_domain ) {
			if ( '' === $allowed_domain ) {
				continue;
			}
			$pattern = '/(^|\.)' . preg_quote( $allowed_domain, '/' ) . '$/';
			if ( preg_match( $pattern, $domain ) ) {
				return true;
			}
		}
		return false;
	}

	public static function get_additional_blocked_emails() {
		$list = get_option( 'pmcpc_additional_blocked_emails', '' );
		if ( ! is_string( $list ) || '' === trim( $list ) ) {
			return array();
		}
		$lines = preg_split( '/\r\n|\r|\n/', $list );
		$out   = array();
		if ( is_array( $lines ) ) {
			foreach ( $lines as $line ) {
				$email = sanitize_email( trim( (string) $line ) );
				if ( $email ) {
					$out[] = strtolower( $email );
				}
			}
		}
		return array_values( array_unique( $out ) );
	}

	public static function is_blocked_email_address( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email ) {
			return false;
		}
		$blocked = self::get_additional_blocked_emails();
		return in_array( strtolower( $email ), $blocked, true );
	}

	public static function is_rate_limited() {
		if ( 'yes' !== self::get_spam_setting( 'spam_rate_limit_enabled', 'yes' ) ) {
			return false;
		}
		$ip = '';
		if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.
			$ip = sanitize_text_field( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}
		if ( ! $ip ) {
			return false;
		}
		$key = 'pmcpc_rl_' . substr( hash( 'sha256', $ip ), 0, 20 );
		$window = (int) self::get_spam_setting( 'spam_rate_limit_window', 600 );
		$max    = (int) self::get_spam_setting( 'spam_rate_limit_max', 5 );
		$count  = (int) get_transient( $key );
		$count++;
		set_transient( $key, $count, max( 60, $window ) );
		return ( $count > $max );
	}

	public static function is_spammy_name( $first_name, $last_name ) {
		$first = mb_strtolower( (string) $first_name );
		$last  = mb_strtolower( (string) $last_name );
		if ( $first && $last && $first === $last ) {
			return true;
		}
		$haystack = $first . ' ' . $last;
		if ( preg_match( '/(http|www\\.|\\.ru|\\.xyz|\\.top|@)/i', $haystack ) ) {
			return true;
		}
		if ( mb_strlen( (string) $first_name ) > 40 || mb_strlen( (string) $last_name ) > 40 ) {
			return true;
		}
		return false;
	}

	public static function is_suspicious_tld( $email ) {
		if ( 'yes' !== self::get_spam_setting( 'spam_suspicious_tlds_enabled', 'yes' ) ) {
			return false;
		}
		$email = sanitize_email( (string) $email );
		if ( ! $email || strpos( $email, '@' ) === false ) {
			return false;
		}
		$domain = strtolower( trim( substr( strrchr( $email, '@' ), 1 ) ) );
		if ( ! $domain || strpos( $domain, '.' ) === false ) {
			return false;
		}
		$tld = strtolower( trim( substr( strrchr( $domain, '.' ), 1 ) ) );
		$list = (string) self::get_spam_setting( 'spam_suspicious_tlds', '' );
		$items = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $list ) ) );
		return $tld && in_array( $tld, $items, true );
	}


	/**
	 * WooCommerce purchase stats used on Subscribers screen.
	 * Returns array with keys: total_spend (float) and last_completed_ts (int).
	 *
	 * @param string $email
	 * @return array{total_spend:float,last_completed_ts:int}
	 */
	public static function get_wc_purchase_stats_for_email( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email ) {
			return array( 'total_spend' => 0.0, 'last_completed_ts' => 0 );
		}
		if ( isset( self::$wc_stats_cache[ $email ] ) ) {
			return self::$wc_stats_cache[ $email ];
		}
		$stats = array( 'total_spend' => 0.0, 'last_completed_ts' => 0 );

		if ( ! function_exists( 'wc_get_orders' ) ) {
			self::$wc_stats_cache[ $email ] = $stats;
			return $stats;
		}

		$user = get_user_by( 'email', $email );
		$customer_id = $user ? (int) $user->ID : 0;

		// Total spend.
		if ( $customer_id > 0 && function_exists( 'wc_get_customer_total_spent' ) ) {
			$stats['total_spend'] = (float) wc_get_customer_total_spent( $customer_id );
		} else {
			$order_ids = wc_get_orders( array(
				'limit'    => 50,
				'customer' => $email,
				'status'   => array( 'wc-processing', 'wc-completed' ),
				'return'   => 'ids',
			) );
			if ( ! empty( $order_ids ) ) {
				$total = 0.0;
				foreach ( $order_ids as $oid ) {
					$order = wc_get_order( $oid );
					if ( $order ) {
						$total += (float) $order->get_total();
					}
				}
				$stats['total_spend'] = $total;
			}
		}

		// Last completed order timestamp.
		$args = array(
			'limit'   => 1,
			'orderby' => 'date',
			'order'   => 'DESC',
			'status'  => array( 'wc-completed' ),
			'return'  => 'ids',
		);
		if ( $customer_id > 0 ) {
			$args['customer_id'] = $customer_id;
		} else {
			$args['customer'] = $email;
		}
		$last_ids = wc_get_orders( $args );
		if ( ! empty( $last_ids ) ) {
			$order = wc_get_order( $last_ids[0] );
			if ( $order && $order->get_date_completed() ) {
				$stats['last_completed_ts'] = (int) $order->get_date_completed()->getTimestamp();
			} elseif ( $order && $order->get_date_created() ) {
				$stats['last_completed_ts'] = (int) $order->get_date_created()->getTimestamp();
			}
		}

		self::$wc_stats_cache[ $email ] = $stats;
		return $stats;
	}


	// ===== End back-compat spam helpers =====
}
