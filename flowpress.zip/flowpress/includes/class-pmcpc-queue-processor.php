<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once PMCPC_PLUGIN_DIR . 'includes/queue/class-pmcpc-queue-controller.php';

/**
 * Back-compat façade.
 *
 * Keep the original class name while moving implementation to an instance-first controller.
 */
class PMCPC_Queue_Processor extends PMCPC_Queue_Controller {}
