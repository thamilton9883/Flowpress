<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/trait-pmcpc-shortcodes-bootstrap-methods.php';
require_once __DIR__ . '/trait-pmcpc-shortcodes-form-handler-methods.php';
require_once __DIR__ . '/trait-pmcpc-shortcodes-form-render-methods.php';
require_once __DIR__ . '/trait-pmcpc-shortcodes-subscriber-updates-methods.php';

trait PMCPC_Shortcodes_Methods {
    use PMCPC_Shortcodes_Bootstrap_Methods;
    use PMCPC_Shortcodes_Form_Handler_Methods;
    use PMCPC_Shortcodes_Form_Render_Methods;
    use PMCPC_Shortcodes_Subscriber_Updates_Methods;
}
