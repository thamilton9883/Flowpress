<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Shortcodes_Form_Render_Methods {
    

    public static function render_subscribe_form( $atts ) {

            $atts = shortcode_atts(

                array(

                    'title'        => __( 'Subscribe', 'product-mailer-campaigns' ),

                    'show_name'    => 'yes',

                    'button_label' => __( 'Subscribe', 'product-mailer-campaigns' ),

                    'fields'       => null,

                    'custom_fields'=> null,

                ),

                $atts,

                'pmcpc_subscribe'

            );

    

            ob_start();

    

            self::maybe_load_flash_message();

    

            self::output_frontend_form_assets_once();

    

            $flash_success = ( ! empty( self::$last_message ) && false !== strpos( self::$last_message, 'pmcpc-success' ) );

    

            if ( ! empty( self::$last_message ) ) {

                echo wp_kses_post( self::$last_message );

            }

    

    

    		// Page context (used for return link + tagging / troubleshooting subscription sources).

    		$page_ctx = self::get_current_page_context();

    

            if ( $flash_success ) {

                $reset_url = remove_query_arg( 'pmcpc_flash', $page_ctx['url'] );

                $reset_url = $reset_url . '#pmcpc-form-subscribe';

                echo '<div class="pmcpc-after-success"><a class="pmcpc-action-link" href="' . esc_url( $reset_url ) . '">' . esc_html__( 'Submit another signup', 'product-mailer-campaigns' ) . '</a></div>';

            }

    

            echo '<form method="post" id="pmcpc-form-subscribe" class="pmcpc-subscribe-form' . ( $flash_success ? ' pmcpc-form-disabled' : '' ) . '">';

    

    		echo '<input type="hidden" name="pmcpc_page_url" value="' . esc_attr( $page_ctx['url'] ) . '">';

    		echo '<input type="hidden" name="pmcpc_page_title" value="' . esc_attr( $page_ctx['title'] ) . '">';

    		echo '<input type="hidden" name="pmcpc_post_id" value="' . esc_attr( (string) ( $page_ctx['post_id'] ?? 0 ) ) . '">';

    		echo '<input type="hidden" name="pmcpc_return_to" value="' . esc_attr( $page_ctx['url'] ) . '">';

            wp_nonce_field( 'pmcpc_front_subscribe', 'pmcpc_front_subscribe_nonce' );

    

            if ( ! empty( $atts['title'] ) ) {

                echo '<h3>' . esc_html( $atts['title'] ) . '</h3>';

            }

            if ( 'yes' === (string) ( $atts['review_mode'] ?? '' ) && $prefill_rating > 0 ) {

                if ( $smart_low_rating ) {

                    echo '<p class="pmcpc-review-note">' . esc_html__( 'Thank you for your honesty. This feedback goes privately to our team so we can put things right.', 'product-mailer-campaigns' ) . '</p>';

                } else {

                    echo '<p class="pmcpc-review-note">' . esc_html__( 'Thanks for choosing a rating. Your review will be sent for moderation before it is shown publicly.', 'product-mailer-campaigns' ) . '</p>';

                }

            }

    

            // Field editor support (used by dynamic forms). Legacy shortcode output remains the default.

            $fields = ( isset( $atts['fields'] ) && is_array( $atts['fields'] ) ) ? $atts['fields'] : null;

    

            if ( is_array( $fields ) ) {

                $order = array( 'first_name', 'last_name', 'email' );

                foreach ( $order as $key ) {

                    if ( ! isset( $fields[ $key ] ) || ! is_array( $fields[ $key ] ) ) {

                        continue;

                    }

                    $row = $fields[ $key ];

                    $enabled  = isset( $row['enabled'] ) ? (string) $row['enabled'] : 'yes';

                    $required = isset( $row['required'] ) ? (string) $row['required'] : 'no';

                    $label    = isset( $row['label'] ) ? (string) $row['label'] : '';

                    $ph       = isset( $row['placeholder'] ) ? (string) $row['placeholder'] : '';

    

                    if ( 'no' === $enabled ) {

                        continue;

                    }

    

                    if ( 'optin' === $key ) {

                        echo '<p class="pmcpc-selling-optin"><label>';

                        echo '<input type="checkbox" name="pmcpc_opt_in" value="1" /> ';

                        echo esc_html( $label ? $label : __( 'Email me product updates and special offers', 'product-mailer-campaigns' ) );

                        echo '</label></p>';

                        continue;

                    }

    

                    if ( 'email' === $key ) {

                        $required = 'yes';

                        echo '<p><label>' . esc_html( $label ? $label : __( 'Email address', 'product-mailer-campaigns' ) ) . '<br>';

                        echo '<input type="email" name="pmcpc_email" required placeholder="' . esc_attr( $ph ) . '"></label></p>';

                        continue;

                    }

    

                    $name_attr = ( 'first_name' === $key ) ? 'pmcpc_first_name' : 'pmcpc_last_name';

                    echo '<p><label>' . esc_html( $label ? $label : ( 'first_name' === $key ? __( 'First name', 'product-mailer-campaigns' ) : __( 'Last name', 'product-mailer-campaigns' ) ) ) . '<br>';

                    echo '<input type="text" name="' . esc_attr( $name_attr ) . '" ' . ( 'yes' === $required ? 'required' : '' ) . ' placeholder="' . esc_attr( $ph ) . '"></label></p>';

                }

            } else {

                if ( 'yes' === $atts['show_name'] ) {

                    echo '<p><label>' . esc_html__( 'First name', 'product-mailer-campaigns' ) . '<br>';

                    echo '<input type="text" name="pmcpc_first_name"></label></p>';

                    echo '<p><label>' . esc_html__( 'Last name', 'product-mailer-campaigns' ) . '<br>';

                    echo '<input type="text" name="pmcpc_last_name"></label></p>';

                }

            }

    

            // Honeypot anti-spam field (hidden from humans) - toggleable.

            $hp_enabled = true;

            if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'get_spam_setting' ) ) {

                $hp_enabled = ( 'yes' === PMCPC_Subscriber_Manager::get_spam_setting( 'spam_honeypot_enabled', 'yes' ) );

            }

            if ( $hp_enabled ) {

                echo '<p class="pmcpc-hp-field" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;">';

                echo '<label>' . esc_html__( 'If you are human, leave this field empty.', 'product-mailer-campaigns' ) . '<br>';

                echo '<input type="text" name="pmcpc_hp" autocomplete="off"></label></p>';

            }

    

            if ( ! is_array( $fields ) ) {

                echo '<p><label>' . esc_html__( 'Email address', 'product-mailer-campaigns' ) . '<br>';

                echo '<input type="email" name="pmcpc_email" required></label></p>';

            }

    

            $button_label = ( 'yes' === (string) ( $atts['review_mode'] ?? '' ) && $smart_low_rating ) ? __( 'Send feedback', 'product-mailer-campaigns' ) : ( $atts['button_label'] ?? __( 'Subscribe', 'product-mailer-campaigns' ) );

            echo '<p><button type="submit">' . esc_html( $button_label ) . '</button></p>';

    

            echo '</form>';

    

            return ob_get_clean();

        }

    

    

        

        

    

        /**

         * Shortcode for rendering a checkout-style email opt-in checkbox.

         *

         * Usage: [pmcpc_checkout_optin label="Email me product updates and special offers"]

         * This uses the same 'pmcpc_opt_in' field name that WooCommerce integration listens to.

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

    /**

         * Shortcode for rendering a checkout-style email opt-in checkbox.

         *

         * Usage: [pmcpc_checkout_optin label="Email me product updates and special offers"]

         * This uses the same 'pmcpc_opt_in' field name that WooCommerce integration listens to.

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

        public static function render_checkout_optin( $atts ) {

            $atts = shortcode_atts(

                array(

                    'label' => __( 'Email me product updates and special offers', 'product-mailer-campaigns' ),

                ),

                $atts,

                'pmcpc_checkout_optin'

            );

    

            // Use the same default checked logic as the WooCommerce integration.

            $default_checked = true;

            if ( class_exists( 'PMCPC_Settings' ) ) {

                $setting          = PMCPC_Settings::get( 'wc_opt_in_default_checked', 'yes' );

                $default_checked  = ( 'yes' === $setting );

            }

    

            // Preserve user choice on POST, otherwise use the default.

            $current_value = isset( $_POST['pmcpc_opt_in'] ) ? 1 : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing

            if ( ! isset( $_POST['pmcpc_opt_in'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing

                $current_value = $default_checked ? 1 : 0;

            }

    

            ob_start();

            self::output_frontend_form_assets_once();

            echo '<p class="form-row form-row-wide pmcpc-opt-in-shortcode" style="margin-top:15px;">';

    

            if ( function_exists( 'woocommerce_form_field' ) ) {

                woocommerce_form_field(

                    'pmcpc_opt_in',

                    array(

                        'type'     => 'checkbox',

                        'label'    => esc_html( $atts['label'] ),

                        'required' => false,

                    ),

                    $current_value

                );

            } else {

                printf(

                    '<label><input type="checkbox" name="pmcpc_opt_in" value="1"%s /> %s</label>',

                    checked( 1, $current_value, false ),

                    esc_html( $atts['label'] )

                );

            }

    

            echo '</p>';

    

            return ob_get_clean();

        }

    

    

        /**

         * Simple contact form shortcode.

         *

         * Usage: [pmcpc_contact_form]

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

    /**

         * Simple contact form shortcode.

         *

         * Usage: [pmcpc_contact_form]

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

        public static function render_contact_form( $atts ) {

            $atts = shortcode_atts(

                array(

                    'title'       => __( 'Contact us', 'product-mailer-campaigns' ),

                    'show_subject'=> 'yes',

                    'show_optin'  => 'yes',

                    'button_label'=> __( 'Send message', 'product-mailer-campaigns' ),

                    'fields'       => null,

                    'custom_fields'=> null,

                    'review_mode'  => 'no',

                    'product_review' => 'no',

                ),

                $atts,

                'pmcpc_contact_form'

            );

    

            ob_start();

    

            self::maybe_load_flash_message();

    

            self::output_frontend_form_assets_once();

    

            // Page context is needed for both hidden fields and "send another" reset links.

            $page_ctx = self::get_current_page_context();

    

            $prefill_name   = isset( $_GET['name'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['name'] ) ) : '';

            $prefill_email  = isset( $_GET['email'] ) ? sanitize_email( (string) wp_unslash( $_GET['email'] ) ) : '';

            $prefill_rating = isset( $_GET['rating'] ) ? max( 0, min( 5, absint( wp_unslash( $_GET['rating'] ) ) ) ) : 0;

            $prefill_product_id = isset( $_GET['product'] ) ? absint( wp_unslash( $_GET['product'] ) ) : 0;

            if ( is_user_logged_in() ) {

                $current_user = wp_get_current_user();

                if ( $current_user && $current_user->exists() ) {

                    if ( '' === $prefill_name ) {

                        $prefill_name = $current_user->display_name ? $current_user->display_name : $current_user->user_login;

                    }

                    if ( '' === $prefill_email ) {

                        $prefill_email = (string) $current_user->user_email;

                    }

                }

            }

            $smart_low_rating = ( 'yes' === (string) $atts['review_mode'] && $prefill_rating > 0 && $prefill_rating <= 3 );

            if ( $smart_low_rating && empty( $atts['title'] ) ) {

                $atts['title'] = __( 'Private feedback', 'product-mailer-campaigns' );

            }

    

            $flash_success = ( ! empty( self::$last_message ) && false !== strpos( self::$last_message, 'pmcpc-success' ) );

    

            if ( ! empty( self::$last_message ) ) {

                echo wp_kses_post( self::$last_message );

            }

    

            if ( $flash_success ) {

                $reset_url = remove_query_arg( 'pmcpc_flash', $page_ctx['url'] );

                $reset_url = $reset_url . '#pmcpc-form-contact';

                echo '<div class="pmcpc-after-success"><a class="pmcpc-action-link" href="' . esc_url( $reset_url ) . '">' . esc_html__( 'Send another message', 'product-mailer-campaigns' ) . '</a></div>';

            }

    

            $custom_fields = ( isset( $atts['custom_fields'] ) && is_array( $atts['custom_fields'] ) ) ? $atts['custom_fields'] : array();

            if ( class_exists( 'PMCPC_Forms' ) ) {

                $custom_fields = PMCPC_Forms::sanitize_custom_fields( $custom_fields );

            }

            $has_file = false;

            if ( ! empty( $custom_fields ) ) {

                foreach ( $custom_fields as $cf ) {

                    if ( isset( $cf['enabled'], $cf['type'] ) && 'yes' === (string) $cf['enabled'] && 'file' === (string) $cf['type'] ) {

                        $has_file = true;

                        break;

                    }

                }

            }

    

            echo '<form method="post" id="pmcpc-form-contact" class="pmcpc-contact-form' . ( $flash_success ? ' pmcpc-form-disabled' : '' ) . '"' . ( $has_file ? ' enctype="multipart/form-data"' : '' ) . '>';

    

    		// Page context (used in notification emails so you can see where the form was submitted from).

    		echo '<input type="hidden" name="pmcpc_page_url" value="' . esc_attr( $page_ctx['url'] ) . '">';

    		echo '<input type="hidden" name="pmcpc_page_title" value="' . esc_attr( $page_ctx['title'] ) . '">';

    		echo '<input type="hidden" name="pmcpc_post_id" value="' . esc_attr( (string) ( $page_ctx['post_id'] ?? 0 ) ) . '">';

    		echo '<input type="hidden" name="pmcpc_return_to" value="' . esc_attr( $page_ctx['url'] ) . '">';

            if ( ! empty( $atts['title'] ) ) {

                echo '<h3>' . esc_html( $atts['title'] ) . '</h3>';

            }

            if ( 'yes' === (string) $atts['review_mode'] && $prefill_rating > 0 ) {

                if ( $smart_low_rating ) {

                    echo '<p class="pmcpc-review-note">' . esc_html__( 'Thank you for your honesty. This feedback goes privately to our team so we can put things right.', 'product-mailer-campaigns' ) . '</p>';

                } else {

                    echo '<p class="pmcpc-review-note">' . esc_html__( 'Thanks for choosing a rating. Your review will be sent for moderation before it is shown publicly.', 'product-mailer-campaigns' ) . '</p>';

                }

            }

    

            // Field editor support (used by dynamic forms). Legacy shortcode output remains the default.

            $fields = ( isset( $atts['fields'] ) && is_array( $atts['fields'] ) ) ? $atts['fields'] : null;

    

            if ( is_array( $fields ) ) {

                // Normalize a few legacy toggles based on fields config.

                if ( isset( $fields['subject']['enabled'] ) ) {

                    $atts['show_subject'] = ( 'yes' === (string) $fields['subject']['enabled'] ) ? 'yes' : 'no';

                }

                if ( isset( $fields['optin']['enabled'] ) ) {

                    $atts['show_optin'] = ( 'yes' === (string) $fields['optin']['enabled'] ) ? 'yes' : 'no';

                }

    

                $order = ( 'yes' === (string) $atts['review_mode'] ) ? array( 'name', 'email', 'rating', 'subject', 'message', 'product_id' ) : array( 'name', 'email', 'subject', 'message', 'optin' );

                foreach ( $order as $key ) {

                    if ( ! isset( $fields[ $key ] ) || ! is_array( $fields[ $key ] ) ) {

                        continue;

                    }

                    $row = $fields[ $key ];

                    $enabled  = isset( $row['enabled'] ) ? (string) $row['enabled'] : 'yes';

                    $required = isset( $row['required'] ) ? (string) $row['required'] : 'no';

                    $label    = isset( $row['label'] ) ? (string) $row['label'] : '';

                    $ph       = isset( $row['placeholder'] ) ? (string) $row['placeholder'] : '';

    

                    if ( 'no' === $enabled ) {

                        continue;

                    }

    

                    // Enforce hard-required fields.

                    if ( in_array( $key, array( 'email', 'message' ), true ) ) {

                        $required = 'yes';

                    }

    

                    if ( 'optin' === $key ) {

                        echo '<p class="pmcpc-contact-optin"><label>';

                        echo '<input type="checkbox" name="pmcpc_opt_in" value="1" /> ';

                        echo esc_html( $label ? $label : __( 'Email me product updates and special offers', 'product-mailer-campaigns' ) );

                        echo '</label></p>';

                        continue;

                    }

    

                    if ( 'rating' === $key ) {

                        echo '<p><label>' . esc_html( $label ? $label : __( 'Rating', 'product-mailer-campaigns' ) ) . '<br />';

                        if ( $prefill_rating > 0 ) {

                            echo '<input type="hidden" name="pmcpc_review_rating" value="' . esc_attr( (string) $prefill_rating ) . '" />';

                            echo '<span class="pmcpc-review-fixed-rating">' . esc_html( str_repeat( '★', $prefill_rating ) . ' (' . $prefill_rating . '/5)' ) . '</span>';

                        } else {

                            echo '<select name="pmcpc_review_rating" ' . ( 'yes' === $required ? 'required="required"' : '' ) . '>';

                            echo '<option value="">' . esc_html__( 'Select a rating', 'product-mailer-campaigns' ) . '</option>';

                            for ( $stars = 5; $stars >= 1; $stars-- ) {

                                echo '<option value="' . esc_attr( (string) $stars ) . '">' . esc_html( str_repeat( '★', $stars ) . ' (' . $stars . '/5)' ) . '</option>';

                            }

                            echo '</select>';

                        }

                        echo '</label></p>';

                        continue;

                    }

    

                    if ( 'product_id' === $key ) {

                        $product_id = $prefill_product_id;

                        if ( $product_id <= 0 && function_exists( 'is_singular' ) && is_singular( 'product' ) && function_exists( 'get_the_ID' ) ) {

                            $product_id = (int) get_the_ID();

                        }

                        echo '<input type="hidden" name="pmcpc_product_id" value="' . esc_attr( (string) $product_id ) . '" />';

                        continue;

                    }

    

                    if ( 'message' === $key ) {

                        echo '<p><label>' . esc_html( $label ? $label : ( 'yes' === (string) $atts['review_mode'] ? ( $smart_low_rating ? __( 'How can we improve?', 'product-mailer-campaigns' ) : __( 'Your review', 'product-mailer-campaigns' ) ) : __( 'Message', 'product-mailer-campaigns' ) ) ) . '<br />';

                        echo '<textarea name="pmcpc_contact_message" rows="5" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '"></textarea></label></p>';

                        continue;

                    }

    

                    if ( 'email' === $key ) {

                        echo '<p><label>' . esc_html( $label ? $label : __( 'Your email address', 'product-mailer-campaigns' ) ) . '<br />';

                        echo '<input type="email" name="pmcpc_contact_email" value="' . esc_attr( $prefill_email ) . '" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '" /></label></p>';

                        continue;

                    }

    

                    if ( 'name' === $key ) {

                        echo '<p><label>' . esc_html( $label ? $label : __( 'Your name', 'product-mailer-campaigns' ) ) . '<br />';

                        echo '<input type="text" name="pmcpc_contact_name" value="' . esc_attr( $prefill_name ) . '" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '" /></label></p>';

                        continue;

                    }

    

                    if ( 'subject' === $key ) {

                        echo '<p><label>' . esc_html( $label ? $label : __( 'Subject', 'product-mailer-campaigns' ) ) . '<br />';

                        echo '<input type="text" name="pmcpc_contact_subject" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '" /></label></p>';

                        continue;

                    }

                }

            } else {

                // Default legacy rendering.

                echo '<p><label>' . esc_html__( 'Your name', 'product-mailer-campaigns' ) . '<br />';

                echo '<input type="text" name="pmcpc_contact_name" value="' . esc_attr( $prefill_name ) . '" /></label></p>';

    

                echo '<p><label>' . esc_html__( 'Your email address', 'product-mailer-campaigns' ) . '<br />';

                echo '<input type="email" name="pmcpc_contact_email" value="' . esc_attr( $prefill_email ) . '" required="required" /></label></p>';

    

                if ( 'yes' === $atts['show_subject'] ) {

                    echo '<p><label>' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '<br />';

                    echo '<input type="text" name="pmcpc_contact_subject" /></label></p>';

                }

    

                echo '<p><label>' . esc_html__( 'Message', 'product-mailer-campaigns' ) . '<br />';

                echo '<textarea name="pmcpc_contact_message" rows="5" required="required"></textarea></label></p>';

    

                if ( 'yes' === $atts['show_optin'] ) {

                    echo '<p class="pmcpc-contact-optin"><label>';

                    echo '<input type="checkbox" name="pmcpc_opt_in" value="1" /> ';

                    echo esc_html__( 'Email me product updates and special offers', 'product-mailer-campaigns' );

                    echo '</label></p>';

                }

            }

    

            

            // Render additional/custom fields (dynamic forms only).

            if ( ! empty( $custom_fields ) ) {

                foreach ( $custom_fields as $cf ) {

                    if ( ! is_array( $cf ) ) {

                        continue;

                    }

                    $enabled = isset( $cf['enabled'] ) ? (string) $cf['enabled'] : 'yes';

                    if ( 'no' === $enabled ) {

                        continue;

                    }

                    $key      = isset( $cf['key'] ) ? sanitize_key( (string) $cf['key'] ) : '';

                    $type     = isset( $cf['type'] ) ? (string) $cf['type'] : 'text';

                    $label    = isset( $cf['label'] ) ? (string) $cf['label'] : '';

                    $ph       = isset( $cf['placeholder'] ) ? (string) $cf['placeholder'] : '';

                    $required = ( isset( $cf['required'] ) && 'yes' === (string) $cf['required'] ) ? 'yes' : 'no';

    

                    if ( '' === $key ) {

                        continue;

                    }

    

                    $name = 'pmcpc_cf_' . $key;

    

                    if ( 'file' === $type ) {

                        $max_files = isset( $cf['max_files'] ) ? absint( $cf['max_files'] ) : 5;

                        if ( $max_files < 1 ) {

                            $max_files = 1;

                        }

                        if ( $max_files > 10 ) {

                            $max_files = 10;

                        }

                        echo '<p><label>' . esc_html( $label ? $label : __( 'File upload', 'product-mailer-campaigns' ) ) . '<br />';

                        echo '<input type="file" name="' . esc_attr( $name ) . '[]" multiple="multiple" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' accept=".jpg,.jpeg,.png,.webp,.pdf" />';

    										/* translators: %d: maximum number of files allowed. */

                        echo '<br /><span class="description">' . sprintf( esc_html__( 'You can upload up to %d files (JPG, PNG, WEBP, PDF).', 'product-mailer-campaigns' ), (int) $max_files ) . '</span>';

                        echo '</label></p>';

                        continue;

                    }

    

                    if ( 'textarea' === $type ) {

                        echo '<p><label>' . esc_html( $label ) . '<br />';

                        echo '<textarea name="' . esc_attr( $name ) . '" rows="4" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '"></textarea></label></p>';

                        continue;

                    }

    

                    // Default: text.

                    echo '<p><label>' . esc_html( $label ) . '<br />';

                    echo '<input type="text" name="' . esc_attr( $name ) . '" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '" /></label></p>';

                }

            }

    

    

            // Honeypot anti-spam field (hidden from humans).

            echo '<p class="pmcpc-hp-field" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;">';

            echo '<label>' . esc_html__( 'If you are human, leave this field empty.', 'product-mailer-campaigns' ) . '<br>';

            echo '<input type="text" name="pmcpc_hp" autocomplete="off"></label></p>';

    

            // Signed timing token to detect ultra-fast bot submissions (no JS required).

    		if ( self::timing_checks_enabled() ) {

    			echo '<input type="hidden" name="pmcpc_ft" value="' . esc_attr( self::make_timing_token( 'contact' ) ) . '">';

    		}

    

    wp_nonce_field( 'pmcpc_contact_form', 'pmcpc_contact_form_nonce' );

    

            echo '<p><button type="submit" class="button">' . esc_html( $atts['button_label'] ) . '</button></p>';

            echo '</form>';

    

            return ob_get_clean();

        }

    

        /**

         * Selling enquiry form shortcode.

         *

         * Usage: [pmcpc_selling_form]

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

    /**

         * Selling enquiry form shortcode.

         *

         * Usage: [pmcpc_selling_form]

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

        public static function render_selling_form( $atts ) {

            $atts = shortcode_atts(

                array(

                    'title'        => __( 'Sell us your items', 'product-mailer-campaigns' ),

                    'show_optin'   => 'yes',

                    'button_label' => __( 'Send selling enquiry', 'product-mailer-campaigns' ),

                    'fields'       => null,

                    'custom_fields'=> null,

                    'review_mode'  => 'no',

                ),

                $atts,

                'pmcpc_selling_form'

            );

    

            ob_start();

    

            self::maybe_load_flash_message();

    

            self::output_frontend_form_assets_once();

    

            // Page context is needed for both hidden fields and "send another" reset links.

            $page_ctx = self::get_current_page_context();

    

            $prefill_name   = isset( $_GET['name'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['name'] ) ) : '';

            $prefill_email  = isset( $_GET['email'] ) ? sanitize_email( (string) wp_unslash( $_GET['email'] ) ) : '';

            $prefill_rating = isset( $_GET['rating'] ) ? max( 0, min( 5, absint( wp_unslash( $_GET['rating'] ) ) ) ) : 0;

            $prefill_product_id = isset( $_GET['product'] ) ? absint( wp_unslash( $_GET['product'] ) ) : 0;

            if ( is_user_logged_in() ) {

                $current_user = wp_get_current_user();

                if ( $current_user && $current_user->exists() ) {

                    if ( '' === $prefill_name ) {

                        $prefill_name = $current_user->display_name ? $current_user->display_name : $current_user->user_login;

                    }

                    if ( '' === $prefill_email ) {

                        $prefill_email = (string) $current_user->user_email;

                    }

                }

            }

            $smart_low_rating = ( 'yes' === (string) $atts['review_mode'] && $prefill_rating > 0 && $prefill_rating <= 3 );

            if ( $smart_low_rating && empty( $atts['title'] ) ) {

                $atts['title'] = __( 'Private feedback', 'product-mailer-campaigns' );

            }

    

            $flash_success = ( ! empty( self::$last_message ) && false !== strpos( self::$last_message, 'pmcpc-success' ) );

    

            if ( ! empty( self::$last_message ) ) {

                echo wp_kses_post( self::$last_message );

            }

    

            if ( $flash_success ) {

                $reset_url = remove_query_arg( 'pmcpc_flash', $page_ctx['url'] );

                $reset_url = $reset_url . '#pmcpc-form-selling';

                echo '<div class="pmcpc-after-success"><a class="pmcpc-action-link" href="' . esc_url( $reset_url ) . '">' . esc_html__( 'Send another message', 'product-mailer-campaigns' ) . '</a></div>';

            }

    

            $custom_fields = ( isset( $atts['custom_fields'] ) && is_array( $atts['custom_fields'] ) ) ? $atts['custom_fields'] : array();

            if ( class_exists( 'PMCPC_Forms' ) ) {

                $custom_fields = PMCPC_Forms::sanitize_custom_fields( $custom_fields );

            }

            $has_file = false;

            if ( ! empty( $custom_fields ) ) {

                foreach ( $custom_fields as $cf ) {

                    if ( isset( $cf['enabled'], $cf['type'] ) && 'yes' === (string) $cf['enabled'] && 'file' === (string) $cf['type'] ) {

                        $has_file = true;

                        break;

                    }

                }

            }

    

    

            echo '<form method="post" id="pmcpc-form-selling" class="pmcpc-selling-form' . ( $flash_success ? ' pmcpc-form-disabled' : '' ) . '"' . ( $has_file ? ' enctype="multipart/form-data"' : '' ) . '>';

    

    		// Page context (used in notification emails so you can see where the form was submitted from).

    		echo '<input type="hidden" name="pmcpc_page_url" value="' . esc_attr( $page_ctx['url'] ) . '">';

    		echo '<input type="hidden" name="pmcpc_page_title" value="' . esc_attr( $page_ctx['title'] ) . '">';

    		echo '<input type="hidden" name="pmcpc_post_id" value="' . esc_attr( (string) ( $page_ctx['post_id'] ?? 0 ) ) . '">';

    		echo '<input type="hidden" name="pmcpc_return_to" value="' . esc_attr( $page_ctx['url'] ) . '">';

            if ( ! empty( $atts['title'] ) ) {

                echo '<h3>' . esc_html( $atts['title'] ) . '</h3>';

            }

            if ( 'yes' === (string) $atts['review_mode'] && $prefill_rating > 0 ) {

                if ( $smart_low_rating ) {

                    echo '<p class="pmcpc-review-note">' . esc_html__( 'Thank you for your honesty. This feedback goes privately to our team so we can put things right.', 'product-mailer-campaigns' ) . '</p>';

                } else {

                    echo '<p class="pmcpc-review-note">' . esc_html__( 'Thanks for choosing a rating. Your review will be sent for moderation before it is shown publicly.', 'product-mailer-campaigns' ) . '</p>';

                }

            }

    

            // Field editor support (used by dynamic forms). Legacy shortcode output remains the default.

            $fields = ( isset( $atts['fields'] ) && is_array( $atts['fields'] ) ) ? $atts['fields'] : null;

    

            if ( is_array( $fields ) ) {

                // Normalize a legacy toggle based on fields config.

                if ( isset( $fields['optin']['enabled'] ) ) {

                    $atts['show_optin'] = ( 'yes' === (string) $fields['optin']['enabled'] ) ? 'yes' : 'no';

                }

    

                $rendered_optin = false;

                $order = array( 'name', 'email', 'phone', 'item', 'price', 'details', 'optin' );

                foreach ( $order as $key ) {

                    if ( ! isset( $fields[ $key ] ) || ! is_array( $fields[ $key ] ) ) {

                        continue;

                    }

                    $row = $fields[ $key ];

                    $enabled  = isset( $row['enabled'] ) ? (string) $row['enabled'] : 'yes';

                    $required = isset( $row['required'] ) ? (string) $row['required'] : 'no';

                    $label    = isset( $row['label'] ) ? (string) $row['label'] : '';

                    $ph       = isset( $row['placeholder'] ) ? (string) $row['placeholder'] : '';

    

                    if ( 'no' === $enabled ) {

                        continue;

                    }

    

                    if ( in_array( $key, array( 'email', 'details' ), true ) ) {

                        $required = 'yes';

                    }

    

                    if ( 'optin' === $key ) {

                        // Only render if enabled (admin toggle / field editor).

                        if ( 'yes' === $atts['show_optin'] ) {

                            echo '<p class="pmcpc-selling-optin"><label>';

                            echo '<input type="checkbox" name="pmcpc_opt_in" value="1" /> ';

                            echo esc_html( $label ? $label : __( 'Email me product updates and special offers', 'product-mailer-campaigns' ) );

                            echo '</label></p>';

                        }

                        $rendered_optin = true;

                        continue;

                    }

    

                    if ( 'details' === $key ) {

                        echo '<p><label>' . esc_html( $label ? $label : __( 'Details about the item', 'product-mailer-campaigns' ) ) . '<br />';

                        echo '<textarea name="pmcpc_selling_details" rows="6" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '"></textarea></label></p>';

                        continue;

                    }

    

                    if ( 'email' === $key ) {

                        echo '<p><label>' . esc_html( $label ? $label : __( 'Your email address', 'product-mailer-campaigns' ) ) . '<br />';

                        echo '<input type="email" name="pmcpc_selling_email" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '" /></label></p>';

                        continue;

                    }

    

                    $name_map = array(

                        'name'  => 'pmcpc_selling_name',

                        'phone' => 'pmcpc_selling_phone',

                        'item'  => 'pmcpc_selling_item',

                        'price' => 'pmcpc_selling_price',

                    );

                    if ( isset( $name_map[ $key ] ) ) {

                        echo '<p><label>' . esc_html( $label ? $label : ucfirst( (string) $key ) ) . '<br />';

                        echo '<input type="text" name="' . esc_attr( $name_map[ $key ] ) . '" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '" /></label></p>';

                    }

                }

    

                // Back-compat: older saved selling forms may not have an "optin" field in the field editor config.

                // If the global toggle is enabled, still render the opt-in checkbox.

                if ( 'yes' === $atts['show_optin'] && ! $rendered_optin ) {

                    echo '<p class="pmcpc-selling-optin"><label>';

                    echo '<input type="checkbox" name="pmcpc_opt_in" value="1" /> ';

                    echo esc_html__( 'Email me product updates and special offers', 'product-mailer-campaigns' );

                    echo '</label></p>';

                }

            } else {

                // Default legacy rendering.

                echo '<p><label>' . esc_html__( 'Your name', 'product-mailer-campaigns' ) . '<br />';

                echo '<input type="text" name="pmcpc_selling_name" /></label></p>';

    

                echo '<p><label>' . esc_html__( 'Your email address', 'product-mailer-campaigns' ) . '<br />';

                echo '<input type="email" name="pmcpc_selling_email" required="required" /></label></p>';

    

                echo '<p><label>' . esc_html__( 'Phone number (optional)', 'product-mailer-campaigns' ) . '<br />';

                echo '<input type="text" name="pmcpc_selling_phone" /></label></p>';

    

                echo '<p><label>' . esc_html__( 'Item you want to sell', 'product-mailer-campaigns' ) . '<br />';

                echo '<input type="text" name="pmcpc_selling_item" /></label></p>';

    

                echo '<p><label>' . esc_html__( 'Asking price (optional)', 'product-mailer-campaigns' ) . '<br />';

                echo '<input type="text" name="pmcpc_selling_price" /></label></p>';

    

                echo '<p><label>' . esc_html__( 'Details about the item', 'product-mailer-campaigns' ) . '<br />';

                echo '<textarea name="pmcpc_selling_details" rows="6" required="required"></textarea></label></p>';

    

                if ( 'yes' === $atts['show_optin'] ) {

                    echo '<p class="pmcpc-selling-optin"><label>';

                    echo '<input type="checkbox" name="pmcpc_opt_in" value="1" /> ';

                    echo esc_html__( 'Email me product updates and special offers', 'product-mailer-campaigns' );

                    echo '</label></p>';

                }

            }

    

                            // Render additional/custom fields (dynamic forms only).

                    if ( ! empty( $custom_fields ) ) {

                        foreach ( $custom_fields as $cf ) {

                            if ( ! is_array( $cf ) ) {

                                continue;

                            }

                            $enabled = isset( $cf['enabled'] ) ? (string) $cf['enabled'] : 'yes';

                            if ( 'no' === $enabled ) {

                                continue;

                            }

                            $key      = isset( $cf['key'] ) ? sanitize_key( (string) $cf['key'] ) : '';

                            $type     = isset( $cf['type'] ) ? (string) $cf['type'] : 'text';

                            $label    = isset( $cf['label'] ) ? (string) $cf['label'] : '';

                            $ph       = isset( $cf['placeholder'] ) ? (string) $cf['placeholder'] : '';

                            $required = ( isset( $cf['required'] ) && 'yes' === (string) $cf['required'] ) ? 'yes' : 'no';

    

                            if ( '' === $key ) {

                                continue;

                            }

    

                            $name = 'pmcpc_cf_' . $key;

    

                            if ( 'file' === $type ) {

                                $max_files = isset( $cf['max_files'] ) ? absint( $cf['max_files'] ) : 5;

                                if ( $max_files < 1 ) {

                                    $max_files = 1;

                                }

                                if ( $max_files > 10 ) {

                                    $max_files = 10;

                                }

                                echo '<p><label>' . esc_html( $label ? $label : __( 'File upload', 'product-mailer-campaigns' ) ) . '<br />';

                                echo '<input type="file" name="' . esc_attr( $name ) . '[]" multiple="multiple" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' accept=".jpg,.jpeg,.png,.webp,.pdf" />';

    										/* translators: %d: maximum number of files allowed. */

                                echo '<br /><span class="description">' . sprintf( esc_html__( 'You can upload up to %d files (JPG, PNG, WEBP, PDF).', 'product-mailer-campaigns' ), (int) $max_files ) . '</span>';

                                echo '</label></p>';

                                continue;

                            }

    

                            if ( 'textarea' === $type ) {

                                echo '<p><label>' . esc_html( $label ) . '<br />';

                                echo '<textarea name="' . esc_attr( $name ) . '" rows="4" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '"></textarea></label></p>';

                                continue;

                            }

    

                            // Default: text.

                            echo '<p><label>' . esc_html( $label ) . '<br />';

                            echo '<input type="text" name="' . esc_attr( $name ) . '" ' . ( 'yes' === $required ? 'required="required"' : '' ) . ' placeholder="' . esc_attr( $ph ) . '" /></label></p>';

                        }

                    }

    

    

    

    // Honeypot anti-spam field (hidden from humans).

            echo '<p class="pmcpc-hp-field" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;">';

            echo '<label>' . esc_html__( 'If you are human, leave this field empty.', 'product-mailer-campaigns' ) . '<br>';

            echo '<input type="text" name="pmcpc_hp" autocomplete="off"></label></p>';

    

            // Signed timing token to detect ultra-fast bot submissions (no JS required).

    		if ( self::timing_checks_enabled() ) {

    			echo '<input type="hidden" name="pmcpc_ft" value="' . esc_attr( self::make_timing_token( 'selling' ) ) . '">';

    		}

    

    wp_nonce_field( 'pmcpc_selling_form', 'pmcpc_selling_form_nonce' );

    

            echo '<p><button type="submit" class="button">' . esc_html( $atts['button_label'] ) . '</button></p>';

            echo '</form>';

    

            return ob_get_clean();

        }

    

    public static function render_email_preferences( $atts ) {

            if ( ! is_user_logged_in() ) {

                $login_url = wp_login_url( get_permalink() );

                return '<p>' . esc_html__( 'Please log in to manage your email settings.', 'product-mailer-campaigns' ) . '</p>'

                    . '<p><a href="' . esc_url( $login_url ) . '">' . esc_html__( 'Log in', 'product-mailer-campaigns' ) . '</a></p>';

            }

    

            if ( ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {

                return '<p>' . esc_html__( 'Email subscription system is not available.', 'product-mailer-campaigns' ) . '</p>';

            }

    

            $user  = wp_get_current_user();

            $email = $user->user_email;

    

            $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $email );

            if ( ! $subscriber ) {

                return '<p>' . esc_html__( 'No email subscription found for your account email.', 'product-mailer-campaigns' ) . '</p>';

            }

    

            $status_label = '';

            switch ( $subscriber->status ) {

                case 'active':

                    $status_label = __( 'Active', 'product-mailer-campaigns' );

                    break;

                case 'pending':

                    $status_label = __( 'Pending confirmation', 'product-mailer-campaigns' );

                    break;

                case 'unsubscribed':

                    $status_label = __( 'Unsubscribed', 'product-mailer-campaigns' );

                    break;

                default:

                    $status_label = ucfirst( $subscriber->status );

                    break;

            }

    

            $messages = array();

    

    		$email_prefs_nonce = isset( $_POST['pmcpc_email_prefs_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_email_prefs_nonce'] ) ) : '';

    		if ( $email_prefs_nonce && wp_verify_nonce( $email_prefs_nonce, 'pmcpc_email_prefs' ) ) {

    

                // Change email address.

                if ( ! empty( $_POST['pmcpc_new_email'] ) ) {

                    $new_email = sanitize_email( wp_unslash( $_POST['pmcpc_new_email'] ) );

    

                    if ( ! is_email( $new_email ) ) {

                        $messages[] = '<div class="pmcpc-message pmcpc-error">' . esc_html__( 'Please enter a valid new email address.', 'product-mailer-campaigns' ) . '</div>';

                    } elseif ( email_exists( $new_email ) && $new_email !== $email ) {

                        $messages[] = '<div class="pmcpc-message pmcpc-error">' . esc_html__( 'That email is already in use on this site.', 'product-mailer-campaigns' ) . '</div>';

                    } else {

                        $result = wp_update_user(

                            array(

                                'ID'         => $user->ID,

                                'user_email' => $new_email,

                            )

                        );

    

                        if ( is_wp_error( $result ) ) {

                            $messages[] = '<div class="pmcpc-message pmcpc-error">' . esc_html__( 'Could not update your WordPress account email.', 'product-mailer-campaigns' ) . '</div>';

                        } else {

                            global $wpdb;

                            $table = $wpdb->prefix . 'pmcpc_subscribers';

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

                            $wpdb->update(

                                $table,

                                array( 'email' => $new_email ),

                                array( 'id' => $subscriber->id ),

                                array( '%s' ),

                                array( '%d' )

                            );

    

                            $email      = $new_email;

                            $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $email );

                            $messages[] = '<div class="pmcpc-message pmcpc-success">' . esc_html__( 'Your email address has been updated.', 'product-mailer-campaigns' ) . '</div>';

                        }

                    }

                }

    

                // Preferences & tags / lists.

                $master_subscribed     = ! empty( $_POST['pmcpc_master_subscribed'] );

                $wants_newsletter      = isset( $_POST['pmcpc_pref_newsletter'] ) && '1' === $_POST['pmcpc_pref_newsletter'];

                $wants_product_updates = isset( $_POST['pmcpc_pref_product_updates'] ) && '1' === $_POST['pmcpc_pref_product_updates'];

                $wants_tips            = isset( $_POST['pmcpc_pref_tips'] ) && '1' === $_POST['pmcpc_pref_tips'];

    

                $new_tags = array();

                if ( $wants_newsletter ) {

                    $new_tags[] = 'newsletter';

                }

                if ( $wants_product_updates ) {

                    $new_tags[] = 'product-updates';

                }

                if ( $wants_tips ) {

                    $new_tags[] = 'tips';

                }

    

                // Preserve any non-interest tags (source / lifecycle) and add the email-prefs source tag.

                $all_existing_tags = array();

                if ( method_exists( 'PMCPC_Subscriber_Manager', 'get_tags_for_subscriber' ) ) {

                    $all_existing_tags = PMCPC_Subscriber_Manager::get_tags_for_subscriber( $subscriber->id );

                    if ( ! is_array( $all_existing_tags ) ) {

                        $all_existing_tags = array();

                    }

                }

    

                $interest_catalog   = array( 'newsletter', 'product-updates', 'tips' );

                $non_interest_tags  = array();

    

                foreach ( $all_existing_tags as $tag ) {

                    if ( ! in_array( $tag, $interest_catalog, true ) ) {

                        $non_interest_tags[] = $tag;

                    }

                }

    

                if ( ! in_array( 'email-prefs', $non_interest_tags, true ) ) {

                    $non_interest_tags[] = 'email-prefs';

                }

    

                $merged_tags = array_merge( $non_interest_tags, $new_tags );

                $merged_tags = array_unique( $merged_tags );

    

                if ( method_exists( 'PMCPC_Subscriber_Manager', 'set_tags_for_subscriber' ) ) {

                    PMCPC_Subscriber_Manager::set_tags_for_subscriber( $subscriber->id, $merged_tags );

                }

    

                if ( $master_subscribed ) {

                    PMCPC_Subscriber_Manager::update_status( $subscriber->id, 'active' );

                } else {

                    PMCPC_Subscriber_Manager::update_status( $subscriber->id, 'unsubscribed' );

                }

    

    $allowed_freq = array( 'immediate', 'weekly', 'monthly' );

                $freq         = isset( $_POST['pmcpc_pref_frequency'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_pref_frequency'] ) ) : 'immediate';

                if ( ! in_array( $freq, $allowed_freq, true ) ) {

                    $freq = 'immediate';

                }

                update_user_meta( $user->ID, 'pmcpc_email_frequency', $freq );

    

                $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $email );

                $messages[] = '<div class="pmcpc-message pmcpc-success">' . esc_html__( 'Your email preferences have been updated.', 'product-mailer-campaigns' ) . '</div>';

            }

    

            $current_tags = PMCPC_Subscriber_Manager::get_tags_for_subscriber( $subscriber->id );

            $has_news     = in_array( 'newsletter', $current_tags, true );

            $has_updates  = in_array( 'product-updates', $current_tags, true );

            $has_tips     = in_array( 'tips', $current_tags, true );

    

            $master_subscribed = ( 'active' === $subscriber->status );

    

            $current_freq = get_user_meta( $user->ID, 'pmcpc_email_frequency', true );

            if ( ! $current_freq ) {

                $current_freq = 'immediate';

            }

    

            ob_start();

            self::output_frontend_form_assets_once();

    

            foreach ( $messages as $msg ) {

                echo wp_kses_post( $msg );

            }

    

            echo '<form method="post" class="pmcpc-email-preferences-form">';

            wp_nonce_field( 'pmcpc_email_prefs', 'pmcpc_email_prefs_nonce' );

    

            echo '<h3>' . esc_html__( 'Email address', 'product-mailer-campaigns' ) . '</h3>';

            echo '<p><strong>' . esc_html( $email ) . '</strong></p>';

            echo '<p>' . esc_html__( 'Subscription status:', 'product-mailer-campaigns' ) . ' <strong>' . esc_html( $status_label ) . '</strong></p>';

            if ( 'pending' === $subscriber->status ) {

                echo '<p class="description">' . esc_html__( 'Your subscription is pending confirmation. You can activate it by confirming via email or by saving your preferences below.', 'product-mailer-campaigns' ) . '</p>';

            }

            echo '<p><label><input type="checkbox" name="pmcpc_master_subscribed" value="1" ' . checked( $master_subscribed, true, false ) . ' /> ' . esc_html__( 'I want to receive marketing and update emails.', 'product-mailer-campaigns' ) . '</label></p>';

            echo '<p><label>' . esc_html__( 'Change email address (optional)', 'product-mailer-campaigns' ) . '<br />';

            echo '<input type="email" name="pmcpc_new_email" value="" /></label></p>';

    

            echo '<h3>' . esc_html__( 'Email types', 'product-mailer-campaigns' ) . '</h3>';

    

            echo '<p><label><input type="checkbox" name="pmcpc_pref_newsletter" value="1" ' . checked( $has_news, true, false ) . ' /> ' .

                esc_html__( 'General newsletter', 'product-mailer-campaigns' ) . '</label></p>';

    

            echo '<p><label><input type="checkbox" name="pmcpc_pref_product_updates" value="1" ' . checked( $has_updates, true, false ) . ' /> ' .

                esc_html__( 'Product updates & releases', 'product-mailer-campaigns' ) . '</label></p>';

    

            echo '<p><label><input type="checkbox" name="pmcpc_pref_tips" value="1" ' . checked( $has_tips, true, false ) . ' /> ' .

                esc_html__( 'Tips, tutorials & content', 'product-mailer-campaigns' ) . '</label></p>';

    

            echo '<h3>' . esc_html__( 'Email frequency', 'product-mailer-campaigns' ) . '</h3>';

    

            $freq_options = array(

                'immediate' => __( 'Every time (default)', 'product-mailer-campaigns' ),

                'weekly'    => __( 'Weekly summary', 'product-mailer-campaigns' ),

                'monthly'   => __( 'Monthly summary', 'product-mailer-campaigns' ),

            );

    

            echo '<p>';

            foreach ( $freq_options as $value => $label ) {

                echo '<label style="display:block;"><input type="radio" name="pmcpc_pref_frequency" value="' . esc_attr( $value ) . '" ' . checked( $current_freq, $value, false ) . ' /> ' . esc_html( $label ) . '</label>';

            }

            echo '</p>';

    

            echo '<p><button type="submit">' . esc_html__( 'Save email preferences', 'product-mailer-campaigns' ) . '</button></p>';

    

            echo '</form>';

    

            global $wpdb;

            $queue_table     = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

            $events_table    = esc_sql( $wpdb->prefix . 'pmcpc_email_events' );

            $campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

    

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

    		$history = $wpdb->get_results(

    			$wpdb->prepare(

    				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names are plugin tables derived from $wpdb->prefix.

    				"SELECT q.id, q.subject, q.status, q.scheduled_at,

    						MAX(e.created_at) AS sent_at,

    						c.name AS campaign_name

    				 FROM $queue_table q

    				 LEFT JOIN $events_table e ON e.queue_id = q.id AND e.event_type = 'sent'

    				 LEFT JOIN $campaigns_table c ON c.id = q.campaign_id

    				 WHERE q.subscriber_id = %d

    				 GROUP BY q.id

    				 ORDER BY q.created_at DESC

    				 LIMIT 10",

    				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

    				$subscriber->id

    			)

    		);

    

            if ( $history ) {

                echo '<h3>' . esc_html__( 'Recent emails', 'product-mailer-campaigns' ) . '</h3>';

                echo '<table class="pmcpc-email-history">';

                echo '<thead><tr>';

                echo '<th>' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';

                echo '<th>' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</th>';

                echo '<th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';

                echo '<th>' . esc_html__( 'Sent at', 'product-mailer-campaigns' ) . '</th>';

                echo '</tr></thead><tbody>';

    

                foreach ( $history as $row ) {

                    $sent_at = $row->sent_at ? $row->sent_at : $row->scheduled_at;

                    echo '<tr>';

                    echo '<td>' . esc_html( $row->campaign_name ) . '</td>';

                    echo '<td>' . esc_html( $row->subject ) . '</td>';

                    echo '<td>' . esc_html( $row->status ) . '</td>';

                    echo '<td>' . esc_html( $sent_at ) . '</td>';

                    echo '</tr>';

                }

    

                echo '</tbody></table>';

            }

    

            return ob_get_clean();

        }

    

    

        

        /**

         * Dynamic form renderer that uses stored PMCPC_Forms definitions.

         *

         * Usage: [pmcpc_form id="1"]

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

    /**

         * Dynamic form renderer that uses stored PMCPC_Forms definitions.

         *

         * Usage: [pmcpc_form id="1"]

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

        public static function render_dynamic_form( $atts ) {

            if ( ! class_exists( 'PMCPC_Forms' ) ) {

                return '';

            }

    

            $atts = shortcode_atts(

                array(

                    'id' => 0,

                ),

                $atts,

                'pmcpc_form'

            );

    

            $form_id = absint( $atts['id'] );

            if ( ! $form_id ) {

                return '';

            }

    

            $form = PMCPC_Forms::get_form( $form_id );

            if ( ! $form ) {

                return '';

            }

    

            $type     = isset( $form['type'] ) ? $form['type'] : 'contact';

            $title    = isset( $form['title'] ) ? $form['title'] : '';

            $settings = ( isset( $form['settings'] ) && is_array( $form['settings'] ) )

                ? $form['settings']

                : ( class_exists( 'PMCPC_Forms' ) ? PMCPC_Forms::default_settings( $type ) : array() );

    

            // Render the appropriate base form HTML first.

            if ( 'selling' === $type ) {

                $form_html = self::render_selling_form(

                    array(

                        'title'        => $title,

                        'show_optin'   => isset( $settings['show_optin'] ) ? $settings['show_optin'] : 'no',

                        'button_label' => isset( $settings['button_label'] ) ? $settings['button_label'] : __( 'Send selling enquiry', 'product-mailer-campaigns' ),

                        'fields'        => isset( $settings['fields'] ) ? $settings['fields'] : null,

                        'custom_fields' => isset( $settings['custom_fields'] ) ? $settings['custom_fields'] : null,

                    )

                );

            } elseif ( 'subscribe' === $type ) {

                $form_html = self::render_subscribe_form(

                    array(

                        'title'        => $title,

                        'button_label' => isset( $settings['button_label'] ) ? $settings['button_label'] : __( 'Subscribe', 'product-mailer-campaigns' ),

                        'fields'        => isset( $settings['fields'] ) ? $settings['fields'] : null,

                        'custom_fields' => isset( $settings['custom_fields'] ) ? $settings['custom_fields'] : null,

                    )

                );

            } else {

                $show_subject = isset( $settings['show_subject'] ) ? $settings['show_subject'] : 'yes';

                $show_optin   = isset( $settings['show_optin'] ) ? $settings['show_optin'] : 'yes';

                if ( in_array( $type, array( 'review', 'product_review' ), true ) ) {

                    $show_subject = 'no';

                    $show_optin   = 'no';

                }

                $form_html = self::render_contact_form(

                    array(

                        'title'         => $title,

                        'show_subject'  => $show_subject,

                        'show_optin'    => $show_optin,

                        'button_label'  => isset( $settings['button_label'] ) ? $settings['button_label'] : ( in_array( $type, array( 'review', 'product_review' ), true ) ? __( 'Submit review', 'product-mailer-campaigns' ) : __( 'Send message', 'product-mailer-campaigns' ) ),

                        'fields'        => isset( $settings['fields'] ) ? $settings['fields'] : null,

                        'custom_fields' => isset( $settings['custom_fields'] ) ? $settings['custom_fields'] : null,

                        'review_mode'   => in_array( $type, array( 'review', 'product_review' ), true ) ? 'yes' : 'no',

                        'product_review'=> ( 'product_review' === $type ) ? 'yes' : 'no',

                    )

                );

            }

    

            // Inject a hidden dynamic form ID so downstream handlers can tag the subscriber

            // with the originating form (form-<ID>) regardless of the form type.

            if ( $form_html ) {

                $hidden = '<input type="hidden" name="pmcpc_form_id" value="' . esc_attr( $form_id ) . '" />';

                $form_html = preg_replace(

                    '/(<form[^>]*class="pmcpc-(?:subscribe|contact|selling)-form"[^>]*>)/',

                    '$1' . $hidden,

                    $form_html,

                    1

                );

            }

    

            if ( $form_html ) {

                $form_html = '<div id="pmcpc-form-' . esc_attr( $form_id ) . '">' . $form_html . '</div>';

            }

    

            return $form_html;

        }

    

        /**

         * Front-end helpers for PMCPC forms.

         *

         * - Prevents double submits (disables form on submit).

         * - If a success flash message is present, visually disables the form to avoid accidental re-submission.

         */

    /**

         * Front-end helpers for PMCPC forms.

         *

         * - Prevents double submits (disables form on submit).

         * - If a success flash message is present, visually disables the form to avoid accidental re-submission.

         */

        /**
         * Return the front-end form assets as an HTML string.
         *
         * This is mainly for form-like shortcodes rendered outside this trait.
         *
         * @return string
         */
        public static function render_frontend_form_assets() {
            ob_start();
            self::output_frontend_form_assets_once();
            return ob_get_clean();
        }

        /**
         * Read the global form style settings.
         *
         * @return array
         */
        private static function get_form_style_settings() {
            $settings = array(
                'preset'       => 'theme',
                'accent'       => '#2271b1',
                'button_shape' => 'soft',
                'max_width'    => 640,
            );

            if ( class_exists( 'PMCPC_Settings' ) ) {
                $settings['preset']       = sanitize_key( (string) PMCPC_Settings::get( 'form_style_preset', 'theme' ) );
                $settings['accent']       = sanitize_hex_color( (string) PMCPC_Settings::get( 'form_accent_color', '#2271b1' ) );
                $settings['button_shape'] = sanitize_key( (string) PMCPC_Settings::get( 'form_button_shape', 'soft' ) );
                $settings['max_width']    = absint( PMCPC_Settings::get( 'form_max_width', 640 ) );
            }

            if ( ! in_array( $settings['preset'], array( 'theme', 'clean', 'boxed', 'elegant' ), true ) ) {
                $settings['preset'] = 'theme';
            }
            if ( ! $settings['accent'] ) {
                $settings['accent'] = '#2271b1';
            }
            if ( ! in_array( $settings['button_shape'], array( 'square', 'soft', 'pill' ), true ) ) {
                $settings['button_shape'] = 'soft';
            }
            $settings['max_width'] = max( 0, min( 1600, (int) $settings['max_width'] ) );

            return $settings;
        }

        /**
         * Build optional front-end styling for FlowPress forms.
         *
         * @return string
         */
        private static function get_frontend_form_style_css() {
            $settings = self::get_form_style_settings();

            if ( 'theme' === $settings['preset'] ) {
                return '';
            }

            $accent        = $settings['accent'];
            $max_width     = $settings['max_width'] > 0 ? ( (int) $settings['max_width'] . 'px' ) : 'none';
            $button_radius = '8px';
            if ( 'square' === $settings['button_shape'] ) {
                $button_radius = '2px';
            } elseif ( 'pill' === $settings['button_shape'] ) {
                $button_radius = '999px';
            }

            $form_radius  = '12px';
            $input_radius = ( 'square' === $settings['button_shape'] ) ? '3px' : '8px';
            $card_style   = '';

            if ( 'boxed' === $settings['preset'] ) {
                $card_style = 'background:#fff;border:1px solid rgba(0,0,0,.12);border-radius:' . $form_radius . ';padding:24px;box-shadow:0 10px 30px rgba(0,0,0,.06);';
            } elseif ( 'elegant' === $settings['preset'] ) {
                $form_radius = '16px';
                $card_style  = 'background:linear-gradient(180deg,#fff,rgba(255,255,255,.96));border:1px solid rgba(0,0,0,.10);border-radius:' . $form_radius . ';padding:28px;box-shadow:0 16px 45px rgba(0,0,0,.08);';
            }

            $forms = ':where(form.pmcpc-subscribe-form,form.pmcpc-contact-form,form.pmcpc-selling-form,form.pmcpc-dynamic-form,form.pmcpc-email-preferences-form,form.pmcpc-preferences-center-form)';

            $css  = "\n";
            $css .= $forms . '{box-sizing:border-box;max-width:' . $max_width . ';margin:0 0 22px 0;' . $card_style . "}\n";
            $css .= $forms . ' *{box-sizing:border-box;}' . "\n";
            $css .= $forms . ' h2,' . $forms . ' h3{margin-top:0;margin-bottom:14px;line-height:1.25;}' . "\n";
            $css .= $forms . ' p{margin:0 0 16px 0;}' . "\n";
            $css .= $forms . ' label{display:block;font-weight:600;margin-bottom:6px;}' . "\n";
            $css .= $forms . ' input[type="text"],' . $forms . ' input[type="email"],' . $forms . ' input[type="url"],' . $forms . ' input[type="tel"],' . $forms . ' input[type="number"],' . $forms . ' select,' . $forms . ' textarea{width:100%;max-width:100%;border:1px solid rgba(0,0,0,.22);border-radius:' . $input_radius . ';padding:11px 12px;background:#fff;color:inherit;line-height:1.4;}' . "\n";
            $css .= $forms . ' textarea{min-height:130px;resize:vertical;}' . "\n";
            $css .= $forms . ' input[type="checkbox"],' . $forms . ' input[type="radio"]{width:auto;max-width:none;margin-right:7px;vertical-align:middle;}' . "\n";
            $css .= $forms . ' input:focus,' . $forms . ' select:focus,' . $forms . ' textarea:focus{outline:2px solid ' . $accent . ';outline-offset:1px;border-color:' . $accent . ';}' . "\n";
            $css .= $forms . ' button[type="submit"],' . $forms . ' input[type="submit"],' . $forms . ' .pmcpc-submit-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid ' . $accent . ';border-radius:' . $button_radius . ';background:' . $accent . ';color:#fff;text-decoration:none;font-weight:600;padding:10px 18px;line-height:1.4;cursor:pointer;transition:filter .15s ease,transform .15s ease;}' . "\n";
            $css .= $forms . ' button[type="submit"]:hover,' . $forms . ' input[type="submit"]:hover,' . $forms . ' .pmcpc-submit-button:hover{filter:brightness(.94);}' . "\n";
            $css .= $forms . ' button[type="submit"]:active,' . $forms . ' input[type="submit"]:active{transform:translateY(1px);}' . "\n";
            $css .= '.pmcpc-action-link{border-color:' . $accent . ';color:' . $accent . ';border-radius:' . $button_radius . ';}' . "\n";
            $css .= '.pmcpc-opt-in-shortcode{max-width:' . $max_width . ';}' . "\n";

            if ( 'elegant' === $settings['preset'] ) {
                $css .= $forms . '{font-size:16px;}' . "\n";
                $css .= $forms . ' label{letter-spacing:.01em;}' . "\n";
                $css .= $forms . ' input[type="text"],' . $forms . ' input[type="email"],' . $forms . ' input[type="url"],' . $forms . ' input[type="tel"],' . $forms . ' input[type="number"],' . $forms . ' select,' . $forms . ' textarea{padding:13px 14px;}' . "\n";
            }

            return $css;
        }

        private static function output_frontend_form_assets_once() {

            static $done = false;

            if ( $done ) {

                return;

            }

            $done = true;

    

            $form_style_css = self::get_frontend_form_style_css();

            echo '<style>

    .pmcpc-message{padding:12px 14px;border-left:4px solid #007cba;background:#fff;margin:12px 0 14px 0;}

    .pmcpc-message-title{font-weight:600;margin:0 0 6px 0;}

    .pmcpc-message-body p{margin:0 0 8px 0;}

    .pmcpc-message-body p:last-child{margin-bottom:0;}

    .pmcpc-success{border-left-color:#00a32a;}

    .pmcpc-error{border-left-color:#d63638;}

    .pmcpc-after-success{margin:0 0 14px 0;}

    .pmcpc-action-link{display:inline-block;padding:8px 12px;border:1px solid #2271b1;border-radius:3px;text-decoration:none;}

    .pmcpc-action-link:hover{background:rgba(34,113,177,0.08);}

    .pmcpc-form-disabled{opacity:0.55;filter:grayscale(0.15);}

    .pmcpc-form-disabled *{pointer-events:none;}

    ' . $form_style_css . '

    </style>';

    

            ?>

    <script>

    (function(){

      // Important: don't disable all inputs on submit, because disabled controls are NOT submitted.

      // We only disable submit buttons and make text inputs readonly to prevent edits/double submits.

      function lockFormForSubmit(form){

        if(!form) return;

        form.classList.add("pmcpc-form-disabled");

        var ro=form.querySelectorAll('input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=checkbox]):not([type=radio]), textarea');

        for(var i=0;i<ro.length;i++){

          ro[i].setAttribute('readonly','readonly');

        }

        var btns=form.querySelectorAll('button[type=submit], input[type=submit]');

        for(var j=0;j<btns.length;j++){

          btns[j].setAttribute('disabled','disabled');

        }

      }

    

      function disableFormAfterSuccess(form){

        if(!form) return;

        // After a success state is displayed, we can safely disable everything.

        var els=form.querySelectorAll("input,select,textarea,button");

        for(var i=0;i<els.length;i++){

          els[i].setAttribute("disabled","disabled");

        }

      }

      function onReady(fn){

        if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",fn);} else {fn();}

      }

      onReady(function(){

        var forms=document.querySelectorAll("form.pmcpc-subscribe-form, form.pmcpc-contact-form, form.pmcpc-selling-form, form.pmcpc-dynamic-form, form.pmcpc-email-preferences-form, form.pmcpc-preferences-center-form");

        for(var i=0;i<forms.length;i++){

          (function(form){

            if(form.classList.contains("pmcpc-form-disabled")){

              disableFormAfterSuccess(form);

              return;

            }

            form.addEventListener("submit",function(e){

              if(form.dataset.pmcpcSubmitting==="1"){

                e.preventDefault();

                return false;

              }

              form.dataset.pmcpcSubmitting="1";

              lockFormForSubmit(form);

            }, true);

          })(forms[i]);

        }

      });

    })();

    </script>

    <?php

        }
}
