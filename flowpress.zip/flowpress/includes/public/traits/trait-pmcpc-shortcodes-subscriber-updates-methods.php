<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Shortcodes_Subscriber_Updates_Methods {
    

    

    

    

        protected static function pmcpc_get_unlocked_subscriber() {

            static $resolved = null;

            static $loaded = false;

            if ( $loaded ) {

                return $resolved;

            }

            $loaded = true;

            $resolved = null;

    

            if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {

                $resolved = array( 'subscriber_id' => 0, 'email' => '', 'tags' => array(), 'is_admin' => true );

                return $resolved;

            }

    

            $token = '';

            if ( isset( $_COOKIE['pmcpc_subscriber_access'] ) ) {

                $token = sanitize_text_field( (string) wp_unslash( $_COOKIE['pmcpc_subscriber_access'] ) );

            }

            if ( isset( $_GET['pmcpc_subscriber_access'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended

                $token = sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_subscriber_access'] ) );

            }

            if ( '' === $token || false === strpos( $token, '|' ) ) {

                return null;

            }

            list( $subscriber_id_raw, $exp_raw, $sig ) = array_pad( explode( '|', $token, 3 ), 3, '' );

            $subscriber_id = absint( $subscriber_id_raw );

            $expires = absint( $exp_raw );

            if ( ! $subscriber_id || ! $expires || '' === $sig || $expires < time() ) {

                return null;

            }

            $expected = hash_hmac( 'sha256', $subscriber_id . '|' . $expires, wp_salt( 'auth' ) );

            if ( ! hash_equals( $expected, $sig ) ) {

                return null;

            }

    

            global $wpdb;

            $subs_table = $wpdb->prefix . 'pmcpc_subscribers';

            $row = $wpdb->get_row( $wpdb->prepare( "SELECT id, email, status FROM {$subs_table} WHERE id = %d", $subscriber_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

            if ( ! $row || empty( $row->id ) || ( isset( $row->status ) && 'active' !== (string) $row->status ) ) {

                return null;

            }

            $tags = array();

            if ( class_exists( 'PMCPC_Subscriber_Manager' ) ) {

                $tags = PMCPC_Subscriber_Manager::get_tags_for_subscriber( (int) $row->id );

                if ( ! is_array( $tags ) ) {

                    $tags = array();

                }

            }

            $resolved = array(

                'subscriber_id' => (int) $row->id,

                'email'         => sanitize_email( (string) $row->email ),

                'tags'          => array_map( 'sanitize_text_field', $tags ),

                'is_admin'      => false,

            );

            return $resolved;

        }

    

        protected static function pmcpc_is_update_expired( $post_id ) {

            $expires_at = (string) get_post_meta( $post_id, '_pmcpc_expires_at', true );

            if ( '' === $expires_at ) {

                return false;

            }

            $ts = strtotime( $expires_at );

            if ( ! $ts ) {

                return false;

            }

            return $ts < current_time( 'timestamp' );

        }

    

        public static function pmcpc_can_view_subscriber_update( $post_id ) {

            $visibility = sanitize_key( (string) get_post_meta( $post_id, '_pmcpc_visibility', true ) );

            if ( '' === $visibility ) {

                $visibility = 'public';

            }

            $context = self::pmcpc_get_unlocked_subscriber();

            $allowed = false;

            $reason = '';

    

            if ( self::pmcpc_is_update_expired( $post_id ) ) {

                return array( 'allowed' => false, 'reason' => 'expired', 'context' => $context, 'visibility' => $visibility );

            }

    

            if ( ! empty( $context['is_admin'] ) ) {

                return array( 'allowed' => true, 'reason' => 'admin', 'context' => $context, 'visibility' => $visibility );

            }

    

            switch ( $visibility ) {

                case 'private':

                    $allowed = false;

                    $reason = 'private';

                    break;

                case 'subscribers':

                    $allowed = ! empty( $context['subscriber_id'] );

                    $reason = $allowed ? 'subscriber' : 'subscriber_required';

                    break;

                case 'segment':

                    $segment = sanitize_text_field( (string) get_post_meta( $post_id, '_pmcpc_required_segment', true ) );

                    if ( ! empty( $context['subscriber_id'] ) && '' !== $segment ) {

                        $allowed = in_array( $segment, (array) $context['tags'], true );

                    }

                    $reason = $allowed ? 'segment' : 'segment_required';

                    break;

                case 'public':

                default:

                    $allowed = true;

                    $reason = 'public';

                    break;

            }

    

            return array( 'allowed' => $allowed, 'reason' => $reason, 'context' => $context, 'visibility' => $visibility );

        }

    

        public static function maybe_handle_subscriber_update_unlock() {

            if ( 'POST' !== strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) ) {

                return;

            }

            if ( empty( $_POST['pmcpc_subscriber_unlock_nonce'] ) || empty( $_POST['pmcpc_subscriber_unlock_email'] ) ) {

                return;

            }

            $nonce = sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_subscriber_unlock_nonce'] ) );

            if ( ! wp_verify_nonce( $nonce, 'pmcpc_subscriber_unlock' ) ) {

                return;

            }

            $email = sanitize_email( (string) wp_unslash( $_POST['pmcpc_subscriber_unlock_email'] ) );

            $return_to = isset( $_POST['pmcpc_subscriber_unlock_return'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_subscriber_unlock_return'] ) ) : '';

            if ( ! $email ) {

                self::flash_redirect( '<div class="notice notice-error"><p>' . esc_html__( 'Please enter a valid subscriber email address.', 'product-mailer-campaigns' ) . '</p></div>', '', $return_to );

            }

            global $wpdb;

            $subs_table = $wpdb->prefix . 'pmcpc_subscribers';

            $row = $wpdb->get_row( $wpdb->prepare( "SELECT id, email, status FROM {$subs_table} WHERE email = %s", $email ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

            if ( ! $row || empty( $row->id ) || ( isset( $row->status ) && 'active' !== (string) $row->status ) ) {

                self::flash_redirect( '<div class="notice notice-error"><p>' . esc_html__( 'We could not verify that email as an active subscriber.', 'product-mailer-campaigns' ) . '</p></div>', '', $return_to );

            }

            $expires = time() + ( 30 * DAY_IN_SECONDS );

            $sig = hash_hmac( 'sha256', ((int) $row->id) . '|' . $expires, wp_salt( 'auth' ) );

            $token = (int) $row->id . '|' . $expires . '|' . $sig;

            setcookie( 'pmcpc_subscriber_access', $token, $expires, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );

            $_COOKIE['pmcpc_subscriber_access'] = $token;

            $post_id = 0;

            if ( ! empty( $return_to ) ) {

                $post_id = url_to_postid( $return_to );

            }

            if ( $post_id && function_exists( 'pmcpc_record_subscriber_update_event' ) ) {

                $subscriber_segments = array();

                if ( class_exists( 'PMCPC_Subscriber_Manager' ) ) {

                    $subscriber_segments = PMCPC_Subscriber_Manager::get_tags_for_subscriber( (int) $row->id );

                    if ( ! is_array( $subscriber_segments ) ) {

                        $subscriber_segments = array();

                    }

                }

                pmcpc_record_subscriber_update_event(

                    $post_id,

                    'unlock',

                    array(

                        'segment' => implode( ', ', array_map( 'sanitize_text_field', $subscriber_segments ) ),

                    )

                );

            }

            self::flash_redirect( '<div class="notice notice-success"><p>' . esc_html__( 'Access unlocked for this browser.', 'product-mailer-campaigns' ) . '</p></div>', '', $return_to );

        }

    

        public static function pmcpc_get_tracked_cta_url( $post_id, $url ) {

            $url = esc_url_raw( (string) $url );

            if ( '' === $url ) {

                return '';

            }

            return add_query_arg(

                array(

                    'pmcpc_update_cta' => absint( $post_id ),

                    'pmcpc_target'     => rawurlencode( $url ),

                ),

                home_url( '/' )

            );

        }

    

        public static function maybe_handle_subscriber_update_cta() {

            if ( empty( $_GET['pmcpc_update_cta'] ) || empty( $_GET['pmcpc_target'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended

                return;

            }

            $post_id = absint( wp_unslash( $_GET['pmcpc_update_cta'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

            $target = rawurldecode( (string) wp_unslash( $_GET['pmcpc_target'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

            $target = esc_url_raw( $target );

            if ( ! $post_id || '' === $target ) {

                return;

            }

            $count = (int) get_post_meta( $post_id, '_pmcpc_cta_click_count', true );

            update_post_meta( $post_id, '_pmcpc_cta_click_count', $count + 1 );

            if ( function_exists( 'pmcpc_record_subscriber_update_event' ) ) {

                pmcpc_record_subscriber_update_event( $post_id, 'cta_click' );

            }

            wp_safe_redirect( $target );

            exit;

        }

    

        public static function pmcpc_render_update_unlock_form( $post_id, $reason = 'subscriber_required' ) {

            $message = __( 'This update is reserved for subscribers.', 'product-mailer-campaigns' );

            if ( 'segment_required' === $reason ) {

                $segment = sanitize_text_field( (string) get_post_meta( $post_id, '_pmcpc_required_segment', true ) );

                if ( '' !== $segment ) {

                    $message = sprintf( __( 'This update is reserved for subscribers in the %s segment.', 'product-mailer-campaigns' ), $segment );

                }

            } elseif ( 'private' === $reason ) {

                $message = __( 'This update is private and only visible to administrators.', 'product-mailer-campaigns' );

            }

            ob_start();

            echo '<div class="pmcpc-update-gate" style="margin:28px 0 0;padding:24px;border:1px solid #e5e7eb;border-radius:24px;background:#fffaf3;">';

            echo '<h3 style="margin:0 0 10px;font-size:24px;line-height:1.2;">' . esc_html__( 'Subscriber access', 'product-mailer-campaigns' ) . '</h3>';

            echo '<p style="margin:0 0 16px;color:#4b5563;">' . esc_html( $message ) . '</p>';

            echo '<form method="post" action="" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">';

            wp_nonce_field( 'pmcpc_subscriber_unlock', 'pmcpc_subscriber_unlock_nonce' );

            echo '<input type="hidden" name="pmcpc_subscriber_unlock_return" value="' . esc_attr( get_permalink( $post_id ) ) . '">';

            echo '<p style="margin:0;flex:1 1 260px;"><label for="pmcpc-subscriber-unlock-email-' . esc_attr( (string) $post_id ) . '"><strong>' . esc_html__( 'Subscriber email address', 'product-mailer-campaigns' ) . '</strong></label><br>';

            echo '<input id="pmcpc-subscriber-unlock-email-' . esc_attr( (string) $post_id ) . '" type="email" name="pmcpc_subscriber_unlock_email" required style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid #d1d5db;" placeholder="' . esc_attr__( 'you@example.com', 'product-mailer-campaigns' ) . '"></p>';

            echo '<p style="margin:0;"><button type="submit" style="padding:12px 18px;border-radius:999px;background:#111827;color:#fff;border:0;font-weight:600;cursor:pointer;">' . esc_html__( 'Unlock update', 'product-mailer-campaigns' ) . '</button></p>';

            echo '</form></div>';

            return ob_get_clean();

        }

    

        /**

         * Render Subscriber Updates feed.

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

    /**

         * Render Subscriber Updates feed.

         *

         * @param array $atts Shortcode attributes.

         * @return string

         */

        public static function render_subscriber_updates( $atts = array() ) {

            static $selected_page_rendered = false;

    

            $global_settings = get_option( 'pmcpc_sub_updates_settings', array() );

            if ( ! is_array( $global_settings ) ) {

                $global_settings = array();

            }

            $global_settings = wp_parse_args(

                $global_settings,

                array(

                    'enabled'              => 1,

                    'posts_per_page'       => 10,

                    'hide_expired_in_feed' => 0,

                    'show_date'            => 1,

                    'show_topic_filter'    => 1,

                    'intro_text'           => '',

                    'feed_order'           => 'featured_desc',

                    'feed_columns'         => 2,

                    'feed_image_ratio'     => 'landscape',

                    'feed_excerpt_length'  => 28,

                    'show_images'          => 1,

                )

            );

    

            $selected_page_id = 0;

            if ( class_exists( 'PMCPC_Subscriber_Updates_Settings' ) ) {

                $selected_page_id = isset( $global_settings['page_id'] ) ? absint( $global_settings['page_id'] ) : 0;

                if ( $selected_page_id <= 0 ) {

                    $selected_page_id = (int) get_option( PMCPC_Subscriber_Updates_Settings::PAGE_OPTION_KEY, 0 );

                }

            }

    

            $atts = shortcode_atts(

                array(

                    'posts_per_page' => ! empty( $global_settings['posts_per_page'] ) ? absint( $global_settings['posts_per_page'] ) : 10,

                    'show_date'      => isset( $global_settings['show_date'] ) ? (int) $global_settings['show_date'] : 1,

                    'show_filter'    => isset( $global_settings['show_topic_filter'] ) ? (int) $global_settings['show_topic_filter'] : 1,

                    'intro_text'     => isset( $global_settings['intro_text'] ) ? (string) $global_settings['intro_text'] : '',

                    'feed_order'     => isset( $global_settings['feed_order'] ) ? (string) $global_settings['feed_order'] : 'featured_desc',

                    'feed_columns'   => isset( $global_settings['feed_columns'] ) ? (int) $global_settings['feed_columns'] : 2,

                    'image_ratio'    => isset( $global_settings['feed_image_ratio'] ) ? (string) $global_settings['feed_image_ratio'] : 'landscape',

                    'excerpt_words'  => isset( $global_settings['feed_excerpt_length'] ) ? (int) $global_settings['feed_excerpt_length'] : 28,

                    'show_images'    => isset( $global_settings['show_images'] ) ? (int) $global_settings['show_images'] : 1,

                ),

                $atts,

                'pmcpc_sub_updates'

            );

    

            $is_selected_updates_page = $selected_page_id > 0 && get_queried_object_id() === $selected_page_id;

            if ( $is_selected_updates_page ) {

                if ( $selected_page_rendered ) {

                    return '';

                }

    

                $selected_page_rendered = true;

                $atts['posts_per_page'] = ! empty( $global_settings['posts_per_page'] ) ? absint( $global_settings['posts_per_page'] ) : 10;

                $atts['show_date']      = isset( $global_settings['show_date'] ) ? (int) $global_settings['show_date'] : 1;

                $atts['show_filter']    = isset( $global_settings['show_topic_filter'] ) ? (int) $global_settings['show_topic_filter'] : 1;

                $atts['intro_text']     = isset( $global_settings['intro_text'] ) ? (string) $global_settings['intro_text'] : '';

                // The dedicated updates page should always behave like a straightforward

                // public archive. Featured ordering can exclude older posts when legacy

                // featured meta is sparse, which is exactly the failure the user is seeing.

                $atts['feed_order']     = 'date_desc';

                $atts['feed_columns']   = isset( $global_settings['feed_columns'] ) ? (int) $global_settings['feed_columns'] : 2;

                $atts['image_ratio']    = isset( $global_settings['feed_image_ratio'] ) ? (string) $global_settings['feed_image_ratio'] : 'landscape';

                $atts['excerpt_words']  = isset( $global_settings['feed_excerpt_length'] ) ? (int) $global_settings['feed_excerpt_length'] : 28;

                $atts['show_images']    = isset( $global_settings['show_images'] ) ? (int) $global_settings['show_images'] : 1;

            }

    

            if ( array_key_exists( 'enabled', $global_settings ) && empty( $global_settings['enabled'] ) ) {

                return '<div class="pmcpc-subscriber-updates"><p>' . esc_html__( 'Website publishing is currently disabled.', 'product-mailer-campaigns' ) . '</p></div>';

            }

    

            $paged = max( 1, absint( get_query_var( 'paged' ) ), absint( get_query_var( 'page' ) ) );

            if ( isset( $_GET['pmcpc_updates_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended

                $paged = max( $paged, absint( wp_unslash( $_GET['pmcpc_updates_page'] ) ) );

            }

    

            $topic = '';

            if ( isset( $_GET['pmcpc_updates_topic'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended

                $topic = sanitize_title( (string) wp_unslash( $_GET['pmcpc_updates_topic'] ) );

            }

    

            $cache_key = 'pmcpc_sub_updates_' . md5( wp_json_encode( array( $atts, $paged, $topic, $global_settings, $selected_page_id, (int) $is_selected_updates_page, 'v4' ) ) );

            if ( ! $is_selected_updates_page ) {

                $cached = get_transient( $cache_key );

                if ( false !== $cached ) {

                    return (string) $cached;

                }

            }

    

            $feed_order = isset( $atts['feed_order'] ) ? sanitize_key( (string) $atts['feed_order'] ) : 'featured_desc';

            $query_args = array(

                'post_type'      => 'pmcpc_sub_update',

                'post_status'    => 'publish',

                'posts_per_page' => max( 1, absint( $atts['posts_per_page'] ) ),

                'paged'          => $paged,

            );

    

            if ( 'featured_desc' === $feed_order && ! $is_selected_updates_page ) {

                $query_args['meta_query'] = array(

                    'relation'        => 'OR',

                    'featured_clause' => array(

                        'key'     => '_pmcpc_is_featured',

                        'compare' => 'EXISTS',

                        'type'    => 'NUMERIC',

                    ),

                    array(

                        'key'     => '_pmcpc_is_featured',

                        'compare' => 'NOT EXISTS',

                    ),

                );

                $query_args['orderby'] = array(

                    'featured_clause' => 'DESC',

                    'date'            => 'DESC',

                );

            } elseif ( 'date_asc' === $feed_order ) {

                $query_args['orderby'] = 'date';

                $query_args['order']   = 'ASC';

            } else {

                $query_args['orderby'] = 'date';

                $query_args['order']   = 'DESC';

            }

    

            if ( ! empty( $global_settings['hide_expired_in_feed'] ) ) {

                $query_args['meta_query'] = array(

                    'relation' => 'AND',

                    $query_args['meta_query'],

                    array(

                        'relation' => 'OR',

                        array(

                            'key'     => '_pmcpc_expires_at',

                            'compare' => 'NOT EXISTS',

                        ),

                        array(

                            'key'     => '_pmcpc_expires_at',

                            'value'   => current_time( 'mysql' ),

                            'compare' => '>',

                            'type'    => 'DATETIME',

                        ),

                        array(

                            'key'     => '_pmcpc_expires_at',

                            'value'   => '',

                            'compare' => '=',

                        ),

                    ),

                );

            }

    

            if ( $topic ) {

                $query_args['tax_query'] = array(

                    array(

                        'taxonomy' => 'pmcpc_update_topic',

                        'field'    => 'slug',

                        'terms'    => $topic,

                    ),

                );

            }

    

            $topics = get_terms(

                array(

                    'taxonomy'   => 'pmcpc_update_topic',

                    'hide_empty' => true,

                )

            );

    

            $query = new WP_Query( $query_args );

    

            ob_start();

            echo '<div class="pmcpc-subscriber-updates" style="max-width:1120px;margin:0 auto 48px;">';

    

            if ( ! empty( $atts['intro_text'] ) ) {

                echo '<div style="margin:0 0 24px;padding:22px 24px;border:1px solid #ece7df;border-radius:24px;background:linear-gradient(180deg,#f8f5f0 0%,#ffffff 100%);">';

                echo '<p style="margin:0;font-size:16px;line-height:1.75;color:#4b5563;">' . esc_html( (string) $atts['intro_text'] ) . '</p>';

                echo '</div>';

            }

    

            if ( ! empty( $atts['show_filter'] ) && ! empty( $topics ) && ! is_wp_error( $topics ) ) {

                $form_action = get_permalink();

                if ( ! $form_action ) {

                    $form_action = home_url( '/' );

                }

                echo '<form method="get" action="' . esc_url( $form_action ) . '" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;margin:0 0 26px;padding:18px 20px;border:1px solid #ece7df;border-radius:20px;background:#fff;">';

                foreach ( $_GET as $key => $value ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended

                    if ( 'pmcpc_updates_topic' === $key || 'pmcpc_updates_page' === $key ) {

                        continue;

                    }

                    if ( is_scalar( $value ) ) {

                        echo '<input type="hidden" name="' . esc_attr( (string) $key ) . '" value="' . esc_attr( (string) wp_unslash( $value ) ) . '">';

                    }

                }

                echo '<p style="margin:0;"><label for="pmcpc_updates_topic"><strong>' . esc_html__( 'Filter by topic', 'product-mailer-campaigns' ) . '</strong></label><br>';

                echo '<select id="pmcpc_updates_topic" name="pmcpc_updates_topic" style="min-width:220px;padding:10px 12px;border-radius:12px;border:1px solid #d6d3d1;">';

                echo '<option value="">' . esc_html__( 'All topics', 'product-mailer-campaigns' ) . '</option>';

                foreach ( $topics as $term ) {

                    echo '<option value="' . esc_attr( $term->slug ) . '"' . selected( $topic, $term->slug, false ) . '>' . esc_html( $term->name ) . '</option>';

                }

                echo '</select></p>';

                echo '<p style="margin:0;"><button type="submit" style="padding:10px 18px;border-radius:999px;background:#111827;color:#fff;border:0;font-weight:600;cursor:pointer;">' . esc_html__( 'Apply', 'product-mailer-campaigns' ) . '</button></p>';

                if ( $topic ) {

                    echo '<p style="margin:0;"><a href="' . esc_url( remove_query_arg( array( 'pmcpc_updates_topic', 'pmcpc_updates_page' ) ) ) . '" style="display:inline-block;padding:9px 16px;border-radius:999px;border:1px solid #d0d5dd;text-decoration:none;color:#111827;">' . esc_html__( 'Clear', 'product-mailer-campaigns' ) . '</a></p>';

                }

                echo '</form>';

            }

    

            if ( $query->have_posts() ) {

                $featured_rendered = false;

                $feed_columns = max( 1, min( 3, absint( $atts['feed_columns'] ?? 2 ) ) );

                $min_width = 1 === $feed_columns ? 760 : ( 3 === $feed_columns ? 220 : 280 );

                $ratio = isset( $atts['image_ratio'] ) ? sanitize_key( (string) $atts['image_ratio'] ) : 'landscape';

                $excerpt_words = max( 10, min( 80, absint( $atts['excerpt_words'] ?? 28 ) ) );

                $show_images = ! empty( $atts['show_images'] );

                echo '<div style="display:grid;grid-template-columns:repeat(' . esc_attr( (string) $feed_columns ) . ',minmax(0,1fr));gap:24px;">';

                while ( $query->have_posts() ) {

                    $query->the_post();

                    $post_id = get_the_ID();

                    $permalink = get_permalink();

                    $is_featured = (bool) get_post_meta( $post_id, '_pmcpc_is_featured', true );

                    $terms = get_the_terms( $post_id, 'pmcpc_update_topic' );

                    $image = function_exists( 'pmcpc_get_subscriber_update_image_url' ) ? pmcpc_get_subscriber_update_image_url( $post_id ) : '';

                    $cta_url = esc_url( (string) get_post_meta( $post_id, '_pmcpc_cta_url', true ) );

                    $cta_label = sanitize_text_field( (string) get_post_meta( $post_id, '_pmcpc_cta_label', true ) );

                    $access = self::pmcpc_can_view_subscriber_update( $post_id );

                    $is_locked = ! empty( $access ) && empty( $access['allowed'] ) && in_array( $access['reason'], array( 'subscriber_required', 'segment_required' ), true );

                    $visibility = ! empty( $access['visibility'] ) ? (string) $access['visibility'] : 'public';

                    $grid_span = '';

                    $hero = false;

                    if ( $is_featured && ! $featured_rendered ) {

                        $grid_span = 'grid-column:1/-1;';

                        $hero = true;

                        $featured_rendered = true;

                    }

                    echo '<article style="' . esc_attr( $grid_span . 'border:1px solid #ece7df;border-radius:24px;background:#fff;overflow:hidden;box-shadow:0 12px 30px rgba(17,24,39,0.05);' ) . '">';

                    if ( $show_images && $image ) {

                        $img_height = 'landscape' === $ratio ? ( $hero ? '360px' : '220px' ) : ( 'square' === $ratio ? ( $hero ? '520px' : '320px' ) : ( $hero ? '620px' : '420px' ) );

                        echo '<a href="' . esc_url( $permalink ) . '" style="display:block;background:#f5f1ea;"><img src="' . esc_url( $image ) . '" alt="' . esc_attr( get_the_title() ) . '" style="display:block;width:100%;height:' . esc_attr( $img_height ) . ';object-fit:cover;"></a>';

                    }

                    echo '<div style="padding:22px 22px 20px;">';

                    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {

                        echo '<p style="margin:0 0 12px;">';

                        foreach ( array_slice( $terms, 0, 2 ) as $term ) {

                            echo '<span style="display:inline-block;margin:0 8px 8px 0;padding:6px 11px;border-radius:999px;background:#f3f0ea;border:1px solid #e7dfd3;font-size:12px;font-weight:600;">' . esc_html( $term->name ) . '</span>';

                        }

                        if ( $is_featured ) {

                            echo '<span style="display:inline-block;margin:0 8px 8px 0;padding:6px 11px;border-radius:999px;background:#111827;color:#fff;font-size:12px;font-weight:600;">' . esc_html__( 'Featured', 'product-mailer-campaigns' ) . '</span>';

                        }

                        if ( $is_locked ) {

                            echo '<span style="display:inline-block;margin:0 8px 8px 0;padding:6px 11px;border-radius:999px;background:#fff7ed;border:1px solid #fdba74;font-size:12px;font-weight:600;color:#9a3412;">' . esc_html__( 'Subscribers only', 'product-mailer-campaigns' ) . '</span>';

                        } elseif ( 'private' === $visibility ) {

                            echo '<span style="display:inline-block;margin:0 8px 8px 0;padding:6px 11px;border-radius:999px;background:#f3f4f6;border:1px solid #d1d5db;font-size:12px;font-weight:600;color:#374151;">' . esc_html__( 'Private', 'product-mailer-campaigns' ) . '</span>';

                        }

                        echo '</p>';

                    } elseif ( $is_featured || $is_locked || 'private' === $visibility ) {

                        echo '<p style="margin:0 0 12px;">';

                        if ( $is_featured ) {

                            echo '<span style="display:inline-block;margin:0 8px 8px 0;padding:6px 11px;border-radius:999px;background:#111827;color:#fff;font-size:12px;font-weight:600;">' . esc_html__( 'Featured', 'product-mailer-campaigns' ) . '</span>';

                        }

                        if ( $is_locked ) {

                            echo '<span style="display:inline-block;margin:0 8px 8px 0;padding:6px 11px;border-radius:999px;background:#fff7ed;border:1px solid #fdba74;font-size:12px;font-weight:600;color:#9a3412;">' . esc_html__( 'Subscribers only', 'product-mailer-campaigns' ) . '</span>';

                        } elseif ( 'private' === $visibility ) {

                            echo '<span style="display:inline-block;margin:0 8px 8px 0;padding:6px 11px;border-radius:999px;background:#f3f4f6;border:1px solid #d1d5db;font-size:12px;font-weight:600;color:#374151;">' . esc_html__( 'Private', 'product-mailer-campaigns' ) . '</span>';

                        }

                        echo '</p>';

                    }

                    echo '<h3 style="margin:0 0 10px;font-size:' . esc_attr( $hero ? '34px' : '24px' ) . ';line-height:1.18;"><a href="' . esc_url( $permalink ) . '" style="color:#111827;text-decoration:none;">' . esc_html( get_the_title() ) . '</a></h3>';

                    if ( ! empty( $atts['show_date'] ) ) {

                        echo '<p style="margin:0 0 12px;font-size:13px;letter-spacing:.02em;text-transform:uppercase;color:#6b7280;">' . esc_html( get_the_date() ) . '</p>';

                    }

                    echo '<p style="margin:0 0 18px;color:#4b5563;font-size:16px;line-height:1.7;">' . esc_html( wp_trim_words( wp_strip_all_tags( (string) get_the_excerpt() ), $excerpt_words ) ) . '</p>';

                    echo '<p style="margin:0;display:flex;gap:12px;flex-wrap:wrap;align-items:center;">';

                    echo '<a href="' . esc_url( $permalink ) . '" style="display:inline-block;padding:11px 16px;border-radius:999px;background:#111827;color:#fff;text-decoration:none;font-weight:600;">' . esc_html( $is_locked ? __( 'Preview & unlock', 'product-mailer-campaigns' ) : __( 'Read update', 'product-mailer-campaigns' ) ) . '</a>';

                    if ( $cta_url && $cta_label && ! $is_locked ) {

                        echo '<a href="' . esc_url( self::pmcpc_get_tracked_cta_url( $post_id, $cta_url ) ) . '" style="display:inline-block;padding:11px 16px;border-radius:999px;border:1px solid #d1d5db;color:#111827;text-decoration:none;font-weight:600;">' . esc_html( $cta_label ) . '</a>';

                    }

                    echo '</p>';

                    echo '</div></article>';

                }

                echo '</div>';

    

                $pagination = paginate_links(

                    array(

                        'base'      => esc_url_raw( add_query_arg( array( 'pmcpc_updates_page' => '%#%', 'pmcpc_updates_topic' => $topic ? $topic : false ) ) ),

                        'format'    => '',

                        'current'   => $paged,

                        'total'     => max( 1, (int) $query->max_num_pages ),

                        'type'      => 'list',

                        'prev_text' => '&larr;',

                        'next_text' => '&rarr;',

                    )

                );

                if ( $pagination ) {

                    echo '<div style="margin-top:28px;">' . wp_kses_post( $pagination ) . '</div>';

                }

                wp_reset_postdata();

            } else {

                echo '<div style="padding:28px;border:1px solid #ece7df;border-radius:24px;background:#fff;">';

                echo '<p style="margin:0;color:#4b5563;">' . esc_html__( 'No subscriber updates found yet.', 'product-mailer-campaigns' ) . '</p>';

                echo '</div>';

            }

    

            echo '</div>';

    

            $output = ob_get_clean();

            if ( ! $is_selected_updates_page ) {

                set_transient( $cache_key, $output, 10 * MINUTE_IN_SECONDS );

            }

    

            return $output;

        }

    

    

        /**

         * Process Subscriber Update single post content so campaign placeholders

         * such as {{products_block}} render on the public page as well.

         *

         * @param string $content The post content.

         * @return string

         */

    /**

         * Process Subscriber Update single post content so campaign placeholders

         * such as {{products_block}} render on the public page as well.

         *

         * @param string $content The post content.

         * @return string

         */

        public static function filter_subscriber_update_content( $content ) {

            if ( is_admin() || ! is_singular( 'pmcpc_sub_update' ) || ! in_the_loop() || ! is_main_query() ) {

                return $content;

            }

    

            $post_id = get_the_ID();

            if ( ! $post_id ) {

                return $content;

            }

    

            $campaign_id = absint( get_post_meta( $post_id, '_pmcpc_campaign_id', true ) );

            if ( $campaign_id > 0 && class_exists( 'PMCPC_Campaign_Manager' ) && method_exists( 'PMCPC_Campaign_Manager', 'pmcpc_inject_products_block_for_campaign_id' ) ) {

                $content = PMCPC_Campaign_Manager::pmcpc_inject_products_block_for_campaign_id( $campaign_id, $content );

            }

    

            if ( class_exists( 'PMCPC_Reviews' ) && method_exists( 'PMCPC_Reviews', 'inject_reviews_block_into_content' ) ) {

                $content = PMCPC_Reviews::inject_reviews_block_into_content( $content );

            }

    

            if ( false !== strpos( (string) $content, '{{products_block}}' ) || false !== strpos( (string) $content, '{{products}}' ) ) {

                $content = str_replace( array( '{{products_block}}', '{{products}}' ), '', (string) $content );

            }

            if ( false !== strpos( (string) $content, '{{reviews_block}}' ) || false !== strpos( (string) $content, '{{reviews}}' ) ) {

                $content = str_replace( array( '{{reviews_block}}', '{{reviews}}' ), '', (string) $content );

            }

    

            return $content;

        }

    

    	/**

    	 * Render a public confirmation status page (no login required).

    	 *

    	 * Triggered via ?pmcpc_public_status=confirmed|already_confirmed|expired|invalid

    	 *

    	 * @return void

    	 */

    /**

    	 * Render a public confirmation status page (no login required).

    	 *

    	 * Triggered via ?pmcpc_public_status=confirmed|already_confirmed|expired|invalid

    	 *

    	 * @return void

    	 */

    	public static function maybe_render_public_status_page() {

    		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only status key.

    		$status = isset( $_GET['pmcpc_public_status'] ) ? sanitize_key( (string) wp_unslash( $_GET['pmcpc_public_status'] ) ) : '';

    		if ( '' === $status ) {

    			return;

    		}

    

    		nocache_headers();

    

    		$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );

    		if ( ! $shop_url ) {

    			$shop_url = home_url( '/' );

    		}

    

    		$heading = __( 'Subscription update', 'product-mailer-campaigns' );

    		$message = '';

    		switch ( $status ) {

    			case 'confirmed':

    				$message = __( "You're all set! Your email has been confirmed.", 'product-mailer-campaigns' );

    				break;

    			case 'already_confirmed':

    				$message = __( "You're already subscribed — nothing else to do.", 'product-mailer-campaigns' );

    				break;

    			case 'expired':

    				$message = __( "This confirmation link has expired. Please sign up again and we'll send you a fresh link.", 'product-mailer-campaigns' );

    				break;

    			case 'invalid':

    			default:

    				$message = __( "That confirmation link didn't work. Please use the link from your email, or sign up again to receive a new one.", 'product-mailer-campaigns' );

    				break;

    		}

    

    		$html  = '<div class="pmcpc-public-status" style="max-width:720px;margin:60px auto;padding:24px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;">';

    		$html .= '<h1 style="margin:0 0 12px 0;font-size:28px;line-height:1.2;">' . esc_html( $heading ) . '</h1>';

    		$html .= '<p style="font-size:16px;line-height:1.5;margin:0 0 18px 0;">' . esc_html( $message ) . '</p>';

    		$html .= '<p><a class="button" style="display:inline-block;background:#2271b1;color:#fff;text-decoration:none;padding:10px 14px;border-radius:4px;" href="' . esc_url( $shop_url ) . '">' . esc_html__( 'Continue', 'product-mailer-campaigns' ) . '</a></p>';

    		$html .= '</div>';

    

    		status_header( 200 );

    		// Render using the active theme so visitors don't see a wp-login style screen or debug call stacks.

    		if ( function_exists( 'get_header' ) ) {

    			get_header();

    			echo wp_kses_post( $html );

    			get_footer();

    			exit;

    		}

    

    		echo wp_kses_post( $html );

    		exit;

    	}
}
