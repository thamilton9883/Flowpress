<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Shortcodes_Form_Handler_Methods {
    

    public static function handle_form_submission() {

            // Handle confirmation link for double opt-in.

            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- We validate token/nonce explicitly below.

            if ( isset( $_GET['pmcpc_confirm'] ) ) {

                $email = '';

    

                // Special-case: test link from settings.

                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.

                $raw_confirm = isset( $_GET['pmcpc_confirm'] ) ? (string) wp_unslash( $_GET['pmcpc_confirm'] ) : '';

                if ( 'test' === $raw_confirm ) {

                    $nonce    = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';

                    $nonce_ok = wp_verify_nonce( $nonce, 'pmcpc_confirm_test' );

                    if ( ! $nonce_ok ) {

                        wp_die( esc_html__( 'Security check failed. Please use the link from the email you received.', 'product-mailer-campaigns' ) );

                    }

                    wp_die( esc_html__( 'Test confirmation link successful.', 'product-mailer-campaigns' ) );

                }

    

                // New (robust) flow: token-based confirmation.

                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.

                $maybe_token = isset( $_GET['pmcpc_token'] ) ? wp_unslash( $_GET['pmcpc_token'] ) : '';

                if ( ! empty( $maybe_token ) && class_exists( 'PMCPC_Subscriber_Manager' ) ) {

                    $email = PMCPC_Subscriber_Manager::resolve_double_optin_token( $maybe_token );

                }

    

                // Legacy flow (kept for backward compatibility): email + nonce.

                if ( empty( $email ) ) {

                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.

                    $raw_email = isset( $_GET['pmcpc_confirm'] ) ? wp_unslash( $_GET['pmcpc_confirm'] ) : '';

                    // Some clients may partially decode the query string (e.g. %40 -> @). Normalize first.

                    $raw_email = rawurldecode( (string) $raw_email );

                    $email     = sanitize_email( $raw_email );

    

                    if ( $email && is_email( $email ) ) {

                        $nonce    = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';

                        $nonce_ok = wp_verify_nonce( $nonce, 'pmcpc_confirm_' . $email );

                        if ( ! $nonce_ok ) {

    						wp_safe_redirect( self::get_email_login_destination_url( 'invalid' ) );

    						exit;

                        }

                    }

                }

    

                if ( empty( $email ) ) {

    				wp_safe_redirect( self::get_email_login_destination_url( 'expired' ) );

    				exit;

                }

    

                if ( $email && is_email( $email ) ) {

    					// Clear any resend throttle once the user has successfully confirmed.

    					delete_transient( 'pmcpc_optin_sent_' . md5( strtolower( $email ) ) );

    

    					// If we confirmed via token, invalidate it.

    					if ( ! empty( $maybe_token ) ) {

    						delete_transient( 'pmcpc_confirm_token_' . sanitize_text_field( (string) $maybe_token ) );

    						delete_transient( 'pmcpc_confirm_email_' . md5( strtolower( $email ) ) );

    					}

    

    					$did_activate = false;

    					$subscriber   = PMCPC_Subscriber_Manager::get_subscriber_by_email( $email );

    					if ( $subscriber && 'active' !== $subscriber->status ) {

                            PMCPC_Subscriber_Manager::update_status( $subscriber->id, 'active' );

    						$did_activate = true;

    

                            // Trigger welcome campaigns only after confirmation.

                            if ( class_exists( 'PMCPC_Campaign_Manager' ) ) {

                                PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );

                            }

    

                            // Optionally notify the site admin about the confirmed double opt-in.

                            if ( class_exists( 'PMCPC_Settings' ) ) {

                                $notify_double_optin = PMCPC_Settings::get( 'notify_admin_double_optin', 'no' );

                                if ( 'yes' === $notify_double_optin ) {

                                    $notify_email = PMCPC_Settings::get( 'notify_admin_email', get_option( 'admin_email' ) );

                                    if ( $notify_email && is_email( $notify_email ) ) {

    								$admin_subject = sprintf(

    									/* translators: %s: subscriber email address. */

    									__( 'New subscriber confirmed: %s', 'product-mailer-campaigns' ),

    									$email

    								);

    

    								$admin_message = sprintf(

    									/* translators: 1: subscriber email address, 2: confirmation time. */

    									__( "A subscriber has just confirmed their email address via double opt-in.\n\nEmail: %1\$s\nTime: %2\$s", 'product-mailer-campaigns' ),

    									$email,

    									date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) )

    								);

    

                                        // Send admin notification using same From header logic.

                                        $admin_headers   = array();

                                        $admin_headers[] = 'Content-Type: text/plain; charset=UTF-8';

    

                                        $from_name  = get_bloginfo( 'name' );

                                        $from_email = get_option( 'admin_email' );

                                        if ( class_exists( 'PMCPC_Settings' ) ) {

                                            $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );

                                            $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );

                                            if ( ! empty( $from_name_setting ) ) {

                                                $from_name = $from_name_setting;

                                            }

                                            if ( ! empty( $from_email_setting ) ) {

                                                $from_email = $from_email_setting;

                                            }

                                        }

    

                                        $from_email = sanitize_email( $from_email );

                                        if ( ! $from_email ) {

                                            $from_email = get_option( 'admin_email' );

                                        }

    

                                        $admin_headers[] = 'From: ' . sprintf( '%s <%s>', wp_specialchars_decode( $from_name, ENT_QUOTES ), $from_email );

                                        $admin_headers[] = 'Reply-To: ' . $from_email;

    

                                        wp_mail( $notify_email, $admin_subject, $admin_message, $admin_headers );

                                    }

                                }

                            }

    

    																			// Show a friendly message on pages that render the subscribe form.

    																				self::$last_message = '<div class="pmcpc-message pmcpc-success">' . esc_html__( 'Thanks! Your subscription is now active.', 'product-mailer-campaigns' ) . '</div>';

    																		}

    

    																		// Redirect to the Email & Login screen with a friendly status message.

    																		$confirm_status = 'invalid';

    																		if ( $subscriber ) {

    																			$confirm_status = $did_activate ? 'confirmed' : 'already_confirmed';

    																		}

    																		wp_safe_redirect( self::get_email_login_destination_url( $confirm_status ) );

    																		exit;

    																}

    														}

    

    		// Front‑end subscribe form handler.

    

    

    		$front_sub_nonce = isset( $_POST['pmcpc_front_subscribe_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_front_subscribe_nonce'] ) ) : '';

    		if ( $front_sub_nonce && wp_verify_nonce( $front_sub_nonce, 'pmcpc_front_subscribe' ) ) {

                $dyn = self::get_posted_dynamic_form_settings( 'subscribe' );

                $dyn_settings = isset( $dyn['settings'] ) ? $dyn['settings'] : array();

                $dyn_soft_success = self::build_success_message_html( __( 'Thanks! Your subscription request has been received.', 'product-mailer-campaigns' ), $dyn_settings );

                $email      = isset( $_POST['pmcpc_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_email'] ) ) : '';

                $first_name = isset( $_POST['pmcpc_first_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_first_name'] ) ) : '';

                $last_name  = isset( $_POST['pmcpc_last_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_last_name'] ) ) : '';

    

    

    			// Honeypot field – if filled, treat as spam and bail (toggleable).

    			$hp_value = isset( $_POST['pmcpc_hp'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_hp'] ) ) : '';

    			$hp_enabled = ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'get_spam_setting' ) )

    				? ( 'yes' === PMCPC_Subscriber_Manager::get_spam_setting( 'spam_honeypot_enabled', 'yes' ) )

    				: true;

    			if ( $hp_enabled && ! empty( $hp_value ) ) {

    				if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

    					PMCPC_Subscriber_Manager::record_spam_block( $email, 'honeypot', 'subscribe' );

    				}

    				return;

    			}

    

                if ( ! is_email( $email ) ) {

                    self::$last_message = '<div class="pmcpc-message pmcpc-error">' . esc_html__( 'Please enter a valid email address.', 'product-mailer-campaigns' ) . '</div>';

                    return;

                }

    

       

                // Block common disposable / disallowed email domains.

                if ( self::is_blocked_email_domain( $email ) ) {

                    // Log so admins can review/tune settings.

                    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

                        PMCPC_Subscriber_Manager::record_spam_submission( $email, 'blocked_domain', 'subscribe', (string) $first_name, (string) $last_name, 'blocked' );

                    } elseif ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

                        PMCPC_Subscriber_Manager::record_spam_block( $email, 'blocked_domain', 'subscribe' );

                    }

                    self::$last_message = '<div class="pmcpc-message pmcpc-error">' . esc_html__( 'This email domain is not accepted. Please use a different email address.', 'product-mailer-campaigns' ) . '</div>';

                    return;

                }

    

    

    	            // Unified spam checks for subscribe submissions.

    	            if ( ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {

    	                $legacy_file = PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-subscriber-manager.php';

    	                if ( file_exists( $legacy_file ) ) {

    	                    require_once $legacy_file;

    	                }

    	            }

    	            if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'evaluate_spam' ) ) {

    	                $spam_eval = PMCPC_Subscriber_Manager::evaluate_spam(

    	                    array(

    	                        'email'      => $email,

    	                        'first_name' => $first_name,

    	                        'last_name'  => $last_name,

    	                        'context'    => 'subscribe',

    	                        'honeypot'   => $hp_value,

    	                    )

    	                );

    

    	                if ( empty( $spam_eval['allowed'] ) ) {

    	                    // Hold/block: do not add subscriber or send double opt-in email.

    	                    if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    	                        $status = ( ( isset( $spam_eval['action'] ) && 'held' === $spam_eval['action'] ) ? 'held' : 'blocked' );

    	                        // Store submitted names in subject/message for review + possible release.

    	                        PMCPC_Subscriber_Manager::record_spam_submission(

    	                            $email,

    	                            ( $spam_eval['reason'] ?? 'blocked' ),

    	                            'subscribe',

    	                            (string) $first_name,

    	                            (string) $last_name,

    	                            $status

    	                        );

    	                    } elseif ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

    	                        PMCPC_Subscriber_Manager::record_spam_block( $email, $spam_eval['reason'] ?? 'blocked', 'subscribe' );

    	                    }

    	                    // Soft-fail to avoid giving feedback to bots.

    	                    self::$last_message = $dyn_soft_success;

    	                    return;

    	                }

    

    	                if ( isset( $spam_eval['action'] ) && 'name_stripped' === $spam_eval['action'] ) {

    	                    $first_name = '';

    	                    $last_name  = '';

    	                }

    	            }

    

                // Extra tags to record where this subscriber came from (originator).

                $extra_tags   = array();

                $extra_tags[] = 'origin:subscribe-form';

    

                // If this subscribe form was rendered via a PMCPC dynamic form ([pmcpc_form]),

                // it will carry a hidden pmcpc_form_id field. Use that as an origin tag.

                if ( ! empty( $_POST['pmcpc_form_id'] ) ) {

                    $form_id = absint( wp_unslash( $_POST['pmcpc_form_id'] ) );

                    if ( $form_id ) {

                        $extra_tags[] = 'form-' . $form_id;

                    }

                }

    

                // If this email already belongs to a WordPress user account, but the visitor is not logged in,

                // redirect them to log in so they can activate subscriptions from their account.

                if ( ! is_user_logged_in() && function_exists( 'get_user_by' ) ) {

                    $existing_user = get_user_by( 'email', $email );

                    if ( $existing_user ) {

                        $redirect_to = '';

                        if ( class_exists( 'PMCPC_Settings' ) ) {

                            $redirect_to = PMCPC_Settings::get( 'email_prefs_url', '' );

                        }

                        if ( ! $redirect_to ) {

                            $redirect_to = wp_get_referer();

                        }

                        if ( ! $redirect_to ) {

                            $redirect_to = home_url( '/' );

                        }

    

                        // Add a flag so we can show a friendly login message.

                        $login_url = add_query_arg( 'pmcpc_email_login', '1', wp_login_url( $redirect_to ) );

                        wp_safe_redirect( $login_url );

                        exit;

                    }

                }

    

                $is_logged_in = is_user_logged_in();

    

                if ( $is_logged_in ) {

                    // Logged‑in customers / users: treat as single opt‑in (no confirmation email).

                    PMCPC_Subscriber_Manager::handle_opt_in(

                        array(

                            'email'      => $email,

                            'first_name' => $first_name,

                            'last_name'  => $last_name,

                            'context'    => 'subscribe',

                            'status'     => 'active',

                            'tags'       => $extra_tags,

    						'honeypot'  => $hp_value,

                        )

                    );

    

                    // Make absolutely sure this email is marked active in the subscriber table.

                    $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $email );

                    if ( $subscriber && 'active' !== $subscriber->status ) {

                        PMCPC_Subscriber_Manager::update_status( $subscriber->id, 'active' );

                    }

    

                    // Also keep the linked WordPress user meta flags in sync so

                    // the Users list "Email Subscriber" column shows the correct status.

                    $current_user = wp_get_current_user();

                    if ( $current_user && $current_user->user_email && strtolower( $current_user->user_email ) === strtolower( $email ) ) {

                        update_user_meta( $current_user->ID, 'pmcpc_is_subscriber', 1 );

                        update_user_meta( $current_user->ID, 'pmcpc_email_unsubscribed', 0 );

                    }

    

                    // Optionally trigger welcome campaigns immediately for newly active subscribers.

                    if ( class_exists( 'PMCPC_Campaign_Manager' ) ) {

                        PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );

                    }

    

                    self::flash_redirect(

                        '<div class="pmcpc-message pmcpc-success">' . esc_html__( 'You are subscribed. You can manage your preferences from your account area.', 'product-mailer-campaigns' ) . '</div>',

                        ( ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc-form-' . absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 'pmcpc-form-subscribe' ),

                        ( isset( $_POST['pmcpc_return_to'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_return_to'] ) ) : '' )

                    );

                }

    

                // Anonymous visitors: double opt‑in flow (pending + confirmation email).

                

                $guest_double_optin = 'yes';

                if ( class_exists( 'PMCPC_Settings' ) ) {

                    $guest_double_optin = PMCPC_Settings::get( 'guest_double_optin', 'yes' );

                }

    

                // If guest double opt-in is disabled, treat guests as single opt-in too.

                if ( 'yes' !== $guest_double_optin ) {

                    PMCPC_Subscriber_Manager::handle_opt_in(

                        array(

                            'email'      => $email,

                            'first_name' => $first_name,

                            'last_name'  => $last_name,

                            'context'    => 'subscribe',

                            'status'     => 'active',

                            'tags'       => $extra_tags,

    						'honeypot'  => $hp_value,

                        )

                    );

    

                    if ( class_exists( 'PMCPC_Campaign_Manager' ) ) {

                        PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );

                    }

    

                    self::flash_redirect(

                        '<div class="pmcpc-message pmcpc-success">' . esc_html__( 'You are subscribed. Please check your email for future updates.', 'product-mailer-campaigns' ) . '</div>',

                        ( ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc-form-' . absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 'pmcpc-form-subscribe' ),

                        ( isset( $_POST['pmcpc_return_to'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_return_to'] ) ) : '' )

                    );

                }

    

    // If this email is already an active subscriber, do not reset them to pending

            // or send another confirmation email. Just keep them active and show a success message.

            $existing_subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $email );

            if ( $existing_subscriber && 'active' === $existing_subscriber->status ) {

                PMCPC_Subscriber_Manager::handle_opt_in(

                    array(

                        'email'      => $email,

                        'first_name' => $first_name,

                        'last_name'  => $last_name,

                        'context'    => 'subscribe',

                        'status'     => 'active',

                        'tags'       => $extra_tags,

    					'honeypot'  => $hp_value,

                    )

                );

    

                self::flash_redirect(

                    '<div class="pmcpc-message pmcpc-success">' . esc_html__( 'You are already subscribed. Your subscription is active.', 'product-mailer-campaigns' ) . '</div>',

                    ( ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc-form-' . absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 'pmcpc-form-subscribe' ),

                    ( isset( $_POST['pmcpc_return_to'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_return_to'] ) ) : '' )

                );

            }

    

            PMCPC_Subscriber_Manager::handle_opt_in(

                array(

                    'email'      => $email,

                    'first_name' => $first_name,

                    'last_name'  => $last_name,

                    'context'    => 'subscribe',

                    'status'     => 'pending',

                    'tags'       => $extra_tags,

    				'honeypot'  => $hp_value,

                )

            );

    

                // Build confirmation URL (token-based, robust across email clients).

                $confirm_url = '';

                if ( class_exists( 'PMCPC_Subscriber_Manager' ) ) {

                    $confirm_url = PMCPC_Subscriber_Manager::build_double_optin_confirm_url( $email );

                }

    

                // Fallback to legacy nonce link if token generation is unavailable for any reason.

                if ( empty( $confirm_url ) ) {

                    $confirm_url = wp_nonce_url(

                        add_query_arg(

                            array(

                                'pmcpc_confirm' => $email,

                            ),

                            home_url( '/' )

                        ),

                        'pmcpc_confirm_' . $email

                    );

                    $confirm_url = html_entity_decode( $confirm_url, ENT_QUOTES, 'UTF-8' );

                }

    

                // Subject and message go through filters so the Email & Login Customization settings apply.

                $subject_default = __( 'Confirm your subscription', 'product-mailer-campaigns' );

                $subject         = apply_filters( 'pmcpc_double_opt_in_subject', $subject_default );

    

    			$message_default = sprintf(

    				/* translators: %s: confirmation URL. */

    				__( "Thanks for subscribing!\n\nPlease confirm your email by clicking this link:\n\n%s\n\nIf you did not request this, you can ignore this message.", 'product-mailer-campaigns' ),

    				$confirm_url

    			);

    

                $message = apply_filters( 'pmcpc_double_opt_in_message', $message_default, $confirm_url );

    

                $headers   = array();

                $headers[] = 'Content-Type: text/plain; charset=UTF-8';

    

                // Determine From / Reply-To based on plugin settings.

                $from_name  = get_bloginfo( 'name' );

                $from_email = get_option( 'admin_email' );

                if ( class_exists( 'PMCPC_Settings' ) ) {

                    $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );

                    $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );

                    if ( ! empty( $from_name_setting ) ) {

                        $from_name = $from_name_setting;

                    }

                    if ( ! empty( $from_email_setting ) ) {

                        $from_email = $from_email_setting;

                    }

                }

    

                $from_email = sanitize_email( $from_email );

                if ( ! $from_email ) {

                    $from_email = get_option( 'admin_email' );

                }

    

                $headers[] = 'From: ' . sprintf( '%s <%s>', wp_specialchars_decode( $from_name, ENT_QUOTES ), $from_email );

                $headers[] = 'Reply-To: ' . $from_email;

                $headers[] = 'Return-Path: ' . $from_email;

    

    			// Avoid spamming confirmation emails if something triggers the subscribe flow repeatedly

    			// (e.g. caching/auto-submits, or plugin updates causing the same POST to be replayed).

    			$throttle_key     = 'pmcpc_optin_sent_' . md5( strtolower( $email ) );

    			$throttle_seconds = (int) apply_filters( 'pmcpc_optin_resend_throttle_seconds', 21600 ); // 6 hours.

    			if ( $throttle_seconds < 60 ) {

    				$throttle_seconds = 60;

    			}

    

    			$sent_now = false;

    			if ( false === get_transient( $throttle_key ) ) {

    				wp_mail( $email, $subject, $message, $headers );

    				set_transient( $throttle_key, 1, $throttle_seconds );

    				$sent_now = true;

    			}

    

    			if ( $sent_now ) {

    				self::$last_message = self::build_success_message_html( __( 'Please check your email and click the confirmation link to complete your subscription.', 'product-mailer-campaigns' ), $dyn_settings );

    			} else {

    				self::$last_message = '<div class="pmcpc-message pmcpc-success">' . esc_html__( 'A confirmation email was sent recently. Please check your inbox (and spam folder) for the latest message.', 'product-mailer-campaigns' ) . '</div>';

    			}

            }

    

            // Contact form handler.

            if ( isset( $_POST['pmcpc_contact_form_nonce'] ) && wp_verify_nonce( sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_contact_form_nonce'] ) ), 'pmcpc_contact_form' ) ) {

                $dyn = self::get_posted_dynamic_form_settings( 'contact' );

                $dyn_settings = isset( $dyn['settings'] ) ? $dyn['settings'] : array();

                $dyn_soft_success = self::build_success_message_html( __( 'Thanks! Your message has been received.', 'product-mailer-campaigns' ), $dyn_settings );

    			$dyn_success_redirect = self::build_success_message_html( __( 'Thank you – your message has been sent.', 'product-mailer-campaigns' ), $dyn_settings );

                $review_mode = false;

                $product_review_mode = false;

                if ( ! empty( $_POST['pmcpc_form_id'] ) && class_exists( 'PMCPC_Forms' ) ) {

                    $posted_form = PMCPC_Forms::get_form( absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) );

                    $posted_type = isset( $posted_form['type'] ) ? sanitize_key( (string) $posted_form['type'] ) : '';

                    $review_mode = in_array( $posted_type, array( 'review', 'product_review' ), true );

                    $product_review_mode = ( 'product_review' === $posted_type );

                }

                $name    = isset( $_POST['pmcpc_contact_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_contact_name'] ) ) : '';

                $email   = isset( $_POST['pmcpc_contact_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_contact_email'] ) ) : '';

                $contact_subject = isset( $_POST['pmcpc_contact_subject'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_contact_subject'] ) ) : '';

                $review_rating   = isset( $_POST['pmcpc_review_rating'] ) ? absint( wp_unslash( $_POST['pmcpc_review_rating'] ) ) : 0;

                $product_id_from_form = isset( $_POST['pmcpc_product_id'] ) ? absint( wp_unslash( $_POST['pmcpc_product_id'] ) ) : 0;

                // Normalize to string to avoid PHP 8.1+ deprecation notices when WP string helpers receive null.

                $contact_message = isset( $_POST['pmcpc_contact_message'] ) ? wp_kses_post( (string) wp_unslash( $_POST['pmcpc_contact_message'] ) ) : '';

                $wants_opt_in = ! empty( $_POST['pmcpc_opt_in'] );

                $contact_message_log = $contact_message;

                if ( $wants_opt_in ) {

                    $contact_message_log .= "\n\n[pmcpc_opt_in=1]";

                }

    

    

    			if ( self::timing_checks_enabled() ) {

    				// Timing token: blocks/holds ultra-fast bot submissions.

    				$timing_token = isset( $_POST['pmcpc_ft'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_ft'] ) ) : '';

    				$elapsed      = self::verify_timing_token( $timing_token, 'contact' );

    				$min_elapsed  = self::min_submit_seconds( 'contact' );

    				if ( false === $elapsed || ( $min_elapsed > 0 && $elapsed < $min_elapsed ) ) {

    					$reason = ( false === $elapsed ) ? 'missing_timing_token' : 'too_fast';

    					if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    						PMCPC_Subscriber_Manager::record_spam_submission( $email, $reason, 'contact', $contact_subject, $contact_message_log, 'blocked' );

    					} elseif ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

    						PMCPC_Subscriber_Manager::record_spam_block( $email, $reason, 'contact' );

    					}

    					self::$last_message = $dyn_soft_success;

    					return;

    				}

    			}

    

                // Honeypot field – if filled, treat as spam and bail early.

                $honeypot = isset( $_POST['pmcpc_hp'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_hp'] ) ) : '';

                if ( ! empty( $honeypot ) ) {

                    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

                        if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    					PMCPC_Subscriber_Manager::record_spam_submission( $email, 'honeypot', 'contact', $contact_subject, $contact_message, 'blocked' );

    				} else {

    					PMCPC_Subscriber_Manager::record_spam_block( $email, 'honeypot', 'contact' );

    				}

                    }

                    // Soft-fail: do not reveal spam detection details.

                    self::$last_message = $dyn_soft_success;

                    return;

                }

    

    			// Block common disposable / disallowed email domains (e.g. mail.ru).

    			// Allowlisted senders bypass domain blocks + message scoring.

    			$allowlisted_sender = ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'is_allowlisted_sender' ) )

    				? PMCPC_Subscriber_Manager::is_allowlisted_sender( $email )

    				: false;

    			if ( ! $allowlisted_sender && self::is_blocked_email_domain( $email ) ) {

                    // Log so admins can review/tune settings.

                    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

                        PMCPC_Subscriber_Manager::record_spam_submission( $email, 'blocked_domain', 'contact', $contact_subject, $contact_message, 'blocked' );

                    } elseif ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

                        PMCPC_Subscriber_Manager::record_spam_block( $email, 'blocked_domain', 'contact' );

                    }

                    self::$last_message = '<div class="pmcpc-message pmcpc-error">' . esc_html__( 'This email domain is not accepted. Please use a different email address.', 'product-mailer-campaigns' ) . '</div>';

                    return;

                }

    

    

    

    

    // Route A: unified spam checks for contact submissions.

    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'evaluate_spam' ) ) {

        $spam_eval = PMCPC_Subscriber_Manager::evaluate_spam(

            array(

                'email'      => $email,

                'first_name' => $name,

                'last_name'  => '',

                'context'    => 'contact',

                'honeypot'   => $honeypot,

            )

        );

    

        if ( empty( $spam_eval['allowed'] ) ) {

            if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

                if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    					PMCPC_Subscriber_Manager::record_spam_submission(

    						$email,

    						( $spam_eval['reason'] ?? 'blocked' ),

    						'contact',

    						( isset( $contact_subject ) ? $contact_subject : '' ),

    						( isset( $contact_message ) ? $contact_message : '' ),

    						'blocked'

    					);

    				} else {

    					PMCPC_Subscriber_Manager::record_spam_block( $email, $spam_eval['reason'] ?? 'blocked', 'contact' );

    				}

            }

            self::$last_message = $dyn_soft_success;

            return;

        }

    

        if ( isset( $spam_eval['action'] ) && 'name_stripped' === $spam_eval['action'] ) {

            $name = '';

        }

    }

    

    			$msg_eval = array( 'score' => null, 'details' => array() );

    			if ( ! $allowlisted_sender && class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'evaluate_message_spam' ) ) {

        $msg_eval = PMCPC_Subscriber_Manager::evaluate_message_spam( $contact_subject, $contact_message, 'contact' );

        if ( empty( $msg_eval['allowed'] ) ) {

            $reason = ( isset( $msg_eval['action'] ) ? 'message_' . $msg_eval['action'] : 'message_blocked' );

            if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

                if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    					PMCPC_Subscriber_Manager::record_spam_submission(

    						$email,

    						$reason,

    						'contact',

    						( isset( $contact_subject ) ? $contact_subject : '' ),

    						( isset( $contact_message ) ? $contact_message : '' ),

    						( ( isset( $msg_eval['action'] ) && 'held' === $msg_eval['action'] ) ? 'held' : 'blocked' ),

    						0,

    						( $msg_eval['score'] ?? null ),

    						( $msg_eval['details'] ?? array() )

    					);

    				} else {

    					PMCPC_Subscriber_Manager::record_spam_block( $email, $reason, 'contact' );

    				}

            }

            self::$last_message = $dyn_soft_success;

            return;

        }

    }

    

                if ( ! $email || ! is_email( $email ) || '' === $contact_message || ( $review_mode && ( $review_rating < 1 || $review_rating > 5 ) ) ) {

                    self::$last_message = '<div class="pmcpc-message pmcpc-error">' . esc_html__( 'Please provide a valid email address and complete the required fields.', 'product-mailer-campaigns' ) . '</div>';

                } else {

                    if ( $review_mode && '' === trim( $contact_subject ) ) {

                        $contact_subject = $product_review_mode ? __( 'New product review submission', 'product-mailer-campaigns' ) : __( 'New review submission', 'product-mailer-campaigns' );

                    }

                    $to = get_option( 'admin_email' );

                    if ( class_exists( 'PMCPC_Settings' ) ) {

                        $configured = PMCPC_Settings::get( 'notify_admin_email', '' );

                        if ( $configured && is_email( $configured ) ) {

                            $to = $configured;

                        }

                    }

    

    

    

                    // Dynamic form override.

                    if ( ! empty( $dyn_settings['recipient_email'] ) && is_email( $dyn_settings['recipient_email'] ) ) {

                        $to = $dyn_settings['recipient_email'];

                    }

                    // Optional list opt-in from the contact form.

                    // $wants_opt_in is captured earlier for logging + guardrails.

    

                    if ( $wants_opt_in && class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'handle_opt_in' ) ) {

                        $extra_tags   = array();

                        $extra_tags[] = 'origin:contact-form';

    

                        // Preserve dynamic form ID source if this contact form was rendered via a PMCPC dynamic form.

                        if ( ! empty( $_POST['pmcpc_form_id'] ) ) {

                            $form_id = absint( wp_unslash( $_POST['pmcpc_form_id'] ) );

                            if ( $form_id ) {

                                $extra_tags[] = 'form-' . $form_id;

                            }

                        }

    

                        // Logged-in users: treat as single opt-in.

                        if ( is_user_logged_in() ) {

                            $is_new = PMCPC_Subscriber_Manager::handle_opt_in(

                                array(

                                    'email'      => $email,

                                    'first_name' => $name,

                                    'last_name'  => '',

                                    'context'    => 'contact',

                                    'status'     => 'active',

                                    'tags'       => $extra_tags,

                                )

                            );

    

                            if ( $is_new && class_exists( 'PMCPC_Campaign_Manager' ) ) {

                                PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );

                            }

                        } else {

                            // Guests: respect the same guest double opt-in setting as the subscribe form.

                            $guest_double_optin = 'yes';

                            if ( class_exists( 'PMCPC_Settings' ) ) {

                                $guest_double_optin = PMCPC_Settings::get( 'guest_double_optin', 'yes' );

                            }

    

                            if ( 'yes' !== $guest_double_optin ) {

                                $is_new = PMCPC_Subscriber_Manager::handle_opt_in(

                                    array(

                                        'email'      => $email,

                                        'first_name' => $name,

                                        'last_name'  => '',

                                        'context'    => 'contact',

                                        'status'     => 'active',

                                        'tags'       => $extra_tags,

                                    )

                                );

    

                                if ( $is_new && class_exists( 'PMCPC_Campaign_Manager' ) ) {

                                    PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );

                                }

                            } else {

                                // Double opt-in for contact form guests: create pending subscriber and send confirmation email.

                                PMCPC_Subscriber_Manager::handle_opt_in(

                                    array(

                                        'email'      => $email,

                                        'first_name' => $name,

                                        'last_name'  => '',

                                        'context'    => 'contact',

                                        'status'     => 'pending',

                                        'tags'       => $extra_tags,

                                    )

                                );

    

                                // Build confirmation URL (token-based, robust across email clients).

                                $confirm_url = '';

                                if ( class_exists( 'PMCPC_Subscriber_Manager' ) ) {

                                    $confirm_url = PMCPC_Subscriber_Manager::build_double_optin_confirm_url( $email );

                                }

    

                                // Fallback to legacy nonce link if token generation is unavailable for any reason.

                                if ( empty( $confirm_url ) ) {

                                    $confirm_url = wp_nonce_url(

                                        add_query_arg(

                                            array(

                                                'pmcpc_confirm' => $email,

                                            ),

                                            home_url( '/' )

                                        ),

                                        'pmcpc_confirm_' . $email

                                    );

                                    $confirm_url = html_entity_decode( $confirm_url, ENT_QUOTES, 'UTF-8' );

                                }

    

                                $optin_subject_default = __( 'Confirm your subscription', 'product-mailer-campaigns' );

                                $optin_subject         = apply_filters( 'pmcpc_double_opt_in_subject', $optin_subject_default );

    

    							$message_default = sprintf(

    								/* translators: %s: confirmation URL. */

    								__( "Thanks for subscribing!\n\nPlease confirm your email address by clicking the link below:\n\n%s\n\nIf you did not request this, you can ignore this message.", 'product-mailer-campaigns' ),

    								$confirm_url

    							);

    

                                $message = apply_filters( 'pmcpc_double_opt_in_message', $message_default, $confirm_url );

    

                                $headers_optin   = array();

                                $headers_optin[] = 'Content-Type: text/plain; charset=UTF-8';

    

                                $from_name_optin  = get_bloginfo( 'name' );

                                $from_email_optin = get_option( 'admin_email' );

                                if ( class_exists( 'PMCPC_Settings' ) ) {

                                    $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );

                                    $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );

                                    if ( ! empty( $from_name_setting ) ) {

                                        $from_name_optin = $from_name_setting;

                                    }

                                    if ( ! empty( $from_email_setting ) ) {

                                        $from_email_optin = $from_email_setting;

                                    }

                                }

    

                                $from_email_optin = sanitize_email( $from_email_optin );

                                if ( ! $from_email_optin ) {

                                    $from_email_optin = get_option( 'admin_email' );

                                }

    

                                $headers_optin[] = 'From: ' . sprintf( '%s <%s>', wp_specialchars_decode( $from_name_optin, ENT_QUOTES ), $from_email_optin );

                                $headers_optin[] = 'Reply-To: ' . $from_email_optin;

                                $headers_optin[] = 'Return-Path: ' . $from_email_optin;

    

    							// Throttle double opt-in emails to avoid repeat sends for the same email.

    							$throttle_key     = 'pmcpc_optin_sent_' . md5( strtolower( $email ) );

    							$throttle_seconds = (int) apply_filters( 'pmcpc_optin_resend_throttle_seconds', 21600 ); // 6 hours.

    							if ( $throttle_seconds < 60 ) {

    								$throttle_seconds = 60;

    							}

    

    							if ( false === get_transient( $throttle_key ) ) {

    								wp_mail( $email, $optin_subject, $message, $headers_optin );

    								set_transient( $throttle_key, 1, $throttle_seconds );

    							}

                            }

                        }

                    }

    

    

                    $mail_subject = $contact_subject ? $contact_subject : sprintf(

                        /* translators: %s: site name. */

                        __( 'New contact form message from %s', 'product-mailer-campaigns' ),

                        wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES )

                    );

    

    

                    // Dynamic form override: fixed subject.

                    if ( ! empty( $dyn_settings['email_subject'] ) ) {

                        $mail_subject = sanitize_text_field( (string) $dyn_settings['email_subject'] );

                    }

                    $body_lines = array();

                    if ( $name ) {

                        $body_lines[] = sprintf( /* translators: %s: subscriber name. */

    					__( 'Name: %s', 'product-mailer-campaigns' ), $name );

                    }

                    $body_lines[] = sprintf( /* translators: %s: subscriber email address. */

    					__( 'Email: %s', 'product-mailer-campaigns' ), $email );

                    if ( $review_mode ) {

                        $body_lines[] = sprintf( __( 'Rating: %d/5', 'product-mailer-campaigns' ), (int) $review_rating );

                    }

    

    				// Include page context so admins know which page the form was sent from.

    				$page_ctx = self::get_posted_page_context();

    				if ( ! empty( $page_ctx['url'] ) || ! empty( $page_ctx['title'] ) ) {

    					$label = __( 'Page', 'product-mailer-campaigns' );

    					$val   = '';

    					if ( ! empty( $page_ctx['title'] ) ) {

    						$val .= $page_ctx['title'];

    					}

    					if ( ! empty( $page_ctx['url'] ) ) {

    						$val .= ( $val ? ' — ' : '' ) . $page_ctx['url'];

    					}

    					if ( $val ) {

    						$body_lines[] = $label . ': ' . $val;

    					}

    				}

    

    			// If the enquiry was sent from a WooCommerce product page, include helpful product metadata.

    			if ( ! empty( $page_ctx['post_id'] ) ) {

    				$body_lines = array_merge( $body_lines, self::build_product_context_lines( (int) $page_ctx['post_id'] ) );

    			}

                    if ( $review_mode && $product_review_mode ) {

                        $review_product_id = $product_id_from_form > 0 ? $product_id_from_form : ( ! empty( $page_ctx['post_id'] ) ? (int) $page_ctx['post_id'] : 0 );

                        if ( $review_product_id > 0 ) {

                            $body_lines[] = sprintf( __( 'Product ID: %d', 'product-mailer-campaigns' ), $review_product_id );

                            if ( class_exists( 'PMCPC_Reviews' ) ) {

                                $pname = PMCPC_Reviews::get_product_name( $review_product_id );

                                if ( '' !== $pname ) {

                                    $body_lines[] = sprintf( __( 'Product: %s', 'product-mailer-campaigns' ), $pname );

                                }

                            }

                        }

                    }

    				// Include the submitted subject in the body as well (useful when the email subject is overridden).

    				if ( ! empty( $contact_subject ) ) {

    					$body_lines[] = sprintf( /* translators: %s: submitted subject. */

    						__( 'Subject: %s', 'product-mailer-campaigns' ),

    						$contact_subject

    					);

    				}

    

    				if ( ! empty( $wants_opt_in ) ) {

    					$body_lines[] = __( 'Opt-in: Yes', 'product-mailer-campaigns' );

    				}

                    $body_lines[] = '';

                    $body_lines[] = __( 'Message:', 'product-mailer-campaigns' );

                    $body_lines[] = wp_strip_all_tags( $contact_message );

                    $body         = $payload = self::collect_custom_fields_payload( $dyn_settings, 'contact' );

                    if ( ! empty( $payload['body_lines'] ) && is_array( $payload['body_lines'] ) ) {

                        $body_lines = array_merge( $body_lines, $payload['body_lines'] );

                    }

                    $attachments = ( ! empty( $payload['attachments'] ) && is_array( $payload['attachments'] ) ) ? $payload['attachments'] : array();

    

                    $body         = implode( "\n", $body_lines );

    

                    $headers   = array();

                    $headers[] = 'Content-Type: text/plain; charset=UTF-8';

    

                    $from_name  = get_bloginfo( 'name' );

                    $from_email = get_option( 'admin_email' );

                    if ( class_exists( 'PMCPC_Settings' ) ) {

                        $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );

                        $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );

                        if ( ! empty( $from_name_setting ) ) {

                            $from_name = $from_name_setting;

                        }

                        if ( ! empty( $from_email_setting ) ) {

                            $from_email = $from_email_setting;

                        }

                    }

    

                    $from_email = sanitize_email( $from_email );

                    if ( ! $from_email ) {

                        $from_email = get_option( 'admin_email' );

                    }

    

                    $headers[] = 'From: ' . sprintf( '%s <%s>', wp_specialchars_decode( $from_name, ENT_QUOTES ), $from_email );

                    $headers[] = 'Reply-To: ' . $email;

    

    				// Duplicate submission guard (optional): if the same email sends the same subject/message within

    				// a short window, hold the duplicate for review and do not send another email.

    				$dup_enabled = class_exists( 'PMCPC_Settings' ) && PMCPC_Settings::get( 'spam_duplicate_guard_enabled', 'no' ) === 'yes';

    				$dup_window  = class_exists( 'PMCPC_Settings' ) ? absint( PMCPC_Settings::get( 'spam_duplicate_guard_window', 60 ) ) : 60;

    				if ( $dup_window < 10 ) { $dup_window = 10; }

    				if ( $dup_enabled && class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'is_duplicate_submission_recent' ) ) {

    					$stored_contact_message = $contact_message;

    					if ( ! empty( $wants_opt_in ) ) {

    						$stored_contact_message .= "\n\n[pmcpc_opt_in=1]";

    					}

    					if ( PMCPC_Subscriber_Manager::is_duplicate_submission_recent( $email, 'contact', $mail_subject, $stored_contact_message, $dup_window ) ) {

    						if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    							PMCPC_Subscriber_Manager::record_spam_submission( $email, 'duplicate', 'contact', $mail_subject, $stored_contact_message, 'held', 0, 3, array( 'duplicate_guard' => 1, 'window' => $dup_window ) );

    						}

    						self::flash_redirect(

    							$dyn_success_redirect,

    							( ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc-form-' . absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 'pmcpc-form-contact' ),

    							( isset( $_POST['pmcpc_return_to'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_return_to'] ) ) : '' )

    						);

    					}

    				}

    

                    if ( $review_mode && class_exists( 'PMCPC_Reviews' ) ) {

                        $review_product_id = $product_review_mode ? ( $product_id_from_form > 0 ? $product_id_from_form : ( ! empty( $page_ctx['post_id'] ) ? (int) $page_ctx['post_id'] : 0 ) ) : 0;

                        $existing_review = PMCPC_Reviews::find_existing_review( $email, $review_product_id );

                        if ( ! empty( $existing_review ) ) {

                            self::flash_redirect(

                                self::build_error_message_html( __( 'Thanks — we already have a review or feedback entry for this email and item.', 'product-mailer-campaigns' ), $dyn_settings ),

                                ( ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc-form-' . absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 'pmcpc-form-contact' ),

                                ( isset( $_POST['pmcpc_return_to'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_return_to'] ) ) : '' )

                            );

                        }

                        $smart_private_feedback = ( $review_rating > 0 && $review_rating <= 3 );

                        PMCPC_Reviews::insert_review(

                            array(

                                'form_id'        => ! empty( $_POST['pmcpc_form_id'] ) ? absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 0,

                                'review_type'    => $product_review_mode ? 'product_review' : 'review',

                                'product_id'     => $review_product_id,

                                'product_name'   => $review_product_id ? PMCPC_Reviews::get_product_name( $review_product_id ) : '',

                                'reviewer_name'  => $name,

                                'reviewer_email' => $email,

                                'rating'         => $review_rating,

                                'review_title'   => $contact_subject,

                                'review_text'    => $contact_message,

                                'status'         => $smart_private_feedback ? 'private_feedback' : 'pending',

                                'verified_buyer' => PMCPC_Reviews::detect_verified_buyer( $email, $review_product_id ),

                                'source'         => ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc_form' : 'shortcode',

                            )

                        );

                        if ( $smart_private_feedback ) {

                            $mail_subject = sprintf( __( 'Private feedback received from %s', 'product-mailer-campaigns' ), $name ? $name : $email );

                        }

                    }

    

                    wp_mail( $to, $mail_subject, $body, $headers, $attachments );

    

                    // Cleanup uploaded files after sending.

                    if ( ! empty( $attachments ) && is_array( $attachments ) ) {

                        foreach ( $attachments as $p ) {

                            if ( is_string( $p ) && file_exists( $p ) ) {

                                wp_delete_file( $p );

                            }

                        }

                    }

    

    				// Store allowed submissions in the Inbox so admins can review everything

    				// and diagnose false positives. This is separate from spam logging and

    				// does not increment spam stats.

    				if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_inbox_submission' ) ) {

    					$stored_contact_message = $contact_message;

    					if ( ! empty( $wants_opt_in ) ) {

    						$stored_contact_message .= "\n\n[pmcpc_opt_in=1]";

    					}

    					PMCPC_Subscriber_Manager::record_inbox_submission( $email, ( $review_mode ? ( $product_review_mode ? 'product_review' : 'review' ) : 'contact' ), $mail_subject, $stored_contact_message, 'sent', 0, ( $msg_eval['score'] ?? null ), ( $msg_eval['details'] ?? array() ) );

    				}

    

    				self::flash_redirect(

    					$dyn_success_redirect,

                        ( ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc-form-' . absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 'pmcpc-form-contact' ),

                        ( isset( $_POST['pmcpc_return_to'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_return_to'] ) ) : '' )

                    );

                }

            }

    

            // Selling form handler.

            if ( isset( $_POST['pmcpc_selling_form_nonce'] ) && wp_verify_nonce( sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_selling_form_nonce'] ) ), 'pmcpc_selling_form' ) ) {

                $dyn = self::get_posted_dynamic_form_settings( 'selling' );

                $dyn_settings = isset( $dyn['settings'] ) ? $dyn['settings'] : array();

                $dyn_soft_success = self::build_success_message_html( __( 'Thanks! Your message has been received.', 'product-mailer-campaigns' ), $dyn_settings );

    			$dyn_success_redirect = self::build_success_message_html( __( 'Thank you – we\'ve received your selling enquiry and will get back to you.', 'product-mailer-campaigns' ), $dyn_settings );

                $name        = isset( $_POST['pmcpc_selling_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_selling_name'] ) ) : '';

                $email       = isset( $_POST['pmcpc_selling_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_selling_email'] ) ) : '';

                $phone       = isset( $_POST['pmcpc_selling_phone'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_selling_phone'] ) ) : '';

                $item_title  = isset( $_POST['pmcpc_selling_item'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_selling_item'] ) ) : '';

                $price       = isset( $_POST['pmcpc_selling_price'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_selling_price'] ) ) : '';

                // Normalize to string to avoid PHP 8.1+ deprecation notices when WP string helpers receive null.

                $details     = isset( $_POST['pmcpc_selling_details'] ) ? wp_kses_post( (string) wp_unslash( $_POST['pmcpc_selling_details'] ) ) : '';

    

                $wants_opt_in = ! empty( $_POST['pmcpc_opt_in'] );

                $details_log  = $details;

                if ( $wants_opt_in ) {

                    $details_log .= "\n\n[pmcpc_opt_in=1]";

                }

    

    

    

    			if ( self::timing_checks_enabled() ) {

    				// Timing token: helps block bots that POST directly without loading the page.

    				$ftoken  = isset( $_POST['pmcpc_ft'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_ft'] ) ) : '';

    				$elapsed = self::verify_timing_token( $ftoken, 'selling' );

    				$min_sec = self::min_submit_seconds( 'selling' );

    				if ( false === $elapsed || ( $min_sec > 0 && $elapsed < $min_sec ) ) {

    					$reason = ( false === $elapsed ) ? 'timing_token_invalid' : 'too_fast';

    					if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    						PMCPC_Subscriber_Manager::record_spam_submission( $email, $reason, 'selling', $item_title, $details_log, 'blocked' );

    					} elseif ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

    						PMCPC_Subscriber_Manager::record_spam_block( $email, $reason, 'selling' );

    					}

    					self::$last_message = $dyn_soft_success;

    					return;

    				}

    			}

    

                // Honeypot field – if filled, treat as spam and bail early.

                $honeypot = isset( $_POST['pmcpc_hp'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_hp'] ) ) : '';

                if ( ! empty( $honeypot ) ) {

                    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

                        if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    					PMCPC_Subscriber_Manager::record_spam_submission( $email, 'honeypot', 'selling', $item_title, $details_log, 'blocked' );

    				} else {

    					PMCPC_Subscriber_Manager::record_spam_block( $email, 'honeypot', 'selling' );

    				}

                    }

                    self::$last_message = $dyn_soft_success;

                    return;

                }

    

    			// Block common disposable / disallowed email domains (e.g. mail.ru).

    			// Allowlisted senders bypass domain blocks + message scoring.

    			$allowlisted_sender = ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'is_allowlisted_sender' ) )

    				? PMCPC_Subscriber_Manager::is_allowlisted_sender( $email )

    				: false;

    			if ( ! $allowlisted_sender && self::is_blocked_email_domain( $email ) ) {

                    // Log so admins can review/tune settings.

                    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

                        PMCPC_Subscriber_Manager::record_spam_submission( $email, 'blocked_domain', 'selling', $item_title, $details_log, 'blocked' );

                    } elseif ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

                        PMCPC_Subscriber_Manager::record_spam_block( $email, 'blocked_domain', 'selling' );

                    }

                    self::$last_message = '<div class="pmcpc-message pmcpc-error">' . esc_html__( 'This email domain is not accepted. Please use a different email address.', 'product-mailer-campaigns' ) . '</div>';

                    return;

                }

    

    // Route A: unified spam checks for selling submissions.

    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'evaluate_spam' ) ) {

        $spam_eval = PMCPC_Subscriber_Manager::evaluate_spam(

            array(

                'email'      => $email,

                'first_name' => $name,

                'last_name'  => '',

                'context'    => 'selling',

                'honeypot'   => $honeypot,

            )

        );

    

        if ( empty( $spam_eval['allowed'] ) ) {

            if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

                if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    					PMCPC_Subscriber_Manager::record_spam_submission(

    						$email,

    						( $spam_eval['reason'] ?? 'blocked' ),

    						'selling',

    						( isset( $item_title ) ? $item_title : '' ),

    						( isset( $details_log ) ? $details_log : ( isset( $details ) ? $details : '' ) ),

    						'blocked'

    					);

    				} else {

    					PMCPC_Subscriber_Manager::record_spam_block( $email, $spam_eval['reason'] ?? 'blocked', 'selling' );

    				}

            }

            self::$last_message = $dyn_soft_success;

            return;

        }

    

        if ( isset( $spam_eval['action'] ) && 'name_stripped' === $spam_eval['action'] ) {

            $name = '';

        }

    }

    

    			if ( ! $allowlisted_sender && class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'evaluate_message_spam' ) ) {

        $body_for_scoring = wp_strip_all_tags( $details );

        if ( ! empty( $price ) ) {

            $body_for_scoring .= "\n" . wp_strip_all_tags( $price );

        }

        if ( ! empty( $phone ) ) {

            $body_for_scoring .= "\n" . wp_strip_all_tags( $phone );

        }

        $msg_eval = PMCPC_Subscriber_Manager::evaluate_message_spam( $item_title, $body_for_scoring, 'selling' );

        if ( empty( $msg_eval['allowed'] ) ) {

            $reason = ( isset( $msg_eval['action'] ) ? 'message_' . $msg_eval['action'] : 'message_blocked' );

            if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_block' ) ) {

                if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    					$pmcpc_selling_message = ( isset( $details_log ) ? $details_log : ( isset( $details ) ? $details : '' ) );

    					if ( isset( $price ) && '' !== (string) $price ) { $pmcpc_selling_message .= "

    " . (string) $price; }

    					if ( isset( $phone ) && '' !== (string) $phone ) { $pmcpc_selling_message .= "

    " . (string) $phone; }

    					PMCPC_Subscriber_Manager::record_spam_submission(

    						$email,

    						$reason,

    						'selling',

    						( isset( $item_title ) ? $item_title : '' ),

    						$pmcpc_selling_message,

    						( ( isset( $msg_eval['action'] ) && 'held' === $msg_eval['action'] ) ? 'held' : 'blocked' )

    					);

    				} else {

    					PMCPC_Subscriber_Manager::record_spam_block( $email, $reason, 'selling' );

    				}

            }

            self::$last_message = $dyn_soft_success;

            return;

        }

    }

    

    

    

                if ( ! $email || ! is_email( $email ) || '' === $details ) {

                    self::$last_message = '<div class="pmcpc-message pmcpc-error">' . esc_html__( 'Please provide a valid email address and details about the item you want to sell.', 'product-mailer-campaigns' ) . '</div>';

                } else {

                    $to = get_option( 'admin_email' );

                    if ( class_exists( 'PMCPC_Settings' ) ) {

                        $configured = PMCPC_Settings::get( 'notify_admin_email', '' );

                        if ( $configured && is_email( $configured ) ) {

                            $to = $configured;

                        }

                    }

    

    

    

                    // Dynamic form override.

                    if ( ! empty( $dyn_settings['recipient_email'] ) && is_email( $dyn_settings['recipient_email'] ) ) {

                        $to = $dyn_settings['recipient_email'];

                    }

    

                    // Optional list opt-in from the selling form.

                    if ( $wants_opt_in && class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'handle_opt_in' ) ) {

                        $extra_tags   = array();

                        $extra_tags[] = 'origin:selling-form';

    

                        // Preserve dynamic form ID source if this selling form was rendered via a PMCPC dynamic form.

                        if ( ! empty( $_POST['pmcpc_form_id'] ) ) {

                            $form_id = absint( wp_unslash( $_POST['pmcpc_form_id'] ) );

                            if ( $form_id ) {

                                $extra_tags[] = 'form-' . $form_id;

                            }

                        }

    

                        // Logged-in users: treat as single opt-in.

                        if ( is_user_logged_in() ) {

                            $is_new = PMCPC_Subscriber_Manager::handle_opt_in(

                                array(

                                    'email'      => $email,

                                    'first_name' => $name,

                                    'last_name'  => '',

                                    'context'    => 'selling',

                                    'status'     => 'active',

                                    'tags'       => $extra_tags,

                                )

                            );

    

                            if ( $is_new && class_exists( 'PMCPC_Campaign_Manager' ) ) {

                                PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );

                            }

                        } else {

                            // Guests: respect the same guest double opt-in setting as the subscribe form.

                            $guest_double_optin = 'yes';

                            if ( class_exists( 'PMCPC_Settings' ) ) {

                                $guest_double_optin = PMCPC_Settings::get( 'guest_double_optin', 'yes' );

                            }

    

                            if ( 'yes' !== $guest_double_optin ) {

                                $is_new = PMCPC_Subscriber_Manager::handle_opt_in(

                                    array(

                                        'email'      => $email,

                                        'first_name' => $name,

                                        'last_name'  => '',

                                        'context'    => 'selling',

                                        'status'     => 'active',

                                        'tags'       => $extra_tags,

                                    )

                                );

    

                                if ( $is_new && class_exists( 'PMCPC_Campaign_Manager' ) ) {

                                    PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );

                                }

                            } else {

                                // Double opt-in for selling form guests: create pending subscriber and send confirmation email.

                                PMCPC_Subscriber_Manager::handle_opt_in(

                                    array(

                                        'email'      => $email,

                                        'first_name' => $name,

                                        'last_name'  => '',

                                        'context'    => 'selling',

                                        'status'     => 'pending',

                                        'tags'       => $extra_tags,

                                    )

                                );

    

                                // Build confirmation URL (token-based, robust across email clients).

                                $confirm_url = '';

                                if ( class_exists( 'PMCPC_Subscriber_Manager' ) ) {

                                    $confirm_url = PMCPC_Subscriber_Manager::build_double_optin_confirm_url( $email );

                                }

    

                                // Fallback to legacy nonce link if token generation is unavailable for any reason.

                                if ( empty( $confirm_url ) ) {

                                    $confirm_url = wp_nonce_url(

                                        add_query_arg(

                                            array(

                                                'pmcpc_confirm' => $email,

                                            ),

                                            home_url( '/' )

                                        ),

                                        'pmcpc_confirm_' . $email

                                    );

                                    $confirm_url = html_entity_decode( $confirm_url, ENT_QUOTES, 'UTF-8' );

                                }

    

                                $optin_subject_default = __( 'Confirm your subscription', 'product-mailer-campaigns' );

                                $optin_subject         = apply_filters( 'pmcpc_double_opt_in_subject', $optin_subject_default );

    

                                $message_default = sprintf(

                                    /* translators: %s: confirmation URL. */

                                    __( "Thanks for subscribing!

    

    Please confirm your email address by clicking the link below:

    

    %s

    

    If you did not request this, you can ignore this message.", 'product-mailer-campaigns' ),

                                    $confirm_url

                                );

    

                                $message = apply_filters( 'pmcpc_double_opt_in_message', $message_default, $confirm_url );

    

                                $headers_optin   = array();

                                $headers_optin[] = 'Content-Type: text/plain; charset=UTF-8';

    

                                $from_name_optin  = get_bloginfo( 'name' );

                                $from_email_optin = get_option( 'admin_email' );

                                if ( class_exists( 'PMCPC_Settings' ) ) {

                                    $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );

                                    $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );

                                    if ( ! empty( $from_name_setting ) ) {

                                        $from_name_optin = $from_name_setting;

                                    }

                                    if ( ! empty( $from_email_setting ) ) {

                                        $from_email_optin = $from_email_setting;

                                    }

                                }

    

                                $from_email_optin = sanitize_email( $from_email_optin );

                                if ( ! $from_email_optin ) {

                                    $from_email_optin = get_option( 'admin_email' );

                                }

    

                                $headers_optin[] = 'From: ' . sprintf( '%s <%s>', wp_specialchars_decode( $from_name_optin, ENT_QUOTES ), $from_email_optin );

                                $headers_optin[] = 'Reply-To: ' . $from_email_optin;

                                $headers_optin[] = 'Return-Path: ' . $from_email_optin;

    

                                // Throttle double opt-in emails to avoid repeat sends for the same email.

                                $throttle_key     = 'pmcpc_optin_sent_' . md5( strtolower( $email ) );

                                $throttle_seconds = (int) apply_filters( 'pmcpc_optin_resend_throttle_seconds', 21600 ); // 6 hours.

                                if ( $throttle_seconds < 60 ) {

                                    $throttle_seconds = 60;

                                }

    

                                if ( false === get_transient( $throttle_key ) ) {

                                    wp_mail( $email, $optin_subject, $message, $headers_optin );

                                    set_transient( $throttle_key, 1, $throttle_seconds );

                                }

                            }

                        }

                    }

    

                    $mail_subject = sprintf(

                        /* translators: %s: item title. */

                        __( 'Selling enquiry: %s', 'product-mailer-campaigns' ),

                        $item_title ? $item_title : __( 'Unnamed item', 'product-mailer-campaigns' )

                    );

    

    

                    // Dynamic form override: fixed subject.

                    if ( ! empty( $dyn_settings['email_subject'] ) ) {

                        $mail_subject = sanitize_text_field( (string) $dyn_settings['email_subject'] );

                    }

                    $body_lines   = array();

                    if ( $name ) {

                        $body_lines[] = sprintf( /* translators: %s: subscriber name. */

    					__( 'Name: %s', 'product-mailer-campaigns' ), $name );

                    }

                    $body_lines[] = sprintf( /* translators: %s: subscriber email address. */

    					__( 'Email: %s', 'product-mailer-campaigns' ), $email );

    

    				// Include page context so admins know which page the form was sent from.

    				$page_ctx = self::get_posted_page_context();

    				if ( ! empty( $page_ctx['url'] ) || ! empty( $page_ctx['title'] ) ) {

    					$label = __( 'Page', 'product-mailer-campaigns' );

    					$val   = '';

    					if ( ! empty( $page_ctx['title'] ) ) {

    						$val .= $page_ctx['title'];

    					}

    					if ( ! empty( $page_ctx['url'] ) ) {

    						$val .= ( $val ? ' — ' : '' ) . $page_ctx['url'];

    					}

    					if ( $val ) {

    						$body_lines[] = $label . ': ' . $val;

    					}

    				}

    

    				if ( ! empty( $wants_opt_in ) ) {

    					$body_lines[] = __( 'Opt-in: Yes', 'product-mailer-campaigns' );

    				}

    				if ( $phone ) {

    					$body_lines[] = sprintf(

    						/* translators: %s: subscriber phone number. */

    						__( 'Phone: %s', 'product-mailer-campaigns' ),

    						$phone

    					);

    				}

                    if ( $item_title ) {

                        $body_lines[] = sprintf( /* translators: %s: item title. */

    					__( 'Item: %s', 'product-mailer-campaigns' ), $item_title );

                    }

    				if ( $price ) {

    					$body_lines[] = sprintf(

    						/* translators: %s: asking price. */

    						__( 'Asking price: %s', 'product-mailer-campaigns' ),

    						$price

    					);

    				}

                    $body_lines[] = '';

                    $body_lines[] = __( 'Details:', 'product-mailer-campaigns' );

                    $body_lines[] = wp_strip_all_tags( $details );

                    $body         = $payload = self::collect_custom_fields_payload( $dyn_settings, 'selling' );

                    if ( ! empty( $payload['body_lines'] ) && is_array( $payload['body_lines'] ) ) {

                        $body_lines = array_merge( $body_lines, $payload['body_lines'] );

                    }

                    $attachments = ( ! empty( $payload['attachments'] ) && is_array( $payload['attachments'] ) ) ? $payload['attachments'] : array();

    

                    $body         = implode( "\n", $body_lines );

    

                    $headers   = array();

                    $headers[] = 'Content-Type: text/plain; charset=UTF-8';

    

                    $from_name  = get_bloginfo( 'name' );

                    $from_email = get_option( 'admin_email' );

                    if ( class_exists( 'PMCPC_Settings' ) ) {

                        $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );

                        $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );

                        if ( ! empty( $from_name_setting ) ) {

                            $from_name = $from_name_setting;

                        }

                        if ( ! empty( $from_email_setting ) ) {

                            $from_email = $from_email_setting;

                        }

                    }

    

                    $from_email = sanitize_email( $from_email );

                    if ( ! $from_email ) {

                        $from_email = get_option( 'admin_email' );

                    }

    

                    $headers[] = 'From: ' . sprintf( '%s <%s>', wp_specialchars_decode( $from_name, ENT_QUOTES ), $from_email );

                    $headers[] = 'Reply-To: ' . $email;

    

    				// Duplicate submission guard (optional).

    				$dup_enabled = class_exists( 'PMCPC_Settings' ) && PMCPC_Settings::get( 'spam_duplicate_guard_enabled', 'no' ) === 'yes';

    				$dup_window  = class_exists( 'PMCPC_Settings' ) ? absint( PMCPC_Settings::get( 'spam_duplicate_guard_window', 60 ) ) : 60;

    				if ( $dup_window < 10 ) { $dup_window = 10; }

    				if ( $dup_enabled && class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'is_duplicate_submission_recent' ) ) {

    					if ( PMCPC_Subscriber_Manager::is_duplicate_submission_recent( $email, 'selling', $mail_subject, $details_log, $dup_window ) ) {

    						if ( method_exists( 'PMCPC_Subscriber_Manager', 'record_spam_submission' ) ) {

    							PMCPC_Subscriber_Manager::record_spam_submission( $email, 'duplicate', 'selling', $mail_subject, $details_log, 'held', 0, 3, array( 'duplicate_guard' => 1, 'window' => $dup_window ) );

    						}

    						self::flash_redirect(

    							$dyn_success_redirect,

    							( ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc-form-' . absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 'pmcpc-form-selling' ),

    							( isset( $_POST['pmcpc_return_to'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_return_to'] ) ) : '' )

    						);

    					}

    				}

    

                    if ( $review_mode && class_exists( 'PMCPC_Reviews' ) ) {

                        $review_product_id = $product_review_mode ? ( $product_id_from_form > 0 ? $product_id_from_form : ( ! empty( $page_ctx['post_id'] ) ? (int) $page_ctx['post_id'] : 0 ) ) : 0;

                        $existing_review = PMCPC_Reviews::find_existing_review( $email, $review_product_id );

                        if ( ! empty( $existing_review ) ) {

                            self::flash_redirect(

                                self::build_error_message_html( __( 'Thanks — we already have a review or feedback entry for this email and item.', 'product-mailer-campaigns' ), $dyn_settings ),

                                ( ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc-form-' . absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 'pmcpc-form-contact' ),

                                ( isset( $_POST['pmcpc_return_to'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_return_to'] ) ) : '' )

                            );

                        }

                        $smart_private_feedback = ( $review_rating > 0 && $review_rating <= 3 );

                        PMCPC_Reviews::insert_review(

                            array(

                                'form_id'        => ! empty( $_POST['pmcpc_form_id'] ) ? absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 0,

                                'review_type'    => $product_review_mode ? 'product_review' : 'review',

                                'product_id'     => $review_product_id,

                                'product_name'   => $review_product_id ? PMCPC_Reviews::get_product_name( $review_product_id ) : '',

                                'reviewer_name'  => $name,

                                'reviewer_email' => $email,

                                'rating'         => $review_rating,

                                'review_title'   => $contact_subject,

                                'review_text'    => $contact_message,

                                'status'         => $smart_private_feedback ? 'private_feedback' : 'pending',

                                'verified_buyer' => PMCPC_Reviews::detect_verified_buyer( $email, $review_product_id ),

                                'source'         => ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc_form' : 'shortcode',

                            )

                        );

                        if ( $smart_private_feedback ) {

                            $mail_subject = sprintf( __( 'Private feedback received from %s', 'product-mailer-campaigns' ), $name ? $name : $email );

                        }

                    }

    

                    wp_mail( $to, $mail_subject, $body, $headers, $attachments );

    

                    // Cleanup uploaded files after sending.

                    if ( ! empty( $attachments ) && is_array( $attachments ) ) {

                        foreach ( $attachments as $p ) {

                            if ( is_string( $p ) && file_exists( $p ) ) {

                                wp_delete_file( $p );

                            }

                        }

                    }

    

    				// Store allowed submissions in the Inbox so admins can review everything.

    				if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'record_inbox_submission' ) ) {

    					PMCPC_Subscriber_Manager::record_inbox_submission( $email, 'selling', $mail_subject, $details_log, 'sent', 0, ( $msg_eval['score'] ?? null ), ( $msg_eval['details'] ?? array() ) );

    				}

    

                    self::flash_redirect(

                        $dyn_success_redirect,

                        ( ! empty( $_POST['pmcpc_form_id'] ) ? 'pmcpc-form-' . absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 'pmcpc-form-selling' ),

                        ( isset( $_POST['pmcpc_return_to'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_return_to'] ) ) : '' )

                    );

                }

            }

    

    

        }
}
