<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Shortcodes_Bootstrap_Methods {
    

    protected static function maybe_load_flash_message() {

        if ( ! empty( self::$last_message ) ) {

            return;

        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- One-time display token, not a privileged action.

        $token = isset( $_GET['pmcpc_flash'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_flash'] ) ) : '';

        if ( '' === $token ) {

            return;

        }

    

        $key  = 'pmcpc_flash_' . $token;

        $html = get_transient( $key );

        if ( ! empty( $html ) && is_string( $html ) ) {

            self::$last_message = $html;

            delete_transient( $key );

        }

    }

    

    /**

     * Redirect back to the referring page with a one-time message and optional anchor.

     *

     * @param string $html   HTML message (already escaped/sanitized for output).

     * @param string $anchor Anchor id without the leading '#'.

     * @return void

     */

    /**

     * Redirect back to the referring page with a one-time message and optional anchor.

     *

     * @param string $html   HTML message (already escaped/sanitized for output).

     * @param string $anchor Anchor id without the leading '#'.

     * @return void

     */

    protected static function flash_redirect( $html, $anchor = '', $return_to = '' ) {

        $html = (string) $html;

    

        // Prefer an explicit return URL posted by the form (more reliable than HTTP_REFERER).

        $return_to   = (string) $return_to;

        $redirect_to = '';

        if ( '' !== $return_to ) {

            $redirect_to = wp_validate_redirect( $return_to, '' );

        }

    

        // Fallback to the HTTP referrer so we return the user to the page that contained the form.

        if ( ! $redirect_to ) {

            $redirect_to = wp_get_referer();

        }

        if ( ! $redirect_to ) {

            $redirect_to = home_url( '/' );

        }

    

        // Strip any existing flash token + fragment so we can attach our own.

        $redirect_to = remove_query_arg( array( 'pmcpc_flash' ), $redirect_to );

        $redirect_to = preg_replace( '/#.*$/', '', (string) $redirect_to );

    

        // Store the message in a short-lived transient and pass a token in the URL.

        $token = wp_generate_password( 12, false, false );

        set_transient( 'pmcpc_flash_' . $token, $html, (int) apply_filters( 'pmcpc_flash_message_ttl', 300 ) );

    

        $redirect_to = add_query_arg( 'pmcpc_flash', rawurlencode( $token ), $redirect_to );

    

        $anchor = sanitize_key( (string) $anchor );

        if ( '' !== $anchor ) {

            $redirect_to .= '#' . $anchor;

        }

    

        wp_safe_redirect( $redirect_to );

        exit;

    }

    

    

        /**

         * Create a signed timing token to make it harder for bots to submit forms without first loading the page.

         *

         * Token format: "<issued_ts>:<sig>".

         *

         * @param string $context Form context (contact/selling/subscribe).

         * @return string

         */

    /**

         * Create a signed timing token to make it harder for bots to submit forms without first loading the page.

         *

         * Token format: "<issued_ts>:<sig>".

         *

         * @param string $context Form context (contact/selling/subscribe).

         * @return string

         */

        protected static function make_timing_token( $context ) {

            $context = sanitize_key( (string) $context );

            $issued  = (int) time();

            $sig     = wp_hash( $issued . '|' . $context . '|pmcpc_form_timing', 'nonce' );

            return $issued . ':' . $sig;

        }

    

        /**

         * Verify timing token and return elapsed seconds since issue time.

         *

         * @param string $token   Token from POST.

         * @param string $context Form context.

         * @return int|false Elapsed seconds, or false if invalid.

         */

    /**

         * Verify timing token and return elapsed seconds since issue time.

         *

         * @param string $token   Token from POST.

         * @param string $context Form context.

         * @return int|false Elapsed seconds, or false if invalid.

         */

        protected static function verify_timing_token( $token, $context ) {

            $token   = (string) $token;

            $context = sanitize_key( (string) $context );

            if ( '' === $token || false === strpos( $token, ':' ) ) {

                return false;

            }

            list( $issued_raw, $sig ) = array_pad( explode( ':', $token, 2 ), 2, '' );

            $issued = (int) $issued_raw;

            if ( $issued <= 0 || '' === $sig ) {

                return false;

            }

            $expected = wp_hash( $issued . '|' . $context . '|pmcpc_form_timing', 'nonce' );

            if ( ! hash_equals( $expected, $sig ) ) {

                return false;

            }

            $now = (int) time();

            if ( $now < $issued ) {

                return false;

            }

            return (int) ( $now - $issued );

        }

    

        /**

         * Minimum seconds before a form submission is considered plausible.

         * Filterable so shops can tune it.

         *

         * @param string $context Form context.

         * @return int

         */

    /**

         * Minimum seconds before a form submission is considered plausible.

         * Filterable so shops can tune it.

         *

         * @param string $context Form context.

         * @return int

         */

        protected static function min_submit_seconds( $context ) {

            $context = sanitize_key( (string) $context );

            $min = 4;

            if ( class_exists( 'PMCPC_Settings' ) ) {

                $min = (int) PMCPC_Settings::get( 'spam_min_submit_seconds', 4 );

            }

            $min = (int) apply_filters( 'pmcpc_spam_min_submit_seconds', $min, $context );

            if ( $min < 0 ) {

                $min = 0;

            }

            return $min;

        }

    

    	/**

    	 * Whether the signed timing token checks are enabled for PMCPC forms.

    	 *

    	 * @return bool

    	 */

    /**

    	 * Whether the signed timing token checks are enabled for PMCPC forms.

    	 *

    	 * @return bool

    	 */

    	protected static function timing_checks_enabled() {

    		$enabled = 'yes';

    		if ( class_exists( 'PMCPC_Settings' ) ) {

    			$enabled = (string) PMCPC_Settings::get( 'spam_form_timing_enabled', 'yes' );

    		}

    		$enabled = (string) apply_filters( 'pmcpc_spam_form_timing_enabled', $enabled );

    		return 'yes' === $enabled;

    	}

    

        /**

         * Extract the domain part from an email address.

         *

         * @param string $email Email address.

         * @return string Domain, or empty string on failure.

         */

    /**

         * Extract the domain part from an email address.

         *

         * @param string $email Email address.

         * @return string Domain, or empty string on failure.

         */

        protected static function get_email_domain( $email ) {

            $email = trim( (string) $email );

            if ( '' === $email || false === strpos( $email, '@' ) ) {

                return '';

            }

            $domain = substr( strrchr( $email, '@' ), 1 );

            return strtolower( $domain );

        }

    

    	    /**

         * Whether an email address is using a blocked domain.

         *

         * Public so other plugin components (e.g. Subscriber Manager and the admin

         * "Test spam protection" tool) can reuse the same domain-blocking logic.

         *

         * @param string $email Email address.

         * @return bool True if the domain is blocked.

         */

    /**

         * Whether an email address is using a blocked domain.

         *

         * Public so other plugin components (e.g. Subscriber Manager and the admin

         * "Test spam protection" tool) can reuse the same domain-blocking logic.

         *

         * @param string $email Email address.

         * @return bool True if the domain is blocked.

         */

        public static function is_blocked_email_domain( $email ) {

            $domain = self::get_email_domain( $email );

            if ( '' === $domain ) {

                return false;

            }

    

            // Base list of disposable domains.

            $blocked_domains = array(

                'tempmail.com',

                '10minutemail.com',

                'mailinator.com',

                'guerrillamail.com',

                'yopmail.com',

                'discardmail.com',

                'maildrop.cc',

                'moakt.com',

                'trashmail.com',

                // Explicitly block mail.ru and any sub‑domains.

                'mail.ru',

            );

    

            /**

             * Filter the list of blocked email domains.

             *

             * This allows site owners to add or remove domains without editing the plugin.

             *

             * @param array  $blocked_domains Default blocked domains.

             * @param string $domain          The domain part of the email address.

             * @param string $email           The full email address.

             */

            $blocked_domains = apply_filters( 'pmcpc_blocked_email_domains', $blocked_domains, $domain, $email );

    

            if ( in_array( $domain, $blocked_domains, true ) ) {

                return true;

            }

    

            // Also treat sub‑domains of mail.ru as blocked (e.g. something.mail.ru).

            if ( preg_match( '/(^|\.)mail\.ru$/', $domain ) ) {

                return true;

            }

    

            // Optionally treat domains with no valid DNS (MX or A records) as blocked as well.

            // This helps catch obvious typos or non-existent domains while still allowing site owners

            // to disable the check via the pmcpc_check_email_domain_mx filter.

            $check_mx = apply_filters( 'pmcpc_check_email_domain_mx', true, $domain, $email );

            if ( $check_mx && function_exists( 'checkdnsrr' ) ) {

                $has_mx_or_a = checkdnsrr( $domain, 'MX' ) || checkdnsrr( $domain, 'A' );

                if ( ! $has_mx_or_a ) {

                    return true;

                }

            }

    

            /**

             * Final chance to override whether a domain is blocked.

             *

             * @param bool   $is_blocked True if the email should be treated as blocked.

             * @param string $domain     The domain part of the email address.

             * @param string $email      The full email address.

             */

            $is_blocked = apply_filters( 'pmcpc_is_blocked_email_domain', false, $domain, $email );

    

            return (bool) $is_blocked;

        }

    

        public static function init() {

            // Current shortcode namespace.

            add_shortcode( 'pmcpc_subscribe', array( __CLASS__, 'render_subscribe_form' ) );

            add_shortcode( 'pmcpc_email_preferences', array( __CLASS__, 'render_email_preferences' ) );

            add_shortcode( 'pmcpc_checkout_optin', array( __CLASS__, 'render_checkout_optin' ) );

            add_shortcode( 'pmcpc_contact_form', array( __CLASS__, 'render_contact_form' ) );

            add_shortcode( 'pmcpc_selling_form', array( __CLASS__, 'render_selling_form' ) );

            add_shortcode( 'pmcpc_form', array( __CLASS__, 'render_dynamic_form' ) );

            add_shortcode( 'pmcpc_sub_updates', array( __CLASS__, 'render_subscriber_updates' ) );

            add_shortcode( 'pmcpc_subscriber_updates', array( __CLASS__, 'render_subscriber_updates' ) );

    

            add_action( 'wp_loaded', array( __CLASS__, 'handle_form_submission' ) );

            add_action( 'init', array( __CLASS__, 'maybe_handle_subscriber_update_unlock' ) );

            add_action( 'template_redirect', array( __CLASS__, 'maybe_handle_subscriber_update_cta' ) );

            add_filter( 'the_content', array( __CLASS__, 'filter_subscriber_update_content' ), 20 );

            add_filter( 'login_message', array( __CLASS__, 'login_message' ) );

            add_filter( 'pmcpc_blocked_email_domains', array( __CLASS__, 'filter_blocked_email_domains' ), 10, 3 );

    		add_filter( 'pmcpc_check_email_domain_mx', array( __CLASS__, 'filter_check_email_domain_mx' ), 10, 3 );

        }

    

    

        /**

         * Merge user-configured blocked domains from settings into the base list.

         *

         * @param array  $blocked_domains Default blocked domains.

         * @param string $domain          The domain part of the email address.

         * @param string $email           The full email address.

         * @return array

         */

    /**

         * Merge user-configured blocked domains from settings into the base list.

         *

         * @param array  $blocked_domains Default blocked domains.

         * @param string $domain          The domain part of the email address.

         * @param string $email           The full email address.

         * @return array

         */

        public static function filter_blocked_email_domains( $blocked_domains, $domain, $email ) {

            $extra = '';

    

            if ( class_exists( 'PMCPC_Settings' ) ) {

                $extra = PMCPC_Settings::get( 'blocked_email_domains', '' );

            } else {

                $extra = get_option( 'pmcpc_blocked_email_domains', '' );

            }

    

            if ( ! empty( $extra ) ) {

                $lines = preg_split( '/\r\n|\r|\n/', (string) $extra );

                if ( is_array( $lines ) ) {

                    foreach ( $lines as $line ) {

                        $line = strtolower( trim( $line ) );

                        if ( '' === $line ) {

                            continue;

                        }

                        if ( ! in_array( $line, $blocked_domains, true ) ) {

                            $blocked_domains[] = $line;

                        }

                    }

                }

            }

    

            return $blocked_domains;

        }

    

    	/**

    	 * Toggle DNS (MX/A) validation from Spam protection settings.

    	 *

    	 * @param bool   $check  Whether to perform MX/A checks.

    	 * @param string $domain Email domain.

    	 * @param string $context Context (subscribe/contact/selling).

    	 * @return bool

    	 */

    /**

    	 * Toggle DNS (MX/A) validation from Spam protection settings.

    	 *

    	 * @param bool   $check  Whether to perform MX/A checks.

    	 * @param string $domain Email domain.

    	 * @param string $context Context (subscribe/contact/selling).

    	 * @return bool

    	 */

    	public static function filter_check_email_domain_mx( $check, $domain, $context ) {

    		if ( ! class_exists( 'PMCPC_Settings' ) ) {

    			return $check;

    		}

    		$enabled = PMCPC_Settings::get( 'spam_email_dns_enabled', 'yes' );

    		if ( 'yes' !== $enabled ) {

    			return false;

    		}

    		return $check;

    	}

    

    

        /**

         * Custom message on the WordPress login screen when users are coming from an email-subscription flow.

         *

         * @param string $message Existing login message HTML.

         * @return string

         */

    /**

         * Custom message on the WordPress login screen when users are coming from an email-subscription flow.

         *

         * @param string $message Existing login message HTML.

         * @return string

         */

        public static function login_message( $message ) {

    		// This flag only controls whether a message is displayed; it does not change server state.

    		// phpcs:ignore WordPress.Security.NonceVerification.Recommended

    		if ( ! isset( $_GET['pmcpc_email_login'] ) ) {

    			return $message;

    		}

    

    		// phpcs:ignore WordPress.Security.NonceVerification.Recommended

    		$status = isset( $_GET['pmcpc_status'] ) ? sanitize_key( (string) wp_unslash( $_GET['pmcpc_status'] ) ) : '';

    		$shop_url = home_url( '/' );

    		if ( function_exists( 'wc_get_page_permalink' ) ) {

    			$maybe_shop = wc_get_page_permalink( 'shop' );

    			if ( $maybe_shop ) {

    				$shop_url = $maybe_shop;

    			}

    		}

    

    		$extra = '';

    		switch ( $status ) {

    			case 'confirmed':

    				$extra .= '<p class="message">' . esc_html__( "You're all set! Your email has been confirmed.", 'product-mailer-campaigns' ) . '</p>';

    				$extra .= '<p><a class="button" href="' . esc_url( $shop_url ) . '">' . esc_html__( 'Continue to shop', 'product-mailer-campaigns' ) . '</a></p>';

    				break;

    			case 'already_confirmed':

    				$extra .= '<p class="message">' . esc_html__( "You're already subscribed — nothing else to do.", 'product-mailer-campaigns' ) . '</p>';

    				$extra .= '<p><a class="button" href="' . esc_url( $shop_url ) . '">' . esc_html__( 'Continue to shop', 'product-mailer-campaigns' ) . '</a></p>';

    				break;

    			case 'expired':

    				$extra .= '<p class="message">' . esc_html__( 'This confirmation link has expired. Please sign up again and we\'ll send you a fresh link.', 'product-mailer-campaigns' ) . '</p>';

    				$extra .= '<p><a class="button" href="' . esc_url( $shop_url ) . '">' . esc_html__( 'Go to the site', 'product-mailer-campaigns' ) . '</a></p>';

    				break;

    			case 'invalid':

    				$extra .= '<p class="message">' . esc_html__( "That confirmation link didn't work. Please use the link from your email, or sign up again to receive a new one.", 'product-mailer-campaigns' ) . '</p>';

    				$extra .= '<p><a class="button" href="' . esc_url( $shop_url ) . '">' . esc_html__( 'Go to the site', 'product-mailer-campaigns' ) . '</a></p>';

    				break;

    			default:

    				$extra .= '<p class="message">' . esc_html__( 'Please log in to manage your email subscriptions.', 'product-mailer-campaigns' ) . '</p>';

    				break;

    		}

    

    		return $extra . $message;

        }

    

    	/**

    	 * Build the Email & Login destination URL for confirmation results.

    	 *

    	 * Uses wp-login.php so we can display a user-friendly notice without dying

    	 * on the confirmation handler page.

    	 *

    	 * @param string $status Status key.

    	 * @return string

    	 */

    /**

    	 * Build the Email & Login destination URL for confirmation results.

    	 *

    	 * Uses wp-login.php so we can display a user-friendly notice without dying

    	 * on the confirmation handler page.

    	 *

    	 * @param string $status Status key.

    	 * @return string

    	 */

    	private static function get_email_login_destination_url( $status ) {

    		// Public-facing status page (no login required).

    		$status = sanitize_key( (string) $status );

    		$dest   = apply_filters( 'pmcpc_confirm_status_url', home_url( '/' ), $status );

    		$args   = array(

    			'pmcpc_public_status' => $status,

    		);

    		return add_query_arg( $args, $dest );

    	}

    

    

        /**

         * Load dynamic form settings from a posted pmcpc_form_id.

         *

         * @param string $expected_type contact|selling|subscribe

         * @return array { id:int, settings:array }

         */

    /**

         * Load dynamic form settings from a posted pmcpc_form_id.

         *

         * @param string $expected_type contact|selling|subscribe

         * @return array { id:int, settings:array }

         */

        private static function get_posted_dynamic_form_settings( $expected_type ) {

            $expected_type = sanitize_key( (string) $expected_type );

    

            // phpcs:ignore WordPress.Security.NonceVerification.Missing

            $form_id = isset( $_POST['pmcpc_form_id'] ) ? absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 0;

            if ( ! $form_id || ! class_exists( 'PMCPC_Forms' ) ) {

                return array( 'id' => 0, 'settings' => array() );

            }

    

            $form = PMCPC_Forms::get_form( $form_id );

            if ( ! $form ) {

                return array( 'id' => 0, 'settings' => array() );

            }

    

            $type = isset( $form['type'] ) ? sanitize_key( (string) $form['type'] ) : '';

            if ( $expected_type ) {

                $aliases = array(

                    'contact' => array( 'contact', 'review', 'product_review' ),

                    'review'  => array( 'review', 'product_review' ),

                );

                $allowed = isset( $aliases[ $expected_type ] ) ? $aliases[ $expected_type ] : array( $expected_type );

                if ( ! in_array( $type, $allowed, true ) ) {

                    return array( 'id' => 0, 'settings' => array() );

                }

            }

    

            $settings = ( isset( $form['settings'] ) && is_array( $form['settings'] ) ) ? $form['settings'] : array();

            return array(

                'id'       => $form_id,

                'settings' => $settings,

            );

        }

    

        /**

         * Build a success message HTML wrapper. Uses settings['success_message'] when provided.

         *

         * @param string $fallback_text Plain-text fallback.

         * @param array  $settings Settings array.

         * @return string HTML

         */

    /**

         * Build a success message HTML wrapper. Uses settings['success_message'] when provided.

         *

         * @param string $fallback_text Plain-text fallback.

         * @param array  $settings Settings array.

         * @return string HTML

         */

        private static function build_success_message_html( $fallback_text, $settings ) {

            $msg = '';

            if ( is_array( $settings ) && ! empty( $settings['success_message'] ) ) {

                $msg = (string) $settings['success_message'];

            }

    

            $body_html = '';

            if ( '' === trim( wp_strip_all_tags( $msg ) ) ) {

                $body_html = '<p>' . esc_html( (string) $fallback_text ) . '</p>';

            } else {

                // Allow site owners to include basic formatting in the custom message.

                $body_html = wp_kses_post( $msg );

                // If message is plain text, wrap it for consistent spacing.

                if ( $body_html === esc_html( wp_strip_all_tags( $body_html ) ) ) {

                    $body_html = '<p>' . $body_html . '</p>';

                }

            }

    

            return '<div class="pmcpc-message pmcpc-success" data-pmcpc-success="1" role="status" aria-live="polite">'

                . '<div class="pmcpc-message-title">' . esc_html__( 'Thank you', 'product-mailer-campaigns' ) . '</div>'

                . '<div class="pmcpc-message-body">' . $body_html . '</div>'

                . '</div>';

        }

    

        private static function build_error_message_html( $fallback_text, $settings ) {

            $body_html = '<p>' . esc_html( (string) $fallback_text ) . '</p>';

            return '<div class="pmcpc-message pmcpc-error" role="alert" aria-live="assertive">'

                . '<div class="pmcpc-message-title">' . esc_html__( 'Please check', 'product-mailer-campaigns' ) . '</div>'

                . '<div class="pmcpc-message-body">' . $body_html . '</div>'

                . '</div>';

        }

    

    

        

        /**

         * Collect additional/custom field values and uploaded files (dynamic forms only).

         *

         * Returns array with:

         *  - body_lines (array of strings)

         *  - attachments (array of file paths)

         *

         * @param array  $settings Form settings.

         * @param string $context  contact|selling

         * @return array

         */

    /**

         * Collect additional/custom field values and uploaded files (dynamic forms only).

         *

         * Returns array with:

         *  - body_lines (array of strings)

         *  - attachments (array of file paths)

         *

         * @param array  $settings Form settings.

         * @param string $context  contact|selling

         * @return array

         */

        private static function collect_custom_fields_payload( $settings, $context ) {

            $context = sanitize_key( (string) $context );

    

            $out = array(

                'body_lines'  => array(),

                'attachments' => array(),

            );

    

            if ( ! is_array( $settings ) || empty( $settings['custom_fields'] ) || ! is_array( $settings['custom_fields'] ) ) {

                return $out;

            }

    

            if ( class_exists( 'PMCPC_Forms' ) ) {

                $custom_fields = PMCPC_Forms::sanitize_custom_fields( $settings['custom_fields'] );

            } else {

                $custom_fields = $settings['custom_fields'];

            }

    

            // Upload handling helpers.

            if ( ! function_exists( 'wp_handle_upload' ) ) {

                require_once ABSPATH . 'wp-admin/includes/file.php';

            }

    

            $allowed_mimes = array(

                'jpg'  => 'image/jpeg',

                'jpeg' => 'image/jpeg',

                'png'  => 'image/png',

                'webp' => 'image/webp',

                'pdf'  => 'application/pdf',

            );

    

            foreach ( $custom_fields as $cf ) {

                if ( ! is_array( $cf ) ) {

                    continue;

                }

                $enabled = isset( $cf['enabled'] ) ? (string) $cf['enabled'] : 'yes';

                if ( 'no' === $enabled ) {

                    continue;

                }

    

                $key  = isset( $cf['key'] ) ? sanitize_key( (string) $cf['key'] ) : '';

                $type = isset( $cf['type'] ) ? sanitize_key( (string) $cf['type'] ) : 'text';

                $label = isset( $cf['label'] ) ? sanitize_text_field( (string) $cf['label'] ) : $key;

    

                if ( '' === $key ) {

                    continue;

                }

    

                $name = 'pmcpc_cf_' . $key;

    

                if ( 'file' === $type ) {

                    $max_files = isset( $cf['max_files'] ) ? absint( $cf['max_files'] ) : 5;

                    if ( $max_files < 1 ) {

                        $max_files = 1;

                    }

                    if ( $max_files > 10 ) {

                        $max_files = 10;

                    }

    

    			if ( empty( $_FILES[ $name ] ) || ! is_array( $_FILES[ $name ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

                        continue;

                    }

    

    			$files = $_FILES[ $name ]; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

    

                    // Normalize multi-upload structure.

                    $count = 0;

                    $filenames = array();

    

                    $is_multi = is_array( $files['name'] );

                    $total = $is_multi ? count( $files['name'] ) : 1;

    

                    for ( $i = 0; $i < $total; $i++ ) {

                        if ( $count >= $max_files ) {

                            break;

                        }

    

                        $file = array(

                            'name'     => $is_multi ? $files['name'][ $i ] : $files['name'],

                            'type'     => $is_multi ? $files['type'][ $i ] : $files['type'],

                            'tmp_name' => $is_multi ? $files['tmp_name'][ $i ] : $files['tmp_name'],

                            'error'    => $is_multi ? $files['error'][ $i ] : $files['error'],

                            'size'     => $is_multi ? $files['size'][ $i ] : $files['size'],

                        );

    

                        if ( empty( $file['name'] ) ) {

                            continue;

                        }

                        if ( ! empty( $file['error'] ) ) {

                            continue;

                        }

                        if ( ! empty( $file['size'] ) && (int) $file['size'] > 5 * 1024 * 1024 ) { // 5MB

                            continue;

                        }

    

                        $ext = strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) );

                        if ( ! isset( $allowed_mimes[ $ext ] ) ) {

                            continue;

                        }

    

                        $upload = wp_handle_upload(

                            $file,

                            array(

                                'test_form' => false,

                                'mimes'     => $allowed_mimes,

                            )

                        );

    

                        if ( isset( $upload['file'] ) && is_string( $upload['file'] ) && file_exists( $upload['file'] ) ) {

                            $out['attachments'][] = $upload['file'];

                            $filenames[] = basename( $upload['file'] );

                            $count++;

                        }

                    }

    

                    if ( ! empty( $filenames ) ) {

                        $out['body_lines'][] = $label . ': ' . implode( ', ', $filenames );

                    }

    

                    continue;

                }

    

                // Text/textarea fields.

    // phpcs:ignore WordPress.Security.NonceVerification.Missing

    $val = '';

    if ( 'textarea' === $type ) {

    		$val = isset( $_POST[ $name ] ) ? trim( sanitize_textarea_field( (string) wp_unslash( $_POST[ $name ] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

    } else {

    		$val = isset( $_POST[ $name ] ) ? trim( sanitize_text_field( (string) wp_unslash( $_POST[ $name ] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

    }

    

                if ( '' !== $val ) {

                    $out['body_lines'][] = $label . ': ' . $val;

                }

            }

    

            return $out;

        }

    

    	/**

    	 * Best-effort page context for a form submission.

    	 *

    	 * We prefer explicit hidden inputs (most reliable), then fall back to the HTTP referrer.

    	 *

    	 * @return array{url:string,title:string,post_id:int}

    	 */

    /**

    	 * Best-effort page context for a form submission.

    	 *

    	 * We prefer explicit hidden inputs (most reliable), then fall back to the HTTP referrer.

    	 *

    	 * @return array{url:string,title:string,post_id:int}

    	 */

    	private static function get_posted_page_context() {

    		// phpcs:ignore WordPress.Security.NonceVerification.Missing

    		$url   = isset( $_POST['pmcpc_page_url'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_page_url'] ) ) : '';

    		// phpcs:ignore WordPress.Security.NonceVerification.Missing

    		$title = isset( $_POST['pmcpc_page_title'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_page_title'] ) ) : '';

    

    		if ( ! $url ) {

    			$url = wp_get_referer();

    			if ( $url ) {

    				$url = esc_url_raw( $url );

    			}

    		}

    

    

    		// phpcs:ignore WordPress.Security.NonceVerification.Missing

    		$post_id = isset( $_POST['pmcpc_post_id'] ) ? absint( wp_unslash( $_POST['pmcpc_post_id'] ) ) : 0;

    

    		return array(

    			'url'     => is_string( $url ) ? $url : '',

    			'title'   => is_string( $title ) ? $title : '',

    			'post_id' => $post_id,

    		);

    	}

    

    	/**

    	 * Current page context for rendering hidden inputs.

    	 *

    	 * @return array{url:string,title:string,post_id:int}

    	 */

    /**

    	 * Current page context for rendering hidden inputs.

    	 *

    	 * @return array{url:string,title:string,post_id:int}

    	 */

    	private static function get_current_page_context() {

    		$url = '';

    		if ( function_exists( 'is_singular' ) && is_singular() && function_exists( 'get_permalink' ) ) {

    			$url = get_permalink();

    		}

    		if ( ! $url ) {

    			$url = home_url( add_query_arg( array(), '' ) );

    		}

    

    		$title = '';

    		if ( function_exists( 'is_singular' ) && is_singular() && function_exists( 'get_the_title' ) ) {

    			$title = (string) get_the_title();

    		}

    		if ( '' === trim( $title ) && function_exists( 'wp_get_document_title' ) ) {

    			$title = (string) wp_get_document_title();

    		}

    

    		return array(

    			'url'     => esc_url_raw( (string) $url ),

    			'title'   => sanitize_text_field( (string) $title ),

    			'post_id' => ( function_exists( 'get_the_ID' ) && function_exists( 'is_singular' ) && is_singular() ) ? (int) get_the_ID() : 0,

    		);

    	}

    

    	/**

    	 * If a form submission came from a WooCommerce product page, return helpful product metadata.

    	 *

    	 * @param int $post_id Post ID from page context.

    	 * @return string[] Lines to append to an email body.

    	 */

    /**

    	 * If a form submission came from a WooCommerce product page, return helpful product metadata.

    	 *

    	 * @param int $post_id Post ID from page context.

    	 * @return string[] Lines to append to an email body.

    	 */

    	private static function build_product_context_lines( $post_id ) {

		$post_id = absint( $post_id );

		if ( ! $post_id ) {

			return array();

		}

		$woocommerce_ready = function_exists( 'wc_get_product' )
			&& function_exists( 'did_action' )
			&& did_action( 'woocommerce_init' )
			&& did_action( 'woocommerce_after_register_taxonomy' )
			&& did_action( 'woocommerce_after_register_post_type' );

		if ( $woocommerce_ready ) {

			$product = wc_get_product( $post_id );

			if ( $product ) {

				$lines   = array();
				/* translators: %d: WooCommerce product ID. */
				$lines[] = sprintf( __( 'Product ID: %d', 'product-mailer-campaigns' ), (int) $product->get_id() );

				$sku = $product->get_sku();
				if ( $sku ) {
					/* translators: %s: product SKU. */
					$lines[] = sprintf( __( 'SKU: %s', 'product-mailer-campaigns' ), $sku );
				}

				// Categories.
				if ( function_exists( 'wc_get_product_category_list' ) ) {
					$cats_html = wc_get_product_category_list( $product->get_id(), ', ' );
					$cats      = trim( wp_strip_all_tags( (string) $cats_html ) );
					if ( $cats ) {
						/* translators: %s: product categories list. */
						$lines[] = sprintf( __( 'Category: %s', 'product-mailer-campaigns' ), $cats );
					}
				}

				// Price (best effort, plain text).
				$raw_price = $product->get_price();
				if ( '' !== $raw_price && null !== $raw_price ) {
					$price_text = '';
					if ( function_exists( 'wc_price' ) ) {
						$price_text = trim( wp_strip_all_tags( (string) wc_price( $raw_price ) ) );
					}
					if ( '' === $price_text ) {
						$price_text = trim( wp_strip_all_tags( (string) $product->get_price_html() ) );
					}
					if ( $price_text ) {
						/* translators: %s: product price. */
						$lines[] = sprintf( __( 'Price: %s', 'product-mailer-campaigns' ), $price_text );
					}
				}

				// Stock status.
				$stock_status = method_exists( $product, 'get_stock_status' ) ? (string) $product->get_stock_status() : '';
				if ( $stock_status ) {
					$labels = array(
						'instock'     => __( 'In stock', 'product-mailer-campaigns' ),
						'outofstock'  => __( 'Out of stock', 'product-mailer-campaigns' ),
						'onbackorder' => __( 'On backorder', 'product-mailer-campaigns' ),
					);
					$stock_text = isset( $labels[ $stock_status ] ) ? $labels[ $stock_status ] : $stock_status;
					/* translators: %s: stock status label. */
					$lines[]    = sprintf( __( 'Stock: %s', 'product-mailer-campaigns' ), $stock_text );
				}

				return $lines;

			}

		}

		// Fallback for early form handling: avoid WooCommerce product APIs until WooCommerce is ready.
		if ( function_exists( 'get_post_type' ) && 'product' !== get_post_type( $post_id ) ) {

			return array();

		}

		$lines   = array();
		/* translators: %d: WooCommerce product ID. */
		$lines[] = sprintf( __( 'Product ID: %d', 'product-mailer-campaigns' ), (int) $post_id );

		$sku = function_exists( 'get_post_meta' ) ? get_post_meta( $post_id, '_sku', true ) : '';
		if ( '' !== $sku && null !== $sku ) {
			/* translators: %s: product SKU. */
			$lines[] = sprintf( __( 'SKU: %s', 'product-mailer-campaigns' ), trim( wp_strip_all_tags( (string) $sku ) ) );
		}

		$terms = function_exists( 'get_the_terms' ) ? get_the_terms( $post_id, 'product_cat' ) : false;
		if ( ! is_wp_error( $terms ) && ! empty( $terms ) && is_array( $terms ) ) {
			$cats = array();
			foreach ( $terms as $term ) {
				if ( isset( $term->name ) ) {
					$cats[] = $term->name;
				}
			}
			if ( ! empty( $cats ) ) {
				/* translators: %s: product categories list. */
				$lines[] = sprintf( __( 'Category: %s', 'product-mailer-campaigns' ), implode( ', ', $cats ) );
			}
		}

		$raw_price = function_exists( 'get_post_meta' ) ? get_post_meta( $post_id, '_price', true ) : '';
		if ( '' !== $raw_price && null !== $raw_price ) {
			$price_text = trim( wp_strip_all_tags( (string) $raw_price ) );
			if ( $price_text ) {
				/* translators: %s: product price. */
				$lines[] = sprintf( __( 'Price: %s', 'product-mailer-campaigns' ), $price_text );
			}
		}

		$stock_status = function_exists( 'get_post_meta' ) ? (string) get_post_meta( $post_id, '_stock_status', true ) : '';
		if ( $stock_status ) {
			$labels = array(
				'instock'     => __( 'In stock', 'product-mailer-campaigns' ),
				'outofstock'  => __( 'Out of stock', 'product-mailer-campaigns' ),
				'onbackorder' => __( 'On backorder', 'product-mailer-campaigns' ),
			);
			$stock_text = isset( $labels[ $stock_status ] ) ? $labels[ $stock_status ] : $stock_status;
			/* translators: %s: stock status label. */
			$lines[]    = sprintf( __( 'Stock: %s', 'product-mailer-campaigns' ), $stock_text );
		}

		return $lines;

	}
}
