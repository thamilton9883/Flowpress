<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Inbox_Helper_Methods {

        /**
         * Render a standard inbox admin notice.
         *
         * @param string $type        Notice type.
         * @param string $message     Notice message.
         * @param bool   $dismissible Whether the notice is dismissible.
         * @return void
         */
        protected static function render_inbox_notice( $type, $message, $dismissible = false ) {
            $classes = array( 'notice', 'notice-' . sanitize_html_class( $type ) );

            if ( $dismissible ) {
                $classes[] = 'is-dismissible';
            }

            echo '<div class="' . esc_attr( implode( ' ', $classes ) ) . '"><p>' . esc_html( $message ) . '</p></div>';
        }

        /**
         * Check whether the spam submissions table exists.
         *
         * @param wpdb   $wpdb  WordPress DB instance.
         * @param string $table Inbox table name.
         * @return bool
         */


        /**
         * Check whether the spam submissions table exists.
         *
         * @param wpdb   $wpdb  WordPress DB instance.
         * @param string $table Inbox table name.
         * @return bool
         */
        protected static function inbox_table_exists( $wpdb, $table ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            return ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
        }

        /**
         * Parse request values used by the inbox page.
         *
         * @return array<string,int|string>
         */


        /**
         * Parse request values used by the inbox page.
         *
         * @return array<string,int|string>
         */
        protected static function get_inbox_request_data() {
            return array(
                'view_id'        => isset( $_GET['pmcpc_view_id'] ) ? absint( $_GET['pmcpc_view_id'] ) : 0, // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
                'mark_all'       => isset( $_GET['pmcpc_mark_all_read'] ) ? absint( $_GET['pmcpc_mark_all_read'] ) : 0, // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Verified separately.
                'mark_all_nonce' => isset( $_GET['_pmcpc_mark_all_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_pmcpc_mark_all_nonce'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Verified separately.
                'notice'         => isset( $_GET['pmcpc_notice'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_notice'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
                'notice_type'    => isset( $_GET['pmcpc_notice_type'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_notice_type'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
                'notice_text'    => isset( $_GET['pmcpc_notice_text'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_notice_text'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
                'action'         => isset( $_GET['pmcpc_action'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_action'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Verified separately.
                'submission_id'  => isset( $_GET['pmcpc_submission_id'] ) ? absint( $_GET['pmcpc_submission_id'] ) : 0, // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Verified separately.
                'action_nonce'   => isset( $_GET['_pmcpc_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_pmcpc_nonce'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Verified separately.
            );
        }

        /**
         * Parse the current inbox queue filters from the request.
         *
         * @return array<string,int|string>
         */


        /**
         * Parse the current inbox queue filters from the request.
         *
         * @return array<string,int|string>
         */
        protected static function get_inbox_filter_state() {
            $status_raw = isset( $_GET['pmcpc_status'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_status'] ) ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
            $status_raw = strtolower( preg_replace( '/[^a-z0-9_\-]/', '', $status_raw ) );
            $status     = ( '' === $status_raw ) ? 'all' : $status_raw;
            if ( ! in_array( $status, array( 'all', 'allowed', 'held', 'blocked', 'released', 'banned' ), true ) ) {
                $status = 'all';
            }

            $context_raw = isset( $_GET['pmcpc_context'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_context'] ) ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
            $context_raw = strtolower( preg_replace( '/[^a-z0-9_\-]/', '', $context_raw ) );
            $context     = ( '' === $context_raw ) ? 'all' : $context_raw;
            if ( ! in_array( $context, array( 'all', 'contact', 'selling', 'subscribe', 'checkout' ), true ) ) {
                $context = 'all';
            }

            $reason_filter = isset( $_GET['pmcpc_reason'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_reason'] ) ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
            $reason_filter = strtolower( preg_replace( '/[^a-z0-9_\-]/', '', $reason_filter ) );
            $reason_filter = ( '' === $reason_filter ) ? 'all' : $reason_filter;

            $search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
            $paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.

            return array(
                'status' => $status,
                'context' => $context,
                'reason_filter' => $reason_filter,
                'search' => $search,
                'paged' => $paged,
            );
        }

        /**
         * Convert inbox filter state into query args.
         *
         * @param array<string,int|string> $filter_state Current filter state.
         * @param bool                     $include_paged Whether to preserve pagination.
         * @return array<string,int|string>
         */


        /**
         * Convert inbox filter state into query args.
         *
         * @param array<string,int|string> $filter_state Current filter state.
         * @param bool                     $include_paged Whether to preserve pagination.
         * @return array<string,int|string>
         */
        protected static function get_inbox_filter_query_args( $filter_state, $include_paged = true ) {
            $args = array();

            if ( ! empty( $filter_state['status'] ) && 'all' !== $filter_state['status'] ) {
                $args['pmcpc_status'] = (string) $filter_state['status'];
            }
            if ( ! empty( $filter_state['context'] ) && 'all' !== $filter_state['context'] ) {
                $args['pmcpc_context'] = (string) $filter_state['context'];
            }
            if ( ! empty( $filter_state['reason_filter'] ) && 'all' !== $filter_state['reason_filter'] ) {
                $args['pmcpc_reason'] = (string) $filter_state['reason_filter'];
            }
            if ( ! empty( $filter_state['search'] ) ) {
                $args['s'] = (string) $filter_state['search'];
            }
            if ( $include_paged && ! empty( $filter_state['paged'] ) && (int) $filter_state['paged'] > 1 ) {
                $args['paged'] = (int) $filter_state['paged'];
            }

            return $args;
        }

        /**
         * Find the next inbox submission id in the current filtered queue.
         *
         * @param wpdb                    $wpdb         WordPress DB instance.
         * @param string                  $table        Inbox table name.
         * @param int                     $current_id   Current submission id.
         * @param array<string,int|string> $filter_state Current filter state.
         * @return int
         */


        /**
         * Find the next inbox submission id in the current filtered queue.
         *
         * @param wpdb                    $wpdb         WordPress DB instance.
         * @param string                  $table        Inbox table name.
         * @param int                     $current_id   Current submission id.
         * @param array<string,int|string> $filter_state Current filter state.
         * @return int
         */
        protected static function get_next_inbox_submission_id( $wpdb, $table, $current_id, $filter_state ) {
            $where_parts = array( 'status != %s' );
            $where_args  = array( 'discarded' );

            if ( ! empty( $filter_state['status'] ) && 'all' !== $filter_state['status'] ) {
                $status = (string) $filter_state['status'];
                if ( 'blocked' === $status ) {
                    $where_parts[] = 'status = %s';
                    $where_args[]  = 'blocked';
                } elseif ( 'banned' === $status ) {
                    $where_parts[] = '(status = %s OR status = %s)';
                    $where_args[]  = 'blocked';
                    $where_args[]  = 'discarded';
                } elseif ( 'held' === $status ) {
                    $where_parts[] = 'status = %s';
                    $where_args[]  = 'held';
                } else {
                    $where_parts[] = 'status = %s';
                    $where_args[]  = $status;
                }
            }

            if ( ! empty( $filter_state['context'] ) && 'all' !== $filter_state['context'] ) {
                $where_parts[] = 'context = %s';
                $where_args[]  = (string) $filter_state['context'];
            }

            if ( ! empty( $filter_state['reason_filter'] ) && 'all' !== $filter_state['reason_filter'] ) {
                $where_parts[] = 'reason LIKE %s';
                $where_args[]  = '%' . $wpdb->esc_like( (string) $filter_state['reason_filter'] ) . '%';
            }

            if ( ! empty( $filter_state['search'] ) ) {
                $search_like   = '%' . $wpdb->esc_like( (string) $filter_state['search'] ) . '%';
                $where_parts[] = '(email LIKE %s OR subject LIKE %s OR message LIKE %s)';
                $where_args[]  = $search_like;
                $where_args[]  = $search_like;
                $where_args[]  = $search_like;
            }

            $where_sql = implode( ' AND ', $where_parts );
            $sql       = "SELECT id FROM {$table} WHERE {$where_sql} AND id > %d ORDER BY id ASC LIMIT 1"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $args      = array_merge( $where_args, array( $current_id ) );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
            return (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) );
        }

        /**
         * Redirect after an inbox action while preserving queue context.
         *
         * @param wpdb                     $wpdb          WordPress DB instance.
         * @param string                   $table         Inbox table name.
         * @param int                      $current_id    Current submission id.
         * @param array<string,int|string> $filter_state  Current filter state.
         * @param string                   $notice_type   Notice type.
         * @param string                   $notice_text   Notice text.
         * @param bool                     $prefer_next   Whether to open the next matching item when possible.
         * @return void
         */


        /**
         * Redirect after an inbox action while preserving queue context.
         *
         * @param wpdb                     $wpdb          WordPress DB instance.
         * @param string                   $table         Inbox table name.
         * @param int                      $current_id    Current submission id.
         * @param array<string,int|string> $filter_state  Current filter state.
         * @param string                   $notice_type   Notice type.
         * @param string                   $notice_text   Notice text.
         * @param bool                     $prefer_next   Whether to open the next matching item when possible.
         * @return void
         */
        protected static function redirect_after_inbox_action( $wpdb, $table, $current_id, $filter_state, $notice_type, $notice_text, $prefer_next = false ) {
            $args = array_merge(
                array(
                    'page'              => 'pmcpc_inbox',
                    'pmcpc_notice_type' => sanitize_key( $notice_type ),
                    'pmcpc_notice_text' => $notice_text,
                ),
                self::get_inbox_filter_query_args( $filter_state )
            );

            if ( $prefer_next ) {
                $next_id = self::get_next_inbox_submission_id( $wpdb, $table, (int) $current_id, $filter_state );
                if ( $next_id > 0 ) {
                    $args['pmcpc_view_id'] = $next_id;
                } else {
                    $args['pmcpc_notice_text'] = $notice_text . ' ' . __( 'No more matching messages remain in this view.', 'product-mailer-campaigns' );
                }
            }

            wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
            exit;
        }

        /**
         * Handle the "mark all read" inbox action.
         *
         * @param wpdb   $wpdb      WordPress DB instance.
         * @param string $table     Inbox table name.
         * @param int    $mark_all  Mark-all flag.
         * @param string $nonce     Mark-all nonce.
         * @return void
         */


        /**
         * Render inbox notices driven by redirect query args.
         *
         * @param string $notice Notice key.
         * @return void
         */
        protected static function render_inbox_result_notice( $notice ) {
            $request_notice_type = isset( $_GET['pmcpc_notice_type'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_notice_type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
            $request_notice_text = isset( $_GET['pmcpc_notice_text'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_notice_text'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.

            if ( $request_notice_type && $request_notice_text ) {
                self::render_inbox_notice( $request_notice_type, $request_notice_text, true );
                return;
            }

            if ( 'submission_deleted' === $notice ) {
                self::render_inbox_notice( 'success', __( 'Submission deleted.', 'product-mailer-campaigns' ), true );
            }
        }

        /**
         * Build default plain-text email headers for inbox/admin emails.
         *
         * @param string $reply_to Optional reply-to address.
         * @return array
         */


        /**
         * Build default plain-text email headers for inbox/admin emails.
         *
         * @param string $reply_to Optional reply-to address.
         * @return array
         */
        protected static function get_inbox_email_headers( $reply_to = '' ) {
            $headers   = array();
            $headers[] = 'Content-Type: text/plain; charset=UTF-8';

            $from_name  = get_bloginfo( 'name' );
            $from_email = get_option( 'admin_email' );

            if ( class_exists( 'PMCPC_Settings' ) ) {
                $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );
                $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );

                if ( is_string( $from_name_setting ) && '' !== trim( $from_name_setting ) ) {
                    $from_name = $from_name_setting;
                }
                if ( is_string( $from_email_setting ) && is_email( $from_email_setting ) ) {
                    $from_email = $from_email_setting;
                }
            }

            $headers[] = 'From: ' . sprintf( '%s <%s>', wp_specialchars_decode( $from_name, ENT_QUOTES ), sanitize_email( $from_email ) );

            if ( ! empty( $reply_to ) ) {
                $headers[] = 'Reply-To: ' . sanitize_email( $reply_to );
            }

            return $headers;
        }

        /**
         * Send an inbox submission to the configured admin email.
         *
         * @param object $submission Inbox submission row.
         * @return bool
         */

}
