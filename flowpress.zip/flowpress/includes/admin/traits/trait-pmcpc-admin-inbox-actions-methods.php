<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Inbox_Actions_Methods {

        /**
         * Handle the "mark all read" inbox action.
         *
         * @param wpdb   $wpdb      WordPress DB instance.
         * @param string $table     Inbox table name.
         * @param int    $mark_all  Mark-all flag.
         * @param string $nonce     Mark-all nonce.
         * @return void
         */
        protected static function maybe_handle_mark_all_read( $wpdb, $table, $mark_all, $nonce ) {
            if ( 1 !== (int) $mark_all || empty( $nonce ) || ! wp_verify_nonce( $nonce, 'pmcpc_mark_all_read' ) ) {
                return;
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $max_id = (int) $wpdb->get_var( "SELECT MAX(id) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
            if ( $max_id > 0 ) {
                update_user_meta( get_current_user_id(), 'pmcpc_messages_last_seen_id', $max_id );
            }

            wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_inbox' ) );
            exit;
        }

        /**
         * Render inbox notices driven by redirect query args.
         *
         * @param string $notice Notice key.
         * @return void
         */


        /**
         * Send an inbox submission to the configured admin email.
         *
         * @param object $submission Inbox submission row.
         * @return bool
         */
        protected static function send_inbox_submission_to_admin( $submission ) {
            $to = get_option( 'admin_email' );

            if ( class_exists( 'PMCPC_Settings' ) ) {
                $configured = PMCPC_Settings::get( 'notify_admin_email', '' );
                if ( $configured && is_email( $configured ) ) {
                    $to = $configured;
                }
            }

            $subject = ! empty( $submission->subject ) ? (string) $submission->subject : __( 'Submission', 'product-mailer-campaigns' );
            $body    = ! empty( $submission->message ) ? (string) $submission->message : '';
            $reply_to = ! empty( $submission->email ) ? sanitize_email( (string) $submission->email ) : '';
            $headers = self::get_inbox_email_headers( $reply_to );

            return (bool) wp_mail( $to, $subject, $body, $headers );
        }

        /**
         * Start the subscription flow for an inbox submission email.
         *
         * @param string $subscriber_email Subscriber email address.
         * @param string $first_name       Optional first name.
         * @param string $last_name        Optional last name.
         * @param array  $tags             Tags to add to the subscriber.
         * @return bool
         */


        /**
         * Start the subscription flow for an inbox submission email.
         *
         * @param string $subscriber_email Subscriber email address.
         * @param string $first_name       Optional first name.
         * @param string $last_name        Optional last name.
         * @param array  $tags             Tags to add to the subscriber.
         * @return bool
         */
        protected static function start_inbox_double_optin( $subscriber_email, $first_name = '', $last_name = '', $tags = array() ) {
            $subscriber_email = sanitize_email( (string) $subscriber_email );
            if ( ! $subscriber_email || ! is_email( $subscriber_email ) || ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {
                return false;
            }

            $guest_double_optin = 'yes';
            if ( class_exists( 'PMCPC_Settings' ) ) {
                $guest_double_optin = PMCPC_Settings::get( 'guest_double_optin', 'yes' );
            }

            if ( method_exists( 'PMCPC_Subscriber_Manager', 'get_subscriber_by_email' ) ) {
                $existing = PMCPC_Subscriber_Manager::get_subscriber_by_email( $subscriber_email );
                if ( $existing && ! empty( $existing->status ) && 'active' === (string) $existing->status ) {
                    return true;
                }
            }

            if ( 'yes' !== $guest_double_optin ) {
                if ( method_exists( 'PMCPC_Subscriber_Manager', 'upsert_subscriber' ) ) {
                    PMCPC_Subscriber_Manager::upsert_subscriber( $subscriber_email, (string) $first_name, (string) $last_name, 'active' );
                }
                if ( method_exists( 'PMCPC_Subscriber_Manager', 'get_subscriber_by_email' ) && method_exists( 'PMCPC_Subscriber_Manager', 'add_tags_for_subscriber' ) ) {
                    $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $subscriber_email );
                    if ( $subscriber ) {
                        PMCPC_Subscriber_Manager::add_tags_for_subscriber( $subscriber->id, $tags );
                    }
                }
                if ( class_exists( 'PMCPC_Campaign_Manager' ) && method_exists( 'PMCPC_Campaign_Manager', 'send_welcome_campaigns_for_subscriber_email' ) ) {
                    PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $subscriber_email );
                }
                return true;
            }

            if ( method_exists( 'PMCPC_Subscriber_Manager', 'upsert_subscriber' ) ) {
                PMCPC_Subscriber_Manager::upsert_subscriber( $subscriber_email, (string) $first_name, (string) $last_name, 'pending' );
            }

            if ( method_exists( 'PMCPC_Subscriber_Manager', 'get_subscriber_by_email' ) && method_exists( 'PMCPC_Subscriber_Manager', 'add_tags_for_subscriber' ) ) {
                $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $subscriber_email );
                if ( $subscriber ) {
                    PMCPC_Subscriber_Manager::add_tags_for_subscriber( $subscriber->id, $tags );
                }
            }

            $confirm_url = '';
            if ( method_exists( 'PMCPC_Subscriber_Manager', 'build_double_optin_confirm_url' ) ) {
                $confirm_url = PMCPC_Subscriber_Manager::build_double_optin_confirm_url( $subscriber_email );
            }
            if ( empty( $confirm_url ) ) {
                $confirm_url = wp_nonce_url(
                    add_query_arg(
                        array(
                            'pmcpc_confirm' => $subscriber_email,
                        ),
                        home_url( '/' )
                    ),
                    'pmcpc_confirm_' . $subscriber_email
                );
                $confirm_url = html_entity_decode( $confirm_url, ENT_QUOTES, 'UTF-8' );
            }

            $subject = apply_filters( 'pmcpc_double_opt_in_subject', __( 'Confirm your subscription', 'product-mailer-campaigns' ) );
            $message_default = sprintf(
                /* translators: %s: confirmation URL. */
                __( "Thanks for subscribing!

    Please confirm your email by clicking this link:

    %s

    If you did not request this, you can ignore this message.", 'product-mailer-campaigns' ),
                $confirm_url
            );
            $message = apply_filters( 'pmcpc_double_opt_in_message', $message_default, $confirm_url );
            $headers = self::get_inbox_email_headers();

            return (bool) wp_mail( $subscriber_email, $subject, $message, $headers );
        }

        /**
         * Evaluate whether a release action can also start subscription flow.
         *
         * @param string $action      Requested inbox action.
         * @param object $submission  Inbox submission row.
         * @param string $context_key Submission context key.
         * @return array{action:string,downgraded:bool,notice:string}
         */


        /**
         * Evaluate whether a release action can also start subscription flow.
         *
         * @param string $action      Requested inbox action.
         * @param object $submission  Inbox submission row.
         * @param string $context_key Submission context key.
         * @return array{action:string,downgraded:bool,notice:string}
         */
        protected static function get_release_action_state( $action, $submission, $context_key ) {
            $state = array(
                'action'     => (string) $action,
                'downgraded' => false,
                'notice'     => '',
            );

            if ( 'release_with_doi' !== $action ) {
                return $state;
            }

            $doi_ok = ( 'subscribe' === $context_key ) || ( in_array( $context_key, array( 'contact', 'selling' ), true ) && false !== strpos( (string) $submission->message, '[pmcpc_opt_in=1]' ) );
            $subscriber_email = ! empty( $submission->email ) ? sanitize_email( (string) $submission->email ) : '';

            if ( $doi_ok && $subscriber_email && class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'get_subscriber_by_email' ) ) {
                $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $subscriber_email );
                if ( $subscriber && ! empty( $subscriber->id ) && ! empty( $subscriber->status ) && in_array( (string) $subscriber->status, array( 'active', 'pending', 'unsubscribed' ), true ) ) {
                    $doi_ok = false;

                    if ( 'pending' === (string) $subscriber->status ) {
                        $state['notice'] = __( 'Subscriber is already pending confirmation - DOI was not restarted.', 'product-mailer-campaigns' );
                    } elseif ( 'active' === (string) $subscriber->status ) {
                        $state['notice'] = __( 'Subscriber is already active - DOI was not restarted.', 'product-mailer-campaigns' );
                    } else {
                        $state['notice'] = __( 'Subscriber is unsubscribed - DOI was not restarted.', 'product-mailer-campaigns' );
                    }
                }
            }

            if ( ! $doi_ok ) {
                $state['action']     = 'release_message_only';
                $state['downgraded'] = true;
            }

            return $state;
        }

        /**
         * Update an inbox submission status.
         *
         * @param wpdb   $wpdb          WordPress DB instance.
         * @param string $table         Inbox table name.
         * @param int    $submission_id Submission ID.
         * @param string $status        New status.
         * @param string $reason        Optional reason.
         * @param string $reviewed_at   Reviewed timestamp.
         * @return int|false
         */


        /**
         * Update an inbox submission status.
         *
         * @param wpdb   $wpdb          WordPress DB instance.
         * @param string $table         Inbox table name.
         * @param int    $submission_id Submission ID.
         * @param string $status        New status.
         * @param string $reason        Optional reason.
         * @param string $reviewed_at   Reviewed timestamp.
         * @return int|false
         */
        protected static function update_inbox_submission_status( $wpdb, $table, $submission_id, $status, $reason, $reviewed_at ) {
            $data   = array(
                'status'      => $status,
                'reviewed_at' => $reviewed_at,
            );
            $format = array( '%s', '%s' );

            if ( '' !== $reason ) {
                $data['reason'] = $reason;
                $format[]       = '%s';
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            return $wpdb->update( $table, $data, array( 'id' => $submission_id ), $format, array( '%d' ) );
        }

        /**
         * Add sender email/domain to the allowlist when supported.
         *
         * @param string $email  Sender email.
         * @param string $domain Sender domain.
         * @return void
         */


        /**
         * Add sender email/domain to the allowlist when supported.
         *
         * @param string $email  Sender email.
         * @param string $domain Sender domain.
         * @return void
         */
        protected static function allow_inbox_sender( $email, $domain ) {
            if ( ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {
                return;
            }

            if ( $email && method_exists( 'PMCPC_Subscriber_Manager', 'add_allowlisted_email' ) ) {
                PMCPC_Subscriber_Manager::add_allowlisted_email( $email );
            }

            if ( $domain && method_exists( 'PMCPC_Subscriber_Manager', 'add_allowlisted_email_domain' ) ) {
                PMCPC_Subscriber_Manager::add_allowlisted_email_domain( $domain );
            }
        }

        /**
         * Add sender email/domain to the blocklist when supported.
         *
         * @param string $email  Sender email.
         * @param string $domain Sender domain.
         * @return array{domain_protected:bool}
         */


        /**
         * Add sender email/domain to the blocklist when supported.
         *
         * @param string $email  Sender email.
         * @param string $domain Sender domain.
         * @return array{domain_protected:bool}
         */
        protected static function block_inbox_sender( $email, $domain ) {
            $domain_protected = false;

            if ( ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {
                return array( 'domain_protected' => false );
            }

            if ( $email && method_exists( 'PMCPC_Subscriber_Manager', 'add_blocked_email' ) ) {
                PMCPC_Subscriber_Manager::add_blocked_email( $email );
            }

            if ( $domain && method_exists( 'PMCPC_Subscriber_Manager', 'add_domain_to_blocked_list' ) ) {
                $domain_protected = ( method_exists( 'PMCPC_Subscriber_Manager', 'is_auto_block_protected_domain' ) && PMCPC_Subscriber_Manager::is_auto_block_protected_domain( $domain ) );
                if ( ! $domain_protected ) {
                    PMCPC_Subscriber_Manager::add_domain_to_blocked_list( $domain );
                }
            }

            return array( 'domain_protected' => $domain_protected );
        }

        /**
         * Add only the sender email to the blocklist.
         *
         * @param string $email Sender email.
         * @return void
         */


        /**
         * Add only the sender email to the blocklist.
         *
         * @param string $email Sender email.
         * @return void
         */
        protected static function block_inbox_email( $email ) {
            if ( $email && class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'add_blocked_email' ) ) {
                PMCPC_Subscriber_Manager::add_blocked_email( $email );
            }
        }

        /**
         * Attempt to block a sender domain.
         *
         * @param string $domain Sender domain.
         * @return array{blocked:bool,protected:bool}
         */


        /**
         * Attempt to block a sender domain.
         *
         * @param string $domain Sender domain.
         * @return array{blocked:bool,protected:bool}
         */
        protected static function block_inbox_domain( $domain ) {
            $result = array(
                'blocked'   => false,
                'protected' => false,
            );

            if ( ! $domain || ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {
                return $result;
            }

            $result['protected'] = ( method_exists( 'PMCPC_Subscriber_Manager', 'is_auto_block_protected_domain' ) && PMCPC_Subscriber_Manager::is_auto_block_protected_domain( $domain ) );
            if ( ! $result['protected'] && method_exists( 'PMCPC_Subscriber_Manager', 'add_domain_to_blocked_list' ) ) {
                $result['blocked'] = (bool) PMCPC_Subscriber_Manager::add_domain_to_blocked_list( $domain );
            }

            return $result;
        }

        /**
         * Apply a bulk inbox action to one submission.
         *
         * @param wpdb   $wpdb        WordPress DB instance.
         * @param string $table       Inbox table name.
         * @param string $bulk_action Bulk action key.
         * @param int    $id          Submission ID.
         * @param string $now         Current timestamp.
         * @return string
         */


        /**
         * Apply a bulk inbox action to one submission.
         *
         * @param wpdb   $wpdb        WordPress DB instance.
         * @param string $table       Inbox table name.
         * @param string $bulk_action Bulk action key.
         * @param int    $id          Submission ID.
         * @param string $now         Current timestamp.
         * @return string
         */
        protected static function handle_inbox_bulk_action_row( $wpdb, $table, $bulk_action, $id, $now ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
            if ( ! $row ) {
                return 'skipped';
            }

            $email = ! empty( $row->email ) ? (string) $row->email : '';
            $domain = ! empty( $row->domain ) ? (string) $row->domain : '';

            if ( 'allow_sender' === $bulk_action ) {
                self::allow_inbox_sender( $email, $domain );
                self::update_inbox_submission_status( $wpdb, $table, $id, 'allowed', '', $now );
                return 'updated';
            }

            if ( 'block_sender' === $bulk_action ) {
                self::block_inbox_sender( $email, $domain );
                self::update_inbox_submission_status( $wpdb, $table, $id, 'blocked', 'manual_block', $now );
                return 'updated';
            }

            if ( 'mark_spam' === $bulk_action ) {
                self::block_inbox_sender( $email, $domain );
                self::update_inbox_submission_status( $wpdb, $table, $id, 'blocked', 'manual_spam', $now );
                return 'updated';
            }

            if ( 'release_message_only' === $bulk_action || 'release_with_doi' === $bulk_action ) {
                $context_key = ! empty( $row->context ) ? (string) $row->context : '';
                $release_action = $bulk_action;
                $release_state  = self::get_release_action_state( $release_action, $row, $context_key );
                $release_action = $release_state['action'];

                if ( 'subscribe' === $context_key ) {
                    $subscriber_email = ! empty( $row->email ) ? sanitize_email( (string) $row->email ) : '';
                    $first_name       = ! empty( $row->subject ) ? sanitize_text_field( (string) $row->subject ) : '';
                    $last_name        = ! empty( $row->message ) ? sanitize_text_field( (string) $row->message ) : '';

                    if ( 'release_message_only' === $release_action ) {
                        self::update_inbox_submission_status( $wpdb, $table, $id, 'allowed', 'not_spam', $now );
                        return 'updated';
                    } elseif ( self::start_inbox_double_optin( $subscriber_email, $first_name, $last_name ) ) {
                        self::update_inbox_submission_status( $wpdb, $table, $id, 'released', 'released_with_doi', $now );
                        return 'updated';
                    }

                    return 'skipped';
                }

                if ( self::send_inbox_submission_to_admin( $row ) ) {
                    if ( 'release_with_doi' === $release_action ) {
                        $subscriber_email = ! empty( $row->email ) ? sanitize_email( (string) $row->email ) : '';
                        self::start_inbox_double_optin( $subscriber_email, '', '' );
                    }

                    $reason = ( 'release_with_doi' === $release_action ) ? 'released_with_doi' : 'released_message_only';
                    self::update_inbox_submission_status( $wpdb, $table, $id, 'released', $reason, $now );
                    return 'updated';
                }

                return 'skipped';
            }

            if ( 'mark_not_spam' === $bulk_action ) {
                self::update_inbox_submission_status( $wpdb, $table, $id, 'allowed', 'not_spam', $now );
                return 'updated';
            }

            if ( 'delete' === $bulk_action ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
                return 'deleted';
            }

            return 'skipped';
        }

        /**
         * Handle inbox bulk actions from the admin list.
         *
         * @param wpdb   $wpdb  WordPress DB instance.
         * @param string $table Inbox table name.
         * @return void
         */


        /**
         * Handle inbox bulk actions from the admin list.
         *
         * @param wpdb   $wpdb  WordPress DB instance.
         * @param string $table Inbox table name.
         * @return void
         */
        protected static function maybe_handle_inbox_bulk_actions( $wpdb, $table ) {
            if ( ! isset( $_POST['pmcpc_inbox_bulk_nonce'], $_POST['pmcpc_bulk_action'], $_POST['pmcpc_submission_ids'] ) ) {
                return;
            }

            $nonce = sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_inbox_bulk_nonce'] ) );
            if ( ! wp_verify_nonce( $nonce, 'pmcpc_inbox_bulk' ) ) {
                return;
            }

            $bulk_action = sanitize_key( (string) wp_unslash( $_POST['pmcpc_bulk_action'] ) );
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Casted to array and sanitized via absint.
            $ids_raw = isset( $_POST['pmcpc_submission_ids'] ) ? (array) wp_unslash( $_POST['pmcpc_submission_ids'] ) : array();
            $ids     = array_values( array_unique( array_filter( array_map( 'absint', $ids_raw ) ) ) );
            $now     = current_time( 'mysql' );

            if ( ! $bulk_action || empty( $ids ) ) {
                return;
            }

            $allowed_actions = array( 'release_message_only', 'release_with_doi', 'mark_not_spam', 'allow_sender', 'block_sender', 'mark_spam', 'delete', 'unblock_domain', 'protect_domain', 'timing_set_2', 'timing_disable' );
            if ( ! in_array( $bulk_action, $allowed_actions, true ) ) {
                return;
            }

            $results = array(
                'updated' => 0,
                'deleted' => 0,
                'skipped' => 0,
            );
            foreach ( $ids as $id ) {
                $result = self::handle_inbox_bulk_action_row( $wpdb, $table, $bulk_action, $id, $now );
                if ( isset( $results[ $result ] ) ) {
                    $results[ $result ]++;
                } else {
                    $results['skipped']++;
                }
            }

            $action_labels = array(
                'mark_not_spam'      => __( 'Moved to Inbox', 'product-mailer-campaigns' ),
                'mark_spam'          => __( 'Moved to Spam', 'product-mailer-campaigns' ),
                'delete'             => __( 'Deleted', 'product-mailer-campaigns' ),
                'release_message_only' => __( 'Released', 'product-mailer-campaigns' ),
                'release_with_doi'   => __( 'Released + subscribed', 'product-mailer-campaigns' ),
                'allow_sender'       => __( 'Allowlisted', 'product-mailer-campaigns' ),
                'block_sender'       => __( 'Blocked', 'product-mailer-campaigns' ),
            );
            $summary_label = isset( $action_labels[ $bulk_action ] ) ? $action_labels[ $bulk_action ] : __( 'Processed', 'product-mailer-campaigns' );
            $notice_parts  = array();

            if ( $results['updated'] > 0 ) {
                $notice_parts[] = sprintf(
                    /* translators: 1: action label, 2: count. */
                    __( '%1$s %2$d item(s).', 'product-mailer-campaigns' ),
                    $summary_label,
                    (int) $results['updated']
                );
            }

            if ( $results['deleted'] > 0 ) {
                $notice_parts[] = sprintf(
                    /* translators: %d: count. */
                    __( 'Deleted %d item(s).', 'product-mailer-campaigns' ),
                    (int) $results['deleted']
                );
            }

            if ( $results['skipped'] > 0 ) {
                $notice_parts[] = sprintf(
                    /* translators: %d: count. */
                    __( 'Skipped %d item(s) that could not be changed.', 'product-mailer-campaigns' ),
                    (int) $results['skipped']
                );
            }

            if ( empty( $notice_parts ) ) {
                $notice_parts[] = __( 'No selected messages were changed.', 'product-mailer-campaigns' );
            }

            $filter_state = self::get_inbox_filter_state();
            $redirect_args = array_merge(
                array(
                    'page'              => 'pmcpc_inbox',
                    'pmcpc_notice_type' => ( $results['updated'] > 0 || $results['deleted'] > 0 ) ? 'success' : 'warning',
                    'pmcpc_notice_text' => implode( ' ', $notice_parts ),
                ),
                self::get_inbox_filter_query_args( $filter_state )
            );

            wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'admin.php' ) ) );
            exit;
        }


    public static function handle_run_queue_now() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( esc_html__( 'Insufficient permissions.', 'product-mailer-campaigns' ) );
            }

            $nonce = isset( $_POST['pmcpc_run_queue_now_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_run_queue_now_nonce'] ) ) : '';
            if ( ! wp_verify_nonce( $nonce, 'pmcpc_run_queue_now' ) ) {
                wp_die( esc_html__( 'Security check failed.', 'product-mailer-campaigns' ) );
            }

            if ( class_exists( 'PMCPC_Queue_Processor' ) ) {
                PMCPC_Queue_Processor::process_queue();
            }

            // Clear cached dashboard stats so the counters update immediately.
            delete_transient( 'pmcpc_dashboard_stats_v2' );

            wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_dashboard&pmcpc_queue_ran=1' ) );
            exit;
        }

}
