<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Dashboard_Activity_Methods {


        protected static function pmcpc_dashboard_get_trigger_metrics( $trigger_key, $campaigns_table, $queue_table, $events_table, $event_logs_table, $dt_30_mysql ) {
            global $wpdb;

            $trigger_key = sanitize_key( (string) $trigger_key );
            $campaign_ids = self::pmcpc_dashboard_get_trigger_campaign_ids( $trigger_key, $campaigns_table );
            $campaign_ids = array_values( array_filter( array_map( 'intval', $campaign_ids ) ) );

            $metrics = array(
                'entered_30'      => 0,
                'sent_30'         => 0,
                'open_rate_30'    => null,
                'click_rate_30'   => null,
                'scheduled_count' => 0,
                'next_run_at'     => '',
                'last_activity_at' => '',
                'last_activity_email' => '',
                'last_activity_status' => '',
            );

            if ( 'date' === $trigger_key ) {
                $metrics['scheduled_count'] = count( $campaign_ids );
                if ( ! empty( $campaign_ids ) ) {
                    $now_mysql = current_time( 'mysql' );
                    $next_value = $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT MIN(COALESCE(NULLIF(next_run_at, ''), NULLIF(schedule_datetime, '')))
                             FROM {$campaigns_table}
                             WHERE id IN (" . implode( ',', $campaign_ids ) . ")
                               AND status IN (%s, %s, %s)
                               AND COALESCE(NULLIF(next_run_at, ''), NULLIF(schedule_datetime, '')) IS NOT NULL
                               AND COALESCE(NULLIF(next_run_at, ''), NULLIF(schedule_datetime, '')) <> %s
                               AND COALESCE(NULLIF(next_run_at, ''), NULLIF(schedule_datetime, '')) >= %s",
                            'scheduled',
                            'active',
                            'queued',
                            '0000-00-00 00:00:00',
                            $now_mysql
                        )
                    ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    if ( empty( $next_value ) ) {
                        $next_value = $wpdb->get_var(
                            $wpdb->prepare(
                                "SELECT MIN(COALESCE(NULLIF(next_run_at, ''), NULLIF(schedule_datetime, '')))
                                 FROM {$campaigns_table}
                                 WHERE id IN (" . implode( ',', $campaign_ids ) . ")
                                   AND status IN (%s, %s, %s)
                                   AND COALESCE(NULLIF(next_run_at, ''), NULLIF(schedule_datetime, '')) IS NOT NULL
                                   AND COALESCE(NULLIF(next_run_at, ''), NULLIF(schedule_datetime, '')) <> %s",
                                'scheduled',
                                'active',
                                'queued',
                                '0000-00-00 00:00:00'
                            )
                        ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    }
                    $metrics['next_run_at'] = (string) $next_value;
                }
                return $metrics;
            }

            if ( empty( $campaign_ids ) ) {
                return $metrics;
            }

            $campaign_id_sql = implode( ',', $campaign_ids );

            $metrics['entered_30'] = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$queue_table} WHERE campaign_id IN ({$campaign_id_sql}) AND created_at >= %s",
                    $dt_30_mysql
                )
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

            $metrics['sent_30'] = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$queue_table} WHERE campaign_id IN ({$campaign_id_sql}) AND status = %s AND updated_at >= %s",
                    'sent',
                    $dt_30_mysql
                )
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

            $recent_row = $wpdb->get_row(
                "SELECT to_email, status, COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), created_at) AS activity_at FROM {$queue_table} WHERE campaign_id IN ({$campaign_id_sql}) ORDER BY COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), created_at) DESC, id DESC LIMIT 1"
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            if ( $recent_row ) {
                $metrics['last_activity_at'] = ! empty( $recent_row->activity_at ) ? (string) $recent_row->activity_at : '';
                $metrics['last_activity_email'] = ! empty( $recent_row->to_email ) ? sanitize_email( (string) $recent_row->to_email ) : '';
                $metrics['last_activity_status'] = ! empty( $recent_row->status ) ? sanitize_key( (string) $recent_row->status ) : '';
            }

            $opens = 0;
            $clicks = 0;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $events_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $events_table ) ) === $events_table );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $event_logs_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $event_logs_table ) ) === $event_logs_table );

            if ( $events_exists ) {
                $opens = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(DISTINCT e.queue_id) FROM {$events_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE q.campaign_id IN ({$campaign_id_sql}) AND q.status = %s AND q.updated_at >= %s AND e.event_type = %s",
                        'sent',
                        $dt_30_mysql,
                        'opened'
                    )
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $clicks = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(DISTINCT e.queue_id) FROM {$events_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE q.campaign_id IN ({$campaign_id_sql}) AND q.status = %s AND q.updated_at >= %s AND e.event_type = %s",
                        'sent',
                        $dt_30_mysql,
                        'clicked'
                    )
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            } elseif ( $event_logs_exists ) {
                $opens = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(DISTINCT e.queue_id) FROM {$event_logs_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE q.campaign_id IN ({$campaign_id_sql}) AND q.status = %s AND q.updated_at >= %s AND e.event_type = %s",
                        'sent',
                        $dt_30_mysql,
                        'open'
                    )
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $clicks = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(DISTINCT e.queue_id) FROM {$event_logs_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE q.campaign_id IN ({$campaign_id_sql}) AND q.status = %s AND q.updated_at >= %s AND e.event_type = %s",
                        'sent',
                        $dt_30_mysql,
                        'click'
                    )
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            }

            if ( $metrics['sent_30'] > 0 ) {
                $metrics['open_rate_30'] = round( ( $opens / $metrics['sent_30'] ) * 100, 1 );
                $metrics['click_rate_30'] = round( ( $clicks / $metrics['sent_30'] ) * 100, 1 );
            }

            return $metrics;
        }





        protected static function pmcpc_dashboard_get_recent_activity( $queue_table, $email_log_table, $campaigns_table, $subscribers_table ) {
            global $wpdb;

            $email_log_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $email_log_table ) ) === $email_log_table ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $queue_exists     = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $queue_table ) ) === $queue_table ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

            $activity_items = array();
            $seen_keys      = array();

            if ( $email_log_exists ) {
                $log_rows = $wpdb->get_results(
                    "SELECT l.campaign_id, l.queue_id, l.to_email, l.status, COALESCE(NULLIF(l.sent_at, '0000-00-00 00:00:00'), l.created_at) AS activity_at, c.name AS campaign_name
                     FROM {$email_log_table} l
                     LEFT JOIN {$campaigns_table} c ON c.id = l.campaign_id
                     ORDER BY COALESCE(NULLIF(l.sent_at, '0000-00-00 00:00:00'), l.created_at) DESC, l.id DESC
                     LIMIT 12"
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

                foreach ( (array) $log_rows as $row ) {
                    $key = 'log:' . (int) $row->campaign_id . ':' . sanitize_email( (string) $row->to_email ) . ':' . (string) $row->activity_at;
                    if ( isset( $seen_keys[ $key ] ) ) {
                        continue;
                    }
                    $seen_keys[ $key ] = true;
                    $activity_items[] = array(
                        'title'       => ! empty( $row->campaign_name ) ? (string) $row->campaign_name : __( 'Campaign delivery', 'product-mailer-campaigns' ),
                        'email'       => ! empty( $row->to_email ) ? sanitize_email( (string) $row->to_email ) : '',
                        'status'      => ! empty( $row->status ) ? sanitize_key( (string) $row->status ) : 'sent',
                        'activity_at' => ! empty( $row->activity_at ) ? (string) $row->activity_at : '',
                        'detail'      => __( 'Automation or campaign email', 'product-mailer-campaigns' ),
                        'icon'        => '📧',
                        'sort_ts'     => ! empty( $row->activity_at ) ? strtotime( (string) $row->activity_at ) : 0,
                    );
                    if ( count( $activity_items ) >= 6 ) {
                        break;
                    }
                }
            }

            if ( $queue_exists ) {
                $queue_status_sql = $email_log_exists
                    ? "q.status IN ('pending','processing','failed') OR (q.status = 'sent' AND NOT EXISTS (SELECT 1 FROM {$email_log_table} el WHERE el.queue_id = q.id))"
                    : "q.status IN ('pending','processing','failed','sent')";
                $queue_rows = $wpdb->get_results(
                    "SELECT q.id, q.campaign_id, q.to_email, q.status, COALESCE(NULLIF(q.updated_at, '0000-00-00 00:00:00'), q.created_at) AS activity_at, c.name AS campaign_name
                     FROM {$queue_table} q
                     LEFT JOIN {$campaigns_table} c ON c.id = q.campaign_id
                     WHERE {$queue_status_sql}
                     ORDER BY COALESCE(NULLIF(q.updated_at, '0000-00-00 00:00:00'), q.created_at) DESC, q.id DESC
                     LIMIT 10"
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

                foreach ( (array) $queue_rows as $row ) {
                    $key = 'queue:' . (int) $row->id;
                    if ( isset( $seen_keys[ $key ] ) ) {
                        continue;
                    }
                    $seen_keys[ $key ] = true;
                    $activity_items[] = array(
                        'title'       => ! empty( $row->campaign_name ) ? (string) $row->campaign_name : __( 'Queued email', 'product-mailer-campaigns' ),
                        'email'       => ! empty( $row->to_email ) ? sanitize_email( (string) $row->to_email ) : '',
                        'status'      => ! empty( $row->status ) ? sanitize_key( (string) $row->status ) : 'pending',
                        'activity_at' => ! empty( $row->activity_at ) ? (string) $row->activity_at : '',
                        'detail'      => __( 'Queue activity', 'product-mailer-campaigns' ),
                        'icon'        => in_array( sanitize_key( (string) $row->status ), array( 'failed' ), true ) ? '⚠️' : '⏳',
                        'sort_ts'     => ! empty( $row->activity_at ) ? strtotime( (string) $row->activity_at ) : 0,
                    );
                }
            }

            usort(
                $activity_items,
                static function( $a, $b ) {
                    $a_ts = isset( $a['sort_ts'] ) ? (int) $a['sort_ts'] : 0;
                    $b_ts = isset( $b['sort_ts'] ) ? (int) $b['sort_ts'] : 0;
                    if ( $a_ts === $b_ts ) {
                        return 0;
                    }
                    return ( $a_ts > $b_ts ) ? -1 : 1;
                }
            );
            $activity_items = array_slice( $activity_items, 0, 5 );

            $scheduled_items = array();
            $campaign_rows = $wpdb->get_results(
                "SELECT id, name, status, next_run_at, updated_at, created_at
                 FROM {$campaigns_table}
                 WHERE next_run_at IS NOT NULL AND next_run_at <> '0000-00-00 00:00:00'
                 ORDER BY next_run_at ASC, updated_at DESC, id DESC
                 LIMIT 3"
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

            foreach ( (array) $campaign_rows as $row ) {
                $activity_at = ! empty( $row->next_run_at ) ? (string) $row->next_run_at : ( ! empty( $row->updated_at ) ? (string) $row->updated_at : (string) $row->created_at );
                $scheduled_items[] = array(
                    'title'       => ! empty( $row->name ) ? (string) $row->name : __( 'Scheduled campaign', 'product-mailer-campaigns' ),
                    'email'       => '',
                    'status'      => 'scheduled',
                    'activity_at' => $activity_at,
                    'detail'      => __( 'Upcoming scheduled campaign', 'product-mailer-campaigns' ),
                    'icon'        => '📅',
                    'sort_ts'     => ! empty( $activity_at ) ? strtotime( $activity_at ) : 0,
                );
            }

            $items = array_merge( $activity_items, $scheduled_items );
            foreach ( $items as &$item ) {
                unset( $item['sort_ts'] );
            }
            unset( $item );

            return $items;
        }


        protected static function pmcpc_dashboard_get_group_recent_activity( $group_cards, $campaigns_table, $queue_table ) {
            global $wpdb;

            $trigger_labels = array();
            $campaign_map   = array();

            foreach ( (array) $group_cards as $group_card ) {
                $trigger_key = isset( $group_card['trigger'] ) ? sanitize_key( (string) $group_card['trigger'] ) : '';
                if ( '' === $trigger_key || 'date' === $trigger_key ) {
                    continue;
                }
                $trigger_labels[ $trigger_key ] = isset( $group_card['label'] ) ? (string) $group_card['label'] : $trigger_key;
                foreach ( self::pmcpc_dashboard_get_trigger_campaign_ids( $trigger_key, $campaigns_table ) as $campaign_id ) {
                    $campaign_map[ (int) $campaign_id ] = $trigger_key;
                }
            }

            $campaign_ids = array_values( array_filter( array_map( 'intval', array_keys( $campaign_map ) ) ) );
            if ( empty( $campaign_ids ) ) {
                return array();
            }

            $campaign_id_sql = implode( ',', $campaign_ids );
            $rows = $wpdb->get_results(
                "SELECT campaign_id, to_email, status, COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), created_at) AS activity_at FROM {$queue_table} WHERE campaign_id IN ({$campaign_id_sql}) ORDER BY COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), created_at) DESC, id DESC LIMIT 5"
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

            $activity = array();
            foreach ( (array) $rows as $row ) {
                $campaign_id = isset( $row->campaign_id ) ? (int) $row->campaign_id : 0;
                $trigger_key = isset( $campaign_map[ $campaign_id ] ) ? $campaign_map[ $campaign_id ] : '';
                $activity[] = array(
                    'trigger' => $trigger_key,
                    'label' => isset( $trigger_labels[ $trigger_key ] ) ? $trigger_labels[ $trigger_key ] : $trigger_key,
                    'email' => ! empty( $row->to_email ) ? sanitize_email( (string) $row->to_email ) : '',
                    'status' => ! empty( $row->status ) ? sanitize_key( (string) $row->status ) : '',
                    'activity_at' => ! empty( $row->activity_at ) ? (string) $row->activity_at : '',
                );
            }

            return $activity;
        }


        protected static function pmcpc_dashboard_format_activity_status( $status ) {
            $status = sanitize_key( (string) $status );
            $map = array(
                'sent' => __( 'Sent', 'product-mailer-campaigns' ),
                'pending' => __( 'Queued', 'product-mailer-campaigns' ),
                'processing' => __( 'Processing', 'product-mailer-campaigns' ),
                'failed' => __( 'Failed', 'product-mailer-campaigns' ),
                'paused' => __( 'Paused', 'product-mailer-campaigns' ),
            );
            return isset( $map[ $status ] ) ? $map[ $status ] : ucfirst( str_replace( '_', ' ', $status ) );
        }


        protected static function pmcpc_dashboard_get_trigger_campaign_ids( $trigger_key, $campaigns_table ) {
            global $wpdb;

            $trigger_key = sanitize_key( (string) $trigger_key );
            if ( '' === $trigger_key ) {
                return array();
            }

            if ( 'date' === $trigger_key ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                return $wpdb->get_col(
                    $wpdb->prepare(
                        "SELECT id FROM {$campaigns_table} WHERE automation_trigger = %s OR schedule_type IN (%s, %s)",
                        'date',
                        'one_time',
                        'recurring'
                    )
                );
            }

            $trigger_aliases = array(
                'new_subscriber' => array( 'new_subscriber', 'welcome' ),
                'first_order' => array( 'first_order', 'new_customer' ),
                'repeat_customer' => array( 'repeat_customer', 'repeat', 'repeat_customer_2plus', 'repeat-customer' ),
                'review_request' => array( 'review_request', 'review', 'review-request' ),
                'high_value' => array( 'high_value', 'high-value', 'high_value_customer' ),
                'vip_customer' => array( 'vip_customer', 'vip', 'vip-customer', 'top_spenders' ),
                'customer_inactive' => array( 'customer_inactive', 'inactive', 'win_back_automation', 'winback', 'win_back', 'customer-inactive', 'inactive_customers' ),
                'post_purchase' => array( 'post_purchase' ),
                'lead_magnet_download' => array( 'lead_magnet_download', 'lead_magnet', 'lead-magnet-delivery' ),
                'subscriber_inactive' => array( 'subscriber_inactive', 'subscriber-inactive' ),
                'subscriber_anniversary' => array( 'subscriber_anniversary', 'anniversary', 'subscriber-anniversary' ),
                'subscriber_birthday' => array( 'subscriber_birthday', 'birthday', 'subscriber-birthday' ),
            );

            $aliases = isset( $trigger_aliases[ $trigger_key ] ) ? $trigger_aliases[ $trigger_key ] : array( $trigger_key );
            $aliases = array_values( array_unique( array_filter( array_map( 'sanitize_key', $aliases ) ) ) );
            $where_parts = array();
            $prepare_args = array();

            if ( ! empty( $aliases ) ) {
                $where_parts[] = 'automation_trigger IN (' . implode( ', ', array_fill( 0, count( $aliases ), '%s' ) ) . ')';
                $prepare_args = array_merge( $prepare_args, $aliases );
            }

            if ( 'new_subscriber' === $trigger_key ) {
                $where_parts[] = 'is_welcome = 1';
            } elseif ( 'post_purchase' === $trigger_key ) {
                $where_parts[] = 'is_post_purchase = 1';
            }

            if ( empty( $where_parts ) ) {
                return array();
            }

            $sql = "SELECT id FROM {$campaigns_table} WHERE (" . implode( ' OR ', $where_parts ) . ')';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            return $wpdb->get_col( $wpdb->prepare( $sql, $prepare_args ) );
        }


        protected static function pmcpc_dashboard_get_latest_trigger_campaign( $trigger_key, $campaigns_table ) {
            global $wpdb;

            $trigger_key = sanitize_key( (string) $trigger_key );
            if ( empty( $trigger_key ) ) {
                return null;
            }

            $where_parts  = array();
            $prepare_args = array();

            if ( 'date' === $trigger_key ) {
                $where_parts[]  = '(automation_trigger = %s)';
                $prepare_args[] = 'date';
                $where_parts[]  = "(schedule_type IN (%s, %s) AND (automation_trigger IS NULL OR automation_trigger = '' OR automation_trigger = 'none'))";
                $prepare_args[] = 'one_time';
                $prepare_args[] = 'recurring';
            } else {
                $trigger_aliases = array(
                    'new_subscriber' => array( 'new_subscriber', 'welcome' ),
                    'first_order'    => array( 'first_order', 'new_customer' ),
                    'repeat_customer' => array( 'repeat_customer', 'repeat', 'repeat_customer_2plus', 'repeat-customer' ),
                    'review_request' => array( 'review_request', 'review', 'review-request' ),
                    'high_value'     => array( 'high_value', 'high-value', 'high_value_customer' ),
                    'vip_customer'   => array( 'vip_customer', 'vip', 'vip-customer', 'top_spenders' ),
                    'customer_inactive' => array( 'customer_inactive', 'inactive', 'win_back_automation', 'winback', 'win_back', 'customer-inactive', 'inactive_customers' ),
                    'post_purchase'  => array( 'post_purchase' ),
                );

                $aliases = isset( $trigger_aliases[ $trigger_key ] ) ? $trigger_aliases[ $trigger_key ] : array( $trigger_key );
                $aliases = array_values( array_unique( array_filter( array_map( 'sanitize_key', $aliases ) ) ) );
                if ( $aliases ) {
                    $where_parts[] = 'automation_trigger IN (' . implode( ', ', array_fill( 0, count( $aliases ), '%s' ) ) . ')';
                    $prepare_args  = array_merge( $prepare_args, $aliases );
                }

                if ( 'new_subscriber' === $trigger_key ) {
                    $where_parts[] = 'is_welcome = 1';
                } elseif ( 'post_purchase' === $trigger_key ) {
                    $where_parts[] = 'is_post_purchase = 1';
                }
            }

            if ( empty( $where_parts ) ) {
                return null;
            }

            $sql = "SELECT id, name, status, automation_trigger, schedule_type FROM {$campaigns_table} WHERE (" . implode( ' OR ', $where_parts ) . ") ORDER BY updated_at DESC, id DESC LIMIT 1";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            return $wpdb->get_row( $wpdb->prepare( $sql, $prepare_args ) );
        }


        protected static function pmcpc_dashboard_resolve_automation_status( $trigger_key, $campaign ) {
            $trigger_key = sanitize_key( (string) $trigger_key );
            if ( empty( $campaign ) || empty( $campaign->id ) ) {
                return 'not_created';
            }

            $raw_status = ! empty( $campaign->status ) ? sanitize_key( (string) $campaign->status ) : '';
            if ( 'date' === $trigger_key && in_array( $raw_status, array( 'scheduled', 'active', 'queued' ), true ) ) {
                return 'scheduled';
            }
            if ( 'active' === $raw_status || 'scheduled' === $raw_status || 'queued' === $raw_status ) {
                return 'active';
            }
            if ( in_array( $raw_status, array( 'draft', 'needs_data' ), true ) ) {
                return 'needs_setup';
            }
            if ( in_array( $raw_status, array( 'paused', 'inactive', 'disabled' ), true ) ) {
                return 'inactive';
            }

            return 'inactive';
        }

        /**
         * Build workflow-first cards for the dashboard from real automation campaigns.
         * Multi-step workflows are grouped by workflow_key; single automation emails are shown as 1-step workflows.
         */
        protected static function pmcpc_dashboard_get_workflow_cards( $campaigns_table, $queue_table, $events_table, $event_logs_table, $dt_30_mysql, $campaign_revenue_breakdown = array() ) {
            global $wpdb;

            $cards = array();

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $rows = $wpdb->get_results(
                "SELECT id, name, subject, status, automation_trigger, trigger_delay_minutes, workflow_key, workflow_name, workflow_step, created_at, updated_at
                 FROM {$campaigns_table}
                 WHERE campaign_type = 'automation'
                   AND status <> 'draft'
                 ORDER BY COALESCE(NULLIF(workflow_key, ''), CONCAT('single_', id)) ASC, workflow_step ASC, id ASC"
            );

            if ( empty( $rows ) || ! is_array( $rows ) ) {
                return array();
            }

            $groups = array();
            foreach ( $rows as $row ) {
                $workflow_key = ! empty( $row->workflow_key ) ? sanitize_key( (string) $row->workflow_key ) : '';
                $trigger_key  = ! empty( $row->automation_trigger ) ? sanitize_key( (string) $row->automation_trigger ) : '';

                // Legacy abandoned-cart steps were originally stored as separate automation emails
                // without a workflow_key. Treat them as one dashboard workflow so Step 1/2/3 do not
                // appear as separate cards.
                if ( '' === $workflow_key && in_array( $trigger_key, array( 'abandoned_cart_step_1', 'abandoned_cart_step_2', 'abandoned_cart_step_3' ), true ) ) {
                    $workflow_key = 'abandoned_cart_recovery';
                    if ( empty( $row->workflow_name ) ) {
                        $row->workflow_name = __( 'Abandoned cart recovery', 'product-mailer-campaigns' );
                    }
                }

                $group_key    = '' !== $workflow_key ? 'workflow_' . $workflow_key : 'single_' . (int) $row->id;
                if ( ! isset( $groups[ $group_key ] ) ) {
                    $groups[ $group_key ] = array(
                        'workflow_key' => $workflow_key,
                        'rows'         => array(),
                    );
                }
                $groups[ $group_key ]['rows'][] = $row;
            }

            foreach ( $groups as $group_key => $group ) {
                $group_rows = isset( $group['rows'] ) && is_array( $group['rows'] ) ? $group['rows'] : array();
                if ( empty( $group_rows ) ) {
                    continue;
                }

                usort(
                    $group_rows,
                    static function ( $a, $b ) {
                        $as = isset( $a->workflow_step ) ? (int) $a->workflow_step : 0;
                        $bs = isset( $b->workflow_step ) ? (int) $b->workflow_step : 0;
                        if ( $as === $bs ) {
                            return (int) $a->id <=> (int) $b->id;
                        }
                        return $as <=> $bs;
                    }
                );

                $first       = $group_rows[0];
                $ids         = array_values( array_filter( array_map( static function ( $r ) { return isset( $r->id ) ? (int) $r->id : 0; }, $group_rows ) ) );
                $status_list = array_values( array_filter( array_map( static function ( $r ) { return isset( $r->status ) ? sanitize_key( (string) $r->status ) : ''; }, $group_rows ) ) );
                $active_steps = 0;
                foreach ( $status_list as $step_status ) {
                    if ( in_array( $step_status, array( 'active', 'scheduled', 'queued' ), true ) ) {
                        $active_steps++;
                    }
                }

                $step_count = count( $ids );
                $workflow_name = ! empty( $first->workflow_name ) ? (string) $first->workflow_name : ( ! empty( $first->name ) ? (string) $first->name : __( 'Workflow', 'product-mailer-campaigns' ) );
                if ( '' === (string) $group['workflow_key'] && ! empty( $first->name ) ) {
                    $workflow_name = (string) $first->name;
                }

                $trigger = ! empty( $first->automation_trigger ) ? sanitize_key( (string) $first->automation_trigger ) : '';
                if ( 'abandoned_cart_recovery' === (string) $group['workflow_key'] ) {
                    $trigger = 'abandoned_cart_recovery';
                }
                $metrics = self::pmcpc_dashboard_get_campaign_id_metrics( $ids, $queue_table, $events_table, $event_logs_table, $dt_30_mysql );

                $revenue_30 = 0.0;
                $revenue_orders_30 = 0;
                foreach ( $ids as $campaign_id ) {
                    if ( isset( $campaign_revenue_breakdown[ $campaign_id ] ) ) {
                        $revenue_orders_30 += isset( $campaign_revenue_breakdown[ $campaign_id ]['orders'] ) ? (int) $campaign_revenue_breakdown[ $campaign_id ]['orders'] : 0;
                        $revenue_30        += isset( $campaign_revenue_breakdown[ $campaign_id ]['revenue'] ) ? (float) $campaign_revenue_breakdown[ $campaign_id ]['revenue'] : 0.0;
                    }
                }

                $status = 'inactive';
                if ( $active_steps >= $step_count && $step_count > 0 ) {
                    $status = 'active';
                } elseif ( $active_steps > 0 ) {
                    $status = 'partial';
                } elseif ( in_array( 'needs_data', $status_list, true ) ) {
                    $status = 'needs_setup';
                }

                $cards[] = array(
                    'key'                  => (string) $group_key,
                    'workflow_key'         => (string) $group['workflow_key'],
                    'label'                => $workflow_name,
                    'trigger'              => $trigger,
                    'trigger_label'        => self::pmcpc_dashboard_format_trigger_label( $trigger ),
                    'status'               => $status,
                    'step_count'           => $step_count,
                    'active_steps'         => $active_steps,
                    'campaign_id'          => ! empty( $ids ) ? (int) $ids[0] : 0,
                    'entered_30'           => isset( $metrics['entered_30'] ) ? (int) $metrics['entered_30'] : 0,
                    'sent_30'              => isset( $metrics['sent_30'] ) ? (int) $metrics['sent_30'] : 0,
                    'open_rate_30'         => $metrics['open_rate_30'] ?? null,
                    'click_rate_30'        => $metrics['click_rate_30'] ?? null,
                    'last_activity_at'     => isset( $metrics['last_activity_at'] ) ? (string) $metrics['last_activity_at'] : '',
                    'last_activity_email'  => isset( $metrics['last_activity_email'] ) ? (string) $metrics['last_activity_email'] : '',
                    'last_activity_status' => isset( $metrics['last_activity_status'] ) ? (string) $metrics['last_activity_status'] : '',
                    'revenue_orders_30'    => $revenue_orders_30,
                    'revenue_30'           => $revenue_30,
                );
            }

            usort(
                $cards,
                static function ( $a, $b ) {
                    $a_active = in_array( isset( $a['status'] ) ? (string) $a['status'] : '', array( 'active', 'partial' ), true ) ? 1 : 0;
                    $b_active = in_array( isset( $b['status'] ) ? (string) $b['status'] : '', array( 'active', 'partial' ), true ) ? 1 : 0;
                    if ( $a_active !== $b_active ) {
                        return $b_active <=> $a_active;
                    }
                    $a_sent = isset( $a['sent_30'] ) ? (int) $a['sent_30'] : 0;
                    $b_sent = isset( $b['sent_30'] ) ? (int) $b['sent_30'] : 0;
                    if ( $a_sent !== $b_sent ) {
                        return $b_sent <=> $a_sent;
                    }
                    return strcasecmp( (string) ( $a['label'] ?? '' ), (string) ( $b['label'] ?? '' ) );
                }
            );

            return $cards;
        }

        protected static function pmcpc_dashboard_get_campaign_id_metrics( $campaign_ids, $queue_table, $events_table, $event_logs_table, $dt_30_mysql ) {
            global $wpdb;

            $campaign_ids = array_values( array_filter( array_map( 'intval', (array) $campaign_ids ) ) );
            $metrics = array(
                'entered_30' => 0,
                'sent_30' => 0,
                'open_rate_30' => null,
                'click_rate_30' => null,
                'last_activity_at' => '',
                'last_activity_email' => '',
                'last_activity_status' => '',
            );
            if ( empty( $campaign_ids ) ) {
                return $metrics;
            }

            $campaign_id_sql = implode( ',', $campaign_ids );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $metrics['entered_30'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$queue_table} WHERE campaign_id IN ({$campaign_id_sql}) AND created_at >= %s", $dt_30_mysql ) );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $metrics['sent_30'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$queue_table} WHERE campaign_id IN ({$campaign_id_sql}) AND status = %s AND updated_at >= %s", 'sent', $dt_30_mysql ) );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $recent_row = $wpdb->get_row( "SELECT to_email, status, COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), created_at) AS activity_at FROM {$queue_table} WHERE campaign_id IN ({$campaign_id_sql}) ORDER BY COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), created_at) DESC, id DESC LIMIT 1" );
            if ( $recent_row ) {
                $metrics['last_activity_at'] = ! empty( $recent_row->activity_at ) ? (string) $recent_row->activity_at : '';
                $metrics['last_activity_email'] = ! empty( $recent_row->to_email ) ? sanitize_email( (string) $recent_row->to_email ) : '';
                $metrics['last_activity_status'] = ! empty( $recent_row->status ) ? sanitize_key( (string) $recent_row->status ) : '';
            }

            $opens = 0;
            $clicks = 0;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $events_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $events_table ) ) === $events_table );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $event_logs_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $event_logs_table ) ) === $event_logs_table );
            if ( $events_exists ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $opens = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT e.queue_id) FROM {$events_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE q.campaign_id IN ({$campaign_id_sql}) AND q.status = %s AND q.updated_at >= %s AND e.event_type = %s", 'sent', $dt_30_mysql, 'opened' ) );
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $clicks = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT e.queue_id) FROM {$events_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE q.campaign_id IN ({$campaign_id_sql}) AND q.status = %s AND q.updated_at >= %s AND e.event_type = %s", 'sent', $dt_30_mysql, 'clicked' ) );
            } elseif ( $event_logs_exists ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $opens = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT e.queue_id) FROM {$event_logs_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE q.campaign_id IN ({$campaign_id_sql}) AND q.status = %s AND q.updated_at >= %s AND e.event_type IN (%s, %s)", 'sent', $dt_30_mysql, 'open', 'opened' ) );
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $clicks = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT e.queue_id) FROM {$event_logs_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE q.campaign_id IN ({$campaign_id_sql}) AND q.status = %s AND q.updated_at >= %s AND e.event_type IN (%s, %s)", 'sent', $dt_30_mysql, 'click', 'clicked' ) );
            }
            if ( $metrics['sent_30'] > 0 ) {
                $metrics['open_rate_30'] = ( $opens / max( 1, $metrics['sent_30'] ) ) * 100;
                $metrics['click_rate_30'] = ( $clicks / max( 1, $metrics['sent_30'] ) ) * 100;
            }
            return $metrics;
        }


        protected static function pmcpc_dashboard_get_workflow_icon( $trigger ) {
            $trigger = sanitize_key( (string) $trigger );
            $icons = array(
                'abandoned_cart_recovery' => '🛒',
                'abandoned_cart_step_1' => '🛒',
                'abandoned_cart_step_2' => '🛒',
                'abandoned_cart_step_3' => '🛒',
                'new_subscriber' => '🎉',
                'welcome' => '🎉',
                'welcome_follow_up' => '➕',
                'post_purchase' => '📦',
                'review_request' => '⭐',
                'high_value' => '💎',
                'vip_customer' => '👑',
                'repeat_customer' => '🔁',
                'first_order' => '🥇',
                'customer_inactive' => '💤',
                'subscriber_inactive' => '💤',
                'subscriber_birthday' => '🎂',
                'subscriber_anniversary' => '🎉',
                'date' => '🗓️',
            );
            return isset( $icons[ $trigger ] ) ? $icons[ $trigger ] : '⚙️';
        }

        protected static function pmcpc_dashboard_format_trigger_label( $trigger ) {
            $trigger = sanitize_key( (string) $trigger );
            if ( '' === $trigger ) {
                return __( 'Manual / custom', 'product-mailer-campaigns' );
            }
            $labels = array(
                'new_subscriber' => __( 'New subscriber', 'product-mailer-campaigns' ),
                'welcome' => __( 'New subscriber', 'product-mailer-campaigns' ),
                'first_order' => __( 'First order', 'product-mailer-campaigns' ),
                'repeat_customer' => __( 'Repeat customer', 'product-mailer-campaigns' ),
                'review_request' => __( 'Review request', 'product-mailer-campaigns' ),
                'post_purchase' => __( 'Post-purchase', 'product-mailer-campaigns' ),
                'high_value' => __( 'High-value customer', 'product-mailer-campaigns' ),
                'vip_customer' => __( 'VIP customer', 'product-mailer-campaigns' ),
                'customer_inactive' => __( 'Customer inactive', 'product-mailer-campaigns' ),
                'subscriber_inactive' => __( 'Subscriber inactive', 'product-mailer-campaigns' ),
                'subscriber_anniversary' => __( 'Subscriber anniversary', 'product-mailer-campaigns' ),
                'subscriber_birthday' => __( 'Subscriber birthday', 'product-mailer-campaigns' ),
                'lead_magnet_download' => __( 'Lead magnet delivery', 'product-mailer-campaigns' ),
                'abandoned_cart_step_1' => __( 'Abandoned cart', 'product-mailer-campaigns' ),
                'abandoned_cart_step_2' => __( 'Abandoned cart', 'product-mailer-campaigns' ),
                'abandoned_cart_step_3' => __( 'Abandoned cart', 'product-mailer-campaigns' ),
            );
            if ( isset( $labels[ $trigger ] ) ) {
                return $labels[ $trigger ];
            }
            return ucwords( str_replace( array( '_', '-' ), ' ', $trigger ) );
        }


}
