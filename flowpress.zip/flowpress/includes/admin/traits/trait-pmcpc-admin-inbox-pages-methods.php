<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Inbox_Pages_Methods {

        public static function render_inbox_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            global $wpdb;
            $table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );

            if ( ! self::inbox_table_exists( $wpdb, $table ) ) {
                self::render_inbox_notice( 'warning', __( 'Messages log not found yet. Please deactivate and reactivate the plugin to create database tables.', 'product-mailer-campaigns' ) );
                return;
            }

            $request      = self::get_inbox_request_data();
            $view_id      = (int) $request['view_id'];
            $detail_nonce = $view_id ? wp_create_nonce( 'pmcpc_inbox_action_' . $view_id ) : '';
            $filter_state = self::get_inbox_filter_state();
            $is_detail_action = ( $view_id > 0 );

            self::maybe_handle_mark_all_read( $wpdb, $table, (int) $request['mark_all'], (string) $request['mark_all_nonce'] );
            self::render_inbox_result_notice( (string) $request['notice'] );

            $action        = (string) $request['action'];
            $submission_id = (int) $request['submission_id'];
            $action_nonce  = (string) $request['action_nonce'];

            if ( $action && $submission_id && $action_nonce && wp_verify_nonce( $action_nonce, 'pmcpc_inbox_action_' . $submission_id ) ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                $submission = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $submission_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
                if ( $submission ) {
                    $email  = ! empty( $submission->email ) ? (string) $submission->email : '';
                    $domain = ! empty( $submission->domain ) ? (string) $submission->domain : '';
                    $now    = current_time( 'mysql' );


                    // --- Release actions (safe split) ---
                    $context_key = ! empty( $submission->context ) ? (string) $submission->context : '';
                    $did_send_admin = null;
                    $did_subscribe  = null;

                    if ( 'release_message_only' === $action || 'release_with_doi' === $action ) {
                        // For contact/selling: "release" means email the admin. For subscribe: "release" means start subscription flow.
                        $tags = array( 'origin:inbox-release' );

                        // Guardrail: only allow "Release + Subscribe" when the submission actually includes an opt-in (or is a subscribe form).
                        $release_state = self::get_release_action_state( $action, $submission, $context_key );
                        $action = $release_state['action'];

                        if ( 'subscribe' === $context_key ) {
                            $subscriber_email = ! empty( $submission->email ) ? sanitize_email( (string) $submission->email ) : '';
                            $first_name       = ! empty( $submission->subject ) ? sanitize_text_field( (string) $submission->subject ) : '';
                            $last_name        = ! empty( $submission->message ) ? sanitize_text_field( (string) $submission->message ) : '';

                            if ( 'release_message_only' === $action ) {
                                // Explicitly do NOT start subscription flow.
                                self::update_inbox_submission_status( $wpdb, $table, $submission_id, 'allowed', 'not_spam', $now );
                                $notice_type = 'success';
                                $notice_text = __( 'Marked as Inbox only (no subscription started).', 'product-mailer-campaigns' );
                                if ( $release_state['downgraded'] && ! empty( $release_state['notice'] ) ) {
                                    $notice_type = 'info';
                                    $notice_text = $release_state['notice'] . ' ' . $notice_text;
                                }
                                self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, $notice_type, $notice_text, $is_detail_action );
                            } else {
                                $did_subscribe = self::start_inbox_double_optin( $subscriber_email, $first_name, $last_name, array_merge( $tags, array( 'context:subscribe' ) ) );
                                if ( $did_subscribe ) {
                                    self::update_inbox_submission_status( $wpdb, $table, $submission_id, 'released', 'released_with_doi', $now );
                                    $notice_type = 'success';
                                    $notice_text = __( 'Released: subscription flow started (double opt-in if enabled).', 'product-mailer-campaigns' );
                                    if ( $release_state['downgraded'] && ! empty( $release_state['notice'] ) ) {
                                        $notice_type = 'info';
                                        $notice_text = $release_state['notice'] . ' ' . $notice_text;
                                    }
                                    self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, $notice_type, $notice_text, $is_detail_action );
                                } else {
                                    self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'error', __( 'Release failed: could not start the subscription flow for this email.', 'product-mailer-campaigns' ) );
                                }
                            }
                        } else {
                            // Some Inbox items are already processed (admin email already sent) but still visible.
                            $already_sent_admin = ( ! empty( $submission->status ) && 'allowed' === (string) $submission->status && ! empty( $submission->reason ) && 'sent' === (string) $submission->reason );

                            // If already processed and admin chose message-only, don't resend.
                            if ( $already_sent_admin && 'release_message_only' === $action ) {
                                self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'info', __( 'Nothing to do: this message was already sent/processed.', 'product-mailer-campaigns' ), $is_detail_action );
                            }

                            $did_send_admin = $already_sent_admin ? true : self::send_inbox_submission_to_admin( $submission );
                            if ( ! $did_send_admin ) {
                                self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'error', __( 'Release failed: could not send the message to the admin email.', 'product-mailer-campaigns' ) );
                            } else {
                                // If already processed, only start DOI and keep the item in Inbox (do not mark as released).
                                if ( $already_sent_admin && 'release_with_doi' === $action ) {
                                    $subscriber_email = ! empty( $submission->email ) ? sanitize_email( (string) $submission->email ) : '';
                                    $did_subscribe = self::start_inbox_double_optin( $subscriber_email, '', '', array_merge( $tags, array( 'context:' . $context_key ) ) );
                                    if ( $did_subscribe ) {
                                        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Subscription flow started (double opt-in if enabled). Admin message was already sent.', 'product-mailer-campaigns' ), $is_detail_action );
                                    } else {
                                        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'warning', __( 'Admin message was already sent, but subscription flow could not be started.', 'product-mailer-campaigns' ), $is_detail_action );
                                    }
                                }
                                if ( 'release_with_doi' === $action ) {
                                    $subscriber_email = ! empty( $submission->email ) ? sanitize_email( (string) $submission->email ) : '';
                                    // Names are not reliably stored for contact/selling spam submissions, so we start with email only.
                                    $did_subscribe = self::start_inbox_double_optin( $subscriber_email, '', '', array_merge( $tags, array( 'context:' . $context_key ) ) );
                                }

                                // Mark as released so it disappears from Inbox/Spam lists.
                                $reason = ( 'release_with_doi' === $action ) ? 'released_with_doi' : 'released_message_only';
                                self::update_inbox_submission_status( $wpdb, $table, $submission_id, 'released', $reason, $now );

                                if ( 'release_with_doi' === $action ) {
                                    if ( $did_subscribe ) {
                                        $notice_type = 'success';
                                        $notice_text = __( 'Released: message sent to admin and subscription flow started (double opt-in if enabled).', 'product-mailer-campaigns' );
                                    } else {
                                        $notice_type = 'warning';
                                        $notice_text = __( 'Released: message sent to admin, but subscription flow could not be started.', 'product-mailer-campaigns' );
                                    }
                                } else {
                                    $notice_type = 'success';
                                    $notice_text = __( 'Released: message sent to admin.', 'product-mailer-campaigns' );
                                }

                                if ( $release_state['downgraded'] && ! empty( $release_state['notice'] ) ) {
                                    $notice_type = 'info';
                                    $notice_text = $release_state['notice'] . ' ' . $notice_text;
                                }

                                self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, $notice_type, $notice_text, $is_detail_action );
                            }
                        }
                    }

                    if ( 'allow_sender' === $action ) {
                        self::allow_inbox_sender( $email, $domain );
                        self::update_inbox_submission_status( $wpdb, $table, $submission_id, 'allowed', '', $now );
                        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Sender allowlisted and submission marked as allowed.', 'product-mailer-campaigns' ), $is_detail_action );
                    }

                    if ( 'block_sender' === $action ) {
                        self::block_inbox_sender( $email, $domain );
                        self::update_inbox_submission_status( $wpdb, $table, $submission_id, 'blocked', 'manual_block', $now );
                        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Sender blocked and submission marked as blocked.', 'product-mailer-campaigns' ), $is_detail_action );
                    }


                        if ( 'block_email' === $action ) {
                            self::block_inbox_email( $email );
                            self::update_inbox_submission_status( $wpdb, $table, $submission_id, 'blocked', 'manual_block', $now );
                            self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Email blocked and submission marked as spam.', 'product-mailer-campaigns' ), $is_detail_action );
                        }

                        if ( 'block_domain' === $action ) {
                            $blocked = self::block_inbox_domain( $domain );

                            if ( $blocked['protected'] ) {
                                self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'warning', __( 'This is a protected provider domain, so it cannot be blocked as a domain. Block the specific email instead.', 'product-mailer-campaigns' ), $is_detail_action );
                            }

                            if ( $blocked['blocked'] ) {
                                self::update_inbox_submission_status( $wpdb, $table, $submission_id, 'blocked', 'manual_block', $now );
                                self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Domain blocked and submission marked as spam.', 'product-mailer-campaigns' ), $is_detail_action );
                            }
                        }

                    // Mark as spam (adds to block list and marks submission blocked).
                    if ( 'mark_spam' === $action ) {
                        self::block_inbox_sender( $email, $domain );
                        self::update_inbox_submission_status( $wpdb, $table, $submission_id, 'blocked', 'manual_spam', $now );
                        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Submission marked as spam and sender blocked.', 'product-mailer-campaigns' ), $is_detail_action );
                    }

                    if ( 'mark_not_spam' === $action ) {
                        self::update_inbox_submission_status( $wpdb, $table, $submission_id, 'allowed', 'not_spam', $now );
                        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Submission marked as allowed.', 'product-mailer-campaigns' ), $is_detail_action );
                    }

                
    if ( 'unblock_domain' === $action ) {
        if ( $domain ) {
            self::inbox_unblock_domain( $domain );
        }
        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Domain unblocked.', 'product-mailer-campaigns' ), $is_detail_action );
    }

    if ( 'protect_domain' === $action ) {
        if ( $domain ) {
            self::inbox_protect_domain( $domain );
        }
        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Domain protected (never auto-block).', 'product-mailer-campaigns' ), $is_detail_action );
    }

    if ( 'timing_set_2' === $action ) {
        self::inbox_set_timing_settings( 'yes', 2 );
        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Timing rule updated (min 2 seconds).', 'product-mailer-campaigns' ), $is_detail_action );
    }

    if ( 'timing_disable' === $action ) {
        self::inbox_set_timing_settings( 'no', 0 );
        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Timing rule disabled.', 'product-mailer-campaigns' ), $is_detail_action );
    }

    if ( 'delete' === $action ) {
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                        $wpdb->delete( $table, array( 'id' => $submission_id ), array( '%d' ) );
                        self::redirect_after_inbox_action( $wpdb, $table, $submission_id, $filter_state, 'success', __( 'Submission deleted.', 'product-mailer-campaigns' ), $is_detail_action );
                    }
                }
            }

            self::maybe_handle_inbox_bulk_actions( $wpdb, $table );

            // Filters.
            $status        = (string) $filter_state['status'];
            $context       = (string) $filter_state['context'];
            $search        = (string) $filter_state['search'];
            $reason_filter = (string) $filter_state['reason_filter'];

                // Paging.
                $limit = 50;
                $paged = (int) $filter_state['paged'];
                $offset = ( $paged - 1 ) * $limit;

                $limit  = (int) $limit;
                $offset = (int) $offset;

                $search_like = '%' . $wpdb->esc_like( $search ) . '%';
                $reason_like = '%' . $wpdb->esc_like( $reason_filter ) . '%';

                // Optional campaign context (if campaigns table exists).
                $campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
                $campaigns_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $campaigns_table ) ) === $campaigns_table );

                if ( $campaigns_exists ) {
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names from $wpdb->prefix; values are prepared.
                    $rows = $wpdb->get_results(
                        $wpdb->prepare(
                            "SELECT s.*, c.name AS campaign_name
                                FROM {$table} s
                                LEFT JOIN {$campaigns_table} c ON c.id = s.campaign_id
                                WHERE s.status <> %s
                                AND ( %s = 'all' OR s.status = %s )
                                AND ( %s = 'all' OR s.context = %s )
                                AND ( %s = '' OR ( s.email LIKE %s OR s.domain LIKE %s OR s.subject LIKE %s OR s.message LIKE %s ) )
                                AND ( %s = 'all' OR s.reason LIKE %s )
                                ORDER BY s.created_at DESC
                                LIMIT %d OFFSET %d",
                            'discarded',
                            $status,
                            $status,
                            $context,
                            $context,
                            $search,
                            $search_like,
                            $search_like,
                            $search_like,
                            $search_like,
                            $reason_filter,
                            $reason_like,
                            $limit,
                            $offset
                        )
                    ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                } else {
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix; values are prepared.
                    $rows = $wpdb->get_results(
                        $wpdb->prepare(
                            "SELECT *
                                FROM {$table}
                                WHERE status <> %s
                                AND ( %s = 'all' OR status = %s )
                                AND ( %s = 'all' OR context = %s )
                                AND ( %s = '' OR ( email LIKE %s OR domain LIKE %s OR subject LIKE %s OR message LIKE %s ) )
                                AND ( %s = 'all' OR reason LIKE %s )
                                ORDER BY created_at DESC
                                LIMIT %d OFFSET %d",
                            'discarded',
                            $status,
                            $status,
                            $context,
                            $context,
                            $search,
                            $search_like,
                            $search_like,
                            $search_like,
                            $search_like,
                            $reason_filter,
                            $reason_like,
                            $limit,
                            $offset
                        )
                    ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                }

                // Total rows (base table only).
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix; values are prepared.
                $total = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*)
                            FROM {$table}
                            WHERE status <> %s
                            AND ( %s = 'all' OR status = %s )
                            AND ( %s = 'all' OR context = %s )
                            AND ( %s = '' OR ( email LIKE %s OR domain LIKE %s OR subject LIKE %s OR message LIKE %s ) )
                            AND ( %s = 'all' OR reason LIKE %s )",
                        'discarded',
                        $status,
                        $status,
                        $context,
                        $context,
                        $search,
                        $search_like,
                        $search_like,
                        $search_like,
                        $search_like,
                        $reason_filter,
                        $reason_like
                    )
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

            $total_pages = (int) ceil( $total / $limit );

            $base_url = admin_url( 'admin.php?page=pmcpc_inbox' );

            echo '<div class="wrap' . ( $view_id ? ' pmcpc-inbox-detail' : '' ) . '">';
            $mark_all_url = add_query_arg(
                array(
                    'page'                => 'pmcpc_inbox',
                    'pmcpc_mark_all_read' => 1,
                    '_pmcpc_mark_all_nonce' => wp_create_nonce( 'pmcpc_mark_all_read' ),
                ),
                admin_url( 'admin.php' )
            );
            if ( $view_id ) {
                PMCPC_Admin::render_app_header( __( 'Inbox Review', 'product-mailer-campaigns' ) );
            } else {
                PMCPC_Admin::render_app_header(
                    __( 'Inbox Review', 'product-mailer-campaigns' ),
                    array(
                        array(
                            'label' => __( 'Mark all as read', 'product-mailer-campaigns' ),
                            'url'   => $mark_all_url,
                        ),
                    )
                );
            }

            // Unread row highlighting (per-admin). Uses the same "last seen" pointer as the Messages menu badge.
            $pmcpc_last_seen_id = (int) get_user_meta( get_current_user_id(), 'pmcpc_messages_last_seen_id', true );
            $counts = array(
                'all'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status <> 'discarded'" ),
                'allowed' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'allowed'" ),
                'held'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'held'" ),
                'blocked' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'blocked'" ),
                'unread'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status <> 'discarded' AND id > %d", $pmcpc_last_seen_id ) ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            );
            if ( ! $view_id ) {
                PMCPC_Admin::render_page_intro(
                    __( 'Inbox Review', 'product-mailer-campaigns' ),
                    __( 'Review incoming messages, decide what to do next, and only use sender controls when you need to affect future messages.', 'product-mailer-campaigns' ),
                    array(
                        array(
                            'label' => __( 'Review new messages first', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-email-alt',
                        ),
                        array(
                            'label' => __( 'Release safe messages', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-yes-alt',
                        ),
                        array(
                            'label' => __( 'Use block tools for repeat spam', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-shield',
                        ),
                    )
                );
                PMCPC_Admin::render_stats_strip(
                    array(
                        array(
                            'label' => __( 'Unread', 'product-mailer-campaigns' ),
                            'value' => (string) $counts['unread'],
                            'meta'  => __( 'Messages newer than your last seen marker', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Inbox', 'product-mailer-campaigns' ),
                            'value' => (string) $counts['allowed'],
                            'meta'  => __( 'Allowed messages ready for review', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Held', 'product-mailer-campaigns' ),
                            'value' => (string) $counts['held'],
                            'meta'  => __( 'Messages still waiting for a decision', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Spam', 'product-mailer-campaigns' ),
                            'value' => (string) $counts['blocked'],
                            'meta'  => __( 'Blocked messages and sender issues', 'product-mailer-campaigns' ),
                        ),
                    )
                );
            }
            $tabs = array(
                'all'     => __( 'All', 'product-mailer-campaigns' ) . ' (' . $counts['all'] . ')',
                'allowed' => __( 'Inbox', 'product-mailer-campaigns' ) . ' (' . $counts['allowed'] . ')',
                'held'    => __( 'Held', 'product-mailer-campaigns' ) . ' (' . $counts['held'] . ')',
                'blocked' => __( 'Spam', 'product-mailer-campaigns' ) . ' (' . $counts['blocked'] . ')',
            );
            if ( ! $view_id ) {
            echo '<h2 class="nav-tab-wrapper" style="margin-top: 10px;">';
                    foreach ( $tabs as $tab_key => $tab_label ) {
                        $tab_url = add_query_arg(
                            array(
                                'page'         => 'pmcpc_inbox',
                                'pmcpc_status' => $tab_key,
                                'pmcpc_context'=> $context,
                                'pmcpc_reason' => $reason_filter,
                                's'            => $search,
                            ),
                            admin_url( 'admin.php' )
                        );
                        $active = ( $status === $tab_key ) ? ' nav-tab-active' : '';
                        echo '<a class="nav-tab' . esc_attr( $active ) . '" href="' . esc_url( $tab_url ) . '">' . esc_html( $tab_label ) . '</a>';
                    }
                    echo '</h2>';
        
                
            }

    // Filter form.
    if ( ! $view_id ) {
            echo '<div class="pmcpc-inbox-toolbar">';
            echo '<p class="pmcpc-inbox-toolbar__intro">' . esc_html__( 'Use filters to narrow the queue, then open a message to review its content and take the most appropriate next action.', 'product-mailer-campaigns' ) . '</p>';
            echo '<form method="get" class="pmcpc-inbox-filter-form">';
            echo '<input type="hidden" name="page" value="pmcpc_inbox" />';
            echo '<input type="hidden" name="pmcpc_reason" value="' . esc_attr( $reason_filter ) . '" />';
            echo '<select name="pmcpc_status">';
            $statuses = array(
                'all'     => __( 'All statuses', 'product-mailer-campaigns' ),
                'allowed' => __( 'Inbox', 'product-mailer-campaigns' ) . ' (' . $counts['allowed'] . ')',
                'held'    => __( 'Held', 'product-mailer-campaigns' ) . ' (' . $counts['held'] . ')',
                'blocked' => __( 'Spam', 'product-mailer-campaigns' ) . ' (' . $counts['blocked'] . ')',
            );
            foreach ( $statuses as $k => $label ) {
                echo '<option value="' . esc_attr( $k ) . '" ' . selected( $status, $k, false ) . '>' . esc_html( $label ) . '</option>';
            }
            echo '</select> ';
            echo '<select name="pmcpc_context">';
            $contexts = array(
                'all'      => __( 'All contexts', 'product-mailer-campaigns' ),
                'contact'  => __( 'Contact', 'product-mailer-campaigns' ),
                'selling'  => __( 'Selling', 'product-mailer-campaigns' ),
                'subscribe'=> __( 'Subscribe', 'product-mailer-campaigns' ),
                'checkout' => __( 'Checkout', 'product-mailer-campaigns' ),
            );
            foreach ( $contexts as $ckey => $clabel ) {
                echo '<option value="' . esc_attr( $ckey ) . '" ' . selected( $context, $ckey, false ) . '>' . esc_html( $clabel ) . '</option>';
            }
            echo '</select> ';
            echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'Search messages…', 'product-mailer-campaigns' ) . '" style="width:280px;" /> ';
            submit_button( __( 'Filter', 'product-mailer-campaigns' ), 'secondary', '', false );
            echo '</form>';
            echo '</div>';

            $active_filter_parts = array();
            $active_reason_labels = array(
                'honeypot'       => __( 'Honeypot', 'product-mailer-campaigns' ),
                'suspicious_tld' => __( 'Suspicious TLD', 'product-mailer-campaigns' ),
                'too_fast'       => __( 'Too fast', 'product-mailer-campaigns' ),
                'spammy_name'    => __( 'Spammy name', 'product-mailer-campaigns' ),
                'blocked_domain' => __( 'Blocked domain', 'product-mailer-campaigns' ),
                'blocked_email'  => __( 'Blocked email', 'product-mailer-campaigns' ),
                'manual_spam'    => __( 'Manual spam', 'product-mailer-campaigns' ),
                'manual_block'   => __( 'Manual block', 'product-mailer-campaigns' ),
            );
            if ( 'all' !== $status ) {
                $active_filter_parts[] = array(
                    'label' => __( 'Status', 'product-mailer-campaigns' ),
                    'value' => isset( $statuses[ $status ] ) ? wp_strip_all_tags( (string) $statuses[ $status ] ) : ucfirst( $status ),
                );
            }
            if ( 'all' !== $context ) {
                $active_filter_parts[] = array(
                    'label' => __( 'Context', 'product-mailer-campaigns' ),
                    'value' => isset( $contexts[ $context ] ) ? (string) $contexts[ $context ] : ucfirst( $context ),
                );
            }
            if ( 'all' !== $reason_filter ) {
                $reason_label = isset( $active_reason_labels[ $reason_filter ] ) ? $active_reason_labels[ $reason_filter ] : ucwords( str_replace( array( '_', '-' ), ' ', (string) $reason_filter ) );
                $active_filter_parts[] = array(
                    'label' => __( 'Reason', 'product-mailer-campaigns' ),
                    'value' => $reason_label,
                );
            }
            if ( '' !== $search ) {
                $active_filter_parts[] = array(
                    'label' => __( 'Search', 'product-mailer-campaigns' ),
                    'value' => '"' . $search . '"',
                );
            }
            if ( ! empty( $active_filter_parts ) ) {
                echo '<div class="pmcpc-active-filters">';
                echo '<span class="pmcpc-active-filters__label">' . esc_html__( 'Active filters', 'product-mailer-campaigns' ) . '</span>';
                foreach ( $active_filter_parts as $filter_part ) {
                    echo '<span class="pmcpc-active-filters__chip"><strong>' . esc_html( $filter_part['label'] ) . ':</strong> ' . esc_html( $filter_part['value'] ) . '</span>';
                }
                echo '<a class="pmcpc-active-filters__clear" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_inbox' ) ) . '">' . esc_html__( 'Clear filters', 'product-mailer-campaigns' ) . '</a>';
                echo '</div>';
            }
    }

    // Detail view.
            if ( $view_id ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
                $view_row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $view_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
                if ( $view_row ) {
                    // --- Rule transparency helpers (kept local to avoid wide refactors) ---
                    $pmcpc_reason_map = array(
                        'honeypot'        => __( 'Honeypot field was filled', 'product-mailer-campaigns' ),
                        'rate_limit'      => __( 'Too many submissions (rate limit)', 'product-mailer-campaigns' ),
                        'suspicious_tld'  => __( 'Suspicious email domain/TLD', 'product-mailer-campaigns' ),
                        'spammy_name'     => __( 'Spammy name / content', 'product-mailer-campaigns' ),
                        'blocked_domain'  => __( 'Sender domain is blocked', 'product-mailer-campaigns' ),
                        'blocked_email'   => __( 'Sender email is blocked', 'product-mailer-campaigns' ),
                        'allowlisted'     => __( 'Sender is allowlisted', 'product-mailer-campaigns' ),
                        'manual_block'    => __( 'Manually blocked by an admin', 'product-mailer-campaigns' ),
                        'manual_spam'     => __( 'Marked as spam by an admin', 'product-mailer-campaigns' ),
                        'not_spam'        => __( 'Marked as not spam by an admin', 'product-mailer-campaigns' ),
                    );

                    $pmcpc_parse_reasons = static function( $reason_raw ) {
                        $reason_raw = (string) $reason_raw;
                        if ( '' === trim( $reason_raw ) ) {
                            return array();
                        }
                        $parts = array_filter( array_map( 'trim', explode( ',', $reason_raw ) ) );
                        return array_values( array_unique( $parts ) );
                    };

                    $pmcpc_is_manual_decision = static function( $reason_raw ) use ( $pmcpc_parse_reasons ) {
                        $reasons = $pmcpc_parse_reasons( $reason_raw );
                        foreach ( $reasons as $r ) {
                            if ( 0 === strpos( $r, 'manual_' ) || 'not_spam' === $r ) {
                                return true;
                            }
                        }
                        return false;
                    };

                    // Navigation (Back / Prev / Next).
                    // IMPORTANT: Navigation must follow the *same dataset* as the list view.
                    // The list view always hides auto-deleted submissions (status = discarded),
                    // so we must also exclude them here. Otherwise "Previous/Next" can scroll
                    // through items the user cannot see in the list.

                    $back_url = remove_query_arg( array( 'pmcpc_view_id' ) );

                    $nav_where_parts = array( "status <> 'discarded'" );
                    $nav_where_args  = array();

                    // Keep navigation within the active filters when present.
                    if ( isset( $status ) && 'all' !== $status ) {
                        $nav_where_parts[] = 'status = %s';
                        $nav_where_args[]  = $status;
                    }
                    if ( isset( $context ) && 'all' !== $context ) {
                        $nav_where_parts[] = 'context = %s';
                        $nav_where_args[]  = $context;
                    }
                    if ( isset( $reason_filter ) && 'all' !== $reason_filter ) {
                        $nav_where_parts[] = 'reason LIKE %s';
                        $nav_where_args[]  = $reason_like;
                    }
                    if ( ! empty( $search ) ) {
                        $nav_where_parts[] = '(email LIKE %s OR subject LIKE %s OR message LIKE %s)';
                        $nav_where_args[]  = $search_like;
                        $nav_where_args[]  = $search_like;
                        $nav_where_args[]  = $search_like;
                    }

                    $nav_where_sql = implode( ' AND ', $nav_where_parts );

                    // If the current item itself is discarded, hide navigation entirely.
                    // (This should be unreachable from the list view, but can happen via direct URL.)
                    if ( isset( $view_row->status ) && 'discarded' === (string) $view_row->status ) {
                        $prev_id  = 0;
                        $next_id  = 0;
                        $prev_url = '';
                        $next_url = '';
                    } else {
                        // Prev.
                        $prev_sql  = "SELECT id FROM {$table} WHERE {$nav_where_sql} AND id < %d ORDER BY id DESC LIMIT 1"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                        $prev_args = array_merge( $nav_where_args, array( $view_id ) );
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
                        $prev_id = (int) $wpdb->get_var( $wpdb->prepare( $prev_sql, $prev_args ) );

                        // Next.
                        $next_sql  = "SELECT id FROM {$table} WHERE {$nav_where_sql} AND id > %d ORDER BY id ASC LIMIT 1"; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                        $next_args = array_merge( $nav_where_args, array( $view_id ) );
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
                        $next_id = (int) $wpdb->get_var( $wpdb->prepare( $next_sql, $next_args ) );

                        // Preserve current filters when navigating.
                        $nav_qs = array();
                        if ( isset( $status ) && 'all' !== $status ) {
                            $nav_qs['pmcpc_status'] = $status;
                        }
                        if ( isset( $context ) && 'all' !== $context ) {
                            $nav_qs['pmcpc_context'] = $context;
                        }
                        if ( isset( $reason_filter ) && 'all' !== $reason_filter ) {
                            $nav_qs['pmcpc_reason'] = $reason_filter;
                        }
                        if ( ! empty( $search ) ) {
                            $nav_qs['s'] = $search;
                        }

                        $prev_url = $prev_id ? add_query_arg( array_merge( $nav_qs, array( 'pmcpc_view_id' => $prev_id ) ), $back_url ) : '';
                        $next_url = $next_id ? add_query_arg( array_merge( $nav_qs, array( 'pmcpc_view_id' => $next_id ) ), $back_url ) : '';
                    }

                    $context_key = isset( $view_row->context ) ? (string) $view_row->context : '';
                    $context_badge_label = $context_key;
                    switch ( $context_key ) {
                        case 'subscribe':
                            $context_badge_label = __( 'Subscription attempt', 'product-mailer-campaigns' );
                            break;
                        case 'contact':
                            $context_badge_label = __( 'Contact message', 'product-mailer-campaigns' );
                            break;
                        case 'selling':
                            $context_badge_label = __( 'Selling enquiry', 'product-mailer-campaigns' );
                            break;
                    }
                    $view_status_label = (string) $view_row->status;
                    if ( 'blocked' === $view_status_label ) { $view_status_label = __( 'Spam', 'product-mailer-campaigns' ); }
                    elseif ( 'allowed' === $view_status_label ) { $view_status_label = __( 'Inbox', 'product-mailer-campaigns' ); }
                    elseif ( 'held' === $view_status_label ) { $view_status_label = __( 'Held', 'product-mailer-campaigns' ); }
                    PMCPC_Admin::render_page_intro(
                        __( 'Message review', 'product-mailer-campaigns' ),
                        __( 'Review the message first, then use the recommended actions below to release it, trust the sender, or block future submissions safely.', 'product-mailer-campaigns' ),
                        array(
                            array(
                                'label' => __( 'Summary and content first', 'product-mailer-campaigns' ),
                                'icon'  => 'dashicons-media-text',
                            ),
                            array(
                                'label' => __( 'Recommended actions next', 'product-mailer-campaigns' ),
                                'icon'  => 'dashicons-controls-forward',
                            ),
                        )
                    );
                    PMCPC_Admin::render_stats_strip(
                        array(
                            array(
                                'label' => __( 'Status', 'product-mailer-campaigns' ),
                                'value' => $view_status_label,
                                'meta'  => __( 'Current review state', 'product-mailer-campaigns' ),
                            ),
                            array(
                                'label' => __( 'Context', 'product-mailer-campaigns' ),
                                'value' => $context_badge_label,
                                'meta'  => __( 'Why this message was submitted', 'product-mailer-campaigns' ),
                            ),
                            array(
                                'label' => __( 'Sender', 'product-mailer-campaigns' ),
                                'value' => (string) $view_row->email,
                                'meta'  => __( 'Used for reply, allow, and block actions', 'product-mailer-campaigns' ),
                            ),
                        )
                    );
                    echo '<div class="pmcpc-inbox-detail-shell">';
                    echo '<div class="card pmcpc-inbox-summary-card" style="max-width: 100%;">';
                    echo '<h2 style="margin-top:0;">' . esc_html__( 'Message summary', 'product-mailer-campaigns' ) . '</h2>';
                    echo '<p class="pmcpc-inbox-detail-copy">' . esc_html__( 'Confirm the sender, context, and current review state before you decide what to do next.', 'product-mailer-campaigns' ) . '</p>';
                    echo '<div class="pmcpc-submission-nav">';
                    echo '<div class="pmcpc-nav-left">';
                    echo '<a class="button" href="' . esc_url( $back_url ) . '">' . esc_html__( '← Back to Messages', 'product-mailer-campaigns' ) . '</a>';
                    echo '</div>';
                    echo '<div class="pmcpc-nav-right">';
                    if ( $prev_url ) {
                        echo '<a class="button" href="' . esc_url( $prev_url ) . '">' . esc_html__( '← Previous', 'product-mailer-campaigns' ) . '</a>';
                    }
                    if ( $next_url ) {
                        echo '<a class="button" href="' . esc_url( $next_url ) . '">' . esc_html__( 'Next →', 'product-mailer-campaigns' ) . '</a>';
                    }
                    echo '</div>';
                    echo '</div>';
                    $context_key = isset( $view_row->context ) ? (string) $view_row->context : '';
                    $context_badge_label = $context_key;
                    $context_badge_emoji = '📝';
                    switch ( $context_key ) {
                        case 'subscribe':
                            $context_badge_label = __( 'Subscription attempt', 'product-mailer-campaigns' );
                            $context_badge_emoji = '📩';
                            break;
                        case 'contact':
                            $context_badge_label = __( 'Contact message', 'product-mailer-campaigns' );
                            $context_badge_emoji = '💬';
                            break;
                        case 'selling':
                            $context_badge_label = __( 'Selling enquiry', 'product-mailer-campaigns' );
                            $context_badge_emoji = '🪑';
                            break;
                    }
                    echo '<p style="margin:-6px 0 10px 0;"><span style="display:inline-block;padding:3px 10px;border:1px solid #dcdcde;border-radius:999px;background:#f6f7f7;font-size:12px;line-height:1.8;">' . esc_html( $context_badge_emoji . ' ' . $context_badge_label ) . '</span></p>';

                    echo '<div class="pmcpc-meta-grid">';

                    $email_disp = (string) $view_row->email;
                    echo '<p><strong>' . esc_html__( 'Email:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $email_disp );
                    if ( $email_disp ) {
                        $reply = 'mailto:' . rawurlencode( $email_disp );
                        $subj  = (string) $view_row->subject;
                        if ( $subj ) {
                            $reply .= '?subject=' . rawurlencode( 'Re: ' . $subj );
                        }
                        echo ' <a href="' . esc_url( $reply ) . '" class="button button-small" style="margin-left:8px;">' . esc_html__( 'Reply', 'product-mailer-campaigns' ) . '</a>';
                    }
                    echo '</p>';
                    echo '<p><strong>' . esc_html__( 'Context:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $context_key ? $context_key : (string) $view_row->context ) . '</p>';

                    // Campaign context (optional).
                    $campaign_id = isset( $view_row->campaign_id ) ? absint( $view_row->campaign_id ) : 0;
                    if ( $campaign_id && isset( $campaigns_exists ) && $campaigns_exists ) {
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
                        $campaign_name = (string) $wpdb->get_var( $wpdb->prepare( "SELECT name FROM {$campaigns_table} WHERE id = %d", $campaign_id ) );
                        $edit_url = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . $campaign_id );
                        echo '<p><strong>' . esc_html__( 'Campaign:', 'product-mailer-campaigns' ) . '</strong> <a href="' . esc_url( $edit_url ) . '">' . esc_html( $campaign_name ? $campaign_name : ( '#' . $campaign_id ) ) . '</a></p>';
                    } else {
                        echo '<p><strong>' . esc_html__( 'Campaign:', 'product-mailer-campaigns' ) . '</strong> <span style="color:#6c7781;">' . esc_html__( '—', 'product-mailer-campaigns' ) . '</span></p>';
                    }
                    $view_status_label = (string) $view_row->status;
                    if ( 'blocked' === $view_status_label ) { $view_status_label = __( 'Spam', 'product-mailer-campaigns' ); }
                    elseif ( 'allowed' === $view_status_label ) { $view_status_label = __( 'Inbox', 'product-mailer-campaigns' ); }
                    elseif ( 'held' === $view_status_label ) { $view_status_label = __( 'Held', 'product-mailer-campaigns' ); }
                    echo '<p><strong>' . esc_html__( 'Status:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $view_status_label ) . '</p>';

                    $ip_hash_view = isset( $view_row->ip_hash ) ? (string) $view_row->ip_hash : '';
                    if ( $ip_hash_view ) {
                        echo '<p><strong>' . esc_html__( 'IP hash:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( substr( $ip_hash_view, 0, 16 ) ) . '</p>';
                    }

                    echo '</div>'; // .pmcpc-meta-grid

                    // Rule transparency panel.
                    $reason_raw = isset( $view_row->reason ) ? (string) $view_row->reason : '';
                    $reasons    = $pmcpc_parse_reasons( $reason_raw );
                    $is_manual  = $pmcpc_is_manual_decision( $reason_raw );
                    $decision   = $is_manual ? __( 'Manual', 'product-mailer-campaigns' ) : __( 'Automatic', 'product-mailer-campaigns' );
                    $source     = $is_manual ? __( 'Admin action', 'product-mailer-campaigns' ) : __( 'Spam engine', 'product-mailer-campaigns' );

                    $border = ( 'blocked' === (string) $view_row->status ) ? 'border-left-color:#d63638;' : 'border-left-color:#2271b1;';
                    echo '<div class="pmcpc-review-decision" style="' . esc_attr( $border ) . '">';
                    if ( 'blocked' === (string) $view_row->status ) {
                        echo '<h3 style="margin:0 0 8px 0;">' . esc_html__( 'Why this was blocked', 'product-mailer-campaigns' ) . '</h3>';
                    } else {
                        echo '<h3 style="margin:0 0 8px 0;">' . esc_html__( 'Decision details', 'product-mailer-campaigns' ) . '</h3>';
                    }

                    echo '<div class="pmcpc-review-decision__meta">';
                    echo '<p><span class="pmcpc-review-decision__label">' . esc_html__( 'Decision', 'product-mailer-campaigns' ) . '</span>' . esc_html( $decision ) . '</p>';
                    echo '<p><span class="pmcpc-review-decision__label">' . esc_html__( 'Rule source', 'product-mailer-campaigns' ) . '</span>' . esc_html( $source ) . '</p>';
                    echo '</div>';
                    echo '<p style="margin: 0 0 6px 0;"><span class="pmcpc-review-decision__label" style="display:inline-block;margin-bottom:0;">' . esc_html__( 'Reasons', 'product-mailer-campaigns' ) . '</span></p>';
                    if ( empty( $reasons ) ) {
                        echo '<p class="pmcpc-review-decision__note">' . esc_html__( 'No reason provided.', 'product-mailer-campaigns' ) . '</p>';
                    } else {
                        echo '<ul class="pmcpc-review-decision__reasons">';
                        foreach ( $reasons as $r ) {
                            $label = isset( $pmcpc_reason_map[ $r ] ) ? $pmcpc_reason_map[ $r ] : $r;
                            echo '<li>' . esc_html( $label ) . ' <span style="color:#6c7781;">(' . esc_html( $r ) . ')</span></li>';
                        }
                        echo '</ul>';
                        // Extra clarity for name-based blocks (common for subscription spam).
                        if ( in_array( 'spammy_name', $reasons, true ) ) {
                            $name_val = '';
                            if ( 'subscribe' === $context_key ) {
                                $fn = trim( (string) $view_row->subject );
                                $ln = trim( (string) $view_row->message );
                                $name_val = trim( $fn . ' ' . $ln );
                            }
                            echo '<p class="pmcpc-review-decision__note"><strong>' . esc_html__( 'Triggered field:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html__( 'Name', 'product-mailer-campaigns' ) . '</p>';
                            if ( $name_val ) {
                                echo '<p class="pmcpc-review-decision__note" style="margin-top:2px;"><strong>' . esc_html__( 'Value:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $name_val ) . '</p>';
                            }
                        }
                    }


                    // Spam score (message/content scoring) + compact signals.
                    $spam_score_view = null;
                    $score_details   = array();
                    if ( isset( $view_row->spam_score ) && '' !== (string) $view_row->spam_score ) {
                        $spam_score_view = (float) $view_row->spam_score;
                    }
                    if ( ! empty( $view_row->score_details ) ) {
                        $decoded = json_decode( (string) $view_row->score_details, true );
                        if ( is_array( $decoded ) ) {
                            $score_details = $decoded;
                        }
                    }
                    if ( null !== $spam_score_view ) {
                        echo '<p class="pmcpc-review-decision__note"><strong>' . esc_html__( 'Spam score:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( rtrim( rtrim( number_format( $spam_score_view, 2, '.', '' ), '0' ), '.' ) ) . '</p>';

                        // Render a compact, human-readable signals line if present.
                        if ( ! empty( $score_details ) ) {
                            $signals = array();
                            foreach ( $score_details as $item ) {
                                if ( is_string( $item ) ) {
                                    $item = trim( $item );
                                    if ( '' !== $item ) {
                                        $signals[] = $item;
                                    }
                                    continue;
                                }
                                if ( is_array( $item ) && isset( $item['label'], $item['score'] ) ) {
                                    $label = trim( (string) $item['label'] );
                                    $val   = (float) $item['score'];
                                    if ( '' !== $label ) {
                                        $signals[] = sprintf( '%s (%+0.1f)', $label, $val );
                                    }
                                }
                            }
                            if ( ! empty( $signals ) ) {
                                $signals = array_slice( $signals, 0, 6 );
                                echo '<p class="pmcpc-review-decision__note" style="margin-top:2px;font-size:12px;">';
                                echo '<strong>' . esc_html__( 'Signals:', 'product-mailer-campaigns' ) . '</strong> ';
                                echo esc_html( implode( ', ', $signals ) );
                                echo '</p>';
                            }
                        }
                    } else {
                        echo '<p class="pmcpc-review-decision__note"><strong>' . esc_html__( 'Spam score:', 'product-mailer-campaigns' ) . '</strong> <span style="color:#6c7781;">' . esc_html__( 'n/a (rule-based)', 'product-mailer-campaigns' ) . '</span></p>';
                    }
                    echo '</div>';

                    // (IP hash moved into the meta grid above for consistent layout.)
                    // Wrap subject so admins can highlight text and add it as a spam phrase (training UX).
                    // Layout: main content (left) + sidebar (right)
                    echo '<div class="pmcpc-submission-layout">';
                    echo '<div class="pmcpc-submission-main">';
                    echo '<div class="pmcpc-inbox-content-card">';

                    $raw_subject_view = isset( $view_row->subject ) ? (string) $view_row->subject : '';
                    $raw_message_view = isset( $view_row->message ) ? (string) $view_row->message : '';

                    // Contact/selling messages may include an opt-in marker from the front-end form.
                    $has_optin_marker = false;
                    if ( false !== strpos( $raw_message_view, '[pmcpc_opt_in=1]' ) ) {
                        $has_optin_marker = true;
                        $raw_message_view = str_replace( '[pmcpc_opt_in=1]', '', $raw_message_view );
                        $raw_message_view = trim( $raw_message_view );
                    }

                    if ( 'subscribe' === $context_key ) {
                        // Keep the same layout as other message types, but render subscriber fields clearly.
                        $first_name_view = trim( $raw_subject_view );
                        $last_name_view  = trim( $raw_message_view );

                        echo '<h2>' . esc_html__( 'Message content', 'product-mailer-campaigns' ) . '</h2>';
                        echo '<p class="pmcpc-inbox-detail-copy">' . esc_html__( 'Subscription requests are shown as subscriber details so you can quickly confirm what was submitted before taking action.', 'product-mailer-campaigns' ) . '</p>';
                        echo '<p><strong>' . esc_html__( 'Subject:', 'product-mailer-campaigns' ) . '</strong> <span id="pmcpc-view-subject">' . esc_html__( 'Subscription request', 'product-mailer-campaigns' ) . '</span></p>';

                        echo '<h3 style="margin-bottom:8px;">' . esc_html__( 'Subscriber details', 'product-mailer-campaigns' ) . '</h3>';
                        echo '<div style="border:1px solid #ccd0d4; padding:12px; background:#fff;">';
                        echo '<p style="margin:0 0 8px;"><strong>' . esc_html__( 'First name:', 'product-mailer-campaigns' ) . '</strong> ' . ( $first_name_view ? esc_html( $first_name_view ) : '<span style="color:#6c7781;">' . esc_html__( '—', 'product-mailer-campaigns' ) . '</span>' ) . '</p>';
                        echo '<p style="margin:0 0 8px;"><strong>' . esc_html__( 'Last name:', 'product-mailer-campaigns' ) . '</strong> ' . ( $last_name_view ? esc_html( $last_name_view ) : '<span style="color:#6c7781;">' . esc_html__( '—', 'product-mailer-campaigns' ) . '</span>' ) . '</p>';
                        echo '<p style="margin:0;"><strong>' . esc_html__( 'Opt-in:', 'product-mailer-campaigns' ) . '</strong> <span style="display:inline-block;padding:1px 8px;border:1px solid #dcdcde;border-radius:999px;background:#f6f7f7;">' . esc_html__( 'Yes', 'product-mailer-campaigns' ) . '</span></p>';
                        echo '</div>';

                        // For spam training/highlighting, treat the combined subscriber fields as the "message" text.
                        $raw_message_view = trim( ( $first_name_view ? ( 'First name: ' . $first_name_view ) : '' ) . "
    " . ( $last_name_view ? ( 'Last name: ' . $last_name_view ) : '' ) );
                    } else {
                        // Wrap subject so admins can highlight text and add it as a spam phrase (training UX).
                        echo '<h2>' . esc_html__( 'Message content', 'product-mailer-campaigns' ) . '</h2>';
                        echo '<p class="pmcpc-inbox-detail-copy">' . esc_html__( 'Read the submitted content here before deciding whether to release it, trust the sender, or block it.', 'product-mailer-campaigns' ) . '</p>';
                        echo '<p><strong>' . esc_html__( 'Subject:', 'product-mailer-campaigns' ) . '</strong> <span id="pmcpc-view-subject">' . esc_html( (string) $view_row->subject ) . '</span></p>';
                    }

                    echo '<div class="pmcpc-inbox-message-toolbar"><h3>' . esc_html__( 'Message', 'product-mailer-campaigns' ) . '</h3><button type="button" class="button button-small" id="pmcpc-toggle-highlights" style="margin-left:auto;">' . esc_html__( 'Show highlights', 'product-mailer-campaigns' ) . '</button></div>';
                    echo '<textarea id="pmcpc-raw-message" style="display:none;">' . esc_textarea( $raw_message_view ) . '</textarea>';
                    echo '<textarea id="pmcpc-raw-subject" style="display:none;">' . esc_textarea( $raw_subject_view ) . '</textarea>';
                    echo '<div id="pmcpc-view-message" class="pmcpc-inbox-message-surface">' . wp_kses_post( $raw_message_view ) . '</div>';
                    // Floating “Add selected phrase” button (shown when the admin highlights text in subject/message).
                    echo '<button type="button" class="button button-small" id="pmcpc-add-selection" style="display:none;position:fixed;z-index:99999;">' . esc_html__( 'Add phrase', 'product-mailer-campaigns' ) . '</button>';

                    if ( $has_optin_marker && in_array( (string) $view_row->context, array( 'contact', 'selling' ), true ) ) {
                        echo '<p style="margin-top:6px; color:#6c7781;"><em>' . esc_html__( 'Opt-in: subscriber requested (double opt-in available).', 'product-mailer-campaigns' ) . '</em></p>';
                    }
                    echo '</div>';

    ob_start();
                        // --- Spam training panel (keyword phrases) ---
    // --- Spam training panel (keyword phrases) ---
                    $spam_keywords_enabled = ( 'yes' === (string) PMCPC_Settings::get( 'spam_message_keywords_enabled', 'yes' ) );
                    $spam_keywords_list    = (string) PMCPC_Settings::get( 'spam_message_keywords', '' );
                    $trained_phrases_raw   = preg_split( '/\r\n|\r|\n/', $spam_keywords_list );
                    $trained_phrases_raw   = is_array( $trained_phrases_raw ) ? $trained_phrases_raw : array();
                    $trained_phrases       = array();
                    $trained_norm          = array();
                    foreach ( $trained_phrases_raw as $p ) {
                        $p = trim( (string) $p );
                        if ( '' === $p || strlen( $p ) < 3 ) {
                            continue;
                        }
                        $trained_phrases[] = $p;
                        $trained_norm[ strtolower( $p ) ] = true;
                    }
                    $subject_plain = strtolower( wp_strip_all_tags( (string) $view_row->subject ) );
                    $message_plain = strtolower( wp_strip_all_tags( $raw_message_view ) );
                    $trained_hits  = array();
                    foreach ( $trained_phrases as $phrase ) {
                        $needle = strtolower( $phrase );
                        $in_sub = ( '' !== $subject_plain && false !== stripos( $subject_plain, $needle ) );
                        $in_msg = ( '' !== $message_plain && false !== stripos( $message_plain, $needle ) );
                        if ( $in_sub || $in_msg ) {
                            $loc = array();
                            if ( $in_sub ) { $loc[] = __( 'subject', 'product-mailer-campaigns' ); }
                            if ( $in_msg ) { $loc[] = __( 'message', 'product-mailer-campaigns' ); }
                            $trained_hits[] = array( 'phrase' => $phrase, 'loc' => implode( ', ', $loc ) );
                        }
                    }

                    // Suggestions: simple n-gram extractor with trigger words.
                    // We treat some triggers as "strong" (useful even alone) and others as "weak" (need more than one to avoid noise).
                    // Note: this runs even when the submission was blocked by other spam rules (e.g. too_fast) so admins can still train phrases.
                    $strong_triggers = array(
                        // Marketing/SEO.
                        'seo', 'backlink', 'backlinks', 'guest post', 'guest', 'write for us', 'outreach',
                        // Adult/dating spam.
                        'intimate', 'hook up', 'hookup', 'dating', 'escort', 'nude', 'sex', 'xxx', 'onlyfans',
                    );
                    $weak_triggers   = array(
                        // Marketing/SEO.
                        'traffic', 'marketing', 'ai', 'service', 'rank', 'ranking', 'google', 'advertising', 'increase', 'boost', 'leads', 'keywords', 'clicks', 'search',
                        // Adult/dating spam.
                        'connection', 'wildness', 'ordinary',
                    );
                                // Weak triggers that are allowed to stand alone in short (2-word) phrases.
                                $single_weak_ok = array( 'advertising', 'marketing', 'service', 'traffic', 'seo', 'dating', 'intimate', 'connection' );
                    $triggers        = array_merge( $strong_triggers, $weak_triggers );
                    // Stopwords for suggestion extraction (also excludes common TLD fragments so we don't suggest phrases like "example com").
                    $stopwords = array( 'the','and','for','with','that','this','your','you','our','are','can','will','from','into','than','now','have','has','been','was','were','they','them','their','its','it','a','an','to','of','in','on','at','by','as','or','is','www','com','net','org','co','uk', 'start','save','bringing','powered','solution','less' );
                    // Also exclude the site host words (to avoid suggesting phrases that include your own domain/brand).
                    $site_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
                    $site_host = strtolower( preg_replace( '/^www\./i', '', $site_host ) );
                    if ( '' !== $site_host ) {
                        $host_parts = preg_split( '/\.+/', $site_host );
                        if ( is_array( $host_parts ) ) {
                            foreach ( $host_parts as $hp ) {
                                $hp = trim( (string) $hp );
                                if ( '' !== $hp && strlen( $hp ) >= 4 ) {
                                    $stopwords[] = $hp;
                                }
                            }
                        }
                    }
                    $build_tokens = function( $text ) use ( $stopwords ) {
                        $text = strtolower( (string) $text );
                        $text = preg_replace( '/https?:\/\/\S+/i', ' ', $text );
                        $text = preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $text );
                        $words = preg_split( '/\s+/', trim( $text ) );
                        $out = array();
                        foreach ( $words as $w ) {
                            $w = trim( $w );
                            if ( '' === $w ) { continue; }
                            if ( in_array( $w, $stopwords, true ) ) { continue; }
                            if ( strlen( $w ) < 3 ) { continue; }
                            $out[] = $w;
                        }
                        return $out;
                    };
                    $tokens = array_merge( $build_tokens( $subject_plain ), $build_tokens( substr( $message_plain, 0, 600 ) ) );
                    $suggestions = array();
                    $push_suggestion = function( $phrase, $src ) use ( &$suggestions, $trained_norm, $triggers, $strong_triggers, $weak_triggers, $single_weak_ok ) {
                        $phrase = trim( preg_replace( '/\s+/', ' ', (string) $phrase ) );
                        if ( '' === $phrase || strlen( $phrase ) < 8 || strlen( $phrase ) > 60 ) { return; }
                        $norm = strtolower( $phrase );
                        if ( isset( $trained_norm[ $norm ] ) ) { return; }
                        // Must contain either a strong trigger OR multiple weak triggers (to avoid noisy suggestions).
                        $has_strong = false;
                        foreach ( $strong_triggers as $t ) {
                            if ( false !== strpos( $norm, $t ) ) { $has_strong = true; break; }
                        }
                        $weak_count = 0;
                        foreach ( $weak_triggers as $t ) {
                            if ( false !== strpos( $norm, $t ) ) { $weak_count++; }
                        }
                        // Allow either a strong trigger, or multiple weak triggers. For short 2-word phrases, allow a single key weak trigger (e.g. 'paid advertising').
                                $word_count = count( preg_split( '/\s+/', $norm ) );
                                $single_ok = false;
                                if ( $word_count <= 2 && $weak_count >= 1 ) {
                                    foreach ( $single_weak_ok as $t ) {
                                        if ( false !== strpos( $norm, $t ) ) { $single_ok = true; break; }
                                    }
                                }
                                if ( ! $has_strong && $weak_count < 2 && ! $single_ok ) { return; }
                        if ( ! isset( $suggestions[ $norm ] ) ) {
                            $suggestions[ $norm ] = array( 'phrase' => $phrase, 'src' => $src );
                        }
                    };
                    $max = count( $tokens );
                    for ( $i = 0; $i < $max; $i++ ) {
                        for ( $n = 2; $n <= 4; $n++ ) {
                            if ( $i + $n > $max ) { continue; }
                            $ng = implode( ' ', array_slice( $tokens, $i, $n ) );
                            $push_suggestion( $ng, ( $i < 12 ? __( 'subject/message', 'product-mailer-campaigns' ) : __( 'message', 'product-mailer-campaigns' ) ) );
                        }
                    }
                    // Fallback: if triggers are too restrictive for this submission, suggest a few clean 2–3 word phrases anyway.
                    // This helps admins train new spam patterns outside the default trigger lists.
                    if ( empty( $suggestions ) ) {
                        $fallback = array();
                        $push_fallback = function( $phrase, $src ) use ( &$fallback, $trained_norm ) {
                            $phrase = trim( preg_replace( '/\s+/', ' ', (string) $phrase ) );
                            if ( '' === $phrase || strlen( $phrase ) < 8 || strlen( $phrase ) > 60 ) { return; }
                            $norm = strtolower( $phrase );
                            if ( isset( $trained_norm[ $norm ] ) ) { return; }
                            if ( ! isset( $fallback[ $norm ] ) ) {
                                $fallback[ $norm ] = array( 'phrase' => $phrase, 'src' => $src );
                            }
                        };
                        for ( $i = 0; $i < $max; $i++ ) {
                            for ( $n = 2; $n <= 3; $n++ ) {
                                if ( $i + $n > $max ) { continue; }
                                $ng = implode( ' ', array_slice( $tokens, $i, $n ) );
                                $push_fallback( $ng, ( $i < 12 ? __( 'subject/message', 'product-mailer-campaigns' ) : __( 'message', 'product-mailer-campaigns' ) ) );
                                if ( count( $fallback ) >= 8 ) { break 2; }
                            }
                        }
                        $suggestions = $fallback;
                    }
                    // Prefer longer phrases.
                    usort( $suggestions, function( $a, $b ) {
                        return strlen( $b['phrase'] ) <=> strlen( $a['phrase'] );
                    } );
                    $suggestions = array_slice( $suggestions, 0, 5 );

                    $add_nonce = wp_create_nonce( 'pmcpc_add_spam_phrase' );
                    echo '<div class="pmcpc-card pmcpc-spam-training-box">';
                    echo '<h3 style="margin:0 0 8px;">' . esc_html__( 'Spam phrase training', 'product-mailer-campaigns' ) . '</h3>';
                    echo '<p style="margin:0 0 10px;color:#6c7781;">' . esc_html__( 'Highlight a phrase in the message above or add one manually to improve the spam filter for future submissions.', 'product-mailer-campaigns' ) . '</p>';
                    if ( ! $spam_keywords_enabled ) {
                        echo '<p style="margin:0 0 8px;color:#d63638;">' . esc_html__( 'Keyword scanning is disabled in Settings → Spam Protection. Enable it to use training suggestions.', 'product-mailer-campaigns' ) . '</p>';
                    }
                    echo '<p style="margin:0 0 10px;color:#6c7781;">' . esc_html__( 'Use short phrases that clearly indicate spam. This trains the spam phrase list without blocking shared email providers.', 'product-mailer-campaigns' ) . '</p>';
                    // Matched phrases (already trained).
                    echo '<div class="pmcpc-spam-training-sections">';
                    echo '<div class="pmcpc-spam-training-section">';
                    echo '<strong>' . esc_html__( 'Matched phrases (already in your list)', 'product-mailer-campaigns' ) . '</strong>';
                    if ( empty( $trained_hits ) ) {
                            echo '<p id="pmcpc-trained-none" style="margin:6px 0 0;color:#6c7781;">' . esc_html__( 'None.', 'product-mailer-campaigns' ) . '</p>';
                            echo '<ul id="pmcpc-trained-list" style="margin:6px 0 0 18px;display:none;"></ul>';
                    } else {
                            echo '<ul id="pmcpc-trained-list" class="pmcpc-plain-list">';
                        foreach ( $trained_hits as $hit ) {
                            echo '<li><code>' . esc_html( $hit['phrase'] ) . '</code> <span style="color:#6c7781;">(' . esc_html( $hit['loc'] ) . ')</span></li>';
                        }
                        echo '</ul>';
                    }
                    echo '</div>';
                    // Suggested phrases.
                    echo '<div class="pmcpc-spam-training-section">';
                    echo '<strong>' . esc_html__( 'Suggested phrases to add', 'product-mailer-campaigns' ) . '</strong>';
                    if ( empty( $suggestions ) ) {
                        echo '<p style="margin:6px 0 0;color:#6c7781;">' . esc_html__( 'No suggestions for this submission.', 'product-mailer-campaigns' ) . '</p>';
                    } else {
                            echo '<ul id="pmcpc-suggested-list" class="pmcpc-plain-list">';
                        foreach ( $suggestions as $s ) {
                            $phrase = (string) $s['phrase'];
                            echo '<li class="pmcpc-suggestion-item"><code class="pmcpc-suggested-phrase" data-phrase="' . esc_attr( $phrase ) . '">' . esc_html( $phrase ) . '</code> <button type="button" class="button button-small pmcpc-add-phrase" data-phrase="' . esc_attr( $phrase ) . '">' . esc_html__( 'Add', 'product-mailer-campaigns' ) . '</button></li>';
                        }
                        echo '</ul>';
                        // Settings tabs use key "spam"; using an unknown tab hides all content.
                        $settings_link = admin_url( 'admin.php?page=pmcpc_settings&tab=spam#pmcpc-spam-message-scoring' );
                        echo '<p style="margin:8px 0 0;color:#6c7781;">' . esc_html__( 'Adds to:', 'product-mailer-campaigns' ) . ' <a href="' . esc_url( $settings_link ) . '">' . esc_html__( 'Settings → Spam Protection → Spam phrases', 'product-mailer-campaigns' ) . '</a></p>';
                    }
                        // Always allow manual training even if suggestions are empty or the submission was blocked by another rule.
                        echo '<div style="margin-top:10px; padding-top:10px; border-top:1px solid #f0f0f1;">';
                        echo '<label for="pmcpc-custom-phrase" style="display:block; font-size:12px; color:#6c7781; margin-bottom:4px;">' . esc_html__( 'Add a custom phrase from this message', 'product-mailer-campaigns' ) . '</label>';
                        echo '<div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">';
                        echo '<input type="text" id="pmcpc-custom-phrase" class="regular-text" placeholder="' . esc_attr__( 'e.g. intimate connection', 'product-mailer-campaigns' ) . '" style="max-width:320px;" />';
                        echo '<button type="button" class="button" id="pmcpc-add-custom-phrase">' . esc_html__( 'Add phrase', 'product-mailer-campaigns' ) . '</button>';
                        echo '<span id="pmcpc-custom-phrase-status" style="color:#6c7781;"></span>';
                        echo '</div>';
                        echo '<p style="margin:6px 0 0;color:#6c7781; font-size:12px;">' . esc_html__( 'Tip: copy a short phrase (3–80 chars) from the message above and paste it here.', 'product-mailer-campaigns' ) . '</p>';
                        echo '</div>';

                    // Close suggested section + the sections wrapper.
                    echo '</div>'; // .pmcpc-spam-training-section
                    echo '</div>'; // .pmcpc-spam-training-sections

                    echo '<input type="hidden" id="pmcpc-add-phrase-nonce" value="' . esc_attr( $add_nonce ) . '" />';
                    echo '</div>';

                    // Inline styles + JS for highlights + add buttons.
    echo '<style>.pmcpc-mark-trained{background:rgba(34,113,177,.18);padding:0 2px;border-radius:2px}.pmcpc-mark-suggested{background:rgba(255,200,0,.28);padding:0 2px;border-radius:2px}#pmcpc-add-selection{box-shadow:0 6px 18px rgba(0,0,0,.12);}.pmcpc-inbox-spam-training-wrap{margin-top:16px}</style>';

    $trained_json   = wp_json_encode( array_values( array_slice( $trained_phrases, 0, 120 ) ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
    $suggested_json = wp_json_encode( array_values( array_map( static function( $x ) { return $x['phrase']; }, $suggestions ) ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );

    $label_show_json   = wp_json_encode( __( 'Show highlights', 'product-mailer-campaigns' ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
    $label_hide_json   = wp_json_encode( __( 'Hide highlights', 'product-mailer-campaigns' ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
    $label_added_json  = wp_json_encode( __( 'Added', 'product-mailer-campaigns' ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
    $label_exists_json = wp_json_encode( __( 'Already added', 'product-mailer-campaigns' ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
    $confirm_add_json  = wp_json_encode( __( 'Add spam phrase:', 'product-mailer-campaigns' ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );

    echo '<script>(function(){
        function escapeHtml(s){
            return (s||"")
                .replace(/&/g,"&amp;")
                .replace(/</g,"&lt;")
                .replace(/>/g,"&gt;")
                .replace(/\"/g,"&quot;")
                .replace(/\'/g,"&#039;");
        }
        function escRe(s){
            return String(s||"").replace(/[-\\/\\^$*+?.()|[\\]{}]/g,"\\\\$&");
        }
        function highlight(text, trained, suggested){
            var out = escapeHtml(text);
            function apply(list, cls){
                (list||[]).forEach(function(p){
                    p = String(p||"").trim();
                    if(!p || p.length < 3){ return; }
                    var parts = p.split(/\s+/).filter(Boolean).map(escRe);
                    if(!parts.length){ return; }
                    var pat = parts.join("[\\\\s\\\\W_]+?");
                    try {
                        var re = new RegExp(pat, "gi");
                        out = out.replace(re, function(m){ return "<mark class=\""+cls+"\">"+m+"</mark>"; });
                    } catch(e) {}
                });
            }
            apply(trained, "pmcpc-mark-trained");
            apply(suggested, "pmcpc-mark-suggested");
            return out;
        }

        var btn = document.getElementById("pmcpc-toggle-highlights");
        var box = document.getElementById("pmcpc-view-message");
        var raw = document.getElementById("pmcpc-raw-message");
        var on = false;

        function gatherTrained(){
            var ul = document.getElementById("pmcpc-trained-list");
            if(!ul){ return []; }
            var arr = [];
            ul.querySelectorAll("code").forEach(function(c){
                var t = (c.textContent||"").trim();
                if(t){ arr.push(t); }
            });
            return arr;
        }
        function gatherSuggested(){
            var ul = document.getElementById("pmcpc-suggested-list");
            if(!ul){ return []; }
            var arr = [];
            ul.querySelectorAll("code.pmcpc-suggested-phrase").forEach(function(c){
                var t = (c.textContent||"").trim();
                if(t){ arr.push(t); }
            });
            return arr;
        }

        if(btn && box && raw){
            var trained = ' . wp_json_encode( array_values( array_slice( $trained_phrases, 0, 120 ) ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ';
            var suggested = ' . wp_json_encode( array_values( array_map( static function( $x ) { return $x['phrase']; }, $suggestions ) ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ';

            btn.addEventListener("click", function(){
                on = !on;
                btn.textContent = on ? ' . $label_hide_json . ' : ' . $label_show_json . ';
                trained = gatherTrained();
                suggested = gatherSuggested();
                box.innerHTML = on ? highlight(raw.value, trained, suggested) : escapeHtml(raw.value);
                box.style.whiteSpace = "pre-wrap";
            });

            box.textContent = raw.value;
        }

        function postAdd(phrase, btnEl){
            var nonce = document.getElementById("pmcpc-add-phrase-nonce");
            var data = new FormData();
            data.append("action","pmcpc_add_spam_phrase");
            data.append("_wpnonce", nonce ? nonce.value : "");
            data.append("phrase", phrase);

            btnEl.disabled = true;
            fetch(ajaxurl, {method:"POST", credentials:"same-origin", body:data})
                .then(function(r){ return r.json(); })
                .then(function(json){
                    btnEl.disabled = false;
                    if(!json || !json.success){
                        alert((json && json.data && json.data.message) ? json.data.message : "Error");
                        return;
                    }
                    var phraseOut = (json.data && json.data.phrase) ? String(json.data.phrase) : phrase;

                    btnEl.textContent = ' . $label_added_json . ';
                    btnEl.classList.add("disabled");
                    btnEl.disabled = true;

                    var li = btnEl.closest ? btnEl.closest("li") : null;
                    var sugUl = document.getElementById("pmcpc-suggested-list");
                    var trainedUl = document.getElementById("pmcpc-trained-list");
                    var trainedNone = document.getElementById("pmcpc-trained-none");

                    if(li && sugUl && sugUl.contains(li)){ sugUl.removeChild(li); }

                    if(trainedUl){
                        if(trainedNone){ trainedNone.style.display = "none"; }
                        trainedUl.style.display = "block";
                        var newLi = document.createElement("li");
                        newLi.innerHTML = "<code>"+escapeHtml(phraseOut)+"</code> <span style=\"color:#6c7781;\">(added)</span>";
                        trainedUl.appendChild(newLi);
                    }

                    if(on && box && raw){
                        var tr = gatherTrained();
                        var su = gatherSuggested();
                        box.innerHTML = highlight(raw.value, tr, su);
                        box.style.whiteSpace = "pre-wrap";
                    }
                }).catch(function(){
                    btnEl.disabled = false;
                    alert("Error");
                });
        }

        // Highlight-to-add: let admins select text in the subject or message and add it as a spam phrase.
        var selBtn = document.getElementById("pmcpc-add-selection");
        var subjEl = document.getElementById("pmcpc-view-subject");
        function cleanSelectedText(t){
            t = String(t||"").replace(/\s+/g," ").trim();
            // Strip common wrapping punctuation/quotes.
            t = t.replace(/^[\"\'\“\”\‘\’\(\[\{\s]+/,"").replace(/[\"\'\“\”\‘\’\)\]\}\s\.,;:!\?]+$/,"");
            return t;
        }
        function selectionIsInside(container, sel){
            if(!container || !sel || sel.rangeCount === 0){ return false; }
            try {
                var range = sel.getRangeAt(0);
                var node = range.commonAncestorContainer;
                return container.contains(node.nodeType === 1 ? node : node.parentNode);
            } catch(e){ return false; }
        }
        function hideSelBtn(){
            if(!selBtn){ return; }
            selBtn.style.display = "none";
            selBtn.dataset.phrase = "";
        }
        function maybeShowSelBtn(){
            if(!selBtn){ return; }
            var sel = window.getSelection ? window.getSelection() : null;
            if(!sel || sel.rangeCount === 0){ return hideSelBtn(); }
            if(sel.isCollapsed){ return hideSelBtn(); }
            // Only allow selection from subject or message.
            if(!selectionIsInside(box, sel) && !selectionIsInside(subjEl, sel)){
                return hideSelBtn();
            }
            var text = cleanSelectedText(sel.toString());
            if(!text || text.length < 3 || text.length > 80){ return hideSelBtn(); }
            // Avoid URLs/domains/emails.
            if(/https?:\/\//i.test(text) || /\b\S+@\S+\b/.test(text) || /\b[a-z0-9-]+\.(com|net|org|co|uk|io|ly|me|app|site|online)\b/i.test(text)){
                return hideSelBtn();
            }
            var rect;
            try { rect = sel.getRangeAt(0).getBoundingClientRect(); } catch(e){ rect = null; }
            if(!rect){ return hideSelBtn(); }
            selBtn.dataset.phrase = text;
            // Position near the selection.
            selBtn.style.left = Math.max(8, Math.min((window.innerWidth-120), rect.left)) + "px";
            selBtn.style.top  = Math.max(8, Math.min((window.innerHeight-40), rect.bottom + 6)) + "px";
            selBtn.style.display = "inline-block";
        }
        if(selBtn){
            document.addEventListener("mouseup", function(){ setTimeout(maybeShowSelBtn, 0); });
            document.addEventListener("keyup", function(){ setTimeout(maybeShowSelBtn, 0); });
            document.addEventListener("scroll", function(){ hideSelBtn(); }, true);
            document.addEventListener("mousedown", function(e){
                // Hide when clicking elsewhere.
                if(e && e.target && (e.target === selBtn || selBtn.contains(e.target))){ return; }
                hideSelBtn();
            });
            selBtn.addEventListener("click", function(e){
                e.preventDefault();
                var phrase = String(selBtn.dataset.phrase||"").trim();
                if(!phrase){ return; }
                if(!confirm(' . $confirm_add_json . ' + " \"" + phrase + "\" ?")){ return; }
                hideSelBtn();
                postAdd(phrase, selBtn);
            });
        }

            // Manual phrase training (lets admins train even when a submission was blocked by another rule).
            var customBtn = document.getElementById("pmcpc-add-custom-phrase");
            var customInput = document.getElementById("pmcpc-custom-phrase");
            var customStatus = document.getElementById("pmcpc-custom-phrase-status");
            if(customBtn && customInput){
                customBtn.addEventListener("click", function(e){
                    e.preventDefault();
                    var phrase = String(customInput.value||"").trim().replace(/\s+/g," ");
                    if(!phrase){ return; }
                    if(!confirm(' . $confirm_add_json . ' + " \"" + phrase + "\" ?")){ return; }
                    customBtn.disabled = true;
                    if(customStatus){ customStatus.textContent = ""; }

                    // Use the same endpoint as suggestions.
                    var nonce = document.getElementById("pmcpc-add-phrase-nonce");
                    var data = new FormData();
                    data.append("action","pmcpc_add_spam_phrase");
                    data.append("_wpnonce", nonce ? nonce.value : "");
                    data.append("phrase", phrase);
                    fetch(ajaxurl, {method:"POST", credentials:"same-origin", body:data})
                        .then(function(r){ return r.json(); })
                        .then(function(json){
                            customBtn.disabled = false;
                            if(!json || !json.success){
                                if(customStatus){ customStatus.textContent = (json && json.data && json.data.message) ? json.data.message : "Error"; }
                                return;
                            }
                            var added = !!(json.data && json.data.added);
                            var phraseOut = (json.data && json.data.phrase) ? String(json.data.phrase) : phrase;
                            customInput.value = "";
                            if(customStatus){ customStatus.textContent = added ? ' . $label_added_json . ' : ' . $label_exists_json . '; }

                            var trainedUl = document.getElementById("pmcpc-trained-list");
                            var trainedNone = document.getElementById("pmcpc-trained-none");
                            if(trainedUl){
                                if(trainedNone){ trainedNone.style.display = "none"; }
                                trainedUl.style.display = "block";
                                var newLi = document.createElement("li");
                                newLi.innerHTML = "<code>"+escapeHtml(phraseOut)+"</code> <span style=\"color:#6c7781;\">("+(added?"added":"exists")+")</span>";
                                trainedUl.appendChild(newLi);
                            }

                            if(on && box && raw){
                                var tr = gatherTrained();
                                var su = gatherSuggested();
                                box.innerHTML = highlight(raw.value, tr, su);
                                box.style.whiteSpace = "pre-wrap";
                            }
                        }).catch(function(){
                            customBtn.disabled = false;
                            if(customStatus){ customStatus.textContent = "Error"; }
                        });
                });
            }

        document.addEventListener("click", function(e){
            var t = e.target;
            if(!t || !t.classList || !t.classList.contains("pmcpc-add-phrase")){ return; }
            e.preventDefault();
            var phrase = t.getAttribute("data-phrase") || "";
            if(!phrase){ return; }
            if(!confirm(' . $confirm_add_json . ' + " \"" + phrase + "\" ?")){ return; }
            postAdd(phrase, t);
        });
    })();</script>';

                    }

                        $view_status = (string) $view_row->status;

                        // --- Action availability / guardrails (View page) ---
                        $email_view  = ! empty( $view_row->email ) ? (string) $view_row->email : '';
                        $domain_view = ! empty( $view_row->domain ) ? (string) $view_row->domain : '';
                        $domain_is_protected = false;
                        $domain_is_blocked   = false;
                        $email_is_blocked    = false;
                        $sender_is_allowlisted = false;
                        $timing_enabled = 'yes';
                        $timing_min     = 0;

                        if ( class_exists( 'PMCPC_Subscriber_Manager' ) ) {
                            if ( $domain_view && method_exists( 'PMCPC_Subscriber_Manager', 'is_auto_block_protected_domain' ) ) {
                                $domain_is_protected = PMCPC_Subscriber_Manager::is_auto_block_protected_domain( $domain_view );
                            }
                            if ( $domain_view && method_exists( 'PMCPC_Subscriber_Manager', 'is_domain_in_blocked_list' ) ) {
                                $domain_is_blocked = PMCPC_Subscriber_Manager::is_domain_in_blocked_list( $domain_view );
                            }
                            if ( $email_view && method_exists( 'PMCPC_Subscriber_Manager', 'is_blocked_email_address' ) ) {
                                $email_is_blocked = PMCPC_Subscriber_Manager::is_blocked_email_address( $email_view );
                            }
                            if ( $email_view && method_exists( 'PMCPC_Subscriber_Manager', 'is_allowlisted_sender' ) ) {
                                $sender_is_allowlisted = PMCPC_Subscriber_Manager::is_allowlisted_sender( $email_view );
                            }
                            if ( method_exists( 'PMCPC_Subscriber_Manager', 'get_spam_setting' ) ) {
                                $timing_enabled = (string) PMCPC_Subscriber_Manager::get_spam_setting( 'spam_form_timing_enabled', 'yes' );
                                $timing_min     = (int) PMCPC_Subscriber_Manager::get_spam_setting( 'spam_min_submit_seconds', 4 );
                            }
                        }

                        $context_view = isset( $view_row->context ) ? (string) $view_row->context : '';
                        $view_reason  = isset( $view_row->reason ) ? (string) $view_row->reason : '';
                        // Some Inbox items are already processed (admin email already sent). Don't offer "release" actions that would resend.
                        $already_processed = ( 'allowed' === $view_status && 'sent' === $view_reason );
                        $doi_available = ( 'subscribe' === $context_view ) || ( $has_optin_marker && in_array( $context_view, array( 'contact', 'selling' ), true ) );
                        $pmcpc_spam_training_html = ob_get_clean();
                        if ( ! empty( $pmcpc_spam_training_html ) ) {
                            echo '<div class="pmcpc-inbox-spam-training-wrap">' . $pmcpc_spam_training_html . '</div>';
                        }
                        echo '</div>'; // .pmcpc-submission-main
                        echo '</div>'; // .pmcpc-submission-layout
                        echo '<div class="pmcpc-submission-tools">';
                        $action_defs = array();

                        // Subscriber state (used to disable "Start double opt-in" when it cannot do anything).
                        $subscriber_exists = false;
                        $subscriber_status = '';
                        if ( $email_view && class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'get_subscriber_by_email' ) ) {
                            $sub_row = PMCPC_Subscriber_Manager::get_subscriber_by_email( $email_view );
                            if ( $sub_row && ! empty( $sub_row->id ) ) {
                                $subscriber_exists = true;
                                $subscriber_status = ! empty( $sub_row->status ) ? (string) $sub_row->status : '';
                            }
                        }

                        // Status actions.
                    
                        // Release actions (split to make side-effects explicit).
                        $action_defs['release_message_only'] = array(
                            'label' => __( 'Release to Inbox (message only)', 'product-mailer-campaigns' ),
                            'desc'  => __( 'For contact/selling: sends the message to the admin email and removes it from Spam. For subscribe: marks as Inbox only (no subscription started).', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Inbox/Spam item only. (No settings lists are changed.)', 'product-mailer-campaigns' ),
                            'enabled' => ( 'released' !== $view_status && ! $already_processed ),
                            'disabled_reason' => ( $already_processed ? __( 'Already processed (sent).', 'product-mailer-campaigns' ) : __( 'Already released.', 'product-mailer-campaigns' ) ),
                        );
                        if ( $doi_available ) {
                            // Disable DOI actions when the subscriber already exists in a terminal state.
                            $doi_can_start = true;
                            $doi_block_reason = '';
                            if ( $subscriber_exists && in_array( $subscriber_status, array( 'active', 'pending', 'unsubscribed' ), true ) ) {
                                $doi_can_start = false;
                                if ( 'pending' === $subscriber_status ) {
                                    $doi_block_reason = __( 'Subscriber already pending confirmation.', 'product-mailer-campaigns' );
                                } elseif ( 'active' === $subscriber_status ) {
                                    $doi_block_reason = __( 'Already subscribed.', 'product-mailer-campaigns' );
                                } else {
                                    $doi_block_reason = __( 'Subscriber is unsubscribed.', 'product-mailer-campaigns' );
                                }
                            }

                            $action_defs['release_with_doi'] = array(
                                'label' => __( 'Release + start double opt-in', 'product-mailer-campaigns' ),
                                'desc'  => __( 'Sends the message to admin (if applicable) and starts the subscription flow for this email (double opt-in if enabled).', 'product-mailer-campaigns' ),
                                'applies' => __( 'Applies to: Inbox/Spam item + Subscribers (pending/active).', 'product-mailer-campaigns' ),
                                'enabled' => ( 'released' !== $view_status && $doi_can_start ),
                                'disabled_reason' => ( $doi_can_start ? __( 'Already released.', 'product-mailer-campaigns' ) : $doi_block_reason ),
                            );
                            // If the message was already sent to admin, this action should only start the subscriber flow.
                            if ( $already_processed ) {
                                $action_defs['release_with_doi']['label'] = __( 'Start double opt-in (subscriber only)', 'product-mailer-campaigns' );
                                $action_defs['release_with_doi']['desc']  = __( 'Starts the subscription flow for this email (double opt-in if enabled). Admin message is already sent.', 'product-mailer-campaigns' );
                                $action_defs['release_with_doi']['applies'] = __( 'Applies to: Subscribers (pending/active).', 'product-mailer-campaigns' );
                            }
                        }

                        $action_defs['mark_spam'] = array(
                            'label' => __( 'Move to Spam', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Marks this submission as Spam.', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Inbox status only (no settings lists).', 'product-mailer-campaigns' ),
                            'enabled' => ( 'blocked' !== $view_status ),
                            'disabled_reason' => __( 'Already in Spam.', 'product-mailer-campaigns' ),
                        );

                        // Sender controls.
                        $action_defs['allow_sender'] = array(
                            'label' => __( 'Allow sender (Allowlist)', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Always allow this sender in future.', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Settings → Spam Protection → Allowlist.', 'product-mailer-campaigns' ),
                            'enabled' => ( $email_view && ! $sender_is_allowlisted ),
                            'disabled_reason' => $email_view ? __( 'Sender already allowlisted.', 'product-mailer-campaigns' ) : __( 'No email address found.', 'product-mailer-campaigns' ),
                        );


                        $action_defs['block_sender'] = array(
                            'label' => __( 'Block sender (email + domain)', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Adds the email and domain to the blocklists (domain skipped if protected).', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Settings → Subscribers → Additional blocked emails/domains.', 'product-mailer-campaigns' ),
                            'enabled' => ( $email_view && ( ! $domain_is_protected ) ),
                            'disabled_reason' => ( ! $email_view ) ? __( 'No email address found.', 'product-mailer-campaigns' ) : __( 'Domain is protected — use “Block this email” instead.', 'product-mailer-campaigns' ),
                        );

                        $action_defs['block_email'] = array(
                            'label' => __( 'Block this email', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Blocks this exact email address for future forms.', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Settings → Subscribers → Additional blocked emails.', 'product-mailer-campaigns' ),
                            'enabled' => ( $email_view && ! $email_is_blocked ),
                            'disabled_reason' => $email_view ? __( 'Email already blocked.', 'product-mailer-campaigns' ) : __( 'No email address found.', 'product-mailer-campaigns' ),
                        );

                        $action_defs['block_domain'] = array(
                            'label' => __( 'Block this domain', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Blocks all emails from this domain for future forms.', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Settings → Subscribers → Additional blocked domains.', 'product-mailer-campaigns' ),
                            'enabled' => ( $domain_view && ! $domain_is_blocked && ! $domain_is_protected ),
                            'disabled_reason' => ( ! $domain_view ) ? __( 'No domain found.', 'product-mailer-campaigns' ) : ( $domain_is_protected ? __( 'Protected provider domain — block a specific email instead.', 'product-mailer-campaigns' ) : __( 'Domain already blocked.', 'product-mailer-campaigns' ) ),
                        );

                        $action_defs['unblock_domain'] = array(
                            'label' => __( 'Unblock domain', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Removes this domain from the blocked list.', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Settings → Subscribers → Additional blocked domains.', 'product-mailer-campaigns' ),
                            'enabled' => ( $domain_view && $domain_is_blocked ),
                            'disabled_reason' => $domain_view ? __( 'Domain is not currently blocked.', 'product-mailer-campaigns' ) : __( 'No domain found.', 'product-mailer-campaigns' ),
                        );

                        $action_defs['protect_domain'] = array(
                            'label' => __( 'Protect domain (never auto-block)', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Stops learning/auto-block rules from banning this domain.', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Settings → Spam Protection → Protected domains.', 'product-mailer-campaigns' ),
                            'enabled' => ( $domain_view && ! $domain_is_protected ),
                            'disabled_reason' => $domain_view ? __( 'Domain already protected.', 'product-mailer-campaigns' ) : __( 'No domain found.', 'product-mailer-campaigns' ),
                        );

                        // Timing controls.
                        $action_defs['timing_set_2'] = array(
                            'label' => __( 'Set global timing min to 2s', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Requires forms to take at least 2 seconds to submit.', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Settings → Spam Protection → Timing.', 'product-mailer-campaigns' ),
                            'enabled' => ( ! ( 'yes' === $timing_enabled && (int) $timing_min === 2 ) ),
                            'disabled_reason' => __( 'Timing rule already set to 2 seconds.', 'product-mailer-campaigns' ),
                            'is_global' => true,
                        );

                        $action_defs['timing_disable'] = array(
                            'label' => __( 'Disable global timing rule', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Turns off timing protection (not recommended during attacks).', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Settings → Spam Protection → Timing.', 'product-mailer-campaigns' ),
                            'enabled' => ( 'yes' === $timing_enabled ),
                            'disabled_reason' => __( 'Timing rule is already disabled.', 'product-mailer-campaigns' ),
                            'is_global' => true,
                        );

                        // Delete.
                        $action_defs['delete'] = array(
                            'label' => __( 'Delete submission', 'product-mailer-campaigns' ),
                            'desc'  => __( 'Deletes this submission from the Inbox log.', 'product-mailer-campaigns' ),
                            'applies' => __( 'Applies to: Inbox data only.', 'product-mailer-campaigns' ),
                            'enabled' => true,
                            'disabled_reason' => '',
                        );

                        echo '<div class="pmcpc-actions-box pmcpc-inbox-actions-card" style="width:100%;">';
                        echo '<h2 style="margin:0 0 8px 0;">' . esc_html__( 'Recommended next actions', 'product-mailer-campaigns' ) . '</h2>';
                        echo '<p class="description" style="margin:0 0 10px 0;">' . esc_html__( 'Start with the most likely next step for this message. Buttons are disabled when an action would conflict with protected domains or existing settings.', 'product-mailer-campaigns' ) . '</p>';

                                            // Split per-submission actions vs global settings actions.
                                            $pmcpc_recommended_keys   = array( 'release_message_only', 'release_with_doi', 'allow_sender', 'mark_not_spam', 'mark_spam', 'block_sender' );
                                            $pmcpc_recommended_actions = array();
                                            $pmcpc_advanced_actions    = array();
                                            $pmcpc_global_actions      = array();
                                            foreach ( $action_defs as $pmcpc_k => $pmcpc_meta ) {
                                                if ( ! empty( $pmcpc_meta['is_global'] ) ) {
                                                    $pmcpc_global_actions[ $pmcpc_k ] = $pmcpc_meta;
                                                } elseif ( in_array( $pmcpc_k, $pmcpc_recommended_keys, true ) ) {
                                                    $pmcpc_recommended_actions[ $pmcpc_k ] = $pmcpc_meta;
                                                } else {
                                                    $pmcpc_advanced_actions[ $pmcpc_k ] = $pmcpc_meta;
                                                }
                                            }
                    
                                            $pmcpc_detail_filter_args = self::get_inbox_filter_query_args(
                                                array(
                                                    'status'        => $status,
                                                    'context'       => $context,
                                                    'reason_filter' => $reason_filter,
                                                    'search'        => $search,
                                                    'paged'         => $paged,
                                                ),
                                                false
                                            );
                                            $pmcpc_render_grid = function( $defs, $is_global_section = false ) use ( $view_id, $detail_nonce, $email_view, $context_view, $pmcpc_detail_filter_args ) {
                                                echo '<div class="pmcpc-actions-grid pmcpc-inbox-action-grid">';
                                                foreach ( $defs as $a_key => $meta ) {
                                                    $enabled = ! empty( $meta['enabled'] );
                                                    $label   = isset( $meta['label'] ) ? (string) $meta['label'] : $a_key;
                                                    $desc    = isset( $meta['desc'] ) ? (string) $meta['desc'] : '';
                                                    $applies = isset( $meta['applies'] ) ? (string) $meta['applies'] : '';
                                                    $why     = isset( $meta['disabled_reason'] ) ? (string) $meta['disabled_reason'] : '';
                    
                                                    echo '<div class="pmcpc-inbox-action-card">';
                    
                                                    $url = add_query_arg(
                                                        array_merge(
                                                            $pmcpc_detail_filter_args,
                                                            array(
                                                            'page'               => 'pmcpc_inbox',
                                                            'pmcpc_view_id'       => $view_id,
                                                            'pmcpc_action'        => $a_key,
                                                            'pmcpc_submission_id' => $view_id,
                                                            '_pmcpc_nonce'        => $detail_nonce,
                                                            )
                                                        ),
                                                        admin_url( 'admin.php' )
                                                    );
                    
                                                    if ( $enabled ) {
                                                        $extra_class = '';
                                                        $extra_attrs = '';
                                                        if ( 'release_with_doi' === $a_key ) {
                                                            $extra_class = ' pmcpc-confirm-doi';
                                                            $extra_attrs = ' data-email="' . esc_attr( $email_view ) . '" data-context="' . esc_attr( $context_view ) . '"';
                                                        }
                                                        if ( $is_global_section ) {
                                                            $extra_class .= ' pmcpc-global-action';
                                                            $extra_attrs .= ' data-pmcpc-confirm="' . esc_attr__( 'This changes a global spam protection setting and affects all forms. Continue?', 'product-mailer-campaigns' ) . '"';
                                                        }
                                                        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $extra_attrs is built from escaped attributes.
                                                    echo '<a class="button' . esc_attr( $extra_class ) . '"' . $extra_attrs . ' href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
                                                    } else {
                                                        $title = $why ? $why : __( 'This action is currently unavailable.', 'product-mailer-campaigns' );
                                                        echo '<span class="button disabled" title="' . esc_attr( $title ) . '" style="opacity:0.55; cursor:not-allowed;">' . esc_html( $label ) . '</span>';
                                                    }
                    
                                                    if ( $desc ) {
                                                        echo '<div class="pmcpc-inbox-action-desc">' . esc_html( $desc ) . '</div>';
                                                    }
                                                    if ( $applies ) {
                                                        echo '<div class="pmcpc-inbox-action-applies">' . esc_html( $applies ) . '</div>';
                                                    }
                                                    if ( ! $enabled && $why ) {
                                                        echo '<div class="pmcpc-inbox-action-warning">' . esc_html( $why ) . '</div>';
                                                    }
                                                    echo '</div>';
                                                }
                                                echo '</div>';
                                            };
                    
                                            // Per-submission actions.
                                            $pmcpc_render_grid( $pmcpc_recommended_actions, false );

                                            if ( ! empty( $pmcpc_advanced_actions ) ) {
                                                echo '<div class="pmcpc-inbox-action-section">';
                                                echo '<h3 style="margin:0 0 8px 0;">' . esc_html__( 'Advanced sender controls', 'product-mailer-campaigns' ) . '</h3>';
                                                echo '<p class="description" style="margin:0 0 10px 0;">' . esc_html__( 'Use these when you need to affect future messages from this sender or domain, or make more technical spam-handling decisions.', 'product-mailer-campaigns' ) . '</p>';
                                                $pmcpc_render_grid( $pmcpc_advanced_actions, false );
                                                echo '</div>';
                                            }
                    
                                            // Global settings actions (affects all forms).
                                            if ( ! empty( $pmcpc_global_actions ) ) {
                                                echo '<div class="pmcpc-inbox-action-section pmcpc-inbox-global-section">';
                                                echo '<h4 style="margin:0 0 8px 0;">' . esc_html__( 'Global spam protection settings', 'product-mailer-campaigns' ) . '</h4>';
                                                echo '<p class="description" style="margin:0 0 10px 0;">' . esc_html__( 'These actions change global settings and affect all forms. Use with care.', 'product-mailer-campaigns' ) . '</p>';
                                                $pmcpc_render_grid( $pmcpc_global_actions, true );
                                                echo '</div>';
                                            }
                        echo '</div>';
                        echo '</div>'; // .pmcpc-submission-tools
                        echo '</div>'; // .card
                        echo '</div>'; // .pmcpc-inbox-detail-shell
                        return;
                }
        

            // Summary: top block reasons (click to filter).
            $pmcpc_reason_labels = array(
                'honeypot'       => __( 'Honeypot', 'product-mailer-campaigns' ),
                'spammy_name'    => __( 'Spammy name', 'product-mailer-campaigns' ),
                'suspicious_tld' => __( 'Suspicious TLD', 'product-mailer-campaigns' ),
                'rate_limit'     => __( 'Rate limit', 'product-mailer-campaigns' ),
                'too_fast'       => __( 'Too fast', 'product-mailer-campaigns' ),
                'too fast'       => __( 'Too fast', 'product-mailer-campaigns' ),
                'blocked_domain' => __( 'Blocked domain', 'product-mailer-campaigns' ),
                'blocked_email'  => __( 'Blocked email', 'product-mailer-campaigns' ),
                'manual_spam'    => __( 'Manual spam', 'product-mailer-campaigns' ),
                'manual_block'   => __( 'Manual block', 'product-mailer-campaigns' ),
            );

            $where_blocked = 'status IN (%s,%s)';
            $args_blocked  = array( 'blocked', 'discarded' );
            if ( 'all' !== $context && $context ) {
                $where_blocked .= ' AND context = %s';
                $args_blocked[] = $context;
            }
            if ( $search ) {
                $where_blocked .= " AND (email LIKE %s OR domain LIKE %s OR subject LIKE %s OR message LIKE %s)";
                $like2 = '%' . $wpdb->esc_like( $search ) . '%';
                $args_blocked[] = $like2;
                $args_blocked[] = $like2;
                $args_blocked[] = $like2;
                $args_blocked[] = $like2;
            }

            $reason_counts = array();
            // Limit the scan for performance (still enough to spot patterns).
            $scan_limit = 2000;
            $args_reason = array_merge( $args_blocked, array( $scan_limit ) );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
            $reason_rows = $wpdb->get_col( $wpdb->prepare( "SELECT reason FROM {$table} WHERE {$where_blocked} ORDER BY created_at DESC LIMIT %d", ...$args_reason ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
            if ( ! empty( $reason_rows ) ) {
                foreach ( $reason_rows as $rr ) {
                    $rr = (string) $rr;
                    if ( '' === trim( $rr ) ) { continue; }
                    $parts = array_filter( array_map( 'trim', explode( ',', $rr ) ) );
                    foreach ( $parts as $p ) {
                        if ( '' === $p ) { continue; }
                        if ( ! isset( $reason_counts[ $p ] ) ) { $reason_counts[ $p ] = 0; }
                        $reason_counts[ $p ]++;
                    }
                }
            }

            if ( ! empty( $reason_counts ) ) {
                arsort( $reason_counts );
                // Show *all* reasons as filter links so admins can review each spam bucket.
                // (This is intentionally not limited: new rules/reasons should appear automatically.)
                $top_reasons = $reason_counts;

                echo '<div style="margin: 10px 0 6px 0; padding: 10px 12px; background:#fff; border:1px solid #ccd0d4;">';
                echo '<strong>' . esc_html__( 'Most blocked:', 'product-mailer-campaigns' ) . '</strong> ';
                $parts_out = array();
                foreach ( $top_reasons as $rk => $count ) {
                    $label = isset( $pmcpc_reason_labels[ $rk ] ) ? $pmcpc_reason_labels[ $rk ] : ucwords( str_replace( array( '_', '-' ), ' ', (string) $rk ) );
                    $url = add_query_arg(
                        array(
                            'page'         => 'pmcpc_inbox',
                            'pmcpc_status' => 'blocked',
                            'pmcpc_context'=> $context,
                            'pmcpc_reason' => $rk,
                            's'            => $search,
                        ),
                        admin_url( 'admin.php' )
                    );
                    $parts_out[] = '<a href="' . esc_url( $url ) . '" style="display:inline-block; margin:0 10px 6px 0; white-space:nowrap;">' . esc_html( $label ) . ' (' . (int) $count . ')</a>';
                }
                echo '<div style="margin-top:6px;">' . wp_kses_post( implode( '', $parts_out ) ) . '</div>';

                // Helpful shortcut so admins know these rules are configurable.
                $spam_settings_url = admin_url( 'admin.php?page=pmcpc_settings&tab=spam' );
                echo '<span style="margin-left:12px; color:#6c7781;">&nbsp;&nbsp;|&nbsp;&nbsp;<a href="' . esc_url( $spam_settings_url ) . '">' . esc_html__( 'Configure Spam Protection', 'product-mailer-campaigns' ) . '</a></span>';

                if ( 'all' !== $reason_filter && $reason_filter ) {
                    $label_active = isset( $pmcpc_reason_labels[ $reason_filter ] ) ? $pmcpc_reason_labels[ $reason_filter ] : ucwords( str_replace( array( '_', '-' ), ' ', (string) $reason_filter ) );
                    $clear_url = add_query_arg(
                        array(
                            'page'         => 'pmcpc_inbox',
                            'pmcpc_status' => $status,
                            'pmcpc_context'=> $context,
                            's'            => $search,
                        ),
                        admin_url( 'admin.php' )
                    );
                    echo '<span style="margin-left:10px; color:#6c7781;">' . esc_html__( 'Filtering:', 'product-mailer-campaigns' ) . ' <strong>' . esc_html( $label_active ) . '</strong> <a href="' . esc_url( $clear_url ) . '">' . esc_html__( 'Clear', 'product-mailer-campaigns' ) . '</a></span>';
                }

                echo '</div>';
            }
            // Bulk actions + table.
            echo '<form method="post" id="pmcpc-inbox-bulk-form">';
            wp_nonce_field( 'pmcpc_inbox_bulk', 'pmcpc_inbox_bulk_nonce' );
            echo '<div class="pmcpc-inbox-bulk-bar">';
            echo '<div class="pmcpc-inbox-bulk-form">';
            echo '<label class="screen-reader-text" for="pmcpc_bulk_action">' . esc_html__( 'Select bulk action', 'product-mailer-campaigns' ) . '</label>';
            echo '<select name="pmcpc_bulk_action" id="pmcpc_bulk_action">';
            echo '<option value="">' . esc_html__( 'Bulk actions', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="mark_not_spam">' . esc_html__( 'Move to Inbox', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="mark_spam">' . esc_html__( 'Move to Spam', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="delete">' . esc_html__( 'Delete', 'product-mailer-campaigns' ) . '</option>';
            echo '</select> ';
            submit_button( __( 'Apply', 'product-mailer-campaigns' ), 'secondary', 'submit', false );
            echo '</div>';
            echo '<div style="padding: 4px 0 0 0;">';
            echo '<p class="description" id="pmcpc_bulk_action_help" style="margin:0;">' . esc_html__( 'Bulk actions only change status or delete. Use View for allow/block/protect/timing/subscription actions.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            echo '</div>';
            echo '<div class="pmcpc-inbox-viewbar pmcpc-table-viewbar" data-pmcpc-inbox-viewbar="1">';
            echo '<div class="pmcpc-inbox-viewbar__main">';
            echo '<span class="pmcpc-inbox-viewbar__label pmcpc-table-viewbar__label">' . esc_html__( 'Table view', 'product-mailer-campaigns' ) . '</span>';
            echo '<div class="pmcpc-table-viewmode pmcpc-inbox-viewmode" role="group" aria-label="' . esc_attr__( 'Inbox table view', 'product-mailer-campaigns' ) . '">';
            echo '<button type="button" class="button pmcpc-table-viewmode-button pmcpc-inbox-viewmode-button" data-inbox-view="essential">' . esc_html__( 'Essential', 'product-mailer-campaigns' ) . '</button>';
            echo '<button type="button" class="button pmcpc-table-viewmode-button pmcpc-inbox-viewmode-button" data-inbox-view="full">' . esc_html__( 'Full', 'product-mailer-campaigns' ) . '</button>';
            echo '</div>';
            echo '</div>';
            echo '<div class="pmcpc-inbox-viewbar__controls" aria-label="' . esc_attr__( 'Full view columns', 'product-mailer-campaigns' ) . '">';
            echo '<span class="pmcpc-inbox-viewbar__section-label">' . esc_html__( 'Full view columns:', 'product-mailer-campaigns' ) . '</span>';
            echo '<label class="pmcpc-inbox-viewbar__check"><input type="checkbox" class="pmcpc-inbox-column-toggle" data-column="date" checked="checked" /> ' . esc_html__( 'Date', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-inbox-viewbar__check"><input type="checkbox" class="pmcpc-inbox-column-toggle" data-column="context" checked="checked" /> ' . esc_html__( 'Context', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-inbox-viewbar__check"><input type="checkbox" class="pmcpc-inbox-column-toggle" data-column="campaign" checked="checked" /> ' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-inbox-viewbar__check"><input type="checkbox" class="pmcpc-inbox-column-toggle" data-column="optin" checked="checked" /> ' . esc_html__( 'Opt-in', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-inbox-viewbar__check"><input type="checkbox" class="pmcpc-inbox-column-toggle" data-column="reason" checked="checked" /> ' . esc_html__( 'Reason', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-inbox-viewbar__check"><input type="checkbox" class="pmcpc-inbox-column-toggle" data-column="ip" checked="checked" /> ' . esc_html__( 'IP', 'product-mailer-campaigns' ) . '</label>';
            echo '</div>';
            echo '<a href="#" class="pmcpc-inbox-viewbar__reset pmcpc-inbox-columns-reset">' . esc_html__( 'Reset columns', 'product-mailer-campaigns' ) . '</a>';
            echo '</div>';

        
            // If the admin filtered by a reason that is configured for auto-delete,
            // the table may be empty because those submissions are discarded to keep the Inbox clean.
            if ( empty( $rows ) && 'all' !== $reason_filter ) {
                $mode = PMCPC_Settings::get( 'spam_handling_mode', 'review_all' );
                if ( 'auto_delete_obvious' === $mode && class_exists( 'PMCPC_Subscriber_Manager' ) && PMCPC_Subscriber_Manager::should_auto_delete_blocked_attempt( $reason_filter, $context ) ) {
                    $settings_url = admin_url( 'admin.php?page=pmcpc_settings&tab=spam' );
                    echo '<div class="notice notice-info" style="margin:10px 0 12px;">';
                    echo '<p><strong>' . esc_html__( 'Nothing to show for this filter.', 'product-mailer-campaigns' ) . '</strong> ';
                    echo esc_html__( 'Your Spam Protection settings are set to auto-delete obvious spam (e.g. honeypot hits, blocked domains/emails, suspicious TLDs). Those submissions are discarded, so filtering by this reason can return an empty list.', 'product-mailer-campaigns' );
                    echo ' <a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Review Spam Protection settings', 'product-mailer-campaigns' ) . '</a>';
                    echo '</p></div>';
                }
            }
    echo '<div class="pmcpc-inbox-table-wrap"><div class="pmcpc-inbox-table-wrap__scroll">';
    echo '<table class="widefat fixed striped pmcpc-wide-table pmcpc-wide-table--inbox" data-pmcpc-table="inbox">';
            echo '<colgroup>';
            echo '<col class="pmcpc-inbox-col-check" />';
            echo '<col class="pmcpc-inbox-col-date" />';
            echo '<col class="pmcpc-inbox-col-context" />';
            echo '<col class="pmcpc-inbox-col-campaign" />';
            echo '<col class="pmcpc-inbox-col-email" />';
            echo '<col class="pmcpc-inbox-col-subject" />';
            echo '<col class="pmcpc-inbox-col-optin" />';
            echo '<col class="pmcpc-inbox-col-status" />';
            echo '<col class="pmcpc-inbox-col-reason" />';
            echo '<col class="pmcpc-inbox-col-ip" />';
            echo '<col class="pmcpc-inbox-col-actions" />';
            echo '</colgroup>';
            echo '<thead><tr>';
            echo '<td class="manage-column column-cb check-column"><input type="checkbox" id="pmcpc_inbox_cb_all" /></td>';
            echo '<th class="pmcpc-col-compare pmcpc-inbox-col-date">' . esc_html__( 'Date', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-meta pmcpc-inbox-col-context">' . esc_html__( 'Context', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-meta pmcpc-inbox-col-campaign">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-anchor pmcpc-inbox-col-email">' . esc_html__( 'Email', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-anchor pmcpc-inbox-col-subject">' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-meta pmcpc-inbox-col-optin">' . esc_html__( 'Opt-in', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-compare pmcpc-inbox-col-status">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-compare pmcpc-inbox-col-reason">' . esc_html__( 'Reason', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-meta pmcpc-inbox-col-ip">' . esc_html__( 'IP', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-actions">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
            echo '</tr></thead><tbody>';

            if ( empty( $rows ) ) {
                    echo '<tr><td colspan="11">' . esc_html__( 'No submissions found.', 'product-mailer-campaigns' ) . '</td></tr>';
            } else {
                foreach ( $rows as $row ) {
                    $row_filter_args = self::get_inbox_filter_query_args(
                        array(
                            'status'        => $status,
                            'context'       => $context,
                            'reason_filter' => $reason_filter,
                            'search'        => $search,
                            'paged'         => $paged,
                        ),
                        false
                    );
                    $view_url = add_query_arg(
                        array_merge(
                            $row_filter_args,
                            array(
                            'page'         => 'pmcpc_inbox',
                            'pmcpc_view_id' => (int) $row->id,
                            )
                        ),
                        admin_url( 'admin.php' )
                    );
                    $reason_raw = isset( $row->reason ) ? (string) $row->reason : '';
                    $ip_hash    = isset( $row->ip_hash ) ? (string) $row->ip_hash : '';
                    $ip_short   = $ip_hash ? substr( $ip_hash, 0, 8 ) : '';

                    // Make short clickable "chips" for reasons.
                    $reason_html = '';
                    if ( $reason_raw ) {
                        $parts = array_filter( array_map( 'trim', explode( ',', $reason_raw ) ) );
                        foreach ( array_slice( $parts, 0, 3 ) as $p ) {
                            $label = str_replace( array( '_', '-' ), ' ', $p );

                            $norm = strtolower( str_replace( array( '_', '-' ), ' ', $p ) );
                            $cls  = 'pmcpc-reason-pill';
                            $anchor = 'pmcpc-spam-handling';
                            if ( false !== strpos( $norm, 'honeypot' ) ) {
                                $cls   .= ' honeypot';
                                $anchor = 'pmcpc-spam-honeypot';
                            } elseif ( false !== strpos( $norm, 'too fast' ) ) {
                                $cls   .= ' too-fast';
                                $anchor = 'pmcpc-spam-timing';
                            } elseif ( false !== strpos( $norm, 'spammy' ) ) {
                                $cls   .= ' spammy-name';
                                $anchor = 'pmcpc-spam-spammy-name';
                            } elseif ( false !== strpos( $norm, 'blocked domain' ) ) {
                                $cls   .= ' blocked-domain';
                                $anchor = 'pmcpc-spam-blocked-domains';
                            }

                            $settings_url = admin_url( 'admin.php?page=pmcpc_settings&tab=spam#' . $anchor );

                            $reason_html .= '<a class="' . esc_attr( $cls ) . '" href="' . esc_url( $settings_url ) . '">'
                                . esc_html( $label )
                                . '</a>';
                        }
                        if ( count( $parts ) > 3 ) {
                            $reason_html .= '<span style="color:#6c7781;font-size:12px;">+' . (int) ( count( $parts ) - 3 ) . '</span>';
                        }
                    }
    // Reply mailto.
                    $mailto = '';
                    if ( ! empty( $row->email ) ) {
                        $subject_line = (string) $row->subject;
                        $mailto = 'mailto:' . rawurlencode( (string) $row->email );
                        if ( $subject_line ) {
                            $mailto .= '?subject=' . rawurlencode( 'Re: ' . $subject_line );
                        }
                    }

                    $is_unread = ( (int) $row->id > (int) $pmcpc_last_seen_id );
                    $tr_class  = $is_unread ? 'pmcpc-unread' : '';
                    echo '<tr' . ( $tr_class ? ' class="' . esc_attr( $tr_class ) . '"' : '' ) . '>';
                    echo '<th scope="row" class="check-column"><input type="checkbox" name="pmcpc_submission_ids[]" value="' . esc_attr( (int) $row->id ) . '" /></th>';
                    echo '<td class="pmcpc-col-compare pmcpc-inbox-col-date">' . esc_html( (string) $row->created_at ) . '</td>';
                    echo '<td class="pmcpc-col-meta pmcpc-inbox-col-context">' . esc_html( (string) $row->context ) . '</td>';
                    $campaign_cell = '<span style="color:#6c7781;">' . esc_html__( '—', 'product-mailer-campaigns' ) . '</span>';
                    $cid = isset( $row->campaign_id ) ? absint( $row->campaign_id ) : 0;
                    $cname = isset( $row->campaign_name ) ? (string) $row->campaign_name : '';
                    if ( $cid ) {
                        $edit_url = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . $cid );
                        $campaign_cell = '<a href="' . esc_url( $edit_url ) . '">' . esc_html( $cname ? $cname : ( '#' . $cid ) ) . '</a>';
                    }
                    echo '<td class="pmcpc-col-meta pmcpc-inbox-col-campaign"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . wp_kses_post( $campaign_cell ) . '</span></div></td>';
                    $email_link_text = esc_html( (string) $row->email );
                    $unread_pill     = $is_unread ? '<span class="pmcpc-inbox-unread-pill">' . esc_html__( 'New', 'product-mailer-campaigns' ) . '</span>' : '';
                    if ( $is_unread && '' !== $email_link_text ) {
                        $email_link_text = '<strong>' . $email_link_text . '</strong><span class="screen-reader-text"> ' . esc_html__( '(new)', 'product-mailer-campaigns' ) . '</span>';
                    }
                    echo '<td class="pmcpc-col-anchor pmcpc-inbox-col-email"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title"><a href="' . esc_url( $view_url ) . '">' . wp_kses( $email_link_text, array( 'strong' => array(), 'span' => array( 'class' => true ) ) ) . '</a>' . wp_kses( $unread_pill, array( 'span' => array( 'class' => true ) ) ) . '</span></div></td>';
                        // Extract sender domain for action guardrails.
                        $domain = '';
                        if ( ! empty( $row->email ) && false !== strpos( (string) $row->email, '@' ) ) {
                            $domain = strtolower( substr( strrchr( (string) $row->email, '@' ), 1 ) );
                        }

                    $subject_text = esc_html( (string) $row->subject );
                    if ( $is_unread && '' !== $subject_text ) {
                        $subject_text = '<strong>' . $subject_text . '</strong>';
                    }
                    echo '<td class="pmcpc-col-anchor pmcpc-inbox-col-subject"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title"><a href="' . esc_url( $view_url ) . '">' . wp_kses( $subject_text, array( 'strong' => array() ) ) . '</a></span></div></td>';

                    // Opt-in indicator (subscribe is implicit; contact/selling only when checkbox was ticked).
                    $optin_yes = false;
                    if ( 'subscribe' === (string) $row->context ) {
                        $optin_yes = true;
                    } elseif ( in_array( (string) $row->context, array( 'contact', 'selling' ), true ) ) {
                        $optin_yes = ( false !== strpos( (string) $row->message, '[pmcpc_opt_in=1]' ) );
                    }
                    $optin_cell = '<span style="color:#6c7781;">' . esc_html__( '—', 'product-mailer-campaigns' ) . '</span>';
                    if ( $optin_yes ) {
                        $optin_cell = '<span style="display:inline-block;padding:2px 6px;border:1px solid #c3c4c7;border-radius:999px;font-size:12px;line-height:1;color:#1d2327;background:#f6f7f7;">' . esc_html__( 'Yes', 'product-mailer-campaigns' ) . '</span>';
                    }
                    echo '<td class="pmcpc-col-meta pmcpc-inbox-col-optin">' . wp_kses( $optin_cell, array( 'span' => array( 'style' => true, 'class' => true ) ) ) . '</td>';
                    $status_key = (string) $row->status;
                    $status_label = $status_key;
                    $status_class = 'pmcpc-status-badge--other';
                    if ( 'blocked' === $status_key ) {
                        $status_label = __( 'Spam', 'product-mailer-campaigns' );
                        $status_class = 'pmcpc-status-badge--spam';
                    } elseif ( 'allowed' === $status_key ) {
                        $status_label = __( 'Inbox', 'product-mailer-campaigns' );
                        $status_class = 'pmcpc-status-badge--inbox';
                    } elseif ( 'held' === $status_key ) {
                        $status_label = __( 'Held', 'product-mailer-campaigns' );
                        $status_class = 'pmcpc-status-badge--held';
                    }
    echo '<td class="pmcpc-col-compare pmcpc-inbox-col-status"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-badges"><span class="pmcpc-status-badge ' . esc_attr( $status_class ) . '">' . esc_html( $status_label ) . '</span></span>' . ( $optin_yes ? '<span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Yes', 'product-mailer-campaigns' ) . '</span>' : '' ) . '</div></td>';
    echo '<td class="pmcpc-col-compare pmcpc-inbox-col-reason"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . wp_kses( $reason_html, array( 'span' => array( 'style' => true, 'class' => true, 'title' => true ), 'br' => array(), 'strong' => array(), 'em' => array(), 'a' => array( 'href' => true, 'target' => true, 'rel' => true, 'class' => true ) ) ) . '</span></div></td>';
                    echo '<td class="pmcpc-col-meta pmcpc-inbox-col-ip">' . esc_html( $ip_short ) . '</td>';
                    $pmcpc_primary_actions   = array();
                    $pmcpc_secondary_actions = array();
                    $pmcpc_primary_actions[] = '<a class="button button-small button-primary" href="' . esc_url( $view_url ) . '">' . esc_html__( 'Review', 'product-mailer-campaigns' ) . '</a>';

                    // Inline quick actions.
                    $nonce = wp_create_nonce( 'pmcpc_inbox_action_' . (int) $row->id );

                    if ( 'blocked' === (string) $row->status ) {
                        // Split release actions: message-only vs message + double opt-in.
                        $doi_ok = ( 'subscribe' === (string) $row->context ) || ( in_array( (string) $row->context, array( 'contact', 'selling' ), true ) && false !== strpos( (string) $row->message, '[pmcpc_opt_in=1]' ) );
                        $release_msg_url = add_query_arg(
                            array_merge(
                                $row_filter_args,
                                array(
                                'page'               => 'pmcpc_inbox',
                                'pmcpc_action'        => 'release_message_only',
                                'pmcpc_submission_id' => (int) $row->id,
                                '_pmcpc_nonce'        => $nonce,
                                )
                            ),
                            admin_url( 'admin.php' )
                        );
                        $release_doi_url = add_query_arg(
                            array_merge(
                                $row_filter_args,
                                array(
                                'page'               => 'pmcpc_inbox',
                                'pmcpc_action'        => 'release_with_doi',
                                'pmcpc_submission_id' => (int) $row->id,
                                '_pmcpc_nonce'        => $nonce,
                                )
                            ),
                            admin_url( 'admin.php' )
                        );

                        $pmcpc_primary_actions[] = '<a class="button button-small" href="' . esc_url( $release_msg_url ) . '">' . esc_html__( 'Release only', 'product-mailer-campaigns' ) . '</a>';
                        if ( $doi_ok ) {
                            $pmcpc_primary_actions[] = '<a class="button button-small pmcpc-confirm-doi" data-email="' . esc_attr( (string) $row->email ) . '" data-context="' . esc_attr( (string) $row->context ) . '" href="' . esc_url( $release_doi_url ) . '">' . esc_html__( 'Release + subscribe', 'product-mailer-campaigns' ) . '</a>';
                        }
                    } elseif ( 'allowed' === (string) $row->status ) {
                        if ( ! empty( $row->email ) ) {
                            $reply_url = 'mailto:' . rawurlencode( (string) $row->email );
                            if ( ! empty( $row->subject ) ) {
                                $reply_url .= '?subject=' . rawurlencode( 'Re: ' . (string) $row->subject );
                            }
                            $pmcpc_primary_actions[] = '<a class="button button-small" href="' . esc_url( $reply_url ) . '">' . esc_html__( 'Reply', 'product-mailer-campaigns' ) . '</a>';
                        }

                        $qurl = add_query_arg(
                            array_merge(
                                $row_filter_args,
                                array(
                                'page'               => 'pmcpc_inbox',
                                'pmcpc_action'        => 'mark_spam',
                                'pmcpc_submission_id' => (int) $row->id,
                                '_pmcpc_nonce'        => $nonce,
                                )
                            ),
                            admin_url( 'admin.php' )
                        );
                        $pmcpc_primary_actions[] = '<a href="' . esc_url( $qurl ) . '" onclick="return confirm(\'' . esc_js( __( 'Are you sure?', 'product-mailer-campaigns' ) ) . '\');">' . esc_html__( 'Move to Spam', 'product-mailer-campaigns' ) . '</a>';
                    }

    // Suggested "Fix" actions based on reason.
    $reasons_raw = ! empty( $row->reason ) ? (string) $row->reason : '';
    $norm_reason = strtolower( $reasons_raw );

    // Domain-based fixes.
    if ( $domain && false !== strpos( $norm_reason, 'blocked_domain' ) ) {
        $nonce2 = wp_create_nonce( 'pmcpc_inbox_action_' . (int) $row->id );
        $unblock_url = add_query_arg(
            array_merge(
                $row_filter_args,
                array(
                'page'               => 'pmcpc_inbox',
                'pmcpc_action'        => 'unblock_domain',
                'pmcpc_submission_id' => (int) $row->id,
                '_pmcpc_nonce'        => $nonce2,
                )
            ),
            admin_url( 'admin.php' )
        );
        $protect_url = add_query_arg(
            array_merge(
                $row_filter_args,
                array(
                'page'               => 'pmcpc_inbox',
                'pmcpc_action'        => 'protect_domain',
                'pmcpc_submission_id' => (int) $row->id,
                '_pmcpc_nonce'        => $nonce2,
                )
            ),
            admin_url( 'admin.php' )
        );

        $pmcpc_secondary_actions[] = '<a href="' . esc_url( $unblock_url ) . '">' . esc_html__( 'Unblock domain', 'product-mailer-campaigns' ) . '</a>';
        $pmcpc_secondary_actions[] = '<a href="' . esc_url( $protect_url ) . '">' . esc_html__( 'Protect domain', 'product-mailer-campaigns' ) . '</a>';
    }

    // Timing fixes.
    if ( false !== strpos( $norm_reason, 'too_fast' ) || false !== strpos( $norm_reason, 'timing_too_fast' ) ) {
        $nonce2 = wp_create_nonce( 'pmcpc_inbox_action_' . (int) $row->id );
        $timing2_url = add_query_arg(
            array_merge(
                $row_filter_args,
                array(
                'page'               => 'pmcpc_inbox',
                'pmcpc_action'        => 'timing_set_2',
                'pmcpc_submission_id' => (int) $row->id,
                '_pmcpc_nonce'        => $nonce2,
                )
            ),
            admin_url( 'admin.php' )
        );
        $timing_disable_url = add_query_arg(
            array_merge(
                $row_filter_args,
                array(
                'page'               => 'pmcpc_inbox',
                'pmcpc_action'        => 'timing_disable',
                'pmcpc_submission_id' => (int) $row->id,
                '_pmcpc_nonce'        => $nonce2,
                )
            ),
            admin_url( 'admin.php' )
        );
        $pmcpc_secondary_actions[] = '<a href="' . esc_url( $timing2_url ) . '">' . esc_html__( 'Set timing to 2s', 'product-mailer-campaigns' ) . '</a>';
        $pmcpc_secondary_actions[] = '<a href="' . esc_url( $timing_disable_url ) . '" onclick="return confirm(\'' . esc_js( __( 'Disable timing rule?', 'product-mailer-campaigns' ) ) . '\');">' . esc_html__( 'Disable timing', 'product-mailer-campaigns' ) . '</a>';
    }
                    if ( $mailto && 'allowed' !== (string) $row->status ) {
                        $pmcpc_secondary_actions[] = '<a href="' . esc_url( $mailto ) . '">' . esc_html__( 'Reply', 'product-mailer-campaigns' ) . '</a>';
                    }
                    $action_links   = array_merge( $pmcpc_primary_actions, $pmcpc_secondary_actions );
                    echo '<td class="pmcpc-col-actions"><div class="pmcpc-inbox-row-actions pmcpc-table-actions">';
                    if ( ! empty( $action_links ) ) {
                        echo '<details class="pmcpc-table-actions__menu"><summary class="button button-small pmcpc-table-actions__summary">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</summary><div class="pmcpc-table-actions__popover">' . wp_kses_post( implode( ' ', $action_links ) ) . '</div></details>';
                    }
                    echo '</div></td>';
                    echo '</tr>';
                }
            }

            echo '</tbody></table>';
            echo '</div></div>';
            echo '</form>';

            // Bulk UI JS.
            echo '<script>(function(){
                // Confirm modal for "Release + Subscribe (double opt-in)" actions.
                document.addEventListener("click",function(e){
                    var a = e.target && e.target.closest ? e.target.closest("a.pmcpc-confirm-doi") : null;
                    if(!a){return;}
                    var email = a.getAttribute("data-email") || "";
                    var ctx   = a.getAttribute("data-context") || "";
                    var msg = "This will add the sender to your subscribers and start double opt-in";
                    if(email){msg += " for \""+email+"\"";}
                    if(ctx){msg += " ("+ctx+")";}
                    msg += ".\n\nContinue?";
                    if(!confirm(msg)){
                        e.preventDefault();
                    }
                });
                var all=document.getElementById("pmcpc_inbox_cb_all");
                if(all){all.addEventListener("change",function(){var cbs=document.querySelectorAll("#pmcpc-inbox-bulk-form input[name=\\"pmcpc_submission_ids[]\\"]");cbs.forEach(function(cb){cb.checked=all.checked;});});}

                var action=document.getElementById("pmcpc_bulk_action");
                var help=document.getElementById("pmcpc_bulk_action_help");
                var helpMap={
                    "mark_not_spam": "Moves selected submissions to Inbox. (Status only — no emails are sent and no settings/subscribers are changed.)",
                    "mark_spam": "Moves selected submissions to Spam. (Status only — no settings are changed.)",
                    "delete": "Permanently deletes the selected submissions from history."
                };
                function updateHelp(){
                    if(!help){return;}
                    if(!action||!action.value){help.textContent="Choose a bulk action to see what it does.";return;}
                    help.textContent = helpMap[action.value] || "";
                }
                if(action){action.addEventListener("change",updateHelp);updateHelp();}

                var form=document.getElementById("pmcpc-inbox-bulk-form");
                if(form){form.addEventListener("submit",function(e){
                    if(!action||!action.value){return;}
                    if(action.value==="delete"||action.value==="mark_spam"){
                        if(!confirm("Are you sure?")){e.preventDefault();}
                    }
                });}
            })();</script>';

            // Pagination.
            if ( $total_pages > 1 ) {
                echo '<div class="tablenav"><div class="tablenav-pages">';
                $pagination_base = add_query_arg(
                    array(
                        'page'         => 'pmcpc_inbox',
                        'pmcpc_status' => $status,
                        'pmcpc_context' => $context,
                        's'            => $search,
                    ),
                    admin_url( 'admin.php' )
                );
                echo wp_kses_post( paginate_links(
                    array(
                        'base'      => $pagination_base . '%_%',
                        'format'    => '&paged=%#%',
                        'current'   => $paged,
                        'total'     => $total_pages,
                        'prev_text' => '«',
                        'next_text' => '»',
                    )
                ) );
                echo '</div></div>';
            }

            echo '</div>';
        }


    public static function render_email_page( $force_tab = null ) {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            // Determine tab (read-only UI state).
            // Prefer a plugin-specific query var to avoid clashes with other admin screens/plugins.
            // IMPORTANT: back-compat menu callbacks may pass a forced tab, but an explicit query var should override.
            $raw_tab = '';
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI state.
            if ( isset( $_GET['pmcpc_tab'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $raw_tab = sanitize_key( (string) wp_unslash( $_GET['pmcpc_tab'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin view state (tab).
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI state.
            } elseif ( isset( $_GET['pmcpctab'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $raw_tab = sanitize_key( (string) wp_unslash( $_GET['pmcpctab'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin view state (tab).
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI state.
            } elseif ( isset( $_GET['tab'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $raw_tab = sanitize_key( (string) wp_unslash( $_GET['tab'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin view state (tab).
            } elseif ( null !== $force_tab ) {
                $raw_tab = sanitize_key( (string) $force_tab );
            } else {
                $raw_tab = 'queue';
            }

            $raw_tab = strtolower( (string) $raw_tab );
            $raw_tab = preg_replace( '/[^a-z0-9_\-]/', '', $raw_tab );
            $tab     = in_array( $raw_tab, array( 'queue', 'history', 'analytics' ), true ) ? $raw_tab : 'queue';

            $base_url = add_query_arg( array( 'page' => 'pmcpc_email' ), admin_url( 'admin.php' ) );

            $tab_intro = array(
                'queue'     => array(
                    'title' => __( 'Waiting to Send', 'product-mailer-campaigns' ),
                    'text'  => __( 'Review waiting and failed emails, check sending controls, and keep delivery moving.', 'product-mailer-campaigns' ),
                    'meta'  => array(
                        array(
                            'label' => __( 'Sending view', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-email-alt',
                        ),
                        array(
                            'label' => __( 'Sending, cleanup, and health', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-update',
                        ),
                    ),
                    'stats' => array(
                        array(
                            'label' => __( 'Current view', 'product-mailer-campaigns' ),
                            'value' => __( 'Waiting', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Waiting and failed emails', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Best for', 'product-mailer-campaigns' ),
                            'value' => __( 'Operations', 'product-mailer-campaigns' ),
                            'meta'  => __( 'See what should send next', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Key tools', 'product-mailer-campaigns' ),
                            'value' => __( 'Sending controls', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Pause, resume, clean up, and inspect emails', 'product-mailer-campaigns' ),
                        ),
                    ),
                ),
                'history'   => array(
                    'title' => __( 'Sent Emails', 'product-mailer-campaigns' ),
                    'text'  => __( 'Review sent and failed emails with filters for campaigns, recipients, and delivery status.', 'product-mailer-campaigns' ),
                    'meta'  => array(
                        array(
                            'label' => __( 'Delivery history', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-backup',
                        ),
                        array(
                            'label' => __( 'Search by campaign and subscriber', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-search',
                        ),
                    ),
                    'stats' => array(
                        array(
                            'label' => __( 'Current view', 'product-mailer-campaigns' ),
                            'value' => __( 'Sent', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Sent and failed email records', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Best for', 'product-mailer-campaigns' ),
                            'value' => __( 'Review', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Check results after sending', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Key tools', 'product-mailer-campaigns' ),
                            'value' => __( 'Filters', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Status, campaign, and subscriber search', 'product-mailer-campaigns' ),
                        ),
                    ),
                ),
                'analytics' => array(
                    'title' => __( 'Email Results', 'product-mailer-campaigns' ),
                    'text'  => __( 'Review campaign performance and engagement trends without leaving the Emails area.', 'product-mailer-campaigns' ),
                    'meta'  => array(
                        array(
                            'label' => __( 'Performance view', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-chart-bar',
                        ),
                        array(
                            'label' => __( 'Campaign and engagement trends', 'product-mailer-campaigns' ),
                            'icon'  => 'dashicons-chart-line',
                        ),
                    ),
                    'stats' => array(
                        array(
                            'label' => __( 'Current view', 'product-mailer-campaigns' ),
                            'value' => __( 'Results', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Performance and engagement reporting', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Best for', 'product-mailer-campaigns' ),
                            'value' => __( 'Analysis', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Understand what is working over time', 'product-mailer-campaigns' ),
                        ),
                        array(
                            'label' => __( 'Key tools', 'product-mailer-campaigns' ),
                            'value' => __( 'Reporting', 'product-mailer-campaigns' ),
                            'meta'  => __( 'Use this view for trends instead of queue operations', 'product-mailer-campaigns' ),
                        ),
                    ),
                ),
            );
            $current_tab_intro = isset( $tab_intro[ $tab ] ) ? $tab_intro[ $tab ] : $tab_intro['queue'];

            echo '<div class="wrap">';
            PMCPC_Admin::render_app_header( __( 'Email', 'product-mailer-campaigns' ) );
            PMCPC_Admin::render_page_intro(
                $current_tab_intro['title'],
                $current_tab_intro['text'],
                $current_tab_intro['meta']
            );
            PMCPC_Admin::render_support_panels(
                array(
                    array(
                        'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-editor-help',
                        'title'   => __( 'Use the tabs for one job at a time', 'product-mailer-campaigns' ),
                        'items'   => array(
                            __( 'Waiting shows emails still to be sent.', 'product-mailer-campaigns' ),
                            __( 'Sent shows what already went out.', 'product-mailer-campaigns' ),
                            __( 'Results helps you review performance after sending.', 'product-mailer-campaigns' ),
                        ),
                    ),
                    array(
                        'eyebrow' => __( 'Test and check', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-saved',
                        'title'   => __( 'Know where to look when sending fails', 'product-mailer-campaigns' ),
                        'actions' => array(
                            array( 'label' => __( 'Open Waiting to Send', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=queue' ), 'class' => 'button button-primary' ),
                            array( 'label' => __( 'Open Health Check', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_diagnostics' ), 'class' => 'button' ),
                        ),
                    ),
                )
            );
            PMCPC_Admin::render_stats_strip( $current_tab_intro['stats'] );
            echo '<h2 class="nav-tab-wrapper">';
            $queue_url = esc_url( add_query_arg( 'pmcpc_tab', 'queue', remove_query_arg( array( 'tab','pmcpc_tab' ), $base_url ) ) );
            echo '<a href="' . esc_url( $queue_url ) . '" class="nav-tab ' . ( 'queue' === $tab ? 'nav-tab-active' : '' ) . '">' . esc_html__( 'Waiting', 'product-mailer-campaigns' ) . '</a>';
            $history_url = esc_url( add_query_arg( 'pmcpc_tab', 'history', remove_query_arg( array( 'tab','pmcpc_tab' ), $base_url ) ) );
            echo '<a href="' . esc_url( $history_url ) . '" class="nav-tab ' . ( 'history' === $tab ? 'nav-tab-active' : '' ) . '">' . esc_html__( 'Sent', 'product-mailer-campaigns' ) . '</a>';
            $analytics_url = esc_url( add_query_arg( 'pmcpc_tab', 'analytics', remove_query_arg( array( 'tab','pmcpc_tab' ), $base_url ) ) );
            echo '<a href="' . esc_url( $analytics_url ) . '" class="nav-tab ' . ( 'analytics' === $tab ? 'nav-tab-active' : '' ) . '">' . esc_html__( 'Results', 'product-mailer-campaigns' ) . '</a>';
            echo '</h2>';

            switch ( $tab ) {
                case 'history':
                    // Ensure the email log class is loaded (some installs may not have it loaded yet).
                    if ( ! class_exists( 'PMCPC_Email_Log' ) ) {
                        $email_log_file = ( defined( 'PMCPC_PLUGIN_DIR' ) ? PMCPC_PLUGIN_DIR : plugin_dir_path( __FILE__ ) ) . 'class-pmcpc-email-log.php';
                        if ( file_exists( $email_log_file ) ) {
                            require_once $email_log_file;
                        }
                    }

                    if ( class_exists( 'PMCPC_Email_Log' ) ) {
                        PMCPC_Email_Log::render_page(
                            array(
                                'page_slug' => 'pmcpc_email',
                                'tab'       => 'history',
                            )
                        );
                        // Stop here; don't render other sections on this screen.
                        echo '</div>';
                        return;
                    } else {
                        echo '<p>' . esc_html__( 'Email Log component is missing.', 'product-mailer-campaigns' ) . '</p>';
                        echo '</div>';
                        return;
                    }

                case 'analytics':
                    if ( ! class_exists( 'PMCPC_Analytics' ) ) {
                        $analytics_file = ( defined( 'PMCPC_PLUGIN_DIR' ) ? PMCPC_PLUGIN_DIR : plugin_dir_path( __FILE__ ) ) . 'class-pmcpc-analytics.php';
                        if ( file_exists( $analytics_file ) ) {
                            require_once $analytics_file;
                        }
                    }

                    if ( class_exists( 'PMCPC_Analytics' ) ) {
                        PMCPC_Analytics::render_page();
                    } else {
                        echo '<p>' . esc_html__( 'Analytics component is missing.', 'product-mailer-campaigns' ) . '</p>';
                    }
                    echo '</div>';
                    return;

                case 'queue':
                default:
                    if ( class_exists( 'PMCPC_Queue_Processor' ) ) {
                        PMCPC_Queue_Processor::render_queue_page(
                            array(
                                'page_slug' => 'pmcpc_email',
                                'tab'       => 'queue',
                            )
                        );
                    }
                    echo '</div>';
                    return;
            }

            // Fallback close (shouldn't be reached due to returns above).
            echo '</div>';
        }


        public static function render_spam_log_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            // Spam Log has been consolidated into Inbox.
            wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_inbox&pmcpc_status=blocked' ) );
            exit;
        }


        public static function render_email_log_page() {
            // Back-compat: the log is now a tab on the Email screen.
            self::render_email_page( 'history' );
        }

    private function render_history_page() {
            global $wpdb;

            // Table: queue table stores sent records as status='sent'.
            $table = $wpdb->prefix . 'pmcpc_email_queue';

            // Basic filters (same UI inputs as queue) - optional; keep minimal.
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filters.
                $campaign_id = isset( $_GET['pmcpc_campaign'] ) ? absint( wp_unslash( $_GET['pmcpc_campaign'] ) ) : 0;
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filters.
                $subscriber_q = isset( $_GET['pmcpc_subscriber'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_subscriber'] ) ) : '';

                $like = '';
                if ( '' !== $subscriber_q ) {
                    $like = '%' . $wpdb->esc_like( $subscriber_q ) . '%';
                }

                // Fixed query with optional filters (avoids dynamic SQL fragments).
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $items = $wpdb->get_results(
                    $wpdb->prepare(
                    "SELECT *
                     FROM {$table}
                     WHERE status = %s
                        AND ( %d = 0 OR campaign_id = %d )
                        AND ( %s = '' OR subscriber_email LIKE %s )
                     ORDER BY last_attempt DESC
                     LIMIT %d",
                    'sent',
                    $campaign_id,
                    $campaign_id,
                    $subscriber_q,
                    $like,
                    200
                    )
                );

    echo '<p class="description">This is a history of sent emails. The Queue tab is for operational processing (pending/failed).</p>';

            echo '<table class="widefat striped">';
            echo '<thead><tr>';
            echo '<th>' . esc_html__( 'ID', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Subscriber', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Sent at', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Last attempt', 'product-mailer-campaigns' ) . '</th>';
            echo '</tr></thead><tbody>';

            if ( empty( $items ) ) {
                echo '<tr><td colspan="5">' . esc_html__( 'No sent emails found.', 'product-mailer-campaigns' ) . '</td></tr>';
            } else {
                foreach ( $items as $item ) {
                    $campaign = isset( $item->campaign_name ) && '' !== (string) $item->campaign_name ? (string) $item->campaign_name : ( isset( $item->campaign_id ) ? '#' . (int) $item->campaign_id : '' );
                    echo '<tr>';
                    echo '<td>' . esc_html( (string) $item->id ) . '</td>';
                    echo '<td>' . esc_html( $campaign ) . '</td>';
                    echo '<td>' . esc_html( (string) $item->subscriber_email ) . '</td>';
                    echo '<td>' . esc_html( (string) $item->created_at ) . '</td>';
                    echo '<td>' . esc_html( (string) $item->last_attempt ) . '</td>';
                    echo '</tr>';
                }
            }

            echo '</tbody></table>';
        }

}
