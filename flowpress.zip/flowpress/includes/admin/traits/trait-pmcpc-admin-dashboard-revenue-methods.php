<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Dashboard_Revenue_Methods {

        protected static function render_dashboard_store_revenue_workspace_section( $data ) {
            $days           = self::pmcpc_dashboard_get_selected_revenue_range();
            $metrics            = self::pmcpc_dashboard_get_store_revenue_metrics( $days, $data );
            $top_performers     = self::pmcpc_dashboard_get_revenue_top_performers( $days );
            $recent_orders      = self::pmcpc_dashboard_get_recent_attributed_orders( $days, 8 );
            $attribution_health = self::pmcpc_dashboard_get_revenue_attribution_health( $days );
            $needs_test         = empty( $top_performers['campaigns'] ) && empty( $top_performers['automations'] ) && empty( $recent_orders );
            $current_url        = admin_url( 'admin.php?page=pmcpc_dashboard' ) . '#pmcpc-dashboard-group-store_revenue';

            self::pmcpc_dashboard_section_open(
                'store_revenue',
                __( 'Store Revenue', 'product-mailer-campaigns' ),
                sprintf(
                    /* translators: %d = selected number of days. */
                    __( 'Core store, attributed, and recoverable revenue metrics for the last %d days.', 'product-mailer-campaigns' ),
                    (int) $days
                )
            );

            echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin:0 0 16px;">';
            echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Switch the window to review short-term trends or a broader revenue picture.', 'product-mailer-campaigns' ) . '</div>';
            echo '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
            foreach ( array( 7, 30, 90 ) as $range_option ) {
                $is_current = ( $range_option === $days );
                $range_url  = add_query_arg( 'pmcpc_range', $range_option, $current_url );
                printf(
                    '<a class="button %1$s" href="%2$s">%3$s</a>',
                    $is_current ? 'button-primary' : '',
                    esc_url( $range_url ),
                    esc_html( sprintf( __( '%dd', 'product-mailer-campaigns' ), $range_option ) )
                );
            }
            echo '</div>';
            echo '</div>';

            $primary_cards = array(
                array(
                    'label' => sprintf( __( 'Revenue (%dd)', 'product-mailer-campaigns' ), $days ),
                    'value' => self::pmcpc_dashboard_format_money( $metrics['revenue'] ),
                    'meta'  => __( 'Completed and processing orders in the selected range.', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => sprintf( __( 'Orders (%dd)', 'product-mailer-campaigns' ), $days ),
                    'value' => number_format_i18n( (int) $metrics['orders'] ),
                    'meta'  => __( 'All qualifying shop orders in the selected range.', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Average order value', 'product-mailer-campaigns' ),
                    'value' => self::pmcpc_dashboard_format_money( $metrics['aov'] ),
                    'meta'  => __( 'Average order value for the selected range.', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Influenced revenue %', 'product-mailer-campaigns' ),
                    'value' => number_format_i18n( (float) $metrics['share'], 1 ) . '%',
                    'meta'  => __( 'Share of store revenue attributed to FlowPress emails.', 'product-mailer-campaigns' ),
                ),
            );

            $secondary_cards = array(
                array(
                    'label' => sprintf( __( 'Attributed revenue (%dd)', 'product-mailer-campaigns' ), $days ),
                    'value' => self::pmcpc_dashboard_format_money( $metrics['attributed_revenue'] ),
                    'meta'  => __( 'Orders attributed to campaigns and automations.', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => sprintf( __( 'Attributed orders (%dd)', 'product-mailer-campaigns' ), $days ),
                    'value' => number_format_i18n( (int) $metrics['attributed_orders'] ),
                    'meta'  => __( 'Customers whose order was influenced by FlowPress emails.', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => sprintf( __( 'Recoverable carts (%dd)', 'product-mailer-campaigns' ), $days ),
                    'value' => number_format_i18n( (int) $metrics['recoverable_carts'] ),
                    'meta'  => __( 'Abandoned carts with a known contact waiting to be recovered.', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => sprintf( __( 'Recoverable revenue (%dd)', 'product-mailer-campaigns' ), $days ),
                    'value' => self::pmcpc_dashboard_format_money( $metrics['recoverable_revenue'] ),
                    'meta'  => __( 'Current opportunity value across recoverable carts.', 'product-mailer-campaigns' ),
                ),
            );

            echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin:0 0 14px;">';
            foreach ( $primary_cards as $card ) {
                echo '<div class="pmcpc-premium-card">';
                echo '<h3>' . esc_html( $card['label'] ) . '</h3>';
                echo '<div class="pmcpc-premium-kpi">' . esc_html( $card['value'] ) . '</div>';
                echo '<div class="pmcpc-premium-meta">' . esc_html( $card['meta'] ) . '</div>';
                echo '</div>';
            }
            echo '</div>';

            echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin:0 0 16px;">';
            foreach ( $secondary_cards as $card ) {
                echo '<div class="pmcpc-premium-card">';
                echo '<h3>' . esc_html( $card['label'] ) . '</h3>';
                echo '<div class="pmcpc-premium-kpi">' . esc_html( $card['value'] ) . '</div>';
                echo '<div class="pmcpc-premium-meta">' . esc_html( $card['meta'] ) . '</div>';
                echo '</div>';
            }
            echo '</div>';

            $rev_series_14     = isset( $data['rev_series_14'] ) && is_array( $data['rev_series_14'] ) ? $data['rev_series_14'] : array();
            $rev_series_14_max = ! empty( $rev_series_14 ) ? max( $rev_series_14 ) : 0;
            $sparkline = static function( $points, $max ) {
                $points = array_values( array_map( 'floatval', (array) $points ) );
                if ( count( $points ) < 2 || $max <= 0 ) {
                    return '';
                }
                $w = 240;
                $h = 44;
                $step = $w / max( 1, count( $points ) - 1 );
                $coords = array();
                foreach ( $points as $i => $v ) {
                    $x = round( $i * $step, 2 );
                    $y = round( $h - ( ( $v / $max ) * ( $h - 6 ) ) - 3, 2 );
                    $coords[] = $x . ',' . $y;
                }
                return '<svg width="' . (int) $w . '" height="' . (int) $h . '" viewBox="0 0 ' . (int) $w . ' ' . (int) $h . '" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true"><polyline fill="none" stroke="#2271b1" stroke-width="2" points="' . esc_attr( implode( ' ', $coords ) ) . '"/></svg>';
            };

            echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px;margin:0 0 16px;">';
            echo '<div class="pmcpc-premium-card pmcpc-premium-card--trend">';
            echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">';
            echo '<h3>' . esc_html__( 'Revenue Trend', 'product-mailer-campaigns' ) . '</h3>';
            $svg = $sparkline( $rev_series_14, $rev_series_14_max );
            if ( '' !== $svg ) {
                echo '<div style="opacity:.85;">' . $svg . '</div>';
            }
            echo '</div>';
            echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Last 14 days of store revenue.', 'product-mailer-campaigns' ) . '</div>';
            echo '</div>';

            echo '<div class="pmcpc-premium-card">';
            echo '<h3>' . esc_html__( 'Recovery Funnel', 'product-mailer-campaigns' ) . '</h3>';
            echo '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;">';
            echo '<div><div class="pmcpc-premium-meta">' . esc_html__( 'Recoverable carts', 'product-mailer-campaigns' ) . '</div><div class="pmcpc-premium-kpi" style="font-size:28px;">' . esc_html( number_format_i18n( (int) $metrics['recoverable_carts'] ) ) . '</div></div>';
            echo '<div><div class="pmcpc-premium-meta">' . esc_html__( 'Recoverable revenue', 'product-mailer-campaigns' ) . '</div><div class="pmcpc-premium-kpi" style="font-size:28px;">' . esc_html( self::pmcpc_dashboard_format_money( $metrics['recoverable_revenue'] ) ) . '</div></div>';
            echo '<div><div class="pmcpc-premium-meta">' . esc_html__( 'Attributed orders', 'product-mailer-campaigns' ) . '</div><div class="pmcpc-premium-kpi" style="font-size:28px;">' . esc_html( number_format_i18n( (int) $metrics['attributed_orders'] ) ) . '</div></div>';
            echo '<div><div class="pmcpc-premium-meta">' . esc_html__( 'Recovery rate', 'product-mailer-campaigns' ) . '</div><div class="pmcpc-premium-kpi" style="font-size:28px;">' . esc_html( number_format_i18n( (float) $metrics['recovery_rate'], 1 ) ) . '%</div></div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';

            echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px;margin:0 0 16px;">';
            self::pmcpc_dashboard_render_revenue_performer_table( __( 'Top Campaigns', 'product-mailer-campaigns' ), $top_performers['campaigns'] );
            self::pmcpc_dashboard_render_revenue_performer_table( __( 'Top Automations', 'product-mailer-campaigns' ), $top_performers['automations'] );
            echo '</div>';

            if ( $needs_test ) {
                self::pmcpc_dashboard_render_revenue_test_guidance( $attribution_health, $days );
            }

            echo '<div class="pmcpc-card" style="margin:0 0 16px;">';
            echo '<div class="pmcpc-card__header">';
            echo '<h3 class="pmcpc-card__title">' . esc_html__( 'Attribution Health', 'product-mailer-campaigns' ) . '</h3>';
            echo '<p class="pmcpc-card__intro">' . esc_html__( 'Shows whether revenue is being linked by direct order meta or by fallback email-event matching.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;">';
            echo '<div class="pmcpc-premium-card"><h3>' . esc_html__( 'Orders checked', 'product-mailer-campaigns' ) . '</h3><div class="pmcpc-premium-kpi">' . esc_html( number_format_i18n( (int) $attribution_health['orders_checked'] ) ) . '</div></div>';
            echo '<div class="pmcpc-premium-card"><h3>' . esc_html__( 'Direct meta matches', 'product-mailer-campaigns' ) . '</h3><div class="pmcpc-premium-kpi">' . esc_html( number_format_i18n( (int) $attribution_health['direct_orders'] ) ) . '</div></div>';
            echo '<div class="pmcpc-premium-card"><h3>' . esc_html__( 'Fallback event matches', 'product-mailer-campaigns' ) . '</h3><div class="pmcpc-premium-kpi">' . esc_html( number_format_i18n( (int) $attribution_health['fallback_orders'] ) ) . '</div></div>';
            echo '<div class="pmcpc-premium-card"><h3>' . esc_html__( 'Coverage', 'product-mailer-campaigns' ) . '</h3><div class="pmcpc-premium-kpi">' . esc_html( number_format_i18n( (float) $attribution_health['coverage_pct'], 1 ) ) . '%</div></div>';
            echo '</div>';
            echo '<p class="pmcpc-premium-meta" style="margin:12px 0 0;">' . esc_html( $attribution_health['note'] ) . '</p>';
            echo '</div>';

            echo '<div class="pmcpc-card">';
            echo '<div class="pmcpc-card__header">';
            echo '<h3 class="pmcpc-card__title">' . esc_html__( 'Recent Attributed Orders', 'product-mailer-campaigns' ) . '</h3>';
            echo '<p class="pmcpc-card__intro">' . esc_html__( 'Most recent orders attributed to FlowPress campaigns and automations.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
            echo '<table class="widefat striped pmcpc-wide-table">';
            echo '<thead><tr>';
            echo '<th>' . esc_html__( 'Date', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Customer', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Source', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Value', 'product-mailer-campaigns' ) . '</th>';
            echo '</tr></thead><tbody>';
            if ( empty( $recent_orders ) ) {
                echo '<tr><td colspan="4">' . esc_html__( 'No attributed orders were found in this range yet. Send a test email, click a tracked link, place an order with the same email address, then check this card again.', 'product-mailer-campaigns' ) . '</td></tr>';
            } else {
                foreach ( $recent_orders as $order_row ) {
                    echo '<tr>';
                    echo '<td class="pmcpc-col-compare">' . esc_html( $order_row['date'] ) . '</td>';
                    echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><div class="pmcpc-table-record__title">' . esc_html( $order_row['customer'] ) . '</div><div class="pmcpc-table-record__meta">' . esc_html( $order_row['email'] ) . '</div></div></td>';
                    echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><div class="pmcpc-table-cell-stack__main">' . esc_html( $order_row['source_name'] ) . '</div><div class="pmcpc-table-cell-stack__sub">' . esc_html( $order_row['source_type'] ) . '</div></div></td>';
                    echo '<td class="pmcpc-col-compare">' . esc_html( self::pmcpc_dashboard_format_money( $order_row['total'] ) ) . '</td>';
                    echo '</tr>';
                }
            }
            echo '</tbody></table></div></div>';
            echo '</div>';
            self::pmcpc_dashboard_section_close();
        }


        protected static function pmcpc_dashboard_get_selected_revenue_range() {
            $range = isset( $_GET['pmcpc_range'] ) ? absint( wp_unslash( $_GET['pmcpc_range'] ) ) : 30;
            if ( ! in_array( $range, array( 7, 30, 90 ), true ) ) {
                $range = 30;
            }

            return $range;
        }


        protected static function pmcpc_dashboard_format_money( $value ) {
            $value = (float) $value;
            if ( function_exists( 'wc_price' ) ) {
                return wp_strip_all_tags( wc_price( $value ) );
            }

            return number_format_i18n( $value, 2 );
        }


        protected static function pmcpc_dashboard_get_store_revenue_metrics( $days, $data ) {
            $days    = max( 1, absint( $days ) );
            $metrics = array(
                'orders'              => 30 === $days && isset( $data['orders_30'] ) ? (int) $data['orders_30'] : 0,
                'revenue'             => 30 === $days && isset( $data['revenue_30'] ) ? (float) $data['revenue_30'] : 0.0,
                'aov'                 => 30 === $days && isset( $data['aov_30'] ) ? (float) $data['aov_30'] : 0.0,
                'attributed_orders'   => 30 === $days && isset( $data['wc_email_orders_30'] ) ? (int) $data['wc_email_orders_30'] : 0,
                'attributed_revenue'  => 30 === $days && isset( $data['wc_email_revenue_30'] ) ? (float) $data['wc_email_revenue_30'] : 0.0,
                'share'               => 30 === $days && isset( $data['wc_email_share_30'] ) ? (float) $data['wc_email_share_30'] : 0.0,
                'recoverable_carts'   => 7 === $days && isset( $data['wc_abandoned_7'] ) ? (int) $data['wc_abandoned_7'] : 0,
                'recoverable_revenue' => 7 === $days && isset( $data['wc_abandoned_total_7'] ) ? (float) $data['wc_abandoned_total_7'] : 0.0,
                'recovery_rate'       => 0.0,
            );

            if ( class_exists( 'WooCommerce' ) && function_exists( 'wc_get_orders' ) ) {
                $after = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
                $order_ids = wc_get_orders(
                    array(
                        'limit'        => 300,
                        'status'       => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
                        'return'       => 'ids',
                        'type'         => 'shop_order',
                        'date_created' => '>=' . $after,
                    )
                );
                $metrics['orders']  = is_array( $order_ids ) ? count( $order_ids ) : 0;
                $metrics['revenue'] = 0.0;
                if ( ! empty( $order_ids ) ) {
                    foreach ( $order_ids as $order_id ) {
                        $order = wc_get_order( $order_id );
                        if ( $order ) {
                            $metrics['revenue'] += (float) $order->get_total();
                        }
                    }
                }
                $metrics['aov'] = $metrics['orders'] > 0 ? ( $metrics['revenue'] / $metrics['orders'] ) : 0.0;
            }

            if ( class_exists( 'PMCPC_Revenue_Attribution' ) ) {
                $totals = PMCPC_Revenue_Attribution::totals( $days, 7, 800 );
                if ( is_array( $totals ) ) {
                    $metrics['attributed_orders']  = isset( $totals['orders'] ) ? (int) $totals['orders'] : 0;
                    $metrics['attributed_revenue'] = isset( $totals['revenue'] ) ? (float) $totals['revenue'] : 0.0;
                    $metrics['share']              = $metrics['revenue'] > 0 ? ( (float) $metrics['attributed_revenue'] / (float) $metrics['revenue'] ) * 100 : 0.0;
                }
            }

            if ( class_exists( 'PMCPC_Abandoned_Carts' ) ) {
                $abandoned = PMCPC_Abandoned_Carts::get_abandoned_metrics( $days );
                if ( is_array( $abandoned ) ) {
                    $metrics['recoverable_carts']   = isset( $abandoned['count'] ) ? (int) $abandoned['count'] : 0;
                    $metrics['recoverable_revenue'] = isset( $abandoned['total'] ) ? (float) $abandoned['total'] : 0.0;
                }
            }

            $metrics['recovery_rate'] = $metrics['recoverable_carts'] > 0 ? ( (float) $metrics['attributed_orders'] / (float) $metrics['recoverable_carts'] ) * 100 : 0.0;

            return $metrics;
        }


        protected static function pmcpc_dashboard_get_revenue_attribution_health( $days ) {
            global $wpdb;

            $health = array(
                'orders_checked' => 0,
                'direct_orders'  => 0,
                'fallback_orders'=> 0,
                'coverage_pct'   => 0.0,
                'note'           => __( 'No recent WooCommerce orders were found to inspect.', 'product-mailer-campaigns' ),
            );

            if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
                $health['note'] = __( 'WooCommerce is not active, so revenue attribution cannot be verified here.', 'product-mailer-campaigns' );
                return $health;
            }

            $days                  = max( 1, absint( $days ) );
            $attribution_window_ts = (int) current_time( 'timestamp' ) - ( 7 * DAY_IN_SECONDS );
            $orders_since_ts       = (int) current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS );
            $orders                = wc_get_orders(
                array(
                    'limit'   => 300,
                    'status'  => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
                    'return'  => 'ids',
                    'orderby' => 'date',
                    'order'   => 'DESC',
                )
            );

            if ( empty( $orders ) ) {
                return $health;
            }

            $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
            $queue_table       = $wpdb->prefix . 'pmcpc_email_queue';
            $events_table      = $wpdb->prefix . 'pmcpc_email_events';
            $order_rows        = array();
            $emails            = array();

            foreach ( $orders as $order_id ) {
                $order = wc_get_order( $order_id );
                if ( ! $order ) {
                    continue;
                }
                if ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) {
                    continue;
                }
                $order_ts = $order->get_date_created() ? (int) $order->get_date_created()->getTimestamp() : 0;
                if ( ! $order_ts || $order_ts < $orders_since_ts ) {
                    continue;
                }

                $health['orders_checked']++;

                if ( absint( $order->get_meta( '_pmcpc_attributed_campaign_id', true ) ) > 0 ) {
                    $health['direct_orders']++;
                    continue;
                }

                $email = strtolower( (string) $order->get_billing_email() );
                if ( '' === $email ) {
                    continue;
                }

                $order_rows[] = array(
                    'email'     => $email,
                    'timestamp' => $order_ts,
                );
                $emails[] = $email;
            }

            if ( ! empty( $order_rows ) ) {
                $emails       = array_values( array_unique( $emails ) );
                $placeholders = implode( ',', array_fill( 0, count( $emails ), '%s' ) );
                $subscribers  = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT id, email FROM {$subscribers_table} WHERE status = 'active' AND email IN ({$placeholders})",
                        $emails
                    ),
                    ARRAY_A
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

                if ( ! empty( $subscribers ) ) {
                    $email_to_subscriber = array();
                    foreach ( $subscribers as $row ) {
                        $email_to_subscriber[ strtolower( (string) $row['email'] ) ] = (int) $row['id'];
                    }

                    $subscriber_ids = array_values( array_unique( array_map( 'intval', $email_to_subscriber ) ) );
                    if ( ! empty( $subscriber_ids ) ) {
                        $sid_placeholders = implode( ',', array_fill( 0, count( $subscriber_ids ), '%d' ) );
                        $since_mysql      = gmdate( 'Y-m-d H:i:s', $attribution_window_ts );
                        $events = $wpdb->get_results(
                            $wpdb->prepare(
                                "SELECT q.subscriber_id, q.campaign_id, e.created_at
                                FROM {$events_table} e
                                INNER JOIN {$queue_table} q ON e.queue_id = q.id
                                WHERE q.subscriber_id IN ({$sid_placeholders})
                                  AND e.created_at >= %s",
                                array_merge( $subscriber_ids, array( $since_mysql ) )
                            ),
                            ARRAY_A
                        ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

                        if ( ! empty( $events ) ) {
                            $event_index = array();
                            foreach ( $events as $ev ) {
                                $sid = (int) $ev['subscriber_id'];
                                $cid = (int) $ev['campaign_id'];
                                $ts  = strtotime( (string) $ev['created_at'] );
                                if ( $sid <= 0 || $cid <= 0 || ! $ts ) {
                                    continue;
                                }
                                if ( ! isset( $event_index[ $sid ] ) ) {
                                    $event_index[ $sid ] = array();
                                }
                                if ( ! isset( $event_index[ $sid ][ $cid ] ) || $ts > $event_index[ $sid ][ $cid ] ) {
                                    $event_index[ $sid ][ $cid ] = $ts;
                                }
                            }

                            foreach ( $order_rows as $row ) {
                                if ( empty( $email_to_subscriber[ $row['email'] ] ) ) {
                                    continue;
                                }
                                $sid      = $email_to_subscriber[ $row['email'] ];
                                $order_ts = (int) $row['timestamp'];
                                $best_ts  = 0;
                                foreach ( (array) ( $event_index[ $sid ] ?? array() ) as $ev_ts ) {
                                    if ( $ev_ts <= $order_ts && $ev_ts >= $attribution_window_ts && $ev_ts > $best_ts ) {
                                        $best_ts = $ev_ts;
                                    }
                                }
                                if ( $best_ts ) {
                                    $health['fallback_orders']++;
                                }
                            }
                        }
                    }
                }
            }

            $attributed_total        = (int) $health['direct_orders'] + (int) $health['fallback_orders'];
            $health['coverage_pct']  = $health['orders_checked'] > 0 ? ( (float) $attributed_total / (float) $health['orders_checked'] ) * 100 : 0.0;
            if ( $health['direct_orders'] > 0 ) {
                $health['note'] = __( 'Recent orders include direct FlowPress attribution meta, so the dashboard can credit campaigns and automations directly.', 'product-mailer-campaigns' );
            } elseif ( $health['fallback_orders'] > 0 ) {
                $health['note'] = __( 'Recent attribution is coming from fallback email-event matching. This works, but no direct order attribution meta was detected in the selected range.', 'product-mailer-campaigns' );
            } elseif ( $health['orders_checked'] > 0 ) {
                $health['note'] = __( 'Recent WooCommerce orders were checked, but none could be linked to FlowPress by direct order meta or fallback email events in the attribution window.', 'product-mailer-campaigns' );
            }

            return $health;
        }
        protected static function pmcpc_dashboard_get_revenue_top_performers( $days ) {
            global $wpdb;

            $breakdown = array();
            if ( class_exists( 'PMCPC_Revenue_Attribution' ) && method_exists( 'PMCPC_Revenue_Attribution', 'campaign_totals' ) ) {
                $breakdown = PMCPC_Revenue_Attribution::campaign_totals( $days, 7, 500 );
            }
            if ( empty( $breakdown ) ) {
                $breakdown = self::pmcpc_dashboard_get_campaign_revenue_breakdown( $days, 7, 500 );
            }
            if ( empty( $breakdown ) ) {
                return array(
                    'campaigns'   => array(),
                    'automations' => array(),
                );
            }

            $campaign_ids  = array_keys( $breakdown );
            $placeholders  = implode( ',', array_fill( 0, count( $campaign_ids ), '%d' ) );
            $campaigns_tbl = $wpdb->prefix . 'pmcpc_campaigns';
            $campaign_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, name, automation_trigger FROM {$campaigns_tbl} WHERE id IN ({$placeholders})",
                    $campaign_ids
                ),
                ARRAY_A
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

            $campaign_meta = array();
            foreach ( (array) $campaign_rows as $row ) {
                $campaign_meta[ (int) $row['id'] ] = array(
                    'name'    => isset( $row['name'] ) ? (string) $row['name'] : '',
                    'trigger' => isset( $row['automation_trigger'] ) ? (string) $row['automation_trigger'] : '',
                );
            }

            $results = array(
                'campaigns'   => array(),
                'automations' => array(),
            );
            foreach ( $breakdown as $campaign_id => $values ) {
                $meta = isset( $campaign_meta[ (int) $campaign_id ] ) ? $campaign_meta[ (int) $campaign_id ] : array(
                    'name'    => sprintf( __( 'Campaign #%d', 'product-mailer-campaigns' ), (int) $campaign_id ),
                    'trigger' => '',
                );
                $row = array(
                    'id'      => (int) $campaign_id,
                    'name'    => $meta['name'],
                    'orders'  => isset( $values['orders'] ) ? (int) $values['orders'] : 0,
                    'revenue' => isset( $values['revenue'] ) ? (float) $values['revenue'] : 0.0,
                );
                if ( '' !== trim( (string) $meta['trigger'] ) && 'date' !== trim( (string) $meta['trigger'] ) ) {
                    $results['automations'][] = $row;
                } else {
                    $results['campaigns'][] = $row;
                }
            }

            foreach ( $results as $key => $rows ) {
                usort(
                    $rows,
                    static function( $left, $right ) {
                        if ( $left['revenue'] === $right['revenue'] ) {
                            return $right['orders'] <=> $left['orders'];
                        }

                        return $right['revenue'] <=> $left['revenue'];
                    }
                );
                $results[ $key ] = array_slice( $rows, 0, 5 );
            }

            return $results;
        }

        protected static function pmcpc_dashboard_get_recent_attributed_orders( $days = 30, $limit = 8 ) {
            global $wpdb;

            $rows = array();
            if ( class_exists( 'PMCPC_Revenue_Attribution' ) && method_exists( 'PMCPC_Revenue_Attribution', 'recent_orders' ) ) {
                $rows = PMCPC_Revenue_Attribution::recent_orders( $days, $limit, 7, 300 );
            }
            if ( empty( $rows ) ) {
                return array();
            }

            $campaign_ids  = array_values( array_unique( array_map( 'absint', wp_list_pluck( $rows, 'campaign_id' ) ) ) );
            $campaign_ids  = array_values( array_filter( $campaign_ids ) );
            $campaign_meta = array();
            if ( ! empty( $campaign_ids ) ) {
                $placeholders  = implode( ',', array_fill( 0, count( $campaign_ids ), '%d' ) );
                $campaigns_tbl = $wpdb->prefix . 'pmcpc_campaigns';
                $campaign_rows = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT id, name, automation_trigger FROM {$campaigns_tbl} WHERE id IN ({$placeholders})",
                        $campaign_ids
                    ),
                    ARRAY_A
                ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

                foreach ( (array) $campaign_rows as $row ) {
                    $campaign_meta[ (int) $row['id'] ] = array(
                        'name' => isset( $row['name'] ) ? (string) $row['name'] : '',
                        'type' => ( ! empty( $row['automation_trigger'] ) && 'date' !== $row['automation_trigger'] ) ? __( 'Automation', 'product-mailer-campaigns' ) : __( 'Campaign', 'product-mailer-campaigns' ),
                    );
                }
            }

            foreach ( $rows as &$row ) {
                $meta = isset( $campaign_meta[ (int) $row['campaign_id'] ] ) ? $campaign_meta[ (int) $row['campaign_id'] ] : array(
                    'name' => sprintf( __( 'Campaign #%d', 'product-mailer-campaigns' ), (int) $row['campaign_id'] ),
                    'type' => __( 'Campaign', 'product-mailer-campaigns' ),
                );
                $row['customer']    = '' !== trim( (string) $row['customer'] ) ? $row['customer'] : __( 'Guest order', 'product-mailer-campaigns' );
                $row['source_name'] = $meta['name'];
                $row['source_type'] = $meta['type'];
            }
            unset( $row );

            return $rows;
        }

        protected static function pmcpc_dashboard_render_revenue_test_guidance( $attribution_health, $days ) {
            $health_url      = admin_url( 'admin.php?page=pmcpc_diagnostics' );
            $campaigns_url   = admin_url( 'admin.php?page=pmcpc_campaigns' );
            $automations_url = admin_url( 'admin.php?page=pmcpc_automations' );
            $emails_url      = admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=history' );

            echo '<div class="pmcpc-card" style="margin:0 0 16px;">';
            echo '<div class="pmcpc-card__header">';
            echo '<h3 class="pmcpc-card__title">' . esc_html__( 'How to test attribution', 'product-mailer-campaigns' ) . '</h3>';
            echo '<p class="pmcpc-card__intro">' . esc_html__( 'These revenue cards stay empty until FlowPress can connect a real order to a campaign or automation. The safest test is to send one tracked email to yourself and place one order from that click.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            echo '<div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;align-items:start;">';
            echo '<div class="pmcpc-premium-card">';
            echo '<h3>' . esc_html__( 'Test checklist', 'product-mailer-campaigns' ) . '</h3>';
            echo '<ol style="margin:10px 0 0 18px;line-height:1.7;">';
            echo '<li>' . esc_html__( 'Send one FlowPress campaign or automation email to a test address you control.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li>' . esc_html__( 'Open the email and click a tracked product or shop link from inside that email.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li>' . esc_html__( 'Place one WooCommerce order soon after, using the same email address in checkout.', 'product-mailer-campaigns' ) . '</li>';
            echo '<li>' . esc_html__( 'Refresh this dashboard and check Recent Attributed Orders, Top Campaigns, and Top Automations.', 'product-mailer-campaigns' ) . '</li>';
            echo '</ol>';
            echo '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;">';
            echo '<a class="button button-primary" href="' . esc_url( $campaigns_url ) . '">' . esc_html__( 'Open Campaigns', 'product-mailer-campaigns' ) . '</a>';
            echo '<a class="button" href="' . esc_url( $automations_url ) . '">' . esc_html__( 'Open Automations', 'product-mailer-campaigns' ) . '</a>';
            echo '<a class="button" href="' . esc_url( $emails_url ) . '">' . esc_html__( 'Open Sent Emails', 'product-mailer-campaigns' ) . '</a>';
            echo '</div>';
            echo '</div>';
            echo '<div class="pmcpc-premium-card">';
            echo '<h3>' . esc_html__( 'What the dashboard sees', 'product-mailer-campaigns' ) . '</h3>';
            echo '<div class="pmcpc-premium-meta" style="margin:10px 0 12px;">' . esc_html( $attribution_health['note'] ) . '</div>';
            echo '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;">';
            echo '<div><strong>' . esc_html__( 'Orders checked', 'product-mailer-campaigns' ) . '</strong><br>' . esc_html( number_format_i18n( (int) $attribution_health['orders_checked'] ) ) . '</div>';
            echo '<div><strong>' . esc_html__( 'Coverage', 'product-mailer-campaigns' ) . '</strong><br>' . esc_html( number_format_i18n( (float) $attribution_health['coverage_pct'], 1 ) ) . '%</div>';
            echo '</div>';
            echo '<p class="pmcpc-premium-meta" style="margin:12px 0 0;">' . esc_html( sprintf( __( 'Selected revenue window: last %d days.', 'product-mailer-campaigns' ), (int) $days ) ) . '</p>';
            echo '<p style="margin:10px 0 0;"><a class="button" href="' . esc_url( $health_url ) . '">' . esc_html__( 'Open Health Check', 'product-mailer-campaigns' ) . '</a></p>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }

        protected static function pmcpc_dashboard_render_revenue_performer_table( $title, $rows ) {
            echo '<div class="pmcpc-card">';
            echo '<div class="pmcpc-card__header">';
            echo '<h3 class="pmcpc-card__title">' . esc_html( $title ) . '</h3>';
            echo '<p class="pmcpc-card__intro">' . esc_html__( 'Best performing revenue drivers in the selected range.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
            echo '<table class="widefat striped pmcpc-wide-table">';
            echo '<thead><tr><th>' . esc_html__( 'Name', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Orders', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Revenue', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
            if ( empty( $rows ) ) {
                echo '<tr><td colspan="3">' . esc_html__( 'No attributed revenue yet in this range. Use the test checklist below to create one verified attributed order.', 'product-mailer-campaigns' ) . '</td></tr>';
            } else {
                foreach ( $rows as $row ) {
                    echo '<tr>';
                    echo '<td class="pmcpc-col-anchor">' . esc_html( $row['name'] ) . '</td>';
                    echo '<td class="pmcpc-col-compare">' . esc_html( number_format_i18n( (int) $row['orders'] ) ) . '</td>';
                    echo '<td class="pmcpc-col-compare">' . esc_html( self::pmcpc_dashboard_format_money( $row['revenue'] ) ) . '</td>';
                    echo '</tr>';
                }
            }
            echo '</tbody></table></div></div>';
            echo '</div>';
        }


        protected static function pmcpc_dashboard_get_campaign_revenue_breakdown( $days = 30, $attribution_window_days = 7, $max_orders = 300 ) {
            global $wpdb;

            if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
                return array();
            }

            $days                  = max( 1, absint( $days ) );
            $attribution_window_ts = (int) current_time( 'timestamp' ) - ( absint( $attribution_window_days ) * DAY_IN_SECONDS );
            $orders_since_ts       = (int) current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS );
            $subscribers_table     = $wpdb->prefix . 'pmcpc_subscribers';
            $queue_table           = $wpdb->prefix . 'pmcpc_email_queue';
            $events_table          = $wpdb->prefix . 'pmcpc_email_events';

            $orders = wc_get_orders(
                array(
                    'limit'   => max( 1, absint( $max_orders ) ),
                    'status'  => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
                    'return'  => 'ids',
                    'orderby' => 'date',
                    'order'   => 'DESC',
                )
            );
            if ( empty( $orders ) ) {
                return array();
            }

            $order_rows = array();
            $emails     = array();
            foreach ( $orders as $order_id ) {
                $order = wc_get_order( $order_id );
                if ( ! $order ) {
                    continue;
                }
                if ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) {
                    continue;
                }
                $order_ts = $order->get_date_created() ? (int) $order->get_date_created()->getTimestamp() : 0;
                if ( ! $order_ts || $order_ts < $orders_since_ts ) {
                    continue;
                }
                $email = strtolower( (string) $order->get_billing_email() );
                if ( '' === $email ) {
                    continue;
                }
                $order_rows[] = array(
                    'email'     => $email,
                    'timestamp' => $order_ts,
                    'total'     => (float) $order->get_total(),
                );
                $emails[] = $email;
            }
            if ( empty( $order_rows ) ) {
                return array();
            }

            $emails = array_values( array_unique( $emails ) );
            $placeholders = implode( ',', array_fill( 0, count( $emails ), '%s' ) );
            $subscribers = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, email FROM {$subscribers_table} WHERE status = 'active' AND email IN ({$placeholders})",
                    $emails
                ),
                ARRAY_A
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            if ( empty( $subscribers ) ) {
                return array();
            }

            $email_to_subscriber = array();
            foreach ( $subscribers as $row ) {
                $email_to_subscriber[ strtolower( (string) $row['email'] ) ] = (int) $row['id'];
            }
            $subscriber_ids = array_values( array_unique( array_map( 'intval', $email_to_subscriber ) ) );
            if ( empty( $subscriber_ids ) ) {
                return array();
            }

            $sid_placeholders = implode( ',', array_fill( 0, count( $subscriber_ids ), '%d' ) );
            $since_mysql      = gmdate( 'Y-m-d H:i:s', $attribution_window_ts );
            $events = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT q.subscriber_id, q.campaign_id, e.created_at
                     FROM {$events_table} e
                     INNER JOIN {$queue_table} q ON e.queue_id = q.id
                     WHERE q.subscriber_id IN ({$sid_placeholders}) AND e.created_at >= %s",
                    array_merge( $subscriber_ids, array( $since_mysql ) )
                ),
                ARRAY_A
            ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            if ( empty( $events ) ) {
                return array();
            }

            $event_index = array();
            foreach ( $events as $ev ) {
                $sid = (int) $ev['subscriber_id'];
                $cid = (int) $ev['campaign_id'];
                if ( $sid <= 0 || $cid <= 0 ) {
                    continue;
                }
                $ts = strtotime( (string) $ev['created_at'] );
                if ( ! $ts ) {
                    continue;
                }
                if ( ! isset( $event_index[ $sid ] ) ) {
                    $event_index[ $sid ] = array();
                }
                if ( ! isset( $event_index[ $sid ][ $cid ] ) || $ts > $event_index[ $sid ][ $cid ] ) {
                    $event_index[ $sid ][ $cid ] = $ts;
                }
            }

            $breakdown = array();
            foreach ( $order_rows as $row ) {
                if ( empty( $email_to_subscriber[ $row['email'] ] ) ) {
                    continue;
                }
                $sid = (int) $email_to_subscriber[ $row['email'] ];
                if ( empty( $event_index[ $sid ] ) ) {
                    continue;
                }
                $best_cid = 0;
                $best_ts  = 0;
                foreach ( $event_index[ $sid ] as $cid => $event_ts ) {
                    if ( $event_ts <= (int) $row['timestamp'] && $event_ts >= $attribution_window_ts && $event_ts > $best_ts ) {
                        $best_ts  = $event_ts;
                        $best_cid = (int) $cid;
                    }
                }
                if ( $best_cid <= 0 ) {
                    continue;
                }
                if ( ! isset( $breakdown[ $best_cid ] ) ) {
                    $breakdown[ $best_cid ] = array( 'orders' => 0, 'revenue' => 0.0 );
                }
                $breakdown[ $best_cid ]['orders']++;
                $breakdown[ $best_cid ]['revenue'] += (float) $row['total'];
            }

            return $breakdown;
        }

}
