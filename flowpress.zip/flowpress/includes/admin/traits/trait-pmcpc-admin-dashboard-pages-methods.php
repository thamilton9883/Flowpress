<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Dashboard_Pages_Methods {

        public static function render_dashboard() {
            // Keep one real dashboard only. Any old focused-dashboard routes should land on the main Overview page.
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing param.
            $page = isset( $_GET['page'] ) ? sanitize_key( (string) wp_unslash( $_GET['page'] ) ) : 'pmcpc_dashboard';
            $legacy_dashboard_redirects = array(
                'pmcpc_revenue_dashboard'     => admin_url( 'admin.php?page=pmcpc_dashboard' ),
                'pmcpc_campaign_dashboard'    => admin_url( 'admin.php?page=pmcpc_campaigns' ),
                'pmcpc_automations_dashboard' => admin_url( 'admin.php?page=pmcpc_automations' ),
                'pmcpc_audience_dashboard'    => admin_url( 'admin.php?page=pmcpc_subscribers' ),
            );
            if ( isset( $legacy_dashboard_redirects[ $page ] ) ) {
                wp_safe_redirect( $legacy_dashboard_redirects[ $page ] );
                exit;
            }

            global $wpdb;

            $hide_paid_features = function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features();

            $subscribers_table = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );
            $campaigns_table   = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
            $queue_table       = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
            $email_log_table   = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
            $events_table      = esc_sql( $wpdb->prefix . 'pmcpc_email_events' );
            $event_logs_table  = esc_sql( $wpdb->prefix . 'pmcpc_email_event_logs' );
            $reviews_table     = esc_sql( $wpdb->prefix . 'pmcpc_reviews' );

            // Cache dashboard stats briefly to avoid heavy queries on every page load.
            $cache_key = 'pmcpc_dashboard_stats_v4';

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $pmcpc_refresh_checks = isset( $_GET['pmcpc_refresh_checks'] ) && '1' === sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_refresh_checks'] ) );

            $data      = get_transient( $cache_key );

        
            if ( $pmcpc_refresh_checks ) {
                delete_transient( $cache_key );
                $data = false;
            }
    if ( ! is_array( $data ) ) {
                $now_mysql   = current_time( 'mysql' );
                $now_ts      = (int) current_time( 'timestamp' );
                $dt_30_mysql = date( 'Y-m-d H:i:s', $now_ts - ( 30 * DAY_IN_SECONDS ) );
                $dt_90_mysql = date( 'Y-m-d H:i:s', $now_ts - ( 90 * DAY_IN_SECONDS ) );

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $total_subscribers  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $subscribers_table" );
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $active_subscribers = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $subscribers_table WHERE status = %s", 'active' ) );
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $total_campaigns    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $campaigns_table" );

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $sent_emails = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $queue_table WHERE status = %s", 'sent' ) );
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $queue_pending = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $queue_table WHERE status = %s", 'pending' ) );
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $queue_failed  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $queue_table WHERE status = %s", 'failed' ) );

                // Additional subscriber status counts.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $pending_subscribers = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $subscribers_table WHERE status = %s", 'pending' ) );
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $unsubscribed_subscribers = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $subscribers_table WHERE status = %s", 'unsubscribed' ) );

                // Spam review counts (if spam submissions table exists).
                $spam_held = 0;
                $spam_blocked_today = 0;

                $spam_table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $spam_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $spam_table ) ) === $spam_table );

                if ( $spam_exists ) {
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $spam_held = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$spam_table} WHERE status = %s", 'held' ) );

                    $today_date = current_time( 'Y-m-d' );
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $spam_blocked_today = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(*) FROM {$spam_table} WHERE status = %s AND DATE(created_at) = %s",
                            'blocked',
                            $today_date
                        )
                    );
                }

                // Block lists summary (for quick health view).
                // Domains live in unified settings (blocked_email_domains). Additional blocked emails are
                // stored in a dedicated option (pmcpc_additional_blocked_emails) for backwards compatibility.
                $blocked_domains_count = 0;
                $blocked_emails_count  = 0;
                if ( class_exists( 'PMCPC_Settings' ) ) {
                    $blocked_domains = PMCPC_Settings::get( 'blocked_email_domains', array() );
                    if ( is_string( $blocked_domains ) ) {
                        $blocked_domains = array_filter( array_map( 'trim', preg_split( '/[
    ,]+/', $blocked_domains ) ) );
                    }
                    if ( is_array( $blocked_domains ) ) {
                        $blocked_domains_count = count( array_filter( $blocked_domains ) );
                    }

                    // Additional blocked emails:
                    // - primary source: pmcpc_additional_blocked_emails (textarea on Settings page)
                    // - optional legacy/unified key: blocked_emails (if present)
                    $blocked_emails_raw = get_option( 'pmcpc_additional_blocked_emails', '' );
                    if ( ! is_string( $blocked_emails_raw ) ) {
                        $blocked_emails_raw = '';
                    }

                    $blocked_emails = array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', (string) $blocked_emails_raw ) ) );

                    $blocked_emails_legacy = PMCPC_Settings::get( 'blocked_emails', array() );
                    if ( is_string( $blocked_emails_legacy ) ) {
                        $blocked_emails_legacy = array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', $blocked_emails_legacy ) ) );
                    }
                    if ( is_array( $blocked_emails_legacy ) && ! empty( $blocked_emails_legacy ) ) {
                        $blocked_emails = array_merge( $blocked_emails, $blocked_emails_legacy );
                    }

                    $blocked_emails = array_values( array_unique( array_filter( $blocked_emails ) ) );
                    $blocked_emails_count = count( $blocked_emails );
                }

                // Top source tags (derived from non-origin tags, excluding interest + lifecycle tags).
                $top_sources = array();
                $tags_table  = esc_sql( $wpdb->prefix . 'pmcpc_subscriber_tags' );
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $tag_rows = $wpdb->get_results(
                    "SELECT tag, COUNT(DISTINCT subscriber_id) AS cnt
                     FROM {$tags_table}
                     WHERE tag NOT LIKE 'origin:%' AND tag NOT LIKE 'form-%'
                     GROUP BY tag
                     ORDER BY cnt DESC
                     LIMIT 30"
                );

                $interest_catalog = array( 'newsletter', 'product-updates', 'tips' );
                $lifecycle_catalog = array();
                if ( class_exists( 'PMCPC_Settings' ) ) {
                    $raw_lifecycle = PMCPC_Settings::get( 'lifecycle_tags', "new-customer
    repeat-customer
    high-value
    vip
    recent-buyer
    lapsed-customer" );
                    if ( is_string( $raw_lifecycle ) && '' !== trim( $raw_lifecycle ) ) {
                        $pieces = preg_split( '/[
    ,]+/', $raw_lifecycle );
                        if ( is_array( $pieces ) ) {
                            foreach ( $pieces as $piece ) {
                                $piece = trim( strtolower( $piece ) );
                                if ( '' !== $piece ) {
                                    $lifecycle_catalog[] = $piece;
                                }
                            }
                        }
                    }
                }
                if ( empty( $lifecycle_catalog ) ) {
                    $lifecycle_catalog = array( 'new-customer', 'repeat-customer', 'high-value', 'vip', 'recent-buyer', 'lapsed-customer' );
                }
                $lifecycle_catalog = array_values( array_unique( $lifecycle_catalog ) );

                if ( ! empty( $tag_rows ) && is_array( $tag_rows ) ) {
                    foreach ( $tag_rows as $row ) {
                        $tag = isset( $row->tag ) ? sanitize_text_field( (string) $row->tag ) : '';
                        if ( '' === $tag ) {
                            continue;
                        }
                        if ( in_array( $tag, $interest_catalog, true ) ) {
                            continue;
                        }
                        if ( in_array( $tag, $lifecycle_catalog, true ) ) {
                            continue;
                        }
                        $top_sources[] = array(
                            'tag' => $tag,
                            'cnt' => isset( $row->cnt ) ? (int) $row->cnt : 0,
                        );
                        if ( count( $top_sources ) >= 6 ) {
                            break;
                        }
                    }
                }

                // Lifecycle breakdown (counts per tag) for dashboard.
                $lifecycle_counts = array();
                if ( ! empty( $lifecycle_catalog ) ) {
                    $placeholders = implode( ',', array_fill( 0, count( $lifecycle_catalog ), '%s' ) );

                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name comes from $wpdb->prefix.
                    // phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Dynamic IN() placeholders are built safely.
                    $rows = $wpdb->get_results(
                        $wpdb->prepare(
                            "SELECT tag, COUNT(DISTINCT subscriber_id) AS cnt
                                FROM {$tags_table}
                                WHERE tag IN ($placeholders)
                                GROUP BY tag",
                            ...$lifecycle_catalog
                        )
                    ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
                    // phpcs:enable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
                    if ( $rows ) {
                        foreach ( $rows as $r ) {
                            $lifecycle_counts[ (string) $r->tag ] = (int) $r->cnt;
                        }
                    }
                }

                $lifecycle_enabled = class_exists( 'PMCPC_Settings' ) ? ( PMCPC_Settings::get( 'lifecycle_auto_enabled', 'no' ) === 'yes' ) : false;

                // Engagement counts are lifetime-based, stored on the subscriber row.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $engaged_30 = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM $subscribers_table WHERE status = %s AND last_engaged_at IS NOT NULL AND last_engaged_at >= %s",
                        'active',
                        $dt_30_mysql
                    )
                );

                // At-risk: active subscribers with no engagement ever, or no engagement in 90+ days.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $at_risk_90 = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM $subscribers_table WHERE status = %s AND (last_engaged_at IS NULL OR last_engaged_at < %s)",
                        'active',
                        $dt_90_mysql
                    )
                );

                $next_queue_run    = wp_next_scheduled( 'pmcpc_process_email_queue' );
                $next_campaign_run = wp_next_scheduled( 'pmcpc_process_scheduled_campaigns' );

                // Email performance snapshot (30d): aggregate from the same tracking/event tables used by Analytics.
                // NOTE: the queue table does not store a dedicated `sent_at` column.
                // We treat `updated_at` as the send time when status becomes `sent`.
                $sent_30   = 0;
                $opens_30  = 0;
                $clicks_30 = 0;

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $sent_30 = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$queue_table} WHERE status = %s AND updated_at >= %s",
                        'sent',
                        $dt_30_mysql
                    )
                );

                $tracking_available = false;
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $events_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $events_table ) ) === $events_table );
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $event_logs_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $event_logs_table ) ) === $event_logs_table );

                if ( $events_exists ) {
                    $tracking_available = true;
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $opens_30 = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(DISTINCT e.queue_id) FROM {$events_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE e.event_type = %s AND q.updated_at >= %s AND q.status = %s",
                            'opened',
                            $dt_30_mysql,
                            'sent'
                        )
                    );

                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $clicks_30 = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(DISTINCT e.queue_id) FROM {$events_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE e.event_type = %s AND q.updated_at >= %s AND q.status = %s",
                            'clicked',
                            $dt_30_mysql,
                            'sent'
                        )
                    );
                } elseif ( $event_logs_exists ) {
                    $tracking_available = true;
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $opens_30 = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(DISTINCT e.queue_id) FROM {$event_logs_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE e.event_type = %s AND q.updated_at >= %s AND q.status = %s",
                            'open',
                            $dt_30_mysql,
                            'sent'
                        )
                    );

                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $clicks_30 = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(DISTINCT e.queue_id) FROM {$event_logs_table} e INNER JOIN {$queue_table} q ON q.id = e.queue_id WHERE e.event_type = %s AND q.updated_at >= %s AND q.status = %s",
                            'click',
                            $dt_30_mysql,
                            'sent'
                        )
                    );
                }

                $open_rate_30  = $sent_30 > 0 ? round( ( $opens_30 / $sent_30 ) * 100, 1 ) : null;
                $click_rate_30 = $sent_30 > 0 ? round( ( $clicks_30 / $sent_30 ) * 100, 1 ) : null;

                // Recent activity should reflect real queue, send, and upcoming campaign activity
                // even when tracking event logs are empty.
                $recent_activity = self::pmcpc_dashboard_get_recent_activity( $queue_table, $email_log_table, $campaigns_table, $subscribers_table );

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $latest_campaigns = $wpdb->get_results(
                    "SELECT id, name, status, created_at, updated_at, next_run_at
                     FROM $campaigns_table
                     ORDER BY (CASE WHEN next_run_at IS NULL THEN 1 ELSE 0 END) ASC, next_run_at ASC, updated_at DESC
                     LIMIT 5"
                );


                // WooCommerce opportunity stats (used for upsell + dashboard signals).
                $wc_active = class_exists( 'WooCommerce' );
                $wc_orders_30 = 0;
                $wc_customers_total = 0;
                $wc_customers_active_90 = 0;
                $wc_customers_winback = 0;
                $wc_abandoned_7 = 0;
                $wc_abandoned_total_7 = 0.0;
                $wc_revenue_30 = 0.0;
                $wc_aov_30 = 0.0;
                $wc_revenue_series_14 = array();
                $wc_revenue_series_14_max = 0.0;

                if ( $wc_active ) {
                    $posts_table    = esc_sql( $wpdb->posts );
                    $postmeta_table = esc_sql( $wpdb->postmeta );

                    $order_statuses = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
                    $st_in          = "'" . implode( "','", array_map( 'esc_sql', $order_statuses ) ) . "'";

                    // Orders in last 30 days.
                    // Prefer WooCommerce API (works with HPOS/custom order tables). Fall back to posts table.
                    if ( function_exists( 'wc_get_orders' ) ) {
                        $wc_date_cutoff = date( 'Y-m-d H:i:s', (int) current_time( 'timestamp' ) - ( 30 * DAY_IN_SECONDS ) );
                        $res = wc_get_orders(
                            array(
                                'limit'        => 1,
                                'return'       => 'ids',
                                'paginate'     => true,
                                'status'       => array( 'processing', 'completed', 'on-hold' ),
                                'date_created' => '>' . $wc_date_cutoff,
                            )
                        );
                        if ( is_object( $res ) && isset( $res->total ) ) {
                            $wc_orders_30 = (int) $res->total;
                        } elseif ( is_array( $res ) ) {
                            $wc_orders_30 = count( $res );
                        }
                    }

                    if ( 0 === (int) $wc_orders_30 ) {
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                        $wc_orders_30 = (int) $wpdb->get_var(
                            $wpdb->prepare(
                                "SELECT COUNT(ID)
                                 FROM {$posts_table}
                                 WHERE post_type = 'shop_order'
                                   AND post_status IN ({$st_in})
                                   AND post_date >= %s",
                                $dt_30_mysql
                            )
                        );
                    }

                    // Revenue + AOV (last 30 days).
                    if ( function_exists( 'wc_get_orders' ) ) {
                        $wc_date_cutoff = date( 'Y-m-d H:i:s', (int) current_time( 'timestamp' ) - ( 30 * DAY_IN_SECONDS ) );
                        $ids = wc_get_orders( array(
                            'limit'        => 500,
                            'return'       => 'ids',
                            'status'       => array( 'processing', 'completed', 'on-hold' ),
                            'date_created' => '>' . $wc_date_cutoff,
                        ) );
                        if ( is_array( $ids ) && ! empty( $ids ) ) {
                            $sum = 0.0;
                            $cnt = 0;
                            foreach ( $ids as $oid ) {
                                $order = wc_get_order( $oid );
                                if ( ! $order ) {
                                    continue;
                                }
                                $sum += (float) $order->get_total();
                                $cnt++;
                            }
                            $wc_revenue_30 = $sum;
                            $wc_aov_30 = $cnt ? ( $sum / $cnt ) : 0.0;
                        }
                    }


    // Revenue attributed to email (last 30 days, last-touch within 7 days).
    $wc_email_orders_30  = 0;
    $wc_email_revenue_30 = 0.0;
    $wc_email_share_30   = 0.0;
    if ( class_exists( 'PMCPC_Revenue_Attribution' ) ) {
        $attr = PMCPC_Revenue_Attribution::totals( 30, 7, 500 );
        if ( is_array( $attr ) ) {
            $wc_email_orders_30  = isset( $attr['orders'] ) ? (int) $attr['orders'] : 0;
            $wc_email_revenue_30 = isset( $attr['revenue'] ) ? (float) $attr['revenue'] : 0.0;
            $wc_email_share_30   = ( $wc_revenue_30 > 0 ) ? round( ( $wc_email_revenue_30 / $wc_revenue_30 ) * 100, 1 ) : 0.0;
        }
    }

                    // Revenue trend (last 14 days) for a small dashboard sparkline.
                    if ( function_exists( 'wc_get_orders' ) ) {
                        $days = 14;
                        $series = array();
                        for ( $i = $days - 1; $i >= 0; $i-- ) {
                            $key = gmdate( 'Y-m-d', (int) current_time( 'timestamp' ) - ( $i * DAY_IN_SECONDS ) );
                            $series[ $key ] = 0.0;
                        }

                        $cutoff = date( 'Y-m-d H:i:s', (int) current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS ) );
                        $ids_14 = wc_get_orders( array(
                            'limit'        => 800,
                            'return'       => 'ids',
                            'status'       => array( 'processing', 'completed', 'on-hold' ),
                            'date_created' => '>' . $cutoff,
                        ) );

                        if ( is_array( $ids_14 ) && ! empty( $ids_14 ) ) {
                            foreach ( $ids_14 as $oid ) {
                                $order = wc_get_order( $oid );
                                if ( ! $order ) {
                                    continue;
                                }
                                $dt = $order->get_date_created();
                                if ( ! $dt ) {
                                    continue;
                                }
                                $key = $dt->date_i18n( 'Y-m-d' );
                                if ( isset( $series[ $key ] ) ) {
                                    $series[ $key ] += (float) $order->get_total();
                                }
                            }
                        }

                        $wc_revenue_series_14 = array_values( $series );
                        $wc_revenue_series_14_max = ! empty( $wc_revenue_series_14 ) ? max( $wc_revenue_series_14 ) : 0.0;
                    }


                    // Distinct customers ever vs active in last 90 days.
                    // We count registered users by _customer_user, and fall back to billing email for guests.
                    $distinct_customer_expr = "CASE
                        WHEN cu.meta_value IS NOT NULL AND cu.meta_value != '' AND cu.meta_value != '0'
                            THEN CONCAT('u:', cu.meta_value)
                        WHEN be.meta_value IS NOT NULL AND be.meta_value != ''
                            THEN CONCAT('e:', be.meta_value)
                        ELSE NULL
                    END";

                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $wc_customers_total = (int) $wpdb->get_var(
                        "SELECT COUNT(DISTINCT {$distinct_customer_expr})
                         FROM {$posts_table} p
                         LEFT JOIN {$postmeta_table} cu ON (cu.post_id = p.ID AND cu.meta_key = '_customer_user')
                         LEFT JOIN {$postmeta_table} be ON (be.post_id = p.ID AND be.meta_key = '_billing_email')
                         WHERE p.post_type = 'shop_order'
                           AND p.post_status IN ({$st_in})"
                    );

                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $wc_customers_active_90 = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(DISTINCT {$distinct_customer_expr})
                             FROM {$posts_table} p
                             LEFT JOIN {$postmeta_table} cu ON (cu.post_id = p.ID AND cu.meta_key = '_customer_user')
                             LEFT JOIN {$postmeta_table} be ON (be.post_id = p.ID AND be.meta_key = '_billing_email')
                             WHERE p.post_type = 'shop_order'
                               AND p.post_status IN ({$st_in})
                               AND p.post_date >= %s",
                            $dt_90_mysql
                        )
                    );

                    $wc_customers_winback = max( 0, $wc_customers_total - $wc_customers_active_90 );

                    if ( class_exists( 'PMCPC_Abandoned_Carts' ) ) {
                        $ab = PMCPC_Abandoned_Carts::get_abandoned_metrics( 7 );
                        $wc_abandoned_7 = (int) $ab['count'];
                        $wc_abandoned_total_7 = (float) $ab['total'];
                    }
                }



                // Automation health (distinct triggers with non-draft automation campaigns).
                $automation_active = 0;
                $automation_last_run = null;
                try {
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $automation_active = (int) $wpdb->get_var(
                        "SELECT COUNT(DISTINCT automation_trigger)
                         FROM {$campaigns_table}
                         WHERE campaign_type = 'automation'
                           AND automation_trigger IS NOT NULL
                           AND status <> 'draft'"
                    );

                    // Last automation delivery activity based on queue updates.
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $automation_last_run = $wpdb->get_var(
                        "SELECT MAX(q.updated_at)
                         FROM {$queue_table} q
                         INNER JOIN {$campaigns_table} c ON c.id = q.campaign_id
                         WHERE c.campaign_type = 'automation'
                           AND q.status IN ('sent','failed')"
                    );
                } catch ( Exception $e ) {
                    // Silent fail on shared hosts.
                }

                // Automation health score is recalculated later from the rendered dashboard automation states,
                // queue health, and tracking availability so it reflects the current control panel more directly.
                $growth_score = 0;

                // Dynamic forms summary.
                $forms_total       = 0;
                $forms_with_upload = 0;
                if ( class_exists( 'PMCPC_Forms' ) ) {
                    $forms = PMCPC_Forms::get_forms();
                    if ( is_array( $forms ) ) {
                        $forms_total = count( $forms );
                        foreach ( $forms as $form ) {
                            if ( ! is_array( $form ) ) {
                                continue;
                            }
                            $settings = isset( $form['settings'] ) && is_array( $form['settings'] ) ? $form['settings'] : array();
                            $custom_fields = isset( $settings['custom_fields'] ) && is_array( $settings['custom_fields'] ) ? $settings['custom_fields'] : array();
                            $custom_fields = PMCPC_Forms::sanitize_custom_fields( $custom_fields );
                            foreach ( $custom_fields as $cf ) {
                                if ( ! is_array( $cf ) ) {
                                    continue;
                                }
                                $enabled = isset( $cf['enabled'] ) ? (string) $cf['enabled'] : 'yes';
                                if ( 'no' === $enabled ) {
                                    continue;
                                }
                                $type = isset( $cf['type'] ) ? sanitize_key( (string) $cf['type'] ) : 'text';
                                if ( 'file' === $type ) {
                                    $forms_with_upload++;
                                    break;
                                }
                            }
                        }
                    }
                }


                $reviews_pending_count  = 0;
                $reviews_approved_today = 0;
                $reviews_average_rating = 0.0;
                $reviews_product_count  = 0;
                $reviews_standard_count = 0;
                $reviews_created_7d     = 0;
                $latest_review_preview  = array();

                // Reviews summary.
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $reviews_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $reviews_table ) ) === $reviews_table );
                if ( $reviews_exists ) {
                    $dt_7_mysql = date( 'Y-m-d H:i:s', $now_ts - ( 7 * DAY_IN_SECONDS ) );
                    $today_date = current_time( 'Y-m-d' );

                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $reviews_pending_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$reviews_table} WHERE status = %s", 'pending' ) );
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $reviews_approved_today = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$reviews_table} WHERE status = %s AND DATE(updated_at) = %s", 'approved', $today_date ) );
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $reviews_average_rating = (float) $wpdb->get_var( $wpdb->prepare( "SELECT AVG(rating) FROM {$reviews_table} WHERE status = %s AND rating > 0", 'approved' ) );
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $reviews_product_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$reviews_table} WHERE review_type = %s", 'product_review' ) );
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $reviews_standard_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$reviews_table} WHERE review_type <> %s", 'product_review' ) );
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $reviews_created_7d = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$reviews_table} WHERE created_at >= %s", $dt_7_mysql ) );
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    $latest_review_preview = (array) $wpdb->get_row( $wpdb->prepare( "SELECT reviewer_name, review_text, rating FROM {$reviews_table} WHERE status = %s ORDER BY updated_at DESC, id DESC LIMIT 1", 'approved' ), ARRAY_A );
                }

                $queue_failures_today = 0;
                $queue_last_run       = null;
                $queue_processing_status = $queue_pending > 0 ? 'active' : 'idle';
                $today_date = current_time( 'Y-m-d' );
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $queue_failures_today = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$queue_table} WHERE status = %s AND DATE(updated_at) = %s", 'failed', $today_date ) );
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $queue_last_run = $wpdb->get_var( "SELECT MAX(updated_at) FROM {$queue_table} WHERE status IN ('sent','failed')" );

                // Revenue attribution is optional and only available when the revenue helper can resolve it.
                // Keep this initialised so dashboard cards do not emit notices on non-WooCommerce/free installs.
                $campaign_revenue_breakdown = array();
                if ( method_exists( __CLASS__, 'pmcpc_dashboard_get_campaign_revenue_breakdown' ) ) {
                    $maybe_revenue_breakdown = self::pmcpc_dashboard_get_campaign_revenue_breakdown( 30, 7, 500 );
                    if ( is_array( $maybe_revenue_breakdown ) ) {
                        $campaign_revenue_breakdown = $maybe_revenue_breakdown;
                    }
                }

                $core_trigger_groups = array(
                    'customer' => array(
                        'label' => __( 'Customer / WooCommerce', 'product-mailer-campaigns' ),
                        'triggers' => array(
                            'first_order' => array( 'label' => __( 'First order', 'product-mailer-campaigns' ), 'icon' => '🥇', 'description' => __( 'When a customer places their first WooCommerce order.', 'product-mailer-campaigns' ) ),
                            'repeat_customer' => array( 'label' => __( 'Repeat customer', 'product-mailer-campaigns' ), 'icon' => '🔁', 'description' => __( 'When a customer completes their second WooCommerce order.', 'product-mailer-campaigns' ) ),
                            'high_value' => array( 'label' => __( 'High-value customer', 'product-mailer-campaigns' ), 'icon' => '💎', 'description' => __( 'When a customer crosses your high-value threshold.', 'product-mailer-campaigns' ) ),
                            'vip_customer' => array( 'label' => __( 'VIP customer', 'product-mailer-campaigns' ), 'icon' => '👑', 'description' => __( 'When a customer crosses your VIP threshold.', 'product-mailer-campaigns' ) ),
                            'post_purchase' => array( 'label' => __( 'Post-purchase', 'product-mailer-campaigns' ), 'icon' => '📦', 'description' => __( 'Follow-up emails sent after an order is completed.', 'product-mailer-campaigns' ) ),
                            'review_request' => array( 'label' => __( 'Review request', 'product-mailer-campaigns' ), 'icon' => '⭐', 'description' => __( 'Ask customers for a review after their purchase.', 'product-mailer-campaigns' ) ),
                            'customer_inactive' => array( 'label' => __( 'Customer inactive', 'product-mailer-campaigns' ), 'icon' => '🕰️', 'description' => __( 'Win back customers who have not ordered recently.', 'product-mailer-campaigns' ) ),
                            'lapsed_high_value_customer' => array( 'label' => __( 'Lapsed high-value customer', 'product-mailer-campaigns' ), 'icon' => '💰', 'description' => __( 'Win back high-value customers who have not ordered for 90+ days.', 'product-mailer-campaigns' ) ),
                            'abandoned_cart_recovery' => array( 'label' => __( 'Abandoned cart recovery', 'product-mailer-campaigns' ), 'icon' => '🛒', 'description' => __( 'Recover abandoned carts with the full multi-step sequence.', 'product-mailer-campaigns' ), 'triggers' => array( 'abandoned_cart_step_1', 'abandoned_cart_step_2', 'abandoned_cart_step_3' ) ),
                        ),
                    ),
                    'subscriber' => array(
                        'label' => __( 'Subscriber / List', 'product-mailer-campaigns' ),
                        'triggers' => array(
                            'new_subscriber' => array( 'label' => __( 'New subscribers', 'product-mailer-campaigns' ), 'icon' => '✉️', 'description' => __( 'When someone joins your mailing list.', 'product-mailer-campaigns' ) ),
                            'welcome_follow_up' => array( 'label' => __( 'Welcome follow-up', 'product-mailer-campaigns' ), 'icon' => '➕', 'description' => __( 'A follow-up sent a few days after someone joins your mailing list.', 'product-mailer-campaigns' ) ),
                            'lead_magnet_download' => array( 'label' => __( 'Lead magnet delivery', 'product-mailer-campaigns' ), 'icon' => '📩', 'description' => __( 'When a subscriber joins via a lead magnet or opt-in offer.', 'product-mailer-campaigns' ) ),
                            'subscriber_inactive' => array( 'label' => __( 'Subscriber inactive', 'product-mailer-campaigns' ), 'icon' => '💤', 'description' => __( 'When a subscriber has not engaged for a chosen number of days.', 'product-mailer-campaigns' ) ),
                            'subscriber_anniversary' => array( 'label' => __( 'Subscriber anniversary', 'product-mailer-campaigns' ), 'icon' => '🎉', 'description' => __( 'On the anniversary of when someone joined your mailing list.', 'product-mailer-campaigns' ) ),
                            'subscriber_birthday' => array( 'label' => __( 'Subscriber birthday', 'product-mailer-campaigns' ), 'icon' => '🎂', 'description' => __( 'On a subscriber birthday when that profile field is available.', 'product-mailer-campaigns' ) ),
                        ),
                    ),
                    'scheduled' => array(
                        'label' => __( 'Scheduled', 'product-mailer-campaigns' ),
                        'triggers' => array(
                            'date' => array( 'label' => __( 'On a specific date', 'product-mailer-campaigns' ), 'icon' => '🗓️', 'description' => __( 'One-time or recurring campaigns that run on chosen dates.', 'product-mailer-campaigns' ) ),
                        ),
                    ),
                );
                $core_automation_cards = array();
                $core_automation_group_cards = array();
                $top_automation_rows   = array();
                foreach ( $core_trigger_groups as $group_key => $group_meta ) {
                    $core_automation_group_cards[ $group_key ] = array(
                        'label' => isset( $group_meta['label'] ) ? (string) $group_meta['label'] : '',
                        'cards' => array(),
                    );
                    $group_triggers = isset( $group_meta['triggers'] ) && is_array( $group_meta['triggers'] ) ? $group_meta['triggers'] : array();
                    foreach ( $group_triggers as $trigger_key => $trigger_meta ) {
                    $metric_triggers = ! empty( $trigger_meta['triggers'] ) && is_array( $trigger_meta['triggers'] ) ? array_map( 'sanitize_key', $trigger_meta['triggers'] ) : array( $trigger_key );
                    $campaign = null;
                    $campaign_id = 0;
                    $status_values = array();
                    $trigger_metrics = array(
                        'entered_30' => 0,
                        'sent_30' => 0,
                        'open_rate_30' => null,
                        'click_rate_30' => null,
                        'scheduled_count' => 0,
                        'next_run_at' => '',
                        'last_activity_at' => '',
                        'last_activity_email' => '',
                        'last_activity_status' => '',
                    );
                    $open_weighted = 0.0;
                    $click_weighted = 0.0;
                    $rate_weight = 0;

                    foreach ( $metric_triggers as $metric_trigger ) {
                        $candidate_campaign = self::pmcpc_dashboard_get_latest_trigger_campaign( $metric_trigger, $campaigns_table );
                        if ( ! $campaign && $candidate_campaign ) {
                            $campaign = $candidate_campaign;
                            $campaign_id = isset( $candidate_campaign->id ) ? (int) $candidate_campaign->id : 0;
                        }
                        $status_values[] = self::pmcpc_dashboard_resolve_automation_status( $metric_trigger, $candidate_campaign );
                        $metric_row = self::pmcpc_dashboard_get_trigger_metrics( $metric_trigger, $campaigns_table, $queue_table, $events_table, $event_logs_table, $dt_30_mysql );

                        $sent_for_rate = isset( $metric_row['sent_30'] ) ? (int) $metric_row['sent_30'] : 0;
                        $trigger_metrics['entered_30'] += isset( $metric_row['entered_30'] ) ? (int) $metric_row['entered_30'] : 0;
                        $trigger_metrics['sent_30'] += $sent_for_rate;
                        $trigger_metrics['scheduled_count'] += isset( $metric_row['scheduled_count'] ) ? (int) $metric_row['scheduled_count'] : 0;
                        if ( $sent_for_rate > 0 ) {
                            $rate_weight += $sent_for_rate;
                            if ( ! is_null( $metric_row['open_rate_30'] ) ) {
                                $open_weighted += (float) $metric_row['open_rate_30'] * $sent_for_rate;
                            }
                            if ( ! is_null( $metric_row['click_rate_30'] ) ) {
                                $click_weighted += (float) $metric_row['click_rate_30'] * $sent_for_rate;
                            }
                        }
                        if ( empty( $trigger_metrics['next_run_at'] ) || ( ! empty( $metric_row['next_run_at'] ) && strtotime( (string) $metric_row['next_run_at'] ) < strtotime( (string) $trigger_metrics['next_run_at'] ) ) ) {
                            $trigger_metrics['next_run_at'] = isset( $metric_row['next_run_at'] ) ? (string) $metric_row['next_run_at'] : '';
                        }
                        if ( ! empty( $metric_row['last_activity_at'] ) && ( empty( $trigger_metrics['last_activity_at'] ) || strtotime( (string) $metric_row['last_activity_at'] ) > strtotime( (string) $trigger_metrics['last_activity_at'] ) ) ) {
                            $trigger_metrics['last_activity_at'] = (string) $metric_row['last_activity_at'];
                            $trigger_metrics['last_activity_email'] = isset( $metric_row['last_activity_email'] ) ? (string) $metric_row['last_activity_email'] : '';
                            $trigger_metrics['last_activity_status'] = isset( $metric_row['last_activity_status'] ) ? (string) $metric_row['last_activity_status'] : '';
                        }
                    }
                    if ( $rate_weight > 0 ) {
                        $trigger_metrics['open_rate_30'] = $open_weighted / $rate_weight;
                        $trigger_metrics['click_rate_30'] = $click_weighted / $rate_weight;
                    }

                    $status = 'not_created';
                    $active_count = count( array_filter( $status_values, static function( $v ) { return in_array( $v, array( 'active', 'scheduled' ), true ); } ) );
                    if ( $active_count === count( $metric_triggers ) && $active_count > 0 ) {
                        $status = 'active';
                    } elseif ( $active_count > 0 ) {
                        $status = 'partial';
                    } elseif ( in_array( 'needs_setup', $status_values, true ) ) {
                        $status = 'needs_setup';
                    } elseif ( in_array( 'inactive', $status_values, true ) ) {
                        $status = 'inactive';
                    }

                    $card = array(
                        'trigger' => $trigger_key,
                        'icon' => $trigger_meta['icon'],
                        'label' => $trigger_meta['label'],
                        'description' => $trigger_meta['description'],
                        'status' => $status,
                        'campaign_id' => $campaign_id,
                        'campaign_name' => $campaign && ! empty( $campaign->name ) ? (string) $campaign->name : '',
                        'entered_30' => isset( $trigger_metrics['entered_30'] ) ? (int) $trigger_metrics['entered_30'] : 0,
                        'sent_30' => isset( $trigger_metrics['sent_30'] ) ? (int) $trigger_metrics['sent_30'] : 0,
                        'open_rate_30' => $trigger_metrics['open_rate_30'] ?? null,
                        'click_rate_30' => $trigger_metrics['click_rate_30'] ?? null,
                        'scheduled_count' => isset( $trigger_metrics['scheduled_count'] ) ? (int) $trigger_metrics['scheduled_count'] : 0,
                        'next_run_at' => isset( $trigger_metrics['next_run_at'] ) ? (string) $trigger_metrics['next_run_at'] : '',
                        'last_activity_at' => isset( $trigger_metrics['last_activity_at'] ) ? (string) $trigger_metrics['last_activity_at'] : '',
                        'last_activity_email' => isset( $trigger_metrics['last_activity_email'] ) ? (string) $trigger_metrics['last_activity_email'] : '',
                        'last_activity_status' => isset( $trigger_metrics['last_activity_status'] ) ? (string) $trigger_metrics['last_activity_status'] : '',
                        'revenue_orders_30' => 0,
                        'revenue_30' => 0.0,
                    );
                    if ( 'date' !== $trigger_key ) {
                        foreach ( $metric_triggers as $metric_trigger ) {
                            foreach ( self::pmcpc_dashboard_get_trigger_campaign_ids( $metric_trigger, $campaigns_table ) as $trigger_campaign_id ) {
                                $trigger_campaign_id = (int) $trigger_campaign_id;
                                if ( isset( $campaign_revenue_breakdown[ $trigger_campaign_id ] ) ) {
                                    $card['revenue_orders_30'] += isset( $campaign_revenue_breakdown[ $trigger_campaign_id ]['orders'] ) ? (int) $campaign_revenue_breakdown[ $trigger_campaign_id ]['orders'] : 0;
                                    $card['revenue_30'] += isset( $campaign_revenue_breakdown[ $trigger_campaign_id ]['revenue'] ) ? (float) $campaign_revenue_breakdown[ $trigger_campaign_id ]['revenue'] : 0.0;
                                }
                            }
                        }
                    }
                        $core_automation_cards[] = $card;
                        $core_automation_group_cards[ $group_key ]['cards'][] = $card;
                        if ( 'date' !== $trigger_key ) {
                            $top_automation_rows[] = $card;
                        }
                    }
                }
                foreach ( $core_automation_group_cards as $group_key => $group_card_bundle ) {
                    $group_cards = isset( $group_card_bundle['cards'] ) && is_array( $group_card_bundle['cards'] ) ? $group_card_bundle['cards'] : array();
                    $core_automation_group_cards[ $group_key ]['recent_activity'] = self::pmcpc_dashboard_get_group_recent_activity( $group_cards, $campaigns_table, $queue_table );
                }

                $workflow_cards = self::pmcpc_dashboard_get_workflow_cards(
                    $campaigns_table,
                    $queue_table,
                    $events_table,
                    $event_logs_table,
                    $dt_30_mysql,
                    $campaign_revenue_breakdown
                );

                usort(
                    $top_automation_rows,
                    static function ( $a, $b ) {
                        $a_score = isset( $a['sent_30'] ) ? (int) $a['sent_30'] : 0;
                        $b_score = isset( $b['sent_30'] ) ? (int) $b['sent_30'] : 0;
                        if ( $a_score === $b_score ) {
                            return strcmp( (string) $a['label'], (string) $b['label'] );
                        }
                        return ( $a_score > $b_score ) ? -1 : 1;
                    }
                );
                $top_automation_rows = array_slice( $top_automation_rows, 0, 4 );

                // Recalculate automation health from the same card statuses shown on the dashboard.
                $core_total             = count( $core_automation_cards );
                $active_like_count      = 0;
                $needs_setup_count      = 0;
                $inactive_count         = 0;
                $not_created_count      = 0;
                foreach ( $core_automation_cards as $health_card ) {
                    $health_status = isset( $health_card['status'] ) ? sanitize_key( (string) $health_card['status'] ) : 'not_created';
                    if ( in_array( $health_status, array( 'active', 'scheduled' ), true ) ) {
                        $active_like_count++;
                    } elseif ( 'needs_setup' === $health_status ) {
                        $needs_setup_count++;
                    } elseif ( 'inactive' === $health_status ) {
                        $inactive_count++;
                    } else {
                        $not_created_count++;
                    }
                }
                $automation_component = $core_total > 0 ? ( (float) $active_like_count / (float) $core_total ) * 70 : 0;
                $setup_penalty        = min( 18, ( $needs_setup_count * 6 ) + ( $not_created_count * 4 ) + ( $inactive_count * 5 ) );
                $queue_component      = (int) $queue_failed > 0 ? max( 0, 15 - min( 15, (int) $queue_failed ) ) : 15;
                $tracking_component   = ( ! is_null( $open_rate_30 ) || ! is_null( $click_rate_30 ) ) ? 10 : 0;
                $engagement_component = (int) $active_subscribers > 0 ? min( 5, ( (float) $engaged_30 / (float) $active_subscribers ) * 5 ) : 0;
                $growth_score         = (int) round( max( 0, min( 100, $automation_component - $setup_penalty + $queue_component + $tracking_component + $engagement_component ) ) );

                $data = array(
                    'total_subscribers'  => $total_subscribers,
                    'active_subscribers' => $active_subscribers,
                    'engaged_30'         => $engaged_30,
                    'at_risk_90'         => $at_risk_90,
                    'total_campaigns'    => $total_campaigns,
                    'sent_emails'        => $sent_emails,
                    'sent_30'            => $sent_30,
                    'open_rate_30'       => $open_rate_30,
                    'click_rate_30'      => $click_rate_30,
                    'queue_pending'      => $queue_pending,
                    'queue_failed'       => $queue_failed,
    'pending_subscribers' => $pending_subscribers,
    'unsubscribed_subscribers' => $unsubscribed_subscribers,
    'spam_held' => $spam_held,
    'spam_blocked_today' => $spam_blocked_today,
    'blocked_domains_count' => $blocked_domains_count,
    'blocked_emails_count' => $blocked_emails_count,
                    'forms_total'         => $forms_total,
                    'forms_with_upload'  => $forms_with_upload,
                    'automation_active'  => $automation_active,
                    'automation_last_run' => $automation_last_run,
                    'growth_score'       => isset( $growth_score ) ? (int) $growth_score : 0,
                    'wc_active'          => $wc_active,
                    'wc_orders_30'       => $wc_orders_30,
                    'wc_revenue_30'     => $wc_revenue_30,
                    'wc_aov_30'         => $wc_aov_30,
                    'wc_email_orders_30' => isset( $wc_email_orders_30 ) ? (int) $wc_email_orders_30 : 0,
                    'wc_email_revenue_30' => isset( $wc_email_revenue_30 ) ? (float) $wc_email_revenue_30 : 0.0,
                    'wc_email_share_30' => isset( $wc_email_share_30 ) ? (float) $wc_email_share_30 : 0.0,
                    'wc_customers_total' => $wc_customers_total,
                    'wc_customers_active_90' => $wc_customers_active_90,
                    'wc_customers_winback' => $wc_customers_winback,
                    'wc_abandoned_7' => $wc_abandoned_7,
                    'wc_abandoned_total_7' => $wc_abandoned_total_7,
                    'wc_revenue_series_14' => $wc_revenue_series_14,
                    'wc_revenue_series_14_max' => $wc_revenue_series_14_max,
                    'orders_30'          => $wc_orders_30,
                    'revenue_30'         => $wc_revenue_30,
                    'aov_30'             => $wc_aov_30,
                    'projected_recoverable_30' => ( $wc_abandoned_total_7 > 0 ? (float) ( $wc_abandoned_total_7 * ( 30 / 7 ) ) : 0.0 ),
                    'rev_series_14'      => $wc_revenue_series_14,
                    'rev_series_14_max'  => $wc_revenue_series_14_max,
    'top_sources' => $top_sources,
    'lifecycle_counts' => $lifecycle_counts,
    'lifecycle_enabled' => $lifecycle_enabled,
                    'next_queue_run'     => $next_queue_run,
                    'next_campaign_run'  => $next_campaign_run,
                    'recent_activity'    => is_array( $recent_activity ) ? $recent_activity : array(),
                    'latest_campaigns'   => is_array( $latest_campaigns ) ? $latest_campaigns : array(),
                    'generated_at'       => $now_mysql,
                    'reviews_pending_count' => $reviews_pending_count,
                    'reviews_approved_today' => $reviews_approved_today,
                    'reviews_average_rating' => $reviews_average_rating,
                    'reviews_product_count' => $reviews_product_count,
                    'reviews_standard_count' => $reviews_standard_count,
                    'reviews_created_7d' => $reviews_created_7d,
                    'latest_review_preview' => $latest_review_preview,
                    'queue_failures_today' => $queue_failures_today,
                    'queue_last_run' => $queue_last_run,
                    'queue_processing_status' => $queue_processing_status,
                    'active_like_count'    => isset( $active_like_count ) ? (int) $active_like_count : 0,
                    'needs_setup_count'    => isset( $needs_setup_count ) ? (int) $needs_setup_count : 0,
                    'inactive_count'       => isset( $inactive_count ) ? (int) $inactive_count : 0,
                    'not_created_count'    => isset( $not_created_count ) ? (int) $not_created_count : 0,
                    'automation_component' => isset( $automation_component ) ? (float) $automation_component : 0.0,
                    'setup_penalty'        => isset( $setup_penalty ) ? (float) $setup_penalty : 0.0,
                    'queue_component'      => isset( $queue_component ) ? (float) $queue_component : 0.0,
                    'tracking_component'   => isset( $tracking_component ) ? (float) $tracking_component : 0.0,
                    'engagement_component' => isset( $engagement_component ) ? (float) $engagement_component : 0.0,
                    'core_automation_cards' => $core_automation_cards,
                    'core_automation_group_cards' => $core_automation_group_cards,
                    'workflow_cards' => isset( $workflow_cards ) && is_array( $workflow_cards ) ? $workflow_cards : array(),
                    'top_automation_rows' => $top_automation_rows,
                );

                set_transient( $cache_key, $data, 60 );
            }

            $format_ts = function ( $ts ) {
                if ( empty( $ts ) ) {
                    return __( '—', 'product-mailer-campaigns' );
                }
                return date_i18n( 'Y-m-d H:i', $ts );
            };

            $format_mysql = function ( $mysql ) {
                if ( empty( $mysql ) ) {
                    return __( '—', 'product-mailer-campaigns' );
                }
                $ts = strtotime( $mysql );
                if ( ! $ts ) {
                    return esc_html( $mysql );
                }
                return date_i18n( 'Y-m-d H:i', $ts );
            };

            $tracking_debug = ! is_null( $data['open_rate_30'] ) || ! is_null( $data['click_rate_30'] );

            echo '<div class="wrap pmcpc-dashboard">';

            // Dashboard callouts (avoid WP core `.notice` to prevent unexpected auto-dismiss behaviour).
            echo '<style>';
            echo '.pmcpc-dashboard-callout{background:#fff;border:1px solid #c3c4c7;border-left-width:4px;border-radius:3px;margin:12px 0 18px;padding:10px 12px;box-shadow:0 1px 1px rgba(0,0,0,.04);}';
            echo '.pmcpc-dashboard-callout--success{border-left-color:#00a32a;}';
            echo '.pmcpc-dashboard-callout--warning{border-left-color:#dba617;}';
            echo '.pmcpc-dashboard-callout--info{border-left-color:#72aee6;}';
            echo '.pmcpc-dashboard-callout h2{margin:0 0 6px;font-size:14px;}';
            echo '.pmcpc-dashboard-callout ul{margin:6px 0 0 20px;}';
            echo '.pmcpc-dashboard-callout li{margin:2px 0;}';
            echo '.pmcpc-premium-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px;margin:0 0 14px;}';
            echo '.pmcpc-premium-grid--automation{grid-template-columns:repeat(4,minmax(0,1fr));}';
            echo '.pmcpc-premium-grid--wide{grid-template-columns:1.25fr 1fr 1fr;}';
            echo '.pmcpc-premium-grid--duo{grid-template-columns:minmax(260px,.9fr) minmax(420px,1.6fr);align-items:start;}';
            echo '.pmcpc-premium-card{background:#fff;border:1px solid #d9dee3;border-radius:12px;padding:13px 14px 12px;box-shadow:0 1px 2px rgba(0,0,0,.04);}';
            echo '.pmcpc-premium-card h3{margin:0 0 4px;font-size:13px;line-height:1.3;color:#1d2327;}';
            echo '.pmcpc-premium-card h4{margin:0;font-size:13px;line-height:1.3;color:#1d2327;}';
            echo '.pmcpc-premium-kpi{font-size:28px;line-height:1.05;font-weight:700;color:#1d2327;margin:0 0 4px;}';
            echo '.pmcpc-premium-meta{font-size:12px;color:#50575e;line-height:1.45;}';
            echo '.pmcpc-premium-list{margin:8px 0 0;padding-left:18px;}';
            echo '.pmcpc-premium-list li{margin:0 0 4px;}';
            echo '.pmcpc-activity-feed{display:grid;gap:8px;margin-top:8px;}';
            echo '.pmcpc-activity-item{display:grid;grid-template-columns:auto 1fr;gap:8px;padding:8px 0;border-top:1px solid #eef1f4;}';
            echo '.pmcpc-activity-item:first-child{border-top:0;padding-top:0;}';
            echo '.pmcpc-activity-icon{width:22px;height:22px;display:inline-flex;align-items:center;justify-content:center;border-radius:999px;background:#f6f7f7;font-size:12px;}';
            echo '.pmcpc-activity-title{font-weight:600;color:#1d2327;line-height:1.3;}';
            echo '.pmcpc-activity-sub{margin-top:1px;font-size:11px;color:#50575e;line-height:1.4;}';
            echo '.pmcpc-premium-badge{display:inline-block;border-radius:999px;padding:2px 8px;font-size:11px;font-weight:600;background:#f0f0f1;color:#3c434a;border:1px solid #dcdcde;}';
            echo '.pmcpc-premium-badge--active{background:#edfaef;color:#0a7a2f;border-color:#b8e6c1;}';
            echo '.pmcpc-premium-badge--draft,.pmcpc-premium-badge--needs-data{background:#fff8e5;color:#8a5a00;border-color:#efd38a;}';
            echo '.pmcpc-premium-badge--paused{background:#f6f7f7;color:#50575e;border-color:#dcdcde;}';
            echo '.pmcpc-premium-split{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px 12px;margin-top:10px;}';
            echo '.pmcpc-premium-stat-label{display:block;font-size:11px;color:#50575e;margin-bottom:1px;text-transform:uppercase;letter-spacing:.02em;}';
            echo '.pmcpc-premium-stat-value{display:block;font-size:15px;font-weight:600;color:#1d2327;line-height:1.25;}';
            echo '.pmcpc-premium-actions{margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;}';
            echo '.pmcpc-premium-review{margin-top:8px;padding-top:8px;border-top:1px solid #eef1f4;font-size:12px;color:#3c434a;line-height:1.45;}';
            echo '.pmcpc-premium-section-title{font-weight:600;margin:22px 0 8px;padding-bottom:6px;border-bottom:1px solid #e2e8ee;}';
            echo '.pmcpc-premium-compact-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:5px 12px;margin-top:10px;font-size:12px;color:#3c434a;}';
            echo '.pmcpc-premium-compact-stats strong{color:#1d2327;}';
            echo '.pmcpc-premium-card--trend{padding-bottom:8px;}';
            echo '@media (max-width:1380px){.pmcpc-premium-grid--automation{grid-template-columns:repeat(3,minmax(0,1fr));}}';
            echo '@media (max-width:1200px){.pmcpc-premium-grid--wide,.pmcpc-premium-grid--duo,.pmcpc-premium-grid--automation{grid-template-columns:1fr;}}';
            echo '@media (min-width:781px) and (max-width:1200px){.pmcpc-premium-grid--automation{grid-template-columns:repeat(2,minmax(0,1fr));}}';

            $header = array(
                'title'       => __( 'Overview', 'product-mailer-campaigns' ),
                'description' => __( 'See what is working, what needs attention, and what to do next.', 'product-mailer-campaigns' ),
            );
            $header_actions = array(
                array( 'label' => __( 'Create Campaign', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_campaigns&action=new' ), 'class' => 'button-primary' ),
                array( 'label' => __( 'Create Automation', 'product-mailer-campaigns' ), 'url' => add_query_arg( array( 'page' => 'pmcpc_campaigns', 'campaign_type' => 'automation', 'pmcpc_new' => '1', 'pmcpc_stage' => '2', 'step' => 'timing', 'stage' => 'timing', 'wizard_step' => 'timing', 'tab' => 'timing', 'view' => 'timing' ), admin_url( 'admin.php' ) ) ),
            );
            PMCPC_Admin::render_app_header( $header['title'], $header_actions );

            // One-click automation setup result.
            // Show once per user (so the dashboard feels "live" after onboarding).
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if ( isset( $_GET['pmcpc_setup_done'] ) ) {
                $seen_key = 'pmcpc_setup_done_seen_' . (int) get_current_user_id();
                if ( false !== get_transient( $seen_key ) ) {
                    // Already shown recently; skip rendering.
                } else {
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $created = isset( $_GET['pmcpc_created'] ) ? absint( $_GET['pmcpc_created'] ) : 0;
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $skipped = isset( $_GET['pmcpc_skipped'] ) ? absint( $_GET['pmcpc_skipped'] ) : 0;
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $errors  = isset( $_GET['pmcpc_setup_errors'] ) ? absint( $_GET['pmcpc_setup_errors'] ) : 0;

                $auto_url = admin_url( 'admin.php?page=pmcpc_automations' );
                echo '<div class="pmcpc-dashboard-callout pmcpc-dashboard-callout--success">';
                echo '<h2>' . esc_html__( 'Automations turned on', 'product-mailer-campaigns' ) . '</h2>';
                echo '<p style="margin:0 0 8px;">' . sprintf(
                    /* translators: 1: created, 2: skipped, 3: errors */
                    esc_html__( 'Created %1$d, skipped %2$d, errors %3$d.', 'product-mailer-campaigns' ),
                    (int) $created,
                    (int) $skipped,
                    (int) $errors
                ) . '</p>';
                echo '<p style="margin:0;">' . sprintf(
                    /* translators: %s: link to automations */
                    __( 'Next: review the timing and email copy in <a href="%s">Automations</a>.', 'product-mailer-campaigns' ),
                    esc_url( $auto_url )
                ) . '</p>';
                echo '</div>';

                    // Mark as seen for this user for a day.
                    set_transient( $seen_key, 1, DAY_IN_SECONDS );
                }
            }

            PMCPC_Admin::render_page_intro(
                $header['title'],
                $header['description'],
                array(
                    array( 'label' => sprintf( __( 'Updated: %s', 'product-mailer-campaigns' ), esc_html( $data['generated_at'] ) ), 'icon' => 'dashicons-clock' ),
                    array( 'label' => __( 'Quick status across your main areas', 'product-mailer-campaigns' ), 'icon' => 'dashicons-chart-area' ),
                )
            );
            $overview_detail_actions = array(
                array( 'label' => __( 'Campaign activity', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_dashboard#pmcpc-dashboard-group-campaign_operations' ), 'class' => 'button button-primary' ),
                array( 'label' => __( 'Automation status', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_dashboard#pmcpc-dashboard-group-automations_dashboard' ), 'class' => 'button' ),
                array( 'label' => __( 'Audience details', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_dashboard#pmcpc-dashboard-group-audience_intelligence' ), 'class' => 'button' ),
            );

            if ( ! $hide_paid_features && ! empty( $data['wc_active'] ) ) {
                array_unshift( $overview_detail_actions, array( 'label' => __( 'Sales details', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_dashboard#pmcpc-dashboard-group-store_revenue' ), 'class' => 'button' ) );
            }

            PMCPC_Admin::render_support_panels(
                array(
                    array(
                        'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-editor-help',
                        'title'   => __( 'Use Overview as your starting point', 'product-mailer-campaigns' ),
                        'items'   => array(
                            __( 'Check the status cards first.', 'product-mailer-campaigns' ),
                            __( 'Open the area that needs attention.', 'product-mailer-campaigns' ),
                            __( 'Use the page tools there to test and fix issues.', 'product-mailer-campaigns' ),
                        ),
                    ),
                    array(
                        'eyebrow' => __( 'Main areas', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-screenoptions',
                        'title'   => __( 'Open the part of FlowPress you want to work in', 'product-mailer-campaigns' ),
                        'text'    => __( 'Use Overview as your command centre, then jump into the area you need.', 'product-mailer-campaigns' ),
                        'actions' => array(
                            array( 'label' => __( 'Campaigns', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_campaigns' ), 'class' => 'button button-primary' ),
                            array( 'label' => __( 'Automations', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_automations' ), 'class' => 'button' ),
                            array( 'label' => __( 'Audience', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_subscribers' ), 'class' => 'button' ),
                            array( 'label' => __( 'Emails', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=queue' ), 'class' => 'button' ),
                            array( 'label' => __( 'Content', 'product-mailer-campaigns' ), 'url' => admin_url( 'edit.php?post_type=pmcpc_sub_update' ), 'class' => 'button' ),
                            array( 'label' => __( 'Health Check', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_diagnostics' ), 'class' => 'button' ),
                        ),
                    ),
                    array(
                        'eyebrow' => __( 'More detail', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-chart-bar',
                        'title'   => __( 'Open the deeper summaries on this page', 'product-mailer-campaigns' ),
                        'text'    => __( 'The old dashboard ideas are now folded into Overview. Use these links when you want more detail without leaving the main dashboard.', 'product-mailer-campaigns' ),
                        'actions' => $overview_detail_actions,
                    ),
                )
            );


            // Legacy dashboard block retained for reference but disabled to avoid duplicate sections.
            if ( false ) {

            // WooCommerce subscription features (grouped so it reads as one upsell story).
            $woo_wrap_open = false;
            if ( ! empty( $data['wc_active'] ) ) {
                $woo_wrap_open = true;
                echo '<div style="margin: 14px 0 18px;">';
                echo '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">';
                echo '<h2 style="margin:0;font-size:14px;">' . esc_html__( 'Revenue Automation (WooCommerce)', 'product-mailer-campaigns' ) . '</h2>';
                echo '<span style="display:inline-block;background:#f0f0f1;border:1px solid #dcdcde;border-radius:999px;padding:2px 8px;font-size:12px;color:#50575e;">' . esc_html__( 'Subscription features', 'product-mailer-campaigns' ) . '</span>';
                echo '</div>';
                echo '</div>';
                echo '<div class="pmcpc-woo-subscription">';

                // Opportunity headline: abandoned carts with contact (7d).
                $abandoned_7 = ! empty( $data['wc_abandoned_7'] ) ? (int) $data['wc_abandoned_7'] : 0;
                $abandoned_total_7 = ! empty( $data['wc_abandoned_total_7'] ) ? (float) $data['wc_abandoned_total_7'] : 0.0;
                $abandoned_total_7_display = function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $abandoned_total_7 ) ) : number_format_i18n( $abandoned_total_7, 2 );

                // Recoverable revenue callout (drives activation more clearly than a raw count).
                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);margin:0 0 16px;">';
                echo '<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">';
                echo '<div>';
                echo '<div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Recoverable revenue (7d)', 'product-mailer-campaigns' ) . '</div>';
                $automation_revenue_30 = ! empty( $data['wc_email_revenue_30'] ) ? (float) $data['wc_email_revenue_30'] : 0.0;
                $automation_orders_30  = ! empty( $data['wc_email_orders_30'] ) ? (int) $data['wc_email_orders_30'] : 0;
                echo '<div style="font-size:28px;font-weight:700;">' . esc_html( $abandoned_total_7_display ) . '</div>';
                echo '<div class="description" style="margin-top:6px;">' . sprintf(
                    /* translators: %d: abandoned carts count */
                    esc_html__( '%d abandoned carts with contact waiting to be recovered.', 'product-mailer-campaigns' ),
                    (int) $abandoned_7
                ) . '</div>';
                if ( $automation_revenue_30 > 0 || $automation_orders_30 > 0 ) {
                    echo '<div style="margin-top:12px;padding-top:12px;border-top:1px solid #f0f0f1;">';
                    echo '<div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Automation revenue (30d)', 'product-mailer-campaigns' ) . '</div>';
                    echo '<div style="font-size:24px;font-weight:700;line-height:1.15;">' . esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $automation_revenue_30 ) ) : number_format_i18n( $automation_revenue_30, 2 ) ) . '</div>';
                    echo '<div class="description" style="margin-top:6px;">' . sprintf(
                        /* translators: %d: attributed orders */
                        esc_html__( '%d orders attributed to email automations.', 'product-mailer-campaigns' ),
                        (int) $automation_orders_30
                    ) . '</div>';
                    echo '</div>';
                }
                echo '</div>';
                $automations_url_for_recovery = admin_url( 'admin.php?page=pmcpc_automations' );

                // Hide the CTA once abandoned cart recovery automations are already present.
                $abandoned_recovery_active = false;
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $ab_rows = $wpdb->get_results( "SELECT automation_trigger, status FROM {$campaigns_table} WHERE automation_trigger IN ('abandoned_cart_step_1','abandoned_cart_step_2','abandoned_cart_step_3')" );
                foreach ( (array) $ab_rows as $abr ) {
                    if ( ! empty( $abr->automation_trigger ) && 'active' === (string) $abr->status ) {
                        $abandoned_recovery_active = true;
                        break;
                    }
                }

                if ( ! $abandoned_recovery_active ) {
                    echo '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
                    echo '<a class="button button-primary" href="' . esc_url( $automations_url_for_recovery ) . '">' . esc_html__( 'Set up abandoned cart recovery', 'product-mailer-campaigns' ) . '</a>';
                    echo '</div>';
                }
                echo '</div>';
                echo '</div>';
            }

            // Automation coverage meter: silent guidance that drives activation.
    // Automation coverage meter: silent guidance that drives activation.
            // Core (WP-only) automations count towards coverage; WooCommerce automations only apply when WooCommerce is active.
            $has_wc_for_cov = ! empty( $data['wc_active'] );
            $wc_enabled_for_cov = ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() );

            // Determine which automation triggers already exist.
            $existing_triggers      = array();
            $review_request_active  = false;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $automation_rows = $wpdb->get_results( "SELECT automation_trigger, post_purchase_delay_minutes, trigger_delay_minutes, status FROM {$campaigns_table} WHERE automation_trigger IS NOT NULL AND automation_trigger != '' AND automation_trigger != 'none'" );
            foreach ( (array) $automation_rows as $r ) {
                $t = (string) $r->automation_trigger;
                $existing_triggers[ $t ] = true;
                // Review requests are now a dedicated trigger. Keep legacy fallback for older installs
                // that piggy-backed on post_purchase with a 7d+ delay.
                if ( 'review_request' === $t ) {
                    $review_request_active = true;
                } elseif ( 'post_purchase' === $t ) {
                    $legacy_delay = (int) ( isset( $r->trigger_delay_minutes ) ? $r->trigger_delay_minutes : 0 );
                    if ( $legacy_delay <= 0 ) {
                        $legacy_delay = (int) $r->post_purchase_delay_minutes;
                    }
                    if ( $legacy_delay >= 10080 ) {
                        $review_request_active = true;
                    }
                }
            }

            $checklist = array(
                'welcome' => array(
                    'label' => __( 'Welcome automation', 'product-mailer-campaigns' ),
                    'type'  => 'core',
                    'active'=> ! empty( $existing_triggers['welcome'] ),
                ),
            );

            if ( $has_wc_for_cov ) {
            
                $checklist['new_customer'] = array(
                    'label' => __( 'First order (new customer)', 'product-mailer-campaigns' ),
                    'type'  => 'woo',
                    'active'=> ! empty( $existing_triggers['new_customer'] ) && $wc_enabled_for_cov,
                    'locked'=> ! $wc_enabled_for_cov,
                );
                $checklist['repeat_customer'] = array(
                    'label' => __( 'Repeat customer (2+ orders)', 'product-mailer-campaigns' ),
                    'type'  => 'woo',
                    'active'=> ! empty( $existing_triggers['repeat_customer'] ) && $wc_enabled_for_cov,
                    'locked'=> ! $wc_enabled_for_cov,
                );
                $checklist['high_value'] = array(
                    'label' => __( 'High‑value customer', 'product-mailer-campaigns' ),
                    'type'  => 'woo',
                    'active'=> ( ! empty( $existing_triggers['high_value'] ) || ! empty( $existing_triggers['high_value_customer'] ) ) && $wc_enabled_for_cov,
                    'locked'=> ! $wc_enabled_for_cov,
                );
    $checklist['post_purchase'] = array(
                    'label' => __( 'Post‑purchase follow‑up', 'product-mailer-campaigns' ),
                    'type'  => 'woo',
                    'active'=> ! empty( $existing_triggers['post_purchase'] ) && $wc_enabled_for_cov,
                    'locked'=> ! $wc_enabled_for_cov,
                );
                $checklist['review_request'] = array(
                    'label' => __( 'Review request', 'product-mailer-campaigns' ),
                    'type'  => 'woo',
                    'active'=> $review_request_active && $wc_enabled_for_cov,
                    'locked'=> ! $wc_enabled_for_cov,
                );
                $checklist['customer_inactive'] = array(
                    'label' => __( 'Win‑back customers', 'product-mailer-campaigns' ),
                    'type'  => 'woo',
                    'active'=> ! empty( $existing_triggers['customer_inactive'] ) && $wc_enabled_for_cov,
                    'locked'=> ! $wc_enabled_for_cov,
                );
                // Abandoned cart recovery is a step-based sequence.
                // The recovery runner queues using triggers abandoned_cart_step_1/2/3.
                $abandoned_active = ( ! empty( $existing_triggers['abandoned_cart_step_1'] ) || ! empty( $existing_triggers['abandoned_cart_step_2'] ) || ! empty( $existing_triggers['abandoned_cart_step_3'] ) );
                $checklist['abandoned_cart'] = array(
                    'label' => __( 'Abandoned cart recovery', 'product-mailer-campaigns' ),
                    'type'  => 'woo',
                    'active'=> $abandoned_active && $wc_enabled_for_cov,
                    'locked'=> ! $wc_enabled_for_cov,
                );
            }

            $cov_total = count( $checklist );
            $cov_done  = 0;
            $cov_locked = 0;
            foreach ( $checklist as $key => $item ) {
                if ( ! empty( $item['active'] ) ) {
                    $cov_done++;
                }
                if ( ! empty( $item['locked'] ) ) {
                    $cov_locked++;
                }
            }
            $cov_pct = $cov_total ? (int) round( ( $cov_done / $cov_total ) * 100 ) : 0;

            $setup_url = admin_url( 'admin.php?page=pmcpc_automations' );
            $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
            $trial_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );

            echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);margin:0 0 16px;">';
            echo '<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">';
            echo '<div>';
            echo '<div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Store Automation Coverage', 'product-mailer-campaigns' ) . '</div>';
            $cov_remaining = max( 0, (int) $cov_total - (int) $cov_done );
            echo '<div style="font-size:28px;font-weight:700;">' . esc_html( $cov_pct ) . '%</div>';
            echo '<div class="description" style="margin-top:6px;">' . sprintf( esc_html__( '%1$d of %2$d recommended automations active.', 'product-mailer-campaigns' ), (int) $cov_done, (int) $cov_total ) . '</div>';
            if ( $cov_remaining > 0 ) {
                echo '<div class="description" style="margin-top:6px;">' . sprintf(
                    /* translators: %d: remaining automations */
                    esc_html__( '%d revenue automation remaining.', 'product-mailer-campaigns' ),
                    (int) $cov_remaining
                ) . '</div>';
            }
            if ( $cov_locked > 0 && $has_wc_for_cov && ! $wc_enabled_for_cov ) {
                echo '<div class="description" style="margin-top:6px;">' . sprintf( esc_html__( '+%d store automations available when WooCommerce Automation is enabled.', 'product-mailer-campaigns' ), (int) $cov_locked ) . '</div>';
            }
            echo '</div>';

            echo '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
            if ( $cov_remaining > 0 ) {
                echo '<a class="button button-primary" href="' . esc_url( $setup_url ) . '">' . esc_html__( 'Set up automations', 'product-mailer-campaigns' ) . '</a>';
            }
            echo '<a class="button" href="' . esc_url( add_query_arg( array( 'page' => 'pmcpc_campaigns', 'view' => 'automation' ), admin_url( 'admin.php' ) ) ) . '">' . esc_html__( 'View automations', 'product-mailer-campaigns' ) . '</a>';
            if ( $has_wc_for_cov && ! $wc_enabled_for_cov ) {
                echo '<a class="button" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Enable WooCommerce automation (trial)', 'product-mailer-campaigns' ) . '</a>';
            }
            echo '</div>';
            echo '</div>';

            echo '<div style="margin-top:10px;display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px;">';
            foreach ( $checklist as $key => $item ) {
                $icon = '⬜';
                if ( ! empty( $item['active'] ) ) {
                    $icon = '✅';
                } elseif ( ! empty( $item['locked'] ) ) {
                    $icon = '⭐';
                }
                $focus_map = array(
                    'welcome'          => 'new_subscriber',
                    'new_customer'     => 'new_customer',
                    'post_purchase'    => 'post_purchase',
                    'review_request'   => 'review_request',
                    'repeat_customer'  => 'repeat_customer',
                    'high_value'       => 'high_value',
                    'customer_inactive'=> 'customer_inactive',
                    'abandoned_cart'   => 'abandoned_cart_step_1',
                );
                $focus = isset( $focus_map[ $key ] ) ? $focus_map[ $key ] : '';
                $link  = $focus ? add_query_arg( array( 'page' => 'pmcpc_automations', 'focus' => $focus ), admin_url( 'admin.php' ) ) : admin_url( 'admin.php?page=pmcpc_automations' );

                echo '<a href="' . esc_url( $link ) . '" style="text-decoration:none;color:inherit;display:block;background:#f6f7f7;border:1px solid #dcdcde;border-radius:6px;padding:10px 12px;">';
                echo '<div style="display:flex;gap:8px;align-items:center;">';
                echo '<span>' . esc_html( $icon ) . '</span>';
                echo '<span style="font-weight:600;">' . esc_html( $item['label'] ) . '</span>';
                echo '</div>';
            }
            echo '</div>';

            if ( $has_wc_for_cov && ! $wc_enabled_for_cov ) {
                echo '<div style="margin-top:10px;">';
                echo '<a href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Learn what WooCommerce Automation unlocks', 'product-mailer-campaigns' ) . '</a>';
                echo '</div>';
            }

            // Next best action (lightweight coaching).
            if ( $has_wc_for_cov ) {
                $next_action_title = '';
                $next_action_body  = '';
                $next_action_cta   = '';

                $abandoned_item = isset( $checklist['abandoned_cart'] ) ? $checklist['abandoned_cart'] : null;

                if ( is_array( $abandoned_item ) && ! empty( $abandoned_item['locked'] ) ) {
                    $next_action_title = esc_html__( 'Next step for your store', 'product-mailer-campaigns' );
                    $next_action_body  = esc_html__( 'Enable WooCommerce Automation to unlock abandoned cart recovery and other revenue automations.', 'product-mailer-campaigns' );
                    $next_action_cta   = '<a class="button" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Enable trial', 'product-mailer-campaigns' ) . '</a>';
                } elseif ( is_array( $abandoned_item ) && empty( $abandoned_item['active'] ) ) {
                    $next_action_title = esc_html__( 'Next step for your store', 'product-mailer-campaigns' );
                    $next_action_body  = esc_html__( 'Activate abandoned cart recovery to automatically follow up and recover lost sales.', 'product-mailer-campaigns' );
                    $next_action_cta   = '<a class="button button-primary" href="' . esc_url( $setup_url ) . '">' . esc_html__( 'Activate missing automations', 'product-mailer-campaigns' ) . '</a>';
                } elseif ( $cov_remaining > 0 ) {
                    $next_action_title = esc_html__( 'Next step for your store', 'product-mailer-campaigns' );
                    $next_action_body  = esc_html__( 'You are close to full automation coverage. Activate the remaining automations to maximise revenue capture.', 'product-mailer-campaigns' );
                    $next_action_cta   = '<a class="button button-primary" href="' . esc_url( $setup_url ) . '">' . esc_html__( 'Activate missing automations', 'product-mailer-campaigns' ) . '</a>';
                }

                if ( '' !== $next_action_title ) {
                    echo '<div style="margin-top:12px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:8px;padding:12px 14px;">';
                    echo '<div style="font-weight:600;margin-bottom:4px;">' . $next_action_title . '</div>';
                    echo '<div class="description" style="margin:0 0 10px;">' . $next_action_body . '</div>';
                    if ( '' !== $next_action_cta ) {
                        echo $next_action_cta; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from safe URLs + translations.
                    }
                    echo '</div>';
                }
            }

            echo '</div>';


    // WooCommerce upsell: show "money on the table" signals when WooCommerce is active and premium is locked.
    $has_wc = ! empty( $data['wc_active'] );
    $premium_wc_locked = $has_wc && ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() );

    if ( $premium_wc_locked && ! $hide_paid_features ) {
        $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
    	$trial_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );
        echo '<div class="pmcpc-dashboard-callout pmcpc-dashboard-callout--info" style="border-left-color:#6f42c1;">';
        echo '<h2>' . esc_html__( 'WooCommerce detected — unlock automated revenue emails', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p style="margin:0 0 10px;">' . esc_html__( 'You can automate post‑purchase follow‑ups and win‑back campaigns without leaving WordPress.', 'product-mailer-campaigns' ) . '</p>';
        echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin:10px 0 12px;">';
        echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:10px 12px;"><div style="font-size:12px;color:#50575e;">' . esc_html__( 'Orders in the last 30 days', 'product-mailer-campaigns' ) . '</div><div style="font-size:22px;font-weight:700;">' . esc_html( (int) $data['wc_orders_30'] ) . '</div><div style="font-size:12px;color:#50575e;">' . esc_html__( 'Eligible for post‑purchase follow‑ups', 'product-mailer-campaigns' ) . '</div></div>';
        echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:10px 12px;"><div style="font-size:12px;color:#50575e;">' . esc_html__( 'Customers to win back', 'product-mailer-campaigns' ) . '</div><div style="font-size:22px;font-weight:700;">' . esc_html( (int) $data['wc_customers_winback'] ) . '</div><div style="font-size:12px;color:#50575e;">' . esc_html__( 'No orders in the last 90 days', 'product-mailer-campaigns' ) . '</div></div>';
        echo '</div>';
        echo '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
    	echo '<a class="button button-primary" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Start free trial', 'product-mailer-campaigns' ) . '</a>';
    	echo '<a class="button" href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Activate license', 'product-mailer-campaigns' ) . '</a>';
        echo '</div>';
        echo '</div>';
    }

            // WooCommerce metrics (supporting KPIs).
            if ( ! empty( $data['wc_active'] ) ) {
                $sparkline = function ( $series, $max_value ) {
                    if ( ! is_array( $series ) || empty( $series ) ) {
                        return '';
                    }
                    $w = 140;
                    $h = 34;
                    $pad = 2;
                    $max = (float) $max_value;
                    if ( $max <= 0 ) {
                        $max = 1;
                    }
                    $n = count( $series );
                    if ( $n < 2 ) {
                        return '';
                    }
                    $step = ( $w - ( 2 * $pad ) ) / ( $n - 1 );
                    $points = array();
                    foreach ( $series as $i => $v ) {
                        $x = $pad + ( $i * $step );
                        $y = $h - $pad - ( ( (float) $v / $max ) * ( $h - ( 2 * $pad ) ) );
                        $points[] = round( $x, 1 ) . ',' . round( $y, 1 );
                    }
                    $poly = implode( ' ', $points );
                    return '<svg width="' . (int) $w . '" height="' . (int) $h . '" viewBox="0 0 ' . (int) $w . ' ' . (int) $h . '" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">'
                        . '<polyline fill="none" stroke="currentColor" stroke-width="2" points="' . esc_attr( $poly ) . '" />'
                        . '</svg>';
                };

                echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin:0 0 16px;">';

                $wc_orders_30  = ! empty( $data['wc_orders_30'] ) ? (int) $data['wc_orders_30'] : 0;
                $wc_revenue_30 = ! empty( $data['wc_revenue_30'] ) ? (float) $data['wc_revenue_30'] : 0.0;
                $wc_aov_30     = ! empty( $data['wc_aov_30'] ) ? (float) $data['wc_aov_30'] : 0.0;
                $growth_score  = ! empty( $data['growth_score'] ) ? (int) $data['growth_score'] : 0;
                $rev_series_14 = ! empty( $data['wc_revenue_series_14'] ) && is_array( $data['wc_revenue_series_14'] ) ? $data['wc_revenue_series_14'] : array();
                $rev_series_14_max = ! empty( $data['wc_revenue_series_14_max'] ) ? (float) $data['wc_revenue_series_14_max'] : 0.0;

                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;">';
                echo '<div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Orders (30d)', 'product-mailer-campaigns' ) . '</div>';
                echo '<div style="font-size:28px;line-height:1.1;font-weight:600;color:#1d2327;">' . esc_html( $wc_orders_30 ) . '</div>';
                echo '</div>';

                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;">';
                echo '<div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Revenue (30d)', 'product-mailer-campaigns' ) . '</div>';
                echo '<div style="font-size:28px;line-height:1.1;font-weight:600;color:#1d2327;">' . esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $wc_revenue_30 ) ) : number_format_i18n( $wc_revenue_30, 2 ) ) . '</div>';
                echo '</div>';

                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;">';
                echo '<div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Average order value', 'product-mailer-campaigns' ) . '</div>';
                echo '<div style="font-size:28px;line-height:1.1;font-weight:600;color:#1d2327;">' . esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $wc_aov_30 ) ) : number_format_i18n( $wc_aov_30, 2 ) ) . '</div>';
                echo '</div>';

                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;">';
                echo '<div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Automation health score', 'product-mailer-campaigns' ) . '</div>';
                echo '<div style="display:flex;align-items:baseline;gap:10px;">';
                echo '<div style="font-size:28px;line-height:1.1;font-weight:700;color:#1d2327;">' . esc_html( $growth_score ) . '</div>';
                echo '<div class="description" style="margin:0;">/ 100</div>';
                echo '</div>';
                echo '<div class="description" style="margin-top:6px;">' . esc_html__( 'Based on automations, deliverability, and engagement.', 'product-mailer-campaigns' ) . '</div>';
                echo '</div>';

                echo '</div>';

                // Secondary WooCommerce insights: revenue trend + projected recoverable revenue.
                $abandoned_total_7 = ! empty( $data['wc_abandoned_total_7'] ) ? (float) $data['wc_abandoned_total_7'] : 0.0;
                $projected_30 = $abandoned_total_7 > 0 ? ( $abandoned_total_7 * ( 30 / 7 ) ) : 0.0;
                echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px;margin:0 0 16px;">';

                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;">';
                echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">';
                echo '<div style="font-size:13px;color:#50575e;">' . esc_html__( 'Revenue trend', 'product-mailer-campaigns' ) . '</div>';
                $svg = $sparkline( $rev_series_14, $rev_series_14_max );
                if ( '' !== $svg ) {
                    echo '<div style="opacity:.8;">' . $svg . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                }
                echo '</div>';
                echo '<div class="description" style="margin-top:8px;">' . esc_html__( 'Last 14 days.', 'product-mailer-campaigns' ) . '</div>';
                echo '</div>';

                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;">';
                echo '<div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Projected recoverable (30d)', 'product-mailer-campaigns' ) . '</div>';
                echo '<div style="font-size:28px;line-height:1.1;font-weight:700;color:#1d2327;">' . esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $projected_30 ) ) : number_format_i18n( $projected_30, 2 ) ) . '</div>';
                echo '<div class="description" style="margin-top:6px;">' . esc_html__( 'Directional estimate based on the last 7 days of abandoned carts with contact.', 'product-mailer-campaigns' ) . '</div>';
                echo '</div>';

                echo '</div>';

                if ( $woo_wrap_open ) {
                    echo '</div>'; // end WooCommerce subscription features
                }
            }


            }

    // Attention needed alerts.

    $alerts = array();

    $spam_held_threshold = (int) apply_filters( 'pmcpc_dashboard_spam_held_threshold', 1 );
    if ( ! empty( $data['spam_held'] ) && (int) $data['spam_held'] >= $spam_held_threshold ) {
        $alerts[] = array(
            'type' => 'warning',
            'text' => sprintf(
                /* translators: %d: count. */
                __( 'You have %d submissions held for review.', 'product-mailer-campaigns' ),
                (int) $data['spam_held']
            ),
            'link' => admin_url( 'admin.php?page=pmcpc_inbox&pmcpc_status=held' ),
            'cta'  => __( 'Review held', 'product-mailer-campaigns' ),
        );
    }

    if ( ! empty( $data['queue_failed'] ) ) {
        $alerts[] = array(
            'type' => 'error',
            'text' => sprintf(
                /* translators: %d: count. */
                __( 'Email queue has %d failed items.', 'product-mailer-campaigns' ),
                (int) $data['queue_failed']
            ),
            'link' => admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=queue&queue_status=failed' ),
            'cta'  => __( 'View failed queue', 'product-mailer-campaigns' ),
        );
    }

    $now_ts = time();
    $next_q = isset( $data['next_queue_run'] ) ? (int) $data['next_queue_run'] : 0;
    $next_c = isset( $data['next_campaign_run'] ) ? (int) $data['next_campaign_run'] : 0;

    if ( empty( $next_q ) ) {
        $alerts[] = array(
            'type' => 'error',
            'text' => __( 'WP-Cron queue task is not scheduled. Automated sending may not run.', 'product-mailer-campaigns' ),
            'link' => admin_url( 'admin.php?page=pmcpc_settings&tab=advanced' ),
            'cta'  => __( 'Open Advanced settings', 'product-mailer-campaigns' ),
        );
    } elseif ( $next_q < ( $now_ts - 600 ) ) {
        $alerts[] = array(
            'type' => 'warning',
            'text' => sprintf(
                /* translators: %s: scheduled time. */
                __( 'Queue processing looks behind schedule (next run was %s).', 'product-mailer-campaigns' ),
                date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $next_q )
            ),
            'link' => admin_url( 'admin.php?page=pmcpc_dashboard' ),
            'cta'  => __( 'Refresh dashboard', 'product-mailer-campaigns' ),
        );
    }

    if ( empty( $next_c ) ) {
        $alerts[] = array(
            'type' => 'warning',
            'text' => __( 'Scheduled campaigns task is not scheduled. Future campaigns may not run automatically.', 'product-mailer-campaigns' ),
            'link' => admin_url( 'admin.php?page=pmcpc_settings&tab=advanced' ),
            'cta'  => __( 'Open Advanced settings', 'product-mailer-campaigns' ),
        );
    }


    // Render a lightweight health summary. Actionable alerts live in Notification Center.
    $checks_time = date_i18n( 'Y-m-d H:i', time() );
    // Avoid PHP 8.1+ deprecation notices if REQUEST_URI is missing in some environments.
    $current_uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( (string) wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
    $refresh_url = add_query_arg( array( 'pmcpc_refresh_checks' => '1' ), $current_uri );

    self::pmcpc_dashboard_section_open( 'status_checks', __( 'Status & checks', 'product-mailer-campaigns' ), __( 'Hide or show the dashboard status panel.', 'product-mailer-campaigns' ) );
    // Avoid using the core ``notice`` class here.
    // Some admin themes/plugins attach global JS to `.notice` elements, which can make
    // these dashboard callouts unexpectedly disappear.
    echo '<div class="pmcpc-dashboard-callout ' . ( ! empty( $alerts ) ? 'pmcpc-dashboard-callout--warning' : 'pmcpc-dashboard-callout--success' ) . '" style="margin: 0 0 18px;padding: 10px 12px;">';
    echo '<p style="margin:0;display:flex;align-items:center;gap:10px;justify-content:space-between;">';
    $status_label = empty( $alerts ) ? __( 'Status: All good', 'product-mailer-campaigns' ) : __( 'Status: Notifications active', 'product-mailer-campaigns' );
    echo '<strong>' . esc_html( $status_label ) . '</strong>';
    /* translators: %s: date/time when checks were last run. */
    echo '<span style="font-size:12px;opacity:.8;">' . esc_html( sprintf( __( 'Last checked: %s', 'product-mailer-campaigns' ), $checks_time ) ) . ' &middot; <a href="' . esc_url( $refresh_url ) . '">' . esc_html__( 'Refresh checks', 'product-mailer-campaigns' ) . '</a></span>';
    echo '</p>';
    echo '<p style="margin:8px 0 0;">' . esc_html__( 'Use Notification Center above for actionable alerts and direct links.', 'product-mailer-campaigns' ) . '</p>';
    echo '</div>';
    self::pmcpc_dashboard_section_close();

            self::render_dashboard_premium_overview( $data );
            self::render_dashboard_recent_activity_summary_section( $data );
            if ( ! $hide_paid_features && ! empty( $data['wc_active'] ) ) {
                self::render_dashboard_store_revenue_workspace_section( $data );
            }
            self::render_dashboard_campaign_operations_section( $data );
            self::render_dashboard_automations_section( $data );
            self::render_dashboard_audience_intelligence_section( $data );

            echo '</div>'; // wrap
        }


        protected static function render_dashboard_audience_intelligence_section( $data ) {
            self::pmcpc_dashboard_section_open( 'audience_intelligence', __( 'Audience Intelligence', 'product-mailer-campaigns' ), __( 'Source and lifecycle insights for your audience.', 'product-mailer-campaigns' ) );
            echo '<div class="pmcpc-premium-card" style="margin-bottom:16px;">';
            echo '<h3>' . esc_html__( '🧠 Audience Intelligence', 'product-mailer-campaigns' ) . '</h3>';
            echo '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;">';
            echo '<div>';
            echo '<div class="pmcpc-premium-meta" style="margin-bottom:8px;">' . esc_html__( 'Top acquisition sources', 'product-mailer-campaigns' ) . '</div>';
            if ( empty( $data['top_sources'] ) ) {
                echo '<p class="pmcpc-premium-meta">' . esc_html__( 'No source tags found yet.', 'product-mailer-campaigns' ) . '</p>';
            } else {
                echo '<table class="widefat" style="margin:0;">';
                echo '<thead><tr><th>' . esc_html__( 'Source tag', 'product-mailer-campaigns' ) . '</th><th style="width:120px;">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
                foreach ( $data['top_sources'] as $row ) {
                    $tag = isset( $row['tag'] ) ? (string) $row['tag'] : '';
                    $cnt = isset( $row['cnt'] ) ? (int) $row['cnt'] : 0;
                    $url = admin_url( 'admin.php?page=pmcpc_subscribers&pmcpc_source=' . rawurlencode( $tag ) );
                    echo '<tr><td><a href="' . esc_url( $url ) . '"><code>' . esc_html( $tag ) . '</code></a></td><td><strong>' . esc_html( $cnt ) . '</strong></td></tr>';
                }
                echo '</tbody></table>';
            }
            echo '</div>';
            echo '<div>';
            echo '<div class="pmcpc-premium-meta" style="margin-bottom:8px;">' . esc_html__( 'Customer lifecycle segments', 'product-mailer-campaigns' ) . '</div>';
            if ( empty( $data['lifecycle_counts'] ) ) {
                echo '<p class="pmcpc-premium-meta">' . esc_html__( 'No lifecycle tags applied yet.', 'product-mailer-campaigns' ) . '</p>';
            } else {
                echo '<table class="widefat" style="margin:0;">';
                echo '<thead><tr><th>' . esc_html__( 'Lifecycle tag', 'product-mailer-campaigns' ) . '</th><th style="width:120px;">' . esc_html__( 'Subscribers', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
                foreach ( $data['lifecycle_counts'] as $tag => $cnt ) {
                    $url = admin_url( 'admin.php?page=pmcpc_subscribers&pmcpc_lifecycle=' . rawurlencode( (string) $tag ) );
                    echo '<tr><td><a href="' . esc_url( $url ) . '"><code>' . esc_html( (string) $tag ) . '</code></a></td><td><strong>' . esc_html( (int) $cnt ) . '</strong></td></tr>';
                }
                echo '</tbody></table>';
            }
            echo '</div>';
            echo '</div>';
            echo '</div>';
            self::pmcpc_dashboard_section_close();
        }


        protected static function render_dashboard_campaign_operations_section( $data ) {
            self::pmcpc_dashboard_section_open( 'campaign_operations', __( 'Campaign Operations', 'product-mailer-campaigns' ), __( 'Upcoming campaign activity and recent delivery activity.', 'product-mailer-campaigns' ) );
            echo '<div class="pmcpc-premium-grid pmcpc-premium-grid--wide" style="grid-template-columns:minmax(520px,1.3fr) minmax(340px,1fr);margin-bottom:16px;">';
            echo '<div class="pmcpc-premium-card">';
            echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">';
            echo '<h3>' . esc_html__( '🗓️ Latest Campaigns', 'product-mailer-campaigns' ) . '</h3>';
            echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_campaigns' ) ) . '">' . esc_html__( 'View all', 'product-mailer-campaigns' ) . '</a>';
            echo '</div>';
            if ( empty( $data['latest_campaigns'] ) ) {
                echo '<p class="pmcpc-premium-meta">' . esc_html__( 'No campaigns yet.', 'product-mailer-campaigns' ) . '</p>';
            } else {
                echo '<table class="widefat striped" style="margin-top:10px;">';
                echo '<thead><tr><th>' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th><th style="width:120px;">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th><th style="width:160px;">' . esc_html__( 'Next run', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
                foreach ( $data['latest_campaigns'] as $row ) {
                    $campaign_url = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . (int) $row->id );
                    $status = ! empty( $row->status ) ? (string) $row->status : '—';
                    $next_run = ! empty( $row->next_run_at ) ? self::pmcpc_dashboard_format_mysql_value( $row->next_run_at ) : '—';
                    echo '<tr><td><a href="' . esc_url( $campaign_url ) . '">' . esc_html( (string) $row->name ) . '</a></td><td>' . esc_html( ucfirst( $status ) ) . '</td><td>' . esc_html( $next_run ) . '</td></tr>';
                }
                echo '</tbody></table>';
            }
            echo '</div>';
            echo '<div class="pmcpc-premium-card">';
            echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">';
            echo '<h3>' . esc_html__( '🕒 Latest Activity', 'product-mailer-campaigns' ) . '</h3>';
            echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=history' ) ) . '">' . esc_html__( 'View full activity', 'product-mailer-campaigns' ) . '</a>';
            echo '</div>';
            if ( ! empty( $data['recent_activity'] ) && is_array( $data['recent_activity'] ) ) {
                echo '<div class="pmcpc-activity-feed">';
                $shown = 0;
                foreach ( $data['recent_activity'] as $activity ) {
                    if ( $shown >= 8 ) {
                        break;
                    }
                    $title = ! empty( $activity['title'] ) ? (string) $activity['title'] : __( 'Activity', 'product-mailer-campaigns' );
                    $email = ! empty( $activity['email'] ) ? self::pmcpc_dashboard_mask_email( (string) $activity['email'] ) : '';
                    $status = ! empty( $activity['status'] ) ? self::pmcpc_dashboard_format_activity_status( (string) $activity['status'] ) : '';
                    $time = ! empty( $activity['activity_at'] ) ? self::pmcpc_dashboard_format_mysql_value( (string) $activity['activity_at'] ) : '';
                    $icon = ! empty( $activity['icon'] ) ? (string) $activity['icon'] : '•';
                    echo '<div class="pmcpc-activity-item">';
                    echo '<div class="pmcpc-activity-icon" aria-hidden="true">' . esc_html( $icon ) . '</div>';
                    echo '<div>';
                    echo '<div class="pmcpc-activity-title">' . esc_html( $title ) . '</div>';
                    if ( ! empty( $email ) ) {
                        echo '<div class="pmcpc-activity-sub">' . esc_html( $email ) . '</div>';
                    }
                    $meta_parts = array();
                    if ( ! empty( $status ) ) {
                        $meta_parts[] = $status;
                    }
                    if ( ! empty( $time ) ) {
                        $meta_parts[] = $time;
                    }
                    if ( ! empty( $meta_parts ) ) {
                        echo '<div class="pmcpc-activity-sub">' . esc_html( implode( ' • ', $meta_parts ) ) . '</div>';
                    }
                    if ( ! empty( $activity['detail'] ) ) {
                        echo '<div class="pmcpc-activity-sub">' . esc_html( (string) $activity['detail'] ) . '</div>';
                    }
                    echo '</div>';
                    echo '</div>';
                    $shown++;
                }
                echo '</div>';
            } else {
                echo '<p class="pmcpc-premium-meta">' . esc_html__( 'No recent activity yet. Queue, sent, and scheduled campaign events will appear here automatically.', 'product-mailer-campaigns' ) . '</p>';
            }
            echo '</div>';
            echo '</div>';
            self::pmcpc_dashboard_section_close();
        }



        protected static function render_dashboard_automations_section( $data ) {
            $hide_paid_features = function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features();

            self::pmcpc_dashboard_section_open( 'automations_dashboard', __( 'Automation Performance', 'product-mailer-campaigns' ), __( 'Grouped workflow health, trigger coverage, and recent automation activity.', 'product-mailer-campaigns' ) );

            echo '<div class="pmcpc-premium-grid" style="margin-bottom:16px;grid-template-columns:repeat(4,minmax(180px,1fr));">';
            $summary_cards = array(
                array(
                    'label' => __( 'Automation health', 'product-mailer-campaigns' ),
                    'value' => sprintf( '%d / 100', (int) $data['growth_score'] ),
                    'meta'  => __( 'Coverage and delivery health score.', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Active / scheduled', 'product-mailer-campaigns' ),
                    'value' => number_format_i18n( (int) $data['active_like_count'] ),
                    'meta'  => __( 'Workflows currently live or scheduled.', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Needs setup', 'product-mailer-campaigns' ),
                    'value' => number_format_i18n( (int) $data['needs_setup_count'] ),
                    'meta'  => __( 'Workflow templates waiting for configuration.', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Inactive / not created', 'product-mailer-campaigns' ),
                    'value' => number_format_i18n( (int) $data['inactive_count'] + (int) $data['not_created_count'] ),
                    'meta'  => __( 'Workflows not currently sending.', 'product-mailer-campaigns' ),
                ),
            );
            foreach ( $summary_cards as $summary_card ) {
                echo '<div class="pmcpc-premium-card">';
                echo '<div class="pmcpc-premium-stat-label">' . esc_html( $summary_card['label'] ) . '</div>';
                echo '<div class="pmcpc-premium-kpi">' . esc_html( $summary_card['value'] ) . '</div>';
                echo '<div class="pmcpc-premium-meta">' . esc_html( $summary_card['meta'] ) . '</div>';
                echo '</div>';
            }
            echo '</div>';

            $pmcpc_insight_cards = array();
            $pmcpc_workflow_cards_for_insights = ( ! empty( $data['workflow_cards'] ) && is_array( $data['workflow_cards'] ) ) ? $data['workflow_cards'] : array();
            if ( ! empty( $data['queue_failures_today'] ) ) {
                $pmcpc_insight_cards[] = array( 'icon' => '⚠️', 'title' => __( 'Queue needs attention', 'product-mailer-campaigns' ), 'text' => sprintf( __( '%d queue failures were recorded today. Check the queue before relying on automation sends.', 'product-mailer-campaigns' ), (int) $data['queue_failures_today'] ), 'url' => admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=queue' ), 'button' => __( 'Open queue', 'product-mailer-campaigns' ) );
            }
            if ( ! empty( $pmcpc_workflow_cards_for_insights ) ) {
                $pmcpc_sent_workflows = array_filter( $pmcpc_workflow_cards_for_insights, function( $card ) { return ! empty( $card['sent_30'] ); } );
                if ( ! empty( $pmcpc_sent_workflows ) ) {
                    usort( $pmcpc_sent_workflows, function( $a, $b ) {
                        $a_rate = is_null( $a['open_rate_30'] ) ? -1 : (float) $a['open_rate_30'];
                        $b_rate = is_null( $b['open_rate_30'] ) ? -1 : (float) $b['open_rate_30'];
                        return $b_rate <=> $a_rate;
                    } );
                    $pmcpc_top = reset( $pmcpc_sent_workflows );
                    if ( ! empty( $pmcpc_top['label'] ) ) {
                        $pmcpc_insight_cards[] = array( 'icon' => '📈', 'title' => __( 'Top performing workflow', 'product-mailer-campaigns' ), 'text' => sprintf( __( '%1$s is leading performance with a %2$s open rate and %3$s click rate over the last 30 days.', 'product-mailer-campaigns' ), (string) $pmcpc_top['label'], is_null( $pmcpc_top['open_rate_30'] ) ? '—' : number_format_i18n( (float) $pmcpc_top['open_rate_30'], 1 ) . '%', is_null( $pmcpc_top['click_rate_30'] ) ? '—' : number_format_i18n( (float) $pmcpc_top['click_rate_30'], 1 ) . '%' ), 'url' => admin_url( 'admin.php?page=pmcpc_campaigns' ), 'button' => __( 'Open campaigns', 'product-mailer-campaigns' ) );
                    }
                }
                $pmcpc_dormant = array_filter( $pmcpc_workflow_cards_for_insights, function( $card ) { return empty( $card['sent_30'] ) && ! empty( $card['status'] ) && 'active' === sanitize_key( (string) $card['status'] ); } );
                if ( ! empty( $pmcpc_dormant ) ) {
                    $pmcpc_dormant = reset( $pmcpc_dormant );
                    $pmcpc_insight_cards[] = array( 'icon' => '🟡', 'title' => __( 'Active but quiet', 'product-mailer-campaigns' ), 'text' => sprintf( __( '%s is active but has not sent in the last 30 days. Confirm the trigger and audience rules are correct.', 'product-mailer-campaigns' ), (string) $pmcpc_dormant['label'] ), 'url' => admin_url( 'admin.php?page=pmcpc_automations' ), 'button' => __( 'Check automations', 'product-mailer-campaigns' ) );
                }
            }
            if ( empty( $pmcpc_workflow_cards_for_insights ) ) {
                $pmcpc_insight_cards[] = array( 'icon' => '🚀', 'title' => __( 'Create your first workflow', 'product-mailer-campaigns' ), 'text' => __( 'Start with a welcome series or abandoned cart workflow to begin tracking automation performance.', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_automations' ), 'button' => __( 'Open automations', 'product-mailer-campaigns' ) );
            }
            if ( ! empty( $pmcpc_insight_cards ) ) {
                echo '<div class="pmcpc-premium-card" style="margin-bottom:18px;">';
                echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;">';
                echo '<div><h3>' . esc_html__( 'Insights & Recommendations', 'product-mailer-campaigns' ) . '</h3>';
                echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Quick guidance based on workflow activity, delivery health, and recent performance.', 'product-mailer-campaigns' ) . '</div></div>';
                echo '</div>';
                echo '<div class="pmcpc-premium-grid" style="grid-template-columns:repeat(3,minmax(220px,1fr));">';
                foreach ( array_slice( $pmcpc_insight_cards, 0, 3 ) as $pmcpc_insight ) {
                    echo '<div class="pmcpc-premium-card">';
                    echo '<h4>' . esc_html( (string) $pmcpc_insight['icon'] . ' ' . (string) $pmcpc_insight['title'] ) . '</h4>';
                    echo '<p class="pmcpc-premium-meta" style="margin-top:6px;">' . esc_html( (string) $pmcpc_insight['text'] ) . '</p>';
                    if ( ! empty( $pmcpc_insight['url'] ) ) {
                        echo '<div class="pmcpc-premium-actions" style="margin-top:10px;"><a class="button" href="' . esc_url( $pmcpc_insight['url'] ) . '">' . esc_html( (string) $pmcpc_insight['button'] ) . '</a></div>';
                    }
                    echo '</div>';
                }
                echo '</div>';
                echo '</div>';
            }

            if ( ! empty( $data['core_automation_group_cards'] ) && is_array( $data['core_automation_group_cards'] ) ) {
                $coverage_groups = $data['core_automation_group_cards'];
                $core_groups = array();
                $woocommerce_groups = array();
                $scheduled_groups = array();

                foreach ( $coverage_groups as $group_key => $group_bundle ) {
                    if ( 'customer' === (string) $group_key ) {
                        $woocommerce_groups[ $group_key ] = $group_bundle;
                    } elseif ( 'scheduled' === (string) $group_key ) {
                        $scheduled_groups[ $group_key ] = $group_bundle;
                    } else {
                        $core_groups[ $group_key ] = $group_bundle;
                    }
                }

                $pmcpc_woo_workflow_triggers = array(
                    'abandoned_cart_recovery',
                    'abandoned_cart_step_1',
                    'abandoned_cart_step_2',
                    'abandoned_cart_step_3',
                    'first_order',
                    'firstorder',
                    'new_customer',
                    'newcustomer',
                    'repeat_customer',
                    'repeat_customer_2plus',
                    'review_request',
                    'reviewrequest',
                    'high_value',
                    'high_value_customer',
                    'highvaluecustomer',
                    'lapsed_high_value_customer',
                    'lapsed_high_value',
                    'lapsedhighvalue',
                    'lapsedhighvaluecustomer',
                    'vip_customer',
                    'vipcustomer',
                    'customer_inactive',
                    'customerinactive',
                    'order_completed',
                    'post_purchase',
                    'postpurchase',
                    'post_purchase_sequence',
                    'postpurchasefollowupsequence',
                    'winback',
                    'win_back',
                    'customer_winback',
                    'customerwinback',
                    'inactive_customer',
                );
                $core_workflow_cards = array();
                $woocommerce_workflow_cards = array();
                $scheduled_workflow_cards = array();
                $core_workflow_triggers = array();
                $woocommerce_workflow_triggers = array();
                $scheduled_workflow_triggers = array();
                $workflow_cards_for_sections = ( ! empty( $data['workflow_cards'] ) && is_array( $data['workflow_cards'] ) ) ? $data['workflow_cards'] : array();
                foreach ( $workflow_cards_for_sections as $workflow_card ) {
                    $workflow_trigger = isset( $workflow_card['trigger'] ) ? sanitize_key( (string) $workflow_card['trigger'] ) : '';
                    $workflow_key     = isset( $workflow_card['workflow_key'] ) ? sanitize_key( (string) $workflow_card['workflow_key'] ) : '';
                    $workflow_label_key = isset( $workflow_card['label'] ) ? sanitize_key( (string) $workflow_card['label'] ) : '';
                    $workflow_search_key = $workflow_key . ' ' . $workflow_trigger . ' ' . $workflow_label_key;
                    $is_woocommerce_workflow = in_array( $workflow_trigger, $pmcpc_woo_workflow_triggers, true )
                        || false !== strpos( $workflow_search_key, 'abandonedcart' )
                        || false !== strpos( $workflow_search_key, 'abandoned_cart' )
                        || false !== strpos( $workflow_search_key, 'postpurchase' )
                        || false !== strpos( $workflow_search_key, 'post_purchase' )
                        || false !== strpos( $workflow_search_key, 'firstorder' )
                        || false !== strpos( $workflow_search_key, 'first_order' )
                        || false !== strpos( $workflow_search_key, 'repeatcustomer' )
                        || false !== strpos( $workflow_search_key, 'repeat_customer' )
                        || false !== strpos( $workflow_search_key, 'reviewrequest' )
                        || false !== strpos( $workflow_search_key, 'review_request' )
                        || false !== strpos( $workflow_search_key, 'highvalue' )
                        || false !== strpos( $workflow_search_key, 'high_value' )
                        || false !== strpos( $workflow_search_key, 'vipcustomer' )
                        || false !== strpos( $workflow_search_key, 'vip_customer' )
                        || false !== strpos( $workflow_search_key, 'lapsed' )
                        || false !== strpos( $workflow_search_key, 'customerinactive' )
                        || false !== strpos( $workflow_search_key, 'customer_inactive' )
                        || false !== strpos( $workflow_search_key, 'customerwinback' )
                        || false !== strpos( $workflow_search_key, 'winback' )
                        || false !== strpos( $workflow_search_key, 'win_back' )
                        || false !== strpos( $workflow_search_key, 'woocommerce' );
                    if ( 'date' === $workflow_trigger || false !== strpos( $workflow_key, 'scheduled' ) ) {
                        $scheduled_workflow_cards[] = $workflow_card;
                        if ( '' !== $workflow_trigger ) {
                            $scheduled_workflow_triggers[] = $workflow_trigger;
                        }
                    } elseif ( $is_woocommerce_workflow ) {
                        $woocommerce_workflow_cards[] = $workflow_card;
                        if ( '' !== $workflow_trigger ) {
                            $woocommerce_workflow_triggers[] = $workflow_trigger;
                        }
                    } else {
                        $core_workflow_cards[] = $workflow_card;
                        if ( '' !== $workflow_trigger ) {
                            $core_workflow_triggers[] = $workflow_trigger;
                        }
                    }
                }
                $expand_covered_triggers = function( $triggers ) {
                    $triggers = array_values( array_filter( array_map( 'sanitize_key', (array) $triggers ) ) );
                    $aliases = array(
                        'new_subscriber' => array( 'new_subscribers', 'welcome_series' ),
                        'new_subscribers' => array( 'new_subscriber', 'welcome_series' ),
                        'welcome_series' => array( 'new_subscriber', 'new_subscribers' ),
                        'abandoned_cart_recovery' => array( 'abandoned_cart_step_1', 'abandoned_cart_step_2', 'abandoned_cart_step_3', 'abandoned_cart' ),
                        'abandoned_cart_step_1' => array( 'abandoned_cart_recovery', 'abandoned_cart_step_2', 'abandoned_cart_step_3', 'abandoned_cart' ),
                        'abandoned_cart_step_2' => array( 'abandoned_cart_recovery', 'abandoned_cart_step_1', 'abandoned_cart_step_3', 'abandoned_cart' ),
                        'abandoned_cart_step_3' => array( 'abandoned_cart_recovery', 'abandoned_cart_step_1', 'abandoned_cart_step_2', 'abandoned_cart' ),
                        'first_order' => array( 'new_customer' ),
                        'new_customer' => array( 'first_order' ),
                        'order_completed' => array( 'post_purchase', 'post_purchase_sequence' ),
                        'post_purchase' => array( 'order_completed', 'post_purchase_sequence' ),
                        'post_purchase_sequence' => array( 'order_completed', 'post_purchase' ),
                        'review_request' => array( 'product_review_request' ),
                        'repeat_customer' => array( 'repeat_customer_2plus' ),
                        'repeat_customer_2plus' => array( 'repeat_customer' ),
                        'high_value' => array( 'high_value_customer' ),
                        'high_value_customer' => array( 'high_value' ),
                        'vip_customer' => array( 'vip' ),
                        'customer_inactive' => array( 'inactive_customer', 'customer_winback', 'winback' ),
                        'inactive_customer' => array( 'customer_inactive', 'customer_winback', 'winback' ),
                        'customer_winback' => array( 'customer_inactive', 'inactive_customer', 'winback' ),
                        'winback' => array( 'customer_inactive', 'inactive_customer', 'customer_winback' ),
                        'lapsed_high_value_customer' => array( 'lapsed_high_value' ),
                        'lapsed_high_value' => array( 'lapsed_high_value_customer' ),
                        'date' => array( 'scheduled', 'specific_date' ),
                    );
                    foreach ( $triggers as $trigger ) {
                        if ( isset( $aliases[ $trigger ] ) ) {
                            foreach ( $aliases[ $trigger ] as $alias ) {
                                $triggers[] = sanitize_key( (string) $alias );
                            }
                        }
                    }
                    return array_unique( $triggers );
                };

                $core_workflow_triggers = $expand_covered_triggers( $core_workflow_triggers );
                $woocommerce_workflow_triggers = $expand_covered_triggers( $woocommerce_workflow_triggers );
                $scheduled_workflow_triggers = $expand_covered_triggers( $scheduled_workflow_triggers );

                $filter_covered_cards = function( $groups, $covered_triggers ) {
                    $covered_triggers = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $covered_triggers ) ) ) );
                    foreach ( $groups as $group_key => $group_bundle ) {
                        if ( empty( $group_bundle['cards'] ) || ! is_array( $group_bundle['cards'] ) ) {
                            continue;
                        }
                        $groups[ $group_key ]['cards'] = array_values( array_filter( $group_bundle['cards'], function( $card ) use ( $covered_triggers ) {
                            $trigger = isset( $card['trigger'] ) ? sanitize_key( (string) $card['trigger'] ) : '';
                            $status  = isset( $card['status'] ) ? sanitize_key( (string) $card['status'] ) : '';

                            // Dashboard sections are now workflow-first. If an automation already
                            // exists, it is represented by a workflow card above. Keep coverage
                            // cards only for items that are genuinely not created / not configured.
                            if ( in_array( $status, array( 'active', 'scheduled', 'queued', 'partial' ), true ) ) {
                                return false;
                            }

                            if ( '' !== $trigger && in_array( $trigger, $covered_triggers, true ) ) {
                                return false;
                            }

                            return true;
                        } ) );
                    }
                    return array_filter( $groups, function( $group_bundle ) {
                        return ! empty( $group_bundle['cards'] ) && is_array( $group_bundle['cards'] );
                    } );
                };
                $core_groups = $filter_covered_cards( $core_groups, $core_workflow_triggers );
                $woocommerce_groups = $filter_covered_cards( $woocommerce_groups, $woocommerce_workflow_triggers );
                $scheduled_groups = $filter_covered_cards( $scheduled_groups, $scheduled_workflow_triggers );

                $render_workflow_cards = function( $workflow_cards ) {
                    if ( empty( $workflow_cards ) || ! is_array( $workflow_cards ) ) {
                        return;
                    }
                    echo '<div class="pmcpc-premium-card" style="margin-bottom:18px;">';
                    echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">';
                    echo '<div><h3>' . esc_html__( 'Active workflows', 'product-mailer-campaigns' ) . '</h3>';
                    echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Live workflows and custom automations in this section.', 'product-mailer-campaigns' ) . '</div></div>';
                    echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_campaigns' ) ) . '">' . esc_html__( 'Open campaigns', 'product-mailer-campaigns' ) . '</a>';
                    echo '</div>';
                    echo '<div class="pmcpc-premium-grid pmcpc-premium-grid--automation" style="margin-top:10px;">';
                    foreach ( array_slice( $workflow_cards, 0, 12 ) as $workflow_card ) {
                        $status = isset( $workflow_card['status'] ) ? sanitize_key( (string) $workflow_card['status'] ) : 'inactive';
                        $status_label = ucwords( str_replace( '_', ' ', $status ) );
                        $status_class = 'pmcpc-status--neutral';
                        if ( 'active' === $status ) {
                            $status_class = 'pmcpc-status--success';
                        } elseif ( 'partial' === $status || 'needs_setup' === $status ) {
                            $status_class = 'pmcpc-status--warning';
                        } elseif ( 'inactive' === $status ) {
                            $status_class = 'pmcpc-status--muted';
                        }
                        $step_count = isset( $workflow_card['step_count'] ) ? max( 1, (int) $workflow_card['step_count'] ) : 1;
                        $active_steps = isset( $workflow_card['active_steps'] ) ? (int) $workflow_card['active_steps'] : 0;
                        $workflow_key = ! empty( $workflow_card['workflow_key'] ) ? sanitize_key( (string) $workflow_card['workflow_key'] ) : '';
                        $edit_url = admin_url( 'admin.php?page=pmcpc_campaigns' );
                        if ( '' !== $workflow_key ) {
                            $edit_url = add_query_arg( 'focus', 'workflow_' . $workflow_key, $edit_url );
                        } elseif ( ! empty( $workflow_card['campaign_id'] ) ) {
                            $edit_url = add_query_arg( 'campaign_id', (int) $workflow_card['campaign_id'], $edit_url );
                        }
                        echo '<div class="pmcpc-premium-card">';
                        echo '<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;">';
                        $workflow_icon = self::pmcpc_dashboard_get_workflow_icon( isset( $workflow_card['trigger'] ) ? (string) $workflow_card['trigger'] : '' );
                        echo '<h4>' . esc_html( $workflow_icon . ' ' . (string) $workflow_card['label'] ) . '</h4>';
                        echo '<span class="pmcpc-status-pill ' . esc_attr( $status_class ) . '">' . esc_html( $status_label ) . '</span>';
                        echo '</div>';
                        echo '<div class="pmcpc-premium-meta" style="margin-top:6px;">' . esc_html( sprintf( _n( '%d-step workflow', '%d-step workflow', $step_count, 'product-mailer-campaigns' ), $step_count ) ) . ' · ' . esc_html( sprintf( __( '%1$d/%2$d active', 'product-mailer-campaigns' ), $active_steps, $step_count ) ) . '</div>';
                        echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Trigger:', 'product-mailer-campaigns' ) . ' ' . esc_html( isset( $workflow_card['trigger_label'] ) ? (string) $workflow_card['trigger_label'] : '—' ) . '</div>';
                        echo '<div class="pmcpc-premium-split" style="margin-top:10px;">';
                        echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Entered (30d)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( number_format_i18n( (int) $workflow_card['entered_30'] ) ) . '</span></div>';
                        echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Sent (30d)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( number_format_i18n( (int) $workflow_card['sent_30'] ) ) . '</span></div>';
                        echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Open rate', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( is_null( $workflow_card['open_rate_30'] ) ? '—' : number_format_i18n( (float) $workflow_card['open_rate_30'], 1 ) . '%' ) . '</span></div>';
                        echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Click rate', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( is_null( $workflow_card['click_rate_30'] ) ? '—' : number_format_i18n( (float) $workflow_card['click_rate_30'], 1 ) . '%' ) . '</span></div>';
                        echo '</div>';
                        if ( ! empty( $workflow_card['last_activity_at'] ) ) {
                            $last_activity = self::pmcpc_dashboard_format_mysql_value( (string) $workflow_card['last_activity_at'] );
                            $last_email = ! empty( $workflow_card['last_activity_email'] ) ? self::pmcpc_dashboard_mask_email( (string) $workflow_card['last_activity_email'] ) : '';
                            $last_status = ! empty( $workflow_card['last_activity_status'] ) ? self::pmcpc_dashboard_format_activity_status( (string) $workflow_card['last_activity_status'] ) : '';
                            $activity_bits = array_filter( array( $last_activity, $last_email, $last_status ) );
                            echo '<div class="pmcpc-premium-meta" style="margin-top:8px;">' . esc_html__( 'Last activity:', 'product-mailer-campaigns' ) . ' ' . esc_html( implode( ' • ', $activity_bits ) ) . '</div>';
                        } else {
                            echo '<div class="pmcpc-premium-meta" style="margin-top:8px;">' . esc_html__( 'Last activity: No recent activity', 'product-mailer-campaigns' ) . '</div>';
                        }
                        echo '<div class="pmcpc-premium-meta">' . sprintf( esc_html__( 'Revenue (30d): %s', 'product-mailer-campaigns' ), esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( (float) $workflow_card['revenue_30'] ) ) : number_format_i18n( (float) $workflow_card['revenue_30'], 2 ) ) ) . '</div>';
                        echo '<div class="pmcpc-premium-actions" style="margin-top:10px;"><a class="button" href="' . esc_url( $edit_url ) . '">' . esc_html__( 'Edit in Campaigns', 'product-mailer-campaigns' ) . '</a></div>';
                        echo '</div>';
                    }
                    echo '</div>';
                    if ( count( $workflow_cards ) > 12 ) {
                        echo '<div class="pmcpc-premium-review" style="margin-top:10px;">' . esc_html( sprintf( __( 'Showing 12 of %d workflows. Open Campaigns to manage the full list.', 'product-mailer-campaigns' ), count( $workflow_cards ) ) ) . '</div>';
                    }
                    echo '</div>';
                };

                $render_coverage_group = function( $group_key, $group_bundle ) {
                    $group_label = ! empty( $group_bundle['label'] ) ? (string) $group_bundle['label'] : __( 'Automation group', 'product-mailer-campaigns' );
                    $group_cards = isset( $group_bundle['cards'] ) && is_array( $group_bundle['cards'] ) ? $group_bundle['cards'] : array();
                    $group_activity = isset( $group_bundle['recent_activity'] ) && is_array( $group_bundle['recent_activity'] ) ? $group_bundle['recent_activity'] : array();
                    $flat_section = ! empty( $group_bundle['flat_section'] );

                    if ( ! $flat_section ) {
                        echo '<div class="pmcpc-premium-card" style="margin-bottom:18px;">';
                        echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">';
                        echo '<h3>' . esc_html( $group_label ) . '</h3>';
                        if ( 'scheduled' === $group_key ) {
                            echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_campaigns' ) ) . '">' . esc_html__( 'Open campaigns', 'product-mailer-campaigns' ) . '</a>';
                        } else {
                            echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_automations' ) ) . '">' . esc_html__( 'Manage automations', 'product-mailer-campaigns' ) . '</a>';
                        }
                        echo '</div>';
                    }

                    if ( ! empty( $group_cards ) ) {
                        echo '<div class="pmcpc-premium-grid pmcpc-premium-grid--automation" style="margin-top:10px;">';
                        foreach ( $group_cards as $card ) {
                            $status = isset( $card['status'] ) ? sanitize_key( (string) $card['status'] ) : 'not_created';
                            $status_label = ucwords( str_replace( '_', ' ', $status ) );
                            $status_class = 'pmcpc-status--neutral';
                            if ( in_array( $status, array( 'active', 'scheduled' ), true ) ) {
                                $status_class = 'pmcpc-status--success';
                            } elseif ( 'partial' === $status || 'needs_setup' === $status ) {
                                $status_class = 'pmcpc-status--warning';
                            } elseif ( 'inactive' === $status || 'not_created' === $status ) {
                                $status_class = 'pmcpc-status--muted';
                            }

                            echo '<div class="pmcpc-premium-card">';
                            echo '<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;">';
                            $icon = ! empty( $card['icon'] ) ? (string) $card['icon'] : self::pmcpc_dashboard_get_workflow_icon( isset( $card['trigger'] ) ? (string) $card['trigger'] : '' );
                            echo '<h4>' . esc_html( $icon . ' ' . (string) $card['label'] ) . '</h4>';
                            echo '<span class="pmcpc-status-pill ' . esc_attr( $status_class ) . '">' . esc_html( $status_label ) . '</span>';
                            echo '</div>';
                            if ( ! empty( $card['description'] ) ) {
                                echo '<div class="pmcpc-premium-meta" style="margin-top:6px;">' . esc_html( (string) $card['description'] ) . '</div>';
                            }
                            if ( 'abandoned_cart_recovery' === (string) $card['trigger'] ) {
                                echo '<div class="pmcpc-premium-meta" style="margin-top:6px;font-weight:600;">' . esc_html__( '3-step workflow coverage', 'product-mailer-campaigns' ) . '</div>';
                            }
                            echo '<div class="pmcpc-premium-split" style="margin-top:10px;">';
                            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Entered (30d)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( number_format_i18n( (int) $card['entered_30'] ) ) . '</span></div>';
                            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Sent (30d)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( number_format_i18n( (int) $card['sent_30'] ) ) . '</span></div>';
                            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Open rate', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( is_null( $card['open_rate_30'] ) ? '—' : number_format_i18n( (float) $card['open_rate_30'], 1 ) . '%' ) . '</span></div>';
                            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Click rate', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( is_null( $card['click_rate_30'] ) ? '—' : number_format_i18n( (float) $card['click_rate_30'], 1 ) . '%' ) . '</span></div>';
                            echo '</div>';
                            if ( 'date' === (string) $card['trigger'] ) {
                                echo '<div class="pmcpc-premium-meta" style="margin-top:8px;">' . sprintf( esc_html__( 'Scheduled campaigns: %d', 'product-mailer-campaigns' ), (int) $card['scheduled_count'] ) . '</div>';
                                echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Next send:', 'product-mailer-campaigns' ) . ' ' . esc_html( ! empty( $card['next_run_at'] ) ? self::pmcpc_dashboard_format_mysql_value( (string) $card['next_run_at'] ) : '—' ) . '</div>';
                            } else {
                                if ( ! empty( $card['last_activity_at'] ) ) {
                                    $last_activity = self::pmcpc_dashboard_format_mysql_value( (string) $card['last_activity_at'] );
                                    $last_email = ! empty( $card['last_activity_email'] ) ? self::pmcpc_dashboard_mask_email( (string) $card['last_activity_email'] ) : '';
                                    $last_status = ! empty( $card['last_activity_status'] ) ? self::pmcpc_dashboard_format_activity_status( (string) $card['last_activity_status'] ) : '';
                                    $activity_bits = array_filter( array( $last_activity, $last_email, $last_status ) );
                                    if ( ! empty( $activity_bits ) ) {
                                        echo '<div class="pmcpc-premium-meta" style="margin-top:8px;">' . esc_html__( 'Last activity:', 'product-mailer-campaigns' ) . ' ' . esc_html( implode( ' • ', $activity_bits ) ) . '</div>';
                                    }
                                } else {
                                    echo '<div class="pmcpc-premium-meta" style="margin-top:8px;">' . esc_html__( 'Last activity: No recent activity', 'product-mailer-campaigns' ) . '</div>';
                                }
                                echo '<div class="pmcpc-premium-meta">' . sprintf( esc_html__( 'Revenue (30d): %s', 'product-mailer-campaigns' ), esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( (float) $card['revenue_30'] ) ) : number_format_i18n( (float) $card['revenue_30'], 2 ) ) ) . '</div>';
                            }
                            if ( ! empty( $card['campaign_id'] ) ) {
                                echo '<div class="pmcpc-premium-actions" style="margin-top:10px;"><a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . (int) $card['campaign_id'] ) ) . '">' . esc_html__( 'Edit workflow', 'product-mailer-campaigns' ) . '</a></div>';
                            }
                            echo '</div>';
                        }
                        echo '</div>';
                    }

                    if ( ! $flat_section && ! empty( $group_activity ) ) {
                        echo '<div style="margin-top:12px;">';
                        echo '<div class="pmcpc-premium-meta" style="font-weight:600;margin-bottom:6px;">' . esc_html__( 'Recent automation activity', 'product-mailer-campaigns' ) . '</div>';
                        echo '<div class="pmcpc-activity-feed">';
                        foreach ( array_slice( $group_activity, 0, 5 ) as $activity ) {
                            $title = ! empty( $activity['title'] ) ? (string) $activity['title'] : __( 'Activity', 'product-mailer-campaigns' );
                            $email = ! empty( $activity['email'] ) ? self::pmcpc_dashboard_mask_email( (string) $activity['email'] ) : '';
                            $status = ! empty( $activity['status'] ) ? self::pmcpc_dashboard_format_activity_status( (string) $activity['status'] ) : '';
                            $time = ! empty( $activity['activity_at'] ) ? self::pmcpc_dashboard_format_mysql_value( (string) $activity['activity_at'] ) : '';
                            $detail = ! empty( $activity['detail'] ) ? (string) $activity['detail'] : '';
                            $icon = ! empty( $activity['icon'] ) ? (string) $activity['icon'] : '•';
                            echo '<div class="pmcpc-activity-item">';
                            echo '<div class="pmcpc-activity-icon" aria-hidden="true">' . esc_html( $icon ) . '</div>';
                            echo '<div>';
                            echo '<div class="pmcpc-activity-title">' . esc_html( $title ) . '</div>';
                            $sub_parts = array_filter( array( $email, $status, $time ) );
                            if ( ! empty( $sub_parts ) ) {
                                echo '<div class="pmcpc-activity-sub">' . esc_html( implode( ' • ', $sub_parts ) ) . '</div>';
                            }
                            if ( '' !== $detail ) {
                                echo '<div class="pmcpc-activity-sub">' . esc_html( $detail ) . '</div>';
                            }
                            echo '</div>';
                            echo '</div>';
                        }
                        echo '</div>';
                        echo '</div>';
                    } elseif ( ! $flat_section ) {
                        echo '<div class="pmcpc-premium-review" style="margin-top:10px;">' . esc_html__( 'No recent automation activity yet for this group.', 'product-mailer-campaigns' ) . '</div>';
                    }

                    if ( ! $flat_section ) {
                        echo '</div>';
                    }
                };

                $render_coverage_section = function( $section_id, $heading, $description, $workflow_cards, $groups ) use ( $render_workflow_cards, $render_coverage_group ) {
                    if ( empty( $groups ) && empty( $workflow_cards ) ) {
                        return;
                    }
                    echo '<div class="pmcpc-dashboard-coverage-section" data-pmcpc-dashboard-section="' . esc_attr( $section_id ) . '" style="margin-bottom:20px;">';
                    echo '<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin:4px 0 12px;">';
                    echo '<div><div class="pmcpc-premium-meta" style="font-weight:700;font-size:14px;color:#1d2327;">' . esc_html( $heading ) . '</div>';
                    echo '<div class="pmcpc-premium-meta">' . esc_html( $description ) . '</div></div>';
                    echo '<button type="button" class="button pmcpc-dashboard-section-toggle" data-pmcpc-target-section="' . esc_attr( $section_id ) . '">' . esc_html__( 'Hide section', 'product-mailer-campaigns' ) . '</button>';
                    echo '</div>';
                    echo '<div class="pmcpc-dashboard-coverage-section-body">';
                    $render_workflow_cards( $workflow_cards );
                    if ( ! empty( $groups ) ) {
                        echo '<div class="pmcpc-premium-card" style="margin-bottom:18px;">';
                        foreach ( $groups as $group_key => $group_bundle ) {
                            $group_bundle['flat_section'] = true;
                            $render_coverage_group( $group_key, $group_bundle );
                        }
                        echo '</div>';
                    }
                    echo '</div>';
                    echo '</div>';
                };

                $render_coverage_section(
                    'core',
                    __( 'Core automation coverage (Free)', 'product-mailer-campaigns' ),
                    __( 'Subscriber and list automations included in the core plugin.', 'product-mailer-campaigns' ),
                    $core_workflow_cards,
                    $core_groups
                );

                $render_coverage_section(
                    'scheduled',
                    __( 'Scheduled campaigns', 'product-mailer-campaigns' ),
                    __( 'One-time and recurring campaigns that run on chosen dates.', 'product-mailer-campaigns' ),
                    $scheduled_workflow_cards,
                    $scheduled_groups
                );

                if ( ! $hide_paid_features ) {
                    $render_coverage_section(
                        'woocommerce',
                        __( 'WooCommerce automation coverage (Paid)', 'product-mailer-campaigns' ),
                        __( 'Commerce journeys such as abandoned cart recovery, post-purchase, review requests, VIP, and win-back automations.', 'product-mailer-campaigns' ),
                        $woocommerce_workflow_cards,
                        $woocommerce_groups
                    );
                }

                echo '<script>(function(){try{var key="pmcpc_dashboard_hidden_sections";var hidden=JSON.parse(localStorage.getItem(key)||"[]");function apply(){document.querySelectorAll("[data-pmcpc-dashboard-section]").forEach(function(section){var id=section.getAttribute("data-pmcpc-dashboard-section");var isHidden=hidden.indexOf(id)!==-1;var body=section.querySelector(".pmcpc-dashboard-coverage-section-body");var btn=section.querySelector(".pmcpc-dashboard-section-toggle");if(body){body.style.display=isHidden?"none":"";}if(btn){btn.textContent=isHidden?"Show section":"Hide section";}});}document.addEventListener("click",function(e){var btn=e.target.closest(".pmcpc-dashboard-section-toggle");if(!btn){return;}var id=btn.getAttribute("data-pmcpc-target-section");var i=hidden.indexOf(id);if(i===-1){hidden.push(id);}else{hidden.splice(i,1);}localStorage.setItem(key,JSON.stringify(hidden));apply();});apply();}catch(e){}})();</script>';
            }

            self::pmcpc_dashboard_section_close();
        }



        protected static function render_dashboard_recent_activity_summary_section( $data ) {
            self::pmcpc_dashboard_section_open( 'recent_activity', __( 'Latest Activity', 'product-mailer-campaigns' ), __( 'A compact view of the most recent automation and campaign activity.', 'product-mailer-campaigns' ) );
            echo '<div class="pmcpc-premium-card" style="margin-bottom:18px;">';
            echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">';
            echo '<h3>' . esc_html__( '🕒 Latest Activity', 'product-mailer-campaigns' ) . '</h3>';
            echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=history' ) ) . '">' . esc_html__( 'View full activity', 'product-mailer-campaigns' ) . '</a>';
            echo '</div>';
            if ( ! empty( $data['recent_activity'] ) && is_array( $data['recent_activity'] ) ) {
                echo '<div class="pmcpc-activity-feed">';
                $shown = 0;
                foreach ( $data['recent_activity'] as $activity ) {
                    if ( $shown >= 6 ) {
                        break;
                    }
                    $title = ! empty( $activity['title'] ) ? (string) $activity['title'] : __( 'Activity', 'product-mailer-campaigns' );
                    $email = ! empty( $activity['email'] ) ? self::pmcpc_dashboard_mask_email( (string) $activity['email'] ) : '';
                    $status = ! empty( $activity['status'] ) ? self::pmcpc_dashboard_format_activity_status( (string) $activity['status'] ) : '';
                    $time = ! empty( $activity['activity_at'] ) ? self::pmcpc_dashboard_format_mysql_value( (string) $activity['activity_at'] ) : '';
                    $icon = ! empty( $activity['icon'] ) ? (string) $activity['icon'] : '•';
                    echo '<div class="pmcpc-activity-item">';
                    echo '<div class="pmcpc-activity-icon" aria-hidden="true">' . esc_html( $icon ) . '</div>';
                    echo '<div>';
                    echo '<div class="pmcpc-activity-title">' . esc_html( $title ) . '</div>';
                    if ( '' !== $email ) {
                        echo '<div class="pmcpc-activity-sub">' . esc_html( $email ) . '</div>';
                    }
                    $meta_parts = array();
                    if ( '' !== $status ) {
                        $meta_parts[] = $status;
                    }
                    if ( '' !== $time ) {
                        $meta_parts[] = $time;
                    }
                    if ( ! empty( $meta_parts ) ) {
                        echo '<div class="pmcpc-activity-sub">' . esc_html( implode( ' • ', $meta_parts ) ) . '</div>';
                    }
                    if ( ! empty( $activity['detail'] ) ) {
                        echo '<div class="pmcpc-activity-sub">' . esc_html( (string) $activity['detail'] ) . '</div>';
                    }
                    echo '</div>';
                    echo '</div>';
                    $shown++;
                }
                echo '</div>';
            } else {
                echo '<p class="pmcpc-premium-meta">' . esc_html__( 'No recent activity yet. Queue, sent, and scheduled campaign events will appear here automatically.', 'product-mailer-campaigns' ) . '</p>';
            }
            echo '</div>';
            self::pmcpc_dashboard_section_close();
        }



    public static function render_woocommerce_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            $has_wc = class_exists( 'WooCommerce' );
            $premium_enabled = function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled();
            $hide_paid_features = function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features();

            echo '<div class="wrap">';
            echo '<h1>' . esc_html__( 'WooCommerce', 'product-mailer-campaigns' ) . '</h1>';

            if ( $hide_paid_features ) {
                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);max-width:780px;">';
                echo '<h2 style="margin:0 0 8px;font-size:14px;">' . esc_html__( 'WooCommerce paid features are hidden', 'product-mailer-campaigns' ) . '</h2>';
                echo '<p style="margin:0;">' . esc_html__( 'Use the header toggle to show Commerce features again when you want to review or activate them.', 'product-mailer-campaigns' ) . '</p>';
                echo '</div>';
                echo '</div>';
                return;
            }

            if ( ! $has_wc ) {
                echo '<p>' . esc_html__( 'WooCommerce is not active on this site. Install and activate WooCommerce to unlock ecommerce automations.', 'product-mailer-campaigns' ) . '</p>';
                echo '</div>';
                return;
            }

            // Light stats (same logic as dashboard, but calculated fresh).
            global $wpdb;
            $now_ts      = (int) current_time( 'timestamp' );
            $dt_30_mysql = date( 'Y-m-d H:i:s', $now_ts - ( 30 * DAY_IN_SECONDS ) );
            $dt_90_mysql = date( 'Y-m-d H:i:s', $now_ts - ( 90 * DAY_IN_SECONDS ) );

            $posts_table    = esc_sql( $wpdb->posts );
            $postmeta_table = esc_sql( $wpdb->postmeta );

            $order_statuses = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
            $st_in          = "'" . implode( "','", array_map( 'esc_sql', $order_statuses ) ) . "'";

            $orders_30 = 0;

            // Prefer WooCommerce API when available (HPOS-safe).
            if ( function_exists( 'wc_get_orders' ) ) {
                $res = wc_get_orders(
                    array(
                        'limit'        => 1,
                        'return'       => 'ids',
                        'paginate'     => true,
                        'status'       => array( 'processing', 'completed', 'on-hold' ),
                        'date_created' => '>' . $dt_30_mysql,
                    )
                );
                if ( is_object( $res ) && isset( $res->total ) ) {
                    $orders_30 = (int) $res->total;
                } elseif ( is_array( $res ) ) {
                    $orders_30 = count( $res );
                }
            }

            if ( 0 === (int) $orders_30 ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $orders_30 = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(ID)
                         FROM {$posts_table}
                         WHERE post_type = 'shop_order'
                           AND post_status IN ({$st_in})
                           AND post_date >= %s",
                        $dt_30_mysql
                    )
                );
            }

            $distinct_customer_expr = "CASE
                WHEN cu.meta_value IS NOT NULL AND cu.meta_value != '' AND cu.meta_value != '0'
                    THEN CONCAT('u:', cu.meta_value)
                WHEN be.meta_value IS NOT NULL AND be.meta_value != ''
                    THEN CONCAT('e:', be.meta_value)
                ELSE NULL
            END";

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $customers_total = (int) $wpdb->get_var(
                "SELECT COUNT(DISTINCT {$distinct_customer_expr})
                 FROM {$posts_table} p
                 LEFT JOIN {$postmeta_table} cu ON (cu.post_id = p.ID AND cu.meta_key = '_customer_user')
                 LEFT JOIN {$postmeta_table} be ON (be.post_id = p.ID AND be.meta_key = '_billing_email')
                 WHERE p.post_type = 'shop_order'
                   AND p.post_status IN ({$st_in})"
            );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $customers_active_90 = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(DISTINCT {$distinct_customer_expr})
                     FROM {$posts_table} p
                     LEFT JOIN {$postmeta_table} cu ON (cu.post_id = p.ID AND cu.meta_key = '_customer_user')
                     LEFT JOIN {$postmeta_table} be ON (be.post_id = p.ID AND be.meta_key = '_billing_email')
                     WHERE p.post_type = 'shop_order'
                       AND p.post_status IN ({$st_in})
                       AND p.post_date >= %s",
                    $dt_90_mysql
                )
            );

            $winback = max( 0, $customers_total - $customers_active_90 );

            $abandoned_7 = ! empty( $data['wc_abandoned_7'] ) ? (int) $data['wc_abandoned_7'] : 0;
            $abandoned_total_7 = ! empty( $data['wc_abandoned_total_7'] ) ? (float) $data['wc_abandoned_total_7'] : 0.0;
    echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin:14px 0 18px;">';
            echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);"><div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Orders (last 30 days)', 'product-mailer-campaigns' ) . '</div><div style="font-size:28px;font-weight:700;">' . esc_html( (int) $orders_30 ) . '</div><div class="description" style="margin-top:6px;">' . esc_html__( 'Perfect for post‑purchase follow‑ups.', 'product-mailer-campaigns' ) . '</div></div>';
            echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);"><div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Customers to win back', 'product-mailer-campaigns' ) . '</div><div style="font-size:28px;font-weight:700;">' . esc_html( (int) $winback ) . '</div><div class="description" style="margin-top:6px;">' . esc_html__( 'No orders in the last 90 days.', 'product-mailer-campaigns' ) . '</div></div>';
            echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);"><div style="font-size:13px;color:#50575e;margin-bottom:6px;">' . esc_html__( 'Abandoned carts (7d)', 'product-mailer-campaigns' ) . '</div><div style="font-size:28px;font-weight:700;">' . esc_html( (int) $abandoned_7 ) . '</div><div class="description" style="margin-top:6px;">' . esc_html__( 'Estimated value at risk.', 'product-mailer-campaigns' ) . ' <strong>' . esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $abandoned_total_7 ) ) : number_format_i18n( $abandoned_total_7, 2 ) ) . '</strong></div></div>';
            echo '</div>';

            if ( $premium_enabled ) {
                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);">';
                echo '<h2 style="margin:0 0 8px;font-size:14px;">' . esc_html__( 'Next best automations', 'product-mailer-campaigns' ) . '</h2>';
                echo '<ul style="margin:0 0 0 18px;list-style:disc;">';
                echo '<li>' . esc_html__( 'Post‑purchase: review request, care tips, cross‑sell products', 'product-mailer-campaigns' ) . '</li>';
                echo '<li>' . esc_html__( 'Win‑back: customers who haven’t bought in 90+ days', 'product-mailer-campaigns' ) . '</li>';
                echo '<li>' . esc_html__( 'Customer lifecycle tagging (new → repeat → VIP)', 'product-mailer-campaigns' ) . '</li>';
                echo '</ul>';
                echo '<p style="margin-top:12px;"><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_automations' ) ) . '">' . esc_html__( 'Open Automations', 'product-mailer-campaigns' ) . '</a></p>';
                echo '</div>';
            } elseif ( ! $hide_paid_features ) {
                $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
                $trial_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );
                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);">';
                echo '<h2 style="margin:0 0 8px;font-size:14px;">' . esc_html__( 'Unlock WooCommerce automations', 'product-mailer-campaigns' ) . '</h2>';
                echo '<p style="margin:0 0 10px;">' . esc_html__( 'Turn these opportunities into automated emails: post‑purchase sequences, win‑back campaigns, and customer targeting based on purchase history.', 'product-mailer-campaigns' ) . '</p>';
                echo '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
                echo '<a class="button button-primary" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Start free trial', 'product-mailer-campaigns' ) . '</a>';
                echo '<a class="button" href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Activate license', 'product-mailer-campaigns' ) . '</a>';
                echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_dashboard' ) ) . '">' . esc_html__( 'Back to dashboard', 'product-mailer-campaigns' ) . '</a>';
                echo '</div>';
                echo '<hr style="margin:14px 0;">';
                echo '<h3 style="margin:0 0 8px;font-size:13px;">' . esc_html__( 'What you get', 'product-mailer-campaigns' ) . '</h3>';
                echo '<ul style="margin:0 0 0 18px;list-style:disc;">';
                echo '<li>' . esc_html__( 'Customer segments by purchase behaviour', 'product-mailer-campaigns' ) . '</li>';
                echo '<li>' . esc_html__( 'Automated post‑purchase follow‑ups', 'product-mailer-campaigns' ) . '</li>';
                echo '<li>' . esc_html__( 'Win‑back campaigns for lapsed customers', 'product-mailer-campaigns' ) . '</li>';
                echo '<li>' . esc_html__( 'Abandoned cart recovery and sales sequences', 'product-mailer-campaigns' ) . '</li>';
                echo '</ul>';

                // Inline "locked" automation starters with live opportunity counts.
                $offer_base = add_query_arg( array( 'page' => 'pmcpc_upgrade' ), admin_url( 'admin.php' ) );
                echo '<hr style="margin:14px 0;">';
                echo '<h3 style="margin:0 0 10px;font-size:13px;">' . esc_html__( 'Popular WooCommerce automations (locked)', 'product-mailer-campaigns' ) . '</h3>';
                echo '<p style="margin:0 0 12px;color:#646970;">' . esc_html__( 'These are ready to turn on as soon as you start your trial or activate a license.', 'product-mailer-campaigns' ) . '</p>';
                echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;max-width:980px;">';

                // Card: Post-purchase.
                $pp_url = add_query_arg( array( 'pmcpc_offer' => 'post_purchase' ), $offer_base );
                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);">';
                echo '<div style="font-size:12px;color:#50575e;">' . esc_html__( 'Post‑purchase follow‑ups', 'product-mailer-campaigns' ) . '</div>';
                echo '<div style="font-size:22px;font-weight:700;margin-top:6px;">' . esc_html( (int) $orders_30 ) . '</div>';
                echo '<div style="color:#646970;margin-top:4px;">' . esc_html__( 'orders in the last 30 days', 'product-mailer-campaigns' ) . '</div>';
                echo '<p style="margin:10px 0 12px;">' . esc_html__( 'Send care tips, cross‑sells, review requests, and reorder reminders automatically after a purchase.', 'product-mailer-campaigns' ) . '</p>';
                echo '<a class="button button-primary" href="' . esc_url( $pp_url ) . '">' . esc_html__( 'Start this automation (locked)', 'product-mailer-campaigns' ) . '</a>';
                echo '</div>';

            
                // Card: Abandoned cart recovery.
                $ac_url = add_query_arg( array( 'pmcpc_offer' => 'abandoned_cart' ), $offer_base );
                $ac_value = function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $abandoned_total_7 ) ) : number_format_i18n( $abandoned_total_7, 2 );
                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);">';
                echo '<div style="font-size:12px;color:#50575e;">' . esc_html__( 'Abandoned cart recovery', 'product-mailer-campaigns' ) . '</div>';
                echo '<div style="display:flex;align-items:flex-end;justify-content:space-between;gap:10px;margin-top:6px;">';
                echo '<div style="font-size:22px;font-weight:700;line-height:1;">' . esc_html( (int) $abandoned_7 ) . '</div>';
                echo '<div style="font-size:12px;color:#646970;text-align:right;">' . esc_html__( 'carts (7d)', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $ac_value ) . '</strong></div>';
                echo '</div>';
                echo '<div style="margin-top:10px;color:#646970;font-size:13px;">' . esc_html__( 'Recover lost revenue automatically with a timed email sequence.', 'product-mailer-campaigns' ) . '</div>';
                echo '<p style="margin:10px 0 0;"><a class="button button-primary" href="' . esc_url( $ac_url ) . '">' . esc_html__( 'Start this automation (locked)', 'product-mailer-campaigns' ) . '</a></p>';
                echo '</div>';
    // Card: Win-back.
                $wb_url = add_query_arg( array( 'pmcpc_offer' => 'winback' ), $offer_base );
                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);">';
                echo '<div style="font-size:12px;color:#50575e;">' . esc_html__( 'Win‑back campaign', 'product-mailer-campaigns' ) . '</div>';
                echo '<div style="font-size:22px;font-weight:700;margin-top:6px;">' . esc_html( (int) $winback ) . '</div>';
                echo '<div style="color:#646970;margin-top:4px;">' . esc_html__( 'customers inactive 90+ days', 'product-mailer-campaigns' ) . '</div>';
                echo '<p style="margin:10px 0 12px;">' . esc_html__( 'Bring back past customers with a timed offer and personalised product recommendations.', 'product-mailer-campaigns' ) . '</p>';
                echo '<a class="button button-primary" href="' . esc_url( $wb_url ) . '">' . esc_html__( 'Start this automation (locked)', 'product-mailer-campaigns' ) . '</a>';
                echo '</div>';

                // Card: Review request.
                $rr_url = add_query_arg( array( 'pmcpc_offer' => 'review_request' ), $offer_base );
                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);">';
                echo '<div style="font-size:12px;color:#50575e;">' . esc_html__( 'Review request flow', 'product-mailer-campaigns' ) . '</div>';
                echo '<div style="font-size:22px;font-weight:700;margin-top:6px;">' . esc_html( (int) $orders_30 ) . '</div>';
                echo '<div style="color:#646970;margin-top:4px;">' . esc_html__( 'buyers you can ask this month', 'product-mailer-campaigns' ) . '</div>';
                echo '<p style="margin:10px 0 12px;">' . esc_html__( 'Automatically request reviews a few days after delivery — great for trust and conversion.', 'product-mailer-campaigns' ) . '</p>';
                echo '<a class="button button-primary" href="' . esc_url( $rr_url ) . '">' . esc_html__( 'Start this automation (locked)', 'product-mailer-campaigns' ) . '</a>';
                echo '</div>';

                echo '</div>';
                echo '</div>';
            } else {
                echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;box-shadow:0 1px 1px rgba(0,0,0,.04);">';
                echo '<h2 style="margin:0 0 8px;font-size:14px;">' . esc_html__( 'WooCommerce paid features are hidden', 'product-mailer-campaigns' ) . '</h2>';
                echo '<p style="margin:0;">' . esc_html__( 'Use the header toggle to show Commerce features again when you want to review or activate them.', 'product-mailer-campaigns' ) . '</p>';
                echo '</div>';
            }

            if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
                PMCPC_Activity_Feed::render_panel();
            }

            echo '</div>';
        }



    public static function render_analytics_page() {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__( 'Analytics', 'product-mailer-campaigns' ) . '</h1>';
            PMCPC_Analytics::render_page();
            echo '</div>';
        }


    public static function render_queue_page() {
            // Back-compat: the queue is now a tab on the Email screen.
            self::render_email_page( 'queue' );
        }



        protected static function render_dashboard_premium_overview( $data ) {
            $reviews_url = admin_url( 'admin.php?page=pmcpc_reviews&pmcpc_status=pending' );
            $queue_url   = admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=queue&queue_status=failed' );
            $subs_url    = admin_url( 'admin.php?page=pmcpc_subscribers' );
            $auto_url    = admin_url( 'admin.php?page=pmcpc_automations&scope=core' );
            $tracking_debug = class_exists( 'PMCPC_Settings' ) ? ( PMCPC_Settings::get( 'tracking_debug', 'no' ) === 'yes' ) : false;

            $avg_rating = ! empty( $data['reviews_average_rating'] ) ? number_format_i18n( (float) $data['reviews_average_rating'], 1 ) : '—';
            $subscriber_total = isset( $data['total_subscribers'] ) ? (int) $data['total_subscribers'] : 0;
            $active_subscribers = isset( $data['active_subscribers'] ) ? (int) $data['active_subscribers'] : 0;

            self::pmcpc_dashboard_section_open( 'overview_cards', __( 'Overview Cards', 'product-mailer-campaigns' ), __( 'High-level dashboard snapshot for reviews, subscribers, email performance, and queue health.', 'product-mailer-campaigns' ) );
            echo '<div class="pmcpc-premium-grid">';

            echo '<div class="pmcpc-premium-card">';
            echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">';
            echo '<h3>' . esc_html__( '⭐ Reviews Snapshot', 'product-mailer-campaigns' ) . '</h3>';
            if ( ! empty( $data['reviews_pending_count'] ) ) {
                echo '<a class="button button-primary" href="' . esc_url( $reviews_url ) . '">' . esc_html__( 'Moderate reviews', 'product-mailer-campaigns' ) . '</a>';
            }
            echo '</div>';
            echo '<div class="pmcpc-premium-kpi">' . esc_html( (int) $data['reviews_pending_count'] ) . '</div>';
            echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Pending moderation', 'product-mailer-campaigns' ) . '</div>';
            echo '<div class="pmcpc-premium-split">';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Approved today', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['reviews_approved_today'] ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Average rating', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( $avg_rating ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Product reviews', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['reviews_product_count'] ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Standard reviews', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['reviews_standard_count'] ) . '</span></div>';
            echo '</div>';
            if ( ! empty( $data['latest_review_preview'] ) && is_array( $data['latest_review_preview'] ) ) {
                $preview_name = ! empty( $data['latest_review_preview']['reviewer_name'] ) ? (string) $data['latest_review_preview']['reviewer_name'] : __( 'Latest approved review', 'product-mailer-campaigns' );
                $preview_text = ! empty( $data['latest_review_preview']['review_text'] ) ? wp_trim_words( wp_strip_all_tags( (string) $data['latest_review_preview']['review_text'] ), 14, '…' ) : '';
                $preview_rating = ! empty( $data['latest_review_preview']['rating'] ) ? str_repeat( '★', max( 0, min( 5, (int) $data['latest_review_preview']['rating'] ) ) ) : '';
                echo '<div class="pmcpc-premium-review">';
                if ( '' !== $preview_rating ) {
                    echo '<div style="margin-bottom:4px;">' . esc_html( $preview_rating ) . '</div>';
                }
                if ( '' !== $preview_text ) {
                    echo '<div>“' . esc_html( $preview_text ) . '”</div>';
                }
                echo '<div style="margin-top:4px;font-weight:600;">— ' . esc_html( $preview_name ) . '</div>';
                echo '</div>';
            }
            echo '</div>';

            echo '<div class="pmcpc-premium-card">';
            echo '<h3>' . esc_html__( '👥 Subscriber Growth', 'product-mailer-campaigns' ) . '</h3>';
            echo '<div class="pmcpc-premium-kpi">' . esc_html( number_format_i18n( $subscriber_total ) ) . '</div>';
            echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Total subscribers', 'product-mailer-campaigns' ) . '</div>';
            echo '<div class="pmcpc-premium-split">';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Active', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( number_format_i18n( $active_subscribers ) ) . '</span></div>';
                    echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Pending', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( number_format_i18n( (int) $data['pending_subscribers'] ) ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Engaged (30d)', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( number_format_i18n( (int) $data['engaged_30'] ) ) . '</span></div>';
            echo '</div>';
            echo '</div>';

            echo '<div class="pmcpc-premium-card">';
            echo '<h3>' . esc_html__( '📧 Email Performance', 'product-mailer-campaigns' ) . '</h3>';
            echo '<div class="pmcpc-premium-kpi">' . esc_html( number_format_i18n( (int) $data['sent_30'] ) ) . '</div>';
            echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Emails sent in the last 30 days', 'product-mailer-campaigns' ) . '</div>';
            echo '<div class="pmcpc-premium-split">';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Open rate', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( is_null( $data['open_rate_30'] ) ? '—' : number_format_i18n( (float) $data['open_rate_30'], 1 ) . '%' ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Click rate', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( is_null( $data['click_rate_30'] ) ? '—' : number_format_i18n( (float) $data['click_rate_30'], 1 ) . '%' ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Failures today', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['queue_failures_today'] ) . '</span></div>';
            echo '</div>';
            if ( ! $tracking_debug ) {
                echo '<div class="pmcpc-premium-review">' . esc_html__( 'Open and click rates will appear here when tracking is enabled.', 'product-mailer-campaigns' ) . '</div>';
            }
            echo '</div>';

            echo '<div class="pmcpc-premium-card">';
            echo '<h3>' . esc_html__( '⏱️ Queue Health', 'product-mailer-campaigns' ) . '</h3>';
            echo '<div class="pmcpc-premium-kpi">' . esc_html( (int) $data['queue_pending'] ) . '</div>';
            echo '<div class="pmcpc-premium-meta">' . esc_html__( 'Emails currently waiting in queue', 'product-mailer-campaigns' ) . '</div>';
            echo '<div class="pmcpc-premium-split">';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Processing', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( ucfirst( (string) $data['queue_processing_status'] ) ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Last run', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( self::pmcpc_dashboard_format_mysql_value( isset( $data['queue_last_run'] ) ? $data['queue_last_run'] : '' ) ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Failed total', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['queue_failed'] ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Next cron run', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( self::pmcpc_dashboard_format_ts_value( isset( $data['next_queue_run'] ) ? $data['next_queue_run'] : 0 ) ) . '</span></div>';
            echo '</div>';
            if ( ! empty( $data['queue_pending'] ) || ! empty( $data['queue_failed'] ) ) {
                echo '<div class="pmcpc-premium-actions"><a class="button" href="' . esc_url( $queue_url ) . '">' . esc_html__( 'Open queue', 'product-mailer-campaigns' ) . '</a></div>';
            }
            echo '</div>';

            echo '</div>';
            self::pmcpc_dashboard_section_close();


            self::pmcpc_dashboard_section_open( 'automation_health', __( 'Automation Health & Delivery', 'product-mailer-campaigns' ), __( 'Health, delivery, and compliance summaries for your automation setup.', 'product-mailer-campaigns' ) );
            echo '<div class="pmcpc-premium-grid pmcpc-premium-grid--duo" style="grid-template-columns:minmax(280px,.9fr) minmax(420px,1.3fr);margin-bottom:16px;">';

            echo '<div class="pmcpc-premium-card">';
            echo '<h3>' . esc_html__( '🩺 Automation Health', 'product-mailer-campaigns' ) . '</h3>';
            echo '<div class="pmcpc-premium-kpi">' . esc_html( (int) $data['growth_score'] ) . '<span style="font-size:16px;font-weight:500;color:#50575e;"> / 100</span></div>';
            if ( ! empty( $data['queue_failures_today'] ) ) {
                echo '<p class="pmcpc-premium-meta" style="margin:4px 0 0;">' . sprintf( esc_html__( '%d queue failures need attention today.', 'product-mailer-campaigns' ), (int) $data['queue_failures_today'] ) . '</p>';
            } else {
                echo '<p class="pmcpc-premium-meta" style="margin:4px 0 0;">' . esc_html__( 'Queue healthy and processing normally.', 'product-mailer-campaigns' ) . '</p>';
            }
            echo '<div class="pmcpc-premium-compact-stats" style="margin-top:10px;">';
            echo '<div><strong>' . esc_html__( 'Coverage', 'product-mailer-campaigns' ) . ':</strong> ' . esc_html( number_format_i18n( (float) $data['automation_component'], 1 ) ) . ' / 70</div>';
            echo '<div><strong>' . esc_html__( 'Queue', 'product-mailer-campaigns' ) . ':</strong> ' . esc_html( number_format_i18n( (float) $data['queue_component'], 1 ) ) . ' / 15</div>';
            echo '<div><strong>' . esc_html__( 'Tracking', 'product-mailer-campaigns' ) . ':</strong> ' . esc_html( number_format_i18n( (float) $data['tracking_component'], 1 ) ) . ' / 10</div>';
            echo '<div><strong>' . esc_html__( 'Engagement', 'product-mailer-campaigns' ) . ':</strong> ' . esc_html( number_format_i18n( (float) $data['engagement_component'], 1 ) ) . ' / 5</div>';
            if ( ! empty( $data['setup_penalty'] ) ) {
                echo '<div><strong>' . esc_html__( 'Setup penalty', 'product-mailer-campaigns' ) . ':</strong> -' . esc_html( number_format_i18n( (float) $data['setup_penalty'], 1 ) ) . '</div>';
            }
            echo '</div>';
            if ( ! empty( $data['top_automation_rows'] ) && is_array( $data['top_automation_rows'] ) ) {
                $top = reset( $data['top_automation_rows'] );
                if ( ! empty( $top['label'] ) ) {
                    echo '<p class="pmcpc-premium-meta" style="margin:8px 0 0;"><strong>' . esc_html__( 'Top workflow:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( (string) $top['label'] ) . '</p>';
                }
            }
            if ( ! empty( $data['queue_failures_today'] ) ) {
                echo '<div class="pmcpc-premium-actions"><a class="button" href="' . esc_url( $auto_url ) . '">' . esc_html__( 'View core automations', 'product-mailer-campaigns' ) . '</a></div>';
            }
            echo '</div>';

            echo '<div class="pmcpc-premium-card">';
            echo '<h3>' . esc_html__( '🛡️ Delivery & Compliance', 'product-mailer-campaigns' ) . '</h3>';
            echo '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;">';
            echo '<div>';
            echo '<div class="pmcpc-premium-meta" style="margin-bottom:8px;font-weight:600;">' . esc_html__( 'Delivery', 'product-mailer-campaigns' ) . '</div>';
            echo '<div class="pmcpc-premium-split">';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Queue failed', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['queue_failed'] ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Next queue run', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( self::pmcpc_dashboard_format_ts_value( (int) $data['next_queue_run'] ) ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Pending confirmations', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['pending_subscribers'] ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Unsubscribed', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['unsubscribed_subscribers'] ) . '</span></div>';
            echo '</div>';
            echo '</div>';
            echo '<div>';
            echo '<div class="pmcpc-premium-meta" style="margin-bottom:8px;font-weight:600;">' . esc_html__( 'Compliance', 'product-mailer-campaigns' ) . '</div>';
            echo '<div class="pmcpc-premium-split">';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Blocked emails', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['blocked_emails_count'] ) . '</span></div>';
            echo '<div><span class="pmcpc-premium-stat-label">' . esc_html__( 'Blocked domains', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-premium-stat-value">' . esc_html( (int) $data['blocked_domains_count'] ) . '</span></div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '<div class="pmcpc-premium-actions">';
            echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_settings' ) ) . '">' . esc_html__( 'Open settings', 'product-mailer-campaigns' ) . '</a>';
            echo '</div>';
            echo '</div>';

            echo '</div>';
            self::pmcpc_dashboard_section_close();
        }


    public static function render_campaigns_page() {
            $manager = new PMCPC_Campaign_Manager();
            $manager->handle_request();

            echo '<div class="wrap">';
            PMCPC_Admin::render_app_header( __( 'Campaigns', 'product-mailer-campaigns' ), array( array( 'label' => __( 'Create Campaign', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_campaigns&action=new' ), 'class' => 'button-primary' ), array( 'label' => __( 'Create Automation', 'product-mailer-campaigns' ), 'url' => add_query_arg( array( 'page' => 'pmcpc_campaigns', 'campaign_type' => 'automation', 'pmcpc_new' => '1', 'pmcpc_stage' => '2', 'step' => 'timing', 'stage' => 'timing', 'wizard_step' => 'timing', 'tab' => 'timing', 'view' => 'timing' ), admin_url( 'admin.php' ) ) ) ) );
            PMCPC_Admin::render_page_intro(
                __( 'Create one-off and scheduled emails', 'product-mailer-campaigns' ),
                __( 'Use this page to build campaigns, check audience size, send a test, and confirm what is ready to go live.', 'product-mailer-campaigns' ),
                array(
                    array( 'label' => __( 'Build and edit campaigns', 'product-mailer-campaigns' ), 'icon' => 'dashicons-megaphone' ),
                    array( 'label' => __( 'Preview and send tests', 'product-mailer-campaigns' ), 'icon' => 'dashicons-visibility' ),
                    array( 'label' => __( 'Check audience before sending', 'product-mailer-campaigns' ), 'icon' => 'dashicons-groups' ),
                )
            );
            PMCPC_Admin::render_support_panels(
                array(
                    array(
                        'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-editor-help',
                        'title'   => __( 'Follow the same flow every time', 'product-mailer-campaigns' ),
                        'text'    => __( 'Keeping the steps in the same order makes campaigns easier to review and easier to troubleshoot.', 'product-mailer-campaigns' ),
                        'items'   => array(
                            __( 'Create or open a campaign.', 'product-mailer-campaigns' ),
                            __( 'Check the audience and timing.', 'product-mailer-campaigns' ),
                            __( 'Send a test before adding it to the queue.', 'product-mailer-campaigns' ),
                        ),
                    ),
                    array(
                        'eyebrow' => __( 'Test and check', 'product-mailer-campaigns' ),
                        'icon'    => 'dashicons-saved',
                        'title'   => __( 'See problems sooner', 'product-mailer-campaigns' ),
                        'text'    => __( 'Use the built-in checks on this screen first, then open Health Check if something still looks wrong.', 'product-mailer-campaigns' ),
                        'actions' => array(
                            array( 'label' => __( 'New Campaign', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_campaigns&action=new' ), 'class' => 'button button-primary' ),
                            array( 'label' => __( 'Open Health Check', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_diagnostics' ), 'class' => 'button' ),
                        ),
                    ),
                )
            );
            $manager->render_page();
            echo '</div>';
        }


    public static function render_subscribers_page() {
            $manager = new PMCPC_Subscriber_Manager();
            $manager->handle_request();

            echo '<div class="wrap">';
            if ( function_exists( 'add_thickbox' ) ) {
                add_thickbox();
            }

            PMCPC_Admin::render_app_header( __( 'Audience', 'product-mailer-campaigns' ), array( array( 'label' => __( 'Add Contact', 'product-mailer-campaigns' ), 'url' => '#TB_inline?width=620&height=430&inlineId=pmcpc-add-subscriber-modal', 'class' => 'button-primary thickbox' ) ) );
            $manager->render_page();
            echo '</div>';
        }


    public static function render_diagnostics_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            echo '<div class="wrap">';
            PMCPC_Admin::render_app_header( __( 'System Status', 'product-mailer-campaigns' ) );
            if ( class_exists( 'PMCPC_Diagnostics' ) ) {
                PMCPC_Diagnostics::render_page();
            } else {
                echo '<p>' . esc_html__( 'Health check tools are missing.', 'product-mailer-campaigns' ) . '</p>';
            }

            echo '</div>';
        }

}
