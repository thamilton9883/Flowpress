<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/trait-pmcpc-admin-inbox-helper-methods.php';
require_once __DIR__ . '/trait-pmcpc-admin-inbox-actions-methods.php';
require_once __DIR__ . '/trait-pmcpc-admin-inbox-pages-methods.php';

trait PMCPC_Admin_Inbox_Trait {
    use PMCPC_Admin_Inbox_Helper_Methods;
    use PMCPC_Admin_Inbox_Actions_Methods;
    use PMCPC_Admin_Inbox_Pages_Methods;
}
