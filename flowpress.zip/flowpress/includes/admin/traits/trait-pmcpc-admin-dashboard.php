<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/trait-pmcpc-admin-dashboard-core-methods.php';
require_once __DIR__ . '/trait-pmcpc-admin-dashboard-revenue-methods.php';
require_once __DIR__ . '/trait-pmcpc-admin-dashboard-activity-methods.php';
require_once __DIR__ . '/trait-pmcpc-admin-dashboard-pages-methods.php';

trait PMCPC_Admin_Dashboard_Trait {
    use PMCPC_Admin_Dashboard_Core_Methods;
    use PMCPC_Admin_Dashboard_Revenue_Methods;
    use PMCPC_Admin_Dashboard_Activity_Methods;
    use PMCPC_Admin_Dashboard_Pages_Methods;
}
