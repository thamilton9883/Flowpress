<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Settings_Forms_Methods {
public static function render_forms_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $edit_id = isset( $_GET['pmcpc_edit_form'] ) ? absint( $_GET['pmcpc_edit_form'] ) : 0;
        $editing = ( $edit_id > 0 );

        if ( ! class_exists( 'PMCPC_Forms' ) ) {
            echo '<div class="wrap">'; PMCPC_Admin::render_app_header( __( 'Signup Forms', 'product-mailer-campaigns' ) );
            echo '<p>' . esc_html__( 'Forms support is not available.', 'product-mailer-campaigns' ) . '</p></div>';
            return;
        }

        // Handle duplicate form.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( isset( $_GET['pmcpc_duplicate_form'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ), 'pmcpc_duplicate_form_' . absint( $_GET['pmcpc_duplicate_form'] ) ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $new_id = PMCPC_Forms::duplicate_form( absint( $_GET['pmcpc_duplicate_form'] ) );
            if ( $new_id ) {
                echo '<div class="updated notice"><p>' . esc_html__( 'Form duplicated.', 'product-mailer-campaigns' ) . '</p></div>';
            }
        }

        // Handle add form.
        if ( isset( $_POST['pmcpc_forms_nonce'] ) && wp_verify_nonce( sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_forms_nonce'] ) ), 'pmcpc_save_form' ) ) {
            $name  = isset( $_POST['pmcpc_form_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_form_name'] ) ) : '';
            $type  = isset( $_POST['pmcpc_form_type'] ) ? sanitize_key( wp_unslash( $_POST['pmcpc_form_type'] ) ) : 'contact';
            $title = isset( $_POST['pmcpc_form_title'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_form_title'] ) ) : '';

            $new_id = PMCPC_Forms::add_form(
                array(
                    'name'  => $name,
                    'type'  => $type,
                    'title' => $title,
                )
            );

            // Redirect straight to the edit screen so the user can configure fields/settings.
            $redirect = add_query_arg(
                array(
                    'page'            => 'pmcpc_forms',
                    'pmcpc_edit_form'  => (int) $new_id,
                    'pmcpc_created'    => 1,
                ),
                admin_url( 'admin.php' )
            );
            wp_safe_redirect( $redirect );
            exit;
        }


        // Handle update form.
        if ( isset( $_POST['pmcpc_forms_edit_nonce'] ) && wp_verify_nonce( sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_forms_edit_nonce'] ) ), 'pmcpc_update_form' ) ) {
            $id    = isset( $_POST['pmcpc_form_id'] ) ? absint( wp_unslash( $_POST['pmcpc_form_id'] ) ) : 0;
            $name  = isset( $_POST['pmcpc_form_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_form_name'] ) ) : '';
            $type  = isset( $_POST['pmcpc_form_type'] ) ? sanitize_key( wp_unslash( $_POST['pmcpc_form_type'] ) ) : 'contact';
            $title = isset( $_POST['pmcpc_form_title'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_form_title'] ) ) : '';

            $settings = array(
                'button_label'    => isset( $_POST['pmcpc_button_label'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_button_label'] ) ) : '',
                'success_message' => isset( $_POST['pmcpc_success_message'] ) ? wp_kses_post( (string) wp_unslash( $_POST['pmcpc_success_message'] ) ) : '',
                'recipient_email' => isset( $_POST['pmcpc_recipient_email'] ) ? sanitize_email( (string) wp_unslash( $_POST['pmcpc_recipient_email'] ) ) : '',
                'email_subject'   => isset( $_POST['pmcpc_email_subject'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_email_subject'] ) ) : '',
                'show_subject'    => ( isset( $_POST['pmcpc_show_subject'] ) && 'yes' === sanitize_key( wp_unslash( $_POST['pmcpc_show_subject'] ) ) ) ? 'yes' : 'no',
                'show_optin'      => ( isset( $_POST['pmcpc_show_optin'] ) && 'yes' === sanitize_key( wp_unslash( $_POST['pmcpc_show_optin'] ) ) ) ? 'yes' : 'no',
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below per-field.
                    'fields'         => isset( $_POST['pmcpc_fields'] ) && is_array( $_POST['pmcpc_fields'] ) ? (array) wp_unslash( $_POST['pmcpc_fields'] ) : array(),
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below per-field.
                    'custom_fields'  => isset( $_POST['pmcpc_custom_fields'] ) && is_array( $_POST['pmcpc_custom_fields'] ) ? (array) wp_unslash( $_POST['pmcpc_custom_fields'] ) : array(),
            );

            // Sanitize dynamic field configs (PHPCS: ensure input is sanitized on read).
            $sanitized_fields = array();
            foreach ( (array) $settings['fields'] as $k => $v ) {
                $k = sanitize_key( (string) $k );
                $sanitized_fields[ $k ] = in_array( (string) $v, array( '1', 'yes', 'on', 'true' ), true ) ? '1' : '0';
            }
            $settings['fields'] = $sanitized_fields;

            $sanitized_custom = array();
            foreach ( (array) $settings['custom_fields'] as $row ) {
                if ( ! is_array( $row ) ) {
                    continue;
                }
                $sanitized_custom[] = array(
                    'label'    => isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : '',
                    'key'      => isset( $row['key'] ) ? sanitize_key( (string) $row['key'] ) : '',
                    'type'     => isset( $row['type'] ) ? sanitize_key( (string) $row['type'] ) : 'text',
                    'required' => ! empty( $row['required'] ) ? 1 : 0,
                );
            }
            $settings['custom_fields'] = $sanitized_custom;



            $ok = PMCPC_Forms::update_form(
                $id,
                array(
                    'name'     => $name,
                    'type'     => $type,
                    'title'    => $title,
                    'settings' => $settings,
                )
            );

            if ( $ok ) {
                echo '<div class="updated notice"><p>' . esc_html__( 'Form updated.', 'product-mailer-campaigns' ) . '</p></div>';
                $edit_id = $id;
                $editing = true;
            }
        }

        // Handle delete form.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( isset( $_GET['pmcpc_delete_form'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ), 'pmcpc_delete_form_' . absint( $_GET['pmcpc_delete_form'] ) ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            PMCPC_Forms::delete_form( absint( $_GET['pmcpc_delete_form'] ) );
            echo '<div class="updated notice"><p>' . esc_html__( 'Form deleted.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        $forms     = PMCPC_Forms::get_forms();
        $edit_form = ( $editing && $edit_id ) ? PMCPC_Forms::get_form( $edit_id ) : null;

        echo '<div class="wrap">';
        PMCPC_Admin::render_app_header( __( 'Signup Forms', 'product-mailer-campaigns' ), array( array( 'label' => __( 'Create Form', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_forms&pmcpc_new_form=1' ), 'class' => 'button-primary' ) ) );
        PMCPC_Admin::render_page_intro(
            __( 'Templates for signup, contact, selling, and review forms', 'product-mailer-campaigns' ),
            __( 'Manage reusable frontend forms here, then copy the shortcode into the right page, campaign, or content area.', 'product-mailer-campaigns' ),
            array(
                array(
                    'label' => sprintf(
                        /* translators: %d: number of forms */
                        __( '%d saved forms', 'product-mailer-campaigns' ),
                        count( $forms )
                    ),
                    'icon'  => 'dashicons-feedback',
                ),
                array(
                    'label' => $editing ? __( 'Editing selected form', 'product-mailer-campaigns' ) : __( 'Create and copy shortcodes', 'product-mailer-campaigns' ),
                    'icon'  => 'dashicons-admin-tools',
                ),
            )
        );

        PMCPC_Admin::render_support_panels(
            array(
                array(
                    'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                    'icon'    => 'dashicons-editor-help',
                    'title'   => __( 'Keep forms easy to test', 'product-mailer-campaigns' ),
                    'items'   => array(
                        __( 'Create or edit a form.', 'product-mailer-campaigns' ),
                        __( 'Copy the shortcode into the right page.', 'product-mailer-campaigns' ),
                        __( 'Submit a test entry and confirm it appears in Inbox or Audience.', 'product-mailer-campaigns' ),
                    ),
                ),
                array(
                    'eyebrow' => __( 'Next steps', 'product-mailer-campaigns' ),
                    'icon'    => 'dashicons-arrow-right-alt2',
                    'title'   => __( 'Useful shortcuts', 'product-mailer-campaigns' ),
                    'actions' => array(
                        array( 'label' => __( 'New Form', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_forms&pmcpc_new_form=1' ), 'class' => 'button button-primary' ),
                        array( 'label' => __( 'Open Inbox', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_inbox' ), 'class' => 'button' ),
                    ),
                ),
            )
        );

        if ( ! empty( $forms ) ) {
            $type_counts = array(
                'contact'        => 0,
                'selling'        => 0,
                'subscribe'      => 0,
                'review'         => 0,
                'product_review' => 0,
            );
            foreach ( $forms as $form ) {
                $type = isset( $form['type'] ) ? (string) $form['type'] : '';
                if ( isset( $type_counts[ $type ] ) ) {
                    $type_counts[ $type ]++;
                }
            }
            PMCPC_Admin::render_stats_strip(
                array(
                    array(
                        'label' => __( 'All forms', 'product-mailer-campaigns' ),
                        'value' => (string) count( $forms ),
                        'meta'  => __( 'Reusable form definitions', 'product-mailer-campaigns' ),
                    ),
                    array(
                        'label' => __( 'Contact', 'product-mailer-campaigns' ),
                        'value' => (string) $type_counts['contact'],
                        'meta'  => __( 'General enquiries', 'product-mailer-campaigns' ),
                    ),
                    array(
                        'label' => __( 'Selling', 'product-mailer-campaigns' ),
                        'value' => (string) $type_counts['selling'],
                        'meta'  => __( 'Sell-to-us forms', 'product-mailer-campaigns' ),
                    ),
                    array(
                        'label' => __( 'Reviews', 'product-mailer-campaigns' ),
                        'value' => (string) ( $type_counts['review'] + $type_counts['product_review'] ),
                        'meta'  => __( 'Site and product reviews', 'product-mailer-campaigns' ),
                    ),
                )
            );
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( isset( $_GET['pmcpc_created'] ) ) {
            echo '<div class="updated notice"><p>' . esc_html__( 'Form created. Configure fields and settings below.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        echo '<div class="pmcpc-card">';
        echo '<h2>' . esc_html__( 'Existing forms', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p class="description">' . esc_html__( 'Use the saved forms list as your reusable library, then edit or duplicate a form before copying the shortcode into the right page or workflow.', 'product-mailer-campaigns' ) . '</p>';

        if ( empty( $forms ) ) {
            echo '<p>' . esc_html__( 'No forms have been created yet.', 'product-mailer-campaigns' ) . '</p>';
        } else {
            echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
            echo '<table class="widefat striped pmcpc-wide-table">';
            echo '<thead><tr>';
            echo '<th class="pmcpc-col-compare">' . esc_html__( 'ID', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Name', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-compare">' . esc_html__( 'Type', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-meta">' . esc_html__( 'Title', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-meta">' . esc_html__( 'Shortcode', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-actions">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
            echo '</tr></thead><tbody>';

            foreach ( $forms as $form ) {
                $id    = isset( $form['id'] ) ? (int) $form['id'] : 0;
                $name  = isset( $form['name'] ) ? $form['name'] : '';
                $type  = isset( $form['type'] ) ? $form['type'] : '';
                $title = isset( $form['title'] ) ? $form['title'] : '';

                $shortcode = sprintf( '[pmcpc_form id="%d"]', $id );

                echo '<tr>';
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">#' . esc_html( $id ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Form ID', 'product-mailer-campaigns' ) . '</span></div></td>';
                echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( $name ) . '</span><span class="pmcpc-table-record__meta">' . esc_html( $title ? $title : __( 'No frontend title set yet', 'product-mailer-campaigns' ) ) . '</span></div></td>';
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( ucwords( str_replace( '_', ' ', $type ) ) ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Form type', 'product-mailer-campaigns' ) . '</span></div></td>';
                echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $title ? $title : '—' ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Frontend heading', 'product-mailer-campaigns' ) . '</span></div></td>';
                echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main"><code class="pmcpc-shortcode" data-sc="' . esc_attr( $shortcode ) . '">' . esc_html( $shortcode ) . '</code></span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Paste into a page or block', 'product-mailer-campaigns' ) . '</span></div></td>';
                echo '<td class="pmcpc-col-actions">';

                $edit_url = add_query_arg(
                    array(
                        'page'           => 'pmcpc_forms',
                        'pmcpc_edit_form' => $id,
                    ),
                    admin_url( 'admin.php' )
                );

                $dup_url = wp_nonce_url(
                    add_query_arg(
                        array(
                            'page'                => 'pmcpc_forms',
                            'pmcpc_duplicate_form' => $id,
                        ),
                        admin_url( 'admin.php' )
                    ),
                    'pmcpc_duplicate_form_' . $id
                );

                $delete_url = wp_nonce_url(
                    add_query_arg(
                        array(
                            'page'            => 'pmcpc_forms',
                            'pmcpc_delete_form' => $id,
                        ),
                        admin_url( 'admin.php' )
                    ),
                    'pmcpc_delete_form_' . $id
                );

                echo '<div class="pmcpc-table-actions">';
                echo '<div class="pmcpc-table-actions__primary">';
                echo '<a href="' . esc_url( $edit_url ) . '" class="button button-small button-primary">' . esc_html__( 'Edit', 'product-mailer-campaigns' ) . '</a>';
                echo '</div>';
                echo '<div class="pmcpc-table-actions__secondary">';
                echo '<a href="' . esc_url( $dup_url ) . '" class="button button-small">' . esc_html__( 'Duplicate', 'product-mailer-campaigns' ) . '</a>';
                echo '<button type="button" class="button button-small pmcpc-copy-shortcode" data-sc="' . esc_attr( $shortcode ) . '">' . esc_html__( 'Copy shortcode', 'product-mailer-campaigns' ) . '</button>';
                echo '<a href="' . esc_url( $delete_url ) . '" class="button button-small button-link-delete" onclick="return confirm(\'Are you sure you want to delete this form?\');">' . esc_html__( 'Delete', 'product-mailer-campaigns' ) . '</a>';
                echo '</div>';
                echo '</div>';

                echo '</td>';
                echo '</tr>';
            }

            echo '</tbody></table>';
            echo '</div></div>';
        }
        echo '</div>';

        // Copy-to-clipboard helper.
        echo '<script>
        (function(){
            function copyText(t){
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(t);
                    return;
                }
                var ta=document.createElement("textarea");
                ta.value=t; document.body.appendChild(ta);
                ta.select(); document.execCommand("copy");
                document.body.removeChild(ta);
            }
            document.addEventListener("click", function(e){
                var btn = e.target && e.target.classList && e.target.classList.contains("pmcpc-copy-shortcode") ? e.target : null;
                if (!btn) return;
                copyText(btn.getAttribute("data-sc") || "");
                btn.innerText = "' . esc_js( __( 'Copied!', 'product-mailer-campaigns' ) ) . '";
                setTimeout(function(){ btn.innerText="' . esc_js( __( 'Copy shortcode', 'product-mailer-campaigns' ) ) . '"; }, 900);
            });
        })();
        </script>';

        echo '<div class="pmcpc-card">';

        if ( $editing && $edit_form ) {
            $type     = isset( $edit_form['type'] ) ? $edit_form['type'] : 'contact';
            $settings = ( isset( $edit_form['settings'] ) && is_array( $edit_form['settings'] ) ) ? $edit_form['settings'] : PMCPC_Forms::default_settings( $type );

            echo '<h2>' . esc_html__( 'Edit form', 'product-mailer-campaigns' ) . ' #' . esc_html( (int) $edit_form['id'] ) . '</h2>';
            echo '<p class="description">' . esc_html__( 'Update the saved reusable form here, including field visibility, routing, and additional form inputs.', 'product-mailer-campaigns' ) . '</p>';
            echo '<p><a href="' . esc_url( add_query_arg( array( 'page' => 'pmcpc_forms' ), admin_url( 'admin.php' ) ) ) . '">' . esc_html__( '← Back to forms list', 'product-mailer-campaigns' ) . '</a></p>';

            echo '<form method="post">';
            wp_nonce_field( 'pmcpc_update_form', 'pmcpc_forms_edit_nonce' );
            echo '<input type="hidden" name="pmcpc_form_id" value="' . esc_attr( (int) $edit_form['id'] ) . '" />';

            echo '<table class="form-table" role="presentation">';

            echo '<tr>';
            echo '<th scope="row"><label for="pmcpc_form_name">' . esc_html__( 'Internal name', 'product-mailer-campaigns' ) . '</label></th>';
            echo '<td><input type="text" id="pmcpc_form_name" name="pmcpc_form_name" class="regular-text" value="' . esc_attr( isset( $edit_form['name'] ) ? $edit_form['name'] : '' ) . '" />';
            echo '<p class="description">' . esc_html__( 'Only shown in the admin. Helps you identify where the form is used.', 'product-mailer-campaigns' ) . '</p></td>';
            echo '</tr>';

            echo '<tr>';
            echo '<th scope="row"><label for="pmcpc_form_type">' . esc_html__( 'Form type', 'product-mailer-campaigns' ) . '</label></th>';
            echo '<td><select id="pmcpc_form_type" name="pmcpc_form_type">';
            echo '<option value="contact" ' . selected( $type, 'contact', false ) . '>' . esc_html__( 'Contact form', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="selling" ' . selected( $type, 'selling', false ) . '>' . esc_html__( 'Selling enquiry form', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="subscribe" ' . selected( $type, 'subscribe', false ) . '>' . esc_html__( 'Subscribe form', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="review" ' . selected( $type, 'review', false ) . '>' . esc_html__( 'Review form', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="product_review" ' . selected( $type, 'product_review', false ) . '>' . esc_html__( 'Product review form', 'product-mailer-campaigns' ) . '</option>';
            echo '</select>';
            echo '<p class="description">' . esc_html__( 'Changing type will reset incompatible settings to sensible defaults.', 'product-mailer-campaigns' ) . '</p></td>';
            echo '</tr>';

            echo '<tr>';
            echo '<th scope="row"><label for="pmcpc_form_title">' . esc_html__( 'Form title', 'product-mailer-campaigns' ) . '</label></th>';
            echo '<td><input type="text" id="pmcpc_form_title" name="pmcpc_form_title" class="regular-text" value="' . esc_attr( isset( $edit_form['title'] ) ? $edit_form['title'] : '' ) . '" />';
            echo '<p class="description">' . esc_html__( 'Heading shown above the form on the frontend.', 'product-mailer-campaigns' ) . '</p></td>';
            echo '</tr>';

            echo '<tr>';
            echo '<th scope="row"><label for="pmcpc_button_label">' . esc_html__( 'Button label', 'product-mailer-campaigns' ) . '</label></th>';
            echo '<td><input type="text" id="pmcpc_button_label" name="pmcpc_button_label" class="regular-text" value="' . esc_attr( isset( $settings['button_label'] ) ? $settings['button_label'] : '' ) . '" />';
            echo '<p class="description">' . esc_html__( 'Text on the submit button.', 'product-mailer-campaigns' ) . '</p></td>';
            echo '</tr>';

            echo '<tr>';
            echo '<th scope="row"><label for="pmcpc_success_message">' . esc_html__( 'Success message', 'product-mailer-campaigns' ) . '</label></th>';
            echo '<td><textarea id="pmcpc_success_message" name="pmcpc_success_message" class="large-text" rows="3">' . esc_textarea( isset( $settings['success_message'] ) ? wp_strip_all_tags( (string) $settings['success_message'] ) : '' ) . '</textarea>';
            echo '<p class="description">' . esc_html__( 'Shown after a successful submit. You can use basic HTML.', 'product-mailer-campaigns' ) . '</p></td>';
            echo '</tr>';

            echo '<tr>';
            echo '<th scope="row">' . esc_html__( 'Email routing', 'product-mailer-campaigns' ) . '</th>';
            echo '<td>';
            echo '<p><label for="pmcpc_recipient_email">' . esc_html__( 'Send to (optional)', 'product-mailer-campaigns' ) . '</label><br />';
            echo '<input type="email" id="pmcpc_recipient_email" name="pmcpc_recipient_email" class="regular-text" value="' . esc_attr( isset( $settings['recipient_email'] ) ? $settings['recipient_email'] : '' ) . '" />';
            echo '<span class="description"> ' . esc_html__( 'Leave empty to use the site admin email.', 'product-mailer-campaigns' ) . '</span></p>';
            echo '<p><label for="pmcpc_email_subject">' . esc_html__( 'Email subject (optional)', 'product-mailer-campaigns' ) . '</label><br />';
            echo '<input type="text" id="pmcpc_email_subject" name="pmcpc_email_subject" class="regular-text" value="' . esc_attr( isset( $settings['email_subject'] ) ? $settings['email_subject'] : '' ) . '" /></p>';
            echo '</td>';
            echo '</tr>';

            echo '<tr>';
            echo '<th scope="row">' . esc_html__( 'Form options', 'product-mailer-campaigns' ) . '</th>';
            echo '<td><fieldset>';
            echo '<input type="hidden" name="pmcpc_show_subject" value="no" />';
            echo '<label><input type="checkbox" name="pmcpc_show_subject" value="yes" ' . checked( isset( $settings['show_subject'] ) ? $settings['show_subject'] : 'yes', 'yes', false ) . ' /> ' . esc_html__( 'Show subject field', 'product-mailer-campaigns' ) . '</label><br />';
            echo '<input type="hidden" name="pmcpc_show_optin" value="no" />';
            echo '<label><input type="checkbox" name="pmcpc_show_optin" value="yes" ' . checked( isset( $settings['show_optin'] ) ? $settings['show_optin'] : 'yes', 'yes', false ) . ' /> ' . esc_html__( 'Show opt-in checkbox', 'product-mailer-campaigns' ) . '</label>';
            echo '<p class="description">' . esc_html__( 'These apply to Contact and Selling forms. Subscribe forms ignore these options.', 'product-mailer-campaigns' ) . '</p>';
            echo '</fieldset></td>';
            echo '</tr>';

            // Field editor (applies to dynamic forms: [pmcpc_form id="..."]). Legacy shortcodes remain unchanged.
            $field_defs = PMCPC_Forms::default_fields( $type );
            $saved_fields = isset( $settings['fields'] ) && is_array( $settings['fields'] ) ? $settings['fields'] : array();
            // Normalize saved fields through sanitizer so new keys appear automatically.
            $fields = PMCPC_Forms::sanitize_fields( $saved_fields, $type );

            echo '<tr>';
            echo '<th scope="row">' . esc_html__( 'Fields', 'product-mailer-campaigns' ) . '</th>';
            echo '<td>';

            echo '<p class="description">' . esc_html__( 'Choose which fields are shown for this form when used via the dynamic shortcode. Required fields are locked on.', 'product-mailer-campaigns' ) . '</p>';

            echo '<table class="widefat striped" style="max-width:900px">';
            echo '<thead><tr>';
            echo '<th style="width:90px">' . esc_html__( 'Enabled', 'product-mailer-campaigns' ) . '</th>';
            echo '<th style="width:90px">' . esc_html__( 'Required', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Label', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Placeholder', 'product-mailer-campaigns' ) . '</th>';
            echo '</tr></thead><tbody>';

            foreach ( $field_defs as $key => $def ) {
                $row = isset( $fields[ $key ] ) ? $fields[ $key ] : $def;

                $locked_required = false;
                $locked_enabled  = false;
                if ( 'contact' === $type && in_array( $key, array( 'email', 'message' ), true ) ) {
                    $locked_required = true;
                    $locked_enabled  = true;
                }
                if ( 'selling' === $type && in_array( $key, array( 'email', 'details' ), true ) ) {
                    $locked_required = true;
                    $locked_enabled  = true;
                }
                if ( 'subscribe' === $type && 'email' === $key ) {
                    $locked_required = true;
                    $locked_enabled  = true;
                }
                if ( in_array( $type, array( 'review', 'product_review' ), true ) && in_array( $key, array( 'email', 'message', 'rating' ), true ) ) {
                    $locked_required = true;
                    $locked_enabled  = true;
                }
                if ( 'product_review' === $type && 'product_id' === $key ) {
                    $locked_enabled = true;
                }

                $name_base = 'pmcpc_fields[' . esc_attr( $key ) . ']';

                echo '<tr>';
                echo '<td>';
                // hidden default.
                echo '<input type="hidden" name="' . esc_attr( $name_base ) . '[enabled]" value="no" />';
                $enabled_checked = ( isset( $row['enabled'] ) ? $row['enabled'] : 'yes' );
                echo '<label><input type="checkbox" name="' . esc_attr( $name_base ) . '[enabled]" value="yes" ' . checked( $enabled_checked, 'yes', false ) . ( $locked_enabled ? ' disabled="disabled"' : '' ) . ' /> ' . esc_html( ucfirst( (string) $key ) ) . '</label>';
                if ( $locked_enabled ) {
                    echo '<input type="hidden" name="' . esc_attr( $name_base ) . '[enabled]" value="yes" />';
                }
                echo '</td>';

                echo '<td>';
                echo '<input type="hidden" name="' . esc_attr( $name_base ) . '[required]" value="no" />';
                $required_checked = ( isset( $row['required'] ) ? $row['required'] : ( isset( $def['required'] ) ? $def['required'] : 'no' ) );
                echo '<label><input type="checkbox" name="' . esc_attr( $name_base ) . '[required]" value="yes" ' . checked( $required_checked, 'yes', false ) . ( $locked_required ? ' disabled="disabled"' : '' ) . ' /></label>';
                if ( $locked_required ) {
                    echo '<input type="hidden" name="' . esc_attr( $name_base ) . '[required]" value="yes" />';
                }
                echo '</td>';

                echo '<td><input type="text" class="regular-text" name="' . esc_attr( $name_base ) . '[label]" value="' . esc_attr( isset( $row['label'] ) ? $row['label'] : '' ) . '" /></td>';
                echo '<td><input type="text" class="regular-text" name="' . esc_attr( $name_base ) . '[placeholder]" value="' . esc_attr( isset( $row['placeholder'] ) ? $row['placeholder'] : '' ) . '" /></td>';
                echo '</tr>';
            }

            echo '</tbody></table>';
            echo '<p class="description">' . esc_html__( 'Tip: These settings affect [pmcpc_form id="..."] only. The legacy shortcodes like [pmcpc_contact_form] are unchanged.', 'product-mailer-campaigns' ) . '</p>';

            echo '</td>';
            echo '</tr>';

            
            // Additional fields (text/textarea/file upload) for dynamic forms only.
            $custom_fields = isset( $settings['custom_fields'] ) && is_array( $settings['custom_fields'] ) ? $settings['custom_fields'] : array();
            $custom_fields = PMCPC_Forms::sanitize_custom_fields( $custom_fields );

            echo '<tr>';
            echo '<th scope="row">' . esc_html__( 'Additional fields', 'product-mailer-campaigns' ) . '</th>';
            echo '<td>';

            echo '<p class="description">' . esc_html__( 'Add extra fields (including multiple file uploads) for this dynamic form. These do not affect legacy shortcodes.', 'product-mailer-campaigns' ) . '</p>';

            echo '<table class="widefat striped" id="pmcpc-custom-fields-table" style="max-width:900px">';
            echo '<thead><tr>';
            echo '<th style="width:80px">' . esc_html__( 'Enabled', 'product-mailer-campaigns' ) . '</th>';
            echo '<th style="width:120px">' . esc_html__( 'Type', 'product-mailer-campaigns' ) . '</th>';
            echo '<th style="width:140px">' . esc_html__( 'Key', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Label', 'product-mailer-campaigns' ) . '</th>';
            echo '<th>' . esc_html__( 'Placeholder', 'product-mailer-campaigns' ) . '</th>';
            echo '<th style="width:90px">' . esc_html__( 'Required', 'product-mailer-campaigns' ) . '</th>';
            echo '<th style="width:110px">' . esc_html__( 'Max files', 'product-mailer-campaigns' ) . '</th>';
            echo '<th style="width:90px">' . esc_html__( 'Remove', 'product-mailer-campaigns' ) . '</th>';
            echo '</tr></thead><tbody>';

            $i = 0;
            if ( ! empty( $custom_fields ) ) {
                foreach ( $custom_fields as $row ) {
                    $base = 'pmcpc_custom_fields[' . (int) $i . ']';
                    $enabled  = isset( $row['enabled'] ) ? $row['enabled'] : 'yes';
                    $required = isset( $row['required'] ) ? $row['required'] : 'no';
                    $typev    = isset( $row['type'] ) ? $row['type'] : 'text';
                    $keyv     = isset( $row['key'] ) ? $row['key'] : '';
                    $labelv   = isset( $row['label'] ) ? $row['label'] : '';
                    $phv      = isset( $row['placeholder'] ) ? $row['placeholder'] : '';
                    $maxf     = isset( $row['max_files'] ) ? (int) $row['max_files'] : 5;

                    echo '<tr class="pmcpc-cf-row">';
                    echo '<td><input type="hidden" name="' . esc_attr( $base ) . '[enabled]" value="no" /><input type="checkbox" name="' . esc_attr( $base ) . '[enabled]" value="yes" ' . checked( $enabled, 'yes', false ) . ' /></td>';
                    echo '<td><select name="' . esc_attr( $base ) . '[type]" class="pmcpc-cf-type">';
                    echo '<option value="text" ' . selected( $typev, 'text', false ) . '>' . esc_html__( 'Text', 'product-mailer-campaigns' ) . '</option>';
                    echo '<option value="textarea" ' . selected( $typev, 'textarea', false ) . '>' . esc_html__( 'Textarea', 'product-mailer-campaigns' ) . '</option>';
                    echo '<option value="file" ' . selected( $typev, 'file', false ) . '>' . esc_html__( 'File upload', 'product-mailer-campaigns' ) . '</option>';
                    echo '</select></td>';
                    echo '<td><input type="text" name="' . esc_attr( $base ) . '[key]" value="' . esc_attr( $keyv ) . '" placeholder="e.g. photos" /></td>';
                    echo '<td><input type="text" name="' . esc_attr( $base ) . '[label]" value="' . esc_attr( $labelv ) . '" /></td>';
                    echo '<td><input type="text" name="' . esc_attr( $base ) . '[placeholder]" value="' . esc_attr( $phv ) . '" /></td>';
                    echo '<td><input type="hidden" name="' . esc_attr( $base ) . '[required]" value="no" /><input type="checkbox" name="' . esc_attr( $base ) . '[required]" value="yes" ' . checked( $required, 'yes', false ) . ' /></td>';
                    echo '<td><input type="number" min="1" max="10" class="small-text pmcpc-cf-maxfiles" name="' . esc_attr( $base ) . '[max_files]" value="' . esc_attr( $maxf ) . '" /></td>';
                    echo '<td><button type="button" class="button pmcpc-cf-remove">' . esc_html__( 'Remove', 'product-mailer-campaigns' ) . '</button></td>';
                    echo '</tr>';

                    $i++;
                }
            }

            echo '</tbody></table>';
            echo '<p><button type="button" class="button" id="pmcpc-add-custom-field">' . esc_html__( 'Add field', 'product-mailer-campaigns' ) . '</button></p>';

            // Row template (hidden).
            echo '<script type="text/template" id="pmcpc-cf-row-tpl">';
            echo '<tr class="pmcpc-cf-row">';
            echo '<td><input type="hidden" name="__BASE__[enabled]" value="no" /><input type="checkbox" name="__BASE__[enabled]" value="yes" checked="checked" /></td>';
            echo '<td><select name="__BASE__[type]" class="pmcpc-cf-type">';
            echo '<option value="text">' . esc_html__( 'Text', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="textarea">' . esc_html__( 'Textarea', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="file">' . esc_html__( 'File upload', 'product-mailer-campaigns' ) . '</option>';
            echo '</select></td>';
            echo '<td><input type="text" name="__BASE__[key]" value="" placeholder="e.g. photos" /></td>';
            echo '<td><input type="text" name="__BASE__[label]" value="" /></td>';
            echo '<td><input type="text" name="__BASE__[placeholder]" value="" /></td>';
            echo '<td><input type="hidden" name="__BASE__[required]" value="no" /><input type="checkbox" name="__BASE__[required]" value="yes" /></td>';
            echo '<td><input type="number" min="1" max="10" class="small-text pmcpc-cf-maxfiles" name="__BASE__[max_files]" value="5" /></td>';
            echo '<td><button type="button" class="button pmcpc-cf-remove">' . esc_html__( 'Remove', 'product-mailer-campaigns' ) . '</button></td>';
            echo '</tr>';
            echo '</script>';

            echo '<script>
            (function(){
                var table = document.getElementById("pmcpc-custom-fields-table");
                if (!table) return;
                var btn = document.getElementById("pmcpc-add-custom-field");
                var tpl = document.getElementById("pmcpc-cf-row-tpl");
                var idx = ' . (int) $i . ';
                function refreshRow(row){
                    var sel = row.querySelector(".pmcpc-cf-type");
                    var max = row.querySelector(".pmcpc-cf-maxfiles");
                    if (!sel || !max) return;
                    if (sel.value === "file") {
                        max.removeAttribute("disabled");
                        max.style.opacity = "1";
                    } else {
                        max.setAttribute("disabled","disabled");
                        max.style.opacity = "0.5";
                    }
                }
                table.addEventListener("change", function(e){
                    if (e.target && e.target.classList && e.target.classList.contains("pmcpc-cf-type")){
                        refreshRow(e.target.closest("tr"));
                    }
                });
                table.addEventListener("click", function(e){
                    if (e.target && e.target.classList && e.target.classList.contains("pmcpc-cf-remove")){
                        var tr = e.target.closest("tr");
                        if (tr) tr.parentNode.removeChild(tr);
                    }
                });
                if (btn && tpl){
                    btn.addEventListener("click", function(){
                        var base = "pmcpc_custom_fields[" + idx + "]";
                        var html = tpl.innerHTML.replace(/__BASE__/g, base);
                        table.querySelector("tbody").insertAdjacentHTML("beforeend", html);
                        var rows = table.querySelectorAll("tr.pmcpc-cf-row");
                        var last = rows[rows.length-1];
                        refreshRow(last);
                        idx++;
                    });
                }
                // Init existing rows.
                var rows = table.querySelectorAll("tr.pmcpc-cf-row");
                for (var i=0;i<rows.length;i++){ refreshRow(rows[i]); }
            })();
            </script>';

            echo '</td>';
            echo '</tr>';

echo '</tbody></table>';

            submit_button( __( 'Save changes', 'product-mailer-campaigns' ) );
            echo '</form>';
            echo '</div>';
        } else {
            echo '<div class="pmcpc-card">';
            echo '<h2>' . esc_html__( 'Create a new form', 'product-mailer-campaigns' ) . '</h2>';
            echo '<p class="description">' . esc_html__( 'Start with the internal name and type, then create the form and finish the detailed configuration on the edit screen.', 'product-mailer-campaigns' ) . '</p>';

            echo '<form method="post">';
            wp_nonce_field( 'pmcpc_save_form', 'pmcpc_forms_nonce' );

            echo '<table class="form-table" role="presentation">';
            echo '<tr>';
            echo '<th scope="row"><label for="pmcpc_form_name">' . esc_html__( 'Internal name', 'product-mailer-campaigns' ) . '</label></th>';
            echo '<td><input type="text" id="pmcpc_form_name" name="pmcpc_form_name" class="regular-text" />';
            echo '<p class="description">' . esc_html__( 'Only shown in the admin. Helps you identify where the form is used (e.g. “Homepage contact”, “Sell page form”).', 'product-mailer-campaigns' ) . '</p></td>';
            echo '</tr>';

            echo '<tr>';
            echo '<th scope="row"><label for="pmcpc_form_type">' . esc_html__( 'Form type', 'product-mailer-campaigns' ) . '</label></th>';
            echo '<td><select id="pmcpc_form_type" name="pmcpc_form_type">';
            echo '<option value="contact">' . esc_html__( 'Contact form', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="selling">' . esc_html__( 'Selling enquiry form', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="subscribe">' . esc_html__( 'Subscribe form', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="review">' . esc_html__( 'Review form', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="product_review">' . esc_html__( 'Product review form', 'product-mailer-campaigns' ) . '</option>';
            echo '</select>';
            echo '<p class="description">' . esc_html__( 'Choose what kind of form to output. Subscribe forms use your main PMCPC subscribe form logic.', 'product-mailer-campaigns' ) . '</p></td>';
            echo '</tr>';

            echo '<tr>';
            echo '<th scope="row"><label for="pmcpc_form_title">' . esc_html__( 'Form title', 'product-mailer-campaigns' ) . '</label></th>';
            echo '<td><input type="text" id="pmcpc_form_title" name="pmcpc_form_title" class="regular-text" />';
            echo '<p class="description">' . esc_html__( 'Heading shown above the form on the frontend. Leave empty to use a sensible default.', 'product-mailer-campaigns' ) . '</p></td>';
            echo '</tr>';

            echo '</tbody></table>';

            submit_button( __( 'Create form', 'product-mailer-campaigns' ) );

            echo '</form>';
            echo '</div>';
        }

        echo '</div>';
    }


}
