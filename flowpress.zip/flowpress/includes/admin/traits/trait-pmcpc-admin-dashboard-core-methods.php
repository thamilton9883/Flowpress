<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Dashboard_Core_Methods {


        protected static function pmcpc_dashboard_section_open( $key, $title, $meta = '' ) {
            $section_key = sanitize_key( (string) $key );
            $storage_key = 'pmcpc_dashboard_group_' . $section_key;
            $section_id  = 'pmcpc-dashboard-group-' . $section_key;
            echo '<div id="' . esc_attr( $section_id ) . '" class="pmcpc-dashboard-group" data-storage-key="' . esc_attr( $storage_key ) . '">';
            echo '<button type="button" class="pmcpc-dashboard-group__toggle" aria-expanded="true">';
            echo '<div><h3>' . esc_html( $title ) . '</h3>';
            if ( '' !== (string) $meta ) {
                echo '<div class="pmcpc-dashboard-group__meta">' . esc_html( (string) $meta ) . '</div>';
            }
            echo '</div>';
            echo '<span class="pmcpc-dashboard-group__chevron" aria-hidden="true">⌃</span>';
            echo '</button>';
            echo '<div class="pmcpc-dashboard-group__body">';
        }


        protected static function pmcpc_dashboard_section_close() {
            echo '</div>';
            echo '</div>';
        }


        protected static function pmcpc_dashboard_format_ts_value( $ts ) {
            $ts = absint( $ts );
            if ( ! $ts ) {
                return __( '—', 'product-mailer-campaigns' );
            }
            return date_i18n( 'Y-m-d H:i', $ts );
        }


        protected static function pmcpc_dashboard_format_mysql_value( $mysql ) {
            if ( empty( $mysql ) ) {
                return __( '—', 'product-mailer-campaigns' );
            }
            $ts = strtotime( (string) $mysql );
            if ( ! $ts ) {
                return (string) $mysql;
            }
            return date_i18n( 'Y-m-d H:i', $ts );
        }


        protected static function pmcpc_dashboard_mask_email( $email ) {
            $email = sanitize_email( (string) $email );
            if ( '' === $email || false === strpos( $email, '@' ) ) {
                return $email;
            }
            list( $local, $domain ) = explode( '@', $email, 2 );
            if ( strlen( $local ) <= 3 ) {
                $local = substr( $local, 0, 1 ) . '***';
            } else {
                $local = substr( $local, 0, 3 ) . '***';
            }
            return $local . '@' . $domain;
        }


        protected static function pmcpc_dashboard_status_label( $status ) {
            $status = sanitize_key( (string) $status );
            $map = array(
                'active'       => __( 'Active', 'product-mailer-campaigns' ),
                'needs_setup'  => __( 'Needs setup', 'product-mailer-campaigns' ),
                'inactive'     => __( 'Inactive', 'product-mailer-campaigns' ),
                'scheduled'    => __( 'Scheduled', 'product-mailer-campaigns' ),
                'not_created'  => __( 'Not created', 'product-mailer-campaigns' ),
                'needs_data'   => __( 'Needs setup', 'product-mailer-campaigns' ),
                'draft'        => __( 'Needs setup', 'product-mailer-campaigns' ),
                'paused'       => __( 'Inactive', 'product-mailer-campaigns' ),
            );
            return isset( $map[ $status ] ) ? $map[ $status ] : ucfirst( str_replace( '_', ' ', $status ) );
        }


        protected static function pmcpc_dashboard_status_action_label( $status, $has_campaign, $trigger_key = '' ) {
            $status = sanitize_key( (string) $status );
            $trigger_key = sanitize_key( (string) $trigger_key );
            if ( 'scheduled' === $status && 'date' === $trigger_key ) {
                return __( 'View schedules', 'product-mailer-campaigns' );
            }
            if ( 'active' === $status ) {
                return ( 'date' === $trigger_key ) ? __( 'Edit campaign', 'product-mailer-campaigns' ) : __( 'Edit workflow', 'product-mailer-campaigns' );
            }
            if ( 'needs_setup' === $status ) {
                return __( 'Complete setup', 'product-mailer-campaigns' );
            }
            if ( 'inactive' === $status ) {
                return $has_campaign ? __( 'Enable workflow', 'product-mailer-campaigns' ) : __( 'Create automation', 'product-mailer-campaigns' );
            }
            return __( 'Create automation', 'product-mailer-campaigns' );
        }

}
