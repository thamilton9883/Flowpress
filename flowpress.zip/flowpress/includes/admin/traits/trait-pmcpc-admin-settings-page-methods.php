<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Settings_Page_Methods {
public static function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $nonce = isset( $_POST['pmcpc_settings_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_settings_nonce'] ) ) : '';
        if ( $nonce && wp_verify_nonce( $nonce, 'pmcpc_save_settings' ) ) {
            $tab = isset( $_POST['pmcpc_settings_tab'] ) ? sanitize_key( (string) wp_unslash( $_POST['pmcpc_settings_tab'] ) ) : 'email';
            $values = array();
            $save_notices = array();

            switch ( $tab ) {
                case 'email':
                    $values['from_name_default']  = isset( $_POST['pmcpc_from_name_default'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_from_name_default'] ) ) : PMCPC_Settings::get( 'from_name_default', '' );
                    $values['from_email_default'] = isset( $_POST['pmcpc_from_email_default'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_from_email_default'] ) ) : PMCPC_Settings::get( 'from_email_default', '' );
                    if ( isset( $_POST['pmcpc_queue_batch_size'] ) ) {
                        $values['queue_batch_size'] = max( 1, absint( $_POST['pmcpc_queue_batch_size'] ) );
                    }
                    $values['pause_sending']             = isset( $_POST['pmcpc_pause_sending'] ) ? 'yes' : 'no';
                    $values['notify_admin_double_optin'] = isset( $_POST['pmcpc_notify_double_optin'] ) ? 'yes' : 'no';
                    $values['notify_admin_email']        = isset( $_POST['pmcpc_notify_email'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_notify_email'] ) ) : PMCPC_Settings::get( 'notify_admin_email', '' );

                    // Subscription behaviour / routing shown on this tab.
                    $values['guest_double_optin'] = isset( $_POST['pmcpc_guest_double_optin'] ) ? 'yes' : 'no';
                    $values['email_prefs_url']    = isset( $_POST['pmcpc_email_prefs_url'] ) ? esc_url_raw( (string) wp_unslash( $_POST['pmcpc_email_prefs_url'] ) ) : PMCPC_Settings::get( 'email_prefs_url', '' );

                    // Front-end subscribe popup.
                    $values['subscribe_popup_enabled'] = isset( $_POST['pmcpc_subscribe_popup_enabled'] ) ? 'yes' : 'no';
                    if ( isset( $_POST['pmcpc_subscribe_popup_delay_ms'] ) ) {
                        $values['subscribe_popup_delay_ms'] = max( 0, min( 60000, absint( $_POST['pmcpc_subscribe_popup_delay_ms'] ) ) );
                    }
                    if ( isset( $_POST['pmcpc_subscribe_popup_days_between'] ) ) {
                        $values['subscribe_popup_days_between'] = max( 0, min( 365, absint( wp_unslash( $_POST['pmcpc_subscribe_popup_days_between'] ) ) ) );
                    }

                    // SMTP settings (stored as separate option).
                    if ( isset( $_POST['pmcpc_smtp_settings'] ) && is_array( $_POST['pmcpc_smtp_settings'] ) ) {
                        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per-field below.
                        $raw = (array) wp_unslash( $_POST['pmcpc_smtp_settings'] );
                        $smtp = array(
                            'enabled'    => ! empty( $raw['enabled'] ) ? 'yes' : 'no',
                            'host'       => isset( $raw['host'] ) ? sanitize_text_field( (string) $raw['host'] ) : '',
                            'port'       => isset( $raw['port'] ) ? absint( $raw['port'] ) : 0,
                            'encryption' => isset( $raw['encryption'] ) ? sanitize_text_field( (string) $raw['encryption'] ) : '',
                            'auth'       => ! empty( $raw['auth'] ) ? 'yes' : 'no',
                            'username'   => isset( $raw['username'] ) ? sanitize_text_field( (string) $raw['username'] ) : '',
                            'password'   => isset( $raw['password'] ) ? (string) $raw['password'] : '',
                            'from_email' => isset( $raw['from_email'] ) ? sanitize_email( $raw['from_email'] ) : '',
                            'from_name'  => isset( $raw['from_name'] ) ? sanitize_text_field( (string) $raw['from_name'] ) : '',
                        );
                        update_option( 'pmcpc_smtp_settings', $smtp );
                    }
                    break;

                case 'subscribers':
                    $values['wc_opt_in_default_checked']  = isset( $_POST['pmcpc_wc_opt_in_default_checked'] ) ? 'yes' : 'no';
                    $values['wc_register_opt_in_enabled'] = isset( $_POST['pmcpc_wc_register_opt_in_enabled'] ) ? 'yes' : 'no';
                    $values['guest_double_optin']         = isset( $_POST['pmcpc_guest_double_optin'] ) ? 'yes' : 'no';

                    // Front-end subscribe popup settings.
                    $values['subscribe_popup_enabled'] = isset( $_POST['pmcpc_subscribe_popup_enabled'] ) ? 'yes' : 'no';
                    if ( isset( $_POST['pmcpc_subscribe_popup_delay_ms'] ) ) {
                        $values['subscribe_popup_delay_ms'] = max( 0, min( 60000, absint( $_POST['pmcpc_subscribe_popup_delay_ms'] ) ) );
                    }
                    if ( isset( $_POST['pmcpc_subscribe_popup_days_between'] ) ) {
                        $values['subscribe_popup_days_between'] = max( 0, min( 365, absint( wp_unslash( $_POST['pmcpc_subscribe_popup_days_between'] ) ) ) );
                    }
                    $values['blocked_email_domains']      = isset( $_POST['pmcpc_blocked_email_domains'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['pmcpc_blocked_email_domains'] ) ) : PMCPC_Settings::get( 'blocked_email_domains', '' );

// Normalize + validate blocked domains, and prevent blocking protected/shared providers.
$raw_domains = is_string( $values['blocked_email_domains'] ) ? $values['blocked_email_domains'] : '';
$lines = preg_split( '/\r\n|\r|\n/', (string) $raw_domains );
$lines = is_array( $lines ) ? $lines : array();
$clean = array();
$removed_protected = array();

foreach ( $lines as $line ) {
    $d = strtolower( trim( (string) $line ) );
    $d = ltrim( $d, "@ \t" );
    if ( '' === $d ) {
        continue;
    }
    // Basic domain sanity.
    if ( ! preg_match( '/^[a-z0-9][a-z0-9\-\.]*\.[a-z0-9\-\.]+$/', $d ) ) {
        continue;
    }
    // Prevent accidental blocking of major/shared providers (and any domains in the protected list).
    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'is_auto_block_protected_domain' ) ) {
        if ( PMCPC_Subscriber_Manager::is_auto_block_protected_domain( $d ) ) {
            $removed_protected[] = $d;
            continue;
        }
    }
    $clean[] = $d;
}

$clean = array_values( array_unique( $clean ) );
$values['blocked_email_domains'] = implode( "\n", $clean );

if ( ! empty( $removed_protected ) ) {
    $removed_protected = array_values( array_unique( $removed_protected ) );
    $save_notices[] = array(
        'type' => 'warning',
        /* translators: %s: comma-separated list of domains */
        'text' => sprintf( __( 'Some domains were removed from “Additional blocked domains” because they are protected/shared providers: %s. If you need to block a specific sender, block the full email address instead.', 'product-mailer-campaigns' ), esc_html( implode( ', ', $removed_protected ) ) ),
    );
}

                    $values['blocked_domains_auto_add']   = isset( $_POST['pmcpc_blocked_domains_auto_add'] ) ? 'yes' : 'no';
                    $values['email_prefs_url']            = isset( $_POST['pmcpc_email_prefs_url'] ) ? esc_url_raw( wp_unslash( $_POST['pmcpc_email_prefs_url'] ) ) : PMCPC_Settings::get( 'email_prefs_url', '' );

                    // Additional blocked emails (one per line). Stored separately for fast lookup.
                    $blocked_emails_raw = isset( $_POST['pmcpc_blocked_emails'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['pmcpc_blocked_emails'] ) ) : '';
                    if ( is_array( $blocked_emails_raw ) ) {
                        $blocked_emails_raw = '';
                    }
                    update_option( 'pmcpc_additional_blocked_emails', sanitize_textarea_field( (string) $blocked_emails_raw ) );
                    break;

                case 'spam':
                    $values['spam_protection_enabled']               = isset( $_POST['pmcpc_spam_protection_enabled'] ) ? 'yes' : 'no';
                    $mode = isset( $_POST['pmcpc_spam_handling_mode'] ) ? sanitize_key( (string) wp_unslash( $_POST['pmcpc_spam_handling_mode'] ) ) : PMCPC_Settings::get( 'spam_handling_mode', 'review_all' );
                    if ( ! in_array( $mode, array( 'review_all', 'auto_delete_obvious' ), true ) ) { $mode = 'review_all'; }
                    $values['spam_handling_mode'] = $mode;

                    // Inbox retention (housekeeping).
                    $allowed_retention_values = array( 0, 30, 90, 180 );
                    $inbox_days = isset( $_POST['pmcpc_inbox_retention_days'] ) ? absint( $_POST['pmcpc_inbox_retention_days'] ) : absint( PMCPC_Settings::get( 'inbox_retention_days', 90 ) );
                    $spam_days  = isset( $_POST['pmcpc_spam_retention_days'] ) ? absint( $_POST['pmcpc_spam_retention_days'] ) : absint( PMCPC_Settings::get( 'spam_retention_days', 180 ) );
                    if ( ! in_array( $inbox_days, $allowed_retention_values, true ) ) { $inbox_days = 90; }
                    if ( ! in_array( $spam_days, $allowed_retention_values, true ) ) { $spam_days = 180; }
                    $values['inbox_retention_days'] = $inbox_days;
                    $values['spam_retention_days']  = $spam_days;
                    $values['spam_honeypot_enabled']                 = isset( $_POST['pmcpc_spam_honeypot_enabled'] ) ? 'yes' : 'no';
                    $values['spam_form_timing_enabled']              = isset( $_POST['pmcpc_spam_form_timing_enabled'] ) ? 'yes' : 'no';
                    if ( isset( $_POST['pmcpc_spam_min_submit_seconds'] ) ) {
                        $values['spam_min_submit_seconds'] = max( 0, absint( $_POST['pmcpc_spam_min_submit_seconds'] ) );
                    }
                    $values['spam_rate_limit_enabled']               = isset( $_POST['pmcpc_spam_rate_limit_enabled'] ) ? 'yes' : 'no';
                    if ( isset( $_POST['pmcpc_spam_rate_limit_max'] ) ) {
                        $values['spam_rate_limit_max'] = max( 1, absint( $_POST['pmcpc_spam_rate_limit_max'] ) );
                    }
                    if ( isset( $_POST['pmcpc_spam_rate_limit_window'] ) ) {
                        $values['spam_rate_limit_window'] = max( 60, absint( $_POST['pmcpc_spam_rate_limit_window'] ) );
                    }
                    $values['spam_suspicious_tlds']                  = isset( $_POST['pmcpc_spam_suspicious_tlds'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['pmcpc_spam_suspicious_tlds'] ) ) : PMCPC_Settings::get( 'spam_suspicious_tlds', '' );
                    $values['spam_auto_block_domains_enabled']       = isset( $_POST['pmcpc_spam_auto_block_domains_enabled'] ) ? 'yes' : 'no';
                    if ( isset( $_POST['pmcpc_spam_auto_block_domains_threshold'] ) ) {
                        $values['spam_auto_block_domains_threshold'] = max( 1, absint( $_POST['pmcpc_spam_auto_block_domains_threshold'] ) );
                    }
                    if ( isset( $_POST['pmcpc_spam_auto_block_domains_window'] ) ) {
                        $values['spam_auto_block_domains_window'] = max( 60, absint( $_POST['pmcpc_spam_auto_block_domains_window'] ) );
                    }
                    $values['spam_auto_block_protected_domains']     = isset( $_POST['pmcpc_spam_auto_block_protected_domains'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['pmcpc_spam_auto_block_protected_domains'] ) ) : PMCPC_Settings::get( 'spam_auto_block_protected_domains', '' );
                    $values['spam_name_policy']                      = isset( $_POST['pmcpc_spam_name_policy'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_spam_name_policy'] ) ) : PMCPC_Settings::get( 'spam_name_policy', 'hold' );
                    $values['spam_log_enabled']                      = isset( $_POST['pmcpc_spam_log_enabled'] ) ? 'yes' : 'no';
                    $values['spam_email_dns_enabled']                = isset( $_POST['pmcpc_spam_email_dns_enabled'] ) ? 'yes' : 'no';
                    $values['spam_message_scoring_enabled']          = isset( $_POST['pmcpc_spam_message_scoring_enabled'] ) ? 'yes' : 'no';
                    if ( isset( $_POST['pmcpc_spam_message_max_links'] ) ) {
                        $values['spam_message_max_links'] = max( 0, absint( $_POST['pmcpc_spam_message_max_links'] ) );
                    }
                    $values['spam_message_keywords_enabled']         = isset( $_POST['pmcpc_spam_message_keywords_enabled'] ) ? 'yes' : 'no';
                    $values['spam_message_keywords']                 = isset( $_POST['pmcpc_spam_message_keywords'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['pmcpc_spam_message_keywords'] ) ) : PMCPC_Settings::get( 'spam_message_keywords', '' );
                    if ( isset( $_POST['pmcpc_spam_message_non_ascii_threshold'] ) ) {
                        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized immediately below.
                        $raw_threshold = sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_spam_message_non_ascii_threshold'] ) );
                        $raw_threshold = str_replace( ',', '.', $raw_threshold );
                        $threshold = floatval( $raw_threshold );
                        if ( $threshold < 0 ) {
                            $threshold = 0;
                        }
                        if ( $threshold > 1 ) {
                            // Allow admins to type 30 to mean 0.30.
                            $threshold = $threshold / 100;
                        }
                        $values['spam_message_non_ascii_threshold'] = $threshold;
                    }
                    $values['spam_message_suspicious_markup_enabled']= isset( $_POST['pmcpc_spam_message_suspicious_markup_enabled'] ) ? 'yes' : 'no';
                    if ( isset( $_POST['pmcpc_spam_message_hold_score'] ) ) {
                        $values['spam_message_hold_score'] = max( 0, absint( $_POST['pmcpc_spam_message_hold_score'] ) );
                    }
                    if ( isset( $_POST['pmcpc_spam_message_block_score'] ) ) {
                        $values['spam_message_block_score'] = max( 0, absint( $_POST['pmcpc_spam_message_block_score'] ) );
                    }
                    $values['spam_message_prefer_hold_on_non_ascii_only'] = isset( $_POST['pmcpc_spam_message_prefer_hold_on_non_ascii_only'] ) ? 'yes' : 'no';
                    $values['spam_message_prefer_hold_over_block']        = isset( $_POST['pmcpc_spam_message_prefer_hold_over_block'] ) ? 'yes' : 'no';

                    // Duplicate submission guard.
                    $values['spam_duplicate_guard_enabled'] = isset( $_POST['pmcpc_spam_duplicate_guard_enabled'] ) ? 'yes' : 'no';
                    if ( isset( $_POST['pmcpc_spam_duplicate_guard_window'] ) ) {
                        $values['spam_duplicate_guard_window'] = max( 10, absint( $_POST['pmcpc_spam_duplicate_guard_window'] ) );
                    }

                    // Allowlist settings.
                    $values['allowlisted_email_domains'] = isset( $_POST['pmcpc_allowlisted_email_domains'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['pmcpc_allowlisted_email_domains'] ) ) : PMCPC_Settings::get( 'allowlisted_email_domains', '' );
                    $allow_emails_raw = isset( $_POST['pmcpc_allowlisted_emails'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['pmcpc_allowlisted_emails'] ) ) : '';
                    if ( is_array( $allow_emails_raw ) ) {
                        $allow_emails_raw = '';
                    }
                    update_option( 'pmcpc_allowlisted_emails', sanitize_textarea_field( (string) $allow_emails_raw ), false );

                    break;

                case 'lifecycle':
                    $values['lifecycle_tags']                   = isset( $_POST['pmcpc_lifecycle_tags'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['pmcpc_lifecycle_tags'] ) ) : PMCPC_Settings::get( 'lifecycle_tags', '' );
                    $values['lifecycle_auto_enabled']           = isset( $_POST['pmcpc_lifecycle_auto_enabled'] ) ? 'yes' : 'no';
                    if ( isset( $_POST['pmcpc_lifecycle_high_value_threshold'] ) ) {
                        $values['lifecycle_high_value_threshold'] = absint( $_POST['pmcpc_lifecycle_high_value_threshold'] );
                    }
                    if ( isset( $_POST['pmcpc_lifecycle_vip_threshold'] ) ) {
                        $values['lifecycle_vip_threshold'] = absint( $_POST['pmcpc_lifecycle_vip_threshold'] );
                    }
                    if ( isset( $_POST['pmcpc_lifecycle_recent_days'] ) ) {
                        $values['lifecycle_recent_days'] = absint( $_POST['pmcpc_lifecycle_recent_days'] );
                    }
                    if ( isset( $_POST['pmcpc_lifecycle_lapsed_days'] ) ) {
                        $values['lifecycle_lapsed_days'] = absint( $_POST['pmcpc_lifecycle_lapsed_days'] );
                    }
                    break;

                case 'advanced':
                default:
                    $values['tracking_debug'] = isset( $_POST['pmcpc_tracking_debug'] ) ? 'yes' : 'no';

                    // Email queue retention (housekeeping).
                    // 0 = keep forever; otherwise delete items older than N days by status.
                    $values['queue_retention_sent_days'] = isset( $_POST['pmcpc_queue_retention_sent_days'] )
                        ? max( 0, min( 3650, absint( $_POST['pmcpc_queue_retention_sent_days'] ) ) )
                        : absint( PMCPC_Settings::get( 'queue_retention_sent_days', 60 ) );
                    $values['queue_retention_failed_days'] = isset( $_POST['pmcpc_queue_retention_failed_days'] )
                        ? max( 0, min( 3650, absint( $_POST['pmcpc_queue_retention_failed_days'] ) ) )
                        : absint( PMCPC_Settings::get( 'queue_retention_failed_days', 30 ) );
                    $values['queue_retention_pending_days'] = isset( $_POST['pmcpc_queue_retention_pending_days'] )
                        ? max( 0, min( 3650, absint( $_POST['pmcpc_queue_retention_pending_days'] ) ) )
                        : absint( PMCPC_Settings::get( 'queue_retention_pending_days', 14 ) );

                    // Front-end shortcode form styling.
                    $allowed_form_styles = array( 'theme', 'clean', 'boxed', 'elegant' );
                    $form_style_preset   = isset( $_POST['pmcpc_form_style_preset'] ) ? sanitize_key( (string) wp_unslash( $_POST['pmcpc_form_style_preset'] ) ) : (string) PMCPC_Settings::get( 'form_style_preset', 'theme' );
                    if ( ! in_array( $form_style_preset, $allowed_form_styles, true ) ) {
                        $form_style_preset = 'theme';
                    }
                    $values['form_style_preset'] = $form_style_preset;

                    $form_accent_color = isset( $_POST['pmcpc_form_accent_color'] ) ? sanitize_hex_color( (string) wp_unslash( $_POST['pmcpc_form_accent_color'] ) ) : sanitize_hex_color( (string) PMCPC_Settings::get( 'form_accent_color', '#2271b1' ) );
                    if ( ! $form_accent_color ) {
                        $form_accent_color = '#2271b1';
                    }
                    $values['form_accent_color'] = $form_accent_color;

                    $allowed_button_shapes = array( 'square', 'soft', 'pill' );
                    $form_button_shape     = isset( $_POST['pmcpc_form_button_shape'] ) ? sanitize_key( (string) wp_unslash( $_POST['pmcpc_form_button_shape'] ) ) : (string) PMCPC_Settings::get( 'form_button_shape', 'soft' );
                    if ( ! in_array( $form_button_shape, $allowed_button_shapes, true ) ) {
                        $form_button_shape = 'soft';
                    }
                    $values['form_button_shape'] = $form_button_shape;

                    $values['form_max_width'] = isset( $_POST['pmcpc_form_max_width'] )
                        ? max( 0, min( 1600, absint( $_POST['pmcpc_form_max_width'] ) ) )
                        : absint( PMCPC_Settings::get( 'form_max_width', 640 ) );

                    break;
            }

            if ( ! empty( $values ) ) {
                PMCPC_Settings::update( $values );
            }

            
// Show any extra save notices (e.g., sanitized / removed values).
if ( ! empty( $save_notices ) && is_array( $save_notices ) ) {
    foreach ( $save_notices as $n ) {
        $type = isset( $n['type'] ) ? sanitize_key( (string) $n['type'] ) : 'info';
        if ( ! in_array( $type, array( 'info', 'success', 'warning', 'error' ), true ) ) {
            $type = 'info';
        }
        $class = 'notice notice-' . $type;
        $text  = isset( $n['text'] ) ? (string) $n['text'] : '';
        if ( '' !== trim( $text ) ) {
            echo '<div class="' . esc_attr( $class ) . '"><p>' . wp_kses_post( $text ) . '</p></div>';
        }
    }
}

            echo '<div class="updated"><p>' . esc_html__( 'Settings saved.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        $from_name_default  = PMCPC_Settings::get( 'from_name_default', get_bloginfo( 'name' ) );
        $from_email_default = PMCPC_Settings::get( 'from_email_default', get_option( 'admin_email' ) );
        $wc_checked         = PMCPC_Settings::get( 'wc_opt_in_default_checked', 'yes' ) === 'yes';
        $wc_register_enabled = PMCPC_Settings::get( 'wc_register_opt_in_enabled', 'yes' ) === 'yes';
        $batch_size         = (int) PMCPC_Settings::get( 'queue_batch_size', 20 );
        $pause_sending      = PMCPC_Settings::get( 'pause_sending', 'no' ) === 'yes';
        $notify_double_optin_enabled = PMCPC_Settings::get( 'notify_admin_double_optin', 'no' ) === 'yes';
        $notify_email       = PMCPC_Settings::get( 'notify_admin_email', get_option( 'admin_email' ) );
        $guest_double_optin_enabled  = PMCPC_Settings::get( 'guest_double_optin', 'yes' ) === 'yes';
        $subscribe_popup_enabled = PMCPC_Settings::get( 'subscribe_popup_enabled', 'yes' ) === 'yes';
        $subscribe_popup_delay_ms = (int) PMCPC_Settings::get( 'subscribe_popup_delay_ms', 3000 );
        $subscribe_popup_days_between = (int) PMCPC_Settings::get( 'subscribe_popup_days_between', 7 );
        if ( $subscribe_popup_delay_ms < 0 ) {
            $subscribe_popup_delay_ms = 0;
        } elseif ( $subscribe_popup_delay_ms > 60000 ) {
            $subscribe_popup_delay_ms = 60000;
        }
        if ( $subscribe_popup_days_between < 0 ) {
            $subscribe_popup_days_between = 0;
        } elseif ( $subscribe_popup_days_between > 365 ) {
            $subscribe_popup_days_between = 365;
        }
        $email_prefs_url    = PMCPC_Settings::get( 'email_prefs_url', '' );
        $blocked_email_domains = PMCPC_Settings::get( 'blocked_email_domains', '' );

        $blocked_emails        = get_option( 'pmcpc_additional_blocked_emails', '' );
        if ( ! is_string( $blocked_emails ) ) {
            $blocked_emails = '';
        }
        $blocked_domains_auto_add = PMCPC_Settings::get( 'blocked_domains_auto_add', 'yes' );

        $lifecycle_tags      = PMCPC_Settings::get( 'lifecycle_tags', "new-customer\nrepeat-customer\nhigh-value\nvip\nrecent-buyer\nlapsed-customer" );
        $lifecycle_auto_enabled = PMCPC_Settings::get( 'lifecycle_auto_enabled', 'no' ) === 'yes';
        $lifecycle_high_value_threshold = (float) PMCPC_Settings::get( 'lifecycle_high_value_threshold', '0' );
        $lifecycle_vip_threshold        = (float) PMCPC_Settings::get( 'lifecycle_vip_threshold', '0' );
        $lifecycle_recent_days          = absint( PMCPC_Settings::get( 'lifecycle_recent_days', '90' ) );
        $lifecycle_lapsed_days          = absint( PMCPC_Settings::get( 'lifecycle_lapsed_days', '180' ) );

        $tracking_debug    = PMCPC_Settings::get( 'tracking_debug', 'no' ) === 'yes';

        // Email queue retention.
        $queue_retention_sent_days   = absint( PMCPC_Settings::get( 'queue_retention_sent_days', 60 ) );
        $queue_retention_failed_days = absint( PMCPC_Settings::get( 'queue_retention_failed_days', 30 ) );
        $queue_retention_pending_days = absint( PMCPC_Settings::get( 'queue_retention_pending_days', 14 ) );

        // Front-end shortcode form styling.
        $form_style_preset = sanitize_key( (string) PMCPC_Settings::get( 'form_style_preset', 'theme' ) );
        if ( ! in_array( $form_style_preset, array( 'theme', 'clean', 'boxed', 'elegant' ), true ) ) {
            $form_style_preset = 'theme';
        }
        $form_accent_color = sanitize_hex_color( (string) PMCPC_Settings::get( 'form_accent_color', '#2271b1' ) );
        if ( ! $form_accent_color ) {
            $form_accent_color = '#2271b1';
        }
        $form_button_shape = sanitize_key( (string) PMCPC_Settings::get( 'form_button_shape', 'soft' ) );
        if ( ! in_array( $form_button_shape, array( 'square', 'soft', 'pill' ), true ) ) {
            $form_button_shape = 'soft';
        }
        $form_max_width = max( 0, min( 1600, absint( PMCPC_Settings::get( 'form_max_width', 640 ) ) ) );

        // Spam protection settings.
        $spam_enabled = PMCPC_Settings::get( 'spam_protection_enabled', 'yes' ) === 'yes';
        $spam_handling_mode = sanitize_key( (string) PMCPC_Settings::get( 'spam_handling_mode', 'review_all' ) );
        if ( ! in_array( $spam_handling_mode, array( 'review_all', 'auto_delete_obvious' ), true ) ) { $spam_handling_mode = 'review_all'; }
        $spam_honeypot_enabled = PMCPC_Settings::get( 'spam_honeypot_enabled', 'yes' ) === 'yes';
        $spam_rate_enabled = PMCPC_Settings::get( 'spam_rate_limit_enabled', 'yes' ) === 'yes';
        $spam_rate_max = (int) PMCPC_Settings::get( 'spam_rate_limit_max', 5 );
        $spam_rate_window = (int) PMCPC_Settings::get( 'spam_rate_limit_window', 600 );
        $spam_tlds_enabled = PMCPC_Settings::get( 'spam_suspicious_tlds_enabled', 'yes' ) === 'yes';
        $spam_tlds = PMCPC_Settings::get( 'spam_suspicious_tlds', "ru\nxyz\ntop\nclub\nsite\nclick\nlink\nfit\nrest\nmonster\nwork\nbiz" );
        $spam_auto_domains_enabled = PMCPC_Settings::get( 'spam_auto_block_domains_enabled', 'yes' ) === 'yes';
        $spam_auto_domains_threshold = (int) PMCPC_Settings::get( 'spam_auto_block_domains_threshold', 3 );
        $spam_auto_domains_window = (int) PMCPC_Settings::get( 'spam_auto_block_domains_window', 86400 );
        $spam_auto_protected_domains = PMCPC_Settings::get( 'spam_auto_block_protected_domains', '' );
        $spam_name_policy = PMCPC_Settings::get( 'spam_name_policy', 'blank' );
        $spam_log_enabled = PMCPC_Settings::get( 'spam_log_enabled', 'yes' ) === 'yes';
        $spam_email_dns_enabled = PMCPC_Settings::get( 'spam_email_dns_enabled', 'yes' ) === 'yes';
        $spam_form_timing_enabled = PMCPC_Settings::get( 'spam_form_timing_enabled', 'yes' ) === 'yes';
        $spam_min_submit_seconds  = (int) PMCPC_Settings::get( 'spam_min_submit_seconds', 4 );

        // Inbox retention (housekeeping).
        $inbox_retention_days = absint( PMCPC_Settings::get( 'inbox_retention_days', 90 ) );
        $spam_retention_days  = absint( PMCPC_Settings::get( 'spam_retention_days', 180 ) );
        $allowed_retention_values = array( 0, 30, 90, 180 );
        if ( ! in_array( $inbox_retention_days, $allowed_retention_values, true ) ) {
            $inbox_retention_days = 90;
        }
        if ( ! in_array( $spam_retention_days, $allowed_retention_values, true ) ) {
            $spam_retention_days = 180;
        }

        // Allowlist (never block) settings.
        $allowlisted_emails = get_option( 'pmcpc_allowlisted_emails', '' );
        if ( ! is_string( $allowlisted_emails ) ) {
            $allowlisted_emails = '';
        }
        $allowlisted_email_domains = PMCPC_Settings::get( 'allowlisted_email_domains', '' );

        $spam_message_scoring_enabled = PMCPC_Settings::get( 'spam_message_scoring_enabled', 'yes' ) === 'yes';
        $spam_message_max_links = (int) PMCPC_Settings::get( 'spam_message_max_links', 1 );
        $spam_message_keywords_enabled = PMCPC_Settings::get( 'spam_message_keywords_enabled', 'yes' ) === 'yes';
        $spam_message_keywords = PMCPC_Settings::get( 'spam_message_keywords', "seo\nbacklink\nbacklinks\nlink building\nguest post\nwrite for us\n\ncasino\npoker\nbetting\nloan\ncrypto\ntelegram\nwhatsapp\n\nказино\nонлайн казино\nслоты\nбукмекер\nставки\n\nxrumer\nxrum\n\n\"best service\"\n\"promote your site\"\n\"website promotion\"" );
        $spam_message_non_ascii_threshold = (float) PMCPC_Settings::get( 'spam_message_non_ascii_threshold', 0.30 );
        $spam_message_suspicious_markup_enabled = PMCPC_Settings::get( 'spam_message_suspicious_markup_enabled', 'yes' ) === 'yes';
        $spam_message_hold_score = (int) PMCPC_Settings::get( 'spam_message_hold_score', 3 );
        $spam_message_block_score = (int) PMCPC_Settings::get( 'spam_message_block_score', 6 );
        $spam_message_prefer_hold_on_non_ascii_only = PMCPC_Settings::get( 'spam_message_prefer_hold_on_non_ascii_only', 'yes' ) === 'yes';
        $spam_message_prefer_hold_over_block        = PMCPC_Settings::get( 'spam_message_prefer_hold_over_block', 'no' ) === 'yes';

        // Spam Log stats (computed from the reviewable Spam Log table).
        $spam_total = 0;
        $spam_today = 0;
        $spam_top_domains = array();
        global $wpdb;
        $spam_table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $spam_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $spam_table ) ) === $spam_table );
        if ( $spam_exists ) {
            $today_date = current_time( 'Y-m-d' );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $spam_total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$spam_table} WHERE status = %s", 'blocked' ) );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $spam_today = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$spam_table} WHERE status = %s AND DATE(created_at) = %s", 'blocked', $today_date ) );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT domain, COUNT(*) AS cnt FROM {$spam_table} WHERE status = %s AND domain IS NOT NULL AND domain <> '' GROUP BY domain ORDER BY cnt DESC LIMIT 5", 'blocked' ), ARRAY_A );
            if ( is_array( $rows ) ) {
                foreach ( $rows as $row ) {
                    if ( empty( $row['domain'] ) ) { continue; }
                    $spam_top_domains[ (string) $row['domain'] ] = (int) $row['cnt'];
                }
            }
        }


        // Custom SMTP settings (generic for any provider).
        $smtp_settings = class_exists( 'PMCPC_SMTP' ) ? PMCPC_SMTP::get_settings() : array();
        $smtp_defaults = array(
            'enabled'    => 0,
            'host'       => '',
            'port'       => 587,
            'encryption' => 'tls',
            'auth'       => 1,
            'username'   => '',
            'password'   => '',
            'from_email' => '',
            'from_name'  => '',
        );
        if ( ! is_array( $smtp_settings ) ) {
            $smtp_settings = array();
        }
        $smtp_settings   = wp_parse_args( $smtp_settings, $smtp_defaults );

        $smtp_enabled    = ! empty( $smtp_settings['enabled'] );
        $smtp_host       = $smtp_settings['host'];
        $smtp_port       = (int) $smtp_settings['port'];
        $smtp_encryption = $smtp_settings['encryption'];
        $smtp_auth       = ! empty( $smtp_settings['auth'] );
        $smtp_username   = $smtp_settings['username'];
        $smtp_password   = $smtp_settings['password'];
        $smtp_from_email = $smtp_settings['from_email'];
        $smtp_from_name  = $smtp_settings['from_name'];



        echo '<div class="wrap">';
        PMCPC_Admin::render_app_header( __( 'Settings', 'product-mailer-campaigns' ) );

        PMCPC_Admin::render_page_intro(
            __( 'Control sending, defaults, and security', 'product-mailer-campaigns' ),
            __( 'Use Settings to manage how email is sent, how new subscribers are handled, and which safety rules apply across FlowPress.', 'product-mailer-campaigns' ),
            array(
                array( 'label' => __( 'Email and sender setup', 'product-mailer-campaigns' ), 'icon' => 'dashicons-email-alt' ),
                array( 'label' => __( 'Audience defaults', 'product-mailer-campaigns' ), 'icon' => 'dashicons-admin-users' ),
                array( 'label' => __( 'Security and advanced rules', 'product-mailer-campaigns' ), 'icon' => 'dashicons-shield' ),
            )
        );
        PMCPC_Admin::render_support_panels(
            array(
                array(
                    'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                    'icon'    => 'dashicons-editor-help',
                    'title'   => __( 'Change one section at a time', 'product-mailer-campaigns' ),
                    'items'   => array(
                        __( 'Save your changes after each section.', 'product-mailer-campaigns' ),
                        __( 'Send a test after changing email settings.', 'product-mailer-campaigns' ),
                        __( 'Use Health Check if sending still does not look right.', 'product-mailer-campaigns' ),
                    ),
                ),
                array(
                    'eyebrow' => __( 'Test and check', 'product-mailer-campaigns' ),
                    'icon'    => 'dashicons-saved',
                    'title'   => __( 'Confirm sending before moving on', 'product-mailer-campaigns' ),
                    'actions' => array(
                        array( 'label' => __( 'Open Email & Login', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc-email-login-settings' ), 'class' => 'button' ),
                        array( 'label' => __( 'Open Health Check', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_diagnostics' ), 'class' => 'button' ),
                    ),
                ),
            )
        );

        // Inline styles + JS for help icons and the spam test tool.
        echo '<style>.pmcpc-help-tip{margin-left:6px;vertical-align:text-bottom;color:#646970;cursor:help}.pmcpc-help-tip:hover{color:#1d2327}.pmcpc-test-spam{margin-top:6px}.pmcpc-test-spam input,.pmcpc-test-spam select,.pmcpc-test-spam textarea{margin-right:8px}.pmcpc-test-spam .row{margin:6px 0}.pmcpc-test-spam .label{display:inline-block;min-width:110px;color:#50575e}.pmcpc-test-spam textarea{width:100%;max-width:820px}.pmcpc-test-result{margin-top:8px;padding:8px 10px;border:1px solid #c3c4c7;border-radius:4px;display:none}.pmcpc-test-result.is-ok{background:#f0f6fc}.pmcpc-test-result.is-bad{background:#fcf0f1}.pmcpc-test-breakdown{margin-top:8px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;font-size:12px;white-space:pre-wrap}.pmcpc-settings-layout{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:20px;align-items:start}.pmcpc-settings-card{padding:18px 20px;border:1px solid #dcdcde;border-radius:12px;background:#fff;box-shadow:0 1px 1px rgba(0,0,0,.03)}.pmcpc-settings-layout__side{display:flex;flex-direction:column;gap:20px}.pmcpc-settings-card .form-table{margin-top:0}.pmcpc-settings-card .nav-tab-wrapper{margin-top:0}.pmcpc-settings-actions{display:flex;justify-content:flex-end;margin:12px 0 16px}.pmcpc-settings-panel-title{margin:18px 0 0;padding-top:16px;border-top:1px solid #dcdcde}.pmcpc-settings-panel-title:first-of-type{border-top:0;padding-top:0}.pmcpc-settings-section-intro{margin:4px 0 12px;color:#646970}.pmcpc-settings-status-card h3,.pmcpc-settings-promo-card h3{margin-top:0;margin-bottom:8px;font-size:18px}.pmcpc-settings-status-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px}.pmcpc-settings-status-grid strong{display:block;font-size:12px;letter-spacing:.02em;text-transform:uppercase;color:#646970;margin-bottom:4px}.pmcpc-settings-promo-card ul{list-style:none;margin:10px 0 0;padding:0}.pmcpc-settings-promo-card li{margin:0 0 8px;padding-left:22px;position:relative}.pmcpc-settings-promo-card li:before{content:"✔";position:absolute;left:0;top:0;color:#00a32a;font-weight:700}.pmcpc-settings-promo-card .pmcpc-settings-promo-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}@media (max-width:1100px){.pmcpc-settings-layout{grid-template-columns:1fr}}</style>';
        $test_nonce = wp_create_nonce( 'pmcpc_test_spam' );
        echo '<script>(function(){function byId(id){return document.getElementById(id);}function v(id){var el=byId(id);return el?el.value:"";}function checked(id){var el=byId(id);return !!(el&&el.checked);}function prettyPart(name,part){if(!part){return name+": (n/a)";}var out=name+": ";out+=(part.allowed?"allowed":"NOT allowed");out+=" | action="+(part.action||"");if(part.reason){out+=" | reason="+part.reason;}if(typeof part.score!=="undefined"){out+=" | score="+part.score;}if(part.details&&part.details.length){out+=" | details="+part.details.join(", ");}return out;}document.addEventListener("click",function(e){if(!e.target||e.target.id!=="pmcpc-test-spam-btn"){return;}e.preventDefault();var btn=e.target;btn.disabled=true;var data=new FormData();data.append("action","pmcpc_test_spam");data.append("_wpnonce","' . esc_js( $test_nonce ) . '");data.append("email",v("pmcpc_test_spam_email"));data.append("first_name",v("pmcpc_test_spam_first_name"));data.append("last_name",v("pmcpc_test_spam_last_name"));data.append("context",v("pmcpc_test_spam_context")||"subscribe");data.append("subject",v("pmcpc_test_spam_subject"));data.append("message",v("pmcpc_test_spam_message"));data.append("ft_mode",v("pmcpc_test_spam_ft_mode")||"valid");data.append("ft_seconds",v("pmcpc_test_spam_ft_seconds")||"10");data.append("honeypot",checked("pmcpc_test_spam_hp_on")?"1":"");var res=byId("pmcpc-test-spam-result");var br=byId("pmcpc-test-spam-breakdown");res.style.display="block";res.className="pmcpc-test-result";res.textContent="Testing…";if(br){br.textContent="";}fetch(ajaxurl,{method:"POST",credentials:"same-origin",body:data}).then(function(r){return r.json();}).then(function(json){btn.disabled=false;res.className="pmcpc-test-result";if(!json||!json.success){res.classList.add("is-bad");res.textContent=(json&&json.data&&json.data.message)?json.data.message:"Error";return;}var d=json.data||{};var headline="";if(d.allowed){res.classList.add("is-ok");headline="Allowed";if(d.action==="name_stripped"){headline+=" (name would be stripped)";}}else{res.classList.add("is-bad");headline=(d.action==="held")?"Held for review":"Blocked";}if(d.reason){headline+=" — "+d.reason;}res.textContent=headline;var parts=d.parts||{};if(br){var lines=[];lines.push(prettyPart("Timing",parts.timing));lines.push(prettyPart("Identity",parts.identity));lines.push(prettyPart("Message",parts.message));br.textContent=lines.join("\n");}}).catch(function(){btn.disabled=false;res.className="pmcpc-test-result is-bad";res.textContent="Error";});});})();</script>';

        $smtp_test_nonce = wp_create_nonce( 'pmcpc_test_smtp' );
        echo '<script>(function(){function byId(id){return document.getElementById(id);}function v(id){var el=byId(id);return el?el.value:"";}function checked(id){var el=byId(id);return !!(el&&el.checked);}function detailLine(d){if(!d){return "";}return "Host: "+(d.host||"")+":"+(d.port||"")+" | Encryption: "+(d.encryption||"")+" | Recipient: "+(d.recipient||"");}document.addEventListener("click",function(e){if(!e.target||e.target.id!=="pmcpc-test-smtp-btn"){return;}e.preventDefault();var btn=e.target;var res=byId("pmcpc-test-smtp-result");var br=byId("pmcpc-test-smtp-breakdown");btn.disabled=true;if(res){res.style.display="block";res.className="pmcpc-test-result";res.textContent="Sending test email…";}if(br){br.textContent="";}var data=new FormData();data.append("action","pmcpc_test_smtp");data.append("_wpnonce","' . esc_js( $smtp_test_nonce ) . '");data.append("recipient",v("pmcpc_smtp_test_to"));data.append("settings[enabled]",checked("pmcpc_smtp_enabled")?"1":"");data.append("settings[host]",v("pmcpc_smtp_host"));data.append("settings[port]",v("pmcpc_smtp_port"));data.append("settings[encryption]",v("pmcpc_smtp_encryption"));data.append("settings[auth]",checked("pmcpc_smtp_auth")?"1":"");data.append("settings[username]",v("pmcpc_smtp_username"));data.append("settings[password]",v("pmcpc_smtp_password"));data.append("settings[from_email]",v("pmcpc_smtp_from_email"));data.append("settings[from_name]",v("pmcpc_smtp_from_name"));fetch(ajaxurl,{method:"POST",credentials:"same-origin",body:data}).then(function(r){return r.json();}).then(function(json){btn.disabled=false;var d=(json&&json.data)?json.data:{};if(!res){return;}res.className="pmcpc-test-result";if(json&&json.success){res.classList.add("is-ok");res.textContent=d.message||"Test email sent.";}else{res.classList.add("is-bad");res.textContent=d.message||"The test email could not be sent.";}if(br&&d.details){br.textContent=detailLine(d.details);}}).catch(function(){btn.disabled=false;if(res){res.className="pmcpc-test-result is-bad";res.textContent="The SMTP test request failed.";}});});})();</script>';

        echo '<form method="post">';
        wp_nonce_field( 'pmcpc_save_settings', 'pmcpc_settings_nonce' );

        $active_tab = 'email';
        if ( isset( $_GET['tab'] ) ) {
            $active_tab = sanitize_key( (string) wp_unslash( $_GET['tab'] ) );
        } elseif ( isset( $_GET['pmcpc_tab'] ) ) {
            $active_tab = sanitize_key( (string) wp_unslash( $_GET['pmcpc_tab'] ) );
        } elseif ( isset( $_GET['pmcpctab'] ) ) {
            $active_tab = sanitize_key( (string) wp_unslash( $_GET['pmcpctab'] ) );
        }
        $tabs = array(
            'email'      => __( 'General & Email', 'product-mailer-campaigns' ),
            'subscribers'=> __( 'Forms & Blocklist', 'product-mailer-campaigns' ),
            'spam'       => __( 'Spam Protection', 'product-mailer-campaigns' ),
            'lifecycle'  => __( 'Lifecycle & Segments', 'product-mailer-campaigns' ),
            'advanced'   => __( 'Advanced & Styling', 'product-mailer-campaigns' ),
        );
        if ( ! isset( $tabs[ $active_tab ] ) ) {
            $active_tab = 'email';
        }

        $license_mode = 'Core';
        $license_state = __( 'Built-in features active', 'product-mailer-campaigns' );
        $license_cta_label = __( 'View upgrade options', 'product-mailer-campaigns' );
        $license_cta_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
        if ( function_exists( 'pmcpc_license' ) && function_exists( 'pmcpc_trial' ) ) {
            if ( pmcpc_license()->is_active() ) {
                $license_mode = __( 'Licensed', 'product-mailer-campaigns' );
                $license_state = __( 'Premium automations available', 'product-mailer-campaigns' );
                $license_cta_label = __( 'Manage license', 'product-mailer-campaigns' );
            } elseif ( pmcpc_trial()->is_active() ) {
                $license_mode = __( 'Trial active', 'product-mailer-campaigns' );
                $license_state = sprintf( _n( '%d day remaining', '%d days remaining', (int) pmcpc_trial()->days_left(), 'product-mailer-campaigns' ), (int) pmcpc_trial()->days_left() );
                $license_cta_label = __( 'Upgrade now', 'product-mailer-campaigns' );
            }
        }

        echo '<div class="pmcpc-settings-layout">';
        echo '<div class="pmcpc-settings-layout__main">';
        echo '<div class="pmcpc-settings-card">';

        echo '<h2 class="nav-tab-wrapper">';
        foreach ( $tabs as $tab_key => $tab_label ) {
            $class = ( $active_tab === $tab_key ) ? ' nav-tab-active' : '';
            $url = add_query_arg( array( 'page' => 'pmcpc_settings', 'tab' => $tab_key ), admin_url( 'admin.php' ) );
            echo '<a class="nav-tab' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '">' . esc_html( $tab_label ) . '</a>';
        }
        echo '</h2>';

        echo '<div class="pmcpc-settings-actions">';
        submit_button( __( 'Save Settings', 'product-mailer-campaigns' ), 'primary', 'submit', false );
        echo '</div>';

        echo '<input type="hidden" name="pmcpc_settings_tab" value="' . esc_attr( $active_tab ) . '">';

        echo '<table class="form-table">';
        echo '<tbody class="pmcpc-settings-tab pmcpc-tab-email"' . ( $active_tab !== 'email' ? ' style="display:none;"' : '' ) . '>';
        echo '<tr><th colspan="2"><h2 class="pmcpc-settings-panel-title">' . esc_html__( 'Sender Settings', 'product-mailer-campaigns' ) . '</h2><p class="pmcpc-settings-section-intro">' . esc_html__( 'Choose the default sender details used for your campaign emails.', 'product-mailer-campaigns' ) . '</p></th></tr>';
        echo '<tr><th><label for="pmcpc_from_name_default">' . esc_html__( 'Default sender name', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="pmcpc_from_name_default" type="text" id="pmcpc_from_name_default" class="regular-text" value="' . esc_attr( $from_name_default ) . '">';
        echo '<p class="description">' . esc_html__( 'Default sender name used for campaign emails.', 'product-mailer-campaigns' ) . '</p></td></tr>';

        echo '<tr><th><label for="pmcpc_from_email_default">' . esc_html__( 'Default sender email', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="pmcpc_from_email_default" type="email" id="pmcpc_from_email_default" class="regular-text" value="' . esc_attr( $from_email_default ) . '">';
        echo '<p class="description">' . esc_html__( 'Default sender email used for campaign emails. Make sure this address is allowed by your mail provider.', 'product-mailer-campaigns' ) . '</p></td></tr>';

        echo '<tr><th colspan="2"><h2 class="pmcpc-settings-panel-title">' . esc_html__( 'WooCommerce Integration', 'product-mailer-campaigns' ) . '</h2><p class="pmcpc-settings-section-intro">' . esc_html__( 'Control how newsletter signup options appear during WooCommerce checkout and registration.', 'product-mailer-campaigns' ) . '</p></th></tr>';
        echo '<tr><th><label for="pmcpc_wc_opt_in_default_checked">' . esc_html__( 'Pre-check newsletter box at checkout', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><label><input name="pmcpc_wc_opt_in_default_checked" type="checkbox" id="pmcpc_wc_opt_in_default_checked" value="1" ' . checked( true, $wc_checked, false ) . '> ';
        echo esc_html__( 'If enabled, the newsletter checkbox on checkout is pre-checked.', 'product-mailer-campaigns' ) . '</label></td></tr>';

        echo '<tr><th><label for="pmcpc_wc_register_opt_in_enabled">' . esc_html__( 'Show newsletter signup on WooCommerce registration', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><label><input name="pmcpc_wc_register_opt_in_enabled" type="checkbox" id="pmcpc_wc_register_opt_in_enabled" value="1" ' . checked( true, $wc_register_enabled, false ) . '> ';
        echo esc_html__( 'If enabled, show the newsletter opt-in checkbox on the WooCommerce registration form.', 'product-mailer-campaigns' ) . '</label></td></tr>';


        echo '<tr><th colspan="2"><h2 class="pmcpc-settings-panel-title">' . esc_html__( 'Waiting to Send', 'product-mailer-campaigns' ) . '</h2><p class="pmcpc-settings-section-intro">' . esc_html__( 'Choose how many emails to send at a time and whether sending is paused.', 'product-mailer-campaigns' ) . '</p></th></tr>';
        echo '<tr><th><label for="pmcpc_queue_batch_size">' . esc_html__( 'Emails processed per cron run', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="pmcpc_queue_batch_size" type="number" id="pmcpc_queue_batch_size" class="small-text" min="1" max="200" value="' . esc_attr( $batch_size ) . '">';
        echo '<p class="description">' . esc_html__( 'The maximum number of emails to send in each cron run.', 'product-mailer-campaigns' ) . '</p></td></tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_pause_sending">' . esc_html__( 'Pause all email sending', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="pmcpc_pause_sending" id="pmcpc_pause_sending" value="1" ' . checked( true, $pause_sending, false ) . '> ';
        echo esc_html__( 'If turned on, waiting emails will not send until you switch this off.', 'product-mailer-campaigns' ) . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr><th colspan="2"><h2 class="pmcpc-settings-panel-title">' . esc_html__( 'Admin Notifications', 'product-mailer-campaigns' ) . '</h2><p class="pmcpc-settings-section-intro">' . esc_html__( 'Choose when administrators should receive email alerts and where they should be sent.', 'product-mailer-campaigns' ) . '</p></th></tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__( 'Notify admin on double opt-in', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="pmcpc_notify_double_optin" value="1" ' . checked( true, $notify_double_optin_enabled, false ) . '> ' . esc_html__( 'Send an email to the site admin when a subscriber confirms via double opt-in.', 'product-mailer-campaigns' ) . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_notify_email">' . esc_html__( 'Notification email address', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_notify_email" type="email" id="pmcpc_notify_email" class="regular-text" value="' . esc_attr( $notify_email ) . '">';
        echo '<p class="description">' . esc_html__( 'Where admin notifications (like double opt-in confirmations) should be sent. Defaults to the main admin email if left blank or invalid.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__( 'Require double opt-in for guests', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="pmcpc_guest_double_optin" value="1" ' . checked( true, $guest_double_optin_enabled, false ) . '> ' . esc_html__( 'If enabled, visitors who are not logged in must confirm via email before their subscription is activated.', 'product-mailer-campaigns' ) . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_email_prefs_url">' . esc_html__( 'Email settings page URL', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_email_prefs_url" type="url" id="pmcpc_email_prefs_url" class="regular-text" value="' . esc_attr( $email_prefs_url ) . '">';
        echo '<p class="description">' . esc_html__( 'URL of the page where you added the [pmcpc_email_preferences] shortcode. Logged-out users with an account will be redirected here after logging in.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr><th colspan="2"><h2 class="pmcpc-settings-panel-title">' . esc_html__( 'Subscribe Popup', 'product-mailer-campaigns' ) . '</h2><p class="pmcpc-settings-section-intro">' . esc_html__( 'Control if and when the subscribe popup appears for logged-out visitors.', 'product-mailer-campaigns' ) . '</p></th></tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__( 'Enable subscribe popup', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="pmcpc_subscribe_popup_enabled" value="1" ' . checked( true, $subscribe_popup_enabled, false ) . '> ' . esc_html__( 'Show the subscribe popup to logged-out visitors.', 'product-mailer-campaigns' ) . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_subscribe_popup_delay_ms">' . esc_html__( 'Popup delay (ms)', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="pmcpc_subscribe_popup_delay_ms" type="number" id="pmcpc_subscribe_popup_delay_ms" class="small-text" min="0" max="60000" value="' . esc_attr( (int) $subscribe_popup_delay_ms ) . '">';
        echo '<p class="description">' . esc_html__( 'How long to wait before showing the popup (in milliseconds).', 'product-mailer-campaigns' ) . '</p></td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_subscribe_popup_days_between">' . esc_html__( 'Days between shows', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="pmcpc_subscribe_popup_days_between" type="number" id="pmcpc_subscribe_popup_days_between" class="small-text" min="0" max="365" value="' . esc_attr( (int) $subscribe_popup_days_between ) . '">';
        echo '<p class="description">' . esc_html__( 'Only show the popup again after this many days since it was last dismissed. Set to 0 to show every visit.', 'product-mailer-campaigns' ) . '</p></td>';
        echo '</tr>';

        echo '</tbody><tbody class="pmcpc-settings-tab pmcpc-tab-advanced"' . ( $active_tab !== 'advanced' ? ' style="display:none;"' : '' ) . '>';

        echo '<tr><th colspan="2"><h2>' . esc_html__( 'Tracking', 'product-mailer-campaigns' ) . '</h2></th></tr>';
echo '<tr>';
        echo '<th scope="row">' . esc_html__( 'Tracking debug logging', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="pmcpc_tracking_debug" value="1" ' . checked( true, $tracking_debug, false ) . '> ';
        echo esc_html__( 'Enable raw tracking logs (opens/clicks/views) for troubleshooting and bot/proxy filtering.', 'product-mailer-campaigns' ) . '</label>';
        echo '<p class="description">' . esc_html__( 'When enabled, a lightweight event log is stored and shown on the Diagnostics screen. Disable on very high-traffic sites if you do not need debugging.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';
        echo '<tr><th colspan="2"><h2>' . esc_html__( 'Queue retention', 'product-mailer-campaigns' ) . '</h2></th></tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__( 'Prune queue automatically', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p class="description">' . esc_html__( 'The plugin can automatically delete old queue rows daily to keep the database tidy. Set any value to 0 to keep that status forever.', 'product-mailer-campaigns' ) . '</p>';

        echo '<p><label>' . esc_html__( 'Delete sent items older than (days)', 'product-mailer-campaigns' ) . ' ';
        echo '<input type="number" min="0" max="3650" step="1" name="pmcpc_queue_retention_sent_days" value="' . esc_attr( (int) $queue_retention_sent_days ) . '" style="width:90px;" />';
        echo '</label></p>';

        echo '<p><label>' . esc_html__( 'Delete failed items older than (days)', 'product-mailer-campaigns' ) . ' ';
        echo '<input type="number" min="0" max="3650" step="1" name="pmcpc_queue_retention_failed_days" value="' . esc_attr( (int) $queue_retention_failed_days ) . '" style="width:90px;" />';
        echo '</label></p>';

        echo '<p><label>' . esc_html__( 'Delete pending items older than (days)', 'product-mailer-campaigns' ) . ' ';
        echo '<input type="number" min="0" max="3650" step="1" name="pmcpc_queue_retention_pending_days" value="' . esc_attr( (int) $queue_retention_pending_days ) . '" style="width:90px;" />';
        echo '</label></p>';

        echo '</td>';
        echo '</tr>';

        echo '<tr><th colspan="2"><h2>' . esc_html__( 'Form styling', 'product-mailer-campaigns' ) . '</h2><p class="description">' . esc_html__( 'Choose the default appearance for front-end shortcode forms such as subscribe, contact, selling enquiry, reviews, checkout opt-in, and email preferences.', 'product-mailer-campaigns' ) . '</p></th></tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_form_style_preset">' . esc_html__( 'Form style', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<select name="pmcpc_form_style_preset" id="pmcpc_form_style_preset">';
        $form_style_options = array(
            'theme'   => __( 'Theme default / unstyled', 'product-mailer-campaigns' ),
            'clean'   => __( 'Clean', 'product-mailer-campaigns' ),
            'boxed'   => __( 'Boxed card', 'product-mailer-campaigns' ),
            'elegant' => __( 'Elegant', 'product-mailer-campaigns' ),
        );
        foreach ( $form_style_options as $style_key => $style_label ) {
            echo '<option value="' . esc_attr( $style_key ) . '"' . selected( $form_style_preset, $style_key, false ) . '>' . esc_html( $style_label ) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__( 'Theme default keeps the forms as plain as possible so your theme can style them. The other options add FlowPress styling.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_form_accent_color">' . esc_html__( 'Accent colour', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_form_accent_color" type="color" id="pmcpc_form_accent_color" value="' . esc_attr( $form_accent_color ) . '">';
        echo '<p class="description">' . esc_html__( 'Used for submit buttons, focus outlines, and action links when a FlowPress style is selected.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_form_button_shape">' . esc_html__( 'Button shape', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<select name="pmcpc_form_button_shape" id="pmcpc_form_button_shape">';
        $button_shape_options = array(
            'square' => __( 'Square', 'product-mailer-campaigns' ),
            'soft'   => __( 'Soft rounded', 'product-mailer-campaigns' ),
            'pill'   => __( 'Pill', 'product-mailer-campaigns' ),
        );
        foreach ( $button_shape_options as $shape_key => $shape_label ) {
            echo '<option value="' . esc_attr( $shape_key ) . '"' . selected( $form_button_shape, $shape_key, false ) . '>' . esc_html( $shape_label ) . '</option>';
        }
        echo '</select>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_form_max_width">' . esc_html__( 'Maximum form width', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_form_max_width" type="number" min="0" max="1600" step="1" id="pmcpc_form_max_width" class="small-text" value="' . esc_attr( (int) $form_max_width ) . '"> px';
        echo '<p class="description">' . esc_html__( 'Use 0 for full width. Applies to styled FlowPress shortcode forms.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';
                echo '</tbody><tbody class="pmcpc-settings-tab pmcpc-tab-subscribers"' . ( $active_tab !== 'subscribers' ? ' style="display:none;"' : '' ) . '>';

        echo '<tr><th colspan="2"><h2>' . esc_html__( 'Blocklist (applies to subscribe/contact/selling forms)', 'product-mailer-campaigns' ) . '</h2></th></tr>';

        echo '<tr><td colspan="2"><p class="description">' . esc_html__( 'These block rules apply to all Product Mailer forms. Use this to stop repeat offenders and disposable domains.', 'product-mailer-campaigns' ) . '</p></td></tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_blocked_email_domains">' . esc_html__( 'Additional blocked domains', 'product-mailer-campaigns' ) . '</label>' . wp_kses_post( self::help_icon( __( 'Blocks signups from specific email domains (the part after @). One domain per line, no @ symbol.', 'product-mailer-campaigns' ) ) ) . '</th>';
        echo '<td>';
                echo '<textarea name="pmcpc_blocked_email_domains" id="pmcpc_blocked_email_domains" rows="4" cols="50" class="large-text code">' . esc_textarea( $blocked_email_domains ) . '</textarea>';
        echo '<p class="description">' . esc_html__( 'One domain per line, without the @ symbol. Example: "example.com". These will be blocked in addition to built-in disposable domains and mail.ru.', 'product-mailer-campaigns' ) . '</p>';
        echo '<p class="description">' . esc_html__( 'Safety: major/shared email providers (e.g. Gmail, Yahoo, Outlook) are protected and cannot be blocked as domains. To block a specific sender, add the full email address under “Additional blocked emails”.', 'product-mailer-campaigns' ) . '</p>';
        echo '<p><label><input type="checkbox" name="pmcpc_blocked_domains_auto_add" value="1"' . checked( $blocked_domains_auto_add, 'yes', false ) . ' /> ' . esc_html__( 'Sync domains banned from the Subscribers screen into the spam blocklist.', 'product-mailer-campaigns' ) . '</label></p>';
        echo '<p class="description">' . esc_html__( 'When you use the Subscribers screen to block a domain, this option also adds it to the Additional blocked domains list so it is blocked across forms.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        
        // Additional blocked emails (exact addresses).
        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_blocked_emails">' . esc_html__( 'Additional blocked emails', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<textarea name="pmcpc_blocked_emails" id="pmcpc_blocked_emails" rows="5" class="large-text code">' . esc_textarea( $blocked_emails ) . '</textarea>';
        echo '<p class="description">' . esc_html__( 'One full email address per line. These addresses will always be blocked for subscribe/contact/selling forms. Use this for repeat offenders; prefer domain blocking for disposable domains.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

echo '</tr>';

        echo '</tbody><tbody class="pmcpc-settings-tab pmcpc-tab-spam"' . ( $active_tab !== 'spam' ? ' style="display:none;"' : '' ) . '>';

        echo '<tr><th colspan="2"><h2>' . esc_html__( 'Spam protection', 'product-mailer-campaigns' ) . '</h2></th></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Blocked counts', 'product-mailer-campaigns' ) . '</th><td>';
        echo '<p><strong>' . esc_html__( 'Total blocked:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $spam_total ) . ' &nbsp; <strong>' . esc_html__( 'Today:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $spam_today ) . '</p>';
        if ( ! empty( $spam_top_domains ) ) {
            $bits = array();
            foreach ( $spam_top_domains as $d => $c ) {
                $bits[] = esc_html( $d ) . ' (' . esc_html( (int) $c ) . ')';
            }
            echo '<p><strong>' . esc_html__( 'Top blocked domains:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( implode( ', ', $bits ) ) . '</p>';
        }
        echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=pmcpc_inbox&pmcpc_status=blocked' ) ) . '">' . esc_html__( 'View blocked / spam', 'product-mailer-campaigns' ) . '</a></p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Enable spam protection', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Turns on all built-in anti-spam checks for subscription forms and the subscribe API.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_protection_enabled" value="1" ' . checked( true, $spam_enabled, false ) . '> ' . esc_html__( 'Enable built-in anti-spam checks on subscription forms and API.', 'product-mailer-campaigns' ) . '</label>';
        echo '</td></tr>';

        echo '<tr id="pmcpc-spam-handling"><th scope="row">' . esc_html__( 'Spam handling', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Controls what happens to high-confidence automated spam. You can keep everything for review, or automatically discard obvious bot noise while still counting it in spam stats.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<fieldset>';
        echo '<label style="display:block;margin:0 0 6px;"><input type="radio" name="pmcpc_spam_handling_mode" value="review_all" ' . checked( 'review_all', $spam_handling_mode, false ) . ' /> ' . esc_html__( 'Deliver only Inbox items (recommended)', 'product-mailer-campaigns' ) . '</label>';
        echo '<label style="display:block;margin:0 0 6px;"><input type="radio" name="pmcpc_spam_handling_mode" value="auto_delete_obvious" ' . checked( 'auto_delete_obvious', $spam_handling_mode, false ) . ' /> ' . esc_html__( 'Auto-delete obvious spam', 'product-mailer-campaigns' ) . '</label>';
        echo '</fieldset>';
        echo '<p class="description">' . esc_html__( 'Only Inbox items trigger email notifications. Held/Spam are stored for review and do not send emails.', 'product-mailer-campaigns' ) . '</p>';
        echo '<p class="description">' . esc_html__( 'Auto-delete hides high-confidence spam (like honeypot hits) from the Inbox to keep it clean. Spam counts and top blocked reasons still include these events.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        // Duplicate submission guard.
        $dup_enabled = PMCPC_Settings::get( 'spam_duplicate_guard_enabled', 'no' ) === 'yes';
        $dup_window  = absint( PMCPC_Settings::get( 'spam_duplicate_guard_window', 60 ) );
        if ( $dup_window < 10 ) { $dup_window = 10; }
        echo '<tr><th scope="row">' . esc_html__( 'Duplicate submission guard', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Prevents accidental double-submits (or quick repeat spam) by holding identical submissions for review instead of emailing them again.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_duplicate_guard_enabled" value="1" ' . checked( true, $dup_enabled, false ) . '> ' . esc_html__( 'Prevent duplicate submissions within a short time window.', 'product-mailer-campaigns' ) . '</label>';
        echo '<p style="margin:8px 0 0;">' . esc_html__( 'Window (seconds)', 'product-mailer-campaigns' ) . ' <input type="number" min="10" step="1" name="pmcpc_spam_duplicate_guard_window" value="' . esc_attr( $dup_window ) . '" style="width:90px;" /></p>';
        echo '<p class="description">' . esc_html__( 'Duplicates are stored as Held (review) and do not trigger an email notification.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        

            
// Domain blocks are managed in the Subscribers tab to avoid confusion and accidental loss of changes.
echo '<tr id="pmcpc-spam-blocked-domains"><th scope="row">' . esc_html__( 'Domain blocks', 'product-mailer-campaigns' ) . '</th><td>';

$manage_url = add_query_arg(
    array(
        'page' => 'pmcpc_settings',
        'tab'  => 'subscribers',
    ),
    admin_url( 'admin.php' )
);

echo '<p class="description" style="margin-top:0;">' . esc_html__( 'Permanent domain blocks are managed in the Subscribers tab (“Additional blocked domains”). This avoids duplicated fields and prevents changes being lost.', 'product-mailer-campaigns' ) . '</p>';
echo '<p style="margin:10px 0 0;"><a class="button" href="' . esc_url( $manage_url ) . '">' . esc_html__( 'Manage blocked domains', 'product-mailer-campaigns' ) . '</a></p>';

$blocked_list = is_string( $blocked_email_domains ) ? $blocked_email_domains : '';
$blocked_lines = preg_split( '/\r\n|\r|\n/', (string) $blocked_list );
$blocked_lines = is_array( $blocked_lines ) ? $blocked_lines : array();
$blocked_lines = array_values( array_unique( array_filter( array_map( 'trim', $blocked_lines ) ) ) );

if ( ! empty( $blocked_lines ) ) {
    $preview = array_slice( $blocked_lines, 0, 8 );
    echo '<p style="margin:10px 0 0;"><strong>' . esc_html__( 'Currently blocked domains:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( implode( ', ', $preview ) ) . ( count( $blocked_lines ) > count( $preview ) ? esc_html__( '…', 'product-mailer-campaigns' ) : '' ) . '</p>';
} else {
    echo '<p style="margin:10px 0 0;"><strong>' . esc_html__( 'Currently blocked domains:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html__( 'None', 'product-mailer-campaigns' ) . '</p>';
}

echo '</td></tr>';

// Inbox retention.
        echo '<tr><th scope="row">' . esc_html__( 'Inbox retention', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Automatically prunes old Inbox entries to keep your database small and the Inbox fast.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<p style="margin:0 0 8px;">' . esc_html__( 'Keep Inbox entries for:', 'product-mailer-campaigns' ) . ' ';
        echo '<select name="pmcpc_inbox_retention_days">';
        $opts = array(
            0   => __( 'Forever', 'product-mailer-campaigns' ),
            30  => __( '30 days', 'product-mailer-campaigns' ),
            90  => __( '90 days', 'product-mailer-campaigns' ),
            180 => __( '180 days', 'product-mailer-campaigns' ),
        );
        foreach ( $opts as $val => $label ) {
            echo '<option value="' . esc_attr( $val ) . '"' . selected( $inbox_retention_days, (int) $val, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
        echo '</p>';

        echo '<p style="margin:0 0 8px;">' . esc_html__( 'Keep Spam for:', 'product-mailer-campaigns' ) . ' ';
        echo '<select name="pmcpc_spam_retention_days">';
        foreach ( $opts as $val => $label ) {
            echo '<option value="' . esc_attr( $val ) . '"' . selected( $spam_retention_days, (int) $val, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
        echo '</p>';
        echo '<p class="description">' . esc_html__( 'Cleanup runs daily via WordPress cron. This does not affect your subscriber list.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';


        echo '<tr id="pmcpc-spam-honeypot"><th scope="row">' . esc_html__( 'Honeypot field', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Adds a hidden field bots often fill in. If it is filled, the signup is blocked. Real visitors will not see this field.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_honeypot_enabled" value="1" ' . checked( true, $spam_honeypot_enabled, false ) . '> ' . esc_html__( 'Add a hidden field bots often fill; submissions that fill it are blocked.', 'product-mailer-campaigns' ) . '</label>';
        echo '</td></tr>';

        echo '<tr id="pmcpc-spam-timing"><th scope="row">' . esc_html__( 'Form timing check', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Adds a signed hidden field and blocks very fast submissions. This helps catch bots that post directly without loading the page.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_form_timing_enabled" value="1" ' . checked( true, $spam_form_timing_enabled, false ) . '> ' . esc_html__( 'Enable timing token + minimum submit time for PMCPC contact/selling forms.', 'product-mailer-campaigns' ) . '</label>';
        echo '<p style="margin-top:8px;">';
        echo '<label>' . esc_html__( 'Minimum seconds before submit', 'product-mailer-campaigns' ) . ' <input type="number" min="0" max="120" name="pmcpc_spam_min_submit_seconds" value="' . esc_attr( $spam_min_submit_seconds ) . '" class="small-text" /></label>';
        echo ' <span class="description" style="margin-left:8px;">' . esc_html__( 'Set 0 to disable the “too fast” rule while keeping the signed token check.', 'product-mailer-campaigns' ) . '</span>';
        echo '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Rate limiting', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Limits repeated subscribe attempts from the same IP address in a short period to reduce bot attacks.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_rate_limit_enabled" value="1" ' . checked( true, $spam_rate_enabled, false ) . '> ' . esc_html__( 'Limit repeated subscribe attempts from the same IP.', 'product-mailer-campaigns' ) . '</label>';
        echo '<p style="margin-top:8px;">';
        echo '<label>' . esc_html__( 'Max attempts', 'product-mailer-campaigns' ) . ' <input type="number" min="1" max="100" name="pmcpc_spam_rate_limit_max" value="' . esc_attr( $spam_rate_max ) . '" class="small-text" /></label> ';
        echo '<label style="margin-left:10px;">' . esc_html__( 'Window (seconds)', 'product-mailer-campaigns' ) . ' <input type="number" min="60" max="86400" name="pmcpc_spam_rate_limit_window" value="' . esc_attr( $spam_rate_window ) . '" class="small-text" /></label>';
        echo '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Suspicious TLDs', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Blocks signups where the email domain ends in one of these TLDs (the part after the final dot), e.g. ".ru" or ".xyz".', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_suspicious_tlds_enabled" value="1" ' . checked( true, $spam_tlds_enabled, false ) . '> ' . esc_html__( 'Block signups from suspicious top-level domains.', 'product-mailer-campaigns' ) . '</label>';
        echo '<p style="margin-top:8px;"><textarea name="pmcpc_spam_suspicious_tlds" rows="4" cols="50" class="large-text code">' . esc_textarea( $spam_tlds ) . '</textarea></p>';
        echo '<p class="description">' . esc_html__( 'One TLD per line (without the dot). Example: ru', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th colspan="2" style="padding-top:16px;"><h3 style="margin:0;">' . esc_html__( 'Auto-block protection', 'product-mailer-campaigns' ) . '</h3><p class="description" style="margin:6px 0 0;">' . esc_html__( 'Controls when domains are automatically escalated into your blocked domains list.', 'product-mailer-campaigns' ) . '</p></th></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Auto-block repeat offender domains', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'If the same email domain triggers blocks repeatedly, it will be added to “Additional blocked domains” automatically.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_auto_block_domains_enabled" value="1" ' . checked( true, $spam_auto_domains_enabled, false ) . '> ' . esc_html__( 'Automatically add email domains to the blocked list after repeated blocked attempts.', 'product-mailer-campaigns' ) . '</label>';
        echo '<p style="margin-top:8px;">';
        echo '<label>' . esc_html__( 'Threshold (blocked attempts)', 'product-mailer-campaigns' ) . ' <input type="number" min="2" max="50" name="pmcpc_spam_auto_block_domains_threshold" value="' . esc_attr( $spam_auto_domains_threshold ) . '" class="small-text" /></label> ';
        echo '<label style="margin-left:10px;">' . esc_html__( 'Window (seconds)', 'product-mailer-campaigns' ) . ' <input type="number" min="300" max="604800" name="pmcpc_spam_auto_block_domains_window" value="' . esc_attr( $spam_auto_domains_window ) . '" class="small-text" /></label>';
        echo '</p>';
        echo '<p style="margin-top:8px;">';
        echo '<label for="pmcpc_spam_auto_block_protected_domains" style="display:block;margin-bottom:4px;">' . esc_html__( 'Major email providers (exclude from auto-blocking)', 'product-mailer-campaigns' ) . '</label>';
        echo '<textarea name="pmcpc_spam_auto_block_protected_domains" id="pmcpc_spam_auto_block_protected_domains" rows="4" cols="50" class="large-text code">' . esc_textarea( $spam_auto_protected_domains ) . '</textarea>';
        echo '<span class="description" style="display:block;margin-top:4px;">' . esc_html__( 'One domain per line (no @). Prevents common providers (e.g. Gmail, Yahoo, Outlook) from being automatically added to “Additional blocked domains” by the repeat-offender rule. Individual messages may still be blocked. Subdomains are matched too.', 'product-mailer-campaigns' ) . '</span>';
        echo '</p>';
        echo '<p class="description">' . esc_html__( 'Example: 3 blocked attempts within 24 hours will add that domain to “Additional blocked domains”.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr id="pmcpc-spam-spammy-name"><th scope="row">' . esc_html__( 'Spammy name handling', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Controls what happens when first/last names look automated (duplicate names, URL-like text, very long values).', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<select name="pmcpc_spam_name_policy">';
        echo '<option value="blank"' . selected( $spam_name_policy, 'blank', false ) . '>' . esc_html__( 'Strip name but allow subscription', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="block"' . selected( $spam_name_policy, 'block', false ) . '>' . esc_html__( 'Block subscription', 'product-mailer-campaigns' ) . '</option>';
        echo '</select>';
        echo '<p class="description">' . esc_html__( 'If the first/last name looks automated (duplicate names, URL-like text, etc.).', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Email domain DNS validation', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Checks the email domain has valid DNS records (MX or A). Helps reduce fake / disposable-looking domains.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_email_dns_enabled" value="1" ' . checked( true, $spam_email_dns_enabled, false ) . '> ' . esc_html__( 'Validate email domains using DNS (MX/A).', 'product-mailer-campaigns' ) . '</label>';
        echo '<p class="description">' . esc_html__( 'If enabled, addresses at domains with no MX or A record will be blocked.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Message/content spam scoring', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Extra checks for contact/selling forms (not the subscribe email itself). Looks for links, spam words, suspicious markup, and high non‑Latin content.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_message_scoring_enabled" value="1" ' . checked( true, $spam_message_scoring_enabled, false ) . '> ' . esc_html__( 'Enable message/content spam scoring.', 'product-mailer-campaigns' ) . '</label>';
        echo '<div style="margin-top:10px;">';
        echo '<label style="display:inline-block;margin-right:10px;">' . esc_html__( 'Max links allowed', 'product-mailer-campaigns' ) . ' <input type="number" min="0" max="10" name="pmcpc_spam_message_max_links" value="' . esc_attr( $spam_message_max_links ) . '" class="small-text" /></label>';
        echo '<label style="display:inline-block;margin-right:10px;">' . esc_html__( 'Non‑Latin threshold', 'product-mailer-campaigns' ) . ' <input type="number" step="0.05" min="0" max="1" name="pmcpc_spam_message_non_ascii_threshold" value="' . esc_attr( $spam_message_non_ascii_threshold ) . '" class="small-text" /></label>';
        echo '<label style="display:inline-block;margin-right:10px;">' . esc_html__( 'Hold score', 'product-mailer-campaigns' ) . ' <input type="number" min="1" max="99" name="pmcpc_spam_message_hold_score" value="' . esc_attr( $spam_message_hold_score ) . '" class="small-text" /></label>';
        echo '<label style="display:inline-block;">' . esc_html__( 'Block score', 'product-mailer-campaigns' ) . ' <input type="number" min="1" max="99" name="pmcpc_spam_message_block_score" value="' . esc_attr( $spam_message_block_score ) . '" class="small-text" /></label>';
        echo '</div>';
            echo '<p style="margin-top:8px;"><label><input type="checkbox" name="pmcpc_spam_message_prefer_hold_on_non_ascii_only" value="1" ' . checked( true, $spam_message_prefer_hold_on_non_ascii_only, false ) . '> ' . esc_html__( 'Prefer Hold (review) for high non‑Latin messages unless other strong spam signals are present', 'product-mailer-campaigns' ) . '</label></p>';
        echo '<p style="margin-top:8px;"><label><input type="checkbox" name="pmcpc_spam_message_prefer_hold_over_block" value="1" ' . checked( true, $spam_message_prefer_hold_over_block, false ) . '> ' . esc_html__( 'Prefer Hold over Block for message scoring (review instead of blocking).', 'product-mailer-campaigns' ) . '</label></p>';

        echo '<p style="margin-top:8px;">';
        echo '<label><input type="checkbox" name="pmcpc_spam_message_suspicious_markup_enabled" value="1" ' . checked( true, $spam_message_suspicious_markup_enabled, false ) . '> ' . esc_html__( 'Treat BBCode / suspicious markup (e.g. [url=]) as spammy.', 'product-mailer-campaigns' ) . '</label>';
        echo '</p>';
        echo '<p style="margin-top:8px;">';
        echo '<label><input type="checkbox" name="pmcpc_spam_message_keywords_enabled" value="1" ' . checked( true, $spam_message_keywords_enabled, false ) . '> ' . esc_html__( 'Scan for spammy words/phrases in subject + message.', 'product-mailer-campaigns' ) . '</label>';
        echo '</p>';
        echo '<p style="margin-top:8px;"><textarea name="pmcpc_spam_message_keywords" rows="6" cols="50" class="large-text code">' . esc_textarea( $spam_message_keywords ) . '</textarea></p>';
        echo '<p class="description">' . esc_html__( 'One word/phrase per line. Matches are case-insensitive. Use short phrases for best results.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th colspan="2" style="padding-top:16px;"><h3 style="margin:0;">' . esc_html__( 'Trust overrides', 'product-mailer-campaigns' ) . '</h3><p class="description" style="margin:6px 0 0;">' . esc_html__( 'Allow specific senders through to reduce false positives without weakening global rules.', 'product-mailer-campaigns' ) . '</p></th></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Allowlist (never block)', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Emails/domains in this list bypass email/domain blocks and message scoring. Useful for reducing false positives. Does not bypass form integrity checks like honeypots or timing tokens.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<p style="margin:0 0 6px;"><strong>' . esc_html__( 'Allowlisted email addresses', 'product-mailer-campaigns' ) . '</strong></p>';
        echo '<textarea name="pmcpc_allowlisted_emails" rows="4" cols="50" class="large-text code">' . esc_textarea( $allowlisted_emails ) . '</textarea>';
        echo '<p class="description">' . esc_html__( 'One email per line.', 'product-mailer-campaigns' ) . '</p>';
        echo '<p style="margin:12px 0 6px;"><strong>' . esc_html__( 'Allowlisted domains', 'product-mailer-campaigns' ) . '</strong></p>';
        echo '<textarea name="pmcpc_allowlisted_email_domains" rows="4" cols="50" class="large-text code">' . esc_textarea( $allowlisted_email_domains ) . '</textarea>';
        echo '<p class="description">' . esc_html__( 'One domain per line (no @). Subdomains are matched too.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Spam logging', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Stores a lightweight log of blocked attempts so you can review what is being blocked and why.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<label><input type="checkbox" name="pmcpc_spam_log_enabled" value="1" ' . checked( true, $spam_log_enabled, false ) . '> ' . esc_html__( 'Store a lightweight log of blocked attempts (last 200 shown).', 'product-mailer-campaigns' ) . '</label>';
        echo '</td></tr>';

        // Test tool.
        echo '<tr><th scope="row">' . esc_html__( 'Test spam protection', 'product-mailer-campaigns' ) . wp_kses_post( self::help_icon( __( 'Test an email/name against your current spam rules without subscribing the address.', 'product-mailer-campaigns' ) ) ) . '</th><td>';
        echo '<div class="pmcpc-test-spam">';
        echo '<div class="row">';
        echo '<span class="label">' . esc_html__( 'Sender', 'product-mailer-campaigns' ) . '</span>';
        echo '<input type="email" id="pmcpc_test_spam_email" class="regular-text" placeholder="email@example.com" />';
        echo '<input type="text" id="pmcpc_test_spam_first_name" class="regular-text" style="max-width:160px;" placeholder="First name" />';
        echo '<input type="text" id="pmcpc_test_spam_last_name" class="regular-text" style="max-width:160px;" placeholder="Last name" />';
        echo '<select id="pmcpc_test_spam_context" title="Context"><option value="subscribe">subscribe</option><option value="checkout">checkout</option><option value="contact">contact</option><option value="selling">selling</option></select>';
        echo '</div>';

        echo '<div class="row">';
        echo '<span class="label">' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</span>';
        echo '<input type="text" id="pmcpc_test_spam_subject" class="regular-text" style="max-width:520px;width:100%;" placeholder="(optional)" />';
        echo '</div>';

        echo '<div class="row">';
        echo '<span class="label" style="vertical-align:top;">' . esc_html__( 'Message', 'product-mailer-campaigns' ) . '</span>';
        echo '<textarea id="pmcpc_test_spam_message" rows="4" placeholder="Paste a message body here to test content scoring (links, keywords, non-Latin threshold, markup)."></textarea>';
        echo '</div>';

        echo '<div class="row">';
        echo '<span class="label">' . esc_html__( 'Simulate form checks', 'product-mailer-campaigns' ) . '</span>';
        echo '<label style="margin-right:10px;"><input type="checkbox" id="pmcpc_test_spam_hp_on" value="1" /> ' . esc_html__( 'Honeypot filled', 'product-mailer-campaigns' ) . '</label>';
        echo '<label style="margin-right:6px;">' . esc_html__( 'Timing token', 'product-mailer-campaigns' ) . '</label>';
        echo '<select id="pmcpc_test_spam_ft_mode"><option value="valid">valid</option><option value="missing">missing</option><option value="invalid">invalid</option></select>';
        echo '<label style="margin-left:10px;margin-right:6px;">' . esc_html__( 'Seconds since load', 'product-mailer-campaigns' ) . '</label>';
        echo '<input type="number" id="pmcpc_test_spam_ft_seconds" class="small-text" min="0" step="1" value="10" />';
        echo '</div>';

        echo '<div class="row">';
        echo '<button type="button" class="button" id="pmcpc-test-spam-btn">' . esc_html__( 'Test spam protection', 'product-mailer-campaigns' ) . '</button>';
        echo '</div>';

        echo '<div id="pmcpc-test-spam-result" class="pmcpc-test-result" aria-live="polite"></div>';
        echo '<div id="pmcpc-test-spam-breakdown" class="pmcpc-test-breakdown" aria-live="polite"></div>';
        echo '</div>';
        echo '<p class="description">' . esc_html__( 'This does not send emails or create a subscriber. It reports whether the current rules would allow, hold, block, or strip the name, and shows a breakdown for timing/identity/message checks.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';


        echo '</tbody><tbody class="pmcpc-settings-tab pmcpc-tab-lifecycle"' . ( $active_tab !== 'lifecycle' ? ' style="display:none;"' : '' ) . '>';

        echo '<tr><th colspan="2"><h2>' . esc_html__( 'Lifecycle tags & automation', 'product-mailer-campaigns' ) . '</h2></th></tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_lifecycle_tags">' . esc_html__( 'Lifecycle tags', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<textarea name="pmcpc_lifecycle_tags" id="pmcpc_lifecycle_tags" rows="4" cols="50" class="large-text code">' . esc_textarea( $lifecycle_tags ) . '</textarea>';
        echo '<p class="description">' . esc_html__( 'One tag per line. Line 1 = "new-customer", line 2 = "repeat-customer", line 3 = "high-value", line 4 = "vip", line 5 = "recent-buyer", line 6 = "lapsed-customer". Lines 1–6 are auto-managed; any extra lines are manual-only lifecycle tags (not auto-managed). These tags are shown under Lifecycle in the Tag Inspector.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_lifecycle_auto_enabled">' . esc_html__( 'Enable WooCommerce lifecycle auto-tagging', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="pmcpc_lifecycle_auto_enabled" id="pmcpc_lifecycle_auto_enabled" value="1"' . checked( $lifecycle_auto_enabled, true, false ) . '> ' . esc_html__( 'Automatically add lifecycle tags based on completed orders for this billing email.', 'product-mailer-campaigns' ) . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_lifecycle_high_value_threshold">' . esc_html__( 'High-value customer threshold', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_lifecycle_high_value_threshold" type="number" step="0.01" min="0" id="pmcpc_lifecycle_high_value_threshold" class="small-text" value="' . esc_attr( $lifecycle_high_value_threshold ) . '">';
        echo '<p class="description">' . esc_html__( 'Total completed order value at which the "high-value" lifecycle tag is added (0 to disable).', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';


        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_lifecycle_vip_threshold">' . esc_html__( 'VIP customer threshold', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_lifecycle_vip_threshold" type="number" step="0.01" min="0" id="pmcpc_lifecycle_vip_threshold" class="small-text" value="' . esc_attr( $lifecycle_vip_threshold ) . '">';
        echo '<p class="description">' . esc_html__( 'Total completed order value at which the "vip" lifecycle tag is added (0 to disable).', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_lifecycle_recent_days">' . esc_html__( 'Recent buyer window (days)', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_lifecycle_recent_days" type="number" step="1" min="0" id="pmcpc_lifecycle_recent_days" class="small-text" value="' . esc_attr( $lifecycle_recent_days ) . '">';
        echo '<p class="description">' . esc_html__( 'If the most recent completed order is within this many days, the "recent-buyer" tag is added (0 to disable).', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_lifecycle_lapsed_days">' . esc_html__( 'Lapsed customer threshold (days)', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_lifecycle_lapsed_days" type="number" step="1" min="0" id="pmcpc_lifecycle_lapsed_days" class="small-text" value="' . esc_attr( $lifecycle_lapsed_days ) . '">';
        echo '<p class="description">' . esc_html__( 'If the most recent completed order is older than this many days, the "lapsed-customer" tag is added (0 to disable).', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';


// Shortcodes documentation.
        echo '</tbody><tbody class="pmcpc-settings-tab pmcpc-tab-advanced"' . ( $active_tab !== 'advanced' ? ' style="display:none;"' : '' ) . '>';

        echo '<tr><th colspan="2"><h2>' . esc_html__( 'Shortcodes', 'product-mailer-campaigns' ) . '</h2></th></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Subscribe form', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_subscribe]</code></p>';
        echo '<p class="description">' . esc_html__( 'Displays a front-end subscribe form that supports double opt-in, login-aware behaviour, and welcome campaigns.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Email preferences (account area)', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_email_preferences]</code></p>';
        echo '<p class="description">' . esc_html__( 'Allows logged-in customers to view and manage their email subscription status, tags, frequency, and recent email history.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Preferences centre (public page)', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_preferences_center]</code></p>';
        echo '<p class="description">' . esc_html__( 'Shows the manage-preferences page for subscribers coming from email links (token-based). Place this shortcode on a public page and use that page as your Manage Preferences URL.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Checkout opt-in checkbox', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_checkout_optin]</code></p>';
        echo '<p class="description">' . esc_html__( 'Outputs the same opt-in checkbox used on the WooCommerce checkout. Useful for block-based checkout layouts or custom forms. You can override the label with an attribute, for example: [pmcpc_checkout_optin label="Email me updates and special offers"].', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';
        echo '<tr><th scope="row">' . esc_html__( 'Contact form', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_contact_form]</code></p>';
        echo '<p class="description">' . esc_html__( 'Simple contact form that emails the site admin. You can use [pmcpc_contact_form title="Contact us"] to change the heading.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';
        echo '<tr><th scope="row">' . esc_html__( 'Selling enquiry form', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_selling_form]</code></p>';
        echo '<p class="description">' . esc_html__( 'Form for visitors to offer items for sale to you. Captures contact details and item info, sending them to the admin email.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th colspan="2"><h3>' . esc_html__( 'Reviews', 'product-mailer-campaigns' ) . '</h3></th></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Combined reviews (recommended)', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_all_reviews]</code></p>';
        echo '<p class="description">' . esc_html__( 'Displays approved standard reviews and product reviews together. Best for a main Customer Reviews page or homepage trust section.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Standard reviews', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_reviews]</code></p>';
        echo '<p class="description">' . esc_html__( 'Displays approved general store reviews only.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Product reviews', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_product_reviews]</code></p>';
        echo '<p class="description">' . esc_html__( 'Displays approved product reviews for the current WooCommerce product. You can also target a specific product with [pmcpc_product_reviews product="123"].', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__( 'Form shortcode', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><code>[pmcpc_form id="123"]</code></p>';
        echo '<p class="description">' . esc_html__( 'Displays a specific saved form such as a review form, product review form, contact form, or selling enquiry form.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '</tbody><tbody class="pmcpc-settings-tab pmcpc-tab-email"' . ( $active_tab !== 'email' ? ' style="display:none;"' : '' ) . '>';

        echo '<tr><th colspan="2"><h2>' . esc_html__( 'Custom SMTP (optional)', 'product-mailer-campaigns' ) . '</h2></th></tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__( 'Enable custom SMTP', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" id="pmcpc_smtp_enabled" name="pmcpc_smtp_settings[enabled]" value="1" ' . checked( true, $smtp_enabled, false ) . '> ' . esc_html__( 'Route all wp_mail() emails through this SMTP server.', 'product-mailer-campaigns' ) . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_smtp_host">' . esc_html__( 'SMTP host', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_smtp_settings[host]" type="text" id="pmcpc_smtp_host" class="regular-text" value="' . esc_attr( $smtp_host ) . '">';
        echo '<p class="description">' . esc_html__( 'For example: smtp.fasthosts.co.uk, smtp.sendgrid.net, email-smtp.eu-west-1.amazonaws.com', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_smtp_port">' . esc_html__( 'Port', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_smtp_settings[port]" type="number" id="pmcpc_smtp_port" class="small-text" value="' . esc_attr( $smtp_port ) . '">';
        echo '<p class="description">' . esc_html__( 'Common values: 587 (TLS), 465 (SSL), 25 (no encryption).', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_smtp_encryption">' . esc_html__( 'Encryption', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<select name="pmcpc_smtp_settings[encryption]" id="pmcpc_smtp_encryption">';
        echo '<option value="none"' . selected( $smtp_encryption, 'none', false ) . '>' . esc_html__( 'None', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="ssl"' . selected( $smtp_encryption, 'ssl', false ) . '>' . esc_html__( 'SSL', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="tls"' . selected( $smtp_encryption, 'tls', false ) . '>' . esc_html__( 'TLS', 'product-mailer-campaigns' ) . '</option>';
        echo '</select>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__( 'Use authentication', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" id="pmcpc_smtp_auth" name="pmcpc_smtp_settings[auth]" value="1" ' . checked( true, $smtp_auth, false ) . '> ' . esc_html__( 'Most SMTP servers require a username and password.', 'product-mailer-campaigns' ) . '</label>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_smtp_username">' . esc_html__( 'Username', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_smtp_settings[username]" type="text" id="pmcpc_smtp_username" class="regular-text" value="' . esc_attr( $smtp_username ) . '">';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_smtp_password">' . esc_html__( 'Password', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_smtp_settings[password]" type="password" id="pmcpc_smtp_password" class="regular-text" value="' . esc_attr( $smtp_password ) . '" autocomplete="new-password">';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_smtp_from_email">' . esc_html__( 'From email (optional)', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_smtp_settings[from_email]" type="email" id="pmcpc_smtp_from_email" class="regular-text" value="' . esc_attr( $smtp_from_email ) . '">';
        echo '<p class="description">' . esc_html__( 'If set, this address will be used as the From email for all emails sent by wp_mail().', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_smtp_from_name">' . esc_html__( 'From name (optional)', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="pmcpc_smtp_settings[from_name]" type="text" id="pmcpc_smtp_from_name" class="regular-text" value="' . esc_attr( $smtp_from_name ) . '">';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row"><label for="pmcpc_smtp_test_to">' . esc_html__( 'Test custom SMTP', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input type="email" id="pmcpc_smtp_test_to" class="regular-text" value="' . esc_attr( get_option( 'admin_email' ) ) . '" placeholder="you@example.com"> ';
        echo '<button type="button" class="button" id="pmcpc-test-smtp-btn">' . esc_html__( 'Send test email', 'product-mailer-campaigns' ) . '</button>';
        echo '<p class="description">' . esc_html__( 'Sends a test email using the SMTP values currently shown above. Save Settings after a successful test if you changed any values.', 'product-mailer-campaigns' ) . '</p>';
        echo '<div id="pmcpc-test-smtp-result" class="pmcpc-test-result" aria-live="polite"></div>';
        echo '<div id="pmcpc-test-smtp-breakdown" class="pmcpc-test-breakdown"></div>';
        echo '</td>';
        echo '</tr>';

        echo '</tbody></table>';

        submit_button( __( 'Save Settings', 'product-mailer-campaigns' ) );

        echo '</form>';
        echo '</div>';
        echo '</div>';

        echo '<aside class="pmcpc-settings-layout__side">';
        echo '<div class="pmcpc-settings-card pmcpc-settings-status-card">';
        echo '<h3>' . esc_html__( 'Workspace status', 'product-mailer-campaigns' ) . '</h3>';
        echo '<div class="pmcpc-settings-status-grid">';
        echo '<div><strong>' . esc_html__( 'Mode', 'product-mailer-campaigns' ) . '</strong><span>' . esc_html( $license_mode ) . '</span></div>';
        echo '<div><strong>' . esc_html__( 'Email queue', 'product-mailer-campaigns' ) . '</strong><span>' . esc_html( $pause_sending ? __( 'Paused', 'product-mailer-campaigns' ) : __( 'Ready to send', 'product-mailer-campaigns' ) ) . '</span></div>';
        echo '<div><strong>' . esc_html__( 'Upgrade status', 'product-mailer-campaigns' ) . '</strong><span>' . esc_html( $license_state ) . '</span></div>';
        echo '</div>';
        echo '<p style="margin:14px 0 0;"><a class="button button-primary" href="' . esc_url( $license_cta_url ) . '">' . esc_html( $license_cta_label ) . '</a></p>';
        echo '</div>';

        pmcpc_render_pro_upsell_box();
        echo '</aside>';

        echo '</div>';
        echo '</div>';
    }

}
