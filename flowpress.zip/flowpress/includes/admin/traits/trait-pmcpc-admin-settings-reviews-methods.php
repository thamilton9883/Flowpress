<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Admin_Settings_Reviews_Methods {
    protected static function render_reviews_page_modern() {
        $status   = isset( $_GET['pmcpc_status'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_status'] ) ) : '';
        $type     = isset( $_GET['pmcpc_review_type'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_review_type'] ) ) : '';
        $search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
        $paged    = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;
        $per_page = 20;
        $filters  = array();
        if ( $status ) {
            $filters['status'] = $status;
        }
        if ( $type ) {
            $filters['review_type'] = $type;
        }
        if ( $search ) {
            $filters['s'] = $search;
        }

        if ( isset( $_GET['pmcpc_review_action'], $_GET['pmcpc_review_id'], $_GET['_wpnonce'] ) ) {
            $action = sanitize_key( wp_unslash( $_GET['pmcpc_review_action'] ) );
            $id     = absint( wp_unslash( $_GET['pmcpc_review_id'] ) );
            if ( $id && wp_verify_nonce( sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ), 'pmcpc_review_action_' . $id . '_' . $action ) ) {
                $notice_text = '';
                if ( in_array( $action, array( 'approve', 'reject', 'pending', 'private' ), true ) ) {
                    $status_map    = array(
                        'approve' => 'approved',
                        'reject'  => 'rejected',
                        'pending' => 'pending',
                        'private' => 'private_feedback',
                    );
                    $review_status = isset( $status_map[ $action ] ) ? $status_map[ $action ] : 'pending';
                    PMCPC_Reviews::update_status( $id, $review_status );
                    $notice_text = __( 'Review updated.', 'product-mailer-campaigns' );
                } elseif ( 'delete' === $action ) {
                    PMCPC_Reviews::delete_review( $id );
                    $notice_text = __( 'Review deleted.', 'product-mailer-campaigns' );
                }

                if ( $notice_text ) {
                    $redirect_args = array(
                        'page'              => 'pmcpc_reviews',
                        'pmcpc_notice_type' => 'success',
                        'pmcpc_notice_text' => $notice_text,
                    );
                    if ( $status ) {
                        $redirect_args['pmcpc_status'] = $status;
                    }
                    if ( $type ) {
                        $redirect_args['pmcpc_review_type'] = $type;
                    }
                    if ( $search ) {
                        $redirect_args['s'] = $search;
                    }
                    if ( $paged > 1 ) {
                        $redirect_args['paged'] = $paged;
                    }

                    $focus_rows = PMCPC_Reviews::get_reviews( $filters, $per_page, ( $paged - 1 ) * $per_page );
                    if ( empty( $focus_rows ) && $paged > 1 ) {
                        $paged = 1;
                        unset( $redirect_args['paged'] );
                        $focus_rows = PMCPC_Reviews::get_reviews( $filters, $per_page, 0 );
                    }
                    if ( ! empty( $focus_rows ) && ! empty( $focus_rows[0]['id'] ) ) {
                        $redirect_args['pmcpc_focus_review_id'] = (int) $focus_rows[0]['id'];
                        $redirect_args['pmcpc_notice_text']    .= ' ' . __( 'Next matching review highlighted below.', 'product-mailer-campaigns' );
                    }

                    $redirect_url = add_query_arg( $redirect_args, admin_url( 'admin.php' ) );
                    if ( ! empty( $redirect_args['pmcpc_focus_review_id'] ) ) {
                        $redirect_url .= '#pmcpc-review-' . (int) $redirect_args['pmcpc_focus_review_id'];
                    }
                    wp_safe_redirect( $redirect_url );
                    exit;
                }
            }
        }

        $focus_review_id = isset( $_GET['pmcpc_focus_review_id'] ) ? absint( wp_unslash( $_GET['pmcpc_focus_review_id'] ) ) : 0;

        $total                = PMCPC_Reviews::count_reviews( $filters );
        $rows                 = PMCPC_Reviews::get_reviews( $filters, $per_page, ( $paged - 1 ) * $per_page );
        $pending_count        = PMCPC_Reviews::count_reviews( array( 'status' => 'pending' ) );
        $approved_count       = PMCPC_Reviews::count_reviews( array( 'status' => 'approved' ) );
        $private_count        = PMCPC_Reviews::count_reviews( array( 'status' => 'private_feedback' ) );
        $product_review_count = PMCPC_Reviews::count_reviews( array( 'review_type' => 'product_review' ) );

        echo '<div class="wrap">';
        PMCPC_Admin::render_app_header( __( 'Reviews', 'product-mailer-campaigns' ) );
        if ( isset( $_GET['pmcpc_notice_type'], $_GET['pmcpc_notice_text'] ) ) {
            $notice_type = sanitize_key( wp_unslash( $_GET['pmcpc_notice_type'] ) );
            $notice_text = sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_notice_text'] ) );
            if ( $notice_type && $notice_text ) {
                echo '<div class="notice notice-' . esc_attr( sanitize_html_class( $notice_type ) ) . ' is-dismissible"><p>' . esc_html( $notice_text ) . '</p></div>';
            }
        }
        PMCPC_Admin::render_page_intro(
            __( 'Reviews', 'product-mailer-campaigns' ),
            __( 'Review, approve, reject, or keep private the customer reviews captured through PMCPC forms.', 'product-mailer-campaigns' ),
            array(
                array(
                    'label' => __( 'Moderate new reviews first', 'product-mailer-campaigns' ),
                    'icon'  => 'dashicons-star-filled',
                ),
                array(
                    'label' => __( 'Approve trusted feedback', 'product-mailer-campaigns' ),
                    'icon'  => 'dashicons-yes-alt',
                ),
                array(
                    'label' => __( 'Keep sensitive replies private', 'product-mailer-campaigns' ),
                    'icon'  => 'dashicons-hidden',
                ),
            )
        );
        PMCPC_Admin::render_stats_strip(
            array(
                array(
                    'label' => __( 'Pending', 'product-mailer-campaigns' ),
                    'value' => (string) $pending_count,
                    'meta'  => __( 'Need moderation', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Approved', 'product-mailer-campaigns' ),
                    'value' => (string) $approved_count,
                    'meta'  => __( 'Visible reviews', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Private', 'product-mailer-campaigns' ),
                    'value' => (string) $private_count,
                    'meta'  => __( 'Hidden feedback', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Product reviews', 'product-mailer-campaigns' ),
                    'value' => (string) $product_review_count,
                    'meta'  => __( 'WooCommerce product feedback', 'product-mailer-campaigns' ),
                ),
            )
        );

        echo '<style>
        .pmcpc-reviews-toolbar{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-start;justify-content:space-between;margin:12px 0 18px;padding:14px 16px;background:#fff;border:1px solid #dcdcde;border-radius:12px;}
        .pmcpc-reviews-toolbar__intro{max-width:620px;margin:0;color:#50575e;}
        .pmcpc-reviews-filter-form{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0;}
        .pmcpc-active-filters{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:-4px 0 14px;padding:10px 14px;background:#fff;border:1px solid #dcdcde;border-radius:12px;}
        .pmcpc-active-filters__label{font-weight:600;color:#1d2327;}
        .pmcpc-active-filters__chip{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border:1px solid #dcdcde;border-radius:999px;background:#f6f7f7;color:#1d2327;line-height:1.4;}
        .pmcpc-active-filters__clear{margin-left:auto;}
        .pmcpc-reviews-table-wrap{margin-top:12px;background:#fff;border:1px solid #dcdcde;border-radius:12px;overflow:hidden;}
        .pmcpc-reviews-table-wrap__scroll{overflow-x:auto;overflow-y:hidden;max-width:100%;-webkit-overflow-scrolling:touch;}
        .pmcpc-reviews-table-wrap table{margin:0;border:none;width:max-content;min-width:100%;}
        .pmcpc-reviews-status{display:inline-flex;align-items:center;padding:4px 10px;border-radius:999px;border:1px solid #dcdcde;background:#f6f7f7;font-weight:600;font-size:12px;line-height:1.2;}
        .pmcpc-reviews-status--approved{background:#edfaef;border-color:#b7e1bf;color:#1e6b34;}
        .pmcpc-reviews-status--pending{background:#fff8e5;border-color:#e7c56f;color:#8a5a00;}
        .pmcpc-reviews-status--rejected{background:#fff1f0;border-color:#f0b2ad;color:#b42318;}
        .pmcpc-reviews-status--private_feedback{background:#eef4ff;border-color:#bfd1ff;color:#174ea6;}
        .pmcpc-reviews-rating{display:flex;flex-direction:column;gap:6px;}
        .pmcpc-reviews-actions{display:flex;flex-direction:column;gap:6px;min-width:150px;}
        .pmcpc-reviews-actions__primary,.pmcpc-reviews-actions__secondary{display:flex;flex-wrap:wrap;gap:6px;}
        .pmcpc-reviews-actions__secondary a{color:#50575e;text-decoration:none;}
        .pmcpc-reviews-actions__secondary a:hover{text-decoration:underline;}
        .pmcpc-reviews-row--focus{background:#f0f7ff !important;box-shadow:inset 3px 0 0 #2271b1;}
        @media (max-width:782px){.pmcpc-reviews-toolbar{padding:12px;}.pmcpc-reviews-filter-form{width:100%;}.pmcpc-reviews-filter-form input[type=search]{width:100% !important;}}
        </style>';

        echo '<div class="pmcpc-reviews-toolbar">';
        echo '<p class="pmcpc-reviews-toolbar__intro">' . esc_html__( 'Moderate new reviews first, then use filters to find product feedback, private replies, or older approved reviews.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="get" class="pmcpc-reviews-filter-form">';
        echo '<input type="hidden" name="page" value="pmcpc_reviews" />';
        echo '<select name="pmcpc_status">';
        echo '<option value="">' . esc_html__( 'All statuses', 'product-mailer-campaigns' ) . '</option>';
        foreach ( array( 'pending' => __( 'Pending', 'product-mailer-campaigns' ), 'approved' => __( 'Approved', 'product-mailer-campaigns' ), 'rejected' => __( 'Rejected', 'product-mailer-campaigns' ), 'private_feedback' => __( 'Private feedback', 'product-mailer-campaigns' ) ) as $key => $label ) {
            echo '<option value="' . esc_attr( $key ) . '" ' . selected( $status, $key, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
        echo '<select name="pmcpc_review_type">';
        echo '<option value="">' . esc_html__( 'All review types', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="review" ' . selected( $type, 'review', false ) . '>' . esc_html__( 'Standard review', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="product_review" ' . selected( $type, 'product_review', false ) . '>' . esc_html__( 'Product review', 'product-mailer-campaigns' ) . '</option>';
        echo '</select>';
        echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'Search reviews...', 'product-mailer-campaigns' ) . '" />';
        submit_button( __( 'Filter', 'product-mailer-campaigns' ), 'secondary', '', false );
        echo '</form>';
        echo '</div>';

        $active_filter_parts = array();
        if ( $status ) {
            $status_labels = array(
                'pending'          => __( 'Pending', 'product-mailer-campaigns' ),
                'approved'         => __( 'Approved', 'product-mailer-campaigns' ),
                'rejected'         => __( 'Rejected', 'product-mailer-campaigns' ),
                'private_feedback' => __( 'Private feedback', 'product-mailer-campaigns' ),
            );
            $active_filter_parts[] = array(
                'label' => __( 'Status', 'product-mailer-campaigns' ),
                'value' => isset( $status_labels[ $status ] ) ? $status_labels[ $status ] : ucfirst( str_replace( '_', ' ', $status ) ),
            );
        }
        if ( $type ) {
            $type_labels = array(
                'review'         => __( 'Standard review', 'product-mailer-campaigns' ),
                'product_review' => __( 'Product review', 'product-mailer-campaigns' ),
            );
            $active_filter_parts[] = array(
                'label' => __( 'Type', 'product-mailer-campaigns' ),
                'value' => isset( $type_labels[ $type ] ) ? $type_labels[ $type ] : ucfirst( str_replace( '_', ' ', $type ) ),
            );
        }
        if ( '' !== $search ) {
            $active_filter_parts[] = array(
                'label' => __( 'Search', 'product-mailer-campaigns' ),
                'value' => '"' . $search . '"',
            );
        }
        if ( ! empty( $active_filter_parts ) ) {
            echo '<div class="pmcpc-active-filters">';
            echo '<span class="pmcpc-active-filters__label">' . esc_html__( 'Active filters', 'product-mailer-campaigns' ) . '</span>';
            foreach ( $active_filter_parts as $filter_part ) {
                echo '<span class="pmcpc-active-filters__chip"><strong>' . esc_html( $filter_part['label'] ) . ':</strong> ' . esc_html( $filter_part['value'] ) . '</span>';
            }
            echo '<a class="pmcpc-active-filters__clear" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_reviews' ) ) . '">' . esc_html__( 'Clear filters', 'product-mailer-campaigns' ) . '</a>';
            echo '</div>';
        }

        echo '<div class="pmcpc-reviews-table-wrap pmcpc-table-wrap">';
        echo '<div class="pmcpc-reviews-table-wrap__scroll pmcpc-table-wrap__scroll">';
        echo '<table class="widefat striped pmcpc-wide-table">';
        echo '<thead><tr>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Date', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-meta">' . esc_html__( 'Type', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-meta">' . esc_html__( 'Rating', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Reviewer', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-meta">' . esc_html__( 'Product', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Review', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-compare">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
        echo '<th class="pmcpc-col-actions">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
        echo '</tr></thead><tbody>';
        if ( empty( $rows ) ) {
            echo '<tr><td colspan="8">' . esc_html__( 'No reviews found yet.', 'product-mailer-campaigns' ) . '</td></tr>';
        } else {
            foreach ( $rows as $row ) {
                $rating      = max( 0, min( 5, absint( $row['rating'] ) ) );
                $stars       = str_repeat( '★', $rating ) . str_repeat( '☆', max( 0, 5 - $rating ) );
                $review      = wp_trim_words( wp_strip_all_tags( (string) $row['review_text'] ), 30 );
                $reviewer    = trim( (string) $row['reviewer_name'] );
                $review_type = ( 'product_review' === $row['review_type'] ) ? __( 'Product review', 'product-mailer-campaigns' ) : __( 'Standard review', 'product-mailer-campaigns' );
                $product     = (string) $row['product_name'];
                $status_key  = (string) $row['status'];
                if ( '' === $reviewer ) {
                    $reviewer = (string) $row['reviewer_email'];
                }
                if ( '' === $product && ! empty( $row['product_id'] ) ) {
                    $product = '#' . (int) $row['product_id'];
                }

                $row_id_attr = 'pmcpc-review-' . (int) $row['id'];
                $row_class   = ( $focus_review_id === (int) $row['id'] ) ? ' class="pmcpc-reviews-row--focus"' : '';
                echo '<tr id="' . esc_attr( $row_id_attr ) . '"' . $row_class . '>';
                echo '<td class="pmcpc-col-compare">' . esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (string) $row['created_at'] ) ) . '</td>';
                echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $review_type ) . '</span></div></td>';
                echo '<td class="pmcpc-col-meta"><div class="pmcpc-reviews-rating"><span class="pmcpc-table-cell-stack__main">' . esc_html( $stars ) . '</span>' . ( ! empty( $row['verified_buyer'] ) ? '<span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Verified buyer', 'product-mailer-campaigns' ) . '</span>' : '' ) . '</div></td>';
                echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( $reviewer ) . '</span><span class="pmcpc-table-record__meta">' . esc_html( (string) $row['reviewer_email'] ) . '</span></div></td>';
                echo '<td class="pmcpc-col-meta"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $product ? $product : __( 'General store', 'product-mailer-campaigns' ) ) . '</span></div></td>';
                echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( $review ) . '</span></div></td>';
                echo '<td class="pmcpc-col-compare"><span class="pmcpc-reviews-status pmcpc-reviews-status--' . esc_attr( sanitize_html_class( $status_key ) ) . '">' . esc_html( ucwords( str_replace( '_', ' ', $status_key ) ) ) . '</span></td>';

                $primary_action    = '';
                $secondary_actions = array();
                foreach ( array( 'approve' => __( 'Approve', 'product-mailer-campaigns' ), 'reject' => __( 'Reject', 'product-mailer-campaigns' ), 'private' => __( 'Private', 'product-mailer-campaigns' ), 'delete' => __( 'Delete', 'product-mailer-campaigns' ) ) as $action => $label ) {
                    $action_args = array(
                        'page'                => 'pmcpc_reviews',
                        'pmcpc_review_action' => $action,
                        'pmcpc_review_id'     => (int) $row['id'],
                    );
                    if ( $status ) {
                        $action_args['pmcpc_status'] = $status;
                    }
                    if ( $type ) {
                        $action_args['pmcpc_review_type'] = $type;
                    }
                    if ( $search ) {
                        $action_args['s'] = $search;
                    }
                    if ( $paged > 1 ) {
                        $action_args['paged'] = $paged;
                    }
                    $url     = wp_nonce_url( add_query_arg( $action_args, admin_url( 'admin.php' ) ), 'pmcpc_review_action_' . (int) $row['id'] . '_' . $action );
                    $onclick = '';
                    if ( 'delete' === $action ) {
                        $onclick = ' onclick="return confirm(\'' . esc_js( __( 'Delete this review?', 'product-mailer-campaigns' ) ) . '\');"';
                    }
                    if ( '' === $primary_action && 'approve' === $action ) {
                        $primary_action = '<a class="button button-small button-primary" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
                    } else {
                        $secondary_actions[] = '<a' . ( 'delete' === $action ? ' class="button-link-delete"' : '' ) . ' href="' . esc_url( $url ) . '"' . $onclick . '>' . esc_html( $label ) . '</a>';
                    }
                }
                echo '<td class="pmcpc-col-actions"><div class="pmcpc-reviews-actions"><div class="pmcpc-reviews-actions__primary">' . wp_kses_post( $primary_action ) . '</div><div class="pmcpc-reviews-actions__secondary">' . wp_kses_post( implode( ' ', $secondary_actions ) ) . '</div></div></td>';
                echo '</tr>';
            }
        }
        echo '</tbody></table>';
        echo '</div>';
        echo '</div>';

        $total_pages = max( 1, (int) ceil( $total / $per_page ) );
        if ( $total_pages > 1 ) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links(
                array(
                    'base'    => add_query_arg( array( 'page' => 'pmcpc_reviews', 'pmcpc_status' => $status, 'pmcpc_review_type' => $type, 's' => $search, 'paged' => '%#%' ), admin_url( 'admin.php' ) ),
                    'format'  => '',
                    'current' => $paged,
                    'total'   => $total_pages,
                )
            );
            echo '</div></div>';
        }
        echo '</div>';
    }

public static function render_reviews_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        if ( ! class_exists( 'PMCPC_Reviews' ) ) {
            echo '<div class="wrap"><p>' . esc_html__( 'Reviews support is not available.', 'product-mailer-campaigns' ) . '</p></div>';
            return;
        }

        self::render_reviews_page_modern();
        return;

        /* Legacy Reviews renderer removed. The active UI lives in render_reviews_page_modern().
        $status = isset( $_GET['pmcpc_status'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_status'] ) ) : '';
        $type   = isset( $_GET['pmcpc_review_type'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_review_type'] ) ) : '';
        $search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
        $paged  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;
        $per_page = 20;
        $filters = array();
        if ( $status ) { $filters['status'] = $status; }
        if ( $type ) { $filters['review_type'] = $type; }
        if ( $search ) { $filters['s'] = $search; }
        $total = PMCPC_Reviews::count_reviews( $filters );
        $rows  = PMCPC_Reviews::get_reviews( $filters, $per_page, ( $paged - 1 ) * $per_page );
        $base  = admin_url( 'admin.php?page=pmcpc_reviews' );

        echo '<div class="wrap">';
        PMCPC_Admin::render_app_header( __( 'Reviews', 'product-mailer-campaigns' ) );
        PMCPC_Admin::render_page_intro(
            __( 'Reviews', 'product-mailer-campaigns' ),
            __( 'Review, approve, reject, or keep private the customer reviews captured through PMCPC forms.', 'product-mailer-campaigns' ),
            array(
                array(
                    'label' => __( 'Moderate new reviews first', 'product-mailer-campaigns' ),
                    'icon'  => 'dashicons-star-filled',
                ),
                array(
                    'label' => __( 'Approve trusted feedback', 'product-mailer-campaigns' ),
                    'icon'  => 'dashicons-yes-alt',
                ),
                array(
                    'label' => __( 'Keep sensitive replies private', 'product-mailer-campaigns' ),
                    'icon'  => 'dashicons-hidden',
                ),
            )
        );

        echo '<form method="get" style="margin:12px 0 18px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">';
        echo '<input type="hidden" name="page" value="pmcpc_reviews" />';
        echo '<select name="pmcpc_status">';
        echo '<option value="">' . esc_html__( 'All statuses', 'product-mailer-campaigns' ) . '</option>';
        foreach ( array( 'pending' => __( 'Pending', 'product-mailer-campaigns' ), 'approved' => __( 'Approved', 'product-mailer-campaigns' ), 'rejected' => __( 'Rejected', 'product-mailer-campaigns' ), 'private_feedback' => __( 'Private feedback', 'product-mailer-campaigns' ) ) as $k => $label ) {
            echo '<option value="' . esc_attr( $k ) . '" ' . selected( $status, $k, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
        echo '<select name="pmcpc_review_type">';
        echo '<option value="">' . esc_html__( 'All review types', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="review" ' . selected( $type, 'review', false ) . '>' . esc_html__( 'Standard review', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="product_review" ' . selected( $type, 'product_review', false ) . '>' . esc_html__( 'Product review', 'product-mailer-campaigns' ) . '</option>';
        echo '</select>';
        echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'Search reviews…', 'product-mailer-campaigns' ) . '" />';
        submit_button( __( 'Filter', 'product-mailer-campaigns' ), 'secondary', '', false );
        echo '</form>';

        echo '<table class="widefat striped">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__( 'Date', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Type', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Rating', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Reviewer', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Product', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Review', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
        echo '<th>' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
        echo '</tr></thead><tbody>';
        if ( empty( $rows ) ) {
            echo '<tr><td colspan="8">' . esc_html__( 'No reviews found yet.', 'product-mailer-campaigns' ) . '</td></tr>';
        } else {
            foreach ( $rows as $row ) {
                $rating = max( 0, min( 5, absint( $row['rating'] ) ) );
                $stars  = str_repeat( '★', $rating ) . str_repeat( '☆', max( 0, 5 - $rating ) );
                $review = wp_trim_words( wp_strip_all_tags( (string) $row['review_text'] ), 30 );
                $reviewer = trim( (string) $row['reviewer_name'] );
                if ( '' === $reviewer ) { $reviewer = (string) $row['reviewer_email']; }
                $product = (string) $row['product_name'];
                if ( '' === $product && ! empty( $row['product_id'] ) ) { $product = '#' . (int) $row['product_id']; }
                echo '<tr>';
                echo '<td>' . esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (string) $row['created_at'] ) ) . '</td>';
                echo '<td>' . esc_html( 'product_review' === $row['review_type'] ? __( 'Product review', 'product-mailer-campaigns' ) : __( 'Standard review', 'product-mailer-campaigns' ) ) . '</td>';
                echo '<td>' . esc_html( $stars ) . ( ! empty( $row['verified_buyer'] ) ? ' <span class="description">' . esc_html__( 'Verified buyer', 'product-mailer-campaigns' ) . '</span>' : '' ) . '</td>';
                echo '<td><strong>' . esc_html( $reviewer ) . '</strong><br><span class="description">' . esc_html( (string) $row['reviewer_email'] ) . '</span></td>';
                echo '<td>' . esc_html( $product ) . '</td>';
                echo '<td>' . esc_html( $review ) . '</td>';
                echo '<td>' . esc_html( ucwords( str_replace( '_', ' ', (string) $row['status'] ) ) ) . '</td>';
                echo '<td>';
                foreach ( array( 'approve' => __( 'Approve', 'product-mailer-campaigns' ), 'reject' => __( 'Reject', 'product-mailer-campaigns' ), 'private' => __( 'Private', 'product-mailer-campaigns' ), 'delete' => __( 'Delete', 'product-mailer-campaigns' ) ) as $action => $label ) {
                    $url = wp_nonce_url( add_query_arg( array( 'page' => 'pmcpc_reviews', 'pmcpc_review_action' => $action, 'pmcpc_review_id' => (int) $row['id'] ), admin_url( 'admin.php' ) ), 'pmcpc_review_action_' . (int) $row['id'] . '_' . $action );
                    $cls = ( 'delete' === $action ) ? 'button-link-delete' : '';
                    $onclick = '';
                    if ( 'delete' === $action ) {
                        $onclick = ' onclick="return confirm(\'' . esc_js( __( 'Delete this review?', 'product-mailer-campaigns' ) ) . '\');"';
                    }
                    echo '<a class="button button-small ' . esc_attr( $cls ) . '" href="' . esc_url( $url ) . '"' . $onclick . '>' . esc_html( $label ) . '</a> ';
                }
                echo '</td>';
                echo '</tr>';
            }
        }
        echo '</tbody></table>';

        $total_pages = max( 1, (int) ceil( $total / $per_page ) );
        if ( $total_pages > 1 ) {
            echo '<div class="tablenav"><div class="tablenav-pages">';
            echo paginate_links( array(
                'base' => add_query_arg( array( 'page' => 'pmcpc_reviews', 'pmcpc_status' => $status, 'pmcpc_review_type' => $type, 's' => $search, 'paged' => '%#%' ), admin_url( 'admin.php' ) ),
                'format' => '',
                'current' => $paged,
                'total' => $total_pages,
            ) );
            echo '</div></div>';
        }
        echo '</div>';
        */
    }

}
