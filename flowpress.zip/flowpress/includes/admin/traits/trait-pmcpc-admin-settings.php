<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/trait-pmcpc-admin-settings-page-methods.php';
require_once __DIR__ . '/trait-pmcpc-admin-settings-forms-methods.php';
require_once __DIR__ . '/trait-pmcpc-admin-settings-reviews-methods.php';

trait PMCPC_Admin_Settings_Trait {
    use PMCPC_Admin_Settings_Page_Methods;
    use PMCPC_Admin_Settings_Forms_Methods;
    use PMCPC_Admin_Settings_Reviews_Methods;
}
