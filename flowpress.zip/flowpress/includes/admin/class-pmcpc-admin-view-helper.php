<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Shared admin presentation helpers.
 *
 * Keeps user-facing copy and common page support components out of the main
 * admin controller so the controller can focus on routing and admin actions.
 */
class PMCPC_Admin_View_Helper {

    /**
     * Page intro waiting to be merged into the next shared help panel.
     *
     * @var array|null
     */
    private static $pending_page_intro = null;

    /**
     * Shared in-app brand label used across admin screens.
     *
     * @return string
     */
    public static function app_brand() {
        return __( 'FlowPress', 'product-mailer-campaigns' );
    }

    /**
     * Shared tagline shown in the custom admin header.
     *
     * @return string
     */
    public static function app_tagline() {
        return __( 'Email marketing, audience growth, and website updates in one place.', 'product-mailer-campaigns' );
    }

    /**
     * Normalize repetitive admin labels into plainer user-facing copy.
     *
     * @param string $text Source label or message.
     * @return string
     */
    public static function normalize_admin_copy( $text ) {
        $text = (string) $text;
        if ( '' === $text ) {
            return $text;
        }

        $map = array(
            'Automation & Revenue Overview' => 'Overview',
            'Campaign Dashboard' => 'Campaigns Overview',
            'Audience Dashboard' => 'Audience Overview',
            'Revenue Dashboard' => 'Sales Overview',
            'Automations Dashboard' => 'Automations Overview',
            'Signup Forms' => 'Forms',
            'Inbox Review' => 'Inbox',
            'Email Queue' => 'Waiting to Send',
            'Email History' => 'Sent Emails',
            'Email Analytics' => 'Email Results',
            'Publishing Activity' => 'Publishing Log',
            'Content Performance' => 'Content Results',
            'System Status' => 'Health Check',
            'Diagnostics' => 'Health Check',
            'Create Campaign' => 'New Campaign',
            'Create Automation' => 'New Automation',
            'Preview Email' => 'Preview',
            'Send Test Email' => 'Send Test',
            'Queue Broadcast' => 'Add to Queue',
            'Test Audience Match' => 'Check Audience',
            'Open Inbox Review' => 'Open Inbox',
            'Open Email Queue' => 'Open Waiting to Send',
            'Open System Status' => 'Open Health Check',
            'Open diagnostics' => 'Open Health Check',
            'Inbox Review has messages waiting' => 'Inbox has messages waiting',
            'Email Queue needs attention' => 'Waiting emails need attention',
            'System diagnostics need review' => 'Health check needs review',
            'Workspace guide' => 'Help & shortcuts',
        );

        if ( isset( $map[ $text ] ) ) {
            return $map[ $text ];
        }

        $replacements = array(
            'Everything looks healthy. Active alerts and shortcuts will appear here across Campaigns, Automations, Audience, Email, Settings, and System Status.' => 'Everything looks good. Alerts and shortcuts will appear here across Overview, Campaigns, Automations, Audience, Emails, Content, Settings, and Help & Status.',
            'Start with Create Campaign for one-off and scheduled sends. Use Create Automation when you want a trigger-based workflow, then use the row actions to test, preview, queue, or edit.' => 'Start with New Campaign for one-off or scheduled emails. Use New Automation when an email should send automatically. Then preview, test, queue, or edit from the row actions.',
            'Templates for signup, contact, selling, and review forms' => 'Create and manage forms',
            'Manage reusable frontend forms here, then copy the shortcode into the right page, campaign, or content area.' => 'Create forms here, copy the shortcode, and test them on the right page, campaign, or content area.',
            'Quick overview and health checks for campaigns, subscribers, and delivery.' => 'See what is working, what needs attention, and what to do next.',
            'Upcoming campaign activity and recent delivery activity in one focused view.' => 'See scheduled campaigns, recent sends, and anything that needs attention.',
            'Subscriber source, lifecycle, and growth signals without the main dashboard clutter.' => 'See subscriber growth, signups, and audience activity in one place.',
            'Store revenue and recoverable revenue metrics in a dedicated view.' => 'See sales and recoverable revenue in one place.',
            'Core workflow groups, health coverage, and recent trigger activity in one operational view.' => 'See active automations, recent triggers, and anything that needs attention.',
            'Automations activated' => 'Automations turned on',
            'Next: fine‑tune the timing and email copy in <a href="%s">Automations</a>.' => 'Next: review the timing and email copy in <a href="%s">Automations</a>.',
            'Diagnostics component is missing.' => 'Health check tools are missing.',
            'Track which Subscriber Updates are getting views, unlocks, and clicks so you can see what content is working over time.' => 'See which updates are getting views, unlocks, and clicks so you know what content is working.',
            'Create and manage subscriber-facing website updates here, then use Content Performance and Publishing Settings to review reach, topics, and publishing behavior.' => 'Create and manage website updates here, then use Content Results and Publishing Settings to review reach, topics, and publishing behaviour.',
        );

        return isset( $replacements[ $text ] ) ? $replacements[ $text ] : $text;
    }

    /**
     * Store a reusable page intro so it can be merged into one page-specific help panel.
     *
     * The panel is flushed by render_support_panels() when shortcut/help panels exist, or by
     * render_stats_strip() before page metrics if the page only has intro guidance.
     *
     * @param string $title Intro title.
     * @param string $text  Supporting helper text.
     * @param array  $meta  Optional pill metadata rows.
     * @return void
     */
    public static function render_page_intro( $title, $text = '', $meta = array() ) {
        $title = (string) $title;
        $text  = (string) $text;

        if ( '' === $title && '' === $text ) {
            return;
        }

        // Keep one pending page help panel per request. Some screens prepare a generic
        // intro before a more specific one; replacing avoids duplicate help blocks.
        self::$pending_page_intro = array(
            'title' => $title,
            'text'  => $text,
            'meta'  => is_array( $meta ) ? $meta : array(),
        );
    }

    /**
     * Render a stored intro-only help panel, if one is waiting.
     *
     * @return void
     */
    private static function flush_pending_page_help() {
        if ( null === self::$pending_page_intro ) {
            return;
        }

        $intro = self::$pending_page_intro;
        self::$pending_page_intro = null;
        self::render_combined_help_panel( $intro, array() );
    }

    /**
     * Render one combined page-specific help panel.
     *
     * @param array|null $intro  Stored page intro details.
     * @param array      $panels Support panel definitions.
     * @return void
     */
    private static function render_combined_help_panel( $intro = null, $panels = array() ) {
        $valid_panels = array();
        if ( ! empty( $panels ) && is_array( $panels ) ) {
            foreach ( $panels as $panel ) {
                if ( ! empty( $panel['title'] ) || ! empty( $panel['text'] ) || ! empty( $panel['items'] ) || ! empty( $panel['actions'] ) ) {
                    $valid_panels[] = $panel;
                }
            }
        }

        $has_intro = is_array( $intro ) && ( ! empty( $intro['title'] ) || ! empty( $intro['text'] ) );
        if ( ! $has_intro && empty( $valid_panels ) ) {
            return;
        }

        $has_actions = false;
        $first_title = '';
        foreach ( $valid_panels as $panel ) {
            if ( '' === $first_title && ! empty( $panel['title'] ) ) {
                $first_title = (string) $panel['title'];
            }
            if ( ! empty( $panel['actions'] ) && is_array( $panel['actions'] ) ) {
                $has_actions = true;
            }
        }

        $intro_title = $has_intro && ! empty( $intro['title'] ) ? (string) $intro['title'] : '';
        $summary_title = '' !== $intro_title ? $intro_title : $first_title;
        if ( '' === $summary_title ) {
            $summary_title = __( 'How to use this page', 'product-mailer-campaigns' );
        }

        $summary_label = __( 'Help & shortcuts', 'product-mailer-campaigns' );

        echo '<details class="pmcpc-help-collapsible pmcpc-help-collapsible--combined">';
        echo '<summary class="pmcpc-help-collapsible__summary">';
        echo '<span class="pmcpc-help-collapsible__summary-main">';
        echo '<span class="pmcpc-help-collapsible__label"><span class="dashicons dashicons-editor-help" aria-hidden="true"></span><span>' . esc_html( self::normalize_admin_copy( $summary_label ) ) . '</span></span>';
        echo '<span class="pmcpc-help-collapsible__title">' . esc_html( self::normalize_admin_copy( $summary_title ) ) . '</span>';
        echo '</span>';
        echo '<span class="pmcpc-help-collapsible__toggle" aria-hidden="true"></span>';
        echo '</summary>';
        echo '<div class="pmcpc-help-collapsible__body">';

        if ( $has_intro ) {
            echo '<div class="pmcpc-page-intro">';
            if ( ! empty( $intro['title'] ) ) {
                echo '<h2>' . esc_html( self::normalize_admin_copy( (string) $intro['title'] ) ) . '</h2>';
            }
            if ( ! empty( $intro['text'] ) ) {
                echo '<p>' . esc_html( self::normalize_admin_copy( (string) $intro['text'] ) ) . '</p>';
            }
            $meta = isset( $intro['meta'] ) && is_array( $intro['meta'] ) ? $intro['meta'] : array();
            if ( ! empty( $meta ) ) {
                echo '<div class="pmcpc-page-intro__meta">';
                foreach ( $meta as $item ) {
                    $label = isset( $item['label'] ) ? (string) $item['label'] : '';
                    if ( '' === $label ) {
                        continue;
                    }
                    $icon = isset( $item['icon'] ) ? sanitize_html_class( (string) $item['icon'] ) : 'dashicons-info-outline';
                    echo '<span class="pmcpc-page-intro__pill"><span class="dashicons ' . esc_attr( $icon ) . '" aria-hidden="true"></span><span>' . esc_html( self::normalize_admin_copy( $label ) ) . '</span></span>';
                }
                echo '</div>';
            }
            echo '</div>';
        }

        if ( ! empty( $valid_panels ) ) {
            $classes = 'pmcpc-page-support-grid';
            if ( 1 === count( $valid_panels ) ) {
                $classes .= ' pmcpc-page-support-grid--single';
            }
            echo '<div class="' . esc_attr( $classes ) . '">';
            foreach ( $valid_panels as $panel ) {
                $title   = isset( $panel['title'] ) ? (string) $panel['title'] : '';
                $text    = isset( $panel['text'] ) ? (string) $panel['text'] : '';
                $items   = ( isset( $panel['items'] ) && is_array( $panel['items'] ) ) ? $panel['items'] : array();
                $actions = ( isset( $panel['actions'] ) && is_array( $panel['actions'] ) ) ? $panel['actions'] : array();
                $eyebrow = isset( $panel['eyebrow'] ) ? (string) $panel['eyebrow'] : '';
                $icon    = isset( $panel['icon'] ) ? sanitize_html_class( (string) $panel['icon'] ) : 'dashicons-info-outline';
                $class   = 'pmcpc-support-card';
                if ( empty( $panel['plain'] ) ) {
                    $class .= ' pmcpc-support-card--soft';
                }
                echo '<div class="' . esc_attr( $class ) . '">';
                if ( '' !== $eyebrow ) {
                    echo '<div class="pmcpc-support-card__eyebrow"><span class="dashicons ' . esc_attr( $icon ) . '" aria-hidden="true"></span><span>' . esc_html( self::normalize_admin_copy( $eyebrow ) ) . '</span></div>';
                }
                if ( '' !== $title ) {
                    echo '<h3 class="pmcpc-support-card__title">' . esc_html( self::normalize_admin_copy( $title ) ) . '</h3>';
                }
                if ( '' !== $text ) {
                    echo '<p class="pmcpc-support-card__text">' . esc_html( self::normalize_admin_copy( $text ) ) . '</p>';
                }
                if ( ! empty( $items ) ) {
                    echo '<ul class="pmcpc-support-card__list">';
                    foreach ( $items as $item ) {
                        $label = is_array( $item ) ? (string) ( $item['label'] ?? '' ) : (string) $item;
                        $item_icon = is_array( $item ) && ! empty( $item['icon'] ) ? sanitize_html_class( (string) $item['icon'] ) : 'dashicons-yes-alt';
                        if ( '' === $label ) {
                            continue;
                        }
                        echo '<li><span class="dashicons ' . esc_attr( $item_icon ) . '" aria-hidden="true"></span><span>' . esc_html( self::normalize_admin_copy( $label ) ) . '</span></li>';
                    }
                    echo '</ul>';
                }
                if ( ! empty( $actions ) ) {
                    echo '<div class="pmcpc-support-card__actions">';
                    foreach ( $actions as $action ) {
                        $label = isset( $action['label'] ) ? (string) $action['label'] : '';
                        $url   = isset( $action['url'] ) ? (string) $action['url'] : '';
                        $class = isset( $action['class'] ) ? (string) $action['class'] : 'button';
                        if ( '' === $label || '' === $url ) {
                            continue;
                        }
                        echo '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '">' . esc_html( self::normalize_admin_copy( $label ) ) . '</a>';
                    }
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</div>';
        }

        echo '</div>';
        echo '</details>';
    }

    /**
     * Render a compact summary strip for admin overview metrics.
     *
     * @param array $items Summary card items.
     * @return void
     */
    public static function render_stats_strip( $items ) {
        self::flush_pending_page_help();

        if ( empty( $items ) || ! is_array( $items ) ) {
            return;
        }

        echo '<div class="pmcpc-stats-strip">';
        foreach ( $items as $item ) {
            $label = isset( $item['label'] ) ? (string) $item['label'] : '';
            $value = isset( $item['value'] ) ? (string) $item['value'] : '';
            $meta  = isset( $item['meta'] ) ? (string) $item['meta'] : '';
            if ( '' === $label && '' === $value ) {
                continue;
            }
            echo '<div class="pmcpc-stat-card">';
            if ( '' !== $label ) {
                echo '<span class="pmcpc-stat-card__label">' . esc_html( self::normalize_admin_copy( $label ) ) . '</span>';
            }
            if ( '' !== $value ) {
                echo '<strong class="pmcpc-stat-card__value">' . esc_html( $value ) . '</strong>';
            }
            if ( '' !== $meta ) {
                echo '<span class="pmcpc-stat-card__meta">' . esc_html( self::normalize_admin_copy( $meta ) ) . '</span>';
            }
            echo '</div>';
        }
        echo '</div>';
    }

    /**
     * Render reusable support panels, merged with any pending page intro.
     *
     * @param array $panels Support panel definitions.
     * @return void
     */
    public static function render_support_panels( $panels ) {
        $intro = self::$pending_page_intro;
        self::$pending_page_intro = null;
        self::render_combined_help_panel( $intro, $panels );
    }
}
