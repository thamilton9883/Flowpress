<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Simple stored form definitions for PMCPC dynamic forms.
 *
 * Forms are stored in a single option as an array of arrays:
 *  array(
 *      1 => array(
 *          'id'    => 1,
 *          'name'  => 'Homepage contact',
 *          'type'  => 'contact',
 *          'title' => 'Contact us',
 *          'settings' => array( ... ),
 *      ),
 *      ...
 *  )
 */
class PMCPC_Forms {

    const OPTION_KEY = 'pmcpc_forms';

    /**
     * Supported form types.
     *
     * @return string[]
     */
    public static function get_supported_types() {
        return array( 'contact', 'selling', 'subscribe', 'review', 'product_review' );
    }

    /**
     * Treat review forms as contact-style forms for rendering/submission.
     *
     * @param string $type Form type.
     * @return bool
     */
    public static function is_contact_like_type( $type ) {
        return in_array( sanitize_key( (string) $type ), array( 'contact', 'review', 'product_review' ), true );
    }


    /**
     * Back-compat init hook.
     *
     * Older versions wired this class into init to ensure stored form
     * definitions are migrated/normalized early.
     *
     * @return void
     */
    public static function init() {
        // Trigger lazy migration/normalization.
        self::get_forms();
    }


    /**
     * Default per-form settings (used for new forms + migration).
     *
     * @param string $type contact|selling|subscribe
     * @return array
     */
    public static function default_settings( $type = 'contact' ) {
        $type = sanitize_key( (string) $type );
        if ( ! in_array( $type, self::get_supported_types(), true ) ) {
            $type = 'contact';
        }

        $defaults = array(
            // Frontend text.
            'button_label'    => ( 'selling' === $type )
                ? __( 'Send selling enquiry', 'product-mailer-campaigns' )
                : ( ( 'subscribe' === $type ) ? __( 'Subscribe', 'product-mailer-campaigns' ) : ( ( 'review' === $type || 'product_review' === $type ) ? __( 'Submit review', 'product-mailer-campaigns' ) : __( 'Send message', 'product-mailer-campaigns' ) ) ),
            'success_message' => __( 'Thanks — we’ve received your message.', 'product-mailer-campaigns' ),

            // Email routing (contact/selling).
            'recipient_email' => '',
            'email_subject'   => '',

            // Contact-only toggles.
            'show_subject'    => 'yes',
            'show_optin'      => 'yes',

            // Field editor (dynamic forms).
            'fields'         => self::default_fields( $type ),
            'custom_fields' => array(),
        );

        if ( 'subscribe' === $type ) {
            $defaults['success_message'] = __( 'Please check your email and click the confirmation link to complete your subscription.', 'product-mailer-campaigns' );
            $defaults['show_subject']    = 'no';
            $defaults['show_optin']      = 'no';
        }

        if ( 'selling' === $type ) {
            $defaults['show_subject'] = 'no';
            $defaults['show_optin']   = 'no';
        }

        return $defaults;
    }

    /**
     * Default field configuration for each form type.
     *
     * IMPORTANT: We keep legacy shortcodes stable. Field configuration is primarily
     * used by dynamic forms ([pmcpc_form id="..."]).
     *
     * @param string $type contact|selling|subscribe
     * @return array
     */
    public static function default_fields( $type = 'contact' ) {
        $type = sanitize_key( (string) $type );

        if ( 'selling' === $type ) {
            return array(
                'name'   => array( 'enabled' => 'yes', 'label' => __( 'Name', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no',  'input' => 'text' ),
                'email'  => array( 'enabled' => 'yes', 'label' => __( 'Email', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'yes', 'input' => 'email' ),
                'phone'  => array( 'enabled' => 'yes', 'label' => __( 'Phone', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no',  'input' => 'text' ),
                'item'   => array( 'enabled' => 'yes', 'label' => __( 'Item', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no',  'input' => 'text' ),
                'price'  => array( 'enabled' => 'yes', 'label' => __( 'Price', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no',  'input' => 'text' ),
                'details'=> array( 'enabled' => 'yes', 'label' => __( 'Details', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'yes', 'input' => 'textarea' ),
                'optin'  => array( 'enabled' => 'yes', 'label' => __( 'Email me product updates and special offers', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no', 'input' => 'checkbox' ),
            );
        }

        if ( 'review' === $type || 'product_review' === $type ) {
            $fields = array(
                'name'    => array( 'enabled' => 'yes', 'label' => __( 'Your name', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no',  'input' => 'text' ),
                'email'   => array( 'enabled' => 'yes', 'label' => __( 'Your email address', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'yes', 'input' => 'email' ),
                'subject' => array( 'enabled' => 'no',  'label' => __( 'Review title', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no', 'input' => 'text' ),
                'rating'  => array( 'enabled' => 'yes', 'label' => __( 'Rating', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'yes', 'input' => 'select' ),
                'message' => array( 'enabled' => 'yes', 'label' => __( 'Your review', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'yes', 'input' => 'textarea' ),
            );
            if ( 'product_review' === $type ) {
                $fields['product_id'] = array( 'enabled' => 'yes', 'label' => __( 'Product', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no', 'input' => 'hidden' );
            }
            return $fields;
        }

        if ( 'subscribe' === $type ) {
            return array(
                'first_name' => array( 'enabled' => 'yes', 'label' => __( 'First name', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no',  'input' => 'text' ),
                'last_name'  => array( 'enabled' => 'yes', 'label' => __( 'Last name', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no',  'input' => 'text' ),
                'email'      => array( 'enabled' => 'yes', 'label' => __( 'Email address', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'yes', 'input' => 'email' ),
            );
        }

        // Contact default.
        return array(
            'name'    => array( 'enabled' => 'yes', 'label' => __( 'Name', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no',  'input' => 'text' ),
            'email'   => array( 'enabled' => 'yes', 'label' => __( 'Email', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'yes', 'input' => 'email' ),
            'subject' => array( 'enabled' => 'yes', 'label' => __( 'Subject', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no',  'input' => 'text' ),
            'message' => array( 'enabled' => 'yes', 'label' => __( 'Message', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'yes', 'input' => 'textarea' ),
            'optin'   => array( 'enabled' => 'yes', 'label' => __( 'Email me product updates and special offers', 'product-mailer-campaigns' ), 'placeholder' => '', 'required' => 'no', 'input' => 'checkbox' ),
        );
    }

    /**
     * Sanitize and normalize fields configuration.
     *
     * @param array  $fields Incoming fields config.
     * @param string $type   Form type.
     * @return array
     */
    public static function sanitize_fields( $fields, $type = 'contact' ) {
        $defaults = self::default_fields( $type );
        $fields   = is_array( $fields ) ? $fields : array();

        $out = array();

        foreach ( $defaults as $key => $def ) {
            $row = isset( $fields[ $key ] ) && is_array( $fields[ $key ] ) ? $fields[ $key ] : array();

            $enabled = isset( $row['enabled'] ) && 'no' === (string) $row['enabled'] ? 'no' : 'yes';
            $required = isset( $row['required'] ) && 'yes' === (string) $row['required'] ? 'yes' : 'no';

            // Enforce required baseline fields.
            if ( 'contact' === $type ) {
                if ( in_array( $key, array( 'email', 'message' ), true ) ) {
                    $enabled  = 'yes';
                    $required = 'yes';
                }
            } elseif ( 'selling' === $type ) {
                if ( in_array( $key, array( 'email', 'details' ), true ) ) {
                    $enabled  = 'yes';
                    $required = 'yes';
                }
            } elseif ( 'subscribe' === $type ) {
                if ( 'email' === $key ) {
                    $enabled  = 'yes';
                    $required = 'yes';
                }
            } elseif ( in_array( $type, array( 'review', 'product_review' ), true ) ) {
                if ( in_array( $key, array( 'email', 'message', 'rating' ), true ) ) {
                    $enabled  = 'yes';
                    $required = 'yes';
                }
                if ( 'product_id' === $key && 'product_review' === $type ) {
                    $enabled = 'yes';
                }
            }

            $label = isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : sanitize_text_field( (string) $def['label'] );
            $placeholder = isset( $row['placeholder'] ) ? sanitize_text_field( (string) $row['placeholder'] ) : '';

            $out[ $key ] = array(
                'enabled'     => $enabled,
                'required'    => $required,
                'label'       => $label ? $label : sanitize_text_field( (string) $def['label'] ),
                'placeholder' => $placeholder,
                'input'       => isset( $def['input'] ) ? $def['input'] : 'text',
            );
        }

        return $out;
    }

    
    /**
     * Sanitize and normalize additional/custom fields configuration.
     *
     * These are only rendered for dynamic forms ([pmcpc_form id="..."]) and do not affect
     * the legacy shortcodes.
     *
     * Structure:
     *  array(
     *    array(
     *      'key'        => 'photos',
     *      'type'       => 'text'|'textarea'|'file',
     *      'enabled'    => 'yes'|'no',
     *      'required'   => 'yes'|'no',
     *      'label'      => 'Photos',
     *      'placeholder'=> '',
     *      'max_files'  => 5, // file only
     *    ),
     *  )
     *
     * @param array $custom_fields Incoming config.
     * @return array
     */
    public static function sanitize_custom_fields( $custom_fields ) {
        $custom_fields = is_array( $custom_fields ) ? $custom_fields : array();

        $out  = array();
        $seen = array();

        foreach ( $custom_fields as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }

            $key = isset( $row['key'] ) ? sanitize_key( (string) $row['key'] ) : '';
            if ( '' === $key ) {
                continue;
            }
            if ( isset( $seen[ $key ] ) ) {
                continue;
            }
            $seen[ $key ] = true;

            $type = isset( $row['type'] ) ? sanitize_key( (string) $row['type'] ) : 'text';
            if ( ! in_array( $type, array( 'text', 'textarea', 'file' ), true ) ) {
                $type = 'text';
            }

            $enabled  = ( isset( $row['enabled'] ) && 'no' === (string) $row['enabled'] ) ? 'no' : 'yes';
            $required = ( isset( $row['required'] ) && 'yes' === (string) $row['required'] ) ? 'yes' : 'no';

            $label = isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : '';
            $ph    = isset( $row['placeholder'] ) ? sanitize_text_field( (string) $row['placeholder'] ) : '';

            $max_files = 5;
            if ( 'file' === $type ) {
                $max_files = isset( $row['max_files'] ) ? absint( $row['max_files'] ) : 5;
                if ( $max_files < 1 ) {
                    $max_files = 1;
                }
                if ( $max_files > 10 ) {
                    $max_files = 10;
                }
            }

            $out[] = array(
                'key'         => $key,
                'type'        => $type,
                'enabled'     => $enabled,
                'required'    => $required,
                'label'       => $label,
                'placeholder' => $ph,
                'max_files'   => $max_files,
            );
        }

        return $out;
    }

/**
     * Sanitize settings array.
     *
     * @param array  $settings Incoming settings.
     * @param string $type Form type.
     * @return array
     */
    public static function sanitize_settings( $settings, $type = 'contact' ) {
        $defaults = self::default_settings( $type );
        $settings = is_array( $settings ) ? $settings : array();

        $out = $defaults;
        foreach ( $defaults as $k => $v ) {
            if ( ! array_key_exists( $k, $settings ) ) {
                continue;
            }

            switch ( $k ) {
                case 'recipient_email':
                    $out[ $k ] = sanitize_email( (string) $settings[ $k ] );
                    break;
                case 'email_subject':
                case 'button_label':
                    $out[ $k ] = sanitize_text_field( (string) $settings[ $k ] );
                    break;
                case 'success_message':
                    $out[ $k ] = wp_kses_post( (string) $settings[ $k ] );
                    break;
                case 'show_subject':
                case 'show_optin':
                    $out[ $k ] = ( 'no' === (string) $settings[ $k ] ) ? 'no' : 'yes';
                    break;
                case 'fields':
                    $out[ $k ] = self::sanitize_fields( $settings[ $k ], $type );
                    break;
                case 'custom_fields':
                    $out[ $k ] = self::sanitize_custom_fields( $settings[ $k ] );
                    break;
                default:
                    $out[ $k ] = sanitize_text_field( (string) $settings[ $k ] );
                    break;
            }
        }

        return $out;
    }

    /**
     * Lightweight migration: ensure all stored forms have a settings array.
     *
     * @param array $forms Stored forms.
     * @return array
     */
    protected static function migrate_forms_if_needed( $forms ) {
        $changed = false;

        foreach ( $forms as $id => $form ) {
            $type = isset( $form['type'] ) ? sanitize_key( (string) $form['type'] ) : 'contact';

            if ( ! isset( $form['settings'] ) || ! is_array( $form['settings'] ) ) {
                $forms[ $id ]['settings'] = self::default_settings( $type );
                $changed = true;
            } else {
                $merged = self::sanitize_settings( $form['settings'], $type );
                if ( $merged !== $form['settings'] ) {
                    $forms[ $id ]['settings'] = $merged;
                    $changed = true;
                }
            }
        }

        if ( $changed ) {
            update_option( self::OPTION_KEY, $forms );
        }

        return $forms;
    }

    /**
     * Get all forms.
     *
     * @return array
     */
    public static function get_forms() {
        $forms = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $forms ) ) {
            $forms = array();
        }
        return self::migrate_forms_if_needed( $forms );
    }

    /**
     * Get a single form by ID.
     *
     * @param int $id Form ID.
     * @return array|null
     */
    public static function get_form( $id ) {
        $id    = absint( $id );
        $forms = self::get_forms();
        if ( isset( $forms[ $id ] ) ) {
            return $forms[ $id ];
        }
        return null;
    }

    /**
     * Add a new form.
     *
     * @param array $data Form data (name, type, title).
     * @return int New form ID.
     */
    public static function add_form( $data ) {
        $forms = self::get_forms();

        $next_id = 1;
        if ( ! empty( $forms ) ) {
            $keys    = array_map( 'intval', array_keys( $forms ) );
            $next_id = max( $keys ) + 1;
        }

        $form = array(
            'id'    => $next_id,
            'name'  => isset( $data['name'] ) ? sanitize_text_field( $data['name'] ) : '',
            'type'  => isset( $data['type'] ) ? sanitize_key( $data['type'] ) : 'contact',
            'title' => isset( $data['title'] ) ? sanitize_text_field( $data['title'] ) : '',
        );

        if ( ! in_array( $form['type'], self::get_supported_types(), true ) ) {
            $form['type'] = 'contact';
        }

        if ( '' === $form['title'] ) {
            if ( 'selling' === $form['type'] ) {
                $form['title'] = __( 'Sell us your items', 'product-mailer-campaigns' );
            } elseif ( 'subscribe' === $form['type'] ) {
                $form['title'] = __( 'Subscribe', 'product-mailer-campaigns' );
            } elseif ( 'review' === $form['type'] ) {
                $form['title'] = __( 'Leave a review', 'product-mailer-campaigns' );
            } elseif ( 'product_review' === $form['type'] ) {
                $form['title'] = __( 'Review this product', 'product-mailer-campaigns' );
            } else {
                $form['title'] = __( 'Contact us', 'product-mailer-campaigns' );
            }
        }

        $form['settings'] = self::default_settings( $form['type'] );

        $forms[ $next_id ] = $form;
        update_option( self::OPTION_KEY, $forms );

        return $next_id;
    }

    /**
     * Update an existing form by ID.
     *
     * @param int   $id Form ID.
     * @param array $data Allowed keys: name, type, title, settings
     * @return bool
     */
    public static function update_form( $id, $data ) {
        $id    = absint( $id );
        $forms = self::get_forms();

        if ( ! $id || ! isset( $forms[ $id ] ) ) {
            return false;
        }

        $current = $forms[ $id ];

        $name  = isset( $data['name'] ) ? sanitize_text_field( (string) $data['name'] ) : ( isset( $current['name'] ) ? $current['name'] : '' );
        $type  = isset( $data['type'] ) ? sanitize_key( (string) $data['type'] ) : ( isset( $current['type'] ) ? $current['type'] : 'contact' );
        $title = isset( $data['title'] ) ? sanitize_text_field( (string) $data['title'] ) : ( isset( $current['title'] ) ? $current['title'] : '' );

        if ( ! in_array( $type, self::get_supported_types(), true ) ) {
            $type = 'contact';
        }

        $settings = isset( $data['settings'] )
            ? self::sanitize_settings( $data['settings'], $type )
            : ( isset( $current['settings'] ) ? self::sanitize_settings( $current['settings'], $type ) : self::default_settings( $type ) );

        $forms[ $id ] = array(
            'id'       => $id,
            'name'     => $name,
            'type'     => $type,
            'title'    => $title,
            'settings' => $settings,
        );

        update_option( self::OPTION_KEY, $forms );
        return true;
    }

    /**
     * Duplicate a form and return the new ID.
     *
     * @param int $id Form ID.
     * @return int New form ID (0 on failure).
     */
    public static function duplicate_form( $id ) {
        $id   = absint( $id );
        $form = self::get_form( $id );
        if ( ! $form ) {
            return 0;
        }

        $new_id = self::add_form(
            array(
                'name'  => ( isset( $form['name'] ) ? $form['name'] : '' ) . ' (Copy)',
                'type'  => isset( $form['type'] ) ? $form['type'] : 'contact',
                'title' => isset( $form['title'] ) ? $form['title'] : '',
            )
        );

        if ( $new_id ) {
            self::update_form(
                $new_id,
                array(
                    'settings' => isset( $form['settings'] ) ? $form['settings'] : self::default_settings( isset( $form['type'] ) ? $form['type'] : 'contact' ),
                )
            );
        }

        return $new_id;
    }

    /**
     * Delete a form by ID.
     *
     * @param int $id Form ID.
     * @return void
     */
    public static function delete_form( $id ) {
        $id    = absint( $id );
        $forms = self::get_forms();
        if ( isset( $forms[ $id ] ) ) {
            unset( $forms[ $id ] );
            update_option( self::OPTION_KEY, $forms );
        }
    }
}
