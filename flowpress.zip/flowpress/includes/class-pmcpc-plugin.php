<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Core feature classes.
require_once PMCPC_PLUGIN_DIR . 'includes/helpers/class-pmcpc-email-templates.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-admin.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-email-log.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-subscriber-manager.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-campaign-manager.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-queue-processor.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-tracking.php';
require_once PMCPC_PLUGIN_DIR . 'includes/queue/class-pmcpc-queue-controller.php';
require_once PMCPC_PLUGIN_DIR . 'includes/campaign/class-pmcpc-campaigns-controller.php';
require_once PMCPC_PLUGIN_DIR . 'includes/subscribers/class-pmcpc-subscribers-controller.php';
require_once PMCPC_PLUGIN_DIR . 'includes/shortcodes/class-pmcpc-shortcodes-controller.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-woocommerce.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-automation-dispatcher.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-abandoned-carts.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-analytics.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-settings.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-forms.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-reviews.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-shortcodes.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-profile-fields.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-rest.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-diagnostics.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-automation-quick-setup.php';

// Service layer contracts.
require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/container/class-pmcpc-container.php';
require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-provider.php';

// Services (infrastructure).
require_once PMCPC_PLUGIN_DIR . 'includes/services/class-pmcpc-admin-ui.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/class-pmcpc-cron-migration.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/class-pmcpc-db-upgrader.php';

// Domain services (split responsibilities).
require_once PMCPC_PLUGIN_DIR . 'includes/services/domain/class-pmcpc-admin-notices-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/domain/class-pmcpc-cron-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/domain/class-pmcpc-admin-post-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/domain/class-pmcpc-public-init-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/domain/class-pmcpc-rest-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/domain/class-pmcpc-woocommerce-service.php';

// Licensing + premium modules (single-plugin monetisation).
require_once PMCPC_PLUGIN_DIR . 'includes/services/domain/class-pmcpc-licensing-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/domain/class-pmcpc-premium-modules-service.php';

// Default provider.
require_once PMCPC_PLUGIN_DIR . 'includes/providers/class-pmcpc-default-provider.php';

/**
 * Core plugin orchestrator.
 *
 * Responsibility: build container, register providers, and boot services.
 */
class PMCPC_Plugin {

    /** @var PMCPC_Container */
    private $container;

    /** @var PMCPC_Provider_Interface */
    private $provider;

    public function __construct( $container = null, $provider = null ) {
        $this->container = $container instanceof PMCPC_Container ? $container : new PMCPC_Container();
        $this->provider  = $provider instanceof PMCPC_Provider_Interface ? $provider : new PMCPC_Default_Provider();
    }

    /**
     * Register hooks.
     */
    public function run() {
        // Register bindings.
        $this->provider->register( $this->container );

        // Make container available for back-compat static facades.
        // (Service locator pattern is intentionally minimal and WP-friendly.)
        $GLOBALS['pmcpc_container'] = $this->container;

        PMCPC_Profile_Fields::init();
        PMCPC_Reviews::init();

        // Boot services in order.
        foreach ( (array) $this->provider->boot_services() as $service_id ) {
            $service = $this->container->get( $service_id );
            if ( $service instanceof PMCPC_Service_Interface ) {
                $service->register();
            }
        }
    }

    /**
     * Expose container for advanced integrations/testing.
     *
     * @return PMCPC_Container
     */
    public function container() {
        return $this->container;
    }
}
