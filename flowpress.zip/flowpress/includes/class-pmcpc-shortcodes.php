<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once PMCPC_PLUGIN_DIR . 'includes/shortcodes/class-pmcpc-shortcodes-controller.php';

/**
 * Back-compat façade for shortcodes.
 *
 * Some legacy hook registrations call PMCPC_Shortcodes::register_shortcodes().
 * Keep this method explicitly on the façade to avoid callback edge-cases.
 */
class PMCPC_Shortcodes extends PMCPC_Shortcodes_Controller {

    /**
     * Back-compat: Register all plugin shortcodes.
     *
     * @return void
     */
    public static function register_shortcodes() {
        // Delegate to controller method if present, otherwise fall back to init().
        if ( method_exists( 'PMCPC_Shortcodes_Controller', 'register_shortcodes' ) ) {
            parent::register_shortcodes();
            return;
        }
        if ( method_exists( __CLASS__, 'init' ) ) {
            self::init();
        }
    }
}
