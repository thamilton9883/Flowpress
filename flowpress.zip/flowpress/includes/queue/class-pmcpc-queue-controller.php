<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Queue responsibilities are split into traits for maintainability.
require_once PMCPC_PLUGIN_DIR . 'includes/queue/class-pmcpc-queue-runtime.php';
require_once PMCPC_PLUGIN_DIR . 'includes/queue/traits/trait-pmcpc-queue-processing.php';
require_once PMCPC_PLUGIN_DIR . 'includes/queue/traits/trait-pmcpc-queue-retention.php';
require_once PMCPC_PLUGIN_DIR . 'includes/queue/traits/trait-pmcpc-queue-admin-page.php';

/**
 * Instance-first queue controller (preferred for DI).
 * Legacy code can continue using PMCPC_Queue_Processor.
 */
class PMCPC_Queue_Controller {
    use PMCPC_Queue_Processing_Trait;
    use PMCPC_Queue_Retention_Trait;
    use PMCPC_Queue_Admin_Page_Trait;
}
