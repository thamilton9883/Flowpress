<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Shared queue runtime helpers.
 *
 * Keeps scheduling, locking, and queue persistence concerns in one place so
 * the controller can focus on per-email decisions.
 */
class PMCPC_Queue_Runtime {

	const PROCESS_LOCK_KEY = 'pmcpc_queue_process_lock';
	const PROCESS_LOCK_TTL = 5 * MINUTE_IN_SECONDS;
	const MAX_ATTEMPTS     = 5;

	/**
	 * Ensure the queue cron hook exists.
	 *
	 * @return void
	 */
	public static function ensure_queue_is_scheduled() {
		if ( ! wp_next_scheduled( 'pmcpc_process_email_queue' ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, 'pmcpc_process_email_queue' );
		}
	}

	/**
	 * Prevent overlapping queue runs.
	 *
	 * @return bool
	 */
	public static function acquire_process_lock() {
		if ( get_transient( self::PROCESS_LOCK_KEY ) ) {
			return false;
		}

		return set_transient( self::PROCESS_LOCK_KEY, time(), self::PROCESS_LOCK_TTL );
	}

	/**
	 * Release the queue run lock.
	 *
	 * @return void
	 */
	public static function release_process_lock() {
		delete_transient( self::PROCESS_LOCK_KEY );
	}

	/**
	 * Queue "now" value, with testing offset support.
	 *
	 * @return string
	 */
	public static function get_now() {
		$offset_minutes = (int) get_option( 'pmcpc_testing_time_offset_minutes', 0 );

		return gmdate( 'Y-m-d H:i:s', time() + ( $offset_minutes * MINUTE_IN_SECONDS ) );
	}

	/**
	 * Sanitized queue batch size.
	 *
	 * @return int
	 */
	public static function get_batch_size() {
		$batch_size = (int) PMCPC_Settings::get( 'queue_batch_size', 20 );

		if ( $batch_size < 1 ) {
			return 1;
		}

		if ( $batch_size > 200 ) {
			return 200;
		}

		return $batch_size;
	}

	/**
	 * Write to the activity feed when available.
	 *
	 * @param string $message Log message.
	 * @return void
	 */
	public static function log_activity( $message ) {
		if ( class_exists( 'PMCPC_Logger' ) ) {
			PMCPC_Logger::activity( (string) $message );
			return;
		}

		if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
			PMCPC_Activity_Feed::log( (string) $message );
		}
	}

	/**
	 * Fetch the next due queue items.
	 *
	 * @param string $now        Current timestamp.
	 * @param int    $batch_size Batch size.
	 * @return array
	 */
	public static function get_due_items( $now, $batch_size ) {
		global $wpdb;

		$queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
				"SELECT * FROM {$queue_table} WHERE status = %s AND scheduled_at <= %s ORDER BY id ASC LIMIT %d",
				'pending',
				$now,
				$batch_size
			)
		);
	}

	/**
	 * Persist a sent/failed entry to the email log table.
	 *
	 * @param object $item    Queue item.
	 * @param array  $payload Log payload.
	 * @return void
	 */
	public static function insert_email_log( $item, $payload ) {
		global $wpdb;

		$log_table = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
		$data      = wp_parse_args(
			(array) $payload,
			array(
				'queue_id'      => isset( $item->id ) ? (int) $item->id : 0,
				'subscriber_id' => isset( $item->subscriber_id ) ? (int) $item->subscriber_id : 0,
				'campaign_id'   => isset( $item->campaign_id ) ? (int) $item->campaign_id : 0,
				'to_email'      => isset( $item->to_email ) ? (string) $item->to_email : '',
				'subject'       => isset( $item->subject ) ? (string) $item->subject : '',
				'body_html'     => null,
				'body_text'     => null,
				'headers'       => null,
				'status'        => 'sent',
				'last_error'    => null,
				'sent_at'       => null,
				'created_at'    => current_time( 'mysql' ),
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert(
			$log_table,
			$data,
			array( '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Mark queued campaigns as completed once no pending queue items remain.
	 *
	 * @param string $now Current timestamp.
	 * @return void
	 */
	public static function complete_finished_campaigns( $now ) {
		global $wpdb;

		$campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
		$queue_table     = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names are plugin-controlled.
		$pending_campaigns = $wpdb->get_results( "SELECT c.id FROM {$campaigns_table} c WHERE c.status = 'queued' AND NOT EXISTS ( SELECT 1 FROM {$queue_table} q WHERE q.campaign_id = c.id AND q.status IN ('pending') )" );

		if ( empty( $pending_campaigns ) ) {
			return;
		}

		foreach ( $pending_campaigns as $campaign ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$campaigns_table,
				array(
					'status'     => 'completed',
					'updated_at' => $now,
				),
				array( 'id' => (int) $campaign->id ),
				array( '%s', '%s' ),
				array( '%d' )
			);
		}
	}
}
