<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait PMCPC_Queue_Retention_Trait {

    public static function cleanup_queue_retention() {
        global $wpdb;
		$queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

        $sent_days   = absint( PMCPC_Settings::get( 'queue_retention_sent_days', 60 ) );
        $failed_days = absint( PMCPC_Settings::get( 'queue_retention_failed_days', 30 ) );
        $pending_days = absint( PMCPC_Settings::get( 'queue_retention_pending_days', 14 ) );

        $deleted = 0;

        if ( $sent_days > 0 ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $deleted += (int) $wpdb->query(
                $wpdb->prepare(
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $queue_table is plugin-controlled.
                    "DELETE FROM {$queue_table} WHERE status = 'sent' AND created_at < DATE_SUB( UTC_TIMESTAMP(), INTERVAL %d DAY )",
                    $sent_days
                )
            );
        }

        if ( $failed_days > 0 ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $deleted += (int) $wpdb->query(
                $wpdb->prepare(
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $queue_table is plugin-controlled.
                    "DELETE FROM {$queue_table} WHERE status = 'failed' AND created_at < DATE_SUB( UTC_TIMESTAMP(), INTERVAL %d DAY )",
                    $failed_days
                )
            );
        }

        if ( $pending_days > 0 ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $deleted += (int) $wpdb->query(
                $wpdb->prepare(
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $queue_table is plugin-controlled.
                    "DELETE FROM {$queue_table} WHERE status = 'pending' AND created_at < DATE_SUB( UTC_TIMESTAMP(), INTERVAL %d DAY )",
                    $pending_days
                )
            );
        }

        /**
         * Fires after queue retention cleanup.
         *
         * @param int $deleted Number of rows deleted.
         */
        do_action( 'pmcpc_queue_retention_cleaned', (int) $deleted );
    }

}
