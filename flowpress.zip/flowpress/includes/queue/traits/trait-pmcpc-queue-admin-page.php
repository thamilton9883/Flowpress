<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait PMCPC_Queue_Admin_Page_Trait {

    /**
     * Whether the current user can manage queue actions.
     *
     * @return bool
     */
    protected static function pmcpc_can_manage_queue() {
        return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
    }

    /**
     * Read and verify a queue admin nonce from POST.
     *
     * @param string $field  Field name.
     * @param string $action Nonce action.
     * @return bool
     */
    protected static function pmcpc_verify_queue_post_nonce( $field, $action ) {
        $nonce = isset( $_POST[ $field ] ) ? sanitize_text_field( (string) wp_unslash( $_POST[ $field ] ) ) : '';

        return ( ! empty( $nonce ) && wp_verify_nonce( $nonce, $action ) );
    }

    /**
     * Queue screen filter state.
     *
     * @return array
     */
    protected static function pmcpc_get_queue_filters() {
        $status_filter = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
        $allowed_status = array( 'pending', 'held', 'paused', 'sent', 'failed' );
        if ( ! in_array( $status_filter, $allowed_status, true ) ) {
            $status_filter = '';
        }

        return array(
            'status_filter'     => $status_filter,
            'allowed_status'    => $allowed_status,
            'campaign_filter'   => isset( $_GET['campaign_id'] ) ? absint( $_GET['campaign_id'] ) : 0,
            'subscriber_search' => trim( isset( $_GET['subscriber'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['subscriber'] ) ) : '' ),
        );
    }

    /**
     * Fetch campaign options for the queue admin dropdowns.
     *
     * @param string $campaigns_table Campaign table name.
     * @return array<int,string>
     */
    protected static function pmcpc_get_queue_campaign_options( $campaigns_table ) {
        global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
        $campaign_rows = $wpdb->get_results( "SELECT id, name FROM {$campaigns_table} ORDER BY id DESC LIMIT 200", ARRAY_A );
        $campaign_options = array();

        if ( is_array( $campaign_rows ) ) {
            foreach ( $campaign_rows as $row ) {
                if ( empty( $row['id'] ) ) {
                    continue;
                }
                $campaign_options[ (int) $row['id'] ] = isset( $row['name'] ) ? (string) $row['name'] : '';
            }
        }

        return $campaign_options;
    }


    /**
     * Human-readable queue send timing and issue note.
     *
     * @param object $item Queue item.
     * @param array  $paused_campaigns Paused campaign IDs.
     * @return array{main:string,sub:string}
     */
    protected static function pmcpc_get_queue_send_issue_note( $item, $paused_campaigns = array() ) {
        $status       = isset( $item->status ) ? (string) $item->status : '';
        $scheduled_at = isset( $item->scheduled_at ) ? (string) $item->scheduled_at : '';
        $campaign_id  = isset( $item->campaign_id ) ? (int) $item->campaign_id : 0;
        $now_ts       = current_time( 'timestamp' );
        $main         = '—';
        $sub          = '';

        if ( 'failed' === $status ) {
            return array(
                'main' => __( 'Failed', 'product-mailer-campaigns' ),
                'sub'  => ! empty( $item->last_error ) ? (string) $item->last_error : __( 'No error message was recorded.', 'product-mailer-campaigns' ),
            );
        }

        if ( in_array( $status, array( 'held', 'paused' ), true ) ) {
            return array(
                'main' => __( 'Not sending', 'product-mailer-campaigns' ),
                'sub'  => 'held' === $status ? __( 'Paused at campaign level.', 'product-mailer-campaigns' ) : __( 'Paused before processing.', 'product-mailer-campaigns' ),
            );
        }

        if ( 'sent' === $status ) {
            return array(
                'main' => __( 'Sent', 'product-mailer-campaigns' ),
                'sub'  => ! empty( $item->updated_at ) ? sprintf( __( 'Completed: %s', 'product-mailer-campaigns' ), (string) $item->updated_at ) : '',
            );
        }

        if ( 'pending' !== $status ) {
            return array( 'main' => $main, 'sub' => $sub );
        }

        if ( $campaign_id && in_array( $campaign_id, $paused_campaigns, true ) ) {
            return array(
                'main' => __( 'Paused', 'product-mailer-campaigns' ),
                'sub'  => __( 'Campaign sending is currently paused.', 'product-mailer-campaigns' ),
            );
        }

        if ( '' === $scheduled_at || '0000-00-00 00:00:00' === $scheduled_at ) {
            return array(
                'main' => __( 'Issue', 'product-mailer-campaigns' ),
                'sub'  => __( 'No scheduled send time is set.', 'product-mailer-campaigns' ),
            );
        }

        $scheduled_ts = strtotime( $scheduled_at );
        if ( ! $scheduled_ts ) {
            return array(
                'main' => __( 'Issue', 'product-mailer-campaigns' ),
                'sub'  => __( 'Scheduled send time is invalid.', 'product-mailer-campaigns' ),
            );
        }

        if ( $scheduled_ts > $now_ts ) {
            $main = sprintf( __( 'Sends %s', 'product-mailer-campaigns' ), human_time_diff( $now_ts, $scheduled_ts ) );
            $sub  = sprintf( __( 'Scheduled for %s.', 'product-mailer-campaigns' ), $scheduled_at );
        } else {
            $overdue_seconds = max( 0, $now_ts - $scheduled_ts );
            $main = __( 'Due now', 'product-mailer-campaigns' );
            if ( $overdue_seconds > 15 * MINUTE_IN_SECONDS ) {
                $sub = sprintf( __( 'Overdue by %s. The queue runner may not have processed yet.', 'product-mailer-campaigns' ), human_time_diff( $scheduled_ts, $now_ts ) );
            } else {
                $sub = __( 'Waiting for the next queue run.', 'product-mailer-campaigns' );
            }
        }

        return array( 'main' => $main, 'sub' => $sub );
    }

    /**
     * Handle queue campaign pause/resume actions.
     *
     * @param string $queue_table Queue table name.
     * @return string Empty string when no notice should be shown.
     */
    protected static function pmcpc_handle_queue_campaign_toggle( $queue_table ) {
        global $wpdb;

        if ( ! self::pmcpc_verify_queue_post_nonce( 'pmcpc_campaign_pause_nonce', 'pmcpc_campaign_pause' ) ) {
            return '';
        }

        if ( ! self::pmcpc_can_manage_queue() ) {
            return '<div class="error notice"><p>' . esc_html__( 'You do not have permission to change campaign sending controls.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        $toggle_campaign_id = isset( $_POST['pmcpc_pause_campaign_id'] ) ? absint( $_POST['pmcpc_pause_campaign_id'] ) : 0;
        $toggle_action      = isset( $_POST['pmcpc_pause_action'] ) ? sanitize_key( (string) wp_unslash( $_POST['pmcpc_pause_action'] ) ) : '';

        if ( $toggle_campaign_id <= 0 || ! in_array( $toggle_action, array( 'pause', 'resume' ), true ) ) {
            return '';
        }

        $paused = get_option( 'pmcpc_paused_campaigns', array() );
        if ( ! is_array( $paused ) ) {
            $paused = array();
        }
        $paused = array_values( array_unique( array_map( 'absint', $paused ) ) );

        if ( 'pause' === $toggle_action ) {
            if ( ! in_array( $toggle_campaign_id, $paused, true ) ) {
                $paused[] = $toggle_campaign_id;
            }
            update_option( 'pmcpc_paused_campaigns', $paused, false );

            return '<div class="updated notice"><p>' . esc_html__( 'Campaign sending paused. New queue items will be held (logged but not sent).', 'product-mailer-campaigns' ) . '</p></div>';
        }

        $paused = array_values( array_diff( $paused, array( $toggle_campaign_id ) ) );
        update_option( 'pmcpc_paused_campaigns', $paused, false );

        $now = current_time( 'mysql' );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query( $wpdb->prepare( 'UPDATE %i SET status = %s, updated_at = %s WHERE status = %s AND campaign_id = %d', $queue_table, 'pending', $now, 'held', $toggle_campaign_id ) );

        return '<div class="updated notice"><p>' . esc_html__( 'Campaign sending resumed. Held items were restored to pending.', 'product-mailer-campaigns' ) . '</p></div>';
    }

    /**
     * Handle queue cleanup submissions.
     *
     * @param string $queue_table Queue table name.
     * @return string Empty string when no notice should be shown.
     */
    protected static function pmcpc_handle_queue_cleanup( $queue_table ) {
        global $wpdb;

        if ( ! self::pmcpc_verify_queue_post_nonce( 'pmcpc_queue_cleanup_nonce', 'pmcpc_queue_cleanup' ) ) {
            return '';
        }

        if ( ! self::pmcpc_can_manage_queue() ) {
            return '<div class="error notice"><p>' . esc_html__( 'You do not have permission to clean up the email queue.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        $days = isset( $_POST['pmcpc_queue_days'] ) ? absint( $_POST['pmcpc_queue_days'] ) : 30;
        if ( $days < 0 ) {
            $days = 0;
        }

        $cleanup_action = isset( $_POST['pmcpc_queue_cleanup_action'] ) ? sanitize_key( (string) wp_unslash( $_POST['pmcpc_queue_cleanup_action'] ) ) : '';
        $delete_sent    = ! empty( $_POST['pmcpc_queue_delete_sent'] ) || 'sent' === $cleanup_action;
        $delete_failed  = ! empty( $_POST['pmcpc_queue_delete_failed'] ) || 'failed' === $cleanup_action;
        $delete_pending = ! empty( $_POST['pmcpc_queue_delete_pending'] ) || 'pending' === $cleanup_action;
        $delete_all     = ! empty( $_POST['pmcpc_queue_delete_pending_all'] ) || 'pending_all' === $cleanup_action;

        $deleted_total = 0;

        if ( $delete_sent ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $deleted_total += (int) $wpdb->query(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
					"DELETE FROM $queue_table WHERE status = 'sent' AND created_at < DATE_SUB( UTC_TIMESTAMP(), INTERVAL %d DAY )",
                    $days
                )
            );
        }

        if ( $delete_failed ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $deleted_total += (int) $wpdb->query(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
					"DELETE FROM $queue_table WHERE status = 'failed' AND created_at < DATE_SUB( UTC_TIMESTAMP(), INTERVAL %d DAY )",
                    $days
                )
            );
        }

        if ( $delete_pending ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $deleted_total += (int) $wpdb->query(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
					"DELETE FROM $queue_table WHERE status IN ('pending','held','paused') AND created_at < DATE_SUB( NOW(), INTERVAL %d DAY )",
                    $days
                )
            );
        }

        if ( $delete_all ) {
            if ( empty( $_POST['pmcpc_queue_confirm_pending_all'] ) ) {
                return '<div class="error notice"><p>' . esc_html__( 'To delete ALL unsent items, please confirm the checkbox below.', 'product-mailer-campaigns' ) . '</p></div>';
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $deleted_total += (int) $wpdb->query(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
                "DELETE FROM $queue_table WHERE status IN ('pending','held','paused')"
            );
        }

        if ( $deleted_total > 0 ) {
            return '<div class="updated notice"><p>' . sprintf(
                /* translators: %d: number of queue items removed. */
                esc_html__( 'Queue cleanup complete. %d items removed.', 'product-mailer-campaigns' ),
                (int) $deleted_total
            ) . '</p></div>';
        }

        return '<div class="updated notice"><p>' . esc_html__( 'Queue cleanup complete. No matching items to remove.', 'product-mailer-campaigns' ) . '</p></div>';
    }

    /**
     * Handle manual force-send submissions from the queue admin page.
     *
     * This intentionally forces only queue timing/status; the normal queue processor
     * still performs the actual delivery checks, compliance footer, logging, and
     * sent/failed state updates.
     *
     * @param string $queue_table Queue table name.
     * @return string Empty string when no notice should be shown.
     */
    protected static function pmcpc_handle_queue_force_send( $queue_table ) {
        global $wpdb;

        if ( ! self::pmcpc_verify_queue_post_nonce( 'pmcpc_queue_force_nonce', 'pmcpc_queue_force_send' ) ) {
            return '';
        }

        if ( ! self::pmcpc_can_manage_queue() ) {
            return '<div class="error notice"><p>' . esc_html__( 'You do not have permission to force-send queue items.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        $force_scope = isset( $_POST['pmcpc_force_scope'] ) ? sanitize_key( (string) wp_unslash( $_POST['pmcpc_force_scope'] ) ) : '';
        $now         = PMCPC_Queue_Runtime::get_now();

        if ( 'all_pending' === $force_scope ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $pending_total = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s', $queue_table, 'pending' ) );

            if ( $pending_total <= 0 ) {
                return '<div class="updated notice"><p>' . esc_html__( 'There are no pending queue items to force send.', 'product-mailer-campaigns' ) . '</p></div>';
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $updated_total = (int) $wpdb->query(
                $wpdb->prepare(
                    'UPDATE %i SET scheduled_at = %s, updated_at = %s WHERE status = %s',
                    $queue_table,
                    $now,
                    $now,
                    'pending'
                )
            );

            if ( method_exists( __CLASS__, 'process_queue' ) ) {
                self::process_queue();
            }

            return '<div class="updated notice"><p>' . sprintf(
                /* translators: %d: number of pending queue items moved to now. */
                esc_html__( '%d pending queue item(s) were moved to now and the queue processor ran once.', 'product-mailer-campaigns' ),
                max( $pending_total, $updated_total )
            ) . '</p></div>';
        }

        if ( 'item' === $force_scope ) {
            $queue_id = isset( $_POST['pmcpc_force_queue_id'] ) ? absint( $_POST['pmcpc_force_queue_id'] ) : 0;
            if ( $queue_id <= 0 ) {
                return '';
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $item = $wpdb->get_row( $wpdb->prepare( 'SELECT id, status FROM %i WHERE id = %d LIMIT 1', $queue_table, $queue_id ) );
            if ( ! $item ) {
                return '<div class="error notice"><p>' . esc_html__( 'That queue item could not be found.', 'product-mailer-campaigns' ) . '</p></div>';
            }

            if ( 'sent' === (string) $item->status ) {
                return '<div class="error notice"><p>' . esc_html__( 'That queue item has already been sent.', 'product-mailer-campaigns' ) . '</p></div>';
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update(
                $queue_table,
                array(
                    'status'       => 'pending',
                    'scheduled_at' => $now,
                    'last_error'   => null,
                    'updated_at'   => $now,
                ),
                array( 'id' => $queue_id ),
                array( '%s', '%s', '%s', '%s' ),
                array( '%d' )
            );

            if ( method_exists( __CLASS__, 'process_queue' ) ) {
                self::process_queue();
            }

            return '<div class="updated notice"><p>' . sprintf(
                /* translators: %d: queue item ID. */
                esc_html__( 'Queue item #%d was moved to now and the queue processor ran once.', 'product-mailer-campaigns' ),
                (int) $queue_id
            ) . '</p></div>';
        }

        return '';
    }

    /**
     * Queue items for the admin list table.
     *
     * @param string $queue_table Queue table name.
     * @param array  $filters     Queue filters.
     * @return array
     */
    protected static function pmcpc_get_queue_items_for_admin( $queue_table, $filters ) {
        global $wpdb;

        $where  = array();
        $params = array();

        if ( '' !== $filters['status_filter'] ) {
            $where[]  = 'status = %s';
            $params[] = $filters['status_filter'];
        }
        if ( $filters['campaign_filter'] > 0 ) {
            $where[]  = 'campaign_id = %d';
            $params[] = (int) $filters['campaign_filter'];
        }
        if ( '' !== $filters['subscriber_search'] ) {
            $where[]  = 'to_email LIKE %s';
            $params[] = '%' . $wpdb->esc_like( $filters['subscriber_search'] ) . '%';
        }

        $sql = "SELECT * FROM $queue_table";
        if ( ! empty( $where ) ) {
            $sql .= ' WHERE ' . implode( ' AND ', $where );
        }
        $sql .= ' ORDER BY created_at DESC LIMIT 100';

		if ( ! empty( $params ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
			return (array) $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
		return (array) $wpdb->get_results( $sql );
    }

    /**
     * Queue health summary for the admin page.
     *
     * @param string $queue_table Queue table name.
     * @return array
     */
    protected static function pmcpc_get_queue_health_summary( $queue_table ) {
        global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
        $counts_rows = $wpdb->get_results( "SELECT status, COUNT(*) AS cnt FROM $queue_table GROUP BY status", ARRAY_A );
        $counts = array( 'pending' => 0, 'held' => 0, 'paused' => 0, 'sent' => 0, 'failed' => 0 );
        if ( is_array( $counts_rows ) ) {
            foreach ( $counts_rows as $row ) {
                if ( empty( $row['status'] ) ) {
                    continue;
                }
                $status = (string) $row['status'];
                if ( isset( $counts[ $status ] ) ) {
                    $counts[ $status ] = (int) $row['cnt'];
                }
            }
        }

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
        $oldest_pending = (string) $wpdb->get_var( "SELECT MIN(created_at) FROM $queue_table WHERE status = 'pending'" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
        $sent_7d = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $queue_table WHERE status = 'sent' AND created_at >= DATE_SUB( UTC_TIMESTAMP(), INTERVAL 7 DAY )" );

        return array(
            'counts'         => $counts,
            'oldest_pending' => $oldest_pending,
            'sent_7d'        => $sent_7d,
        );
    }

    public static function render_queue_page( $args = array() ) {
        global $wpdb;

        $page_slug = isset( $args['page_slug'] ) ? sanitize_key( (string) $args['page_slug'] ) : 'pmcpc_queue';
        $tab       = isset( $args['tab'] ) ? sanitize_key( (string) $args['tab'] ) : '';

        $queue_table     = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
        $campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

        $filters           = self::pmcpc_get_queue_filters();
        $status_filter     = $filters['status_filter'];
        $allowed_status    = $filters['allowed_status'];
        $campaign_filter   = $filters['campaign_filter'];
        $subscriber_search = $filters['subscriber_search'];
        $campaign_options  = self::pmcpc_get_queue_campaign_options( $campaigns_table );

        $toggle_notice     = self::pmcpc_handle_queue_campaign_toggle( $queue_table );
        $cleanup_notice    = self::pmcpc_handle_queue_cleanup( $queue_table );
        $force_send_notice = self::pmcpc_handle_queue_force_send( $queue_table );
        if ( '' !== $toggle_notice ) {
            echo $toggle_notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
        if ( '' !== $cleanup_notice ) {
            echo $cleanup_notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
        if ( '' !== $force_send_notice ) {
            echo $force_send_notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }

        $items          = self::pmcpc_get_queue_items_for_admin( $queue_table, $filters );
        $health_summary = self::pmcpc_get_queue_health_summary( $queue_table );
        $counts         = $health_summary['counts'];
        $oldest_pending = $health_summary['oldest_pending'];
        $sent_7d        = $health_summary['sent_7d'];

        echo '<style>
        .pmcpc-queue-tools-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px;align-items:start;margin:0 0 18px;}
        .pmcpc-queue-panel{min-width:0;}
        .pmcpc-queue-panel h2{margin:0 0 8px;font-size:20px;line-height:1.3;}
        .pmcpc-queue-panel .description{margin:0 0 14px;color:#50575e;max-width:none;}
        .pmcpc-queue-actions-row{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;}
        .pmcpc-queue-field{display:flex;flex-direction:column;gap:6px;min-width:260px;flex:1 1 320px;}
        .pmcpc-queue-field label{font-weight:600;}
        .pmcpc-queue-field select{max-width:100%;}
        .pmcpc-queue-paused-note{display:block;color:#6c7781;}
        .pmcpc-queue-cleanup-form{display:flex;flex-direction:column;gap:12px;margin-bottom:0;}
        .pmcpc-queue-cleanup-grid{display:flex;flex-wrap:wrap;gap:14px;align-items:flex-end;}
        .pmcpc-queue-cleanup-field{display:flex;flex-direction:column;gap:6px;min-width:220px;}
        .pmcpc-queue-cleanup-field label{font-weight:600;}
        .pmcpc-queue-cleanup-help{margin:0;color:#50575e;max-width:720px;}
        .pmcpc-queue-cleanup-confirm{display:none;padding:10px 12px;border:1px solid #f0b2ad;border-radius:10px;background:#fff5f5;}
        .pmcpc-queue-cleanup-confirm.is-visible{display:block;}
        .pmcpc-queue-cleanup-actions{display:flex;flex-wrap:wrap;gap:10px;align-items:center;}
        .pmcpc-queue-cleanup-note{color:#6c7781;}
        .pmcpc-queue-section-title{margin:18px 0 10px;}
        .pmcpc-queue-toolbar-note{margin:0;color:#50575e;}
        .pmcpc-queue-healthbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:10px 12px;margin:12px 0 14px;}
        .pmcpc-queue-healthbar__summary{min-width:240px;}
        .pmcpc-queue-force-form{margin:0;display:inline-flex;gap:8px;align-items:center;}
        .pmcpc-queue-row-actions{display:flex;flex-wrap:wrap;gap:6px;align-items:center;}
        .pmcpc-queue-issue-main{font-weight:600;}
        .pmcpc-queue-issue-main--problem{color:#b32d2e;}
        @media (max-width:782px){.pmcpc-queue-tools-grid{grid-template-columns:1fr;}.pmcpc-queue-actions-row,.pmcpc-queue-cleanup-grid{align-items:stretch;}.pmcpc-queue-field,.pmcpc-queue-cleanup-field{min-width:0;width:100%;}.pmcpc-queue-healthbar{align-items:stretch;}.pmcpc-queue-force-form .button{width:100%;text-align:center;}}
        </style>';

        echo '<div class="pmcpc-queue-healthbar">';
        echo '<div class="pmcpc-queue-healthbar__summary">';
        echo '<strong>' . esc_html__( 'Queue health:', 'product-mailer-campaigns' ) . '</strong> ';
        echo esc_html__( 'Pending', 'product-mailer-campaigns' ) . ': ' . esc_html( (int) $counts['pending'] ) . ' &nbsp; ';
        if ( isset( $counts['held'] ) && (int) $counts['held'] > 0 ) {
            echo esc_html__( 'Held', 'product-mailer-campaigns' ) . ': ' . esc_html( (int) $counts['held'] ) . ' &nbsp; ';
        }
        echo esc_html__( 'Failed', 'product-mailer-campaigns' ) . ': ' . esc_html( (int) $counts['failed'] ) . ' &nbsp; ';
        echo esc_html__( 'Sent (7 days)', 'product-mailer-campaigns' ) . ': ' . esc_html( (int) $sent_7d ) . ' &nbsp; ';
        if ( ! empty( $oldest_pending ) ) {
            echo '<span style="opacity:.85;">' . esc_html__( 'Oldest pending:', 'product-mailer-campaigns' ) . ' ' . esc_html( $oldest_pending ) . '</span>';
        }
        echo '</div>';
        if ( self::pmcpc_can_manage_queue() && (int) $counts['pending'] > 0 ) {
            echo '<form method="post" class="pmcpc-queue-force-form" onsubmit="return confirm(\'' . esc_js( __( 'Send all pending queue items now? This includes future-scheduled workflow steps.', 'product-mailer-campaigns' ) ) . '\');">';
            wp_nonce_field( 'pmcpc_queue_force_send', 'pmcpc_queue_force_nonce' );
            echo '<input type="hidden" name="pmcpc_force_scope" value="all_pending" />';
            echo '<button type="submit" class="button button-primary">' . esc_html__( 'Force send pending now', 'product-mailer-campaigns' ) . '</button>';
            echo '</form>';
        }
        echo '</div>';

        echo '<h2 class="pmcpc-queue-section-title">' . esc_html__( 'Recent queue items', 'product-mailer-campaigns' ) . '</h2>';
        echo '<form method="get" class="pmcpc-table-toolbar">';
        echo '<input type="hidden" name="page" value="' . esc_attr( $page_slug ) . '" />';
        if ( '' !== $tab ) {
            echo '<input type="hidden" name="pmcpc_tab" value="' . esc_attr( $tab ) . '" />';
            echo '<input type="hidden" name="tab" value="' . esc_attr( $tab ) . '" />';
        }
        echo '<div class="pmcpc-table-toolbar__group">';
        echo '<label class="screen-reader-text" for="pmcpc_queue_status">' . esc_html__( 'Filter by status', 'product-mailer-campaigns' ) . '</label>';
        echo '<select id="pmcpc_queue_status" name="status">';
        echo '<option value="">' . esc_html__( 'All statuses', 'product-mailer-campaigns' ) . '</option>';
        foreach ( $allowed_status as $st ) {
            echo '<option value="' . esc_attr( $st ) . '" ' . selected( $status_filter, $st, false ) . '>' . esc_html( ucfirst( $st ) ) . '</option>';
        }
        echo '</select>';
        echo '<label class="screen-reader-text" for="pmcpc_queue_campaign">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</label>';
        echo '<select id="pmcpc_queue_campaign" name="campaign_id" style="min-width:280px;">';
        echo '<option value="0">' . esc_html__( 'All campaigns', 'product-mailer-campaigns' ) . '</option>';
        if ( ! empty( $campaign_options ) ) {
            foreach ( $campaign_options as $cid => $cname ) {
                $label = $cname ? ( $cname . ' (#' . (int) $cid . ')' ) : ( '#' . (int) $cid );
                echo '<option value="' . esc_attr( (int) $cid ) . '" ' . selected( (int) $campaign_filter, (int) $cid, false ) . '>' . esc_html( $label ) . '</option>';
            }
        }
        echo '</select>';
        echo '<label class="screen-reader-text" for="pmcpc_queue_subscriber">' . esc_html__( 'Subscriber', 'product-mailer-campaigns' ) . '</label>';
        echo '<input id="pmcpc_queue_subscriber" type="text" name="subscriber" value="' . esc_attr( $subscriber_search ) . '" placeholder="' . esc_attr__( 'Search subscriber email…', 'product-mailer-campaigns' ) . '" style="min-width:220px;" />';
        echo '<button type="submit" class="button">' . esc_html__( 'Filter', 'product-mailer-campaigns' ) . '</button>';
        if ( '' !== $status_filter || $campaign_filter > 0 || '' !== $subscriber_search ) {
            $clear_url = admin_url( 'admin.php?page=' . $page_slug );
            if ( '' !== $tab ) {
                $clear_url = add_query_arg( array( 'pmcpc_tab' => $tab, 'tab' => $tab ), $clear_url );
            }
            echo '<a class="button button-secondary" href="' . esc_url( $clear_url ) . '">' . esc_html__( 'Clear', 'product-mailer-campaigns' ) . '</a>';
        }
        echo '</div>';
        echo '<div class="pmcpc-table-toolbar__meta"><span>' . esc_html__( 'Filter the queue table without leaving Waiting.', 'product-mailer-campaigns' ) . '</span></div>';
        echo '</form>';

        if ( ! empty( $items ) ) {
            $campaign_ids = array();
            foreach ( $items as $it ) {
                if ( ! empty( $it->campaign_id ) ) {
                    $campaign_ids[] = (int) $it->campaign_id;
                }
            }
            $campaign_ids = array_values( array_unique( array_filter( $campaign_ids ) ) );
            $campaign_map = array();
            if ( ! empty( $campaign_ids ) ) {
                $in = implode( ',', array_fill( 0, count( $campaign_ids ), '%d' ) );
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Placeholder list is built dynamically.
                $rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, name, subject FROM {$campaigns_table} WHERE id IN ($in)", ...$campaign_ids ), ARRAY_A );
                if ( is_array( $rows ) ) {
                    foreach ( $rows as $r ) {
                        $cid   = (int) $r['id'];
                        $label = '';
                        if ( ! empty( $r['name'] ) ) {
                            $label = (string) $r['name'];
                        } elseif ( ! empty( $r['subject'] ) ) {
                            $label = (string) $r['subject'];
                        }
                        $campaign_map[ $cid ] = $label;
                    }
                }
            }

            $paused_campaigns = get_option( 'pmcpc_paused_campaigns', array() );
            if ( ! is_array( $paused_campaigns ) ) {
                $paused_campaigns = array();
            }
            $paused_campaigns = array_values( array_unique( array_map( 'absint', $paused_campaigns ) ) );

            echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
            echo '<table class="widefat striped pmcpc-queue-table pmcpc-wide-table pmcpc-wide-table--queue">';
            echo '<thead><tr>';
            echo '<th class="pmcpc-col-metric">' . esc_html__( 'ID', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-anchor">' . esc_html__( 'Subscriber', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-compare">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-compare">' . esc_html__( 'Send / issue', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-compare">' . esc_html__( 'Created at', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-actions">' . esc_html__( 'Action', 'product-mailer-campaigns' ) . '</th>';
            echo '</tr></thead><tbody>';

            foreach ( $items as $item ) {
                echo '<tr>';
                echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">#' . intval( $item->id ) . '</span></div></td>';
                $cid   = (int) $item->campaign_id;
                $cname = isset( $campaign_map[ $cid ] ) ? $campaign_map[ $cid ] : '';
                echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( $cname ? $cname : ( '#' . $cid ) ) . '</span><span class="pmcpc-table-record__meta">#' . esc_html( $cid ) . '</span></div></td>';
                echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( $item->to_email ) . '</span>';
                if ( ! empty( $item->subscriber_id ) ) {
                    echo '<span class="pmcpc-table-record__meta">' . esc_html__( 'Subscriber ID', 'product-mailer-campaigns' ) . ': ' . esc_html( (int) $item->subscriber_id ) . '</span>';
                }
                echo '</div></td>';
                $status_note = '';
                if ( 'failed' === $item->status && ! empty( $item->last_error ) ) {
                    $status_note = $item->last_error;
                } elseif ( 'held' === $item->status ) {
                    $status_note = __( 'Paused at campaign level', 'product-mailer-campaigns' );
                } elseif ( 'paused' === $item->status ) {
                    $status_note = __( 'Paused before processing', 'product-mailer-campaigns' );
                }
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( ucfirst( (string) $item->status ) ) . '</span>' . ( '' !== $status_note ? '<span class="pmcpc-table-cell-stack__sub">' . esc_html( $status_note ) . '</span>' : '' ) . '</div></td>';
                $send_issue = self::pmcpc_get_queue_send_issue_note( $item, $paused_campaigns );
                $issue_class = in_array( (string) $item->status, array( 'failed', 'held', 'paused' ), true ) || 'Issue' === $send_issue['main'] ? ' pmcpc-queue-issue-main--problem' : '';
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main pmcpc-queue-issue-main' . esc_attr( $issue_class ) . '">' . esc_html( $send_issue['main'] ) . '</span>' . ( '' !== $send_issue['sub'] ? '<span class="pmcpc-table-cell-stack__sub">' . esc_html( $send_issue['sub'] ) . '</span>' : '' ) . '</div></td>';
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( (string) $item->created_at ) . '</span></div></td>';
                echo '<td class="pmcpc-col-actions"><div class="pmcpc-queue-row-actions">';
                if ( self::pmcpc_can_manage_queue() && in_array( (string) $item->status, array( 'pending', 'failed' ), true ) ) {
                    echo '<form method="post" class="pmcpc-queue-force-form" onsubmit="return confirm(\'' . esc_js( __( 'Send this queue item now?', 'product-mailer-campaigns' ) ) . '\');">';
                    wp_nonce_field( 'pmcpc_queue_force_send', 'pmcpc_queue_force_nonce' );
                    echo '<input type="hidden" name="pmcpc_force_scope" value="item" />';
                    echo '<input type="hidden" name="pmcpc_force_queue_id" value="' . esc_attr( (int) $item->id ) . '" />';
                    $send_label = 'failed' === (string) $item->status ? __( 'Retry now', 'product-mailer-campaigns' ) : __( 'Send now', 'product-mailer-campaigns' );
                    echo '<button type="submit" class="button button-small">' . esc_html( $send_label ) . '</button>';
                    echo '</form>';
                } else {
                    echo '<span aria-hidden="true">—</span>';
                }
                echo '</div></td>';
                echo '</tr>';
            }

            echo '</tbody></table>';
            echo '</div></div>';
        } else {
            echo '<div class="pmcpc-card"><p>' . esc_html__( 'No items currently in the email queue.', 'product-mailer-campaigns' ) . '</p></div>';
        }

        $paused_campaigns = get_option( 'pmcpc_paused_campaigns', array() );
        if ( ! is_array( $paused_campaigns ) ) {
            $paused_campaigns = array();
        }
        $paused_campaigns = array_values( array_unique( array_map( 'absint', $paused_campaigns ) ) );

        echo '<h2 class="pmcpc-queue-section-title">' . esc_html__( 'Queue tools', 'product-mailer-campaigns' ) . '</h2>';
        echo '<div class="pmcpc-queue-tools-grid">';

        echo '<div class="pmcpc-card pmcpc-queue-panel">';
        echo '<h2>' . esc_html__( 'Campaign sending controls', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p class="description">' . esc_html__( 'Pause sending for a specific campaign to keep queue activity logged while preventing emails from being sent. This is useful when testing.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="post" class="pmcpc-queue-actions-row">';
        wp_nonce_field( 'pmcpc_campaign_pause', 'pmcpc_campaign_pause_nonce' );
        echo '<div class="pmcpc-queue-field"><label>' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</label>';
        echo '<select name="pmcpc_pause_campaign_id" required>';
        echo '<option value="0">' . esc_html__( 'Select…', 'product-mailer-campaigns' ) . '</option>';
        if ( ! empty( $campaign_options ) ) {
            foreach ( $campaign_options as $cid => $cname ) {
                $label  = $cname ? ( $cname . ' (#' . (int) $cid . ')' ) : ( '#' . (int) $cid );
                $suffix = in_array( (int) $cid, $paused_campaigns, true ) ? ' — ' . esc_html__( 'Paused', 'product-mailer-campaigns' ) : '';
                echo '<option value="' . esc_attr( (int) $cid ) . '">' . esc_html( $label . $suffix ) . '</option>';
            }
        }
        echo '</select>';
        echo '</div>';
        echo '<button type="submit" name="pmcpc_pause_action" value="pause" class="button button-secondary">' . esc_html__( 'Pause sending', 'product-mailer-campaigns' ) . '</button>';
        echo '<button type="submit" name="pmcpc_pause_action" value="resume" class="button">' . esc_html__( 'Resume sending', 'product-mailer-campaigns' ) . '</button>';
        if ( ! empty( $paused_campaigns ) ) {
            $paused_labels = array();
            foreach ( $paused_campaigns as $pcid ) {
                $paused_labels[] = isset( $campaign_options[ $pcid ] ) && $campaign_options[ $pcid ] ? ( $campaign_options[ $pcid ] . ' (#' . $pcid . ')' ) : ( '#' . $pcid );
            }
            echo '<span class="pmcpc-queue-paused-note">' . esc_html__( 'Paused:', 'product-mailer-campaigns' ) . ' ' . esc_html( implode( ', ', $paused_labels ) ) . '</span>';
        }
        echo '</form>';
        echo '</div>';

        echo '<div class="pmcpc-card pmcpc-queue-panel">';
        echo '<h2>' . esc_html__( 'Queue cleanup tools', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p class="description">' . esc_html__( 'Use cleanup when you want to remove old queue records or clear unsent items after testing. Choose one cleanup action at a time for safer review.', 'product-mailer-campaigns' ) . '</p>';
        echo '<form method="post" class="pmcpc-queue-cleanup-form" id="pmcpc-queue-cleanup-form">';
        wp_nonce_field( 'pmcpc_queue_cleanup', 'pmcpc_queue_cleanup_nonce' );
        echo '<div class="pmcpc-queue-cleanup-grid">';
        echo '<div class="pmcpc-queue-cleanup-field">';
        echo '<label for="pmcpc-queue-cleanup-action">' . esc_html__( 'Cleanup action', 'product-mailer-campaigns' ) . '</label>';
        echo '<select id="pmcpc-queue-cleanup-action" name="pmcpc_queue_cleanup_action">';
        echo '<option value="">' . esc_html__( 'Select cleanup action…', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="sent">' . esc_html__( 'Delete sent items older than X days', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="failed">' . esc_html__( 'Delete failed items older than X days', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="pending">' . esc_html__( 'Delete unsent items older than X days (pending/held/paused)', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="pending_all">' . esc_html__( 'Delete ALL unsent items (any age)', 'product-mailer-campaigns' ) . '</option>';
        echo '</select>';
        echo '</div>';
        echo '<div class="pmcpc-queue-cleanup-field">';
        echo '<label for="pmcpc-queue-days">' . esc_html__( 'Only delete items older than (days)', 'product-mailer-campaigns' ) . '</label>';
        echo '<input id="pmcpc-queue-days" type="number" name="pmcpc_queue_days" value="30" min="0" style="width:96px;" />';
        echo '</div>';
        echo '</div>';
        echo '<p class="pmcpc-queue-cleanup-help" id="pmcpc-queue-cleanup-help">' . esc_html__( 'Choose a cleanup action, then run it. Age-based cleanups leave newer queue records alone.', 'product-mailer-campaigns' ) . '</p>';
        echo '<div class="pmcpc-queue-cleanup-confirm" id="pmcpc-queue-cleanup-confirm">';
        echo '<label><input type="checkbox" name="pmcpc_queue_confirm_pending_all" value="1" /> ' . esc_html__( 'I understand this will permanently remove all unsent queue items.', 'product-mailer-campaigns' ) . '</label>';
        echo '</div>';
        echo '<input type="hidden" name="pmcpc_queue_delete_sent" value="" />';
        echo '<input type="hidden" name="pmcpc_queue_delete_failed" value="" />';
        echo '<input type="hidden" name="pmcpc_queue_delete_pending" value="" />';
        echo '<input type="hidden" name="pmcpc_queue_delete_pending_all" value="" />';
        echo '<div class="pmcpc-queue-cleanup-actions">';
        echo '<button type="submit" class="button button-secondary">' . esc_html__( 'Run cleanup', 'product-mailer-campaigns' ) . '</button>';
        echo '<span class="pmcpc-queue-cleanup-note">' . esc_html__( 'Tip: use sent/failed cleanup for routine tidying, and reserve “Delete ALL unsent items” for test resets.', 'product-mailer-campaigns' ) . '</span>';
        echo '</div>';
        echo '</form>';
        echo '<script>(function(){var form=document.getElementById("pmcpc-queue-cleanup-form");if(!form){return;}var select=document.getElementById("pmcpc-queue-cleanup-action");var help=document.getElementById("pmcpc-queue-cleanup-help");var confirmBox=document.getElementById("pmcpc-queue-cleanup-confirm");var sent=form.querySelector(\'input[name="pmcpc_queue_delete_sent"]\');var failed=form.querySelector(\'input[name="pmcpc_queue_delete_failed"]\');var pending=form.querySelector(\'input[name="pmcpc_queue_delete_pending"]\');var pendingAll=form.querySelector(\'input[name="pmcpc_queue_delete_pending_all"]\');var copy={"":"Choose a cleanup action, then run it. Age-based cleanups leave newer queue records alone.","sent":"Removes older sent records while keeping recent delivery history available.","failed":"Removes older failed records after you are done investigating them.","pending":"Removes older unsent items that are still pending, held, or paused.","pending_all":"Removes every unsent queue item regardless of age. Use this only when you want a full reset."};var sync=function(){var value=select?select.value:"";sent.value="";failed.value="";pending.value="";pendingAll.value="";if(value==="sent"){sent.value="1";}else if(value==="failed"){failed.value="1";}else if(value==="pending"){pending.value="1";}else if(value==="pending_all"){pendingAll.value="1";}if(help&&copy[value]!==undefined){help.textContent=copy[value];}if(confirmBox){confirmBox.classList.toggle("is-visible", value==="pending_all");}};if(select){select.addEventListener("change",sync);}sync();})();</script>';
        echo '</div>';

        echo '</div>';
    }

}
