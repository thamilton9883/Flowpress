<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait PMCPC_Queue_Processing_Trait {

    /**
     * Determine if a campaign is an automation-style campaign (non-empty automation_trigger).
     * These are considered "premium" when WooCommerce automation is locked.
     *
     * @param int $campaign_id
     * @return bool
     */
    protected static function pmcpc_is_automation_campaign( $campaign_id ) {
        return '' !== self::pmcpc_get_campaign_automation_trigger( $campaign_id );
    }

    /**
     * Fetch the automation trigger for a campaign.
     *
     * @param int $campaign_id
     * @return string
     */
    protected static function pmcpc_get_campaign_automation_trigger( $campaign_id ) {
        global $wpdb;
        $campaign_id = absint( $campaign_id );
        if ( ! $campaign_id ) {
            return '';
        }
        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $trigger = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT automation_trigger FROM %i WHERE id = %d', $campaigns_table, $campaign_id ) );
        $trigger = sanitize_key( $trigger );
        return ( '' !== $trigger && 'none' !== $trigger ) ? $trigger : '';
    }

    /**
     * Determine if a queue item belongs to a paid WooCommerce automation trigger.
     *
     * @param int $campaign_id
     * @return bool
     */
    protected static function pmcpc_is_premium_wc_queue_campaign( $campaign_id ) {
        $trigger = self::pmcpc_get_campaign_automation_trigger( $campaign_id );
        return '' !== $trigger && function_exists( 'pmcpc_is_premium_wc_trigger' ) && pmcpc_is_premium_wc_trigger( $trigger );
    }

    /**
     * Check if sending is paused for a specific campaign.
     * Stored as an option so it does not require schema changes.
     *
     * @param int $campaign_id
     * @return bool
     */
    protected static function pmcpc_is_campaign_sending_paused( $campaign_id ) {
        $campaign_id = absint( $campaign_id );
        if ( ! $campaign_id ) {
            return false;
        }

        $paused = get_option( 'pmcpc_paused_campaigns', array() );
        if ( ! is_array( $paused ) ) {
            $paused = array();
        }
        $paused = array_map( 'absint', $paused );
        return in_array( $campaign_id, $paused, true );
    }

    protected static function pmcpc_get_campaign_subscriber_page_settings( $campaign_id ) {
        $campaign_id = absint( $campaign_id );
        $defaults = array(
            'enabled'          => 0,
            'title'            => '',
            'excerpt'          => '',
            'content'          => '',
            'topic'            => '',
            'post_status'      => '',
            'featured'         => 0,
            'image_url'        => '',
            'cta_label'        => '',
            'cta_url'          => '',
            'visibility'       => 'public',
            'segment'          => '',
            'expires_at'       => '',
        );

        if ( ! $campaign_id ) {
            return $defaults;
        }

        $settings = get_option( 'pmcpc_campaign_subscriber_page_settings_' . $campaign_id, null );
        if ( ! is_array( $settings ) ) {
            $legacy_settings = get_option( 'pmcpc_campaign_subscriber_page_settings', array() );
            if ( ! is_array( $legacy_settings ) ) {
                $legacy_settings = array();
            }

            if ( empty( $legacy_settings[ $campaign_id ] ) || ! is_array( $legacy_settings[ $campaign_id ] ) ) {
                return $defaults;
            }

            $settings = $legacy_settings[ $campaign_id ];
        }

        $settings = wp_parse_args( $settings, $defaults );
        $settings_has_data = (
            ! empty( $settings['title'] )
            || ! empty( $settings['excerpt'] )
            || ! empty( $settings['content'] )
            || ! empty( $settings['topic'] )
            || ! empty( $settings['post_status'] )
            || ! empty( $settings['featured'] )
            || ! empty( $settings['image_url'] )
            || ! empty( $settings['cta_label'] )
            || ! empty( $settings['cta_url'] )
            || ( isset( $settings['visibility'] ) && 'public' !== (string) $settings['visibility'] )
            || ! empty( $settings['segment'] )
            || ! empty( $settings['expires_at'] )
        );
        $settings['enabled']     = ( empty( $settings['enabled'] ) && ! $settings_has_data ) ? 0 : 1;
        $settings['featured']    = empty( $settings['featured'] ) ? 0 : 1;
        $settings['title']       = sanitize_text_field( (string) $settings['title'] );
        $settings['excerpt']     = sanitize_textarea_field( (string) $settings['excerpt'] );
        $settings['content']     = wp_kses_post( (string) $settings['content'] );
        $settings['topic']       = sanitize_text_field( (string) $settings['topic'] );
        $settings['post_status'] = sanitize_key( (string) $settings['post_status'] );
        $settings['image_url']   = esc_url_raw( (string) $settings['image_url'] );
        $settings['cta_label']   = sanitize_text_field( (string) $settings['cta_label'] );
        $settings['cta_url']     = esc_url_raw( (string) $settings['cta_url'] );
        $settings['visibility']  = sanitize_key( (string) $settings['visibility'] );
        if ( ! in_array( $settings['visibility'], array( 'public', 'subscribers', 'segment', 'private' ), true ) ) {
            $settings['visibility'] = 'public';
        }
        $settings['segment']     = sanitize_text_field( (string) $settings['segment'] );
        $settings['expires_at']  = sanitize_text_field( (string) $settings['expires_at'] );

        return $settings;
    }

    protected static function pmcpc_get_subscriber_updates_defaults() {
        $defaults = array(
            'enabled'               => 1,
            'post_status'           => 'publish',
            'auto_create_page'      => 1,
            'page_id'               => 0,
            'posts_per_page'        => 10,
            'show_date'             => 1,
            'show_topic_filter'     => 1,
            'intro_text'            => '',
            'log_limit'             => 100,
        );

        $saved = get_option( 'pmcpc_sub_updates_settings', array() );
        if ( ! is_array( $saved ) ) {
            $saved = array();
        }

        $settings = wp_parse_args( $saved, $defaults );
        $settings['enabled']          = empty( $settings['enabled'] ) ? 0 : 1;
        $settings['auto_create_page'] = empty( $settings['auto_create_page'] ) ? 0 : 1;
        $settings['page_id']          = absint( $settings['page_id'] );
        $settings['posts_per_page']   = max( 1, min( 50, absint( $settings['posts_per_page'] ) ) );
        $settings['show_date']        = empty( $settings['show_date'] ) ? 0 : 1;
        $settings['show_topic_filter']= empty( $settings['show_topic_filter'] ) ? 0 : 1;
        $settings['intro_text']       = sanitize_textarea_field( (string) $settings['intro_text'] );
        $settings['log_limit']        = max( 20, absint( $settings['log_limit'] ) );
        if ( ! in_array( $settings['post_status'], array( 'publish', 'draft', 'private' ), true ) ) {
            $settings['post_status'] = 'publish';
        }

        return $settings;
    }

    protected static function pmcpc_log_subscriber_update_event( $campaign_row, $result, $details ) {
        $entries = get_option( 'pmcpc_sub_updates_publish_log', array() );
        if ( ! is_array( $entries ) ) {
            $entries = array();
        }

        $entries[] = array(
            'timestamp'     => current_time( 'mysql' ),
            'campaign_id'   => isset( $campaign_row->id ) ? absint( $campaign_row->id ) : 0,
            'campaign_name' => isset( $campaign_row->name ) ? sanitize_text_field( (string) $campaign_row->name ) : '',
            'result'        => sanitize_key( (string) $result ),
            'details'       => sanitize_text_field( (string) $details ),
        );

        $settings = self::pmcpc_get_subscriber_updates_defaults();
        $limit = max( 20, absint( $settings['log_limit'] ) );
        if ( count( $entries ) > $limit ) {
            $entries = array_slice( $entries, -1 * $limit );
        }

        update_option( 'pmcpc_sub_updates_publish_log', array_values( $entries ), false );
    }

    protected static function pmcpc_map_subscriber_update_topic( $trigger_key ) {
        $map = array(
            'welcome'                => __( 'New subscribers', 'product-mailer-campaigns' ),
            'post_purchase'          => __( 'Post purchase', 'product-mailer-campaigns' ),
            'subscriber_inactive'    => __( 'Inactive subscribers', 'product-mailer-campaigns' ),
            'subscriber_anniversary' => __( 'Subscriber anniversary', 'product-mailer-campaigns' ),
            'subscriber_birthday'    => __( 'Subscriber birthday', 'product-mailer-campaigns' ),
            'lead_magnet'            => __( 'Lead magnets', 'product-mailer-campaigns' ),
        );

        if ( isset( $map[ $trigger_key ] ) ) {
            return $map[ $trigger_key ];
        }

        return __( 'Campaign updates', 'product-mailer-campaigns' );
    }

    protected static function pmcpc_ensure_subscriber_updates_page() {
        $settings = self::pmcpc_get_subscriber_updates_defaults();

        $page_id = ! empty( $settings['page_id'] ) ? absint( $settings['page_id'] ) : absint( get_option( 'pmcpc_sub_updates_page_id', 0 ) );
        if ( $page_id > 0 ) {
            $page = get_post( $page_id );
            if ( $page instanceof WP_Post && 'page' === $page->post_type ) {
                update_option( 'pmcpc_sub_updates_page_id', $page_id, false );
                if ( false === strpos( (string) $page->post_content, '[pmcpc_sub_updates' ) ) {
                    wp_update_post(
                        array(
                            'ID'           => $page_id,
                            'post_content' => trim( (string) $page->post_content . "

[pmcpc_sub_updates]" ),
                        )
                    );
                }
                return $page_id;
            }
        }

        if ( empty( $settings['auto_create_page'] ) ) {
            return 0;
        }

        $existing = get_page_by_path( 'subscriber-updates' );
        if ( $existing instanceof WP_Post ) {
            update_option( 'pmcpc_sub_updates_page_id', (int) $existing->ID, false );
            return (int) $existing->ID;
        }

        $page_id = wp_insert_post(
            array(
                'post_title'   => __( 'Subscriber Updates', 'product-mailer-campaigns' ),
                'post_name'    => 'subscriber-updates',
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_content' => '[pmcpc_sub_updates]',
            )
        );

        if ( $page_id && ! is_wp_error( $page_id ) ) {
            update_option( 'pmcpc_sub_updates_page_id', (int) $page_id, false );
            return (int) $page_id;
        }

        return 0;
    }

    protected static function pmcpc_sync_subscriber_update_post( $item, $subject, $body_html, $now ) {
        $campaign_id = isset( $item->campaign_id ) ? absint( $item->campaign_id ) : 0;
        if ( ! $campaign_id ) {
            return;
        }

        $settings = self::pmcpc_get_campaign_subscriber_page_settings( $campaign_id );
        $global_settings = self::pmcpc_get_subscriber_updates_defaults();
        if ( empty( $global_settings['enabled'] ) || empty( $settings['enabled'] ) ) {
            return;
        }

        global $wpdb;
        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $campaign_row = $wpdb->get_row( $wpdb->prepare( "SELECT id, name, automation_trigger FROM {$campaigns_table} WHERE id = %d", $campaign_id ) );
        if ( ! $campaign_row ) {
            return;
        }

        self::pmcpc_ensure_subscriber_updates_page();

        $trigger_key = isset( $campaign_row->automation_trigger ) ? sanitize_key( (string) $campaign_row->automation_trigger ) : '';
        $current_day = function_exists( 'wp_date' ) ? wp_date( 'Ymd' ) : gmdate( 'Ymd' );
        $publish_key = ( '' !== $trigger_key && 'none' !== $trigger_key )
            ? 'campaign-' . $campaign_id . '-' . $current_day
            : 'queue-' . absint( $item->id );

        if ( false !== get_transient( 'pmcpc_sub_update_lock_' . $publish_key ) ) {
            self::pmcpc_log_subscriber_update_event( $campaign_row, 'skipped', __( 'Duplicate publish attempt blocked by transient lock.', 'product-mailer-campaigns' ) );
            return;
        }

        set_transient( 'pmcpc_sub_update_lock_' . $publish_key, 1, 5 * MINUTE_IN_SECONDS );

        $existing = get_posts(
            array(
                'post_type'      => 'pmcpc_sub_update',
                'post_status'    => array( 'publish', 'draft', 'private' ),
                'posts_per_page' => 1,
                'meta_key'       => '_pmcpc_publish_key',
                'meta_value'     => $publish_key,
                'fields'         => 'ids',
            )
        );

        $title = '' !== trim( (string) $settings['title'] ) ? sanitize_text_field( (string) $settings['title'] ) : wp_strip_all_tags( (string) $subject );
        if ( '' === $title ) {
            $title = ! empty( $campaign_row->name ) ? (string) $campaign_row->name : __( 'Subscriber Update', 'product-mailer-campaigns' );
        }

        $content = '' !== trim( wp_strip_all_tags( (string) $settings['content'] ) ) ? wp_kses_post( (string) $settings['content'] ) : wp_kses_post( (string) $body_html );
        if ( class_exists( 'PMCPC_Campaign_Manager' ) && method_exists( 'PMCPC_Campaign_Manager', 'pmcpc_inject_products_block_for_campaign_id' ) ) {
            $content = PMCPC_Campaign_Manager::pmcpc_inject_products_block_for_campaign_id( $campaign_id, $content );
        }
        if ( class_exists( 'PMCPC_Campaign_Manager' ) && method_exists( 'PMCPC_Campaign_Manager', 'pmcpc_render_products_block_for_campaign_id' ) ) {
            $products_html = (string) PMCPC_Campaign_Manager::pmcpc_render_products_block_for_campaign_id( $campaign_id );
            if ( '' !== $products_html && false === strpos( $content, 'pmcpc-commerce-update' ) && false === strpos( $content, 'pmcpc-email-products' ) && false === strpos( $content, 'pmcpc-product-card' ) && false === strpos( $content, 'pmcpc-product-grid' ) ) {
                $content .= $products_html;
            }
        }
        if ( '' === trim( wp_strip_all_tags( $content ) ) ) {
            delete_transient( 'pmcpc_sub_update_lock_' . $publish_key );
            self::pmcpc_log_subscriber_update_event( $campaign_row, 'skipped', __( 'Skipped because the rendered content was empty.', 'product-mailer-campaigns' ) );
            return;
        }

        $global_settings = self::pmcpc_get_subscriber_updates_defaults();
        $excerpt = '' !== trim( (string) $settings['excerpt'] ) ? sanitize_textarea_field( (string) $settings['excerpt'] ) : wp_trim_words( wp_strip_all_tags( $content ), 40 );
        $post_status = ! empty( $settings['post_status'] ) ? sanitize_key( (string) $settings['post_status'] ) : $global_settings['post_status'];
        if ( ! in_array( $post_status, array( 'publish', 'draft', 'private' ), true ) ) {
            $post_status = $global_settings['post_status'];
        }
        $postarr = array(
            'post_type'    => 'pmcpc_sub_update',
            'post_title'   => $title,
            'post_content' => $content,
            'post_excerpt' => $excerpt,
            'post_status'  => $post_status,
        );

        if ( ! empty( $existing ) ) {
            $postarr['ID'] = (int) $existing[0];
            $post_id = wp_update_post( wp_slash( $postarr ), true );
            $log_result = 'updated';
        } else {
            $post_id = wp_insert_post( wp_slash( $postarr ), true );
            $log_result = 'created';
        }

        if ( $post_id && ! is_wp_error( $post_id ) ) {
            update_post_meta( $post_id, '_pmcpc_campaign_id', $campaign_id );
            update_post_meta( $post_id, '_pmcpc_publish_key', $publish_key );
            update_post_meta( $post_id, '_pmcpc_last_queue_id', absint( $item->id ) );
            update_post_meta( $post_id, '_pmcpc_last_synced_at', sanitize_text_field( (string) $now ) );
            update_post_meta( $post_id, '_pmcpc_source_trigger', $trigger_key );
            update_post_meta( $post_id, '_pmcpc_source_type', ( '' !== $trigger_key && 'none' !== $trigger_key ) ? 'automation' : 'campaign' );
            update_post_meta( $post_id, '_pmcpc_is_featured', empty( $settings['featured'] ) ? 0 : 1 );
            update_post_meta( $post_id, '_pmcpc_image_url', esc_url_raw( (string) $settings['image_url'] ) );
            update_post_meta( $post_id, '_pmcpc_cta_label', sanitize_text_field( (string) $settings['cta_label'] ) );
            update_post_meta( $post_id, '_pmcpc_cta_url', esc_url_raw( (string) $settings['cta_url'] ) );
            update_post_meta( $post_id, '_pmcpc_visibility', sanitize_key( (string) $settings['visibility'] ) );
            update_post_meta( $post_id, '_pmcpc_required_segment', sanitize_text_field( (string) $settings['segment'] ) );
            if ( ! empty( $settings['expires_at'] ) ) {
                update_post_meta( $post_id, '_pmcpc_expires_at', sanitize_text_field( (string) $settings['expires_at'] ) );
            } else {
                delete_post_meta( $post_id, '_pmcpc_expires_at' );
            }
            if ( '' === get_post_meta( $post_id, '_pmcpc_view_count', true ) ) {
                update_post_meta( $post_id, '_pmcpc_view_count', 0 );
            }
            if ( '' === get_post_meta( $post_id, '_pmcpc_subscriber_view_count', true ) ) {
                update_post_meta( $post_id, '_pmcpc_subscriber_view_count', 0 );
            }
            if ( '' === get_post_meta( $post_id, '_pmcpc_cta_click_count', true ) ) {
                update_post_meta( $post_id, '_pmcpc_cta_click_count', 0 );
            }
            $topic_name = '' !== trim( (string) $settings['topic'] ) ? sanitize_text_field( (string) $settings['topic'] ) : self::pmcpc_map_subscriber_update_topic( $trigger_key );
            wp_set_post_terms( $post_id, array( $topic_name ), 'pmcpc_update_topic', false );
            self::pmcpc_log_subscriber_update_event( $campaign_row, $log_result, sprintf( __( 'Website update saved as post #%d.', 'product-mailer-campaigns' ), absint( $post_id ) ) );
        } else {
            self::pmcpc_log_subscriber_update_event( $campaign_row, 'error', $post_id instanceof WP_Error ? $post_id->get_error_message() : __( 'Unknown publishing error.', 'product-mailer-campaigns' ) );
        }

        delete_transient( 'pmcpc_sub_update_lock_' . $publish_key );
    }

    /**
     * Build the standard headers used for queued emails.
     *
     * @return array
     */
    protected static function pmcpc_build_queue_headers() {
        $from_name  = get_bloginfo( 'name' );
        $from_email = get_option( 'admin_email' );

        if ( class_exists( 'PMCPC_Settings' ) ) {
            $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );
            $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );

            if ( ! empty( $from_name_setting ) ) {
                $from_name = $from_name_setting;
            }
            if ( ! empty( $from_email_setting ) ) {
                $from_email = $from_email_setting;
            }
        }

        $from_email = sanitize_email( $from_email );
        if ( ! $from_email ) {
            $from_email = sanitize_email( (string) get_option( 'admin_email' ) );
        }

        return array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . sprintf( '%s <%s>', wp_specialchars_decode( (string) $from_name, ENT_QUOTES ), $from_email ),
            'Reply-To: ' . $from_email,
            'Return-Path: ' . $from_email,
        );
    }

    /**
     * Build preference-management URLs for a queued email.
     *
     * @param string $to   Recipient email.
     * @param object $item Queue item.
     * @return array<string,string>
     */
    protected static function pmcpc_build_preferences_urls( $to, $item ) {
        $prefs_base = pmcpc_get_setting( 'preferences_page_url', home_url( '/manage-preferences/' ) );

        /**
         * Filter: pmcpc_preferences_page_url
         *
         * Allows sites to override the Manage Preferences page URL.
         *
         * @param string $prefs_base Preferences page URL.
         * @param object $item       Queue item.
         */
        $prefs_base  = apply_filters( 'pmcpc_preferences_page_url', $prefs_base, $item );
        $email_norm  = strtolower( trim( (string) $to ) );
        $expires_at  = time() + ( WEEK_IN_SECONDS * 2 );
        $token_data  = $email_norm . '|' . $expires_at;
        $signature   = hash_hmac( 'sha256', $token_data, wp_salt( 'auth' ) );
        $token       = rtrim( strtr( base64_encode( $token_data . '|' . $signature ), '+/', '-_' ), '=' );
        $manage_url  = add_query_arg( 'pmcpc_token', $token, $prefs_base );
        $unsub_url   = $manage_url . '#pmcpc-unsubscribe';

        return array(
            'manage_url' => $manage_url,
            'unsub_url'  => $unsub_url,
        );
    }

    /**
     * Add compliance links to the email body when enabled.
     *
     * @param string $body_html  Email HTML.
     * @param int    $campaign_id Campaign ID.
     * @param string $manage_url Manage preferences URL.
     * @param string $unsub_url  Unsubscribe URL.
     * @return string
     */
    protected static function pmcpc_append_compliance_footer( $body_html, $campaign_id, $manage_url, $unsub_url ) {
        global $wpdb;

        $auto_footer_links_enabled = 1;
        if ( $campaign_id > 0 ) {
            $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $footer_setting = $wpdb->get_var( $wpdb->prepare( "SELECT auto_footer_links_enabled FROM {$campaigns_table} WHERE id = %d", $campaign_id ) );
            if ( null !== $footer_setting ) {
                $auto_footer_links_enabled = (int) $footer_setting;
            }
        }

        if ( ! $auto_footer_links_enabled || false !== strpos( (string) $body_html, 'pmcpc-footer-links' ) ) {
            return (string) $body_html;
        }

        return (string) $body_html
            . '<hr class="pmcpc-footer-links" />'
            . '<p class="pmcpc-footer-links" style="font-size:12px;line-height:1.4;margin:10px 0 0;">'
            . '<a href="' . esc_url( $manage_url ) . '">' . esc_html__( 'Manage preferences', 'product-mailer-campaigns' ) . '</a>'
            . ' | '
            . '<a href="' . esc_url( $unsub_url ) . '">' . esc_html__( 'Unsubscribe', 'product-mailer-campaigns' ) . '</a>'
            . '</p>';
    }

    /**
     * Persist an event row for a queue item.
     *
     * @param int    $queue_id Queue item ID.
     * @param string $event    Event type.
     * @param string $now      Timestamp.
     * @return void
     */
    protected static function pmcpc_insert_queue_event( $queue_id, $event, $now ) {
        global $wpdb;

        $events_table = esc_sql( $wpdb->prefix . 'pmcpc_email_events' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->insert(
            $events_table,
            array(
                'queue_id'   => (int) $queue_id,
                'event_type' => sanitize_key( (string) $event ),
                'created_at' => $now,
            ),
            array( '%d', '%s', '%s' )
        );
    }

    public static function process_queue() {
        PMCPC_Queue_Runtime::ensure_queue_is_scheduled();

        if ( ! PMCPC_Queue_Runtime::acquire_process_lock() ) {
            PMCPC_Queue_Runtime::log_activity( 'Queue run skipped because another queue process is already active.' );
            return;
        }

        global $wpdb;

        $queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
        $now         = PMCPC_Queue_Runtime::get_now();

        try {
        // If sending is paused in settings, do not send anything.
        $pause_sending = PMCPC_Settings::get( 'pause_sending', 'no' );
        if ( 'yes' === $pause_sending ) {
            PMCPC_Queue_Runtime::log_activity( 'Queue run skipped because sending is paused in settings.' );
            return;
        }

        // If premium WooCommerce automation is enabled (trial or license), re-activate items
        // paused by the Commerce license gate.
        if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query( $wpdb->prepare( 'UPDATE %i SET status = %s WHERE status = %s AND last_error = %s', $queue_table, 'pending', 'paused', 'Commerce automation unavailable.' ) );
        }

        $items = PMCPC_Queue_Runtime::get_due_items( $now, PMCPC_Queue_Runtime::get_batch_size() );

        if ( ! $items ) {
            PMCPC_Queue_Runtime::log_activity( 'Queue run found no due emails.' );
            return;
        }

        PMCPC_Queue_Runtime::log_activity( sprintf( 'Queue run: processing %d email(s).', count( $items ) ) );

        foreach ( $items as $item ) {

            // If sending is paused for this campaign, hold the queue item (do not send, but keep a record).
            if ( self::pmcpc_is_campaign_sending_paused( (int) $item->campaign_id ) ) {
                $wpdb->update(
                    $queue_table,
                    array(
                        'status'     => 'held',
                        'updated_at' => $now,
                    ),
                    array( 'id' => (int) $item->id ),
                    array( '%s', '%s' ),
                    array( '%d' )
                );
                continue;
            }

            // If this queued email belongs to a paid WooCommerce automation and Commerce is no longer
            // enabled, pause it instead of sending. This catches items queued before a license expired.
            if ( self::pmcpc_is_premium_wc_queue_campaign( (int) $item->campaign_id ) && ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() ) ) {
                if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
                    PMCPC_Activity_Feed::log( 'Commerce automation email paused because the license/trial is inactive.' );
                }

                $wpdb->update(
                    $queue_table,
                    array(
                        'status'     => 'paused',
                        'last_error' => 'Commerce automation unavailable.',
                        'updated_at' => $now,
                    ),
                    array( 'id' => (int) $item->id ),
                    array( '%s', '%s', '%s' ),
                    array( '%d' )
                );
                continue;
            }

            // If this is an automation campaign and premium automation is locked, pause it instead of sending.
            // This is a key conversion mechanic for trials: users can *see* what would have sent, then upgrade.
            if ( function_exists( 'pmcpc_features' ) && ! pmcpc_features()->enabled( 'automation' ) ) {
                $is_auto = self::pmcpc_is_automation_campaign( (int) $item->campaign_id );
                if ( $is_auto ) {
                    // Move to a non-sending status. It will be restored to pending after upgrade.
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
                        PMCPC_Activity_Feed::log( 'Automation email paused (requires WooCommerce Automation).' );
                    }

                    $wpdb->update(
                        $queue_table,
                        array(
                            'status'     => 'paused',
                            'updated_at' => $now,
                        ),
                        array( 'id' => (int) $item->id ),
                        array( '%s', '%s' ),
                        array( '%d' )
                    );
                    continue;
                }
            }

            $headers   = self::pmcpc_build_queue_headers();

            $subject   = $item->subject;
            $body_html = $item->body_html;
            $to        = sanitize_email( (string) $item->to_email );

            $update_data = array(
                'attempts'   => (int) $item->attempts + 1,
                'updated_at' => $now,
            );
            $update_where = array( 'id' => (int) $item->id );
            $attempts     = (int) $update_data['attempts'];

            $body_text = wp_strip_all_tags( (string) $body_html );
            $headers_s = maybe_serialize( $headers );

            if ( ! $to || ! is_email( $to ) ) {
                $update_data['status']     = 'failed';
                $update_data['last_error'] = __( 'Queue item has an invalid recipient email address.', 'product-mailer-campaigns' );

                PMCPC_Queue_Runtime::insert_email_log(
                    $item,
                    array(
                        'to_email'   => (string) $item->to_email,
                        'subject'    => $subject,
                        'body_html'  => $body_html,
                        'body_text'  => $body_text,
                        'headers'    => $headers_s,
                        'status'     => 'failed',
                        'last_error' => $update_data['last_error'],
                        'sent_at'    => null,
                        'created_at' => $now,
                    )
                );

                PMCPC_Queue_Runtime::log_activity( sprintf( 'Email failed for queue item #%d because the recipient email is invalid.', (int) $item->id ) );

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $wpdb->update( $queue_table, $update_data, $update_where );
                continue;
            }

            // Ensure we have a stable per-email view token (used for one-click unsubscribe and view-in-browser).
            $view_token = isset( $item->view_token ) ? (string) $item->view_token : '';
            if ( '' === $view_token && class_exists( 'PMCPC_Tracking' ) ) {
                $view_token = PMCPC_Tracking::generate_view_token();
                // Persist so the token remains valid even if salts/keys change later.
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $wpdb->update(
                    $queue_table,
                    array(
                        'view_token' => $view_token,
                        'updated_at' => $now,
                    ),
                    array( 'id' => (int) $item->id ),
                    array( '%s', '%s' ),
                    array( '%d' )
                );
            }

            $preference_urls = self::pmcpc_build_preferences_urls( $to, $item );
            $manage_url      = $preference_urls['manage_url'];
            $unsub_url       = $preference_urls['unsub_url'];
            $body_html       = self::pmcpc_append_compliance_footer( $body_html, (int) $item->campaign_id, $manage_url, $unsub_url );
            $body_text       = wp_strip_all_tags( (string) $body_html );

            $result = wp_mail( $to, $subject, $body_html, $headers );

            if ( $result ) {
                $subj = is_string( $subject ) ? wp_strip_all_tags( $subject ) : '';
                $subj = substr( $subj, 0, 80 );
                PMCPC_Queue_Runtime::log_activity( sprintf( 'Email sent: %s', $subj ) );

                $update_data['status'] = 'sent';
                $update_data['last_error'] = null;

                self::pmcpc_insert_queue_event( (int) $item->id, 'sent', $now );
                PMCPC_Queue_Runtime::insert_email_log(
                    $item,
                    array(
                        'to_email'   => $to,
                        'subject'    => $subject,
                        'body_html'  => $body_html,
                        'body_text'  => $body_text,
                        'headers'    => $headers_s,
                        'status'     => 'sent',
                        'last_error' => null,
                        'sent_at'    => $now,
                        'created_at' => $now,
                    )
                );

                self::pmcpc_sync_subscriber_update_post( $item, $subject, $body_html, $now );

            } else {
                $update_data['last_error'] = 'wp_mail returned false';

                if ( $attempts >= PMCPC_Queue_Runtime::MAX_ATTEMPTS ) {
                    $update_data['status']     = 'failed';

                    $subj = is_string( $subject ) ? wp_strip_all_tags( $subject ) : '';
                    $subj = substr( $subj, 0, 80 );
                    PMCPC_Queue_Runtime::log_activity( sprintf( 'Email failed after %d attempts: %s', $attempts, $subj ) );

                    PMCPC_Queue_Runtime::insert_email_log(
                        $item,
                        array(
                            'to_email'   => $to,
                            'subject'    => $subject,
                            'body_html'  => $body_html,
                            'body_text'  => $body_text,
                            'headers'    => $headers_s,
                            'status'     => 'failed',
                            'last_error' => 'wp_mail returned false',
                            'sent_at'    => null,
                            'created_at' => $now,
                        )
                    );

                } else {
                    $update_data['status'] = 'pending';
                    PMCPC_Queue_Runtime::log_activity( sprintf( 'Email retry scheduled for queue item #%d (attempt %d of %d).', (int) $item->id, $attempts, PMCPC_Queue_Runtime::MAX_ATTEMPTS ) );
                }
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update(
                $queue_table,
                $update_data,
                $update_where
            );
        }

        PMCPC_Queue_Runtime::complete_finished_campaigns( $now );
        } finally {
            PMCPC_Queue_Runtime::release_process_lock();
        }
    }

}
