<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Lightweight dependency container.
 *
 * - Supports lazy singletons by default.
 * - Designed to be WP-friendly (no external deps).
 */
class PMCPC_Container {

    /** @var array<string, callable> */
    private $factories = array();

    /** @var array<string, bool> */
    private $singletons = array();

    /** @var array<string, mixed> */
    private $instances = array();

    /**
     * Bind a service.
     *
     * @param string   $id
     * @param callable $factory function (PMCPC_Container $c): object
     * @param bool     $singleton
     * @return void
     */
    public function bind( $id, $factory, $singleton = true ) {
        $this->factories[ (string) $id ]  = $factory;
        $this->singletons[ (string) $id ] = (bool) $singleton;
        unset( $this->instances[ (string) $id ] );
    }

    /**
     * Convenience for singletons.
     */
    public function singleton( $id, $factory ) {
        $this->bind( $id, $factory, true );
    }

    /**
     * Convenience for transients.
     */
    public function factory( $id, $factory ) {
        $this->bind( $id, $factory, false );
    }

    /**
     * Resolve a service.
     *
     * @param string $id
     * @return mixed
     */
    public function get( $id ) {
        $id = (string) $id;

        if ( isset( $this->instances[ $id ] ) ) {
            return $this->instances[ $id ];
        }

        if ( ! isset( $this->factories[ $id ] ) ) {
            throw new RuntimeException( 'PMCPC container: unknown service "' . $id . '"' );
        }

        $obj = call_user_func( $this->factories[ $id ], $this );

        if ( ! empty( $this->singletons[ $id ] ) ) {
            $this->instances[ $id ] = $obj;
        }

        return $obj;
    }

    /**
     * @param string $id
     * @return bool
     */
    public function has( $id ) {
        return isset( $this->factories[ (string) $id ] );
    }
}
