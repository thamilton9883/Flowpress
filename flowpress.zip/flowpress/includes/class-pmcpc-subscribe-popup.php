<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PMCPC_Subscribe_Popup {

    public static function init() {
        add_action( 'init', array( __CLASS__, 'maybe_register' ) );
    }

    public static function maybe_register() {
        if ( ! function_exists( 'is_user_logged_in' ) ) {
            return;
        }

        if ( is_user_logged_in() ) {
            return;
        }

        // Allow admins to disable the front-end subscribe popup.
        if ( class_exists( 'PMCPC_Settings' ) ) {
            $popup_enabled = PMCPC_Settings::get( 'subscribe_popup_enabled', 'yes' );
            if ( 'yes' !== (string) $popup_enabled ) {
                return;
            }
        }

        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
        add_action( 'wp_footer', array( __CLASS__, 'render_popup' ) );
    }

    public static function enqueue_assets() {
        wp_enqueue_style(
            'pmcpc-popup',
            PMCPC_PLUGIN_URL . 'assets/popup.css',
            array(),
            PMCPC_PLUGIN_VERSION
        );

        // Popup behaviour can be tuned from Settings.
        $delay_ms     = 3000;
        $days_between = 7;

        if ( class_exists( 'PMCPC_Settings' ) ) {
            $delay_ms     = (int) PMCPC_Settings::get( 'subscribe_popup_delay_ms', 3000 );
            $days_between = (int) PMCPC_Settings::get( 'subscribe_popup_days_between', 7 );
        }

        $delay_ms = max( 0, min( 60000, $delay_ms ) );
        $days_between = max( 0, min( 365, $days_between ) );

        wp_enqueue_script(
            'pmcpc-popup',
            PMCPC_PLUGIN_URL . 'assets/popup.js',
            array(),
            PMCPC_PLUGIN_VERSION,
            true
        );

        wp_localize_script(
            'pmcpc-popup',
            'pmcpcPopupConfig',
            array(
                'delayMs'     => $delay_ms,
                'daysBetween' => $days_between,
            )
        );
    }

    public static function render_popup() {
        echo '<div id="pmcpc-popup" style="display:none;">';
        echo '<div class="pmcpc-popup-box">';
        echo '<span class="pmcpc-popup-close" aria-label="' . esc_attr__( 'Close', 'product-mailer-campaigns' ) . '">&times;</span>';
        echo '<h3>' . esc_html__( 'Subscribe for updates', 'product-mailer-campaigns' ) . '</h3>';
        echo do_shortcode( "[pmcpc_subscribe show_name='no']" ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div></div>';
    }
}
