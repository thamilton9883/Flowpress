<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';

/**
 * Admin UI wiring: menus, labels, legacy redirects, and lightweight admin housekeeping.
 */
class PMCPC_Admin_UI_Service implements PMCPC_Service_Interface {

    /**
     * Hidden workspace routes registered on this request.
     *
     * @var array<string,bool>
     */
    private $hidden_route_slugs = array();

    /**
     * Registered workspace page callbacks keyed by menu slug.
     *
     * @var array<string,callable|string>
     */
    private $workspace_page_callbacks = array();

    /**
     * Build a submenu label with a Dashicon.
     *
     * Note: WordPress supports HTML in submenu labels.
     */
    private static function submenu_label_with_icon( $dashicon, $label_html ) {
        $dashicon = sanitize_html_class( (string) $dashicon );
        return '<span class="dashicons ' . esc_attr( $dashicon ) . '" aria-hidden="true"></span>'
            . '<span class="pmcpc-menu-text">' . $label_html . '</span>';
    }

    /**
     * Determine whether the current admin screen is inside the marketing workspace.
     *
     * @return bool
     */

    /**
     * Ensure WordPress always receives a string for the admin <title> tag.
     *
     * @param mixed $title Raw admin title.
     * @return string
     */
    public function ensure_safe_admin_title( $title ) {
        return is_string( $title ) ? $title : '';
    }

    /**
     * Ensure page titles used in the admin header are never null.
     *
     * @param mixed $title Raw page title.
     * @return string
     */
    public function ensure_safe_page_title( $title ) {
        return is_string( $title ) ? $title : '';
    }

    /**
     * Ensure hidden workspace pages always have a string title before
     * wp-admin/admin-header.php calls strip_tags().
     *
     * @return void
     */
    public function ensure_global_admin_page_title() {
        if ( ! is_admin() || ! $this->is_workspace_screen() ) {
            return;
        }

        global $title;
        if ( is_string( $title ) && '' !== trim( $title ) ) {
            return;
        }

        $page  = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing param.
        $title = $this->resolve_workspace_admin_page_title( $page );
    }

    /**
     * Normalize an admin page title to a non-empty plain string.
     *
     * @param mixed $page_title Raw page title.
     * @return string
     */
    private function normalize_admin_page_title( $page_title ) {
        $page_title = is_scalar( $page_title ) ? (string) $page_title : '';
        $page_title = trim( wp_strip_all_tags( $page_title ) );

        if ( '' === $page_title ) {
            $page_title = ( class_exists( 'PMCPC_Admin' ) && method_exists( 'PMCPC_Admin', 'app_brand' ) )
                ? (string) PMCPC_Admin::app_brand()
                : __( 'FlowPress', 'product-mailer-campaigns' );
        }

        return $page_title;
    }

    /**
     * Resolve a workspace route/page slug to the page title used in the browser tab.
     *
     * @param string $page Admin page slug.
     * @return string
     */
    private function resolve_workspace_admin_page_title( $page ) {
        $page        = (string) $page;
        $definitions = array_merge(
            $this->get_workspace_submenu_definitions(),
            $this->get_hidden_admin_page_definitions(),
            $this->get_workspace_route_definitions()
        );

        foreach ( $definitions as $definition ) {
            $slug = isset( $definition['menu_slug'] ) ? (string) $definition['menu_slug'] : ( isset( $definition['slug'] ) ? (string) $definition['slug'] : '' );
            if ( $slug !== $page ) {
                continue;
            }

            $raw_title = isset( $definition['page_title'] ) ? $definition['page_title'] : ( isset( $definition['title'] ) ? $definition['title'] : '' );
            return $this->normalize_admin_page_title( $raw_title );
        }

        return $this->normalize_admin_page_title( '' );
    }

    /**
     * Remove WordPress footer text on FlowPress workspace screens.
     *
     * @param string $text Existing footer text.
     * @return string
     */
    public function filter_workspace_admin_footer_text( $text ) {
        return $this->is_workspace_screen() ? '' : $text;
    }

    /**
     * Remove WordPress version text on FlowPress workspace screens.
     *
     * @param string $text Existing update footer text.
     * @return string
     */
    public function filter_workspace_update_footer_text( $text ) {
        return $this->is_workspace_screen() ? '' : $text;
    }

    private function is_workspace_screen() {
        if ( ! is_admin() ) {
            return false;
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( $page && ( 0 === strpos( (string) $page, 'pmcpc_' ) || 0 === strpos( (string) $page, 'pmcpc-' ) ) ) {
            return true;
        }

        if ( isset( $_GET['post_type'] ) && 'pmcpc_sub_update' === sanitize_key( wp_unslash( $_GET['post_type'] ) ) ) {
            return true;
        }

        if ( isset( $_GET['post'] ) ) {
            $post_id = absint( $_GET['post'] );
            if ( $post_id && 'pmcpc_sub_update' === get_post_type( $post_id ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Determine whether the current screen is a native Subscriber Updates CPT screen.
     *
     * @return bool
     */
    private function is_subscriber_updates_native_screen() {
        if ( ! is_admin() || ! function_exists( 'get_current_screen' ) ) {
            return false;
        }

        $screen = get_current_screen();
        if ( ! $screen || 'pmcpc_sub_update' !== $screen->post_type ) {
            return false;
        }

        return in_array( $screen->base, array( 'edit', 'post', 'post-new' ), true );
    }

    /**
     * Add a workspace body class so the admin shell can be styled safely.
     *
     * @param string $classes Existing admin body classes.
     * @return string
     */
    public function add_workspace_body_class( $classes ) {
        $classes = is_string( $classes ) ? $classes : '';

        if ( $this->is_workspace_screen() ) {
            $classes .= ' pmcpc-workspace-screen';
            if ( function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features() ) {
                $classes .= ' pmcpc-paid-features-hidden';
            }
        }

        return trim( $classes );
    }

    public function register() {
        add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
        add_action( 'admin_menu', array( $this, 'register_email_preview_page' ), 100002 );
        // Reorder submenu items into a task-first flow (includes Pro items when present).
        add_action( 'admin_menu', array( $this, 'reorder_admin_submenus' ), 99999 );
        add_action( 'admin_menu', array( $this, 'cleanup_legacy_submenus' ), 100000 );
        add_action( 'admin_menu', array( $this, 'ensure_workspace_routes' ), 100001 );
        add_action( 'admin_menu', array( $this, 'whitelist_workspace_submenus' ), 2147483647 );
        // Hide selected submenu items visually (CSS), while keeping pages registered.
        // NOTE: remove_submenu_page() also removes routability for admin.php?page=... screens.
        add_action( 'admin_head', array( $this, 'hide_workspace_pages_from_menu_css' ) );
        add_action( 'admin_head', array( $this, 'hide_wordpress_admin_sidebar_on_workspace_pages' ) );
        add_action( 'admin_head', array( $this, 'output_workspace_shell_assets' ) );
        add_action( 'current_screen', array( $this, 'ensure_global_admin_page_title' ), 1 );
        add_action( 'admin_head', array( $this, 'output_subscriber_updates_bridge_assets' ) );
        add_action( 'in_admin_header', array( $this, 'render_subscriber_updates_bridge_header' ) );
        add_filter( 'admin_body_class', array( $this, 'add_workspace_body_class' ) );
        // Back-compat: redirect legacy page slugs to current ones.
        add_action( 'admin_init', array( $this, 'handle_legacy_admin_pages' ) );
        // Mark Messages as seen for the current admin when they visit the Messages screen.
        add_action( 'admin_init', array( $this, 'maybe_mark_messages_seen' ), 20 );
        // Uses gettext so it works regardless of where the strings are generated.
        add_filter( 'gettext', array( $this, 'admin_gettext_overrides' ), 10, 3 );
        add_filter( 'admin_title', array( $this, 'ensure_safe_admin_title' ), 10, 1 );
        add_filter( 'get_admin_page_title', array( $this, 'ensure_safe_page_title' ), 10, 1 );
        add_filter( 'admin_footer_text', array( $this, 'filter_workspace_admin_footer_text' ), 99 );
        add_filter( 'update_footer', array( $this, 'filter_workspace_update_footer_text' ), 99 );
    }

    /**
     * Resolve the current workspace navigation key.
     *
     * @return string
     */
    private function get_workspace_current_nav_key() {
        if ( isset( $_GET['post_type'] ) && 'pmcpc_sub_update' === sanitize_key( wp_unslash( $_GET['post_type'] ) ) ) {
            return 'pmcpc-publishing-log';
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 'pmcpc_email' === $page ) {
            $tab = isset( $_GET['pmcpc_tab'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_tab'] ) ) : '';
            if ( in_array( $tab, array( 'queue', 'history', 'analytics' ), true ) ) {
                return 'pmcpc_email&pmcpc_tab=' . $tab;
            }
        }

        if ( 'pmcpc_email_template' === $page ) {
            return 'pmcpc_email_templates';
        }

        return $page;
    }

    /**
     * Determine whether Segments should appear as a real workspace destination.
     *
     * @return bool
     */
    private function should_show_segments_nav() {
        if ( function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features() ) {
            return false;
        }

        if ( ! class_exists( 'PMCPC_Automation_Bootstrap' ) ) {
            return false;
        }

        if ( function_exists( 'pmcpc_features' ) ) {
            return (bool) pmcpc_features()->enabled( 'automation' );
        }

        return true;
    }

    /**
     * Build workspace navigation structure.
     *
     * @return array<int,array<string,mixed>>
     */
    private function get_workspace_sidebar_structure() {
        $audience_children = array(
            array(
                'slug'  => 'pmcpc_subscribers',
                'label' => __( 'Subscribers', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-admin-users',
            ),
            array(
                'slug'  => 'pmcpc_forms',
                'label' => __( 'Forms', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-feedback',
            ),
        );

        if ( $this->should_show_segments_nav() ) {
            $audience_children[] = array(
                'slug'  => 'pmcpc_segments',
                'label' => __( 'Segments', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-filter',
            );
        }

        $audience_children[] = array(
            'slug'  => 'pmcpc_inbox',
            'label' => __( 'Inbox', 'product-mailer-campaigns' ),
            'icon'  => 'dashicons-email-alt2',
        );
        $audience_children[] = array(
            'slug'  => 'pmcpc_reviews',
            'label' => __( 'Reviews', 'product-mailer-campaigns' ),
            'icon'  => 'dashicons-star-filled',
        );

        return array(
            array(
                'type'  => 'leaf',
                'slug'  => 'pmcpc_dashboard',
                'label' => __( 'Overview', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-chart-area',
            ),
            array(
                'type'  => 'leaf',
                'slug'  => 'pmcpc_campaigns',
                'label' => __( 'Campaigns', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-megaphone',
            ),
            array(
                'type'  => 'leaf',
                'slug'  => 'pmcpc_automations',
                'label' => __( 'Automations', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-controls-repeat',
            ),
            array(
                'type'     => 'group',
                'key'      => 'audience',
                'label'    => __( 'Audience', 'product-mailer-campaigns' ),
                'icon'     => 'dashicons-groups',
                'children' => $audience_children,
            ),
            array(
                'type'     => 'group',
                'key'      => 'emails',
                'label'    => __( 'Emails', 'product-mailer-campaigns' ),
                'icon'     => 'dashicons-email',
                'children' => array(
                    array(
                        'slug'  => 'pmcpc_email&pmcpc_tab=queue',
                        'label' => __( 'Waiting to Send', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-email-alt',
                    ),
                    array(
                        'slug'  => 'pmcpc_email&pmcpc_tab=history',
                        'label' => __( 'Sent Emails', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-clock',
                    ),
                    array(
                        'slug'  => 'pmcpc_email&pmcpc_tab=analytics',
                        'label' => __( 'Email Results', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-chart-line',
                    ),
                    array(
                        'slug'  => 'pmcpc_email_templates',
                        'label' => __( 'Templates', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-editor-code',
                    ),
                ),
            ),
            array(
                'type'     => 'group',
                'key'      => 'content',
                'label'    => __( 'Content', 'product-mailer-campaigns' ),
                'icon'     => 'dashicons-admin-site-alt3',
                'children' => array(
                    array(
                        'slug'  => 'pmcpc-publishing-log',
                        'label' => __( 'Publishing Log', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-list-view',
                    ),
                    array(
                        'slug'  => 'pmcpc-subscriber-analytics',
                        'label' => __( 'Content Results', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-chart-bar',
                    ),
                    array(
                        'slug'  => 'pmcpc-website-publishing',
                        'label' => __( 'Publishing Settings', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-admin-site-alt3',
                    ),
                ),
            ),
            array(
                'type'     => 'group',
                'key'      => 'settings',
                'label'    => __( 'Settings', 'product-mailer-campaigns' ),
                'icon'     => 'dashicons-admin-settings',
                'children' => array(
                    array(
                        'slug'  => 'pmcpc_settings',
                        'label' => __( 'Settings', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-admin-settings',
                    ),
                    array(
                        'slug'  => 'pmcpc-email-login-settings',
                        'label' => __( 'Email & Login', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-email-alt',
                    ),
                ),
            ),
            array(
                'type'     => 'group',
                'key'      => 'help-status',
                'label'    => __( 'Help & Status', 'product-mailer-campaigns' ),
                'icon'     => 'dashicons-info-outline',
                'children' => array(
                    array(
                        'slug'  => 'pmcpc_diagnostics',
                        'label' => __( 'Health Check', 'product-mailer-campaigns' ),
                        'icon'  => 'dashicons-chart-pie',
                    ),
                ),
            ),
        );
    }

    /**
     * Convert a nav slug into a real admin URL.
     *
     * @param string $slug Nav slug.
     * @return string
     */
    private function get_workspace_nav_href( $slug ) {
        $slug = (string) $slug;
        if ( 0 === strpos( $slug, 'edit.php?' ) || 0 === strpos( $slug, 'post-new.php?' ) || 'index.php' === $slug ) {
            return admin_url( $slug );
        }

        $parts = explode( '&', $slug );
        $page  = array_shift( $parts );
        $args  = array();

        foreach ( $parts as $part ) {
            $pair = explode( '=', $part, 2 );
            if ( 2 === count( $pair ) ) {
                $args[ $pair[0] ] = $pair[1];
            }
        }

        return $this->get_admin_page_url( $page, $args );
    }

    /**
     * Check whether a plugin-owned table exists.
     *
     * @param string $table Fully qualified table name.
     * @return bool
     */
    private function workspace_table_exists( $table ) {
        global $wpdb;

        $table = (string) $table;
        if ( '' === $table ) {
            return false;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
    }

    /**
     * Get actionable badge counts for high-value sidebar destinations.
     *
     * @return array<string,int>
     */
    private function get_workspace_nav_badges() {
        global $wpdb;

        $badges = array();

        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
        if ( $this->workspace_table_exists( $subscribers_table ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $pending_subscribers = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$subscribers_table} WHERE status = %s",
                    'pending'
                )
            );
            if ( $pending_subscribers > 0 ) {
                $badges['pmcpc_subscribers'] = $pending_subscribers;
            }
        }

        if ( class_exists( 'PMCPC_Forms' ) ) {
            $forms = get_option( PMCPC_Forms::OPTION_KEY, array() );
            if ( is_array( $forms ) && ! empty( $forms ) ) {
                $badges['pmcpc_forms'] = count( $forms );
            }
        }

        $spam_table = $wpdb->prefix . 'pmcpc_spam_submissions';
        if ( $this->workspace_table_exists( $spam_table ) ) {
            $user_id   = get_current_user_id();
            $last_seen = (int) get_user_meta( $user_id, 'pmcpc_messages_last_seen_id', true );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $inbox_unread = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$spam_table} WHERE id > %d AND status IN (%s, %s)",
                    $last_seen,
                    'allowed',
                    'held'
                )
            );
            if ( $inbox_unread > 0 ) {
                $badges['pmcpc_inbox'] = $inbox_unread;
            }
        }

        $reviews_table = $wpdb->prefix . 'pmcpc_reviews';
        if ( $this->workspace_table_exists( $reviews_table ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $pending_reviews = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$reviews_table} WHERE status = %s", 'pending' ) );
            if ( $pending_reviews > 0 ) {
                $badges['pmcpc_reviews'] = $pending_reviews;
            }
        }

        $queue_table = $wpdb->prefix . 'pmcpc_email_queue';
        if ( $this->workspace_table_exists( $queue_table ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $queue_work = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$queue_table} WHERE status IN ('pending','processing','failed','paused')"
            );
            if ( $queue_work > 0 ) {
                $badges['pmcpc_email&pmcpc_tab=queue'] = $queue_work;
            }
        }

        if ( post_type_exists( 'pmcpc_sub_update' ) ) {
            $counts = wp_count_posts( 'pmcpc_sub_update' );
            if ( $counts ) {
                $update_count = 0;
                foreach ( array( 'publish', 'draft', 'private' ) as $status ) {
                    $update_count += isset( $counts->{$status} ) ? (int) $counts->{$status} : 0;
                }
                if ( $update_count > 0 ) {
                    $badges['pmcpc-publishing-log'] = $update_count;
                }
            }
        }

        return $badges;
    }

    /**
     * Render the server-side workspace sidebar shell.
     *
     * @return string
     */
    private function render_workspace_sidebar() {
        $current = $this->get_workspace_current_nav_key();
        $groups  = $this->get_workspace_sidebar_structure();
        $badges  = $this->get_workspace_nav_badges();

        ob_start();
        echo '<aside class="pmcpc-workspace-nav">';
        echo '<div class="pmcpc-workspace-nav__header">';
        echo '<div class="pmcpc-workspace-nav__eyebrow"><span class="dashicons dashicons-controls-repeat" aria-hidden="true"></span><span>' . esc_html__( 'Workspace', 'product-mailer-campaigns' ) . '</span></div>';
        echo '<div class="pmcpc-workspace-nav__title">' . esc_html( PMCPC_Admin::app_brand() ) . '</div>';
        echo '<p class="pmcpc-workspace-nav__subtitle">' . esc_html( PMCPC_Admin::app_tagline() ) . '</p>';
        echo '</div>';

        echo '<div class="pmcpc-workspace-nav__tree">';
        foreach ( $groups as $item ) {
            if ( 'leaf' === $item['type'] ) {
                $is_current = $current === $item['slug'];
                $badge = isset( $badges[ $item['slug'] ] ) ? (int) $badges[ $item['slug'] ] : 0;
                echo '<div><a href="' . esc_url( $this->get_workspace_nav_href( $item['slug'] ) ) . '"' . ( $is_current ? ' class="is-current"' : '' ) . '><span class="pmcpc-workspace-nav__link-main"><span class="dashicons ' . esc_attr( $item['icon'] ) . '" aria-hidden="true"></span><span>' . esc_html( $item['label'] ) . '</span></span>';
                if ( $badge > 0 ) {
                    echo '<span class="pmcpc-workspace-nav__badge" aria-label="' . esc_attr( sprintf( __( '%d items', 'product-mailer-campaigns' ), $badge ) ) . '">' . esc_html( number_format_i18n( $badge ) ) . '</span>';
                }
                echo '</a></div>';
                continue;
            }

            $has_current = false;
            foreach ( $item['children'] as $child ) {
                if ( $current === $child['slug'] ) {
                    $has_current = true;
                    break;
                }
            }

            echo '<details class="pmcpc-workspace-nav__group" data-key="' . esc_attr( $item['key'] ) . '"' . ( $has_current ? ' open' : '' ) . '>';
            echo '<summary><span class="pmcpc-workspace-nav__summary-left"><span class="dashicons ' . esc_attr( $item['icon'] ) . '" aria-hidden="true"></span><span>' . esc_html( $item['label'] ) . '</span></span><span class="pmcpc-workspace-nav__caret" aria-hidden="true">▸</span></summary>';
            echo '<ul>';
            foreach ( $item['children'] as $child ) {
                $is_current = $current === $child['slug'];
                $badge = isset( $badges[ $child['slug'] ] ) ? (int) $badges[ $child['slug'] ] : 0;
                echo '<li><a href="' . esc_url( $this->get_workspace_nav_href( $child['slug'] ) ) . '"' . ( $is_current ? ' class="is-current"' : '' ) . '><span class="pmcpc-workspace-nav__link-main"><span class="dashicons ' . esc_attr( $child['icon'] ) . '" aria-hidden="true"></span><span>' . esc_html( $child['label'] ) . '</span></span>';
                if ( $badge > 0 ) {
                    echo '<span class="pmcpc-workspace-nav__badge" aria-label="' . esc_attr( sprintf( __( '%d items', 'product-mailer-campaigns' ), $badge ) ) . '">' . esc_html( number_format_i18n( $badge ) ) . '</span>';
                }
                echo '</a></li>';
            }
            echo '</ul></details>';
        }
        echo '</div>';

        echo '<div class="pmcpc-workspace-nav__footer"><a href="' . esc_url( admin_url() ) . '"><span class="dashicons dashicons-wordpress" aria-hidden="true"></span><span>' . esc_html__( 'Back to WordPress', 'product-mailer-campaigns' ) . '</span></a></div>';
        echo '</aside>';

        return (string) ob_get_clean();
    }

    /**
     * Generic server-rendered wrapper for workspace admin pages.
     *
     * @return void
     */
    public function render_registered_workspace_page() {
        $slug = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( '' === $slug || empty( $this->workspace_page_callbacks[ $slug ] ) ) {
            return;
        }

        $callback = $this->workspace_page_callbacks[ $slug ];

        ob_start();
        call_user_func( $callback );
        $content = (string) ob_get_clean();

        echo '<div class="pmcpc-workspace-shell" data-pmcpc-server="1">';
        echo $this->render_workspace_sidebar();
        echo '<div class="pmcpc-workspace-main">' . $content . '</div>';
        echo '</div>';
    }

    /**
     * Register the hidden Email Preview admin page.
     *
     * Uses a real parent slug for WordPress compatibility, then removes the
     * submenu item so the route stays available without appearing in the menu.
     *
     * @return void
     */
    public function register_email_preview_page() {
        add_submenu_page(
            'pmcpc_email',
            esc_html__( 'Email Preview', 'product-mailer-campaigns' ),
            '',
            'manage_options',
            'pmcpc_view_email',
            array( 'PMCPC_Admin', 'render_email_preview' )
        );

        remove_submenu_page( 'pmcpc_email', 'pmcpc_view_email' );
    }


    /**
     * Hide the native WordPress admin sidebar on workspace pages so the plugin shell
     * becomes the single navigation experience.
     */
    public function hide_wordpress_admin_sidebar_on_workspace_pages() {
        if ( ! current_user_can( 'manage_options' ) || ! $this->is_workspace_screen() ) {
            return;
        }

        echo <<<'CSS'
<style id="pmcpc-hide-wp-admin-sidebar">
#adminmenu,
#adminmenuback,
#adminmenuwrap,
#collapse-menu,
#toplevel_page_pmcpc_dashboard {
    display:none !important;
}
#wpcontent,
#wpfooter,
.auto-fold #wpcontent,
.auto-fold #wpfooter,
.folded #wpcontent,
.folded #wpfooter {
    margin-left:0 !important;
}
#wpfooter,
#footer-left,
#footer-upgrade,
#footer-thankyou {
    display:none !important;
    visibility:hidden !important;
    height:0 !important;
    min-height:0 !important;
    overflow:hidden !important;
}
html.wp-toolbar {
    padding-left:0 !important;
}
#wpbody-content {
    padding-bottom:24px;
}
@media screen and (max-width: 782px) {
    #wpcontent,
    #wpfooter {
        margin-left:0 !important;
    }
}
</style>
CSS;
    }

    /**
     * Output CSS and lightweight state JS for the server-rendered workspace shell.
     *
     * @return void
     */
    public function output_workspace_shell_assets() {
        if ( ! current_user_can( 'manage_options' ) || ! $this->is_workspace_screen() ) {
            return;
        }

        echo <<<'CSS'
<style id="pmcpc-workspace-shell-css">
.pmcpc-workspace-anchor{height:0;overflow:hidden;}
.pmcpc-global-header{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin:8px 0 14px;padding-bottom:14px;border-bottom:1px solid #dcdcde;}
.pmcpc-global-header__eyebrow{display:flex;align-items:center;gap:8px;margin:0 0 4px;font-size:12px;font-weight:600;letter-spacing:.02em;text-transform:uppercase;color:#2271b1;}
.pmcpc-global-header__title{margin:0;font-size:28px;line-height:1.15;font-weight:600;color:#1d2327;}
.pmcpc-global-header__tagline{margin:6px 0 0;color:#50575e;font-size:13px;}
.pmcpc-global-header__main{flex:1 1 320px;}
.pmcpc-global-header__actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center;justify-content:flex-end;flex:0 0 auto;}
.pmcpc-global-header__link{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border:1px solid #dcdcde;border-radius:999px;background:#fff;color:#1d2327;text-decoration:none;font-size:12px;font-weight:500;line-height:1.2;}
.pmcpc-global-header__link:hover{background:#f6f7f7;color:#135e96;}
.pmcpc-workspace-shell{display:grid;grid-template-columns:260px minmax(0,1fr);gap:24px;align-items:start;margin-top:20px;max-width:100%;min-width:0;box-sizing:border-box;}
.pmcpc-workspace-shell > *{min-width:0;max-width:100%;box-sizing:border-box;}
.pmcpc-workspace-nav{position:sticky;top:46px;background:#fff;border:1px solid #dcdcde;border-radius:14px;box-shadow:0 1px 1px rgba(0,0,0,.03);overflow:hidden;}
.pmcpc-workspace-nav__header{padding:16px 18px;border-bottom:1px solid #e2e4e7;background:linear-gradient(180deg,#f8fafc 0%,#fff 100%);}
.pmcpc-workspace-nav__eyebrow{display:flex;align-items:center;gap:8px;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#2271b1;margin-bottom:6px;}
.pmcpc-workspace-nav__title{font-size:16px;font-weight:700;color:#1d2327;margin:0 0 4px;}
.pmcpc-workspace-nav__subtitle{margin:0;color:#646970;font-size:12px;line-height:1.45;}
.pmcpc-workspace-nav__quick{display:flex;flex-wrap:wrap;gap:8px;padding:14px 16px;border-bottom:1px solid #f0f0f1;}
.pmcpc-workspace-nav__quick a{font-size:12px;text-decoration:none;padding:6px 10px;border:1px solid #dcdcde;border-radius:999px;background:#f6f7f7;color:#1d2327;}
.pmcpc-workspace-nav__tree{padding:8px 10px 8px;}
.pmcpc-workspace-nav__footer{padding:10px 14px 14px;border-top:1px solid #f0f0f1;margin-top:4px;}
.pmcpc-workspace-nav__footer a{display:flex;align-items:center;gap:8px;padding:10px 10px;border:1px solid #dcdcde;border-radius:10px;background:#fff;color:#1d2327;text-decoration:none;font-weight:600;}
.pmcpc-workspace-nav__footer a:hover{background:#f6f7f7;color:#135e96;}
.pmcpc-workspace-nav details{border-top:1px solid #f0f0f1;padding-top:8px;margin-top:8px;}
.pmcpc-workspace-nav details:first-of-type{border-top:0;padding-top:0;margin-top:0;}
.pmcpc-workspace-nav summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between;padding:9px 8px;border-radius:10px;font-weight:600;color:#1d2327;}
.pmcpc-workspace-nav summary::-webkit-details-marker{display:none;}
.pmcpc-workspace-nav summary:hover{background:#f6f7f7;}
.pmcpc-workspace-nav__summary-left{display:flex;align-items:center;gap:8px;}
.pmcpc-workspace-nav__caret{transition:transform .16s ease;font-size:12px;color:#646970;}
.pmcpc-workspace-nav details[open] > summary .pmcpc-workspace-nav__caret{transform:rotate(90deg);}
.pmcpc-workspace-nav ul{margin:6px 0 0 0;padding:0 0 0 28px;}
.pmcpc-workspace-nav li{margin:0;list-style:none;position:relative;}
.pmcpc-workspace-nav li::before{content:'';position:absolute;left:-12px;top:0;bottom:0;width:1px;background:#e2e4e7;}
.pmcpc-workspace-nav li:last-child::before{bottom:50%;}
.pmcpc-workspace-nav li a{position:relative;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 8px 8px 0;color:#2c3338;text-decoration:none;border-radius:8px;}
.pmcpc-workspace-nav__link-main{display:flex;align-items:center;gap:8px;min-width:0;}
.pmcpc-workspace-nav__badge{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:999px;background:#edf4ff;color:#135e96;font-size:11px;font-weight:700;line-height:1;flex:0 0 auto;border:1px solid #c5d9f4;}
.pmcpc-workspace-nav li a::before{content:'';position:absolute;left:-12px;top:50%;width:12px;height:1px;background:#e2e4e7;}
.pmcpc-workspace-nav a:hover{color:#135e96;}
.pmcpc-workspace-nav a.is-current{font-weight:700;color:#135e96;background:#f0f6fc;padding-left:8px;}
.pmcpc-workspace-nav a.is-current::after{content:'';position:absolute;left:-20px;top:8px;bottom:8px;width:3px;border-radius:999px;background:#2271b1;}
.pmcpc-workspace-main{min-width:0;max-width:100%;width:100%;box-sizing:border-box;overflow-x:hidden;}
.pmcpc-workspace-main > .wrap{width:100%;max-width:100%;margin:0;box-sizing:border-box;}
.pmcpc-workspace-main > .wrap > *{max-width:100%;box-sizing:border-box;}
@media (max-width: 1180px){
  .pmcpc-workspace-shell{grid-template-columns:1fr;}
  .pmcpc-workspace-nav{position:relative;top:auto;}
}
</style>
CSS;

        echo <<<'JS'
<script id="pmcpc-workspace-shell-js">
(function(){
  function init(){
    var groups=document.querySelectorAll('.pmcpc-workspace-nav details[data-key]');
    if(!groups.length){ return; }
    groups.forEach(function(details){
      var key=details.getAttribute('data-key');
      if(!key){ return; }
      var hasCurrent=details.querySelector('a.is-current') !== null;
      try{
        var stored=window.localStorage.getItem('pmcpc_workspace_group_'+key) || '';
        if(stored==='open'){ details.open=true; }
        if(stored==='closed' && !hasCurrent){ details.open=false; }
      }catch(err){}
      details.addEventListener('toggle',function(){
        try{ window.localStorage.setItem('pmcpc_workspace_group_'+key, details.open ? 'open' : 'closed'); }catch(err){}
      });
    });
  }
  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();
</script>
JS;
    }

    /**
     * Output lightweight bridge styles for native Subscriber Updates CPT screens.
     *
     * @return void
     */
    public function output_subscriber_updates_bridge_assets() {
        if ( ! current_user_can( 'manage_options' ) || ! $this->is_subscriber_updates_native_screen() ) {
            return;
        }

        ?>
<style id="pmcpc-sub-updates-bridge-css">
.pmcpc-sub-updates-bridge{
    margin:16px 0 18px;
    padding:18px 20px;
    border:1px solid #dcdcde;
    border-radius:14px;
    background:#fff;
    box-shadow:0 12px 28px rgba(0,0,0,.04);
}
.pmcpc-sub-updates-bridge__eyebrow{
    display:flex;
    align-items:center;
    gap:8px;
    margin:0 0 8px;
    color:#135e96;
    font-size:11px;
    font-weight:700;
    letter-spacing:.08em;
    text-transform:uppercase;
}
.pmcpc-sub-updates-bridge__top{
    display:flex;
    justify-content:space-between;
    gap:16px;
    align-items:flex-start;
    flex-wrap:wrap;
}
.pmcpc-sub-updates-bridge__title{
    margin:0 0 6px;
    font-size:30px;
    line-height:1.15;
    font-weight:700;
    color:#1d2327;
}
.pmcpc-sub-updates-bridge__subtitle{
    margin:0;
    max-width:760px;
    color:#50575e;
    font-size:14px;
    line-height:1.5;
}
.pmcpc-sub-updates-bridge__actions{
    display:flex;
    flex-wrap:wrap;
    gap:10px;
}
.pmcpc-sub-updates-bridge__actions a{
    display:inline-flex;
    align-items:center;
    gap:6px;
    padding:8px 12px;
    border:1px solid #c3c4c7;
    border-radius:999px;
    background:#fff;
    color:#135e96;
    text-decoration:none;
    font-size:13px;
    font-weight:600;
}
.pmcpc-sub-updates-bridge__actions a.button-primary{
    border-color:#2271b1;
    background:#2271b1;
    color:#fff;
}
.pmcpc-sub-updates-bridge .pmcpc-page-stats{
    margin-top:16px;
}
.pmcpc-sub-updates-bridge .pmcpc-page-support-grid{
    margin-top:16px;
}
.pmcpc-sub-updates-bridge__links{
    display:flex;
    flex-wrap:wrap;
    gap:10px;
    margin-top:14px;
}
.pmcpc-sub-updates-bridge__links a{
    display:inline-flex;
    align-items:center;
    gap:6px;
    padding:6px 10px;
    border:1px solid #dcdcde;
    border-radius:999px;
    background:#f6f7f7;
    color:#3858e9;
    text-decoration:none;
    font-size:12px;
}
body.post-type-pmcpc_sub_update .wrap > h1.wp-heading-inline,
body.post-type-pmcpc_sub_update .wrap > .page-title-action{
    display:none;
}
body.post-type-pmcpc_sub_update .wrap > .subsubsub{
    margin-top:0;
}
@media (max-width: 782px){
    .pmcpc-sub-updates-bridge{
        padding:16px;
        border-radius:12px;
    }
    .pmcpc-sub-updates-bridge__title{
        font-size:24px;
    }
}
</style>
        <?php
    }

    /**
     * Render a compact workspace bridge header for native Subscriber Updates screens.
     *
     * @return void
     */
    public function render_subscriber_updates_bridge_header() {
        if ( ! current_user_can( 'manage_options' ) || ! $this->is_subscriber_updates_native_screen() ) {
            return;
        }

        $screen  = get_current_screen();
        $is_list = $screen && 'edit' === $screen->base;
        $is_new  = $screen && 'post-new' === $screen->base;

        $title = __( 'Subscriber Updates', 'product-mailer-campaigns' );
        if ( $is_new ) {
            $title = __( 'Create Subscriber Update', 'product-mailer-campaigns' );
        } elseif ( ! $is_list ) {
            $title = __( 'Edit Subscriber Update', 'product-mailer-campaigns' );
        }

        $settings         = class_exists( 'PMCPC_Subscriber_Updates_Settings' ) ? get_option( PMCPC_Subscriber_Updates_Settings::OPTION_KEY, array() ) : array();
        $settings         = is_array( $settings ) ? $settings : array();
        $legacy_page_id   = class_exists( 'PMCPC_Subscriber_Updates_Settings' ) ? absint( get_option( PMCPC_Subscriber_Updates_Settings::PAGE_OPTION_KEY, 0 ) ) : 0;
        $updates_page_id  = ! empty( $settings['page_id'] ) ? absint( $settings['page_id'] ) : $legacy_page_id;
        $updates_page_url  = $updates_page_id ? get_permalink( $updates_page_id ) : '';
        $updates_page_name = $updates_page_id ? get_the_title( $updates_page_id ) : __( 'Not set', 'product-mailer-campaigns' );
        $post_counts       = wp_count_posts( 'pmcpc_sub_update' );
        $published_count   = $post_counts && isset( $post_counts->publish ) ? (int) $post_counts->publish : 0;
        $draft_count       = $post_counts && isset( $post_counts->draft ) ? (int) $post_counts->draft : 0;
        $last_update       = get_posts(
            array(
                'post_type'      => 'pmcpc_sub_update',
                'post_status'    => array( 'publish', 'draft', 'private' ),
                'posts_per_page' => 1,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'fields'         => 'ids',
            )
        );
        $last_update_label = __( 'No updates yet', 'product-mailer-campaigns' );
        if ( ! empty( $last_update ) ) {
            $last_update_label = get_the_date( get_option( 'date_format' ), (int) $last_update[0] );
        }

        ?>
<div class="pmcpc-sub-updates-bridge">
    <div class="pmcpc-sub-updates-bridge__eyebrow">
        <span class="dashicons dashicons-controls-repeat" aria-hidden="true"></span>
        <span><?php echo esc_html( PMCPC_Admin::app_brand() ); ?></span>
    </div>
    <div class="pmcpc-sub-updates-bridge__top">
        <div class="pmcpc-sub-updates-bridge__copy">
            <h1 class="pmcpc-sub-updates-bridge__title"><?php echo esc_html( $title ); ?></h1>
            <p class="pmcpc-sub-updates-bridge__subtitle"><?php echo esc_html__( 'Create and manage website updates here, then use Content Results and Publishing Settings to review reach, topics, and publishing behaviour.', 'product-mailer-campaigns' ); ?></p>
        </div>
        <div class="pmcpc-sub-updates-bridge__actions">
            <a class="button-primary" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=pmcpc_sub_update' ) ); ?>">
                <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
                <span><?php echo esc_html__( 'Add Update', 'product-mailer-campaigns' ); ?></span>
            </a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=pmcpc-publishing-log' ) ); ?>">
                <span class="dashicons dashicons-list-view" aria-hidden="true"></span>
                <span><?php echo esc_html__( 'Publishing Log', 'product-mailer-campaigns' ); ?></span>
            </a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=pmcpc-subscriber-analytics' ) ); ?>">
                <span class="dashicons dashicons-chart-line" aria-hidden="true"></span>
                <span><?php echo esc_html__( 'Content Results', 'product-mailer-campaigns' ); ?></span>
            </a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=pmcpc-website-publishing' ) ); ?>">
                <span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
                <span><?php echo esc_html__( 'Publishing Settings', 'product-mailer-campaigns' ); ?></span>
            </a>
            <?php if ( $updates_page_url ) : ?>
            <a href="<?php echo esc_url( $updates_page_url ); ?>" target="_blank" rel="noopener noreferrer">
                <span class="dashicons dashicons-external" aria-hidden="true"></span>
                <span><?php echo esc_html__( 'View live page', 'product-mailer-campaigns' ); ?></span>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php
    PMCPC_Admin::render_support_panels(
        array(
            array(
                'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                'title'   => __( 'Create and review website updates', 'product-mailer-campaigns' ),
                'text'    => __( 'Use this page to add or edit update posts. Then check Publishing Settings, Publishing Log, and Content Results to confirm the feed is working.', 'product-mailer-campaigns' ),
                'items'   => array(
                    __( 'Add or edit the update content.', 'product-mailer-campaigns' ),
                    __( 'Check the live page after publishing.', 'product-mailer-campaigns' ),
                    __( 'Use Publishing Log if an automatic update does not appear.', 'product-mailer-campaigns' ),
                ),
            ),
            array(
                'eyebrow' => __( 'Test and check', 'product-mailer-campaigns' ),
                'title'   => __( 'Keep updates easy to trust', 'product-mailer-campaigns' ),
                'text'    => __( 'The quickest checks are the live updates page, the publishing log, and the health check if anything looks late or missing.', 'product-mailer-campaigns' ),
                'actions' => array_filter(
                    array(
                        array( 'label' => __( 'Open Health Check', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc_diagnostics' ), 'class' => 'button button-primary' ),
                        array( 'label' => __( 'Open Publishing Log', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc-publishing-log' ), 'class' => 'button' ),
                        $updates_page_url ? array( 'label' => __( 'View live page', 'product-mailer-campaigns' ), 'url' => $updates_page_url, 'class' => 'button' ) : null,
                    )
                ),
            ),
        )
    );
    PMCPC_Admin::render_stats_strip(
        array(
            array(
                'label' => __( 'Live page', 'product-mailer-campaigns' ),
                'value' => $updates_page_name,
                'meta'  => $updates_page_id ? __( 'Feed destination', 'product-mailer-campaigns' ) : __( 'Choose a page in Publishing Settings', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Published updates', 'product-mailer-campaigns' ),
                'value' => (string) $published_count,
                'meta'  => __( 'Visible website updates', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Draft updates', 'product-mailer-campaigns' ),
                'value' => (string) $draft_count,
                'meta'  => __( 'Not live yet', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Last update', 'product-mailer-campaigns' ),
                'value' => $last_update_label,
                'meta'  => __( 'Most recent update date', 'product-mailer-campaigns' ),
            ),
        )
    );
    if ( function_exists( 'pmcpc_get_subscriber_updates_health_report' ) && function_exists( 'pmcpc_render_subscriber_updates_health_notice' ) ) {
        $health_report = pmcpc_get_subscriber_updates_health_report( $settings );
        if ( ! empty( $health_report['status'] ) && 'good' !== $health_report['status'] ) {
            pmcpc_render_subscriber_updates_health_notice( $settings, true );
        }
    }

    ?>
</div>
        <?php
    }

    /**
     * Hide workspace pages from the left menu while keeping them routable.
     *
     * WordPress core validates access to admin.php?page=... against the registered
     * admin menu. So we hide via CSS instead of remove_submenu_page().
     */
    public function hide_workspace_pages_from_menu_css() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $workspace_screen = $this->is_workspace_screen();

        // On workspace screens the native WordPress admin menu is fully hidden,
        // so rebuilding a custom tree inside that hidden menu adds extra DOM work
        // without any user-facing benefit. Keep this part for non-workspace
        // contexts only, while workspace pages use the server-rendered shell.
        if ( $workspace_screen ) {
            return;
        }

        $css = <<<'CSS'
<style id="pmcpc-hide-submenu-items">
#toplevel_page_pmcpc_dashboard .wp-submenu .dashicons{font-size:16px;line-height:1.25;vertical-align:middle;margin-right:6px;}
#toplevel_page_pmcpc_dashboard .wp-submenu .pmcpc-menu-text{vertical-align:middle;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul > li{display:none!important;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul > li.pmcpc-tree-node{display:list-item!important;margin:0!important;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul > li[data-pmcpc-native-hidden="1"]{display:none!important;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-root > a{padding-left:10px;display:flex;align-items:center;gap:6px;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-root.current > a{background:rgba(255,255,255,.08);}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-group{margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,.08);}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-group > button{width:100%;background:none;border:0;color:#a7b2bd;padding:9px 10px;cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-group > button:hover{color:#fff;background:rgba(255,255,255,.04);}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-group > button .pmcpc-tree-title{display:flex;align-items:center;gap:8px;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-group > button .pmcpc-tree-caret{font-size:12px;transition:transform .15s ease;opacity:.9;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-group.is-collapsed > button .pmcpc-tree-caret{transform:rotate(-90deg);}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-group ul{margin:4px 0 0 0;padding:0;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-group.is-collapsed ul{display:none;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-child{position:relative;list-style:none;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-child::before{content:'';position:absolute;left:14px;top:0;bottom:0;width:1px;background:rgba(255,255,255,.08);}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-child > a{padding:7px 10px 7px 30px;position:relative;display:flex;align-items:center;gap:6px;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-child > a::before{content:'';position:absolute;left:14px;top:50%;width:10px;height:1px;background:rgba(255,255,255,.16);}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-child--last::before{bottom:50%;}
#toplevel_page_pmcpc_dashboard .wp-submenu ul li.pmcpc-tree-child.current > a{background:rgba(255,255,255,.08);}
</style>
CSS;

        $js = <<<'JS'
<script id="pmcpc-tree-submenu">
(function(){
  function currentSlug(){
    try {
      var url = new URL(window.location.href);
      if (url.pathname.indexOf('/edit.php') !== -1 && url.searchParams.get('post_type') === 'pmcpc_sub_update') {
        return 'pmcpc-publishing-log';
      }
      var page=url.searchParams.get('page') || '';
      if(page==='pmcpc_email_template'){
        return 'pmcpc_email_templates';
      }
      if(page==='pmcpc_email'){
        var tab=url.searchParams.get('pmcpc_tab') || '';
        if(tab==='queue' || tab==='history' || tab==='analytics'){ return page + '&pmcpc_tab=' + tab; }
      }
      return page;
    } catch(err) {
      return '';
    }
  }
  function adminHref(slug){
    return 'admin.php?page=' + slug;
  }
  function init(){
    var menu=document.getElementById('toplevel_page_pmcpc_dashboard');
    if(!menu){return;}
    var submenu=menu.querySelector('.wp-submenu ul');
    if(!submenu || submenu.dataset.pmcpcTreeInit==='1'){return;}
    submenu.dataset.pmcpcTreeInit='1';

    var slug=currentSlug();
    var roots=[
      {type:'leaf', slug:'pmcpc_dashboard', label:'Overview', icon:'dashicons-chart-area'},
      {type:'leaf', slug:'pmcpc_campaigns', label:'Campaigns', icon:'dashicons-megaphone'},
      {type:'leaf', slug:'pmcpc_automations', label:'Automations', icon:'dashicons-controls-repeat'},
      {type:'group', key:'audience', label:'Audience', icon:'dashicons-groups', children:[
        {slug:'pmcpc_subscribers', label:'Subscribers', icon:'dashicons-admin-users'},
        {slug:'pmcpc_forms', label:'Forms', icon:'dashicons-feedback'},
        {slug:'pmcpc_inbox', label:'Inbox', icon:'dashicons-email-alt2'},
        {slug:'pmcpc_reviews', label:'Reviews', icon:'dashicons-star-filled'}
      ]},
      {type:'group', key:'emails', label:'Emails', icon:'dashicons-email', children:[
        {slug:'pmcpc_email&pmcpc_tab=queue', label:'Waiting to Send', icon:'dashicons-email-alt'},
        {slug:'pmcpc_email&pmcpc_tab=history', label:'Sent Emails', icon:'dashicons-clock'},
        {slug:'pmcpc_email&pmcpc_tab=analytics', label:'Email Results', icon:'dashicons-chart-line'},
        {slug:'pmcpc_email_templates', label:'Templates', icon:'dashicons-editor-code'}
      ]},
      {type:'group', key:'content', label:'Content', icon:'dashicons-admin-site-alt3', children:[
        {slug:'pmcpc-publishing-log', label:'Publishing Log', icon:'dashicons-list-view'},
        {slug:'pmcpc-subscriber-analytics', label:'Content Results', icon:'dashicons-chart-bar'},
        {slug:'pmcpc-website-publishing', label:'Publishing Settings', icon:'dashicons-admin-site-alt3'}
      ]},
      {type:'group', key:'settings', label:'Settings', icon:'dashicons-admin-settings', children:[
        {slug:'pmcpc_settings', label:'Settings', icon:'dashicons-admin-settings'},
        {slug:'pmcpc-email-login-settings', label:'Email & Login', icon:'dashicons-email-alt'}
      ]},
      {type:'group', key:'help-status', label:'Help & Status', icon:'dashicons-info-outline', children:[
        {slug:'pmcpc_diagnostics', label:'Health Check', icon:'dashicons-chart-pie'},
      ]}
    ];

    function makeAnchor(item, isCurrent){
      var a=document.createElement('a');
      a.href=adminHref(item.slug);
      if(item.slug.indexOf('edit.php?')===0){ a.href=item.slug; }
      a.innerHTML='<span class="dashicons '+item.icon+'" aria-hidden="true"></span><span class="pmcpc-menu-text">'+item.label+'</span>';
      if(isCurrent){ a.className='current'; }
      return a;
    }

    function hideNativeItems(){
      submenu.querySelectorAll(':scope > li').forEach(function(node){
        if(!node.classList.contains('pmcpc-tree-node')){
          node.style.setProperty('display','none','important');
          node.setAttribute('data-pmcpc-native-hidden','1');
        }
      });
    }

    // Hide native submenu items from the DOM so the custom tree is the only visible navigation.
    hideNativeItems();
    // Remove any previous custom nodes in case of rerender.
    submenu.querySelectorAll('li.pmcpc-tree-node').forEach(function(node){ node.remove(); });

    roots.forEach(function(item){
      if(item.type==='leaf'){
        var current = slug === item.slug;
        var li=document.createElement('li');
        li.className='pmcpc-tree-node pmcpc-tree-root' + (current ? ' current' : '');
        li.appendChild(makeAnchor(item, current));
        submenu.appendChild(li);
        return;
      }
      var groupLi=document.createElement('li');
      groupLi.className='pmcpc-tree-node pmcpc-tree-group';
      var btn=document.createElement('button');
      btn.type='button';
      btn.innerHTML='<span class="pmcpc-tree-title"><span class="dashicons '+item.icon+'" aria-hidden="true"></span><span class="pmcpc-menu-text">'+item.label+'</span></span><span class="pmcpc-tree-caret" aria-hidden="true">▾</span>';
      groupLi.appendChild(btn);
      var ul=document.createElement('ul');
      var hasCurrent=false;
      item.children.forEach(function(child, idx){
        var current = slug === child.slug;
        hasCurrent = hasCurrent || current;
        var cli=document.createElement('li');
        cli.className='pmcpc-tree-child' + (current ? ' current' : '');
        if(idx === item.children.length - 1){ cli.classList.add('pmcpc-tree-child--last'); }
        cli.appendChild(makeAnchor(child, current));
        ul.appendChild(cli);
      });
      groupLi.appendChild(ul);
      submenu.appendChild(groupLi);
      var storageKey='pmcpc_menu_tree_'+item.key;
      var open=hasCurrent;
      try{
        var saved=window.localStorage.getItem(storageKey);
        if(saved==='open'){ open=true; }
        if(saved==='closed' && !hasCurrent){ open=false; }
      }catch(err){}
      groupLi.classList.toggle('is-collapsed', !open);
      btn.addEventListener('click', function(){
        var collapsed=groupLi.classList.toggle('is-collapsed');
        try{ window.localStorage.setItem(storageKey, collapsed ? 'closed' : 'open'); }catch(err){}
      });
    });

    // Some plugin modules append submenu items after DOMContentLoaded. Keep them hidden.
    try {
      var observer = new MutationObserver(function(){ hideNativeItems(); });
      observer.observe(submenu, {childList:true});
    } catch(err) {}
  }
  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',init);}else{init();}
})();
</script>
JS;

        $workspace_css = <<<'CSS'
<style id="pmcpc-workspace-shell-css">
.pmcpc-workspace-anchor{height:0;overflow:hidden;}
.pmcpc-global-header{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin:8px 0 14px;padding-bottom:14px;border-bottom:1px solid #dcdcde;}
.pmcpc-global-header__eyebrow{display:flex;align-items:center;gap:8px;margin:0 0 4px;font-size:12px;font-weight:600;letter-spacing:.02em;text-transform:uppercase;color:#2271b1;}
.pmcpc-global-header__title{margin:0;font-size:28px;line-height:1.15;font-weight:600;color:#1d2327;}
.pmcpc-global-header__tagline{margin:6px 0 0;color:#50575e;font-size:13px;}
.pmcpc-global-header__main{flex:1 1 320px;}
.pmcpc-global-header__actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center;justify-content:flex-end;flex:0 0 auto;}
.pmcpc-global-header__link{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border:1px solid #dcdcde;border-radius:999px;background:#fff;color:#1d2327;text-decoration:none;font-size:12px;font-weight:500;line-height:1.2;}
.pmcpc-global-header__link:hover{background:#f6f7f7;color:#135e96;}
.pmcpc-workspace-shell{display:grid;grid-template-columns:260px minmax(0,1fr);gap:24px;align-items:start;margin-top:20px;max-width:100%;min-width:0;box-sizing:border-box;}
.pmcpc-workspace-shell > *{min-width:0;max-width:100%;box-sizing:border-box;}
.pmcpc-workspace-nav{position:sticky;top:46px;background:#fff;border:1px solid #dcdcde;border-radius:14px;box-shadow:0 1px 1px rgba(0,0,0,.03);overflow:hidden;}
.pmcpc-workspace-nav__header{padding:16px 18px;border-bottom:1px solid #e2e4e7;background:linear-gradient(180deg,#f8fafc 0%,#fff 100%);}
.pmcpc-workspace-nav__eyebrow{display:flex;align-items:center;gap:8px;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#2271b1;margin-bottom:6px;}
.pmcpc-workspace-nav__title{font-size:16px;font-weight:700;color:#1d2327;margin:0 0 4px;}
.pmcpc-workspace-nav__subtitle{margin:0;color:#646970;font-size:12px;line-height:1.45;}
.pmcpc-workspace-nav__quick{display:flex;flex-wrap:wrap;gap:8px;padding:14px 16px;border-bottom:1px solid #f0f0f1;}
.pmcpc-workspace-nav__quick a{font-size:12px;text-decoration:none;padding:6px 10px;border:1px solid #dcdcde;border-radius:999px;background:#f6f7f7;color:#1d2327;}
.pmcpc-workspace-nav__tree{padding:8px 10px 8px;}
.pmcpc-workspace-nav__footer{padding:10px 14px 14px;border-top:1px solid #f0f0f1;margin-top:4px;}
.pmcpc-workspace-nav__footer a{display:flex;align-items:center;gap:8px;padding:10px 10px;border:1px solid #dcdcde;border-radius:10px;background:#fff;color:#1d2327;text-decoration:none;font-weight:600;}
.pmcpc-workspace-nav__footer a:hover{background:#f6f7f7;color:#135e96;}
.pmcpc-workspace-nav details{border-top:1px solid #f0f0f1;padding-top:8px;margin-top:8px;}
.pmcpc-workspace-nav details:first-of-type{border-top:0;padding-top:0;margin-top:0;}
.pmcpc-workspace-nav summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between;padding:9px 8px;border-radius:10px;font-weight:600;color:#1d2327;}
.pmcpc-workspace-nav summary::-webkit-details-marker{display:none;}
.pmcpc-workspace-nav summary:hover{background:#f6f7f7;}
.pmcpc-workspace-nav__summary-left{display:flex;align-items:center;gap:8px;}
.pmcpc-workspace-nav__caret{transition:transform .16s ease;font-size:12px;color:#646970;}
.pmcpc-workspace-nav details[open] > summary .pmcpc-workspace-nav__caret{transform:rotate(90deg);}
.pmcpc-workspace-nav ul{margin:6px 0 0 0;padding:0 0 0 28px;}
.pmcpc-workspace-nav li{margin:0;list-style:none;position:relative;}
.pmcpc-workspace-nav li::before{content:'';position:absolute;left:-12px;top:0;bottom:0;width:1px;background:#e2e4e7;}
.pmcpc-workspace-nav li:last-child::before{bottom:50%;}
.pmcpc-workspace-nav li a{position:relative;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 8px 8px 0;color:#2c3338;text-decoration:none;border-radius:8px;}
.pmcpc-workspace-nav__link-main{display:flex;align-items:center;gap:8px;min-width:0;}
.pmcpc-workspace-nav__badge{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:999px;background:#edf4ff;color:#135e96;font-size:11px;font-weight:700;line-height:1;flex:0 0 auto;border:1px solid #c5d9f4;}
.pmcpc-workspace-nav li a::before{content:'';position:absolute;left:-12px;top:50%;width:12px;height:1px;background:#e2e4e7;}
.pmcpc-workspace-nav a:hover{color:#135e96;}
.pmcpc-workspace-nav a.is-current{font-weight:700;color:#135e96;background:#f0f6fc;padding-left:8px;}
.pmcpc-workspace-nav a.is-current::after{content:'';position:absolute;left:-20px;top:8px;bottom:8px;width:3px;border-radius:999px;background:#2271b1;}
.pmcpc-workspace-main{min-width:0;max-width:100%;width:100%;box-sizing:border-box;overflow-x:hidden;}
.pmcpc-workspace-main > .wrap{width:100%;max-width:100%;margin:0;box-sizing:border-box;}
.pmcpc-workspace-main > .wrap > *{max-width:100%;box-sizing:border-box;}
@media (max-width: 1180px){
  .pmcpc-workspace-shell{grid-template-columns:1fr;}
  .pmcpc-workspace-nav{position:relative;top:auto;}
}
</style>
CSS;

        $workspace_js = <<<'JS'
<script id="pmcpc-workspace-shell-js">
(function(){
  function currentKey(){
    try {
      var url=new URL(window.location.href);
      if(url.pathname.indexOf('/edit.php')!==-1 && url.searchParams.get('post_type')==='pmcpc_sub_update'){
        return 'pmcpc-publishing-log';
      }
      var page=url.searchParams.get('page') || '';
      if(page==='pmcpc_email_template'){
        return 'pmcpc_email_templates';
      }
      if(page==='pmcpc_email'){
        var tab=url.searchParams.get('pmcpc_tab') || '';
        if(tab==='queue' || tab==='history' || tab==='analytics'){ return page + '&pmcpc_tab=' + tab; }
      }
      return page;
    } catch(err){ return ''; }
  }
  function hrefFor(slug){
    if(slug.indexOf('edit.php?')===0 || slug.indexOf('post-new.php?')===0 || slug === 'index.php'){ return window.location.origin + '/wp-admin/' + slug; }
    return window.location.origin + '/wp-admin/admin.php?page=' + slug;
  }
  function init(){
    var slug=currentKey();
    if(!slug || (slug.indexOf('pmcpc_')!==0 && slug.indexOf('pmcpc-')!==0)){ return; }
    var anchor=document.querySelector('.pmcpc-workspace-anchor');
    var wrap=anchor ? anchor.closest('.wrap') : document.querySelector('#wpbody-content > .wrap, #wpbody-content .wrap');
    if(document.querySelector('.pmcpc-workspace-shell[data-pmcpc-server="1"]')){ return; }
    if(!wrap || wrap.dataset.pmcpcWorkspaceInit==='1'){ return; }
    if(wrap.querySelector('.pmcpc-workspace-shell')){ return; }
    wrap.dataset.pmcpcWorkspaceInit='1';
    if(!anchor){
      anchor=document.createElement('div');
      anchor.className='pmcpc-workspace-anchor';
      anchor.setAttribute('aria-hidden','true');
      wrap.insertBefore(anchor, wrap.firstChild);
    }

    var groups=[
      {type:'leaf',slug:'pmcpc_dashboard',label:'Overview',icon:'dashicons-chart-area'},
      {type:'leaf',slug:'pmcpc_campaigns',label:'Campaigns',icon:'dashicons-megaphone'},
      {type:'leaf',slug:'pmcpc_automations',label:'Automations',icon:'dashicons-controls-repeat'},
      {type:'group',key:'audience',label:'Audience',icon:'dashicons-groups',children:[
        {slug:'pmcpc_subscribers',label:'Subscribers',icon:'dashicons-admin-users'},
        {slug:'pmcpc_forms',label:'Forms',icon:'dashicons-feedback'},
        {slug:'pmcpc_inbox',label:'Inbox',icon:'dashicons-email-alt2'},
        {slug:'pmcpc_reviews',label:'Reviews',icon:'dashicons-star-filled'}
      ]},
      {type:'group',key:'emails',label:'Emails',icon:'dashicons-email',children:[
        {slug:'pmcpc_email&pmcpc_tab=queue',label:'Waiting to Send',icon:'dashicons-email-alt'},
        {slug:'pmcpc_email&pmcpc_tab=history',label:'Sent Emails',icon:'dashicons-clock'},
        {slug:'pmcpc_email&pmcpc_tab=analytics',label:'Email Results',icon:'dashicons-chart-line'},
        {slug:'pmcpc_email_templates',label:'Templates',icon:'dashicons-editor-code'}
      ]},
      {type:'group',key:'content',label:'Content',icon:'dashicons-admin-site-alt3',children:[
        {slug:'pmcpc-publishing-log',label:'Publishing Log',icon:'dashicons-list-view'},
        {slug:'pmcpc-subscriber-analytics',label:'Content Results',icon:'dashicons-chart-bar'},
        {slug:'pmcpc-website-publishing',label:'Publishing Settings',icon:'dashicons-admin-site-alt3'}
      ]},
      {type:'group',key:'settings',label:'Settings',icon:'dashicons-admin-settings',children:[
        {slug:'pmcpc_settings',label:'Settings',icon:'dashicons-admin-settings'},
        {slug:'pmcpc-email-login-settings',label:'Email & Login',icon:'dashicons-email-alt'}
      ]},
      {type:'group',key:'help-status',label:'Help & Status',icon:'dashicons-info-outline',children:[
        {slug:'pmcpc_diagnostics',label:'Health Check',icon:'dashicons-chart-pie'},
      ]}
    ];

    var shell=document.createElement('div');
    shell.className='pmcpc-workspace-shell';
    var nav=document.createElement('aside');
    nav.className='pmcpc-workspace-nav';
    var main=document.createElement('div');
    main.className='pmcpc-workspace-main';
    shell.appendChild(nav);
    shell.appendChild(main);

    var existingHeader=wrap.querySelector(':scope > .pmcpc-app-header, :scope > .pmcpc-global-header');
    if(!existingHeader){
      var pageTitle='FlowPress';
      var titleSource=wrap.querySelector(':scope > h1, :scope > .wp-heading-inline, h1, .wp-heading-inline');
      if(titleSource && titleSource.textContent.trim()){ pageTitle=titleSource.textContent.trim(); }
      existingHeader=document.createElement('div');
      existingHeader.className='pmcpc-global-header';
      existingHeader.innerHTML='<div class="pmcpc-global-header__main"><div class="pmcpc-global-header__eyebrow"><span class="dashicons dashicons-controls-repeat" aria-hidden="true"></span><span>FlowPress</span></div><h1 class="pmcpc-global-header__title"></h1><p class="pmcpc-global-header__tagline">Email, audience, and content workflows for WordPress</p></div><div class="pmcpc-global-header__actions"><a class="pmcpc-global-header__link" href="'+hrefFor('index.php')+'"><span class="dashicons dashicons-wordpress" aria-hidden="true"></span><span>Back to WordPress</span></a></div>';
      existingHeader.querySelector('.pmcpc-global-header__title').textContent=pageTitle;
      anchor.parentNode.insertBefore(existingHeader, anchor);
      var coreTitle=wrap.querySelector(':scope > h1, :scope > .wp-heading-inline');
      if(coreTitle){ coreTitle.style.display='none'; }
    }

    var header=document.createElement('div');
    header.className='pmcpc-workspace-nav__header';
    header.innerHTML='<div class="pmcpc-workspace-nav__eyebrow"><span class="dashicons dashicons-controls-repeat" aria-hidden="true"></span><span>Workspace</span></div><div class="pmcpc-workspace-nav__title">FlowPress</div><p class="pmcpc-workspace-nav__subtitle">Email, audience, and content workflows for WordPress</p>' ;
    nav.appendChild(header);

    var tree=document.createElement('div');
    tree.className='pmcpc-workspace-nav__tree';
    nav.appendChild(tree);

    var footer=document.createElement('div');
    footer.className='pmcpc-workspace-nav__footer';
    footer.innerHTML='<a href="'+hrefFor('index.php')+'"><span class="dashicons dashicons-wordpress" aria-hidden="true"></span><span>Back to WordPress</span></a>';
    nav.appendChild(footer);

    function makeLink(item){
      var a=document.createElement('a');
      a.href=hrefFor(item.slug);
      a.innerHTML='<span class="dashicons '+item.icon+'" aria-hidden="true"></span><span>'+item.label+'</span>';
      if(slug===item.slug){ a.classList.add('is-current'); }
      return a;
    }

    groups.forEach(function(item){
      if(item.type==='leaf'){
        var row=document.createElement('div');
        row.appendChild(makeLink(item));
        tree.appendChild(row);
        return;
      }
      var details=document.createElement('details');
      details.className='pmcpc-workspace-nav__group';
      details.dataset.key=item.key;
      var hasCurrent=item.children.some(function(child){ return child.slug===slug; });
      var stored='';
      try{ stored=window.localStorage.getItem('pmcpc_workspace_group_'+item.key) || ''; }catch(err){}
      details.open=hasCurrent || stored==='open';
      if(stored==='closed' && !hasCurrent){ details.open=false; }
      var summary=document.createElement('summary');
      summary.innerHTML='<span class="pmcpc-workspace-nav__summary-left"><span class="dashicons '+item.icon+'" aria-hidden="true"></span><span>'+item.label+'</span></span><span class="pmcpc-workspace-nav__caret" aria-hidden="true">▸</span>';
      details.appendChild(summary);
      var ul=document.createElement('ul');
      item.children.forEach(function(child){
        var li=document.createElement('li');
        li.appendChild(makeLink(child));
        ul.appendChild(li);
      });
      details.appendChild(ul);
      details.addEventListener('toggle',function(){
        try{ window.localStorage.setItem('pmcpc_workspace_group_'+item.key, details.open ? 'open' : 'closed'); }catch(err){}
      });
      tree.appendChild(details);
    });

    anchor.parentNode.insertBefore(shell, anchor.nextSibling);
    var mover=shell.nextSibling;
    while(mover){
      var next=mover.nextSibling;
      var isHeader = mover===existingHeader;
      var isNotice = mover.classList && mover.classList.contains('pmcpc-notification-center');
      if(mover!==null && !isHeader && !isNotice){ main.appendChild(mover); }
      mover=next;
    }
    var noticeCenter=wrap.querySelector(':scope > .pmcpc-notification-center');
    if(noticeCenter){
      shell.parentNode.insertBefore(noticeCenter, shell);
    }
  }
  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();
</script>
JS;

        echo $css;
        echo $js;
        echo $workspace_css;
        echo $workspace_js;
    }


    /**
     * Register a visible submenu item under the workspace top-level menu.
     *
     * @param string          $page_title Page title.
     * @param string          $menu_title Menu title.
     * @param string          $menu_slug  Menu slug.
     * @param callable|string $callback   Render callback.
     * @return void
     */
    private function register_workspace_submenu( $page_title, $menu_title, $menu_slug, $callback ) {
        $page_title = $this->normalize_admin_page_title( $page_title );
        $this->workspace_page_callbacks[ (string) $menu_slug ] = $callback;
        add_submenu_page(
            'pmcpc_dashboard',
            $page_title,
            $menu_title,
            'manage_options',
            $menu_slug,
            array( $this, 'render_registered_workspace_page' )
        );
    }

    /**
     * Register a hidden admin route that remains accessible by URL but does not
     * appear in the native WordPress flyout menu.
     *
     * @param string          $page_title Page title.
     * @param string          $menu_slug  Menu slug.
     * @param callable|string $callback   Render callback.
     * @return void
     */
    private function register_hidden_admin_page( $page_title, $menu_slug, $callback ) {
        $page_title = $this->normalize_admin_page_title( $page_title );
        $this->workspace_page_callbacks[ (string) $menu_slug ] = $callback;
        add_submenu_page(
            '',
            $page_title,
            $page_title,
            'manage_options',
            $menu_slug,
            array( $this, 'render_registered_workspace_page' )
        );

        $this->hidden_route_slugs[ (string) $menu_slug ] = true;
    }

    /**
     * Build a redirect URL for legacy admin routes.
     *
     * @param string $page Admin page slug.
     * @param array  $args Optional query args.
     * @return string
     */
    private function get_admin_page_url( $page, $args = array() ) {
        $args         = is_array( $args ) ? $args : array();
        $args['page'] = (string) $page;

        return add_query_arg( $args, admin_url( 'admin.php' ) );
    }

    /**
     * Build legacy route redirects used by both admin_init and hidden menu routes.
     *
     * @return array<string,string>
     */
    private function get_legacy_admin_redirect_map() {
        return array(
            'pmcpc_revenue_dashboard' => $this->get_admin_page_url( 'pmcpc_dashboard' ),
            'pmcpc_campaign_dashboard' => $this->get_admin_page_url( 'pmcpc_campaigns' ),
            'pmcpc_automations_dashboard' => $this->get_admin_page_url( 'pmcpc_automations' ),
            'pmcpc_audience_dashboard' => $this->get_admin_page_url( 'pmcpc_subscribers' ),
            'pmcpc-publishing-dashboard' => $this->get_admin_page_url( 'pmcpc-publishing-log' ),
            'pmcpc_email_login' => $this->get_admin_page_url( 'pmcpc-email-login-settings' ),
            'pmcpc-spam-log'   => $this->get_admin_page_url(
                'pmcpc_inbox',
                array(
                    'pmcpc_status' => 'blocked',
                )
            ),
            'pmcpc_spam_log'   => $this->get_admin_page_url(
                'pmcpc_inbox',
                array(
                    'pmcpc_status' => 'blocked',
                )
            ),
            'pmcpc_queue'      => $this->get_admin_page_url(
                'pmcpc_email',
                array(
                    'pmcpc_tab' => 'queue',
                )
            ),
            'pmcpc-email-queue' => $this->get_admin_page_url(
                'pmcpc_email',
                array(
                    'pmcpc_tab' => 'queue',
                )
            ),
            'pmcpc_analytics'  => $this->get_admin_page_url(
                'pmcpc_email',
                array(
                    'pmcpc_tab' => 'analytics',
                )
            ),
            'pmcpc_email_template' => $this->get_admin_page_url( 'pmcpc_email_templates' ),
            'pmcpc_email_log'  => $this->get_admin_page_url(
                'pmcpc_email',
                array(
                    'pmcpc_tab' => 'history',
                )
            ),
            'pmcpc-email-log'  => $this->get_admin_page_url(
                'pmcpc_email',
                array(
                    'pmcpc_tab' => 'history',
                )
            ),
            'pmcpc_woocommerce' => $this->get_admin_page_url( 'pmcpc_dashboard' ),
            'pmcpc_automation' => $this->get_admin_page_url( 'pmcpc_automations' ),
            'pmcpc_get_started' => $this->get_admin_page_url( 'pmcpc_dashboard' ),
            'pmcpc_dev_tools' => $this->get_admin_page_url( 'pmcpc_diagnostics' ),
        );
    }

    /**
     * Build a redirect callback for hidden legacy routes.
     *
     * @param string $url Redirect target.
     * @return Closure
     */
    private function get_admin_redirect_callback( $url ) {
        return function () use ( $url ) {
            wp_safe_redirect( $url );
            exit;
        };
    }

    /**
     * Visible top-level workspace submenu definitions.
     *
     * @return array<int,array<string,mixed>>
     */
    private function get_workspace_submenu_definitions() {
        return array(
            array(
                'page_title' => __( 'Overview', 'product-mailer-campaigns' ),
                'menu_title' => self::submenu_label_with_icon( 'dashicons-chart-area', esc_html__( 'Overview', 'product-mailer-campaigns' ) ),
                'menu_slug'  => 'pmcpc_dashboard',
                'callback'   => array( 'PMCPC_Admin', 'render_dashboard' ),
            ),
            array(
                'page_title' => __( 'Campaigns', 'product-mailer-campaigns' ),
                'menu_title' => self::submenu_label_with_icon( 'dashicons-megaphone', esc_html__( 'Campaigns', 'product-mailer-campaigns' ) ),
                'menu_slug'  => 'pmcpc_campaigns',
                'callback'   => array( 'PMCPC_Admin', 'render_campaigns_page' ),
            ),
            array(
                'page_title' => __( 'Automations', 'product-mailer-campaigns' ),
                'menu_title' => self::submenu_label_with_icon( 'dashicons-controls-repeat', esc_html__( 'Automations', 'product-mailer-campaigns' ) ),
                'menu_slug'  => 'pmcpc_automations',
                'callback'   => array( $this, 'render_automations_fallback_page' ),
            ),
            array(
                'page_title' => __( 'Audience', 'product-mailer-campaigns' ),
                'menu_title' => self::submenu_label_with_icon( 'dashicons-groups', esc_html__( 'Audience', 'product-mailer-campaigns' ) ),
                'menu_slug'  => 'pmcpc_subscribers',
                'callback'   => array( 'PMCPC_Admin', 'render_subscribers_page' ),
            ),
            array(
                'page_title' => __( 'Emails', 'product-mailer-campaigns' ),
                'menu_title' => self::submenu_label_with_icon( 'dashicons-email', esc_html__( 'Emails', 'product-mailer-campaigns' ) ),
                'menu_slug'  => 'pmcpc_email',
                'callback'   => array( 'PMCPC_Admin', 'render_email_page' ),
            ),
            array(
                'page_title' => __( 'Content', 'product-mailer-campaigns' ),
                'menu_title' => self::submenu_label_with_icon( 'dashicons-admin-site-alt3', esc_html__( 'Content', 'product-mailer-campaigns' ) ),
                'menu_slug'  => 'pmcpc_content',
                'callback'   => $this->get_admin_redirect_callback( $this->get_admin_page_url( 'pmcpc-publishing-log' ) ),
            ),
            array(
                'page_title' => __( 'Settings', 'product-mailer-campaigns' ),
                'menu_title' => self::submenu_label_with_icon( 'dashicons-admin-settings', esc_html__( 'Settings', 'product-mailer-campaigns' ) ),
                'menu_slug'  => 'pmcpc_settings',
                'callback'   => array( 'PMCPC_Admin', 'render_settings_page' ),
            ),
            array(
                'page_title' => __( 'Help & Status', 'product-mailer-campaigns' ),
                'menu_title' => self::submenu_label_with_icon( 'dashicons-info-outline', esc_html__( 'Help & Status', 'product-mailer-campaigns' ) ),
                'menu_slug'  => 'pmcpc_diagnostics',
                'callback'   => array( 'PMCPC_Admin', 'render_diagnostics_page' ),
            ),
        );
    }

    /**
     * Hidden admin page definitions registered for workspace routing.
     *
     * @return array<int,array<string,mixed>>
     */
    private function get_hidden_admin_page_definitions() {
        $pages = array(
            array(
                'page_title' => __( 'Campaigns', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_campaigns',
                'callback'   => array( 'PMCPC_Admin', 'render_campaigns_page' ),
            ),
            array(
                'page_title' => __( 'Email', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_email',
                'callback'   => array( 'PMCPC_Admin', 'render_email_page' ),
            ),
            array(
                'page_title' => __( 'Audience', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_subscribers',
                'callback'   => array( 'PMCPC_Admin', 'render_subscribers_page' ),
            ),
            array(
                'page_title' => __( 'Inbox', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_inbox',
                'callback'   => array( 'PMCPC_Admin', 'render_inbox_page' ),
            ),
            array(
                'page_title' => __( 'Forms', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_forms',
                'callback'   => array( 'PMCPC_Admin', 'render_forms_page' ),
            ),
            array(
                'page_title' => __( 'Publishing Settings', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc-website-publishing',
                'callback'   => 'pmcpc_render_subscriber_updates_settings_page',
            ),
            array(
                'page_title' => __( 'Publishing Log', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc-publishing-log',
                'callback'   => 'pmcpc_render_subscriber_updates_log_page',
            ),
            array(
                'page_title' => __( 'Content Results', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc-subscriber-analytics',
                'callback'   => 'pmcpc_render_subscriber_updates_analytics_page',
            ),
            array(
                'page_title' => __( 'Reviews', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_reviews',
                'callback'   => array( 'PMCPC_Admin', 'render_reviews_page' ),
            ),
            array(
                'page_title' => __( 'Activate Commerce', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_upgrade',
                'callback'   => array( $this, 'render_upgrade_fallback_page' ),
            ),
            array(
                'page_title' => __( 'Queue (Legacy)', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_queue',
                'callback'   => $this->get_admin_redirect_callback( $this->get_admin_page_url( 'pmcpc_email', array( 'pmcpc_tab' => 'queue' ) ) ),
            ),
            array(
                'page_title' => __( 'Analytics (Legacy)', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_analytics',
                'callback'   => $this->get_admin_redirect_callback( $this->get_admin_page_url( 'pmcpc_email', array( 'pmcpc_tab' => 'analytics' ) ) ),
            ),
            array(
                'page_title' => __( 'Automations (Legacy)', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_automation',
                'callback'   => $this->get_admin_redirect_callback( $this->get_admin_page_url( 'pmcpc_automations' ) ),
            ),
            array(
                'page_title' => __( 'Get Started (Legacy)', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc_get_started',
                'callback'   => $this->get_admin_redirect_callback( $this->get_admin_page_url( 'pmcpc_dashboard' ) ),
            ),
        );

        if ( class_exists( 'PMCPC_Email_Login_Customizer' ) ) {
            $pages[] = array(
                'page_title' => __( 'Email & Login', 'product-mailer-campaigns' ),
                'menu_slug'  => 'pmcpc-email-login-settings',
                'callback'   => array( 'PMCPC_Email_Login_Customizer', 'render_settings_page' ),
            );
        }

        return $pages;
    }

    /**
     * Fallback routes that should remain routable even if a module misses registration.
     *
     * @return array<int,array<string,mixed>>
     */
    private function get_workspace_route_definitions() {
        $routes = array(
            array(
                'slug'     => 'pmcpc_automations',
                'title'    => __( 'Automations', 'product-mailer-campaigns' ),
                'callback' => array( $this, 'render_automations_fallback_page' ),
            ),
            array(
                'slug'     => 'pmcpc_segments',
                'title'    => __( 'Segments', 'product-mailer-campaigns' ),
                'callback' => array( $this, 'render_segments_fallback_page' ),
            ),
            array(
                'slug'     => 'pmcpc_email_templates',
                'title'    => __( 'Email Templates', 'product-mailer-campaigns' ),
                'callback' => array( $this, 'render_templates_fallback_page' ),
            ),
            array(
                'slug'     => 'pmcpc_upgrade',
                'title'    => __( 'Activate Commerce', 'product-mailer-campaigns' ),
                'callback' => array( $this, 'render_upgrade_fallback_page' ),
            ),
        );

        if ( class_exists( 'PMCPC_Email_Login_Customizer' ) ) {
            $routes[] = array(
                'slug'     => 'pmcpc-email-login-settings',
                'title'    => __( 'Email & Login', 'product-mailer-campaigns' ),
                'callback' => array( 'PMCPC_Email_Login_Customizer', 'render_settings_page' ),
            );
        }

        return $routes;
    }

    public function register_admin_menu() {
        $this->workspace_page_callbacks['pmcpc_dashboard'] = array( 'PMCPC_Admin', 'render_dashboard' );
        add_menu_page(
            PMCPC_Admin::app_brand(),
            PMCPC_Admin::app_brand(),
            'manage_options',
            'pmcpc_dashboard',
            array( $this, 'render_registered_workspace_page' ),
            'dashicons-chart-area'
        );

        foreach ( $this->get_workspace_submenu_definitions() as $definition ) {
            $this->register_workspace_submenu(
                $definition['page_title'],
                $definition['menu_title'],
                $definition['menu_slug'],
                $definition['callback']
            );
        }

        foreach ( $this->get_hidden_admin_page_definitions() as $definition ) {
            $this->register_hidden_admin_page(
                $definition['page_title'],
                $definition['menu_slug'],
                $definition['callback']
            );
        }
    }



    /**
     * Remove legacy submenu entries after all plugin modules have registered them.
     *
     * Keep pages routable via URL while preventing duplicate native menu output.
     *
     * @return void
     */

    /**
     * Ensure workspace routes remain registered even if a module misses its
     * submenu registration on a particular admin request.
     *
     * @return void
     */
    public function ensure_workspace_routes() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        foreach ( $this->get_workspace_route_definitions() as $route ) {
            $this->ensure_workspace_route( $route['slug'], $route['title'], $route['callback'] );
        }
    }

    /**
     * Register a hidden submenu route when it is missing.
     *
     * @param string   $slug     Menu slug.
     * @param string   $title    Admin page title.
     * @param callable $callback Render callback.
     * @return void
     */
    private function ensure_workspace_route( $slug, $title, $callback ) {
        global $submenu;

        if ( ! is_callable( $callback ) ) {
            return;
        }

        $slug = (string) $slug;

        if ( isset( $this->hidden_route_slugs[ $slug ] ) ) {
            return;
        }

        if ( ! empty( $submenu['pmcpc_dashboard'] ) && is_array( $submenu['pmcpc_dashboard'] ) ) {
            foreach ( $submenu['pmcpc_dashboard'] as $item ) {
                if ( isset( $item[2] ) && $slug === (string) $item[2] ) {
                    return;
                }
            }
        }

        $this->register_hidden_admin_page( $title, $slug, $callback );
    }

    /**
     * Create an automation bootstrap instance for fallback rendering.
     *
     * @return PMCPC_Automation_Bootstrap|null
     */
    private function get_automation_bootstrap_instance() {
        if ( ! class_exists( 'PMCPC_Automation_Bootstrap' ) ) {
            return null;
        }

        return new PMCPC_Automation_Bootstrap();
    }

    /**
     * Determine whether premium automation pages should be shown in locked mode.
     *
     * @return bool
     */
    private function should_render_locked_automation_pages() {
        if ( function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features() ) {
            return false;
        }

        return class_exists( 'WooCommerce' ) && function_exists( 'pmcpc_features' ) && ! pmcpc_features()->enabled( 'automation' );
    }

    /**
     * Create the licensing service instance when locked premium pages are needed.
     *
     * @return PMCPC_Licensing_Service|null
     */
    private function get_licensing_service_instance() {
        if ( ! class_exists( 'PMCPC_Licensing_Service' ) ) {
            return null;
        }

        return new PMCPC_Licensing_Service();
    }

    public function render_automations_fallback_page() {
        if ( $this->should_render_locked_automation_pages() ) {
            $licensing = $this->get_licensing_service_instance();
            if ( $licensing && method_exists( $licensing, 'render_locked_automations' ) ) {
                $licensing->render_locked_automations();
                return;
            }
        }

        $bootstrap = $this->get_automation_bootstrap_instance();
        if ( $bootstrap && method_exists( $bootstrap, 'render_automations_page' ) ) {
            $bootstrap->render_automations_page();
            return;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_campaigns' ) );
        exit;
    }

    public function render_segments_fallback_page() {
        if ( $this->should_render_locked_automation_pages() ) {
            $licensing = $this->get_licensing_service_instance();
            if ( $licensing && method_exists( $licensing, 'render_locked_segments' ) ) {
                $licensing->render_locked_segments();
                return;
            }
        }

        $bootstrap = $this->get_automation_bootstrap_instance();
        if ( $bootstrap && method_exists( $bootstrap, 'render_segments_page' ) ) {
            $bootstrap->render_segments_page();
            return;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_campaigns' ) );
        exit;
    }

    public function render_templates_fallback_page() {
        if ( $this->should_render_locked_automation_pages() ) {
            $licensing = $this->get_licensing_service_instance();
            if ( $licensing && method_exists( $licensing, 'render_locked_template' ) ) {
                $licensing->render_locked_template();
                return;
            }
        }

        $bootstrap = $this->get_automation_bootstrap_instance();
        if ( $bootstrap && method_exists( $bootstrap, 'render_email_template_page' ) ) {
            $bootstrap->render_email_template_page();
            return;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_campaigns' ) );
        exit;
    }

    public function render_upgrade_fallback_page() {
        $licensing = $this->get_licensing_service_instance();
        if ( $licensing && method_exists( $licensing, 'render_upgrade_page' ) ) {
            $licensing->render_upgrade_page();
            return;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_settings' ) );
        exit;
    }

    public function cleanup_legacy_submenus() {
        if ( ! is_admin() ) {
            return;
        }

        $slugs = array(
            'pmcpc_segments',
            'pmcpc_email_template',
        );

        foreach ( $slugs as $slug ) {
            remove_submenu_page( 'pmcpc_dashboard', $slug );
        }
    }


    /**
     * Force the workspace submenu to a strict whitelist after all modules register.
     *
     * Some legacy modules append menu items after earlier cleanup hooks. Rebuilding
     * the submenu array here prevents old pages like Email & Login / Segments from
     * reappearing underneath the custom tree UI.
     *
     * @return void
     */
    public function whitelist_workspace_submenus() {
        if ( ! is_admin() ) {
            return;
        }

        global $submenu;
        if ( empty( $submenu['pmcpc_dashboard'] ) || ! is_array( $submenu['pmcpc_dashboard'] ) ) {
            return;
        }

        $allowed = array(
            'pmcpc_dashboard',
            'pmcpc_campaigns',
            'pmcpc_automations',
            'pmcpc_subscribers',
            'pmcpc_email',
            'pmcpc_content',
            'pmcpc_settings',
            'pmcpc_diagnostics',
        );

        $filtered = array();
        foreach ( $submenu['pmcpc_dashboard'] as $item ) {
            $slug = isset( $item[2] ) ? (string) $item[2] : '';
            if ( in_array( $slug, $allowed, true ) ) {
                $filtered[] = $item;
            }
        }

        $submenu['pmcpc_dashboard'] = $filtered;
    }

    public function handle_legacy_admin_pages() {
        if ( ! is_admin() ) {
            return;
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        global $pagenow;
        // The old native Updates list has been consolidated into Publishing Log.
        // Keep direct edit/new post screens available, but route the list itself to the new combined screen.
        if ( 'edit.php' === $pagenow && isset( $_GET['post_type'] ) && 'pmcpc_sub_update' === sanitize_key( wp_unslash( $_GET['post_type'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing params.
            wp_safe_redirect( $this->get_admin_page_url( 'pmcpc-publishing-log' ) );
            exit;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing param.
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( '' === $page ) {
            return;
        }

        $redirects = $this->get_legacy_admin_redirect_map();
        if ( isset( $redirects[ $page ] ) ) {
            wp_safe_redirect( $redirects[ $page ] );
            exit;
        }
    }

private static function get_messages_menu_title() {
	    $title = __( 'Inbox', 'product-mailer-campaigns' );
	    $count = 0;

	    global $wpdb;
	    // Table name is plugin-owned (no user input).
	    $table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
	    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	    $exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
	    if ( $exists ) {
	        $user_id   = get_current_user_id();
	        $last_seen = (int) get_user_meta( $user_id, 'pmcpc_messages_last_seen_id', true );

	        // Count new items since last seen (exclude Spam by default; include Inbox + Held).
	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$count = (int) $wpdb->get_var(
	            $wpdb->prepare(
	                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $table uses $wpdb->prefix with a fixed suffix.
	                "SELECT COUNT(*) FROM {$table} WHERE id > %d AND status IN (%s, %s)",
	                $last_seen,
	                'allowed',
	                'held'
	            )
	        );
	    }

	    if ( $count > 0 ) {
	        $title .= ' <span class="awaiting-mod">' . (int) $count . '</span>';
	    }

	    // Add a submenu icon.
	    return self::submenu_label_with_icon( 'dashicons-email-alt2', $title );
	}

private static function get_inbox_menu_title() {
	    return self::get_messages_menu_title();
	}

public function reorder_admin_submenus() {
    if ( ! is_admin() ) {
        return;
    }
    global $submenu;
    if ( empty( $submenu['pmcpc_dashboard'] ) || ! is_array( $submenu['pmcpc_dashboard'] ) ) {
        return;
    }

    $desired = array(
        'pmcpc_dashboard',
        'pmcpc_campaigns',
        'pmcpc_automations',
        'pmcpc_subscribers',
        'pmcpc_email',
        'pmcpc_content',
        'pmcpc_settings',
        'pmcpc_diagnostics',
    );

    $items   = $submenu['pmcpc_dashboard'];
    $by_slug = array();
    foreach ( $items as $item ) {
        $by_slug[ (string) $item[2] ] = $item;
    }

    $new = array();
    foreach ( $desired as $slug ) {
        if ( isset( $by_slug[ $slug ] ) ) {
            $new[] = $by_slug[ $slug ];
            unset( $by_slug[ $slug ] );
        }
    }

    $submenu['pmcpc_dashboard'] = $new;
}

public function maybe_mark_messages_seen() {
    if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing param.
    $page = isset( $_GET['page'] ) ? sanitize_key( (string) wp_unslash( $_GET['page'] ) ) : '';
    if ( 'pmcpc_inbox' !== $page ) {
        return;
    }

    // Only mark messages as "seen" when the admin actually views a submission.
    // This prevents the badge from clearing just by opening the Messages list.
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only.
    $view_id = isset( $_GET['pmcpc_view_id'] ) ? absint( wp_unslash( $_GET['pmcpc_view_id'] ) ) : 0;
    if ( $view_id <= 0 ) {
        return;
    }

    global $wpdb;
    $table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
    $exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
    if ( ! $exists ) {
        return;
    }

    $user_id   = get_current_user_id();
    $last_seen = (int) get_user_meta( $user_id, 'pmcpc_messages_last_seen_id', true );
    if ( $view_id > $last_seen ) {
        update_user_meta( $user_id, 'pmcpc_messages_last_seen_id', $view_id );
    }
}

public function admin_gettext_overrides( $translated, $text, $domain ) {
		// Admin-only: keep wording tweaks scoped to PMCPC pages, but allow any text domain
		// so this also applies when the Pro add-on outputs these strings.
		if ( ! is_admin() ) {
			return $translated;
		}

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing param.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		// Only affect our admin pages to avoid unintended wording changes elsewhere.
		if ( 0 !== strpos( (string) $page, 'pmcpc' ) ) {
			return $translated;
		}

		if ( 'Not enough data yet' === $text ) {
			return '—';
		}

		// Make trigger naming consistent with the revenue table (plural).
		if ( 'New subscriber' === $text ) {
			return 'New subscribers';
		}

        $label_overrides = array(
            'WP Marketing Workflows' => 'FlowPress',
            'Dashboard'                => 'Overview',
            'Revenue Dashboard'        => 'Sales Overview',
            'Form Messages'            => 'Inbox',
            'Form Inbox'               => 'Inbox',
            'Inbox Review'             => 'Inbox',
            'Signup Forms'             => 'Forms',
            'Subscriber Updates'       => 'Updates',
            'Search Subscriber Updates' => 'Search Updates',
            'Website Publishing'       => 'Publishing Settings',
            'Publishing Log'           => 'Publishing Log',
            'Publishing Activity'      => 'Publishing Log',
            'Publishing Analytics'     => 'Content Results',
            'Content Performance'      => 'Content Results',
            'Queue'                    => 'Waiting to Send',
            'Email Queue'              => 'Waiting to Send',
            'Email History'            => 'Sent Emails',
            'Email Analytics'          => 'Email Results',
            'Email Delivery'           => 'Emails',
            'System Status'            => 'Health Check',
            'General Settings'         => 'Settings',
            'New campaign'             => 'New Campaign',
            'New update'               => 'New Update',
        );

        if ( isset( $label_overrides[ $text ] ) ) {
            return $label_overrides[ $text ];
        }

		return $translated;
	}
}
