<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Lightweight activity feed for admin dashboard.
 * Stores recent events in an option (keeps it simple + fast).
 */
class PMCPC_Activity_Feed {

    const OPTION_KEY = 'pmcpc_activity_feed_v1';

    /**
     * Log an activity message.
     *
     * @param string $message
     * @param array  $context Optional context (kept small).
     */
    public static function log( $message, $context = array() ) {
        $message = is_string( $message ) ? trim( $message ) : '';
        if ( '' === $message ) {
            return;
        }

        $feed = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $feed ) ) {
            $feed = array();
        }

        array_unshift(
            $feed,
            array(
                't' => (int) current_time( 'timestamp' ),
                'm' => $message,
                'c' => is_array( $context ) ? array_slice( $context, 0, 8, true ) : array(),
            )
        );

        // Keep the last 30 events.
        $feed = array_slice( $feed, 0, 30 );

        update_option( self::OPTION_KEY, $feed, false );
    }

    /**
     * Get recent feed items.
     *
     * @return array
     */
    public static function get_items() {
        $feed = get_option( self::OPTION_KEY, array() );
        return is_array( $feed ) ? $feed : array();
    }

    /**
     * Render the activity panel.
     */
    public static function render_panel() {
        $items = self::get_items();

        echo '<div class="pmcpc-card" style="margin:16px 0;padding:16px;border:1px solid #dcdcde;background:#fff;border-radius:8px;box-shadow:0 1px 1px rgba(0,0,0,.04);">';
        echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">';
        echo '<h2 style="margin:0;font-size:14px;">' . esc_html__( 'Automation activity', 'product-mailer-campaigns' ) . '</h2>';
        echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_email&tab=queue' ) ) . '">' . esc_html__( 'View queue', 'product-mailer-campaigns' ) . '</a>';
        echo '</div>';

        if ( empty( $items ) ) {
            echo '<p style="margin:10px 0 0;color:#666;">' . esc_html__( 'No recent activity yet. Run the queue to start sending.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
            return;
        }

        echo '<ul style="margin:10px 0 0 18px;">';
        foreach ( $items as $it ) {
            $t = isset( $it['t'] ) ? (int) $it['t'] : 0;
            $m = isset( $it['m'] ) ? (string) $it['m'] : '';
            if ( '' === $m ) { continue; }
            $time = $t ? date_i18n( 'H:i', $t ) : '';
            echo '<li style="margin:6px 0;">';
            if ( $time ) {
                echo '<span style="color:#666;">' . esc_html( $time ) . '</span> — ';
            }
            echo esc_html( $m );
            echo '</li>';
        }
        echo '</ul>';

        echo '</div>';
    }
}
