<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';

/**
 * Migrates legacy recurring cron schedules to self-rescheduling single events.
 */
class PMCPC_Cron_Migration_Service implements PMCPC_Service_Interface {

    public function register() {
        // Run early.
        add_action( 'plugins_loaded', array( $this, 'migrate_cron_to_single_events' ), 1 );
    }

public function migrate_cron_to_single_events() {
        if ( get_option( 'pmcpc_cron_single_events_migrated', false ) ) {
            return;
        }

        // Clear any previously scheduled recurring events (which may reference missing schedules).
        wp_clear_scheduled_hook( 'pmcpc_process_email_queue' );
        wp_clear_scheduled_hook( 'pmcpc_process_scheduled_campaigns' );

        // Schedule initial single events.
        if ( ! wp_next_scheduled( 'pmcpc_process_email_queue' ) ) {
            wp_schedule_single_event( time() + 60, 'pmcpc_process_email_queue' );
        }

        if ( ! wp_next_scheduled( 'pmcpc_process_scheduled_campaigns' ) ) {
            wp_schedule_single_event( time() + 60, 'pmcpc_process_scheduled_campaigns' );
        }

        update_option( 'pmcpc_cron_single_events_migrated', 1, false );
    }
}
