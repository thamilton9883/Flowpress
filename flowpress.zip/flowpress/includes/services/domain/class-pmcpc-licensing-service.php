<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/licensing/class-pmcpc-license-manager.php';
require_once PMCPC_PLUGIN_DIR . 'includes/licensing/class-pmcpc-trial-manager.php';
require_once PMCPC_PLUGIN_DIR . 'includes/licensing/class-pmcpc-feature-manager.php';
require_once PMCPC_PLUGIN_DIR . 'includes/licensing/helpers.php';

class PMCPC_Licensing_Service implements PMCPC_Service_Interface {

    const CRON_HOOK_VERIFY = 'pmcpc_license_verify_weekly';

    public function register() {
        // Enforce local expiry before gated Commerce runtime hooks are registered.
        $this->maybe_enforce_license_expiry();
        add_action( 'init', array( $this, 'maybe_enforce_license_expiry' ), 1 );

        // Keep legacy weekly schedule support; verification itself is scheduled hourly below.
        add_filter( 'cron_schedules', array( $this, 'add_weekly_schedule' ) );

        // Admin post actions.
        add_action( 'admin_post_pmcpc_start_trial', array( $this, 'handle_start_trial' ) );
        add_action( 'admin_post_pmcpc_end_trial', array( $this, 'handle_end_trial' ) );
        add_action( 'admin_post_pmcpc_save_license', array( $this, 'handle_save_license' ) );
        add_action( 'admin_post_pmcpc_verify_license', array( $this, 'handle_verify_license' ) );
        add_action( 'admin_post_pmcpc_toggle_paid_feature_visibility', array( $this, 'handle_toggle_paid_feature_visibility' ) );
        add_action( 'admin_post_pmcpc_set_dev_state', array( $this, 'handle_set_dev_state' ) );

        // Automatic license verification. Local expiry is enforced immediately; remote checks refresh status.
        add_action( self::CRON_HOOK_VERIFY, array( $this, 'cron_verify' ) );
        $this->ensure_license_verify_scheduled();

        // Admin UI: upgrade + locked pages.
        add_action( 'admin_menu', array( $this, 'register_admin_pages' ), 30 );

        // Conversion UI: trial countdown + expiry notices.
        add_action( 'admin_notices', array( $this, 'maybe_render_trial_notices' ) );
        // Lightweight email reminders near trial end.
        add_action( 'admin_init', array( $this, 'maybe_send_trial_reminders' ) );
    }

    /**
     * Render trial countdown/expiry banners within wp-admin.
     */
    public function maybe_render_trial_notices() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Only show on our plugin screens to avoid being noisy.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 0 !== strpos( (string) $page, 'pmcpc_' ) ) {
            return;
        }

        // Plugin pages now use the shared Notification Center for consistent placement.
        return;

        // If licensed, don't show trial banners.
        if ( pmcpc_license()->is_active() ) {
            return;
        }

        $expires = (int) pmcpc_trial()->expires_at();
        $used    = get_option( 'pmcpc_trial_used', 'no' );

        // Trial active: show countdown when 3 days or fewer remain.
        if ( pmcpc_trial()->is_active() ) {
            $days = (int) pmcpc_trial()->days_left();
            if ( $days <= 3 ) {
                $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
                echo '<div class="notice notice-warning" style="border-left-color:#d63638;">';
                echo '<p><strong>' . esc_html__( 'Your FlowPress Commerce trial is ending soon.', 'product-mailer-campaigns' ) . '</strong> ';
                echo esc_html( sprintf( _n( '%d day left.', '%d days left.', $days, 'product-mailer-campaigns' ), $days ) );
                echo ' ';
                echo '<a href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Activate Commerce to keep automations running', 'product-mailer-campaigns' ) . '</a>.';
                echo '</p></div>';
            }
            return;
        }

        // Trial expired: show a strong “paused” notice if trial was used and WooCommerce exists.
        if ( 'yes' === (string) $used && class_exists( 'WooCommerce' ) && $expires > 0 && time() > $expires ) {
            $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
            $auto_url    = admin_url( 'admin.php?page=pmcpc_automations' );
            echo '<div class="notice notice-error">';
            echo '<p><strong>' . esc_html__( 'Trial ended — WooCommerce automations are paused.', 'product-mailer-campaigns' ) . '</strong> ';
            echo esc_html__( 'Your existing automation campaigns remain saved, but new automated sends are paused until you upgrade.', 'product-mailer-campaigns' );
            echo ' <a href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Activate Commerce', 'product-mailer-campaigns' ) . '</a> | ';
            echo '<a href="' . esc_url( $auto_url ) . '">' . esc_html__( 'View paused automations', 'product-mailer-campaigns' ) . '</a>';
            echo '</p></div>';
        }
    }

    /**
     * Send small reminder emails at 3 days and 1 day remaining.
     * Uses options as "send once" flags.
     */
    public function maybe_send_trial_reminders() {
        if ( ! is_admin() ) {
            return;
        }

        if ( pmcpc_license()->is_active() ) {
            return;
        }

        if ( ! pmcpc_trial()->is_active() ) {
            return;
        }

        $days = (int) pmcpc_trial()->days_left();
        if ( $days !== 3 && $days !== 1 ) {
            return;
        }

        $flag = 'pmcpc_trial_email_sent_' . $days;
        if ( 'yes' === (string) get_option( $flag, 'no' ) ) {
            return;
        }

        $to = sanitize_email( (string) get_option( 'admin_email' ) );
        if ( empty( $to ) ) {
            return;
        }

        $site = wp_parse_url( home_url(), PHP_URL_HOST );
        $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );

        $subject = sprintf(
            /* translators: %s: site hostname */
            __( '[%s] FlowPress Commerce trial ending soon', 'product-mailer-campaigns' ),
            (string) $site
        );

        $message = sprintf(
            /* translators: 1: days left, 2: upgrade url */
            __( "Your FlowPress Commerce trial has %1\$d day(s) remaining.\n\nOpen your Commerce options here:\n%2\$s\n", 'product-mailer-campaigns' ),
            $days,
            $upgrade_url
        );

        wp_mail( $to, $subject, $message );
        update_option( $flag, 'yes', false );
    }

    public function add_weekly_schedule( $schedules ) {
        if ( ! isset( $schedules['weekly'] ) ) {
            $schedules['weekly'] = array(
                'interval' => 7 * DAY_IN_SECONDS,
                'display'  => __( 'Once Weekly', 'product-mailer-campaigns' ),
            );
        }
        return $schedules;
    }

    /**
     * Keep the remote verification task frequent enough to catch server-side
     * cancellations, while the license manager handles local expiry instantly.
     */
    protected function ensure_license_verify_scheduled() {
        $hook = self::CRON_HOOK_VERIFY;
        $next = wp_next_scheduled( $hook );

        if ( ! $next ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', $hook );
            return;
        }

        if ( function_exists( 'wp_get_scheduled_event' ) ) {
            $event = wp_get_scheduled_event( $hook );
            if ( $event && isset( $event->schedule ) && 'hourly' !== $event->schedule ) {
                wp_unschedule_event( $next, $hook );
                wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', $hook );
            }
        }
    }

    public function maybe_enforce_license_expiry() {
        if ( ! function_exists( 'pmcpc_license' ) ) {
            return;
        }

        if ( pmcpc_license()->enforce_local_expiry() ) {
            $this->stop_commerce_runtime();
            do_action( 'pmcpc_license_expired_locally' );
        }
    }

    protected function stop_commerce_runtime() {
        if ( class_exists( 'PMCPC_Abandoned_Carts' ) ) {
            $this->clear_scheduled_hook_if_present( PMCPC_Abandoned_Carts::RECOVERY_CRON_HOOK );
        } else {
            $this->clear_scheduled_hook_if_present( 'pmcpc_abandoned_cart_recovery_runner' );
        }

        $this->clear_scheduled_hook_if_present( 'pmcpc_pro_cron_check_inactive_customers' );
    }

    /**
     * Avoid repeated cron-option writes when there is no matching event.
     *
     * @param string $hook Cron hook name.
     * @return void
     */
    protected function clear_scheduled_hook_if_present( $hook ) {
        $hook = (string) $hook;
        if ( '' === $hook || ! wp_next_scheduled( $hook ) ) {
            return;
        }

        $this->remove_all_events_for_hook( $hook );
    }

    /**
     * Directly remove all cron entries for a hook without using wp_clear_scheduled_hook().
     * This avoids noisy cron unschedule notices on hosts where the cron option is fragile.
     *
     * @param string $hook Cron hook name.
     * @return void
     */
    protected function remove_all_events_for_hook( $hook ) {
        $hook = (string) $hook;
        if ( '' === $hook || ! function_exists( '_get_cron_array' ) || ! function_exists( '_set_cron_array' ) ) {
            return;
        }

        $crons   = _get_cron_array();
        $changed = false;

        if ( empty( $crons ) || ! is_array( $crons ) ) {
            return;
        }

        foreach ( $crons as $timestamp => $hooks ) {
            if ( empty( $hooks[ $hook ] ) ) {
                continue;
            }

            unset( $crons[ $timestamp ][ $hook ] );
            $changed = true;

            if ( empty( $crons[ $timestamp ] ) ) {
                unset( $crons[ $timestamp ] );
            }
        }

        if ( $changed ) {
            _set_cron_array( $crons );
        }
    }

    public function cron_verify() {
        $this->maybe_enforce_license_expiry();

        if ( pmcpc_license()->get_key() ) {
            $result = pmcpc_license()->verify( false );
            if ( empty( $result['ok'] ) ) {
                $this->stop_commerce_runtime();
            }
        }
    }

    public function handle_start_trial() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'product-mailer-campaigns' ) );
        }
        check_admin_referer( 'pmcpc_start_trial' );

        $used = get_option( 'pmcpc_trial_used', 'no' );
        if ( 'yes' === (string) $used && ! pmcpc_trial()->is_active() ) {
            wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_upgrade&pmcpc_msg=trial_used' ) );
            exit;
        }

        pmcpc_trial()->start( 14 );
        update_option( 'pmcpc_trial_used', 'yes' );

        wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_upgrade&pmcpc_msg=trial_started' ) );
        exit;
    }
    public function handle_end_trial() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'product-mailer-campaigns' ) );
        }
        check_admin_referer( 'pmcpc_end_trial' );

        // End trial but keep dates for messaging/upsell.
        pmcpc_trial()->end();

        // Hard stop: clear WooCommerce-related scheduled events so nothing keeps running.
        if ( class_exists( 'PMCPC_Abandoned_Carts' ) ) {
            $this->clear_scheduled_hook_if_present( PMCPC_Abandoned_Carts::CRON_HOOK );
            $this->clear_scheduled_hook_if_present( PMCPC_Abandoned_Carts::RECOVERY_CRON_HOOK );
        } else {
            $this->clear_scheduled_hook_if_present( 'pmcpc_abandoned_cart_sweep' );
            $this->clear_scheduled_hook_if_present( 'pmcpc_abandoned_cart_recovery_runner' );
        }

        // Pro inactive/win-back checks (WooCommerce-based).
        $this->clear_scheduled_hook_if_present( 'pmcpc_pro_cron_check_inactive_customers' );

        wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_upgrade&pmcpc_msg=trial_deactivated' ) );
        exit;
    }



    public function handle_save_license() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'product-mailer-campaigns' ) );
        }
        check_admin_referer( 'pmcpc_save_license' );

        $key = isset( $_POST['pmcpc_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['pmcpc_license_key'] ) ) : '';
        pmcpc_license()->set_key( $key );
        $result = pmcpc_license()->verify( true );

        $redirect = add_query_arg(
            array(
                'page' => 'pmcpc_upgrade',
                'pmcpc_msg' => ! empty( $result['ok'] ) ? 'license_verified' : 'license_failed',
                'pmcpc_detail' => rawurlencode( (string) ( $result['message'] ?? '' ) ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect );
        exit;
    }

    public function handle_verify_license() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'product-mailer-campaigns' ) );
        }
        check_admin_referer( 'pmcpc_verify_license' );

        $result = pmcpc_license()->verify( true );

        $redirect = add_query_arg(
            array(
                'page' => 'pmcpc_upgrade',
                'pmcpc_msg' => ! empty( $result['ok'] ) ? 'license_verified' : 'license_failed',
                'pmcpc_detail' => rawurlencode( (string) ( $result['message'] ?? '' ) ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect );
        exit;
    }


    /**
     * Toggle whether paid/Commerce prompts are hidden while the site is in free mode.
     *
     * @return void
     */
    public function handle_toggle_paid_feature_visibility() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_toggle_paid_feature_visibility' );

        if ( function_exists( 'pmcpc_paid_feature_visibility_toggle_available' ) && ! pmcpc_paid_feature_visibility_toggle_available() ) {
            update_option( 'pmcpc_hide_paid_features_for_free', 'no', false );
        } else {
            $current = 'yes' === (string) get_option( 'pmcpc_hide_paid_features_for_free', 'no' );
            update_option( 'pmcpc_hide_paid_features_for_free', $current ? 'no' : 'yes', false );
        }

        $redirect = wp_get_referer();
        if ( empty( $redirect ) ) {
            $redirect = admin_url( 'admin.php?page=pmcpc_dashboard' );
        }

        wp_safe_redirect( $redirect );
        exit;
    }


    public function handle_set_dev_state() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'product-mailer-campaigns' ) );
        }

        if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
            wp_die( esc_html__( 'Developer tools are only available when WP_DEBUG is enabled.', 'product-mailer-campaigns' ) );
        }

        check_admin_referer( 'pmcpc_set_dev_state' );

        $state = isset( $_POST['pmcpc_dev_state'] ) ? sanitize_key( wp_unslash( $_POST['pmcpc_dev_state'] ) ) : '';
        $now   = time();

        delete_option( 'pmcpc_license_key' );
        delete_option( 'pmcpc_license_plan' );
        delete_option( 'pmcpc_license_features' );
        delete_option( 'pmcpc_license_expires_at' );
        delete_option( 'pmcpc_license_last_check' );

        switch ( $state ) {
            case 'core':
                update_option( 'pmcpc_trial_active', 'no' );
                update_option( 'pmcpc_trial_used', 'no' );
                delete_option( 'pmcpc_trial_start' );
                delete_option( 'pmcpc_trial_expires' );
                update_option( 'pmcpc_license_status', 'inactive' );
                $msg = 'dev_core';
                break;

            case 'trial':
                update_option( 'pmcpc_trial_active', 'yes' );
                update_option( 'pmcpc_trial_used', 'yes' );
                update_option( 'pmcpc_trial_start', $now );
                update_option( 'pmcpc_trial_expires', $now + ( 14 * DAY_IN_SECONDS ) );
                update_option( 'pmcpc_license_status', 'inactive' );
                $msg = 'dev_trial';
                break;

            case 'expired':
                update_option( 'pmcpc_trial_active', 'no' );
                update_option( 'pmcpc_trial_used', 'yes' );
                update_option( 'pmcpc_trial_start', $now - ( 15 * DAY_IN_SECONDS ) );
                update_option( 'pmcpc_trial_expires', $now - DAY_IN_SECONDS );
                update_option( 'pmcpc_license_status', 'inactive' );
                $msg = 'dev_expired';
                break;

            case 'pro':
                update_option( 'pmcpc_trial_active', 'no' );
                update_option( 'pmcpc_trial_used', 'yes' );
                update_option( 'pmcpc_license_status', 'active' );
                update_option( 'pmcpc_license_plan', 'commerce' );
                update_option( 'pmcpc_license_expires_at', $now + YEAR_IN_SECONDS );
                $msg = 'dev_pro';
                break;

            default:
                wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_diagnostics&pmcpc_msg=dev_invalid' ) );
                exit;
        }

        if ( class_exists( 'PMCPC_Abandoned_Carts' ) ) {
            $this->clear_scheduled_hook_if_present( PMCPC_Abandoned_Carts::CRON_HOOK );
            $this->clear_scheduled_hook_if_present( PMCPC_Abandoned_Carts::RECOVERY_CRON_HOOK );
            if ( method_exists( 'PMCPC_Abandoned_Carts', 'ensure_cron' ) ) {
                PMCPC_Abandoned_Carts::ensure_cron();
            }
        } else {
            $this->clear_scheduled_hook_if_present( 'pmcpc_abandoned_cart_sweep' );
            $this->clear_scheduled_hook_if_present( 'pmcpc_abandoned_cart_recovery_runner' );
        }

        $this->clear_scheduled_hook_if_present( 'pmcpc_pro_cron_check_inactive_customers' );

        wp_safe_redirect( admin_url( 'admin.php?page=pmcpc_diagnostics&pmcpc_msg=' . rawurlencode( $msg ) ) );
        exit;
    }

    public function register_admin_pages() {
        // Let the shared admin workspace own these routes when it is active.
        // The workspace fallback handlers will delegate to the locked-page renderers
        // when premium automation features are unavailable.
        if ( ( class_exists( 'PMCPC_Admin_UI_Service' ) || class_exists( 'PMCPC_Admin_UI' ) ) ) {
            return;
        }

        // Locked premium pages (visible for upsell).
        if ( class_exists( 'WooCommerce' ) && function_exists( 'pmcpc_features' ) && ! pmcpc_features()->enabled( 'automation' ) ) {
            add_submenu_page(
                'pmcpc_dashboard',
                __( 'Automations', 'product-mailer-campaigns' ),
                __( 'Automations', 'product-mailer-campaigns' ) . ' ' . __( '(Locked)', 'product-mailer-campaigns' ),
                'manage_options',
                'pmcpc_automations',
                array( $this, 'render_locked_automations' )
            );

            add_submenu_page(
                'pmcpc_dashboard',
                __( 'Segments', 'product-mailer-campaigns' ),
                __( 'Segments', 'product-mailer-campaigns' ) . ' ' . __( '(Locked)', 'product-mailer-campaigns' ),
                'manage_options',
                'pmcpc_segments',
                array( $this, 'render_locked_segments' )
            );

            add_submenu_page(
                'pmcpc_dashboard',
                __( 'Email Template', 'product-mailer-campaigns' ),
                __( 'Email Template', 'product-mailer-campaigns' ) . ' ' . __( '(Locked)', 'product-mailer-campaigns' ),
                'manage_options',
                'pmcpc_email_template',
                array( $this, 'render_locked_template' )
            );
        }

        add_submenu_page(
            'pmcpc_dashboard',
            __( 'Upgrade', 'product-mailer-campaigns' ),
            '<span class="dashicons dashicons-star-filled" aria-hidden="true"></span><span class="pmcpc-menu-text">' . esc_html__( 'Upgrade', 'product-mailer-campaigns' ) . '</span>',
            'manage_options',
            'pmcpc_upgrade',
            array( $this, 'render_upgrade_page' )
        );

    }

    public function render_locked_automations() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        global $wpdb;
        $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
        $queue_table     = $wpdb->prefix . 'pmcpc_email_queue';

        // Pull any campaigns that look like automations (non-empty trigger).
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $automation_campaigns = $wpdb->get_results( "SELECT id, name, automation_trigger FROM {$campaigns_table} WHERE automation_trigger IS NOT NULL AND automation_trigger != '' ORDER BY id DESC LIMIT 50" );

        // Count paused queue rows (set by queue processor when premium is locked).
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $paused_count = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(1) FROM %i WHERE status = %s', $queue_table, 'paused' ) );

        $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
        $trial_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );
        $trial_used  = get_option( 'pmcpc_trial_used', 'no' );
        $trial_expires = (int) pmcpc_trial()->expires_at();
        $trial_expired = ( 'yes' === (string) $trial_used && $trial_expires > 0 && time() > $trial_expires && ! pmcpc_trial()->is_active() );

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__( 'Automations', 'product-mailer-campaigns' ) . '</h1>';

        // If trial expired, show a direct paused-state block.
        if ( $trial_expired ) {
            echo '<div style="margin-top:14px; padding:18px; border:1px solid #d63638; background:#fff; border-radius:12px; max-width: 920px;">';
            echo '<h2 style="margin-top:0;">' . esc_html__( 'Paused — upgrade to resume', 'product-mailer-campaigns' ) . '</h2>';
            if ( $paused_count > 0 ) {
                echo '<p>' . esc_html( sprintf( _n( 'There is %d automation email currently paused in your queue.', 'There are %d automation emails currently paused in your queue.', $paused_count, 'product-mailer-campaigns' ), $paused_count ) ) . '</p>';
            } else {
                echo '<p>' . esc_html__( 'Your automation campaigns remain saved, but automated sending is paused until you activate a license.', 'product-mailer-campaigns' ) . '</p>';
            }
            echo '<p><a class="button button-primary" href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Activate Commerce', 'product-mailer-campaigns' ) . '</a></p>';
            echo '</div>';
        }

        // Show the standard upsell block.
        echo '<div style="margin-top:14px; padding:18px; border:1px solid #dcdcde; background:#fff; border-radius:12px; max-width: 920px;">';
        echo '<h2 style="margin-top:0;">' . esc_html__( 'This is part of FlowPress Commerce', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p>' . esc_html__( 'Unlock WooCommerce sales automations, customer segments, and revenue insights for your store.', 'product-mailer-campaigns' ) . '</p>';
        echo '<p>';
        if ( ! $trial_used && ! $trial_active ) {
            echo '<a class="button button-primary" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Start Free Trial', 'product-mailer-campaigns' ) . '</a> ';
        }
        echo '<a class="button' . ( ( $trial_used || $trial_active ) ? ' button-primary' : '' ) . '" href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'View plans / Activate Commerce', 'product-mailer-campaigns' ) . '</a>';
        echo '</p>';
        echo '</div>';

        // If any automation campaigns exist, list them (read-only) to increase perceived value.
        if ( ! empty( $automation_campaigns ) ) {
            echo '<div style="margin-top:14px; padding:18px; border:1px solid #dcdcde; background:#fff; border-radius:12px; max-width: 920px;">';
            echo '<h2 style="margin-top:0;">' . esc_html__( 'Saved automations on this site', 'product-mailer-campaigns' ) . '</h2>';
            echo '<p style="margin-top:0; color:#646970;">' . esc_html__( 'These are currently read-only while Commerce is locked.', 'product-mailer-campaigns' ) . '</p>';
            echo '<table class="widefat striped" style="max-width: 880px;">';
            echo '<thead><tr><th>' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th><th>' . esc_html__( 'Trigger', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
            foreach ( $automation_campaigns as $c ) {
                $name = isset( $c->name ) ? (string) $c->name : '';
                $trigger = isset( $c->automation_trigger ) ? sanitize_key( (string) $c->automation_trigger ) : '';
                echo '<tr>';
                echo '<td>' . esc_html( $name ? $name : ( 'Campaign #' . (int) $c->id ) ) . '</td>';
                echo '<td><code>' . esc_html( $trigger ) . '</code></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            echo '</div>';
        }

        echo '</div>';
    }

    public function render_locked_segments() {
        $this->render_locked_page( __( 'Segments', 'product-mailer-campaigns' ) );
    }

    public function render_locked_template() {
        $this->render_locked_page( __( 'Email Template', 'product-mailer-campaigns' ) );
    }

    protected function render_locked_page( $title ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
        $trial_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );
        $trial_used  = 'yes' === (string) get_option( 'pmcpc_trial_used', 'no' );
        $trial_active = pmcpc_trial()->is_active();

        echo '<div class="wrap">';
        if ( class_exists( 'PMCPC_Admin' ) && method_exists( 'PMCPC_Admin', 'render_app_header' ) ) {
            PMCPC_Admin::render_app_header( $title );
        }
        echo '<div class="pmcpc-hub-intro"><h2>' . esc_html( $title ) . '</h2><p>' . esc_html__( 'This area is part of FlowPress Commerce for WooCommerce stores.', 'product-mailer-campaigns' ) . '</p></div>';
        echo '<div style="margin-top:14px; padding:18px; border:1px solid #dcdcde; background:#fff; border-radius:12px; max-width: 920px;">';
        echo '<h2 style="margin-top:0;">' . esc_html__( 'This is part of FlowPress Commerce', 'product-mailer-campaigns' ) . '</h2>';
        echo '<p>' . esc_html__( 'Unlock WooCommerce sales automations, customer segments, and revenue insights for your store.', 'product-mailer-campaigns' ) . '</p>';
        echo '<p>';
        if ( ! $trial_used && ! $trial_active ) {
            echo '<a class="button button-primary" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Start Free Trial', 'product-mailer-campaigns' ) . '</a> ';
        }
        echo '<a class="button' . ( ( $trial_used || $trial_active ) ? ' button-primary' : '' ) . '" href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'View plans / Activate Commerce', 'product-mailer-campaigns' ) . '</a>';
        echo '</p>';
        echo '</div>';
        echo '</div>';
    }

    public function render_upgrade_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $summary            = pmcpc_features()->status_summary();
        $license_key        = pmcpc_license()->get_key();
        $woo_active         = class_exists( 'WooCommerce' );
        $trial_active       = pmcpc_trial()->is_active();
        $licensed           = pmcpc_license()->is_active();
        $days_left          = (int) ( $summary['days_left'] ?? 0 );
        $trial_used         = 'yes' === (string) get_option( 'pmcpc_trial_used', 'no' );
        $license_expires_at = (int) pmcpc_license()->expires_at();
        $license_days_left  = $license_expires_at > 0 ? max( 0, (int) ceil( ( $license_expires_at - time() ) / DAY_IN_SECONDS ) ) : 0;

        // Optional context: user clicked a locked "starter" automation.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI hint.
        $offer = isset( $_GET['pmcpc_offer'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_offer'] ) ) : '';
        $offer_label = '';
        if ( 'post_purchase' === $offer ) {
            $offer_label = __( 'Post‑purchase follow‑ups', 'product-mailer-campaigns' );
        } elseif ( 'winback' === $offer ) {
            $offer_label = __( 'Win‑back campaign', 'product-mailer-campaigns' );
        } elseif ( 'review_request' === $offer ) {
            $offer_label = __( 'Review request flow', 'product-mailer-campaigns' );
        }

        $trial_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );
        $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
        $notice_msg  = '';
        $notice_type = 'success';

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI notice.
        $pmcpc_msg = isset( $_GET['pmcpc_msg'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_msg'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only UI notice.
        $pmcpc_detail = isset( $_GET['pmcpc_detail'] ) ? sanitize_text_field( wp_unslash( $_GET['pmcpc_detail'] ) ) : '';
        switch ( $pmcpc_msg ) {
            case 'license_saved':
                $notice_msg = __( 'Commerce license key saved and verification requested.', 'product-mailer-campaigns' );
                break;
            case 'license_verified':
                $notice_msg = $licensed
                    ? __( 'License verified successfully.', 'product-mailer-campaigns' )
                    : __( 'License check completed. Review the status summary below for the current result.', 'product-mailer-campaigns' );
                $notice_type = $licensed ? 'success' : 'warning';
                break;
            case 'license_failed':
                $notice_msg = $pmcpc_detail ? $pmcpc_detail : pmcpc_license()->last_message();
                if ( '' === $notice_msg ) {
                    $notice_msg = __( 'License activation did not succeed. Review the details below.', 'product-mailer-campaigns' );
                }
                $notice_type = 'warning';
                break;
            case 'trial_started':
                $notice_msg = __( 'Free trial started. WooCommerce automation features are now available on this site.', 'product-mailer-campaigns' );
                break;
            case 'trial_deactivated':
                $notice_msg = __( 'Trial ended. WooCommerce automation features are now paused.', 'product-mailer-campaigns' );
                $notice_type = 'warning';
                break;
            case 'trial_used':
                $notice_msg = __( 'This site has already used its free trial. Add a Commerce license key to unlock WooCommerce automation again.', 'product-mailer-campaigns' );
                $notice_type = 'warning';
                break;
        }

        $license_card_heading = $licensed ? __( 'Manage Commerce license', 'product-mailer-campaigns' ) : __( 'Activate Commerce', 'product-mailer-campaigns' );
        $license_card_intro   = $licensed
            ? __( 'Review or update the license key for this site, then re-check the current license status when needed.', 'product-mailer-campaigns' )
            : __( 'Paste your FlowPress Commerce license key to unlock WooCommerce features on this site.', 'product-mailer-campaigns' );
        $license_anchor_label = $licensed ? __( 'Manage License', 'product-mailer-campaigns' ) : __( 'Activate License', 'product-mailer-campaigns' );

        echo '<div class="wrap">';
        if ( class_exists( 'PMCPC_Admin' ) && method_exists( 'PMCPC_Admin', 'render_app_header' ) ) {
            PMCPC_Admin::render_app_header( __( 'Upgrade to FlowPress Commerce', 'product-mailer-campaigns' ) );
        }

        echo '<style id="pmcpc-upgrade-page-css">';
        echo '.pmcpc-upgrade-grid{display:grid;grid-template-columns:minmax(0,1fr);gap:16px;max-width:980px;}';
        echo '.pmcpc-upgrade-card{padding:18px;border:1px solid #dcdcde;background:#fff;border-radius:12px;box-shadow:0 1px 1px rgba(0,0,0,.03);}';
        echo '.pmcpc-upgrade-card h2{margin:0 0 8px;font-size:22px;line-height:1.25;color:#1d2327;}';
        echo '.pmcpc-upgrade-card h3{margin:0 0 8px;font-size:18px;line-height:1.3;color:#1d2327;}';
        echo '.pmcpc-upgrade-card p{margin:0 0 12px;color:#50575e;}';
        echo '.pmcpc-upgrade-status{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;align-items:start;}';
        echo '.pmcpc-upgrade-status__label{font-size:12px;font-weight:600;letter-spacing:.03em;text-transform:uppercase;color:#646970;margin-bottom:4px;}';
        echo '.pmcpc-upgrade-status__value{font-size:16px;font-weight:600;color:#1d2327;}';
        echo '.pmcpc-upgrade-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;}';
        echo '.pmcpc-upgrade-benefits{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin:0;padding:0;list-style:none;}';
        echo '.pmcpc-upgrade-benefit{border:1px solid #e2e4e7;border-radius:10px;padding:14px;background:#fcfcfc;}';
        echo '.pmcpc-upgrade-benefit strong{display:flex;align-items:center;gap:8px;margin-bottom:6px;color:#1d2327;}';
        echo '.pmcpc-upgrade-benefit strong .dashicons{color:#00a32a;}';
        echo '.pmcpc-upgrade-license-form{display:flex;gap:8px;flex-wrap:wrap;align-items:center;}';
        echo '.pmcpc-upgrade-license-form .regular-text{min-width:280px;}';
        echo '.pmcpc-upgrade-subtle{font-size:13px;color:#646970;margin-top:8px;}';
        echo '@media (max-width:782px){.pmcpc-upgrade-license-form .regular-text{min-width:100%;width:100%;}}';
        echo '</style>';

        echo '<div class="pmcpc-hub-intro"><h2>' . esc_html__( 'Commerce & Licensing', 'product-mailer-campaigns' ) . '</h2><p>' . esc_html__( 'Unlock WooCommerce automation features, manage your trial, and verify your license from one place.', 'product-mailer-campaigns' ) . '</p></div>';

        if ( $notice_msg ) {
            $notice_class = 'warning' === $notice_type ? 'notice notice-warning' : 'notice notice-success';
            echo '<div class="' . esc_attr( $notice_class ) . '" style="max-width:980px;"><p>' . esc_html( $notice_msg ) . '</p></div>';
        }

        if ( $offer_label ) {
            echo '<div class="pmcpc-upgrade-card" style="max-width:980px;margin:0 0 16px;background:#f6f7f7;">';
            echo '<p><strong>' . esc_html__( 'Locked feature:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $offer_label ) . '. ' . esc_html__( 'Start a free trial or activate a license to turn it on.', 'product-mailer-campaigns' ) . '</p>';
            echo '</div>';
        }

        echo '<div class="pmcpc-upgrade-grid">';

        echo '<div class="pmcpc-upgrade-card">';
        echo '<h3>' . esc_html__( 'License status', 'product-mailer-campaigns' ) . '</h3>';
        echo '<div class="pmcpc-upgrade-status">';
        echo '<div><div class="pmcpc-upgrade-status__label">' . esc_html__( 'Mode', 'product-mailer-campaigns' ) . '</div><div class="pmcpc-upgrade-status__value">';
        if ( 'trial' === ( $summary['mode'] ?? '' ) ) {
            echo esc_html__( 'Trial active', 'product-mailer-campaigns' );
        } elseif ( 'licensed' === ( $summary['mode'] ?? '' ) ) {
            echo esc_html__( 'Licensed', 'product-mailer-campaigns' );
        } else {
            echo esc_html__( 'Free mode', 'product-mailer-campaigns' );
        }
        echo '</div></div>';
        echo '<div><div class="pmcpc-upgrade-status__label">' . esc_html__( 'Time remaining', 'product-mailer-campaigns' ) . '</div><div class="pmcpc-upgrade-status__value">';
        if ( 'trial' === ( $summary['mode'] ?? '' ) ) {
            echo esc_html( sprintf( _n( '%d day', '%d days', $days_left, 'product-mailer-campaigns' ), $days_left ) );
        } elseif ( 'licensed' === ( $summary['mode'] ?? '' ) ) {
            if ( $license_expires_at > 0 ) {
                echo esc_html( sprintf( _n( '%d day left', '%d days left', $license_days_left, 'product-mailer-campaigns' ), $license_days_left ) );
                echo '<div class="pmcpc-upgrade-subtle">' . esc_html( sprintf( __( 'Expires on %s', 'product-mailer-campaigns' ), wp_date( get_option( 'date_format', 'F j, Y' ), $license_expires_at ) ) ) . '</div>';
            } else {
                echo esc_html__( 'Not limited', 'product-mailer-campaigns' );
            }
        } else {
            echo $trial_used ? esc_html__( 'Trial ended', 'product-mailer-campaigns' ) : esc_html__( 'Trial not active', 'product-mailer-campaigns' );
        }
        echo '</div></div>';
        echo '<div><div class="pmcpc-upgrade-status__label">' . esc_html__( 'Commerce features', 'product-mailer-campaigns' ) . '</div><div class="pmcpc-upgrade-status__value">';
        if ( $licensed ) {
            echo esc_html__( 'Unlocked', 'product-mailer-campaigns' );
        } elseif ( $trial_active ) {
            echo esc_html__( 'Unlocked during trial', 'product-mailer-campaigns' );
        } else {
            echo esc_html__( 'Locked', 'product-mailer-campaigns' );
        }
        echo '</div></div>';
        echo '</div>';
        echo '<div class="pmcpc-upgrade-actions">';
        if ( $woo_active && ! $trial_active && ! $licensed && ! $trial_used ) {
            echo '<a class="button button-primary" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Start Free Trial', 'product-mailer-campaigns' ) . '</a>';
        }
        if ( $trial_active && ! $licensed ) {
            $end_trial_url = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_end_trial' ), 'pmcpc_end_trial' );
            echo '<a class="button" href="' . esc_url( $end_trial_url ) . '">' . esc_html__( 'End Trial Now', 'product-mailer-campaigns' ) . '</a>';
        }
        echo '<a class="button button-primary" href="#pmcpc-license-card">' . esc_html( $license_anchor_label ) . '</a>';
        echo '<a class="button" href="' . esc_url( function_exists( 'pmcpc_pricing_url' ) ? pmcpc_pricing_url() : 'https://flowpress.uk/pricing/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'View pricing', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="button" href="' . esc_url( function_exists( 'pmcpc_docs_url' ) ? pmcpc_docs_url() : 'https://flowpress.uk/docs/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Documentation', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="button" href="' . esc_url( function_exists( 'pmcpc_account_url' ) ? pmcpc_account_url() : 'https://flowpress.uk/my-account/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'My account', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_automations' ) ) . '">' . esc_html__( 'View Automations', 'product-mailer-campaigns' ) . '</a>';
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_diagnostics' ) ) . '">' . esc_html__( 'Open Health Check', 'product-mailer-campaigns' ) . '</a>';
        }
        echo '</div>';
        echo '</div>';

        if ( $trial_active && ! $licensed ) {
            $end_trial_url = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_end_trial' ), 'pmcpc_end_trial' );
            echo '<div class="pmcpc-upgrade-card">';
            echo '<h3>' . esc_html__( 'Testing tools', 'product-mailer-campaigns' ) . '</h3>';
            echo '<p>' . esc_html__( 'Need to review the core-only or expired-trial interface? End the active trial here without leaving this page.', 'product-mailer-campaigns' ) . '</p>';
            echo '<div class="pmcpc-upgrade-actions">';
            echo '<a class="button" href="' . esc_url( $end_trial_url ) . '">' . esc_html__( 'End Trial Now', 'product-mailer-campaigns' ) . '</a>';
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_diagnostics' ) ) . '">' . esc_html__( 'Open Health Check', 'product-mailer-campaigns' ) . '</a>';
            }
            echo '</div>';
            echo '</div>';
        }

        echo '<div class="pmcpc-upgrade-card">';
        echo '<h3>' . esc_html__( 'What you unlock', 'product-mailer-campaigns' ) . '</h3>';
        echo '<ul class="pmcpc-upgrade-benefits">';
        $benefits = array(
            array(
                'title' => __( 'Recover lost baskets', 'product-mailer-campaigns' ),
                'text'  => __( 'Abandoned cart recovery and customer win-back flows designed to bring shoppers back.', 'product-mailer-campaigns' ),
            ),
            array(
                'title' => __( 'Follow up after purchase', 'product-mailer-campaigns' ),
                'text'  => __( 'Review requests, replenishment reminders, and cross-sell journeys after the order completes.', 'product-mailer-campaigns' ),
            ),
            array(
                'title' => __( 'Target the right customers', 'product-mailer-campaigns' ),
                'text'  => __( 'Segments for new, repeat, VIP, and inactive customers so campaigns reach the right audience.', 'product-mailer-campaigns' ),
            ),
            array(
                'title' => __( 'See revenue impact', 'product-mailer-campaigns' ),
                'text'  => __( 'Revenue attribution and conversion insight tools so you can see what each automation is driving.', 'product-mailer-campaigns' ),
            ),
        );
        foreach ( $benefits as $benefit ) {
            echo '<li class="pmcpc-upgrade-benefit"><strong><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><span>' . esc_html( $benefit['title'] ) . '</span></strong><div>' . esc_html( $benefit['text'] ) . '</div></li>';
        }
        echo '</ul>';
        echo '</div>';

        echo '<div class="pmcpc-upgrade-card">';
        echo '<h3>' . esc_html__( 'Commerce links', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p>' . esc_html__( 'Open the FlowPress site to compare plans, manage billing, or read setup guides for your WooCommerce store.', 'product-mailer-campaigns' ) . '</p>';
        echo '<div class="pmcpc-upgrade-actions">';
        echo '<a class="button button-primary" href="' . esc_url( function_exists( 'pmcpc_pricing_url' ) ? pmcpc_pricing_url() : 'https://flowpress.uk/pricing/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Open pricing', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="button" href="' . esc_url( function_exists( 'pmcpc_account_url' ) ? pmcpc_account_url() : 'https://flowpress.uk/my-account/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Open account', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="button" href="' . esc_url( function_exists( 'pmcpc_docs_url' ) ? pmcpc_docs_url() : 'https://flowpress.uk/docs/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Open docs', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="button" href="' . esc_url( function_exists( 'pmcpc_support_url' ) ? pmcpc_support_url() : 'https://flowpress.uk/support/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Get support', 'product-mailer-campaigns' ) . '</a>';
        echo '</div>';
        echo '</div>';

        echo '<div id="pmcpc-license-card" class="pmcpc-upgrade-card">';
        if ( ! $licensed ) {
            $last_message = pmcpc_license()->last_message();
            if ( $last_message ) {
                echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Last license check:', 'product-mailer-campaigns' ) . ' ' . esc_html( $last_message ) . '</p></div>';
            }
        }
        echo '<h3>' . esc_html( $license_card_heading ) . '</h3>';
        echo '<p>' . esc_html( $license_card_intro ) . '</p>';
        if ( $licensed && $license_expires_at > 0 ) {
            echo '<p class="pmcpc-upgrade-subtle" style="margin-top:-4px;margin-bottom:12px;">' . esc_html( sprintf( __( 'This Commerce license expires on %1$s with %2$d days remaining.', 'product-mailer-campaigns' ), wp_date( get_option( 'date_format', 'F j, Y' ), $license_expires_at ), $license_days_left ) ) . '</p>';
        }
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="pmcpc_save_license" />';
        wp_nonce_field( 'pmcpc_save_license' );
        echo '<div class="pmcpc-upgrade-license-form">';
        echo '<input type="text" name="pmcpc_license_key" class="regular-text" value="' . esc_attr( $license_key ) . '" placeholder="PMC-XXXX-XXXX" />';
        submit_button( __( 'Save & Verify', 'product-mailer-campaigns' ), 'secondary', 'submit', false );
        echo '</div>';
        echo '</form>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:10px;">';
        echo '<input type="hidden" name="action" value="pmcpc_verify_license" />';
        wp_nonce_field( 'pmcpc_verify_license' );
        submit_button( __( 'Re-check License', 'product-mailer-campaigns' ), 'secondary', 'submit', false );
        echo '</form>';
        echo '<div class="pmcpc-upgrade-subtle">' . esc_html__( 'Tip: the warning above lives in the Notification Center, so this page keeps the status summary calmer and easier to scan.', 'product-mailer-campaigns' ) . '</div>';
        echo '</div>';


        echo '</div>'; // grid
        echo '</div>'; // wrap
    }

    public function render_dev_tools_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
            wp_die( esc_html__( 'Developer tools are only available when WP_DEBUG is enabled.', 'product-mailer-campaigns' ) );
        }

        $summary = pmcpc_features()->status_summary();
        $mode    = isset( $summary['mode'] ) ? (string) $summary['mode'] : 'free';
        $days    = isset( $summary['days_left'] ) ? (int) $summary['days_left'] : 0;

        echo '<div class="wrap">';
        if ( class_exists( 'PMCPC_Admin' ) && method_exists( 'PMCPC_Admin', 'render_app_header' ) ) {
            PMCPC_Admin::render_app_header( __( 'Developer License Tools', 'product-mailer-campaigns' ) );
        }

        echo '<div class="pmcpc-hub-intro"><h2>' . esc_html__( 'Developer License Tools', 'product-mailer-campaigns' ) . '</h2><p>' . esc_html__( 'Quickly switch the site between core-only, trial, expired-trial, and Commerce modes for QA.', 'product-mailer-campaigns' ) . '</p></div>';
        echo '<div style="max-width:980px;padding:18px;border:1px solid #dcdcde;background:#fff;border-radius:12px;box-shadow:0 1px 1px rgba(0,0,0,.03);">';
        echo '<p><strong>' . esc_html__( 'Current mode:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( ucfirst( $mode ) ) . '</p>';
        if ( 'trial' === $mode ) {
            echo '<p>' . esc_html( sprintf( _n( '%d day remaining in the active trial.', '%d days remaining in the active trial.', $days, 'product-mailer-campaigns' ), $days ) ) . '</p>';
        }
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="pmcpc_set_dev_state" />';
        wp_nonce_field( 'pmcpc_set_dev_state' );
        echo '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
        echo '<button type="submit" name="pmcpc_dev_state" value="core" class="button button-secondary">' . esc_html__( 'Core Only', 'product-mailer-campaigns' ) . '</button>';
        echo '<button type="submit" name="pmcpc_dev_state" value="trial" class="button button-primary">' . esc_html__( 'Trial Active', 'product-mailer-campaigns' ) . '</button>';
        echo '<button type="submit" name="pmcpc_dev_state" value="expired" class="button button-secondary">' . esc_html__( 'Trial Expired', 'product-mailer-campaigns' ) . '</button>';
        echo '<button type="submit" name="pmcpc_dev_state" value="pro" class="button button-primary">' . esc_html__( 'Commerce Active', 'product-mailer-campaigns' ) . '</button>';
        echo '</div>';
        echo '</form>';
        echo '<p style="margin-top:12px;color:#646970;">' . esc_html__( 'This page is only available when WP_DEBUG is enabled.', 'product-mailer-campaigns' ) . '</p>';
        echo '</div>';
        echo '</div>';
    }

}
