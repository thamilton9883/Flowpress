<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';

class PMCPC_Admin_Notices_Service implements PMCPC_Service_Interface {
    public function register() {
        add_action( 'admin_notices', array( 'PMCPC_Admin', 'admin_notices' ) );
    }
}
