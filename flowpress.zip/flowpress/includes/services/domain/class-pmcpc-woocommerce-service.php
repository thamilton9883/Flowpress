<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';

class PMCPC_WooCommerce_Service implements PMCPC_Service_Interface {
    public function register() {
        // Only boot WooCommerce integration when ecommerce automation is enabled
        // (trial or active license). Keeps core plugin working without Woo hooks.
        if ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() ) {
            return;
        }

        add_action( 'plugins_loaded', array( 'PMCPC_WooCommerce', 'init' ), 20 );
        add_action( 'plugins_loaded', array( 'PMCPC_Abandoned_Carts', 'init' ), 21 );
    }
}