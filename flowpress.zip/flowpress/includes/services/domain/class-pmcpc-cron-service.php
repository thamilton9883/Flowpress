<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';

class PMCPC_Cron_Service implements PMCPC_Service_Interface {

    /**
     * Core single-event hooks and their initial delays.
     *
     * @return array<string,int>
     */
    private function get_single_event_hooks() {
        return array(
            'pmcpc_process_email_queue'        => 60,
            'pmcpc_process_scheduled_campaigns' => 60,
        );
    }

    /**
     * Recurring maintenance hooks and their scheduling metadata.
     *
     * @return array<string,array<string,int|string>>
     */
    private function get_recurring_hooks() {
        return array(
            'pmcpc_tracking_logs_cleanup' => array(
                'schedule' => 'daily',
                'delay'    => 120,
            ),
            'pmcpc_inbox_cleanup' => array(
                'schedule' => 'daily',
                'delay'    => 180,
            ),
            'pmcpc_queue_retention_cleanup' => array(
                'schedule' => 'daily',
                'delay'    => 240,
            ),
            'pmcpc_recalculate_lifecycle_tags' => array(
                'schedule' => 'daily',
                'delay'    => 3600,
            ),
            'pmcpc_recalculate_health_tags' => array(
                'schedule' => 'pmcpc_every_six_hours',
                'delay'    => 7200,
            ),
        );
    }

    public function register() {
        add_filter( 'cron_schedules', array( $this, 'add_minute_cron_schedule' ) );

        // Self-healing scheduler: ensure our core cron hooks are always scheduled.
        // Runs lightweight checks on init and also has its own recurring watchdog.
        add_action( 'init', array( $this, 'ensure_core_cron_scheduled' ), 5 );

        // Scheduled events.
        add_action( 'pmcpc_process_email_queue', array( 'PMCPC_Queue_Processor', 'process_queue' ) );
        add_action( 'pmcpc_process_scheduled_campaigns', array( 'PMCPC_Campaign_Manager', 'process_scheduled_campaigns' ) );
        add_action( 'pmcpc_tracking_logs_cleanup', array( 'PMCPC_Tracking', 'cleanup_tracking_logs' ) );
        add_action( 'pmcpc_inbox_cleanup', array( 'PMCPC_Subscriber_Manager', 'cleanup_inbox_submissions' ) );
        add_action( 'pmcpc_queue_retention_cleanup', array( 'PMCPC_Queue_Processor', 'cleanup_queue_retention' ) );
        add_action( 'pmcpc_recalculate_lifecycle_tags', array( 'PMCPC_Subscriber_Manager', 'run_scheduled_lifecycle_recalculation' ) );
        add_action( 'pmcpc_recalculate_health_tags', array( 'PMCPC_Subscriber_Manager', 'run_scheduled_health_recalculation' ) );

        // Watchdog tick (recurring): re-schedules core single events if hosts clear them.
        add_action( 'pmcpc_cron_watchdog', array( $this, 'ensure_core_cron_scheduled' ) );
    }

    /**
     * Ensure our core cron hooks exist.
     *
     * The plugin uses single events for queue + scheduled campaigns (robust during updates).
     * Some hosts/plugins clear single events; this watchdog recreates them.
     */
    public function ensure_core_cron_scheduled() {
        $this->ensure_watchdog_scheduled();

        foreach ( $this->get_single_event_hooks() as $hook => $delay ) {
            $this->ensure_single_event_scheduled( $hook, $delay );
        }

        foreach ( $this->get_recurring_hooks() as $hook => $args ) {
            $this->ensure_recurring_event_scheduled( $hook, $args['schedule'], $args['delay'] );
        }

        if ( function_exists( 'pmcpc_sync_daily_commerce_update_schedule' ) ) {
            pmcpc_sync_daily_commerce_update_schedule();
        }
    }

    /**
     * Ensure the watchdog event exists.
     *
     * @return void
     */
    private function ensure_watchdog_scheduled() {
        if ( wp_next_scheduled( 'pmcpc_cron_watchdog' ) ) {
            return;
        }

        $schedule = $this->get_safe_recurring_schedule( 'pmcpc_every_five_minutes' );
        wp_schedule_event( time() + 300, $schedule, 'pmcpc_cron_watchdog' );
        $this->log_cron_recovery( 'pmcpc_cron_watchdog', 'recurring', $schedule );
    }

    /**
     * Ensure a single event hook exists.
     *
     * @param string $hook  Cron hook.
     * @param int    $delay Delay in seconds.
     * @return void
     */
    private function ensure_single_event_scheduled( $hook, $delay ) {
        if ( wp_next_scheduled( $hook ) ) {
            return;
        }

        wp_schedule_single_event( time() + absint( $delay ), $hook );
        $this->log_cron_recovery( $hook, 'single' );
    }

    /**
     * Ensure a recurring event hook exists.
     *
     * @param string $hook     Cron hook.
     * @param string $schedule Cron schedule name.
     * @param int    $delay    Delay in seconds.
     * @return void
     */
    private function ensure_recurring_event_scheduled( $hook, $schedule, $delay ) {
        if ( wp_next_scheduled( $hook ) ) {
            return;
        }

        $schedule = $this->get_safe_recurring_schedule( (string) $schedule );
        wp_schedule_event( time() + absint( $delay ), $schedule, $hook );
        $this->log_cron_recovery( $hook, 'recurring', $schedule );
    }

    /**
     * Return a registered recurring schedule, falling back safely if a host or
     * plugin loads cron before our custom interval is available.
     *
     * @param string $schedule Preferred schedule name.
     * @return string
     */
    private function get_safe_recurring_schedule( $schedule ) {
        $schedule  = (string) $schedule;
        $schedules = wp_get_schedules();

        if ( isset( $schedules[ $schedule ] ) ) {
            return $schedule;
        }

        if ( class_exists( 'PMCPC_Activator' ) ) {
            $schedules = PMCPC_Activator::add_cron_schedules( $schedules );
            if ( isset( $schedules[ $schedule ] ) ) {
                return $schedule;
            }
        }

        return isset( $schedules['hourly'] ) ? 'hourly' : 'daily';
    }

    /**
     * Log when the scheduler has to recreate a missing event.
     *
     * @param string $hook     Cron hook name.
     * @param string $type     Event type.
     * @param string $schedule Optional recurring schedule.
     * @return void
     */
    private function log_cron_recovery( $hook, $type, $schedule = '' ) {
        if ( ! class_exists( 'PMCPC_Logger' ) ) {
            return;
        }

        $context = array(
            'hook' => (string) $hook,
            'type' => (string) $type,
        );

        if ( '' !== $schedule ) {
            $context['schedule'] = (string) $schedule;
        }

        PMCPC_Logger::activity(
            sprintf(
                'Cron recovery re-scheduled %s.',
                (string) $hook
            ),
            $context
        );
    }

    /**
     * @param array $schedules
     * @return array
     */
    public function add_minute_cron_schedule( $schedules ) {
        if ( class_exists( 'PMCPC_Activator' ) ) {
            $schedules = PMCPC_Activator::add_cron_schedules( $schedules );
        } else {
            if ( ! isset( $schedules['pmcpc_every_minute'] ) ) {
                $schedules['pmcpc_every_minute'] = array(
                    'interval' => MINUTE_IN_SECONDS,
                    'display'  => __( 'Every Minute (PMCPC)', 'product-mailer-campaigns' ),
                );
            }
            if ( ! isset( $schedules['pmcpc_every_five_minutes'] ) ) {
                $schedules['pmcpc_every_five_minutes'] = array(
                    'interval' => 5 * MINUTE_IN_SECONDS,
                    'display'  => __( 'Every 5 Minutes (PMCPC)', 'product-mailer-campaigns' ),
                );
            }
            if ( ! isset( $schedules['pmcpc_every_six_hours'] ) ) {
                $schedules['pmcpc_every_six_hours'] = array(
                    'interval' => 6 * HOUR_IN_SECONDS,
                    'display'  => __( 'Every 6 Hours (PMCPC)', 'product-mailer-campaigns' ),
                );
            }
        }
        return $schedules;
    }
}
