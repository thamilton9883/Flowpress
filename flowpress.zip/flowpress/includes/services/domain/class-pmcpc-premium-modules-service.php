<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/licensing/class-pmcpc-license-manager.php';
require_once PMCPC_PLUGIN_DIR . 'includes/licensing/class-pmcpc-trial-manager.php';
require_once PMCPC_PLUGIN_DIR . 'includes/licensing/class-pmcpc-feature-manager.php';
require_once PMCPC_PLUGIN_DIR . 'includes/licensing/helpers.php';

class PMCPC_Premium_Modules_Service implements PMCPC_Service_Interface {

    public function register() {
        // Automation module (adds Automations + Segments pages).
        if ( pmcpc_features()->enabled( 'automation' ) ) {
            require_once PMCPC_PLUGIN_DIR . 'includes/modules/automation/init.php';
        }
    }
}
