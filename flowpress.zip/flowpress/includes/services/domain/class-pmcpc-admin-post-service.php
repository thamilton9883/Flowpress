<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';

class PMCPC_Admin_Post_Service implements PMCPC_Service_Interface {
    public function register() {
        add_action( 'admin_post_pmcpc_queue_campaign', array( 'PMCPC_Campaign_Manager', 'handle_queue_broadcast_action' ) );
        add_action( 'admin_post_pmcpc_test_campaign', array( 'PMCPC_Campaign_Manager', 'handle_test_campaign_action' ) );
        add_action( 'admin_post_pmcpc_send_test_email', array( 'PMCPC_Campaign_Manager', 'handle_send_test_email_action' ) );
        add_action( 'admin_post_pmcpc_delete_campaign', array( 'PMCPC_Campaign_Manager', 'handle_delete_campaign_action' ) );
        // Enable/disable campaigns from the list view.
        add_action( 'admin_post_pmcpc_toggle_campaign', array( 'PMCPC_Campaign_Manager', 'handle_toggle_campaign_action' ) );
        add_action( 'admin_post_pmcpc_delete_log', array( 'PMCPC_Email_Log', 'handle_delete_log_action' ) );
        add_action( 'admin_post_pmcpc_resend_email', array( 'PMCPC_Admin', 'handle_resend_email' ) );
        add_action( 'admin_post_pmcpc_export_subscribers', array( 'PMCPC_Subscriber_Manager', 'handle_export_action' ) );
        add_action( 'admin_post_pmcpc_import_subscribers', array( 'PMCPC_Subscriber_Manager', 'handle_import_action' ) );
        add_action( 'admin_post_pmcpc_delete_subscriber', array( 'PMCPC_Subscriber_Manager', 'handle_delete_subscriber_action' ) );
        add_action( 'admin_post_pmcpc_update_subscriber_status', array( 'PMCPC_Subscriber_Manager', 'handle_update_status_action' ) );

        // One-click setup: create starter automation campaigns and custom step workflows.
        add_action( 'admin_post_pmcpc_setup_store_automation', array( 'PMCPC_Automation_Quick_Setup', 'handle_setup_store_automation' ) );
        add_action( 'admin_post_pmcpc_create_step_workflow', array( 'PMCPC_Automation_Quick_Setup', 'handle_create_step_workflow' ) );

        // Admin AJAX helpers used by spam training tools.
        add_action( 'wp_ajax_pmcpc_add_spam_phrase', array( 'PMCPC_Admin', 'ajax_add_spam_phrase' ) );
        add_action( 'wp_ajax_pmcpc_test_spam', array( 'PMCPC_Admin', 'ajax_test_spam' ) );
    }
}
