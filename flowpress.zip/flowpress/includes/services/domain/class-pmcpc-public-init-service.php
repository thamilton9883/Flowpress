<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';

class PMCPC_Public_Init_Service implements PMCPC_Service_Interface {
    public function register() {
        add_action( 'init', array( 'PMCPC_Tracking', 'init' ) );
        add_action( 'wp_loaded', array( 'PMCPC_Shortcodes', 'handle_form_submission' ), 5 );
        add_action( 'init', array( 'PMCPC_Shortcodes', 'register_shortcodes' ) );
        add_action( 'init', array( 'PMCPC_Forms', 'init' ) );
    }
}
