<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';

class PMCPC_REST_Service implements PMCPC_Service_Interface {
    public function register() {
        // Prefer controller instance if container is available.
        $container = function_exists( 'pmcpc_container' ) ? pmcpc_container() : null;
        if ( $container && method_exists( $container, 'has' ) && $container->has( 'controller.rest' ) ) {
            $controller = $container->get( 'controller.rest' );
            add_action( 'rest_api_init', array( $controller, 'register_routes' ) );
            return;
        }

        // Back-compat fallback.
        add_action( 'rest_api_init', array( 'PMCPC_REST', 'register_routes' ) );
    }
}
