<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-modules.php';

/**
 * Boots optional add-on modules (popup, SMTP, etc.) in a structured way.
 *
 * This keeps the main plugin bootstrap clean and makes module boot order explicit.
 */
class PMCPC_Modules_Service implements PMCPC_Service_Interface {

    public function register() {
        if ( class_exists( 'PMCPC_Modules' ) ) {
            PMCPC_Modules::init();
        }
    }
}
