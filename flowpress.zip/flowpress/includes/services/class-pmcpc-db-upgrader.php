<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-service.php';

/**
 * Database migration runner.
 *
 * This runs on normal requests (plugins_loaded) so schema stays healthy even when hosts update
 * plugins by file replacement (activation hooks do not fire).
 *
 * Design goals:
 * - Idempotent (safe to run repeatedly)
 * - Additive migrations only (no destructive changes)
 * - Back-compat with legacy `pmcpc_db_version` option
 */
class PMCPC_DB_Upgrader_Service implements PMCPC_Service_Interface {

    /**
     * Option name for schema version tracking.
     */
    const OPTION_SCHEMA_VERSION = 'pmcpc_schema_version';

    public function register() {
        add_action( 'plugins_loaded', array( $this, 'maybe_upgrade_database' ), 2 );
    }

    /**
     * Normalize a schema version like YYYY-MM-DD-NN into an integer for comparison.
     *
     * @param string $v
     * @return int
     */
    protected function normalize_version( $v ) {
        $v = (string) $v;
        if ( '' === $v ) { return 0; }
        // Strip non-digits.
        $digits = preg_replace( '/[^0-9]/', '', $v );
        return (int) $digits;
    }

    /**
     * Run any required migrations.
     */
    public function maybe_upgrade_database() {
        if ( ! class_exists( 'PMCPC_Activator' ) ) {
            return;
        }

        $target = (string) PMCPC_Activator::DB_VERSION;

        // Read installed version from new option first, then fall back to legacy.
        $installed = (string) get_option( self::OPTION_SCHEMA_VERSION, '' );
        if ( '' === $installed ) {
            $installed = (string) get_option( 'pmcpc_db_version', '' );
        }

        $installed_n = $this->normalize_version( $installed );
        $target_n    = $this->normalize_version( $target );

        // Always run safe checks; they are idempotent and also fix "version says ok but schema isn't".
        // 1) Ensure baseline tables exist (CREATE TABLE IF NOT EXISTS).
        PMCPC_Activator::activate();

        // 2) Run targeted additive migrations / column ensures.
        PMCPC_Activator::maybe_upgrade();

        // Version bookkeeping.
        if ( $installed_n < $target_n ) {
            update_option( self::OPTION_SCHEMA_VERSION, $target, false );
            update_option( 'pmcpc_db_version', $target, false ); // legacy back-compat
        } else {
            // If versions match but schema was repaired (common), still keep them aligned.
            if ( $target !== $installed ) {
                update_option( self::OPTION_SCHEMA_VERSION, $target, false );
                update_option( 'pmcpc_db_version', $target, false );
            }
        }
    }
}
