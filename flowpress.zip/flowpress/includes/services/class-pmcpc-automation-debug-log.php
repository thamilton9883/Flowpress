<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Structured automation debug log for testing and trigger diagnostics.
 */
class PMCPC_Automation_Debug_Log {

    const OPTION_KEY = 'pmcpc_automation_debug_log_v1';
    const MAX_ITEMS  = 250;

    /**
     * Store one structured log item.
     *
     * @param string $event_type
     * @param string $message
     * @param array  $context
     * @return void
     */
    public static function log( $event_type, $message, $context = array() ) {
        $event_type = sanitize_key( (string) $event_type );
        $message    = is_string( $message ) ? trim( $message ) : '';

        if ( '' === $message ) {
            return;
        }

        $allowed_context = array();
        if ( is_array( $context ) ) {
            foreach ( $context as $key => $value ) {
                $key = sanitize_key( (string) $key );
                if ( '' === $key ) {
                    continue;
                }
                if ( is_scalar( $value ) || null === $value ) {
                    $allowed_context[ $key ] = (string) $value;
                } elseif ( is_array( $value ) ) {
                    $allowed_context[ $key ] = wp_json_encode( $value );
                }
            }
        }

        $items = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $items ) ) {
            $items = array();
        }

        array_unshift(
            $items,
            array(
                't' => (int) current_time( 'timestamp' ),
                'e' => $event_type,
                'm' => $message,
                'c' => array_slice( $allowed_context, 0, 12, true ),
            )
        );

        update_option( self::OPTION_KEY, array_slice( $items, 0, self::MAX_ITEMS ), false );
    }

    /**
     * Return recent items.
     *
     * Supported filters: email, trigger, limit.
     *
     * @param array $args
     * @return array
     */
    public static function get_items( $args = array() ) {
        $items = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $items ) ) {
            $items = array();
        }

        $email   = ! empty( $args['email'] ) ? strtolower( sanitize_email( (string) $args['email'] ) ) : '';
        $trigger = ! empty( $args['trigger'] ) ? sanitize_key( (string) $args['trigger'] ) : '';
        $limit   = ! empty( $args['limit'] ) ? absint( $args['limit'] ) : 25;
        if ( $limit <= 0 ) {
            $limit = 25;
        }

        $filtered = array();
        foreach ( $items as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $context = isset( $item['c'] ) && is_array( $item['c'] ) ? $item['c'] : array();
            if ( '' !== $email ) {
                $context_email = isset( $context['email'] ) ? strtolower( (string) $context['email'] ) : '';
                $message_email = isset( $item['m'] ) ? strtolower( (string) $item['m'] ) : '';
                if ( $context_email !== $email && false === strpos( $message_email, $email ) ) {
                    continue;
                }
            }
            if ( '' !== $trigger ) {
                $context_trigger = isset( $context['trigger'] ) ? sanitize_key( (string) $context['trigger'] ) : '';
                $event_type      = isset( $item['e'] ) ? sanitize_key( (string) $item['e'] ) : '';
                if ( $context_trigger !== $trigger && $event_type !== $trigger ) {
                    continue;
                }
            }
            $filtered[] = $item;
            if ( count( $filtered ) >= $limit ) {
                break;
            }
        }

        return $filtered;
    }
}
