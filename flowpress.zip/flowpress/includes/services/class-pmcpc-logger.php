<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Shared plugin logger for activity, debug, and recoverable error events.
 */
class PMCPC_Logger {

    const OPTION_KEY = 'pmcpc_system_log_v1';
    const MAX_ITEMS  = 100;

    /**
     * Record an activity-feed message.
     *
     * @param string $message Activity message.
     * @param array  $context Optional context.
     * @return void
     */
    public static function activity( $message, $context = array() ) {
        if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
            PMCPC_Activity_Feed::log( (string) $message, self::sanitize_context( $context, 8 ) );
        }
    }

    /**
     * Record a structured debug event.
     *
     * @param string $channel Debug channel.
     * @param string $message Debug message.
     * @param array  $context Optional context.
     * @return void
     */
    public static function debug( $channel, $message, $context = array() ) {
        if ( class_exists( 'PMCPC_Automation_Debug_Log' ) ) {
            PMCPC_Automation_Debug_Log::log(
                sanitize_key( (string) $channel ),
                (string) $message,
                self::sanitize_context( $context, 12 )
            );
        }
    }

    /**
     * Record a recoverable plugin error.
     *
     * @param string $channel Error channel.
     * @param string $message Error message.
     * @param array  $context Optional context.
     * @return void
     */
    public static function error( $channel, $message, $context = array() ) {
        $channel = sanitize_key( (string) $channel );
        $message = is_string( $message ) ? trim( $message ) : '';

        if ( '' === $message ) {
            return;
        }

        $items = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $items ) ) {
            $items = array();
        }

        $context = self::sanitize_context( $context, 12 );

        array_unshift(
            $items,
            array(
                't' => (int) current_time( 'timestamp' ),
                'l' => 'error',
                'h' => $channel,
                'm' => $message,
                'c' => $context,
            )
        );

        update_option( self::OPTION_KEY, array_slice( $items, 0, self::MAX_ITEMS ), false );

        self::debug( $channel . '_error', $message, $context );

        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( sprintf( 'PMCPC [%s] %s', $channel ? $channel : 'general', $message ) );
        }
    }

    /**
     * Record an exception with normalized context.
     *
     * @param string    $channel   Error channel.
     * @param string    $message   Friendly error summary.
     * @param Throwable $exception Exception instance.
     * @param array     $context   Optional context.
     * @return void
     */
    public static function exception( $channel, $message, Throwable $exception, $context = array() ) {
        $context['exception_message'] = $exception->getMessage();
        $context['exception_type']    = get_class( $exception );
        $context['exception_file']    = $exception->getFile();
        $context['exception_line']    = $exception->getLine();

        self::error( $channel, $message, $context );
    }

    /**
     * Return recent plugin error items.
     *
     * @param int $limit Max number of items.
     * @return array
     */
    public static function get_items( $limit = 25 ) {
        $items = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $items ) ) {
            $items = array();
        }

        $limit = absint( $limit );
        if ( $limit <= 0 ) {
            $limit = 25;
        }

        return array_slice( $items, 0, $limit );
    }

    /**
     * Sanitize log context for option storage.
     *
     * @param array $context Context values.
     * @param int   $limit   Maximum keys to keep.
     * @return array
     */
    private static function sanitize_context( $context, $limit ) {
        if ( ! is_array( $context ) ) {
            return array();
        }

        $sanitized = array();

        foreach ( $context as $key => $value ) {
            $key = sanitize_key( (string) $key );
            if ( '' === $key ) {
                continue;
            }

            if ( is_scalar( $value ) || null === $value ) {
                $sanitized[ $key ] = (string) $value;
            } elseif ( is_array( $value ) ) {
                $sanitized[ $key ] = wp_json_encode( $value );
            } elseif ( is_object( $value ) && method_exists( $value, '__toString' ) ) {
                $sanitized[ $key ] = (string) $value;
            }

            if ( count( $sanitized ) >= $limit ) {
                break;
            }
        }

        return $sanitized;
    }
}
