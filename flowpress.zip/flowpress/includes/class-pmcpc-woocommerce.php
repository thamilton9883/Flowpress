<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PMCPC_WooCommerce {

    public static function init() {
        // My Account: Email Settings tab.
        add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'add_account_menu_item' ), 20 );
        add_action( 'init', array( __CLASS__, 'register_account_endpoint' ) );
        add_action( 'woocommerce_account_email-preferences_endpoint', array( __CLASS__, 'render_account_email_preferences' ) );

        add_filter( 'woocommerce_checkout_fields', array( __CLASS__, 'add_checkout_opt_in_field' ) );
        add_action( 'woocommerce_checkout_update_order_meta', array( __CLASS__, 'save_checkout_opt_in' ), 10, 2 );
        add_action( 'woocommerce_thankyou', array( __CLASS__, 'handle_order' ), 10, 1 );
        add_action( 'woocommerce_review_order_before_submit', array( __CLASS__, 'force_opt_in_field' ) );
        add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'handle_order_completed' ), 10, 1 );

        // Registration form newsletter opt-in.
        add_action( 'woocommerce_register_form', array( __CLASS__, 'render_registration_opt_in_field' ) );
        add_action( 'woocommerce_created_customer', array( __CLASS__, 'handle_registration_opt_in' ), 10, 3 );
    }

    public static function add_checkout_opt_in_field( $fields ) {
        $setting = PMCPC_Settings::get( 'wc_opt_in_default_checked', 'yes' );
        $checked_default = ( $setting === 'yes' );

        $fields['billing']['pmcpc_opt_in'] = array(
            'type'     => 'checkbox',
            'label'    => __( 'Email me product updates and special offers', 'product-mailer-campaigns' ),
            'required' => false,
            'default'  => $checked_default ? 1 : 0,
        );
        return $fields;
    }

	// Checkout processing comes from WooCommerce checkout request.
	// Nonces are handled by WooCommerce; this plugin only reads a single checkbox.
	// phpcs:disable WordPress.Security.NonceVerification.Missing
	public static function save_checkout_opt_in( $order_id, $data ) {
		// WooCommerce checkout includes its own nonce verification.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['pmcpc_opt_in'] ) ) {
            update_post_meta( $order_id, '_pmcpc_opt_in', 'yes' );
        } else {
            update_post_meta( $order_id, '_pmcpc_opt_in', 'no' );
	}
	// phpcs:enable WordPress.Security.NonceVerification.Missing
    }

    public static function handle_order( $order_id ) {
        if ( ! $order_id ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $opt_in = $order->get_meta( '_pmcpc_opt_in' );
        if ( 'yes' !== $opt_in ) {
            return;
        }

        $email = $order->get_billing_email();
        if ( ! $email || ! is_email( $email ) ) {
            return;
        }

        $first_name = $order->get_billing_first_name();
        $last_name  = $order->get_billing_last_name();

        // Origin tag so we can see this came from checkout.
        $tags = array( 'origin:checkout' );

        $is_new = false;
        if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'handle_opt_in' ) ) {
            // Logged-in customers: single opt-in.
            $is_logged_in = is_user_logged_in();

            if ( $is_logged_in ) {
                $is_new = PMCPC_Subscriber_Manager::handle_opt_in(
                    array(
                        'email'      => $email,
                        'first_name' => $first_name,
                        'last_name'  => $last_name,
                        'context'    => 'checkout',
                        'status'     => 'active',
                        'tags'       => $tags,
                    )
                );
            } else {
                // Guests: respect global guest double opt-in setting.
                $guest_double_optin = 'yes';
                if ( class_exists( 'PMCPC_Settings' ) ) {
                    $guest_double_optin = PMCPC_Settings::get( 'guest_double_optin', 'yes' );
                }

                if ( 'yes' !== $guest_double_optin ) {
                    $is_new = PMCPC_Subscriber_Manager::handle_opt_in(
                        array(
                            'email'      => $email,
                            'first_name' => $first_name,
                            'last_name'  => $last_name,
                            'context'    => 'checkout',
                            'status'     => 'active',
                            'tags'       => $tags,
                        )
                    );
                } else {
                    // Double opt-in for guest checkout: create pending subscriber and send confirmation email.
                    PMCPC_Subscriber_Manager::handle_opt_in(
                        array(
                            'email'      => $email,
                            'first_name' => $first_name,
                            'last_name'  => $last_name,
                            'context'    => 'checkout',
                            'status'     => 'pending',
                            'tags'       => $tags,
                        )
                    );

                    // Build confirmation URL (token-based, robust across email clients).
                    $confirm_url = '';
                    if ( class_exists( 'PMCPC_Subscriber_Manager' ) ) {
                        $confirm_url = PMCPC_Subscriber_Manager::build_double_optin_confirm_url( $email );
                    }

                    // Fallback to legacy nonce link if token generation is unavailable for any reason.
                    if ( empty( $confirm_url ) ) {
                        $confirm_url = wp_nonce_url(
                            add_query_arg(
                                array(
                                    'pmcpc_confirm' => $email,
                                ),
                                home_url( '/' )
                            ),
                            'pmcpc_confirm_' . $email
                        );
                        $confirm_url = html_entity_decode( $confirm_url, ENT_QUOTES, 'UTF-8' );
                    }

                    $subject_default = __( 'Confirm your subscription', 'product-mailer-campaigns' );
                    $subject         = apply_filters( 'pmcpc_double_opt_in_subject', $subject_default );

	                    $message_default = sprintf(
	                        /* translators: %s: confirmation URL. */
	                        __( "Thanks for subscribing!\n\nPlease confirm your email address by clicking the link below:\n\n%s\n\nIf you did not request this, you can ignore this message.", 'product-mailer-campaigns' ),
	                        $confirm_url
	                    );

                    $message = apply_filters( 'pmcpc_double_opt_in_message', $message_default, $confirm_url );

                    $headers   = array();
                    $headers[] = 'Content-Type: text/plain; charset=UTF-8';

                    $from_name  = get_bloginfo( 'name' );
                    $from_email = get_option( 'admin_email' );
                    if ( class_exists( 'PMCPC_Settings' ) ) {
                        $from_name_setting  = PMCPC_Settings::get( 'from_name_default', '' );
                        $from_email_setting = PMCPC_Settings::get( 'from_email_default', '' );
                        if ( ! empty( $from_name_setting ) ) {
                            $from_name = $from_name_setting;
                        }
                        if ( ! empty( $from_email_setting ) ) {
                            $from_email = $from_email_setting;
                        }
                    }

                    $from_email = sanitize_email( $from_email );
                    if ( ! $from_email ) {
                        $from_email = get_option( 'admin_email' );
                    }

                    $headers[] = 'From: ' . sprintf( '%s <%s>', wp_specialchars_decode( $from_name, ENT_QUOTES ), $from_email );
                    $headers[] = 'Reply-To: ' . $from_email;
                    $headers[] = 'Return-Path: ' . $from_email;

					// Throttle double opt-in emails to avoid repeat sends for the same email.
					$throttle_key     = 'pmcpc_optin_sent_' . md5( strtolower( $email ) );
					$throttle_seconds = (int) apply_filters( 'pmcpc_optin_resend_throttle_seconds', 21600 ); // 6 hours.
					if ( $throttle_seconds < 60 ) {
						$throttle_seconds = 60;
					}

					if ( false === get_transient( $throttle_key ) ) {
						wp_mail( $email, $subject, $message, $headers );
						set_transient( $throttle_key, 1, $throttle_seconds );
					}
                }
            }
        }

        if ( $is_new && class_exists( 'PMCPC_Campaign_Manager' ) ) {
            PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );
        }

        // Fire post-purchase automations (e.g., thank-you series, cross-sell)
        // only while the WooCommerce premium automation layer is active.
        if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
            PMCPC_Campaign_Manager::send_post_purchase_campaigns_for_subscriber_email( $email );
        }
    }



    /**
     * Handle WooCommerce order completion – used for lifecycle tag updates.
     *
     * This runs whenever an order is marked as completed.
     *
     * @param int $order_id Order ID.
     * @return void
     */
    public static function handle_order_completed( $order_id ) {
        if ( ! $order_id || ! function_exists( 'wc_get_order' ) ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $email = $order->get_billing_email();
        if ( ! $email || ! is_email( $email ) ) {
            return;
        }

        if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'update_lifecycle_for_email' ) ) {
            PMCPC_Subscriber_Manager::update_lifecycle_for_email( $email );
        }
    }

    /**
     * Force the PMCPC opt-in checkbox to display near the Place order button.
     */
    public static function force_opt_in_field() {

        // Read the same setting as the admin option: 'yes' (pre-checked) or 'no'.
        $setting = PMCPC_Settings::get( 'wc_opt_in_default_checked', 'yes' );
        $default_checked = ( $setting === 'yes' );

        // If the form was already posted, keep the user's choice; otherwise use the default.
		// WooCommerce account/checkout flows already include nonce verification.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$current_value = isset( $_POST['pmcpc_opt_in'] ) ? 1 : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! isset( $_POST['pmcpc_opt_in'] ) ) {
            $current_value = $default_checked ? 1 : 0;
        }

        echo '<p class="form-row form-row-wide pmcpc-opt-in-forced" style="margin-top:15px;">';

        if ( function_exists( 'woocommerce_form_field' ) ) {
            woocommerce_form_field(
                'pmcpc_opt_in',
                array(
                    'type'     => 'checkbox',
                    'label'    => __( 'Email me product updates and special offers', 'product-mailer-campaigns' ),
                    'required' => false,
                ),
                $current_value
            );
        }

        echo '</p>';
    }



    /**
     * Render opt-in checkbox on WooCommerce registration form.
     */
    public static function render_registration_opt_in_field() {
        // Allow disabling from settings.
        if ( class_exists( 'PMCPC_Settings' ) ) {
            $enabled = PMCPC_Settings::get( 'wc_register_opt_in_enabled', 'yes' );
            if ( 'yes' !== $enabled ) {
                return;
            }
        }

        // Re-use the same default setting as checkout for whether the box is pre-checked.
        $checked_default = true;
        if ( class_exists( 'PMCPC_Settings' ) ) {
            $checked_default = ( 'yes' === PMCPC_Settings::get( 'wc_opt_in_default_checked', 'yes' ) );
        }
        ?>
        <p class="form-row pmcpc-opt-in">
            <label for="pmcpc_opt_in_registration">
                <input type="checkbox"
                       name="pmcpc_opt_in"
                       id="pmcpc_opt_in_registration"
                       value="1"
                       <?php checked( $checked_default ); ?> />
                <?php esc_html_e( 'Email me product updates and special offers', 'product-mailer-campaigns' ); ?>
            </label>
        </p>
        <?php
    }

    /**
     * Handle opt-in when a WooCommerce customer account is created.
     *
     * @param int   $customer_id        New customer ID.
     * @param array $new_customer_data  Registration data.
     * @param bool  $password_generated Whether a password was auto generated.
     */
    public static function handle_registration_opt_in( $customer_id, $new_customer_data, $password_generated ) {
		// Only proceed if the user actually opted in.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( empty( $_POST['pmcpc_opt_in'] ) ) {
            return;
        }

        if ( ! class_exists( 'PMCPC_Subscriber_Manager' ) || ! method_exists( 'PMCPC_Subscriber_Manager', 'handle_opt_in' ) ) {
            return;
        }

        $user = get_userdata( $customer_id );
        if ( ! $user ) {
            return;
        }

        $email      = $user->user_email;
        $first_name = ! empty( $new_customer_data['first_name'] ) ? $new_customer_data['first_name'] : $user->first_name;
        $last_name  = ! empty( $new_customer_data['last_name'] ) ? $new_customer_data['last_name'] : $user->last_name;

        if ( ! $email || ! is_email( $email ) ) {
            return;
        }

        // Tag to show origin = WooCommerce registration.
        // Also add a non-origin source tag so the Subscribers UI can classify it under "Source tags".
        $tags = array( 'origin:wc-registration', 'wc-registration' );

        // Treat as logged-in path: single opt-in, status active.
        $is_new = PMCPC_Subscriber_Manager::handle_opt_in(
            array(
                'email'      => $email,
                'first_name' => $first_name,
                'last_name'  => $last_name,
                'context'    => 'registration',
                'status'     => 'active',
                'tags'       => $tags,
            )
        );

        if ( $is_new && class_exists( 'PMCPC_Campaign_Manager' ) ) {
            PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );
        }
    }


    /**
     * Register the WooCommerce My Account endpoint for email preferences.
     */
    public static function register_account_endpoint() {
        if ( function_exists( 'add_rewrite_endpoint' ) ) {
            add_rewrite_endpoint( 'email-preferences', EP_ROOT | EP_PAGES );
        }
    }

    /**
     * Add the "Email preferences" item to the WooCommerce My Account menu.
     *
     * @param array $items Menu items.
     * @return array
     */
    public static function add_account_menu_item( $items ) {
        if ( isset( $items['email-preferences'] ) ) {
            return $items;
        }

        // Insert after "Dashboard" if present, otherwise append.
        $new = array();
        $inserted = false;
        foreach ( $items as $key => $label ) {
            $new[ $key ] = $label;
            if ( 'dashboard' === $key ) {
                $new['email-preferences'] = __( 'Email preferences', 'product-mailer-campaigns' );
                $inserted = true;
            }
        }
        if ( ! $inserted ) {
            $new['email-preferences'] = __( 'Email preferences', 'product-mailer-campaigns' );
        }
        return $new;
    }

    /**
     * Render the WooCommerce My Account endpoint content.
     */
    public static function render_account_email_preferences() {
        echo do_shortcode( '[pmcpc_email_preferences]' );
    }


}
