<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PMCPC_SMTP {

    const OPTION_KEY = 'pmcpc_smtp_settings';

    /**
     * Runtime-only settings used by the admin SMTP test.
     *
     * @var array|null
     */
    protected static $settings_override = null;

    public static function init() {
        add_action( 'admin_init', array( __CLASS__, 'handle_settings_save' ) );
        add_action( 'phpmailer_init', array( __CLASS__, 'configure_phpmailer' ) );
        add_filter( 'wp_mail_from', array( __CLASS__, 'filter_mail_from' ), 20 );
        add_filter( 'wp_mail_from_name', array( __CLASS__, 'filter_mail_from_name' ), 20 );
        add_action( 'wp_ajax_pmcpc_test_smtp', array( __CLASS__, 'ajax_test_smtp' ) );
    }

    protected static function get_default_settings() {
        return array(
            'enabled'    => 0,
            'host'       => '',
            'port'       => 587,
            'encryption' => 'tls', // none|ssl|tls
            'auth'       => 1,
            'username'   => '',
            'password'   => '',
            'from_email' => '',
            'from_name'  => '',
        );
    }

    public static function get_settings() {
        $settings = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }

        return wp_parse_args( $settings, self::get_default_settings() );
    }

    protected static function sanitize_settings_array( $raw ) {
        if ( ! is_array( $raw ) ) {
            $raw = array();
        }

        $enc = isset( $raw['encryption'] ) ? sanitize_key( (string) $raw['encryption'] ) : 'tls';
        if ( ! in_array( $enc, array( 'none', 'ssl', 'tls' ), true ) ) {
            $enc = 'tls';
        }

        $port = isset( $raw['port'] ) ? absint( $raw['port'] ) : 587;
        if ( $port < 1 || $port > 65535 ) {
            $port = 587;
        }

        return wp_parse_args(
            array(
                'enabled'    => ! empty( $raw['enabled'] ) && 'no' !== $raw['enabled'] ? 1 : 0,
                'host'       => isset( $raw['host'] ) ? sanitize_text_field( (string) $raw['host'] ) : '',
                'port'       => $port,
                'encryption' => $enc,
                'auth'       => ! empty( $raw['auth'] ) && 'no' !== $raw['auth'] ? 1 : 0,
                'username'   => isset( $raw['username'] ) ? sanitize_text_field( (string) $raw['username'] ) : '',
                // Password is stored as-is so users can paste app passwords; do not mangle.
                'password'   => isset( $raw['password'] ) ? (string) $raw['password'] : '',
                'from_email' => isset( $raw['from_email'] ) ? sanitize_email( (string) $raw['from_email'] ) : '',
                'from_name'  => isset( $raw['from_name'] ) ? sanitize_text_field( (string) $raw['from_name'] ) : '',
            ),
            self::get_default_settings()
        );
    }

    protected static function get_runtime_settings() {
        if ( is_array( self::$settings_override ) ) {
            return wp_parse_args( self::$settings_override, self::get_default_settings() );
        }

        return self::get_settings();
    }

    protected static function set_runtime_settings_override( $settings ) {
        self::$settings_override = is_array( $settings ) ? $settings : null;
    }

    public static function handle_settings_save() {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $nonce = isset( $_POST['pmcpc_settings_nonce'] ) && ! is_array( $_POST['pmcpc_settings_nonce'] )
            ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_settings_nonce'] ) )
            : '';

        if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'pmcpc_save_settings' ) ) {
            return;
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per-field below.
        $raw_settings = isset( $_POST['pmcpc_smtp_settings'] ) ? wp_unslash( $_POST['pmcpc_smtp_settings'] ) : array();
        if ( empty( $raw_settings ) || ! is_array( $raw_settings ) ) {
            return;
        }

        $settings = self::sanitize_settings_array( $raw_settings );

        update_option( self::OPTION_KEY, $settings );
    }

    public static function configure_phpmailer( $phpmailer ) {
        if ( ! is_object( $phpmailer ) || ! method_exists( $phpmailer, 'isSMTP' ) ) {
            return;
        }

        $settings = self::get_runtime_settings();
        if ( empty( $settings['enabled'] ) || empty( $settings['host'] ) ) {
            return;
        }

        $phpmailer->isSMTP();
        $phpmailer->Host = $settings['host'];
        $phpmailer->Port = (int) $settings['port'];
        $phpmailer->Timeout = 15;

        if ( 'ssl' === $settings['encryption'] ) {
            $phpmailer->SMTPSecure = 'ssl';
        } elseif ( 'tls' === $settings['encryption'] ) {
            $phpmailer->SMTPSecure = 'tls';
        } else {
            $phpmailer->SMTPSecure = '';
            if ( property_exists( $phpmailer, 'SMTPAutoTLS' ) ) {
                $phpmailer->SMTPAutoTLS = false;
            }
        }

        $phpmailer->SMTPAuth = ! empty( $settings['auth'] );

        if ( $phpmailer->SMTPAuth ) {
            $phpmailer->Username = $settings['username'];
            $phpmailer->Password = $settings['password'];
        }

        // Ensure a valid From is set. Many SMTP servers reject messages where the From
        // doesn't align with the authenticated mailbox. If the From email setting is empty,
        // fall back to the SMTP username (when it looks like an email address).
        $from_email = '';
        if ( ! empty( $settings['from_email'] ) && is_email( $settings['from_email'] ) ) {
            $from_email = $settings['from_email'];
        } elseif ( ! empty( $settings['username'] ) && is_email( $settings['username'] ) ) {
            $from_email = $settings['username'];
        }

        if ( ! empty( $from_email ) ) {
            $from_name = ! empty( $settings['from_name'] ) ? $settings['from_name'] : get_bloginfo( 'name' );
            $phpmailer->setFrom( $from_email, $from_name, false );
        }
    }

    public static function filter_mail_from( $email ) {
        $settings = self::get_runtime_settings();
        if ( ! empty( $settings['enabled'] ) ) {
            if ( ! empty( $settings['from_email'] ) && is_email( $settings['from_email'] ) ) {
                return $settings['from_email'];
            }
            if ( ! empty( $settings['username'] ) && is_email( $settings['username'] ) ) {
                return $settings['username'];
            }
        }

        return $email;
    }

    public static function filter_mail_from_name( $name ) {
        $settings = self::get_runtime_settings();
        if ( ! empty( $settings['enabled'] ) && ! empty( $settings['from_name'] ) ) {
            return $settings['from_name'];
        }

        return $name;
    }

    public static function ajax_test_smtp() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to test SMTP settings.', 'product-mailer-campaigns' ) ), 403 );
        }

        $nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'pmcpc_test_smtp' ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh the page and try again.', 'product-mailer-campaigns' ) ), 403 );
        }

        $recipient = isset( $_POST['recipient'] ) ? sanitize_email( (string) wp_unslash( $_POST['recipient'] ) ) : '';
        if ( empty( $recipient ) ) {
            $recipient = sanitize_email( (string) get_option( 'admin_email' ) );
        }

        if ( ! is_email( $recipient ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter a valid test recipient email address.', 'product-mailer-campaigns' ) ) );
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized by sanitize_settings_array().
        $raw_settings = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : array();
        $settings     = self::sanitize_settings_array( $raw_settings );

        if ( empty( $settings['enabled'] ) ) {
            wp_send_json_error( array( 'message' => __( 'Enable custom SMTP before sending a test email.', 'product-mailer-campaigns' ) ) );
        }

        if ( empty( $settings['host'] ) ) {
            wp_send_json_error( array( 'message' => __( 'Enter an SMTP host before sending a test email.', 'product-mailer-campaigns' ) ) );
        }

        if ( ! empty( $settings['auth'] ) && ( '' === $settings['username'] || '' === $settings['password'] ) ) {
            wp_send_json_error( array( 'message' => __( 'Enter the SMTP username and password before sending a test email.', 'product-mailer-campaigns' ) ) );
        }

        $mail_error    = null;
        $capture_error = function( $wp_error ) use ( &$mail_error ) {
            if ( is_wp_error( $wp_error ) ) {
                $mail_error = $wp_error;
            }
        };

        self::set_runtime_settings_override( $settings );
        add_action( 'wp_mail_failed', $capture_error, 10, 1 );

        $subject = sprintf(
            /* translators: %s: site name. */
            __( 'FlowPress SMTP test from %s', 'product-mailer-campaigns' ),
            wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES )
        );
        $body = sprintf(
            "%s\n\n%s\n%s\n%s\n%s\n",
            __( 'This is a test email sent by FlowPress using the Custom SMTP settings currently shown on the Settings page.', 'product-mailer-campaigns' ),
            sprintf( __( 'Site: %s', 'product-mailer-campaigns' ), home_url() ),
            sprintf( __( 'SMTP host: %1$s:%2$d', 'product-mailer-campaigns' ), $settings['host'], (int) $settings['port'] ),
            sprintf( __( 'Encryption: %s', 'product-mailer-campaigns' ), strtoupper( (string) $settings['encryption'] ) ),
            sprintf( __( 'Sent at: %s', 'product-mailer-campaigns' ), gmdate( 'Y-m-d H:i:s' ) . ' UTC' )
        );

        $sent = wp_mail(
            $recipient,
            $subject,
            $body,
            array( 'Content-Type: text/plain; charset=UTF-8' )
        );

        remove_action( 'wp_mail_failed', $capture_error, 10 );
        self::set_runtime_settings_override( null );

        if ( ! $sent ) {
            $message = __( 'The test email could not be sent.', 'product-mailer-campaigns' );
            if ( is_wp_error( $mail_error ) ) {
                $message .= ' ' . $mail_error->get_error_message();
            }

            wp_send_json_error(
                array(
                    'message' => $message,
                    'details' => array(
                        'host'       => $settings['host'],
                        'port'       => (int) $settings['port'],
                        'encryption' => $settings['encryption'],
                        'recipient'  => $recipient,
                    ),
                )
            );
        }

        wp_send_json_success(
            array(
                'message' => sprintf(
                    /* translators: %s: recipient email. */
                    __( 'Test email sent to %s. Please check the inbox and spam folder.', 'product-mailer-campaigns' ),
                    $recipient
                ),
                'details' => array(
                    'host'       => $settings['host'],
                    'port'       => (int) $settings['port'],
                    'encryption' => $settings['encryption'],
                    'recipient'  => $recipient,
                ),
            )
        );
    }
}
