<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Centralized compatibility + hardening layer.
 *
 * Goal: keep edge-case fixes out of feature classes and the bootstrap file,
 * so the codebase stays coherent and easier to maintain.
 */
class PMCPC_Compat {

    public static function init() {
        // PHP 8.1+ hardening: prevent wp_safe_redirect()/set_url_scheme() from receiving NULL.
        add_filter( 'wp_redirect', array( __CLASS__, 'coerce_null_redirect_location' ), 1, 2 );

        // PHP 8.1+ hardening: if any script/style src becomes null, WordPress core's
        // set_url_scheme() can emit deprecation warnings. Coerce null to empty string.
        add_filter( 'script_loader_src', array( __CLASS__, 'coerce_null_loader_src' ), 1, 2 );
        add_filter( 'style_loader_src', array( __CLASS__, 'coerce_null_loader_src' ), 1, 2 );
    }

    /**
     * Coerce any non-string/empty redirect target to a safe default.
     *
     * @param mixed $location Redirect target.
     * @param int   $status   HTTP status.
     * @return string
     */
    public static function coerce_null_redirect_location( $location, $status ) {
        if ( ! is_string( $location ) || '' === $location ) {
            return admin_url();
        }
        return $location;
    }

    /**
     * Coerce null loader src to a string to avoid PHP 8.1 deprecations.
     *
     * @param mixed  $src
     * @param string $handle
     * @return string
     */
    public static function coerce_null_loader_src( $src, $handle ) {
        return is_string( $src ) ? $src : '';
    }
}
