<?php
// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once PMCPC_PLUGIN_DIR . 'includes/campaign/class-pmcpc-campaigns-controller.php';

/**
 * Back-compat façade.
 *
 * Historically, the plugin used PMCPC_Campaign_Manager directly. We keep the
 * class name intact, but the implementation now lives in an instance-first
 * controller suitable for DI.
 */
class PMCPC_Campaign_Manager extends PMCPC_Campaigns_Controller {}
