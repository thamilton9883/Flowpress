<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function pmcpc_license() {
    static $lm = null;
    if ( null === $lm ) {
        $lm = new PMCPC_License_Manager();
    }
    return $lm;
}

function pmcpc_trial() {
    static $tm = null;
    if ( null === $tm ) {
        $tm = new PMCPC_Trial_Manager();
    }
    return $tm;
}

function pmcpc_features() {
    static $fm = null;
    if ( null === $fm ) {
        $fm = new PMCPC_Feature_Manager( pmcpc_license(), pmcpc_trial() );
    }
    return $fm;
}

/**
 * True when WooCommerce is installed and the WooCommerce automation layer is enabled
 * via trial or license.
 */
function pmcpc_wc_automation_enabled() {
    return class_exists( 'WooCommerce' ) && function_exists( 'pmcpc_features' ) && pmcpc_features()->enabled( 'woocommerce' );
}


/**
 * True when WooCommerce is installed, even if premium automation is unavailable.
 *
 * This is used for capture, attribution, metrics, and upgrade-facing UI that should
 * remain visible after a trial ends.
 */
function pmcpc_wc_metrics_enabled() {
    return class_exists( 'WooCommerce' );
}

/**
 * True when the given trigger belongs to the paid WooCommerce automation layer.
 *
 * These triggers may remain visible in the UI, but execution must be blocked when
 * the trial/license is inactive.
 *
 * @param string $trigger Trigger key.
 * @return bool
 */
function pmcpc_is_premium_wc_trigger( $trigger ) {
    $trigger = sanitize_key( (string) $trigger );

    $premium_triggers = array(
        'post_purchase',
        'new_customer',
        'first_order',
        'repeat_customer',
        'high_value',
        'vip_customer',
        'customer_inactive',
        'lapsed_high_value_customer',
        'review_request',
        'abandoned_cart_step_1',
        'abandoned_cart_step_2',
        'abandoned_cart_step_3',
    );

    return in_array( $trigger, $premium_triggers, true );
}


/**
 * True when paid Commerce access is currently active via license or trial.
 *
 * @return bool
 */
function pmcpc_paid_access_active() {
    $license_active = function_exists( 'pmcpc_license' ) && pmcpc_license()->is_active();
    $trial_active   = function_exists( 'pmcpc_trial' ) && pmcpc_trial()->is_active();

    return (bool) ( $license_active || $trial_active );
}

/**
 * Whether the current admin has asked to hide paid/Commerce prompts while in free mode.
 *
 * @return bool
 */
function pmcpc_hide_paid_features_setting_enabled() {
    return 'yes' === (string) get_option( 'pmcpc_hide_paid_features_for_free', 'no' );
}

/**
 * Whether the paid-feature visibility toggle should be available in the admin header.
 * It is intentionally unavailable while a trial or license is active.
 *
 * @return bool
 */
function pmcpc_paid_feature_visibility_toggle_available() {
    return current_user_can( 'manage_options' ) && ! pmcpc_paid_access_active();
}

/**
 * True when paid/Commerce features should be hidden from free-mode admin screens.
 *
 * @return bool
 */
function pmcpc_should_hide_paid_features() {
    return pmcpc_paid_feature_visibility_toggle_available() && pmcpc_hide_paid_features_setting_enabled();
}


function pmcpc_product_site_url( $path = '/' ) {
    $base = (string) apply_filters( 'pmcpc_product_site_url', 'https://flowpress.uk/' );
    $base = trailingslashit( $base );
    $path = ltrim( (string) $path, '/' );
    return esc_url_raw( $base . $path );
}

function pmcpc_docs_url() {
    return pmcpc_product_site_url( 'docs/' );
}

function pmcpc_pricing_url() {
    return pmcpc_product_site_url( 'pricing/' );
}

function pmcpc_account_url() {
    return pmcpc_product_site_url( 'my-account/' );
}

function pmcpc_support_url() {
    return pmcpc_product_site_url( 'support/' );
}

function pmcpc_download_url() {
    return pmcpc_product_site_url( 'download/' );
}

function pmcpc_paid_plan_label() {
    return __( 'FlowPress Commerce', 'product-mailer-campaigns' );
}
