<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Lightweight license manager.
 *
 * - Stores license key locally.
 * - Optionally pings a remote license server on demand / weekly.
 * - Produces a feature set for the Feature Manager.
 */
class PMCPC_License_Manager {

    const OPTION_KEY        = 'pmcpc_license_key';
    const OPTION_STATUS     = 'pmcpc_license_status';
    const OPTION_PLAN       = 'pmcpc_license_plan';
    const OPTION_EXPIRES_AT = 'pmcpc_license_expires_at';
    const OPTION_FEATURES   = 'pmcpc_license_features';
    const OPTION_LAST_CHECK = 'pmcpc_license_last_check';
    const OPTION_LAST_MESSAGE = 'pmcpc_license_last_message';

    // You can override this via constant PMCPC_LICENSE_SERVER_URL or filter: pmcpc_license_server_url
    const DEFAULT_SERVER_URL = 'https://flowpress.uk/wp-json/pmcpc-license/v1/verify';

    public function get_key() {
        return (string) get_option( self::OPTION_KEY, '' );
    }

    public function set_key( $key ) {
        $key = strtoupper( preg_replace( '/[^A-Z0-9\-]/', '', (string) $key ) );
        update_option( self::OPTION_KEY, $key );
        // Reset cached status when key changes.
        delete_option( self::OPTION_STATUS );
        delete_option( self::OPTION_PLAN );
        delete_option( self::OPTION_EXPIRES_AT );
        delete_option( self::OPTION_FEATURES );
        delete_option( self::OPTION_LAST_CHECK );
        delete_option( self::OPTION_LAST_MESSAGE );
        return $key;
    }

    public function clear() {
        delete_option( self::OPTION_KEY );
        delete_option( self::OPTION_STATUS );
        delete_option( self::OPTION_PLAN );
        delete_option( self::OPTION_EXPIRES_AT );
        delete_option( self::OPTION_FEATURES );
        delete_option( self::OPTION_LAST_CHECK );
        delete_option( self::OPTION_LAST_MESSAGE );
    }


    public function last_message() {
        return (string) get_option( self::OPTION_LAST_MESSAGE, '' );
    }

    protected function set_last_message( $message ) {
        update_option( self::OPTION_LAST_MESSAGE, (string) $message );
    }

    public function status() {
        return (string) get_option( self::OPTION_STATUS, 'inactive' );
    }

    /**
     * Whether the locally stored license expiry timestamp has passed.
     *
     * The remote license server remains the source of truth when available, but
     * the local expiry timestamp must be treated as a hard stop so Commerce
     * features do not stay enabled until a manual re-check.
     *
     * @return bool
     */
    public function is_expired() {
        $expires_at = $this->expires_at();
        return $expires_at > 0 && $expires_at <= time();
    }

    public function is_active() {
        return 'active' === $this->status() && ! $this->is_expired();
    }

    /**
     * Disable a locally active license as soon as its stored expiry time passes.
     *
     * @return bool True when this call changed the license from active to inactive.
     */
    public function enforce_local_expiry() {
        if ( 'active' !== $this->status() || ! $this->is_expired() ) {
            return false;
        }

        $message    = __( 'License expired. Commerce features have been paused until the license is renewed and re-checked.', 'product-mailer-campaigns' );
        $plan       = $this->plan();
        $expires_at = $this->expires_at();

        $this->set_local_status( 'inactive', $plan, $expires_at, array() );
        $this->set_last_message( $message );

        return true;
    }

    public function plan() {
        return (string) get_option( self::OPTION_PLAN, '' );
    }

    public function expires_at() {
        return (int) get_option( self::OPTION_EXPIRES_AT, 0 );
    }

    public function features() {
        $raw = get_option( self::OPTION_FEATURES, array() );
        return is_array( $raw ) ? $raw : array();
    }

    public function server_url() {
        $default_url = defined( 'PMCPC_LICENSE_SERVER_URL' ) ? (string) PMCPC_LICENSE_SERVER_URL : self::DEFAULT_SERVER_URL;
        $url         = (string) apply_filters( 'pmcpc_license_server_url', $default_url );
        return esc_url_raw( $url );
    }

    /**
     * Build the payload sent to the FlowPress license bridge.
     *
     * Older bridge builds identified the Commerce add-on by the core plugin
     * slug, while newer/renewed records may be keyed against the Commerce
     * bridge slug. Send both identifiers so a reactivated subscription can be
     * matched reliably without breaking existing license records.
     *
     * @param string $key License key.
     * @return array
     */
    protected function build_verify_payload( $key ) {
        $commerce_slug = (string) apply_filters( 'pmcpc_license_commerce_slug', 'flowpress_commerce_license_bridge' );

        return array(
            'license_key'         => $key,
            'site_url'            => home_url(),
            'home_url'            => home_url(),
            'plugin'              => 'product-mailer-campaigns',
            'plugin_slug'         => 'product-mailer-campaigns',
            'product_slug'        => $commerce_slug,
            'commerce_addon_slug' => $commerce_slug,
            'license_context'     => 'commerce',
            'version'             => defined( 'PMCPC_PLUGIN_VERSION' ) ? PMCPC_PLUGIN_VERSION : '',
        );
    }

    /**
     * Normalise a truthy/falsey value from the license bridge.
     *
     * @param mixed $value Raw value.
     * @return bool|null Null when the value is not explicit.
     */
    protected function normalise_remote_bool( $value ) {
        if ( is_bool( $value ) ) {
            return $value;
        }

        if ( is_numeric( $value ) ) {
            return (int) $value > 0;
        }

        if ( is_string( $value ) ) {
            $value = strtolower( trim( $value ) );
            if ( in_array( $value, array( '1', 'true', 'yes', 'y', 'active', 'valid', 'verified', 'licensed', 'success', 'ok' ), true ) ) {
                return true;
            }
            if ( in_array( $value, array( '0', 'false', 'no', 'n', 'inactive', 'expired', 'invalid', 'cancelled', 'canceled', 'failed', 'error' ), true ) ) {
                return false;
            }
        }

        return null;
    }

    /**
     * Read an explicit active/inactive flag from a license bridge response.
     *
     * @param array $json Decoded response.
     * @return bool
     */
    protected function response_is_active( $json ) {
        $keys = array( 'active', 'is_active', 'valid', 'verified', 'licensed' );
        foreach ( $keys as $key ) {
            if ( array_key_exists( $key, $json ) ) {
                $value = $this->normalise_remote_bool( $json[ $key ] );
                if ( null !== $value ) {
                    return $value;
                }
            }
        }

        foreach ( array( 'status', 'license_status', 'subscription_status', 'state' ) as $key ) {
            if ( isset( $json[ $key ] ) ) {
                $value = $this->normalise_remote_bool( $json[ $key ] );
                if ( null !== $value ) {
                    return $value;
                }
            }
        }

        foreach ( array( 'success', 'ok' ) as $key ) {
            if ( array_key_exists( $key, $json ) ) {
                $value = $this->normalise_remote_bool( $json[ $key ] );
                if ( null !== $value ) {
                    return $value;
                }
            }
        }

        return false;
    }

    /**
     * Extract the first non-empty response value from a list of possible keys.
     *
     * @param array $json Decoded response.
     * @param array $keys Possible keys.
     * @return mixed|null
     */
    protected function response_value( $json, $keys ) {
        foreach ( $keys as $key ) {
            if ( array_key_exists( $key, $json ) && '' !== $json[ $key ] && null !== $json[ $key ] ) {
                return $json[ $key ];
            }
        }
        return null;
    }

    /**
     * Parse expiry values returned by different license bridge/add-on builds.
     *
     * Some bridge responses return a Unix timestamp, while others return a date
     * string such as 2026-04-24 or 2026-04-24 18:30:00. Casting those strings
     * directly to int turns them into a tiny number like 2026, which made a
     * renewed subscription look immediately expired. This parser handles
     * timestamps, millisecond timestamps, Ymd values, ISO/date strings, and
     * lifetime/unknown expiry values.
     *
     * @param mixed $value Raw expiry value.
     * @return int Unix timestamp, or 0 when no fixed expiry is available.
     */
    protected function parse_expires_at( $value ) {
        if ( is_array( $value ) || is_object( $value ) || null === $value || false === $value ) {
            return 0;
        }

        if ( is_int( $value ) || is_float( $value ) ) {
            $number = (int) $value;
            if ( $number > 999999999999 ) {
                $number = (int) floor( $number / 1000 );
            }
            return max( 0, $number );
        }

        $raw = trim( (string) $value );
        if ( '' === $raw ) {
            return 0;
        }

        $lower = strtolower( $raw );
        if ( in_array( $lower, array( '0', 'none', 'never', 'lifetime', 'no expiry', 'no expiration', 'unlimited' ), true ) ) {
            return 0;
        }

        if ( preg_match( '/^\d+$/', $raw ) ) {
            $number = (int) $raw;
            if ( strlen( $raw ) >= 13 ) {
                $number = (int) floor( $number / 1000 );
            } elseif ( 8 === strlen( $raw ) ) {
                $dt = DateTime::createFromFormat( 'Ymd H:i:s', $raw . ' 23:59:59', wp_timezone() );
                if ( $dt instanceof DateTime ) {
                    return (int) $dt->getTimestamp();
                }
            }
            return max( 0, $number );
        }

        // Date-only values should expire at the end of that local day, not at
        // midnight at the start of the date.
        if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $raw ) ) {
            $raw .= ' 23:59:59';
        }

        $timestamp = strtotime( $raw );
        if ( false === $timestamp ) {
            return 0;
        }

        return max( 0, (int) $timestamp );
    }

    /**
     * Verify license against server.
     *
     * @param bool $force Force remote check, ignoring cache.
     * @return array { ok:bool, message:string, data:array }
     */
    public function verify( $force = false ) {
        $key = $this->get_key();
        if ( '' === $key ) {
            $message = __( 'No license key set.', 'product-mailer-campaigns' );
            $this->set_local_status( 'inactive', '', 0, array() );
            $this->set_last_message( $message );
            return array( 'ok' => false, 'message' => $message, 'data' => array() );
        }

        $last = (int) get_option( self::OPTION_LAST_CHECK, 0 );
        if ( ! $force && $last > 0 && ( time() - $last ) < DAY_IN_SECONDS ) {
            // Use cache for 24h.
            $message = $this->is_active() ? __( 'License active.', 'product-mailer-campaigns' ) : __( 'License inactive.', 'product-mailer-campaigns' );
            $this->set_last_message( $message );
            return array(
                'ok'      => $this->is_active(),
                'message' => $message,
                'data'    => array( 'plan' => $this->plan(), 'expires_at' => $this->expires_at(), 'features' => $this->features() ),
            );
        }

        $payload = $this->build_verify_payload( $key );

        $resp = wp_remote_post(
            $this->server_url(),
            array(
                'timeout' => 12,
                'headers' => array( 'Content-Type' => 'application/json' ),
                'body'    => wp_json_encode( $payload ),
            )
        );

        update_option( self::OPTION_LAST_CHECK, time() );

        if ( is_wp_error( $resp ) ) {
            // Do not wipe existing status on transient network issues.
            $message = $resp->get_error_message();
            $this->set_last_message( $message );
            return array( 'ok' => $this->is_active(), 'message' => $message, 'data' => array() );
        }

        $code = (int) wp_remote_retrieve_response_code( $resp );
        $body = wp_remote_retrieve_body( $resp );
        $json = json_decode( $body, true );

        if ( $code < 200 || $code >= 300 || ! is_array( $json ) ) {
            $message = __( 'License server response was invalid.', 'product-mailer-campaigns' );
            $this->set_last_message( $message );
            return array( 'ok' => $this->is_active(), 'message' => $message, 'data' => array() );
        }

        $active = $this->response_is_active( $json );

        $plan_raw = $this->response_value( $json, array( 'plan', 'product_plan', 'tier', 'product', 'product_slug' ) );
        $plan     = null !== $plan_raw ? (string) $plan_raw : '';

        $expires_raw = $this->response_value(
            $json,
            array( 'expires_at', 'expires', 'expiry', 'expiry_date', 'expiration', 'expiration_date', 'renewal_date', 'next_payment_date' )
        );
        $expires_at = $this->parse_expires_at( $expires_raw );

        $features = isset( $json['features'] ) && is_array( $json['features'] ) ? $json['features'] : array();
        $message  = isset( $json['message'] ) ? (string) $json['message'] : ( $active ? __( 'License active.', 'product-mailer-campaigns' ) : __( 'License inactive.', 'product-mailer-campaigns' ) );

        if ( $active && $expires_at > 0 && $expires_at <= time() ) {
            // A live/reactivated subscription can be returned with an old expiry
            // by some bridge/add-on combinations. When the remote server says the
            // license is active, prefer that fresh server-side state and drop the
            // stale date so local expiry enforcement does not immediately turn it
            // off again. Automatic expiry still applies when the server returns a
            // future expiry timestamp.
            $expires_at = 0;
            if ( empty( $message ) || __( 'License active.', 'product-mailer-campaigns' ) === $message ) {
                $message = __( 'License active. The license server did not return a future expiry date, so expiry will be checked remotely.', 'product-mailer-campaigns' );
            }
        }

        if ( ! $active ) {
            $features = array();
        }

        $this->set_local_status( $active ? 'active' : 'inactive', $plan, $expires_at, $features );
        $this->set_last_message( $message );

        return array( 'ok' => $active, 'message' => $message, 'data' => array_merge( $json, array( 'expires_at' => $expires_at ) ) );
    }

    public function set_local_status( $status, $plan, $expires_at, $features ) {
        update_option( self::OPTION_STATUS, (string) $status );
        update_option( self::OPTION_PLAN, (string) $plan );
        update_option( self::OPTION_EXPIRES_AT, (int) $expires_at );
        update_option( self::OPTION_FEATURES, is_array( $features ) ? $features : array() );
    }
}
