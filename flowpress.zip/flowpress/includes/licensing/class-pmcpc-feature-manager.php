<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class PMCPC_Feature_Manager {

    /** @var PMCPC_License_Manager */
    protected $license;

    /** @var PMCPC_Trial_Manager */
    protected $trial;

    /**
     * Default features available without upgrade.
     *
     * IMPORTANT: keep core useful.
     */
    protected $base = array(
        'core'         => true,
        // "woocommerce" here means advanced ecommerce automations + customer segments.
        // Core plugin may still read WooCommerce products when present.
        'woocommerce'  => false,
        // Automation engine (non-Woo triggers like welcome/new subscriber) is part of core.
        // We only gate WooCommerce-specific triggers behind the "woocommerce" feature.
        'automation'   => true,
        'analytics_pro'=> false,
    );

    public function __construct( $license, $trial ) {
        $this->license = $license;
        $this->trial   = $trial;
    }

    public function enabled( $feature ) {
        $feature = (string) $feature;

        if ( isset( $this->base[ $feature ] ) && true === $this->base[ $feature ] ) {
            return true;
        }

        // Trial temporarily unlocks everything we want users to experience.
        if ( $this->trial && $this->trial->is_active() ) {
            return in_array( $feature, $this->trial->trial_features(), true ) || ( isset( $this->base[ $feature ] ) && $this->base[ $feature ] );
        }

        // Active license unlocks features from server.
        if ( $this->license && $this->license->is_active() ) {
            $features = $this->license->features();
            if ( isset( $features[ $feature ] ) ) {
                return (bool) $features[ $feature ];
            }
            // Back-compat: list format.
            if ( is_array( $features ) && in_array( $feature, $features, true ) ) {
                return true;
            }
        }

        return (bool) ( $this->base[ $feature ] ?? false );
    }

    public function status_summary() {
        if ( $this->trial && $this->trial->is_active() ) {
            return array(
                'mode' => 'trial',
                'expires_at' => $this->trial->expires_at(),
                'days_left' => $this->trial->days_left(),
            );
        }
        if ( $this->license && $this->license->is_active() ) {
            return array(
                'mode' => 'licensed',
                'plan' => $this->license->plan(),
                'expires_at' => $this->license->expires_at(),
            );
        }
        return array( 'mode' => 'free' );
    }
}
