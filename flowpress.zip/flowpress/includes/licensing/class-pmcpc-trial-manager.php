<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class PMCPC_Trial_Manager {

    const OPTION_START   = 'pmcpc_trial_start';
    const OPTION_EXPIRES = 'pmcpc_trial_expires';
    const OPTION_ACTIVE  = 'pmcpc_trial_active';

    /**
     * Features enabled during trial.
     */
    public function trial_features() {
        return array(
            'woocommerce',
            'automation',
            'analytics_pro',
        );
    }

    public function is_active() {
        $active  = ( 'yes' === (string) get_option( self::OPTION_ACTIVE, 'no' ) );
        $expires = (int) get_option( self::OPTION_EXPIRES, 0 );
        if ( ! $active || $expires <= 0 ) {
            return false;
        }
        if ( time() > $expires ) {
            $this->end();
            return false;
        }
        return true;
    }

    public function start( $days = 14 ) {
        $days = max( 1, (int) $days );
        $start = time();
        $expires = $start + ( $days * DAY_IN_SECONDS );
        update_option( self::OPTION_START, $start );
        update_option( self::OPTION_EXPIRES, $expires );
        update_option( self::OPTION_ACTIVE, 'yes' );
        return $expires;
    }

    public function end() {
        update_option( self::OPTION_ACTIVE, 'no' );
        // Keep dates for UI messaging.
    }

    public function expires_at() {
        return (int) get_option( self::OPTION_EXPIRES, 0 );
    }

    public function days_left() {
        if ( ! $this->is_active() ) {
            return 0;
        }
        $left = $this->expires_at() - time();
        return (int) ceil( $left / DAY_IN_SECONDS );
    }
}
