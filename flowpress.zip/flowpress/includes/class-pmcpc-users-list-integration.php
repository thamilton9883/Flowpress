<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PMCPC_Users_List_Integration {

    public static function init() {
        add_filter( 'manage_users_columns', array( __CLASS__, 'add_column' ) );
        add_filter( 'manage_users_custom_column', array( __CLASS__, 'render_column' ), 10, 3 );
        add_filter( 'user_row_actions', array( __CLASS__, 'add_row_actions' ), 10, 2 );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_styles' ) );

        add_action( 'restrict_manage_users', array( __CLASS__, 'render_filter_dropdown' ) );
        add_action( 'pre_get_users', array( __CLASS__, 'apply_filter_to_query' ) );
    }

    public static function add_column( $columns ) {
        $columns['pmcpc_subscriber'] = __( 'Email Subscriber', 'product-mailer-campaigns' );
        $columns['pmcpc_birthday']   = __( 'Birthday', 'product-mailer-campaigns' );
        $columns['pmcpc_marketing']  = __( 'Marketing profile', 'product-mailer-campaigns' );
        return $columns;
    }

    public static function render_column( $value, $column_name, $user_id ) {
        $user_id = (int) $user_id;

        if ( 'pmcpc_subscriber' === $column_name ) {
            $is_sub = get_user_meta( $user_id, 'pmcpc_is_subscriber', true );
            $unsub  = get_user_meta( $user_id, 'pmcpc_email_unsubscribed', true );

            if ( $is_sub ) {
                return '<span class="pmcpc-subscriber-badge pmcpc-subscriber-active">' . esc_html__( 'Active', 'product-mailer-campaigns' ) . '</span>';
            } elseif ( $unsub ) {
                return '<span class="pmcpc-subscriber-badge pmcpc-subscriber-unsub">' . esc_html__( 'Unsubscribed', 'product-mailer-campaigns' ) . '</span>';
            }

            return '<span class="pmcpc-subscriber-badge pmcpc-subscriber-none">' . esc_html__( 'No', 'product-mailer-campaigns' ) . '</span>';
        }

        if ( 'pmcpc_birthday' === $column_name ) {
            $birthday = self::get_user_birthday( $user_id );

            return $birthday ? esc_html( mysql2date( get_option( 'date_format' ), $birthday ) ) : '<span class="pmcpc-muted">' . esc_html__( '—', 'product-mailer-campaigns' ) . '</span>';
        }

        if ( 'pmcpc_marketing' === $column_name ) {
            $user = get_userdata( $user_id );
            if ( ! $user || empty( $user->user_email ) ) {
                return '<span class="pmcpc-muted">' . esc_html__( 'Unavailable', 'product-mailer-campaigns' ) . '</span>';
            }

            $subscriber = self::get_linked_subscriber( $user->user_email );
            $links      = array();

            $links[] = '<a href="' . esc_url( get_edit_user_link( $user_id ) ) . '">' . esc_html__( 'Edit profile', 'product-mailer-campaigns' ) . '</a>';

            $prefs_url = self::get_preferences_page_url();
            if ( $prefs_url ) {
                $links[] = '<a href="' . esc_url( $prefs_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Preferences page', 'product-mailer-campaigns' ) . '</a>';
            }

            $status = $subscriber
                ? '<span class="pmcpc-subscriber-badge pmcpc-subscriber-linked">' . esc_html__( 'Linked', 'product-mailer-campaigns' ) . '</span>'
                : '<span class="pmcpc-subscriber-badge pmcpc-subscriber-none">' . esc_html__( 'No profile', 'product-mailer-campaigns' ) . '</span>';

            return $status . '<div class="pmcpc-marketing-links">' . implode( ' <span class="pmcpc-muted">|</span> ', $links ) . '</div>';
        }

        return $value;
    }

    public static function add_row_actions( $actions, $user ) {
        if ( ! $user instanceof WP_User ) {
            return $actions;
        }

        $actions['pmcpc_marketing'] = '<a href="' . esc_url( get_edit_user_link( $user->ID ) ) . '#pmcpc_birthday">' . esc_html__( 'Marketing profile', 'product-mailer-campaigns' ) . '</a>';

        $prefs_url = self::get_preferences_page_url();
        if ( $prefs_url ) {
            $actions['pmcpc_preferences'] = '<a href="' . esc_url( $prefs_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Email preferences page', 'product-mailer-campaigns' ) . '</a>';
        }

        return $actions;
    }

    public static function enqueue_styles( $hook ) {
        if ( 'users.php' !== $hook ) {
            return;
        }

        $css = '
.column-pmcpc_subscriber{width:140px;}
.column-pmcpc_birthday{width:140px;}
.column-pmcpc_marketing{width:220px;}
.pmcpc-subscriber-badge{display:inline-block;padding:2px 6px;border-radius:3px;font-size:11px;line-height:1.4;margin-bottom:4px;}
.pmcpc-subscriber-active{background:#46b450;color:#fff;}
.pmcpc-subscriber-unsub{background:#d63638;color:#fff;}
.pmcpc-subscriber-none{background:#82878c;color:#fff;}
.pmcpc-subscriber-linked{background:#2271b1;color:#fff;}
.pmcpc-muted{color:#646970;}
.pmcpc-marketing-links{margin-top:4px;font-size:12px;}
';

        wp_register_style( 'pmcpc-admin-inline', false, array(), PMCPC_PLUGIN_VERSION );
        wp_enqueue_style( 'pmcpc-admin-inline' );
        wp_add_inline_style( 'pmcpc-admin-inline', $css );
    }


    protected static function get_user_birthday( $user_id ) {
        $user_id = absint( $user_id );
        if ( ! $user_id ) {
            return '';
        }

        foreach ( array( 'pmcpc_birthday', 'birthday', 'birthdate' ) as $meta_key ) {
            $value = sanitize_text_field( (string) get_user_meta( $user_id, $meta_key, true ) );
            if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
                return $value;
            }
        }

        return '';
    }

    protected static function get_linked_subscriber( $email ) {
        if ( empty( $email ) || ! class_exists( 'PMCPC_Subscriber_Manager' ) || ! method_exists( 'PMCPC_Subscriber_Manager', 'get_subscriber_by_email' ) ) {
            return false;
        }

        return PMCPC_Subscriber_Manager::get_subscriber_by_email( sanitize_email( $email ) );
    }

    protected static function get_preferences_page_url() {
        if ( class_exists( 'WooCommerce' ) && function_exists( 'wc_get_account_endpoint_url' ) ) {
            return wc_get_account_endpoint_url( 'email-preferences' );
        }

        if ( function_exists( 'pmcpc_get_setting' ) ) {
            $url = (string) pmcpc_get_setting( 'email_prefs_url', '' );
            if ( ! empty( $url ) ) {
                return $url;
            }
        }

        return '';
    }

    public static function render_filter_dropdown( $which ) {
        if ( 'top' !== $which ) {
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $current = ( isset( $_GET['pmcpc_subscriber_filter'] ) && ! is_array( $_GET['pmcpc_subscriber_filter'] ) )
            ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_subscriber_filter'] ) )
            : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        ?>
        <select name="pmcpc_subscriber_filter">
            <option value=""><?php esc_html_e( 'All subscriber statuses', 'product-mailer-campaigns' ); ?></option>
            <option value="active" <?php selected( $current, 'active' ); ?>><?php esc_html_e( 'Active subscribers', 'product-mailer-campaigns' ); ?></option>
            <option value="unsubscribed" <?php selected( $current, 'unsubscribed' ); ?>><?php esc_html_e( 'Unsubscribed', 'product-mailer-campaigns' ); ?></option>
            <option value="none" <?php selected( $current, 'none' ); ?>><?php esc_html_e( 'Not a subscriber', 'product-mailer-campaigns' ); ?></option>
            <option value="has_birthday" <?php selected( $current, 'has_birthday' ); ?>><?php esc_html_e( 'Has birthday', 'product-mailer-campaigns' ); ?></option>
            <option value="no_birthday" <?php selected( $current, 'no_birthday' ); ?>><?php esc_html_e( 'No birthday set', 'product-mailer-campaigns' ); ?></option>
        </select>
        <?php
    }

    public static function apply_filter_to_query( $query ) {
        if ( ! is_admin() ) {
            return;
        }

        global $pagenow;
        if ( 'users.php' !== $pagenow ) {
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        if ( empty( $_GET['pmcpc_subscriber_filter'] ) ) {
            return;
        }

        $filter = ( isset( $_GET['pmcpc_subscriber_filter'] ) && ! is_array( $_GET['pmcpc_subscriber_filter'] ) )
            ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_subscriber_filter'] ) )
            : '';

        $meta_query = (array) $query->get( 'meta_query' );

        if ( 'active' === $filter ) {
            $meta_query[] = array(
                'key'   => 'pmcpc_is_subscriber',
                'value' => '1',
            );
        } elseif ( 'unsubscribed' === $filter ) {
            $meta_query[] = array(
                'key'   => 'pmcpc_email_unsubscribed',
                'value' => '1',
            );
        } elseif ( 'none' === $filter ) {
            $meta_query[] = array(
                'relation' => 'AND',
                array(
                    'relation' => 'OR',
                    array(
                        'key'     => 'pmcpc_is_subscriber',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key'     => 'pmcpc_is_subscriber',
                        'value'   => '1',
                        'compare' => '!=',
                    ),
                ),
                array(
                    'relation' => 'OR',
                    array(
                        'key'     => 'pmcpc_email_unsubscribed',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key'     => 'pmcpc_email_unsubscribed',
                        'value'   => '1',
                        'compare' => '!=',
                    ),
                ),
            );
        } elseif ( 'has_birthday' === $filter ) {
            $meta_query[] = array(
                'relation' => 'OR',
                array(
                    'key'     => 'pmcpc_birthday',
                    'value'   => '',
                    'compare' => '!=',
                ),
                array(
                    'key'     => 'birthday',
                    'value'   => '',
                    'compare' => '!=',
                ),
                array(
                    'key'     => 'birthdate',
                    'value'   => '',
                    'compare' => '!=',
                ),
            );
        } elseif ( 'no_birthday' === $filter ) {
            $meta_query[] = array(
                'relation' => 'AND',
                array(
                    'relation' => 'OR',
                    array(
                        'key'     => 'pmcpc_birthday',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key'   => 'pmcpc_birthday',
                        'value' => '',
                    ),
                ),
                array(
                    'relation' => 'OR',
                    array(
                        'key'     => 'birthday',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key'   => 'birthday',
                        'value' => '',
                    ),
                ),
                array(
                    'relation' => 'OR',
                    array(
                        'key'     => 'birthdate',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key'   => 'birthdate',
                        'value' => '',
                    ),
                ),
            );
        }

        $query->set( 'meta_query', $meta_query );
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
    }
}
