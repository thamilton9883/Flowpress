<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Unified automation dispatcher.
 *
 * Philosophy:
 *  - Triggers only *fire events*.
 *  - Campaigns decide audience + delay + content.
 *
 * This class is intentionally small and WP-friendly.
 */
class PMCPC_Automation_Dispatcher {

    /**
     * Backwards-compatible alias used by older runtime paths.
     *
     * @param string $trigger_key
     * @param string $subscriber_email
     * @param array  $context
     * @return void
     */
    public static function dispatch( $trigger_key, $subscriber_email, $context = array() ) {
        self::fire_for_email( $trigger_key, $subscriber_email, $context );
    }

    /**
     * Fire an automation trigger for a subscriber email.
     *
     * @param string $trigger_key
     * @param string $subscriber_email
     * @param array  $context Optional context (order/cart/etc). Passed into template vars filter.
     * @return void
     */
    public static function fire_for_email( $trigger_key, $subscriber_email, $context = array() ) {
        $trigger_key      = sanitize_key( (string) $trigger_key );
        $subscriber_email = sanitize_email( (string) $subscriber_email );

        if ( empty( $trigger_key ) || empty( $subscriber_email ) ) {
            return;
        }

        if ( ! class_exists( 'PMCPC_Campaign_Manager' ) ) {
            return;
        }

        if ( function_exists( 'pmcpc_is_premium_wc_trigger' )
            && pmcpc_is_premium_wc_trigger( $trigger_key )
            && ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() )
        ) {
            return;
        }

        // Back-compat: older code paths use dedicated functions.
        // We still route through the unified dispatcher when available.
        if ( method_exists( 'PMCPC_Campaign_Manager', 'dispatch_automation_trigger_for_subscriber_email' ) ) {
            PMCPC_Campaign_Manager::dispatch_automation_trigger_for_subscriber_email( $trigger_key, $subscriber_email, $context );
            return;
        }

        // Fallback (legacy) for installs where the dispatcher method doesn't exist.
        if ( 'welcome' === $trigger_key && method_exists( 'PMCPC_Campaign_Manager', 'send_welcome_campaigns_for_subscriber_email' ) ) {
            PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $subscriber_email );
            return;
        }

        if ( 'post_purchase' === $trigger_key && method_exists( 'PMCPC_Campaign_Manager', 'send_post_purchase_campaigns_for_subscriber_email' ) ) {
            PMCPC_Campaign_Manager::send_post_purchase_campaigns_for_subscriber_email( $subscriber_email );
            return;
        }
    }
}
