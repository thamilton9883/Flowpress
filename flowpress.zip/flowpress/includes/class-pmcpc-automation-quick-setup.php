<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * One-click automation activation.
 *
 * Creates editable starter automation campaigns for Core and WooCommerce flows.
 * This is intentionally self-contained: no external services.
 */
class PMCPC_Automation_Quick_Setup {

    /**
     * Handle the automation starter admin-post action.
     */
    public static function handle_setup_store_automation() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'product-mailer-campaigns' ) );
        }

        $nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'pmcpc_setup_store_automation' ) ) {
            wp_die( esc_html__( 'Invalid request.', 'product-mailer-campaigns' ) );
        }

        global $wpdb;
        if ( ! isset( $wpdb ) || ! $wpdb instanceof \wpdb ) {
            wp_die( esc_html__( 'Database not available.', 'product-mailer-campaigns' ) );
        }

        if ( class_exists( 'PMCPC_Activator' ) && method_exists( 'PMCPC_Activator', 'maybe_upgrade' ) ) {
            PMCPC_Activator::maybe_upgrade();
        }

        $group = isset( $_GET['pmcpc_setup_group'] ) ? sanitize_key( (string) wp_unslash( $_GET['pmcpc_setup_group'] ) ) : 'all';
        $allowed_groups = array_merge( array( 'core', 'woocommerce', 'abandoned_cart', 'all' ), array_keys( self::get_workflow_setup_groups() ) );
        if ( ! in_array( $group, $allowed_groups, true ) ) {
            $group = 'all';
        }

        $table     = $wpdb->prefix . 'pmcpc_campaigns';
        $now       = gmdate( 'Y-m-d H:i:s' );
        $site_name = get_bloginfo( 'name' );

        $from_name  = class_exists( 'PMCPC_Settings' ) ? trim( (string) PMCPC_Settings::get( 'from_name_default', '' ) ) : '';
        $from_email = class_exists( 'PMCPC_Settings' ) ? trim( (string) PMCPC_Settings::get( 'from_email_default', '' ) ) : '';

        if ( '' === $from_name ) {
            $from_name = $site_name;
        }
        if ( '' === $from_email || ! is_email( $from_email ) ) {
            $from_email = get_bloginfo( 'admin_email' );
        }

        $created = 0;
        $skipped = 0;
        $errors  = 0;

        $want = self::get_setup_kinds( $group );

        if ( in_array( $group, array( 'woocommerce', 'abandoned_cart', 'post_purchase_sequence', 'customer_winback_sequence', 'all' ), true ) && ! class_exists( 'WooCommerce' ) ) {
            $woo_kinds = array_merge(
                self::get_setup_kinds( 'woocommerce' ),
                self::get_setup_kinds( 'post_purchase_sequence' ),
                self::get_setup_kinds( 'customer_winback_sequence' )
            );
            $want = array_values(
                array_filter(
                    $want,
                    static function ( $kind ) use ( $woo_kinds ) {
                        return ! in_array( $kind, $woo_kinds, true );
                    }
                )
            );

            if ( in_array( $group, array( 'woocommerce', 'abandoned_cart', 'post_purchase_sequence', 'customer_winback_sequence' ), true ) ) {
                $skipped += count( self::get_setup_kinds( $group ) );
            }
        }

        foreach ( $want as $kind ) {
            $data = self::build_campaign_row( $kind, $site_name, $from_name, $from_email, $now );
            if ( empty( $data ) ) {
                $errors++;
                continue;
            }

            $trigger = isset( $data['automation_trigger'] ) ? sanitize_key( (string) $data['automation_trigger'] ) : '';
            if ( self::campaign_exists_for_trigger( $trigger, $data, $wpdb, $table ) ) {
                self::maybe_update_existing_starter_delay( $trigger, $data, $wpdb, $table );
                $skipped++;
                continue;
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $ok = $wpdb->insert( $table, $data );
            if ( false === $ok ) {
                $errors++;
                continue;
            }

            $created++;
        }

        $label = self::get_group_label( $group );

        if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
            PMCPC_Activity_Feed::log(
                sprintf(
                    'Automation setup completed for %s (created %d, skipped %d, errors %d).',
                    $label,
                    (int) $created,
                    (int) $skipped,
                    (int) $errors
                )
            );
        }

        $args = array(
            'page'               => 'pmcpc_automations',
            'pmcpc_setup_done'   => 1,
            'pmcpc_setup_group'  => $group,
            'pmcpc_created'      => $created,
            'pmcpc_skipped'      => $skipped,
            'pmcpc_setup_errors' => $errors,
        );

        wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
        exit;
    }

    /**
     * Handle the custom step workflow builder form.
     *
     * Creates a parent-like workflow by inserting separate editable campaign rows
     * that share workflow_key/workflow_name and use workflow_step for ordering.
     */
    public static function handle_create_step_workflow() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'product-mailer-campaigns' ) );
        }

        $nonce = isset( $_POST['pmcpc_create_step_workflow_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_create_step_workflow_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'pmcpc_create_step_workflow' ) ) {
            wp_die( esc_html__( 'Invalid request.', 'product-mailer-campaigns' ) );
        }

        global $wpdb;
        if ( ! isset( $wpdb ) || ! $wpdb instanceof \wpdb ) {
            wp_die( esc_html__( 'Database not available.', 'product-mailer-campaigns' ) );
        }

        if ( class_exists( 'PMCPC_Activator' ) && method_exists( 'PMCPC_Activator', 'maybe_upgrade' ) ) {
            PMCPC_Activator::maybe_upgrade();
        }

        $workflow_name = isset( $_POST['workflow_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['workflow_name'] ) ) : '';
        $trigger       = isset( $_POST['workflow_trigger'] ) ? sanitize_key( (string) wp_unslash( $_POST['workflow_trigger'] ) ) : 'new_subscriber';
        $steps         = isset( $_POST['workflow_steps'] ) ? absint( wp_unslash( $_POST['workflow_steps'] ) ) : 3;
        $steps         = max( 2, min( 5, $steps ) );

        if ( '' === $workflow_name ) {
            $workflow_name = __( 'Custom step workflow', 'product-mailer-campaigns' );
        }

        $allowed_triggers = self::get_custom_workflow_allowed_triggers();
        if ( ! isset( $allowed_triggers[ $trigger ] ) ) {
            $trigger = 'new_subscriber';
        }

        if ( ! empty( $allowed_triggers[ $trigger ]['requires_woocommerce'] ) && ! class_exists( 'WooCommerce' ) ) {
            wp_safe_redirect(
                add_query_arg(
                    array(
                        'page'                  => 'pmcpc_automations',
                        'pmcpc_workflow_builder' => 1,
                        'pmcpc_workflow_error'   => 'woocommerce_required',
                    ),
                    admin_url( 'admin.php' )
                )
            );
            exit;
        }

        $table      = $wpdb->prefix . 'pmcpc_campaigns';
        $now        = gmdate( 'Y-m-d H:i:s' );
        $site_name  = get_bloginfo( 'name' );
        $from_name  = class_exists( 'PMCPC_Settings' ) ? trim( (string) PMCPC_Settings::get( 'from_name_default', '' ) ) : '';
        $from_email = class_exists( 'PMCPC_Settings' ) ? trim( (string) PMCPC_Settings::get( 'from_email_default', '' ) ) : '';

        if ( '' === $from_name ) {
            $from_name = $site_name;
        }
        if ( '' === $from_email || ! is_email( $from_email ) ) {
            $from_email = get_bloginfo( 'admin_email' );
        }

        $base_key = sanitize_key( substr( sanitize_title( $workflow_name ), 0, 52 ) );
        if ( '' === $base_key ) {
            $base_key = 'workflow';
        }
        $workflow_key = 'custom_' . $base_key . '_' . substr( md5( $workflow_name . microtime( true ) ), 0, 8 );
        $workflow_key = substr( sanitize_key( $workflow_key ), 0, 95 );

        $subjects      = isset( $_POST['workflow_step_subject'] ) && is_array( $_POST['workflow_step_subject'] ) ? (array) wp_unslash( $_POST['workflow_step_subject'] ) : array();
        $delay_amounts = isset( $_POST['workflow_step_delay_amount'] ) && is_array( $_POST['workflow_step_delay_amount'] ) ? (array) wp_unslash( $_POST['workflow_step_delay_amount'] ) : array();
        $delay_units   = isset( $_POST['workflow_step_delay_unit'] ) && is_array( $_POST['workflow_step_delay_unit'] ) ? (array) wp_unslash( $_POST['workflow_step_delay_unit'] ) : array();

        $created = 0;
        $errors  = 0;

        for ( $step = 1; $step <= $steps; $step++ ) {
            $subject = isset( $subjects[ $step ] ) ? sanitize_text_field( (string) $subjects[ $step ] ) : '';
            if ( '' === $subject ) {
                $subject = sprintf( __( '%1$s · Step %2$d', 'product-mailer-campaigns' ), $workflow_name, $step );
            }

            $amount = isset( $delay_amounts[ $step ] ) ? absint( $delay_amounts[ $step ] ) : 0;
            $unit   = isset( $delay_units[ $step ] ) ? sanitize_key( (string) $delay_units[ $step ] ) : 'days';
            $delay  = self::convert_delay_to_minutes( $amount, $unit );

            $data = self::build_custom_workflow_campaign_row(
                $workflow_key,
                $workflow_name,
                $step,
                $steps,
                $trigger,
                $subject,
                $delay,
                $site_name,
                $from_name,
                $from_email,
                $now
            );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $ok = $wpdb->insert( $table, $data );
            if ( false === $ok ) {
                $errors++;
            } else {
                $created++;
            }
        }

        if ( class_exists( 'PMCPC_Activity_Feed' ) ) {
            PMCPC_Activity_Feed::log(
                sprintf(
                    'Custom step workflow created: %s (created %d steps, errors %d).',
                    $workflow_name,
                    (int) $created,
                    (int) $errors
                )
            );
        }

        wp_safe_redirect(
            add_query_arg(
                array(
                    'page'                   => 'pmcpc_automations',
                    'pmcpc_workflow_created' => 1,
                    'pmcpc_created'          => $created,
                    'pmcpc_workflow_errors'  => $errors,
                    'focus'                  => 'workflow_' . $workflow_key,
                ),
                admin_url( 'admin.php' )
            )
        );
        exit;
    }

    /**
     * Triggers available in the simple custom workflow builder.
     *
     * @return array<string,array>
     */
    public static function get_custom_workflow_allowed_triggers() {
        return array(
            'new_subscriber' => array(
                'label' => __( 'New subscriber joins list', 'product-mailer-campaigns' ),
                'requires_woocommerce' => false,
            ),
            'lead_magnet_download' => array(
                'label' => __( 'Lead magnet signup', 'product-mailer-campaigns' ),
                'requires_woocommerce' => false,
            ),
            'subscriber_inactive' => array(
                'label' => __( 'Subscriber inactive', 'product-mailer-campaigns' ),
                'requires_woocommerce' => false,
            ),
            'post_purchase' => array(
                'label' => __( 'WooCommerce order completed', 'product-mailer-campaigns' ),
                'requires_woocommerce' => true,
            ),
            'repeat_customer' => array(
                'label' => __( 'Repeat customer', 'product-mailer-campaigns' ),
                'requires_woocommerce' => true,
            ),
            'customer_inactive' => array(
                'label' => __( 'Customer inactive / win-back', 'product-mailer-campaigns' ),
                'requires_woocommerce' => true,
            ),
        );
    }

    /**
     * Convert a user-entered delay to minutes.
     *
     * @param int    $amount Delay amount.
     * @param string $unit   minutes|hours|days.
     * @return int
     */
    protected static function convert_delay_to_minutes( $amount, $unit ) {
        $amount = max( 0, absint( $amount ) );
        $unit   = sanitize_key( (string) $unit );
        if ( 'days' === $unit ) {
            return $amount * 1440;
        }
        if ( 'hours' === $unit ) {
            return $amount * 60;
        }
        return $amount;
    }

    /**
     * Build one editable campaign row for a custom workflow step.
     *
     * @return array
     */
    protected static function build_custom_workflow_campaign_row( $workflow_key, $workflow_name, $step, $total_steps, $trigger, $subject, $delay, $site_name, $from_name, $from_email, $now ) {
        $workflow_key  = sanitize_key( (string) $workflow_key );
        $workflow_name = sanitize_text_field( (string) $workflow_name );
        $step          = max( 1, absint( $step ) );
        $total_steps   = max( $step, absint( $total_steps ) );
        $trigger       = sanitize_key( (string) $trigger );
        $subject       = sanitize_text_field( (string) $subject );
        $delay         = max( 0, absint( $delay ) );

        $name = sprintf( '%1$s · Step %2$d', $workflow_name, $step );
        $body = '<p>' . esc_html__( 'Hi {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
            . '<p>' . esc_html( sprintf( __( 'This is step %1$d of %2$d in the %3$s workflow.', 'product-mailer-campaigns' ), $step, $total_steps, $workflow_name ) ) . '</p>'
            . '<p>' . esc_html__( 'Edit this email to add your own message, offer, product recommendations, or next step.', 'product-mailer-campaigns' ) . '</p>';

        $is_welcome       = 0;
        $is_post_purchase = 0;
        $pro_segment_key  = '';

        if ( 'new_subscriber' === $trigger ) {
            $is_welcome = 1;
        }
        if ( 'post_purchase' === $trigger ) {
            $is_post_purchase = 1;
            $pro_segment_key  = 'customers';
        } elseif ( 'repeat_customer' === $trigger ) {
            $pro_segment_key = 'repeat_customers';
        } elseif ( 'customer_inactive' === $trigger ) {
            $pro_segment_key = 'lapsed';
        }

        return array(
            'name'                       => $name,
            'campaign_type'              => 'automation',
            'automation_trigger'         => $trigger,
            'pro_segment_key'            => $pro_segment_key,
            'workflow_key'               => $workflow_key,
            'workflow_name'              => $workflow_name,
            'workflow_step'              => $step,
            'subject'                    => $subject,
            'from_name'                  => $from_name,
            'from_email'                 => $from_email,
            'content'                    => $body,
            'status'                     => 'active',
            'is_welcome'                 => $is_welcome,
            'is_post_purchase'           => $is_post_purchase,
            'target_tag'                 => '',
            'welcome_delay_minutes'      => $delay,
            'post_purchase_delay_minutes' => $delay,
            'broadcast_delay_minutes'    => $delay,
            'trigger_delay_minutes'      => $delay,
            'schedule_type'              => 'manual',
            'schedule_datetime'          => null,
            'schedule_frequency'         => null,
            'next_run_at'                => null,
            'product_block_enabled'      => 0,
            'product_block_source'       => '',
            'product_block_limit'        => 3,
            'auto_footer_links_enabled'  => 1,
            'created_at'                 => $now,
            'updated_at'                 => $now,
        );
    }

    /**
     * Built-in multi-step workflow setup groups.
     *
     * Each workflow creates separate editable campaign rows which share the same
     * runtime trigger, but are grouped by workflow_key/workflow_step in admin UI.
     *
     * @return array<string,array>
     */
    protected static function get_workflow_setup_groups() {
        return array(
            'welcome_series' => array(
                'label' => __( 'New subscriber welcome series', 'product-mailer-campaigns' ),
                'kinds' => array( 'welcome_series_step_1', 'welcome_series_step_2', 'welcome_series_step_3' ),
            ),
            'post_purchase_sequence' => array(
                'label' => __( 'Post-purchase follow-up sequence', 'product-mailer-campaigns' ),
                'kinds' => array( 'post_purchase_sequence_step_1', 'post_purchase_sequence_step_2', 'post_purchase_sequence_step_3' ),
            ),
            'customer_winback_sequence' => array(
                'label' => __( 'Customer win-back sequence', 'product-mailer-campaigns' ),
                'kinds' => array( 'customer_winback_sequence_step_1', 'customer_winback_sequence_step_2' ),
            ),
        );
    }

    /**
     * Automation kinds by starter group.
     *
     * @param string $group Setup group.
     * @return array
     */
    protected static function get_setup_kinds( $group ) {
        $core = array(
            'new_subscriber',
            'welcome_follow_up',
            'lead_magnet_download',
            'subscriber_inactive',
            'subscriber_anniversary',
            'subscriber_birthday',
        );

        $abandoned_cart = array(
            'abandoned_cart_step_1',
            'abandoned_cart_step_2',
            'abandoned_cart_step_3',
        );

        $woocommerce = array_merge(
            array(
                'new_customer',
                'repeat_customer',
                'post_purchase',
                'review_request',
                'customer_inactive',
                'high_value',
                'lapsed_high_value_customer',
                'vip_customer',
            ),
            $abandoned_cart
        );

        $workflow_groups = self::get_workflow_setup_groups();
        if ( isset( $workflow_groups[ $group ] ) ) {
            return $workflow_groups[ $group ]['kinds'];
        }

        if ( 'core' === $group ) {
            return $core;
        }
        if ( 'woocommerce' === $group ) {
            return $woocommerce;
        }
        if ( 'abandoned_cart' === $group ) {
            return $abandoned_cart;
        }

        return array_merge( $core, $woocommerce );
    }

    /**
     * Human-readable starter group label.
     *
     * @param string $group Setup group.
     * @return string
     */
    protected static function get_group_label( $group ) {
        if ( 'core' === $group ) {
            return __( 'Core automations', 'product-mailer-campaigns' );
        }
        if ( 'woocommerce' === $group ) {
            return __( 'WooCommerce automations', 'product-mailer-campaigns' );
        }
        if ( 'abandoned_cart' === $group ) {
            return __( 'Abandoned cart recovery', 'product-mailer-campaigns' );
        }
        $workflow_groups = self::get_workflow_setup_groups();
        if ( isset( $workflow_groups[ $group ] ) ) {
            return $workflow_groups[ $group ]['label'];
        }
        return __( 'All automations', 'product-mailer-campaigns' );
    }

    /**
     * Default trigger delay, in minutes, for starter automations.
     *
     * @param string $kind Starter kind.
     * @return int
     */
    protected static function get_default_trigger_delay_minutes( $kind ) {
        $kind = sanitize_key( (string) $kind );
        $defaults = array(
            'abandoned_cart_step_1' => class_exists( 'PMCPC_Abandoned_Carts' ) ? (int) PMCPC_Abandoned_Carts::DEFAULT_STEP1_DELAY_MINUTES : 60,
            'abandoned_cart_step_2' => class_exists( 'PMCPC_Abandoned_Carts' ) ? (int) PMCPC_Abandoned_Carts::DEFAULT_STEP2_DELAY_MINUTES : 1440,
            'abandoned_cart_step_3' => class_exists( 'PMCPC_Abandoned_Carts' ) ? (int) PMCPC_Abandoned_Carts::DEFAULT_STEP3_DELAY_MINUTES : 4320,
            'welcome_series_step_1' => 0,
            'welcome_series_step_2' => 2880,
            'welcome_series_step_3' => 7200,
            'post_purchase_sequence_step_1' => 0,
            'post_purchase_sequence_step_2' => 10080,
            'post_purchase_sequence_step_3' => 20160,
            'customer_winback_sequence_step_1' => 0,
            'customer_winback_sequence_step_2' => 10080,
        );

        return isset( $defaults[ $kind ] ) ? max( 0, (int) $defaults[ $kind ] ) : 0;
    }

    /**
     * Update old starter rows that were created with a zero abandoned-cart delay.
     *
     * This keeps existing installs safe when the setup button is clicked again:
     * duplicate campaigns are still skipped, but the three abandoned-cart steps
     * are normalised so the whole recovery sequence does not send at once.
     *
     * @param string $trigger Trigger key.
     * @param array  $data    Starter row data.
     * @param wpdb   $wpdb    Database handle.
     * @param string $table   Campaign table name.
     * @return void
     */
    protected static function maybe_update_existing_starter_delay( $trigger, $data, $wpdb, $table ) {
        $trigger = sanitize_key( (string) $trigger );
        $delay = isset( $data['trigger_delay_minutes'] ) ? max( 0, (int) $data['trigger_delay_minutes'] ) : 0;
        if ( $delay <= 0 ) {
            return;
        }

        $workflow_key  = isset( $data['workflow_key'] ) ? sanitize_key( (string) $data['workflow_key'] ) : '';
        $workflow_step = isset( $data['workflow_step'] ) ? absint( $data['workflow_step'] ) : 0;

        if ( '' !== $workflow_key && $workflow_step > 0 ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$table} SET trigger_delay_minutes = %d, updated_at = %s WHERE workflow_key = %s AND workflow_step = %d AND trigger_delay_minutes = 0 AND status IN ('active','draft','paused','scheduled','queued')",
                    $delay,
                    gmdate( 'Y-m-d H:i:s' ),
                    $workflow_key,
                    $workflow_step
                )
            );
            return;
        }

        if ( ! in_array( $trigger, array( 'abandoned_cart_step_1', 'abandoned_cart_step_2', 'abandoned_cart_step_3' ), true ) ) {
            return;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET trigger_delay_minutes = %d, updated_at = %s WHERE automation_trigger = %s AND trigger_delay_minutes = 0 AND status IN ('active','draft','paused','scheduled','queued')",
                $delay,
                gmdate( 'Y-m-d H:i:s' ),
                $trigger
            )
        );
    }

    /**
     * Check whether an equivalent campaign already exists.
     *
     * @param string $trigger Trigger key.
     * @param array  $data    Insert row data.
     * @param wpdb   $wpdb    Database handle.
     * @param string $table   Campaign table name.
     * @return bool
     */
    protected static function campaign_exists_for_trigger( $trigger, $data, $wpdb, $table ) {
        $trigger = sanitize_key( (string) $trigger );
        if ( '' === $trigger || 'none' === $trigger ) {
            return true;
        }

        $workflow_key  = isset( $data['workflow_key'] ) ? sanitize_key( (string) $data['workflow_key'] ) : '';
        $workflow_step = isset( $data['workflow_step'] ) ? absint( $data['workflow_step'] ) : 0;
        if ( '' !== $workflow_key && $workflow_step > 0 ) {
            $statuses = array( 'active', 'draft', 'paused', 'scheduled', 'queued' );
            $args     = array_merge( $statuses, array( $workflow_key, $workflow_step ) );
            $sql      = "SELECT COUNT(*) FROM {$table} WHERE status IN (" . implode( ', ', array_fill( 0, count( $statuses ), '%s' ) ) . ") AND workflow_key = %s AND workflow_step = %d";
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            return (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) ) > 0;
        }

        $aliases = self::get_trigger_aliases( $trigger );
        if ( empty( $aliases ) ) {
            $aliases = array( $trigger );
        }

        $where = array();
        $args  = array();

        $where[] = "automation_trigger IN (" . implode( ', ', array_fill( 0, count( $aliases ), '%s' ) ) . ')';
        $args    = array_merge( $args, $aliases );

        if ( ! empty( $data['is_welcome'] ) || 'new_subscriber' === $trigger ) {
            $where[] = 'is_welcome = 1';
        }
        if ( ! empty( $data['is_post_purchase'] ) || 'post_purchase' === $trigger ) {
            $where[] = 'is_post_purchase = 1';
        }

        $statuses = array( 'active', 'draft', 'paused', 'scheduled', 'queued' );
        $args     = array_merge( $statuses, $args );

        $sql = "SELECT COUNT(*) FROM {$table} WHERE status IN (" . implode( ', ', array_fill( 0, count( $statuses ), '%s' ) ) . ') AND (' . implode( ' OR ', $where ) . ')';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $found = (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) );

        return $found > 0;
    }

    /**
     * Trigger aliases used to avoid duplicate starter campaigns.
     *
     * @param string $trigger Trigger key.
     * @return array
     */
    protected static function get_trigger_aliases( $trigger ) {
        $trigger = sanitize_key( (string) $trigger );
        $map     = array(
            'new_subscriber'              => array( 'new_subscriber', 'welcome', 'new-subscriber', 'signup', 'signup_form', 'list_join', 'welcome_subscriber' ),
            'welcome_follow_up'           => array( 'welcome_follow_up', 'welcome-follow-up', 'subscriber_welcome_follow_up', 'subscriber_welcome_followup' ),
            'lead_magnet_download'        => array( 'lead_magnet_download', 'lead_magnet_delivery', 'lead-magnet-download', 'lead-magnet-delivery' ),
            'subscriber_inactive'         => array( 'subscriber_inactive', 'subscriber-inactive' ),
            'subscriber_anniversary'      => array( 'subscriber_anniversary', 'anniversary', 'subscriber-anniversary' ),
            'subscriber_birthday'         => array( 'subscriber_birthday', 'birthday', 'subscriber-birthday' ),
            'new_customer'                => array( 'new_customer', 'first_order', 'new-customer' ),
            'repeat_customer'             => array( 'repeat_customer', 'repeat', 'repeat_customer_2plus', 'repeat-customer' ),
            'post_purchase'               => array( 'post_purchase', 'post-purchase' ),
            'review_request'              => array( 'review_request', 'review', 'review-request' ),
            'customer_inactive'           => array( 'customer_inactive', 'inactive', 'win_back_automation', 'winback', 'win_back', 'customer-inactive', 'inactive_customers' ),
            'high_value'                  => array( 'high_value', 'high-value', 'high_value_customer' ),
            'lapsed_high_value_customer'  => array( 'lapsed_high_value_customer', 'lapsed-high-value-customer', 'lapsed_high_value', 'high_value_lapsed', 'lapsed_vip_offer' ),
            'vip_customer'                => array( 'vip_customer', 'vip', 'top_spenders', 'vip-customer' ),
            'abandoned_cart_step_1'       => array( 'abandoned_cart_step_1', 'abandoned_cart', 'abandoned-cart-step-1' ),
            'abandoned_cart_step_2'       => array( 'abandoned_cart_step_2', 'abandoned-cart-step-2' ),
            'abandoned_cart_step_3'       => array( 'abandoned_cart_step_3', 'abandoned-cart-step-3' ),
            'welcome_series_step_1'      => array( 'new_subscriber', 'welcome', 'new-subscriber', 'signup', 'signup_form', 'list_join', 'welcome_subscriber' ),
            'welcome_series_step_2'      => array( 'new_subscriber', 'welcome', 'new-subscriber', 'signup', 'signup_form', 'list_join', 'welcome_subscriber' ),
            'welcome_series_step_3'      => array( 'new_subscriber', 'welcome', 'new-subscriber', 'signup', 'signup_form', 'list_join', 'welcome_subscriber' ),
            'post_purchase_sequence_step_1' => array( 'post_purchase', 'post-purchase' ),
            'post_purchase_sequence_step_2' => array( 'post_purchase', 'post-purchase' ),
            'post_purchase_sequence_step_3' => array( 'post_purchase', 'post-purchase' ),
            'customer_winback_sequence_step_1' => array( 'customer_inactive', 'inactive', 'win_back_automation', 'winback', 'win_back', 'customer-inactive', 'inactive_customers' ),
            'customer_winback_sequence_step_2' => array( 'customer_inactive', 'inactive', 'win_back_automation', 'winback', 'win_back', 'customer-inactive', 'inactive_customers' ),
        );

        return isset( $map[ $trigger ] ) ? array_map( 'sanitize_key', $map[ $trigger ] ) : array( $trigger );
    }

    /**
     * Build a campaign row for insertion into pmcpc_campaigns.
     *
     * @param string $kind       Starter kind.
     * @param string $site_name  Site name.
     * @param string $from_name  Default from name.
     * @param string $from_email Default from email.
     * @param string $now        Current GMT timestamp.
     * @return array
     */
    protected static function build_campaign_row( $kind, $site_name, $from_name, $from_email, $now ) {
        $kind = sanitize_key( (string) $kind );

        $base_footer = '<p style="font-size:12px;color:#6b7280;margin-top:24px;"></p>';
        $product_block = '<p>{{products_block}}</p>';

        $name                        = '';
        $subject                     = '';
        $content                     = '';
        $automation_trigger          = 'none';
        $campaign_type               = 'automation';
        $status                      = 'active';
        $is_welcome                  = 0;
        $is_post_purchase            = 0;
        $welcome_delay_minutes       = 0;
        $post_purchase_delay_minutes = 0;
        $trigger_delay_minutes       = 0;
        $pro_segment_key             = null;
        $product_block_enabled       = 1;
        $product_block_source        = 'latest';
        $product_block_limit         = 4;
        $workflow_key                = null;
        $workflow_name               = null;
        $workflow_step               = 0;

        switch ( $kind ) {
            case 'new_subscriber':
                $automation_trigger    = 'new_subscriber';
                $is_welcome            = 1;
                $product_block_enabled = 1;
                $name                  = sprintf( 'Automation: New subscriber welcome · %s', $site_name );
                $subject               = sprintf( __( 'Welcome to %s', 'product-mailer-campaigns' ), $site_name );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'Thank you for joining %s. Here are a few newly listed pieces we thought you might enjoy.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'welcome_follow_up':
                $automation_trigger    = 'welcome_follow_up';
                $trigger_delay_minutes = 4320; // 3 days.
                $name                  = sprintf( 'Automation: Welcome follow-up · %s', $site_name );
                $subject               = __( 'A few pieces you may have missed', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'We wanted to share a little more from %s and highlight a few pieces that may suit your home.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'lead_magnet_download':
                $automation_trigger    = 'lead_magnet_download';
                $product_block_enabled = 0;
                $name                  = sprintf( 'Automation: Lead magnet delivery · %s', $site_name );
                $subject               = __( 'Here is your download', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'Thank you for signing up. Here is the resource you requested:', 'product-mailer-campaigns' ) . '</p>'
                    . '<p><a href="{{lead_magnet_url}}">' . esc_html__( 'Open your resource', 'product-mailer-campaigns' ) . '</a></p>'
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'subscriber_inactive':
                $automation_trigger = 'subscriber_inactive';
                $name               = sprintf( 'Automation: Subscriber re-engagement · %s', $site_name );
                $subject            = __( 'Still interested in hearing from us?', 'product-mailer-campaigns' );
                $content            = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'It has been a while since we last heard from you. We have added new pieces and updates from %s that you may enjoy.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'subscriber_anniversary':
                $automation_trigger    = 'subscriber_anniversary';
                $product_block_enabled = 0;
                $name                  = sprintf( 'Automation: Subscriber anniversary · %s', $site_name );
                $subject               = __( 'Thank you for being with us', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'It is your anniversary with %s, and we wanted to say thank you for being part of our mailing list.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'subscriber_birthday':
                $automation_trigger    = 'subscriber_birthday';
                $product_block_enabled = 0;
                $name                  = sprintf( 'Automation: Subscriber birthday · %s', $site_name );
                $subject               = __( 'A birthday note from us', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'Happy birthday from all of us at %s. We hope you have a wonderful day.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'new_customer':
                $automation_trigger = 'new_customer';
                $pro_segment_key    = 'new_customers';
                $name               = sprintf( 'Automation: First order · %s', $site_name );
                $subject            = sprintf( __( 'Thank you for your first order from %s', 'product-mailer-campaigns' ), $site_name );
                $content            = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'Thank you for your first order from %s. We are delighted to welcome you as a customer.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'With appreciation,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'repeat_customer':
                $automation_trigger = 'repeat_customer';
                $pro_segment_key    = 'repeat_customers';
                $name               = sprintf( 'Automation: Repeat customer · %s', $site_name );
                $subject            = __( 'Thank you for coming back', 'product-mailer-campaigns' );
                $content            = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'Thank you for choosing %s again. We truly appreciate your continued custom.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'post_purchase':
                $automation_trigger = 'post_purchase';
                $is_post_purchase   = 1;
                $pro_segment_key    = 'customers';
                $name               = sprintf( 'Automation: Post-purchase · %s', $site_name );
                $subject            = sprintf( __( 'Thank you for your order from %s', 'product-mailer-campaigns' ), $site_name );
                $content            = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'Thank you for your recent purchase from %s. If you would like a first look at a few complementary pieces, we have selected some below.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'With appreciation,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'review_request':
                $automation_trigger    = 'review_request';
                $pro_segment_key       = 'customers';
                $trigger_delay_minutes = 10080; // 7 days.
                $name                  = sprintf( 'Automation: Review request · %s', $site_name );
                $subject               = __( 'How did we do?', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'We hope you are enjoying your recent purchase. If you have a moment, we would be grateful for a quick review — it genuinely helps a small business like ours.', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'Thank you again for choosing us.', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'Kind regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                $product_block_enabled = 0;
                break;

            case 'customer_inactive':
                $automation_trigger = 'customer_inactive';
                $pro_segment_key    = 'lapsed';
                $name               = sprintf( 'Automation: Customer win-back · %s', $site_name );
                $subject            = __( 'We have some new arrivals you may like', 'product-mailer-campaigns' );
                $content            = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'It has been a little while since your last visit to %s. We have added several new pieces to the collection and thought you might like a look.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'high_value':
                $automation_trigger = 'high_value';
                $pro_segment_key    = 'high_value';
                $name               = sprintf( 'Automation: High-value customer · %s', $site_name );
                $subject            = __( 'A private first look for you', 'product-mailer-campaigns' );
                $content            = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'As one of our valued customers, we wanted to give you an early look at a few pieces before they are shared more widely.', 'product-mailer-campaigns' ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'lapsed_high_value_customer':
                $automation_trigger = 'lapsed_high_value_customer';
                $pro_segment_key    = 'high_value';
                $name               = sprintf( 'Automation: Lapsed high-value customer · %s', $site_name );
                $subject            = __( 'A personal note from us', 'product-mailer-campaigns' );
                $content            = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'It has been a little while since we saw you at %s. We have selected a few new pieces that may be of interest.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'vip_customer':
                $automation_trigger = 'vip_customer';
                $pro_segment_key    = 'vip';
                $name               = sprintf( 'Automation: VIP customer · %s', $site_name );
                $subject            = __( 'An exclusive note for our VIP customers', 'product-mailer-campaigns' );
                $content            = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'Thank you for being one of our most valued customers. Here is an early look at selected pieces and offers reserved for our VIP list.', 'product-mailer-campaigns' ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;


            case 'welcome_series_step_1':
                $automation_trigger    = 'new_subscriber';
                $is_welcome            = 1;
                $workflow_key          = 'welcome_series';
                $workflow_name         = __( 'New subscriber welcome series', 'product-mailer-campaigns' );
                $workflow_step         = 1;
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( $kind );
                $name                  = sprintf( 'Workflow: Welcome series · Step 1 · %s', $site_name );
                $subject               = sprintf( __( 'Welcome to %s', 'product-mailer-campaigns' ), $site_name );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'Thank you for joining %s. We are delighted to welcome you to our mailing list.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'welcome_series_step_2':
                $automation_trigger    = 'new_subscriber';
                $workflow_key          = 'welcome_series';
                $workflow_name         = __( 'New subscriber welcome series', 'product-mailer-campaigns' );
                $workflow_step         = 2;
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( $kind );
                $name                  = sprintf( 'Workflow: Welcome series · Step 2 · %s', $site_name );
                $subject               = __( 'A few pieces you may have missed', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'We wanted to share a little more from %s and highlight a few pieces that may suit your home.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'welcome_series_step_3':
                $automation_trigger    = 'new_subscriber';
                $workflow_key          = 'welcome_series';
                $workflow_name         = __( 'New subscriber welcome series', 'product-mailer-campaigns' );
                $workflow_step         = 3;
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( $kind );
                $name                  = sprintf( 'Workflow: Welcome series · Step 3 · %s', $site_name );
                $subject               = __( 'A private note for our subscribers', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'As a subscriber, you will receive early notes about selected arrivals, special pieces, and occasional offers.', 'product-mailer-campaigns' ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'post_purchase_sequence_step_1':
                $automation_trigger    = 'post_purchase';
                $is_post_purchase      = 1;
                $pro_segment_key       = 'customers';
                $workflow_key          = 'post_purchase_sequence';
                $workflow_name         = __( 'Post-purchase follow-up sequence', 'product-mailer-campaigns' );
                $workflow_step         = 1;
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( $kind );
                $name                  = sprintf( 'Workflow: Post-purchase · Step 1 · %s', $site_name );
                $subject               = sprintf( __( 'Thank you for your order from %s', 'product-mailer-campaigns' ), $site_name );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'Thank you for your recent purchase from %s. We truly appreciate your order.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . '<p>' . sprintf( __( 'With appreciation,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                $product_block_enabled = 0;
                break;

            case 'post_purchase_sequence_step_2':
                $automation_trigger    = 'post_purchase';
                $is_post_purchase      = 1;
                $pro_segment_key       = 'customers';
                $workflow_key          = 'post_purchase_sequence';
                $workflow_name         = __( 'Post-purchase follow-up sequence', 'product-mailer-campaigns' );
                $workflow_step         = 2;
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( $kind );
                $name                  = sprintf( 'Workflow: Post-purchase · Step 2 · %s', $site_name );
                $subject               = __( 'How did we do?', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'We hope you are enjoying your recent purchase. If you have a moment, we would be grateful for a quick review.', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'Kind regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                $product_block_enabled = 0;
                break;

            case 'post_purchase_sequence_step_3':
                $automation_trigger    = 'post_purchase';
                $is_post_purchase      = 1;
                $pro_segment_key       = 'customers';
                $workflow_key          = 'post_purchase_sequence';
                $workflow_name         = __( 'Post-purchase follow-up sequence', 'product-mailer-campaigns' );
                $workflow_step         = 3;
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( $kind );
                $name                  = sprintf( 'Workflow: Post-purchase · Step 3 · %s', $site_name );
                $subject               = __( 'A few pieces to complement your order', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'We thought you might enjoy seeing a few related pieces from the collection.', 'product-mailer-campaigns' ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'customer_winback_sequence_step_1':
                $automation_trigger    = 'customer_inactive';
                $pro_segment_key       = 'lapsed';
                $workflow_key          = 'customer_winback_sequence';
                $workflow_name         = __( 'Customer win-back sequence', 'product-mailer-campaigns' );
                $workflow_step         = 1;
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( $kind );
                $name                  = sprintf( 'Workflow: Customer win-back · Step 1 · %s', $site_name );
                $subject               = __( 'We have some new arrivals you may like', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . sprintf( __( 'It has been a little while since your last visit to %s. We have added several new pieces to the collection and thought you might like a look.', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'customer_winback_sequence_step_2':
                $automation_trigger    = 'customer_inactive';
                $pro_segment_key       = 'lapsed';
                $workflow_key          = 'customer_winback_sequence';
                $workflow_name         = __( 'Customer win-back sequence', 'product-mailer-campaigns' );
                $workflow_step         = 2;
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( $kind );
                $name                  = sprintf( 'Workflow: Customer win-back · Step 2 · %s', $site_name );
                $subject               = __( 'A final note from us', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'Just a final note in case you would like to see what is new. We would be delighted to welcome you back whenever the time is right.', 'product-mailer-campaigns' ) . '</p>'
                    . $product_block
                    . '<p>' . sprintf( __( 'Warm regards,<br>%s', 'product-mailer-campaigns' ), esc_html( $site_name ) ) . '</p>'
                    . $base_footer;
                break;

            case 'abandoned_cart_step_1':
                $automation_trigger    = 'abandoned_cart_step_1';
                $pro_segment_key       = 'abandoned_cart';
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( 'abandoned_cart_step_1' );
                $name                  = sprintf( 'Automation: Abandoned cart · Step 1 · %s', $site_name );
                $subject               = __( 'Did you mean to check out?', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'It looks like you left a few items in your basket. If you would like to complete your order, you can return to your cart below.', 'product-mailer-campaigns' ) . '</p>'
                    . '<p><a href="{{cart_recovery_url}}">' . esc_html__( 'Return to your cart', 'product-mailer-campaigns' ) . '</a></p>'
                    . $base_footer;
                $product_block_enabled = 0;
                break;

            case 'abandoned_cart_step_2':
                $automation_trigger    = 'abandoned_cart_step_2';
                $pro_segment_key       = 'abandoned_cart';
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( 'abandoned_cart_step_2' );
                $name                  = sprintf( 'Automation: Abandoned cart · Step 2 · %s', $site_name );
                $subject               = __( 'Still thinking it over?', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'Just a quick reminder — your cart is still saved. If you have any questions, simply reply and we will be happy to help.', 'product-mailer-campaigns' ) . '</p>'
                    . '<p><a href="{{cart_recovery_url}}">' . esc_html__( 'Complete your checkout', 'product-mailer-campaigns' ) . '</a></p>'
                    . $base_footer;
                $product_block_enabled = 0;
                break;

            case 'abandoned_cart_step_3':
                $automation_trigger    = 'abandoned_cart_step_3';
                $pro_segment_key       = 'abandoned_cart';
                $trigger_delay_minutes = self::get_default_trigger_delay_minutes( 'abandoned_cart_step_3' );
                $name                  = sprintf( 'Automation: Abandoned cart · Step 3 · %s', $site_name );
                $subject               = __( 'Last chance to complete your order', 'product-mailer-campaigns' );
                $content               = '<p>' . __( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>'
                    . '<p>' . __( 'We will hold your cart a little longer, in case you would like to complete your purchase.', 'product-mailer-campaigns' ) . '</p>'
                    . '<p><a href="{{cart_recovery_url}}">' . esc_html__( 'Return to your cart', 'product-mailer-campaigns' ) . '</a></p>'
                    . $base_footer;
                $product_block_enabled = 0;
                break;

            default:
                return array();
        }

        if ( $is_welcome ) {
            $trigger_delay_minutes = (int) $welcome_delay_minutes;
        } elseif ( $is_post_purchase && 0 === (int) $trigger_delay_minutes ) {
            $trigger_delay_minutes = (int) $post_purchase_delay_minutes;
        }

        $schedule_type = ( 'none' === $automation_trigger || '' === $automation_trigger ) ? 'manual' : 'triggered';

        return array(
            'name'                       => $name,
            'campaign_type'              => $campaign_type,
            'automation_trigger'         => $automation_trigger,
            'pro_segment_key'            => $pro_segment_key,
            'workflow_key'               => $workflow_key,
            'workflow_name'              => $workflow_name,
            'workflow_step'              => (int) $workflow_step,
            'subject'                    => $subject,
            'from_name'                  => $from_name,
            'from_email'                 => $from_email,
            'content'                    => $content,
            'status'                     => $status,
            'is_welcome'                 => $is_welcome,
            'is_post_purchase'           => $is_post_purchase,
            'target_tag'                 => null,
            'trigger_delay_minutes'      => (int) $trigger_delay_minutes,
            'schedule_type'              => $schedule_type,
            'schedule_datetime'          => null,
            'schedule_frequency'         => null,
            'next_run_at'                => null,
            'product_block_enabled'      => (int) $product_block_enabled,
            'product_block_source'       => $product_block_source,
            'product_block_limit'        => (int) $product_block_limit,
            'auto_footer_links_enabled'  => 1,
            'created_at'                 => $now,
            'updated_at'                 => $now,
        );
    }
}
