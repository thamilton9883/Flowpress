<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Hard gate to prevent legacy/short prefixes (pmc / PMC_) slipping back into the codebase.
 *
 * WordPress.org reviewers often flag short prefixes because they can collide with other plugins.
 * This guard is intentionally strict: if it finds legacy prefixes in plugin PHP/JS/CSS files,
 * activation is blocked with a clear error listing offending files.
 */
class PMCPC_Prefix_Guard {

    /**
     * Files that are safe to ignore (paths relative to plugin dir).
     * Keep this small; the goal is to catch regressions.
     */
    protected static function get_ignored_paths() {
        return array(
            // This file necessarily contains legacy tokens in its pattern list / copy.
            'includes/class-pmcpc-prefix-guard.php',
            'vendor/',
            'node_modules/',
            '.git/',
        );
    }

    /**
     * Scan for legacy prefixes and block activation if any are found.
     */
    public static function validate_or_die() {
        $issues = self::scan_plugin_for_legacy_prefixes();
        if ( empty( $issues ) ) {
            return;
        }

        if ( function_exists( 'deactivate_plugins' ) && defined( 'PMCPC_PLUGIN_FILE' ) ) {
            deactivate_plugins( plugin_basename( PMCPC_PLUGIN_FILE ) );
        }

        $lines = array();
        foreach ( $issues as $issue ) {
            $lines[] = esc_html( $issue );
        }

        wp_die(
            '<h1>' . esc_html__( 'Activation blocked: legacy prefix detected', 'product-mailer-campaigns' ) . '</h1>' .
            '<p>' . esc_html__( 'This plugin enforces a consistent 5-letter prefix (pmcpc) to avoid collisions and improve WordPress.org review outcomes.', 'product-mailer-campaigns' ) . '</p>' .
            '<p>' . esc_html__( 'The following files still contain legacy “pmc”/“PMC_” style identifiers:', 'product-mailer-campaigns' ) . '</p>' .
            wp_kses( '<ul><li>' . implode( '</li><li>', array_map( 'esc_html', $lines ) ) . '</li></ul>', array( 'ul' => array(), 'li' => array() ) ) .
            '<p>' . esc_html__( 'Fix the files above and try activating again.', 'product-mailer-campaigns' ) . '</p>',
            esc_html__( 'FlowPress', 'product-mailer-campaigns' ),
            array( 'response' => 500 )
        );
    }

    /**
     * @return string[] list of "path:line" issues
     */
    protected static function scan_plugin_for_legacy_prefixes() {
        if ( ! defined( 'PMCPC_PLUGIN_DIR' ) ) {
            return array();
        }

        $base = rtrim( PMCPC_PLUGIN_DIR, '/\\' ) . DIRECTORY_SEPARATOR;
        if ( ! is_dir( $base ) ) {
            return array();
        }

        $allowed_ext = array( 'php', 'js', 'css', 'json', 'txt', 'md' );

        // Patterns that indicate legacy/short prefix usage.
        // We purposely avoid matching inside the word "campaign".
        $patterns = array(
            '/\\bPMC_\\w+/m',
            '/\\bpmc_(\\w+)/m',
            '/\\bpmc-(\\w+)/m',
            // Match legacy ajax action prefixes, but DO NOT flag the valid "pmcpc_*" actions.
            // Examples to flag: wp_ajax_pmc_click, wp_ajax_nopriv_pmc_open
            // Examples to allow: wp_ajax_pmcpc_click, wp_ajax_nopriv_pmcpc_open
            '/\\bwp_ajax_(?:nopriv_)?pmc(?!pc)\\w*/m',
            '/\\bpmc\/?v\\d+/mi',
            '/class-pmc[^p]/mi',
        );

        $ignored = self::get_ignored_paths();

        $rii = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS )
        );

        $issues = array();

        foreach ( $rii as $file ) {
            /** @var SplFileInfo $file */
            if ( ! $file->isFile() ) {
                continue;
            }

            $rel = str_replace( $base, '', $file->getPathname() );
            $rel = str_replace( array( '\\', '//' ), '/', $rel );

            foreach ( $ignored as $ignore ) {
                if ( 0 === strpos( $rel, $ignore ) ) {
                    continue 2;
                }
            }

            $ext = strtolower( pathinfo( $rel, PATHINFO_EXTENSION ) );
            if ( ! in_array( $ext, $allowed_ext, true ) ) {
                continue;
            }

            $contents = file_get_contents( $file->getPathname() );
            if ( false === $contents || '' === $contents ) {
                continue;
            }

            // Quick skip if file doesn't even mention "pmc" or "PMC_".
            if ( false === strpos( $contents, 'pmc' ) && false === strpos( $contents, 'PMC_' ) ) {
                continue;
            }

            $lines = preg_split( '/\R/', $contents );
            if ( ! is_array( $lines ) ) {
                continue;
            }

            foreach ( $lines as $i => $line ) {
                foreach ( $patterns as $pat ) {
                    if ( preg_match( $pat, $line ) ) {
                        $issues[] = $rel . ':' . ( $i + 1 );
                        if ( count( $issues ) >= 50 ) {
                            return $issues;
                        }
                        break;
                    }
                }
            }
        }

        return $issues;
    }
}
