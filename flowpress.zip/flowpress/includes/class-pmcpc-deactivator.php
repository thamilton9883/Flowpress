<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Fired during plugin deactivation.
 */
class PMCPC_Deactivator {

    /**
     * Clear scheduled cron events when the plugin is deactivated.
     */
    public static function deactivate() {
        $hooks = array(
            'pmcpc_process_email_queue',
            'pmcpc_process_scheduled_campaigns',
            'pmcpc_cron_watchdog',
            'pmcpc_tracking_logs_cleanup',
            'pmcpc_inbox_cleanup',
            'pmcpc_queue_retention_cleanup',
            'pmcpc_daily_commerce_update',
            'pmcpc_recalculate_lifecycle_tags',
            'pmcpc_recalculate_health_tags',
            'pmcpc_abandoned_cart_sweep',
            'pmcpc_abandoned_cart_recovery_runner',
            'pmcpc_pro_cron_check_inactive_customers',
            'pmcpc_core_cron_check_subscriber_triggers',
        );

        foreach ( $hooks as $hook ) {
            self::remove_all_events_for_hook( $hook );
        }
    }

    /**
     * Directly remove all cron entries for a hook.
     *
     * @param string $hook Cron hook name.
     * @return void
     */
    protected static function remove_all_events_for_hook( $hook ) {
        $hook = (string) $hook;
        if ( '' === $hook || ! function_exists( '_get_cron_array' ) || ! function_exists( '_set_cron_array' ) ) {
            return;
        }

        $crons   = _get_cron_array();
        $changed = false;

        if ( empty( $crons ) || ! is_array( $crons ) ) {
            return;
        }

        foreach ( $crons as $timestamp => $hooks ) {
            if ( empty( $hooks[ $hook ] ) ) {
                continue;
            }

            unset( $crons[ $timestamp ][ $hook ] );
            $changed = true;

            if ( empty( $crons[ $timestamp ] ) ) {
                unset( $crons[ $timestamp ] );
            }
        }

        if ( $changed ) {
            _set_cron_array( $crons );
        }
    }
}
