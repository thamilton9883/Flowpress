<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Get the stored daily analytics bucket data for subscriber updates.
 *
 * @return array
 */
function pmcpc_get_subscriber_updates_analytics_store() {
    $store = get_option( 'pmcpc_sub_updates_daily_stats', array() );
    if ( ! is_array( $store ) ) {
        $store = array();
    }
    if ( empty( $store['days'] ) || ! is_array( $store['days'] ) ) {
        $store['days'] = array();
    }
    if ( empty( $store['retention_days'] ) ) {
        $store['retention_days'] = 90;
    }
    $store['retention_days'] = max( 30, min( 365, absint( $store['retention_days'] ) ) );
    return $store;
}

/**
 * Record a subscriber update analytics event in a lightweight daily store.
 *
 * @param int    $post_id Subscriber update post ID.
 * @param string $event   Event key.
 * @param array  $context Optional context array.
 * @return void
 */
function pmcpc_record_subscriber_update_event( $post_id, $event, $context = array() ) {
    $post_id = absint( $post_id );
    $event   = sanitize_key( (string) $event );
    if ( ! $post_id || '' === $event ) {
        return;
    }

    $allowed_events = array( 'view', 'subscriber_view', 'cta_click', 'unlock', 'product_click' );
    if ( ! in_array( $event, $allowed_events, true ) ) {
        return;
    }

    $store   = pmcpc_get_subscriber_updates_analytics_store();
    $day_key = function_exists( 'wp_date' ) ? wp_date( 'Y-m-d' ) : gmdate( 'Y-m-d' );
    if ( empty( $store['days'][ $day_key ] ) || ! is_array( $store['days'][ $day_key ] ) ) {
        $store['days'][ $day_key ] = array(
            'views'            => 0,
            'subscriber_views' => 0,
            'cta_clicks'       => 0,
            'unlocks'          => 0,
            'product_clicks'   => 0,
            'by_post'          => array(),
            'by_campaign'      => array(),
            'by_segment'       => array(),
        );
    }

    $map = array(
        'view'            => 'views',
        'subscriber_view' => 'subscriber_views',
        'cta_click'       => 'cta_clicks',
        'unlock'          => 'unlocks',
        'product_click'   => 'product_clicks',
    );
    $bucket_key = $map[ $event ];
    $store['days'][ $day_key ][ $bucket_key ] = isset( $store['days'][ $day_key ][ $bucket_key ] ) ? ( (int) $store['days'][ $day_key ][ $bucket_key ] + 1 ) : 1;

    $post_title = get_the_title( $post_id );
    if ( empty( $store['days'][ $day_key ]['by_post'][ $post_id ] ) || ! is_array( $store['days'][ $day_key ]['by_post'][ $post_id ] ) ) {
        $store['days'][ $day_key ]['by_post'][ $post_id ] = array(
            'title'            => sanitize_text_field( (string) $post_title ),
            'views'            => 0,
            'subscriber_views' => 0,
            'cta_clicks'       => 0,
            'unlocks'          => 0,
            'product_clicks'   => 0,
        );
    }
    $store['days'][ $day_key ]['by_post'][ $post_id ]['title'] = sanitize_text_field( (string) $post_title );
    $store['days'][ $day_key ]['by_post'][ $post_id ][ $bucket_key ] = isset( $store['days'][ $day_key ]['by_post'][ $post_id ][ $bucket_key ] ) ? ( (int) $store['days'][ $day_key ]['by_post'][ $post_id ][ $bucket_key ] + 1 ) : 1;

    $campaign_id = absint( get_post_meta( $post_id, '_pmcpc_campaign_id', true ) );
    if ( $campaign_id ) {
        if ( empty( $store['days'][ $day_key ]['by_campaign'][ $campaign_id ] ) || ! is_array( $store['days'][ $day_key ]['by_campaign'][ $campaign_id ] ) ) {
            $store['days'][ $day_key ]['by_campaign'][ $campaign_id ] = array(
                'name'             => sanitize_text_field( (string) get_the_title( $post_id ) ),
                'views'            => 0,
                'subscriber_views' => 0,
                'cta_clicks'       => 0,
                'unlocks'          => 0,
                'product_clicks'   => 0,
            );
        }
        $store['days'][ $day_key ]['by_campaign'][ $campaign_id ][ $bucket_key ] = isset( $store['days'][ $day_key ]['by_campaign'][ $campaign_id ][ $bucket_key ] ) ? ( (int) $store['days'][ $day_key ]['by_campaign'][ $campaign_id ][ $bucket_key ] + 1 ) : 1;
    }

    $segment = ! empty( $context['segment'] ) ? sanitize_text_field( (string) $context['segment'] ) : sanitize_text_field( (string) get_post_meta( $post_id, '_pmcpc_required_segment', true ) );
    if ( '' !== $segment ) {
        if ( empty( $store['days'][ $day_key ]['by_segment'][ $segment ] ) || ! is_array( $store['days'][ $day_key ]['by_segment'][ $segment ] ) ) {
            $store['days'][ $day_key ]['by_segment'][ $segment ] = array(
                'views'            => 0,
                'subscriber_views' => 0,
                'cta_clicks'       => 0,
                'unlocks'          => 0,
                'product_clicks'   => 0,
            );
        }
        $store['days'][ $day_key ]['by_segment'][ $segment ][ $bucket_key ] = isset( $store['days'][ $day_key ]['by_segment'][ $segment ][ $bucket_key ] ) ? ( (int) $store['days'][ $day_key ]['by_segment'][ $segment ][ $bucket_key ] + 1 ) : 1;
    }

    ksort( $store['days'] );
    if ( count( $store['days'] ) > $store['retention_days'] ) {
        $store['days'] = array_slice( $store['days'], -1 * $store['retention_days'], null, true );
    }

    update_option( 'pmcpc_sub_updates_daily_stats', $store, false );
}

/**
 * Summarise subscriber update analytics for a selected time range.
 *
 * @param int $days Number of days to include.
 * @return array
 */
function pmcpc_get_subscriber_updates_analytics_summary( $days = 30 ) {
    $days    = max( 1, min( 365, absint( $days ) ) );
    $store   = pmcpc_get_subscriber_updates_analytics_store();
    $summary = array(
        'days'            => array(),
        'totals'          => array( 'views' => 0, 'subscriber_views' => 0, 'clicks' => 0, 'unlocks' => 0 ),
        'top_posts'       => array(),
        'top_segments'    => array(),
        'top_campaigns'   => array(),
        'conversion_rate' => 0,
        'unlock_rate'     => 0,
    );

    $cutoff = strtotime( '-' . ( $days - 1 ) . ' days', current_time( 'timestamp' ) );
    foreach ( $store['days'] as $day_key => $day_data ) {
        $day_ts = strtotime( $day_key . ' 00:00:00' );
        if ( ! $day_ts || $day_ts < $cutoff ) {
            continue;
        }

        $day_views            = isset( $day_data['views'] ) ? (int) $day_data['views'] : 0;
        $day_subscriber_views = isset( $day_data['subscriber_views'] ) ? (int) $day_data['subscriber_views'] : 0;
        $day_clicks           = ( isset( $day_data['cta_clicks'] ) ? (int) $day_data['cta_clicks'] : 0 ) + ( isset( $day_data['product_clicks'] ) ? (int) $day_data['product_clicks'] : 0 );
        $day_unlocks          = isset( $day_data['unlocks'] ) ? (int) $day_data['unlocks'] : 0;

        $summary['days'][ $day_key ] = array(
            'views'            => $day_views,
            'subscriber_views' => $day_subscriber_views,
            'clicks'           => $day_clicks,
            'unlocks'          => $day_unlocks,
        );

        $summary['totals']['views']            += $day_views;
        $summary['totals']['subscriber_views'] += $day_subscriber_views;
        $summary['totals']['clicks']           += $day_clicks;
        $summary['totals']['unlocks']          += $day_unlocks;

        if ( ! empty( $day_data['by_post'] ) && is_array( $day_data['by_post'] ) ) {
            foreach ( $day_data['by_post'] as $by_post_id => $post_data ) {
                $by_post_id = absint( $by_post_id );
                if ( empty( $summary['top_posts'][ $by_post_id ] ) ) {
                    $summary['top_posts'][ $by_post_id ] = array(
                        'title'            => isset( $post_data['title'] ) ? sanitize_text_field( (string) $post_data['title'] ) : '',
                        'views'            => 0,
                        'subscriber_views' => 0,
                        'clicks'           => 0,
                        'unlocks'          => 0,
                    );
                }
                $summary['top_posts'][ $by_post_id ]['views']            += isset( $post_data['views'] ) ? (int) $post_data['views'] : 0;
                $summary['top_posts'][ $by_post_id ]['subscriber_views'] += isset( $post_data['subscriber_views'] ) ? (int) $post_data['subscriber_views'] : 0;
                $summary['top_posts'][ $by_post_id ]['clicks']           += ( isset( $post_data['cta_clicks'] ) ? (int) $post_data['cta_clicks'] : 0 ) + ( isset( $post_data['product_clicks'] ) ? (int) $post_data['product_clicks'] : 0 );
                $summary['top_posts'][ $by_post_id ]['unlocks']          += isset( $post_data['unlocks'] ) ? (int) $post_data['unlocks'] : 0;
            }
        }

        if ( ! empty( $day_data['by_segment'] ) && is_array( $day_data['by_segment'] ) ) {
            foreach ( $day_data['by_segment'] as $segment => $segment_data ) {
                $segment = sanitize_text_field( (string) $segment );
                if ( '' === $segment ) {
                    continue;
                }
                if ( empty( $summary['top_segments'][ $segment ] ) ) {
                    $summary['top_segments'][ $segment ] = array( 'views' => 0, 'subscriber_views' => 0, 'clicks' => 0, 'unlocks' => 0 );
                }
                $summary['top_segments'][ $segment ]['views']            += isset( $segment_data['views'] ) ? (int) $segment_data['views'] : 0;
                $summary['top_segments'][ $segment ]['subscriber_views'] += isset( $segment_data['subscriber_views'] ) ? (int) $segment_data['subscriber_views'] : 0;
                $summary['top_segments'][ $segment ]['clicks']           += ( isset( $segment_data['cta_clicks'] ) ? (int) $segment_data['cta_clicks'] : 0 ) + ( isset( $segment_data['product_clicks'] ) ? (int) $segment_data['product_clicks'] : 0 );
                $summary['top_segments'][ $segment ]['unlocks']          += isset( $segment_data['unlocks'] ) ? (int) $segment_data['unlocks'] : 0;
            }
        }

        if ( ! empty( $day_data['by_campaign'] ) && is_array( $day_data['by_campaign'] ) ) {
            foreach ( $day_data['by_campaign'] as $campaign_id => $campaign_data ) {
                $campaign_id = absint( $campaign_id );
                if ( empty( $summary['top_campaigns'][ $campaign_id ] ) ) {
                    $summary['top_campaigns'][ $campaign_id ] = array(
                        'name'             => isset( $campaign_data['name'] ) ? sanitize_text_field( (string) $campaign_data['name'] ) : '',
                        'views'            => 0,
                        'subscriber_views' => 0,
                        'clicks'           => 0,
                        'unlocks'          => 0,
                    );
                }
                $summary['top_campaigns'][ $campaign_id ]['views']            += isset( $campaign_data['views'] ) ? (int) $campaign_data['views'] : 0;
                $summary['top_campaigns'][ $campaign_id ]['subscriber_views'] += isset( $campaign_data['subscriber_views'] ) ? (int) $campaign_data['subscriber_views'] : 0;
                $summary['top_campaigns'][ $campaign_id ]['clicks']           += ( isset( $campaign_data['cta_clicks'] ) ? (int) $campaign_data['cta_clicks'] : 0 ) + ( isset( $campaign_data['product_clicks'] ) ? (int) $campaign_data['product_clicks'] : 0 );
                $summary['top_campaigns'][ $campaign_id ]['unlocks']          += isset( $campaign_data['unlocks'] ) ? (int) $campaign_data['unlocks'] : 0;
            }
        }
    }

    uasort(
        $summary['top_posts'],
        function( $a, $b ) {
            return ( (int) $b['views'] + (int) $b['clicks'] ) <=> ( (int) $a['views'] + (int) $a['clicks'] );
        }
    );
    uasort(
        $summary['top_segments'],
        function( $a, $b ) {
            return ( (int) $b['subscriber_views'] + (int) $b['unlocks'] ) <=> ( (int) $a['subscriber_views'] + (int) $a['unlocks'] );
        }
    );
    uasort(
        $summary['top_campaigns'],
        function( $a, $b ) {
            return ( (int) $b['views'] + (int) $b['clicks'] ) <=> ( (int) $a['views'] + (int) $a['clicks'] );
        }
    );

    if ( $summary['totals']['views'] > 0 ) {
        $summary['conversion_rate'] = round( ( $summary['totals']['clicks'] / $summary['totals']['views'] ) * 100, 1 );
        $summary['unlock_rate']     = round( ( $summary['totals']['unlocks'] / $summary['totals']['views'] ) * 100, 1 );
    }

    return $summary;
}
