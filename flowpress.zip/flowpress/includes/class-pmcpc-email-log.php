<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PMCPC_Email_Log {

	/**
	 * Parse and normalize email-log filters from the current request.
	 *
	 * @return array<string,int|string>
	 */
	protected static function get_request_filters() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filters.
		$status = isset( $_GET['status'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['status'] ) ) : '';
		$status = strtolower( preg_replace( '/[^a-z0-9_\-]/', '', $status ) );
		$allowed_status = array( '', 'sent', 'failed' );
		if ( ! in_array( $status, $allowed_status, true ) ) {
			$status = '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filters.
		$campaign_id = isset( $_GET['campaign_id'] ) ? absint( wp_unslash( $_GET['campaign_id'] ) ) : 0;

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filters.
		$subscriber_search = isset( $_GET['subscriber'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['subscriber'] ) ) : '';
		$subscriber_search = trim( $subscriber_search );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filters.
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;

		return array(
			'status'            => $status,
			'campaign_id'       => $campaign_id,
			'subscriber_search' => $subscriber_search,
			'paged'             => $paged,
		);
	}

	/**
	 * Build a cache key for email-log queries.
	 *
	 * @param string $prefix Prefix for the cache key.
	 * @param array  $args   Cache key payload.
	 * @return string
	 */
	protected static function get_cache_key( $prefix, $args ) {
		return (string) $prefix . md5( wp_json_encode( $args ) );
	}

	/**
	 * Read a cached value or resolve and cache it.
	 *
	 * @param string   $key      Cache key.
	 * @param callable $resolver Callback that returns the uncached value.
	 * @param int      $ttl      Cache lifetime in seconds.
	 * @return mixed
	 */
	protected static function get_cached_value( $key, $resolver, $ttl = 300 ) {
		$value = wp_cache_get( $key, 'pmcpc' );
		if ( false !== $value ) {
			return $value;
		}

		$value = call_user_func( $resolver );
		wp_cache_set( $key, $value, 'pmcpc', $ttl );

		return $value;
	}

	/**
	 * Build the clear-filter URL for the email log screen.
	 *
	 * @param string $page_slug Admin page slug.
	 * @param string $tab       Optional active tab.
	 * @return string
	 */
	protected static function get_clear_url( $page_slug, $tab ) {
		$clear_url = admin_url( 'admin.php?page=' . sanitize_key( (string) $page_slug ) );
		if ( '' !== $tab ) {
			$clear_url = add_query_arg(
				array(
					'pmcpc_tab' => $tab,
					'tab'       => $tab,
				),
				$clear_url
			);
		}

		return $clear_url;
	}

	/**
	 * Build the base URL for paginated email-log links.
	 *
	 * @return string
	 */
	protected static function get_pagination_base_url() {
		return remove_query_arg( array( 'paged' ) );
	}

	/**
	 * Render hidden routing inputs for the email-log filter form.
	 *
	 * @param string $page_slug Admin page slug.
	 * @param string $tab       Optional active tab.
	 * @return void
	 */
	protected static function render_hidden_form_fields( $page_slug, $tab ) {
		echo '<input type="hidden" name="page" value="' . esc_attr( $page_slug ) . '" />';
		if ( '' !== $tab ) {
			// Use a plugin-specific query var for tab state, but also include the generic one for back-compat.
			echo '<input type="hidden" name="pmcpc_tab" value="' . esc_attr( $tab ) . '" />';
			echo '<input type="hidden" name="tab" value="' . esc_attr( $tab ) . '" />';
		}
	}

	/**
	 * Render pagination links for the email log screen.
	 *
	 * @param string $base_url    Base URL without paged.
	 * @param int    $paged       Current page number.
	 * @param int    $total_pages Total available pages.
	 * @return void
	 */
	protected static function render_pagination( $base_url, $paged, $total_pages ) {
		if ( $total_pages <= 1 ) {
			return;
		}

		echo '<div class="tablenav"><div class="tablenav-pages">';
		for ( $i = 1; $i <= $total_pages; $i++ ) {
			$url = add_query_arg( 'paged', $i, $base_url );
			if ( $i === $paged ) {
				echo '<span class="page-numbers current">' . esc_html( $i ) . '</span> ';
			} else {
				echo '<a class="page-numbers" href="' . esc_url( $url ) . '">' . esc_html( $i ) . '</a> ';
			}
		}
		echo '</div></div>';
	}

	/**
	 * Build the preview URL for a log entry.
	 *
	 * @param int $log_id Log entry ID.
	 * @return string
	 */
	protected static function get_view_url( $log_id ) {
		return admin_url( 'admin.php?page=pmcpc_view_email&log_id=' . absint( $log_id ) );
	}

	/**
	 * Build the resend URL for a log entry.
	 *
	 * @param int $log_id Log entry ID.
	 * @return string
	 */
	protected static function get_resend_url( $log_id ) {
		$log_id = absint( $log_id );

		return wp_nonce_url(
			admin_url( 'admin-post.php?action=pmcpc_resend_email&log_id=' . $log_id ),
			'pmcpc_resend_email_' . $log_id
		);
	}

	/**
	 * Render the filter form for the email log screen.
	 *
	 * @param string            $page_slug         Admin page slug.
	 * @param string            $tab               Optional active tab.
	 * @param string            $status            Selected status filter.
	 * @param int               $campaign_id       Selected campaign ID.
	 * @param string            $subscriber_search Subscriber email search term.
	 * @param array<int,object> $campaigns         Campaign dropdown options.
	 * @return void
	 */
	protected static function render_filter_form( $page_slug, $tab, $status, $campaign_id, $subscriber_search, $campaigns ) {
		echo '<div class="pmcpc-card" style="margin-top:14px;padding:14px 16px;">';
		echo '<div style="font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#3858e9;margin-bottom:12px;">' . esc_html__( 'Table filters', 'product-mailer-campaigns' ) . '</div>';
		echo '<form method="get" action="" class="pmcpc-table-toolbar" style="margin:0;padding:0;background:transparent;border:0;box-shadow:none;">';
		self::render_hidden_form_fields( $page_slug, $tab );
		echo '<div class="pmcpc-table-toolbar__group">';
		echo '<label class="screen-reader-text" for="pmcpc_log_status">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</label>';
		echo '<select id="pmcpc_log_status" name="status">';
		$status_options = array(
			''       => __( 'All statuses', 'product-mailer-campaigns' ),
			'sent'   => __( 'Sent', 'product-mailer-campaigns' ),
			'failed' => __( 'Failed', 'product-mailer-campaigns' ),
		);
		foreach ( $status_options as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '"' . selected( $status, $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<label class="screen-reader-text" for="pmcpc_log_campaign">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</label>';
		echo '<select id="pmcpc_log_campaign" name="campaign_id" style="min-width:280px;">';
		echo '<option value="0"' . selected( 0, $campaign_id, false ) . '>' . esc_html__( 'All campaigns', 'product-mailer-campaigns' ) . '</option>';
		if ( ! empty( $campaigns ) ) {
			foreach ( $campaigns as $campaign ) {
				echo '<option value="' . esc_attr( (int) $campaign->id ) . '"' . selected( $campaign_id, (int) $campaign->id, false ) . '>' . esc_html( $campaign->name ) . ' (#' . esc_html( (int) $campaign->id ) . ')</option>';
			}
		}
		echo '</select>';
		echo '<label class="screen-reader-text" for="pmcpc_log_subscriber">' . esc_html__( 'Subscriber', 'product-mailer-campaigns' ) . '</label>';
		echo '<input id="pmcpc_log_subscriber" type="text" name="subscriber" value="' . esc_attr( $subscriber_search ) . '" placeholder="' . esc_attr__( 'Search subscriber email…', 'product-mailer-campaigns' ) . '" style="min-width:220px;" />';
		submit_button( __( 'Filter', 'product-mailer-campaigns' ), 'secondary', '', false );
		if ( '' !== $status || 0 !== $campaign_id || '' !== $subscriber_search ) {
			$clear_url = self::get_clear_url( $page_slug, $tab );
			echo ' <a class="button" href="' . esc_url( $clear_url ) . '">' . esc_html__( 'Clear', 'product-mailer-campaigns' ) . '</a>';
		}
		echo '</div>';
		echo '</form>';
		echo '<p class="description" style="margin:10px 0 0;">' . esc_html__( 'Use filters to narrow the table without leaving Sent.', 'product-mailer-campaigns' ) . '</p>';
		echo '</div>';
	}

	/**
	 * Render the email-log results table.
	 *
	 * @param array<int,object> $rows Email-log rows.
	 * @return void
	 */
	protected static function render_results_table( $rows ) {
		echo '<div class="pmcpc-email-history-viewbar"><div class="pmcpc-email-history-viewbar__label">' . esc_html__( 'Visible columns', 'product-mailer-campaigns' ) . '</div><div class="pmcpc-email-history-viewbar__controls">';
		echo '<label class="pmcpc-email-history-viewbar__check"><input type="checkbox" class="pmcpc-email-history-column-toggle" data-column="campaign" checked /> ' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</label>';
		echo '<label class="pmcpc-email-history-viewbar__check"><input type="checkbox" class="pmcpc-email-history-column-toggle" data-column="status" checked /> ' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</label>';
		echo '<label class="pmcpc-email-history-viewbar__check"><input type="checkbox" class="pmcpc-email-history-column-toggle" data-column="sent" checked /> ' . esc_html__( 'Sent at', 'product-mailer-campaigns' ) . '</label>';
		echo '<label class="pmcpc-email-history-viewbar__check"><input type="checkbox" class="pmcpc-email-history-column-toggle" data-column="subject" checked /> ' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</label>';
		echo '<a href="#" class="pmcpc-email-history-columns-reset">' . esc_html__( 'Reset columns', 'product-mailer-campaigns' ) . '</a>';
		echo '</div></div>';
		echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
		echo '<table class="widefat striped pmcpc-wide-table pmcpc-wide-table--email-history">';
		echo '<thead><tr>';
		echo '<th class="pmcpc-col-metric">' . esc_html__( 'ID', 'product-mailer-campaigns' ) . '</th>';
		echo '<th class="pmcpc-email-history-col-campaign">' . esc_html__( 'Campaign', 'product-mailer-campaigns' ) . '</th>';
		echo '<th class="pmcpc-col-anchor">' . esc_html__( 'To', 'product-mailer-campaigns' ) . '</th>';
		echo '<th class="pmcpc-col-compare pmcpc-email-history-col-status">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
		echo '<th class="pmcpc-col-compare pmcpc-email-history-col-sent">' . esc_html__( 'Sent at', 'product-mailer-campaigns' ) . '</th>';
		echo '<th class="pmcpc-col-anchor pmcpc-email-history-col-subject">' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</th>';
		echo '<th class="pmcpc-col-actions">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rows as $row ) {
			$sent_at    = ! empty( $row->sent_at ) ? $row->sent_at : '';
			$view_url   = self::get_view_url( $row->id );
			$resend_url = self::get_resend_url( $row->id );
			$status     = isset( $row->status ) ? (string) $row->status : '';
			$status_meta = 'failed' === $status ? __( 'Needs review', 'product-mailer-campaigns' ) : '';

			echo '<tr>';
			echo '<td class="pmcpc-col-metric"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">#' . esc_html( (int) $row->id ) . '</span></div></td>';
			echo '<td class="pmcpc-email-history-col-campaign"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">#' . esc_html( (int) $row->campaign_id ) . '</span></div></td>';
			echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( $row->to_email ) . '</span></div></td>';
			echo '<td class="pmcpc-col-compare pmcpc-email-history-col-status"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $row->status ) . '</span>' . ( '' !== $status_meta ? '<span class="pmcpc-table-cell-stack__sub">' . esc_html( $status_meta ) . '</span>' : '' ) . '</div></td>';
			echo '<td class="pmcpc-col-compare pmcpc-email-history-col-sent"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $sent_at ) . '</span></div></td>';
			echo '<td class="pmcpc-col-anchor pmcpc-email-history-col-subject"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( $row->subject ) . '</span></div></td>';
			echo '<td class="pmcpc-col-actions"><div class="pmcpc-table-actions"><details class="pmcpc-table-actions__menu"><summary class="button button-small pmcpc-table-actions__summary">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</summary><div class="pmcpc-table-actions__popover"><a href="' . esc_url( $view_url ) . '">' . esc_html__( 'View', 'product-mailer-campaigns' ) . '</a><a href="' . esc_url( $resend_url ) . '" onclick="return confirm(\'' . esc_js( __( 'Resend this email?', 'product-mailer-campaigns' ) ) . '\')">' . esc_html__( 'Resend', 'product-mailer-campaigns' ) . '</a></div></details></div></td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
		echo '</div></div>';
	}

	/**
	 * One-time backfill: if the log table is empty (older versions), copy sent/failed
	 * rows from the queue into the log so the History tab immediately has data.
	 *
	 * @param wpdb $wpdb WordPress DB instance.
	 */
	protected static function maybe_backfill_from_queue( $wpdb ) {
		$log_table   = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
		$queue_table = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

		// Only backfill when the log is empty.
		$log_count = (int) self::get_cached_value(
			'pmcpc_email_log_backfill_log_count',
			static function () use ( $wpdb, $log_table ) {
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom plugin tables require direct $wpdb queries.
				return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$log_table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- table name is plugin-controlled.
				// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
			}
		);
		if ( $log_count > 0 ) {
			return;
		}

		$queue_count = (int) self::get_cached_value(
			'pmcpc_email_log_backfill_queue_count',
			static function () use ( $wpdb, $queue_table ) {
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom plugin tables require direct $wpdb queries.
				return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$queue_table} WHERE status IN ('sent','failed')" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- table name is plugin-controlled.
				// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery
			}
		);
		if ( $queue_count < 1 ) {
			return;
		}

		// Copy sent/failed queue rows into the log. Use updated_at as sent_at when available.
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom plugin tables require direct $wpdb queries.
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- custom tables are plugin-controlled.
			"INSERT INTO {$log_table} (queue_id, subscriber_id, campaign_id, to_email, subject, body_html, status, last_error, sent_at, created_at)
			 SELECT q.id, q.subscriber_id, q.campaign_id, q.to_email, q.subject, q.body_html, q.status, q.last_error,
			        CASE WHEN q.status = 'sent' THEN q.updated_at ELSE NULL END,
			        q.created_at
			 FROM {$queue_table} q
			 WHERE q.status IN ('sent','failed')"
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		);
	}

	/**
	 * Load campaigns for the email-log filter dropdown.
	 *
	 * @param wpdb   $wpdb            WordPress DB instance.
	 * @param string $campaigns_table Campaign table name.
	 * @return array<int,object>
	 */
	protected static function get_campaign_options( $wpdb, $campaigns_table ) {
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Dynamic custom table name (plugin-controlled).
		return $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom plugin tables require direct $wpdb queries.
			"SELECT id, name FROM {$campaigns_table} ORDER BY created_at DESC LIMIT 500"
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Load paginated email-log rows for the current filter set.
	 *
	 * @param wpdb   $wpdb              WordPress DB instance.
	 * @param string $log_table         Log table name.
	 * @param string $status            Selected status filter.
	 * @param int    $campaign_id       Selected campaign ID.
	 * @param string $subscriber_search Subscriber email search term.
	 * @param string $like              Prepared LIKE pattern.
	 * @param int    $limit             Page size.
	 * @param int    $offset            Query offset.
	 * @return array<int,object>
	 */
	protected static function get_log_rows( $wpdb, $log_table, $status, $campaign_id, $subscriber_search, $like, $limit, $offset ) {
		$cache_key = self::get_cache_key( 'pmcpc_email_log_rows_', array( $status, $campaign_id, $subscriber_search, $limit, $offset ) );

		return self::get_cached_value(
			$cache_key,
			static function () use ( $wpdb, $log_table, $status, $campaign_id, $subscriber_search, $like, $limit, $offset ) {
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- dynamic table name is plugin-controlled.
				$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom plugin tables require direct $wpdb queries.
					$wpdb->prepare(
						"SELECT *
						FROM {$log_table}
						WHERE ( %s = '' OR status = %s )
							AND ( %d = 0 OR campaign_id = %d )
							AND ( %s = '' OR to_email LIKE %s )
						ORDER BY created_at DESC
						LIMIT %d OFFSET %d",
						$status,
						$status,
						$campaign_id,
						$campaign_id,
						$subscriber_search,
						$like,
						$limit,
						$offset
					)
				);
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

				return is_array( $rows ) ? $rows : array();
			}
		);
	}

	/**
	 * Load the total email-log row count for the current filter set.
	 *
	 * @param wpdb   $wpdb              WordPress DB instance.
	 * @param string $log_table         Log table name.
	 * @param string $status            Selected status filter.
	 * @param int    $campaign_id       Selected campaign ID.
	 * @param string $subscriber_search Subscriber email search term.
	 * @param string $like              Prepared LIKE pattern.
	 * @return int
	 */
	protected static function get_log_total( $wpdb, $log_table, $status, $campaign_id, $subscriber_search, $like ) {
		$cache_key = self::get_cache_key( 'pmcpc_email_log_total_', array( $status, $campaign_id, $subscriber_search ) );

		return (int) self::get_cached_value(
			$cache_key,
			static function () use ( $wpdb, $log_table, $status, $campaign_id, $subscriber_search, $like ) {
				// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- dynamic table name is plugin-controlled.
				$total = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom plugin tables require direct $wpdb queries.
					$wpdb->prepare(
						"SELECT COUNT(*)
						FROM {$log_table}
						WHERE ( %s = '' OR status = %s )
							AND ( %d = 0 OR campaign_id = %d )
							AND ( %s = '' OR to_email LIKE %s )",
						$status,
						$status,
						$campaign_id,
						$campaign_id,
						$subscriber_search,
						$like
					)
				);
				// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

				return $total;
			}
		);
	}

	/**
	 * Render the Email Log page.
	 *
	 * @param array $args Optional args:
	 *              - page_slug: admin page slug for form routing (default: pmcpc_email_log)
	 *              - tab: optional tab value to persist in GET forms
	 */
	public static function render_page( $args = array() ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$page_slug         = isset( $args['page_slug'] ) ? sanitize_key( (string) $args['page_slug'] ) : 'pmcpc_email_log';
		$tab               = isset( $args['tab'] ) ? sanitize_key( (string) $args['tab'] ) : '';
		$filters           = self::get_request_filters();
		$status            = $filters['status'];
		$campaign_id       = (int) $filters['campaign_id'];
		$subscriber_search = (string) $filters['subscriber_search'];
		$paged             = (int) $filters['paged'];
		$limit             = 200;
		$offset            = ( $paged - 1 ) * $limit;

		global $wpdb;

		// Backfill legacy installs where sent emails were stored only in the queue table.
		self::maybe_backfill_from_queue( $wpdb );

		$log_table       = esc_sql( $wpdb->prefix . 'pmcpc_email_log' );
		$campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
		$campaigns       = self::get_campaign_options( $wpdb, $campaigns_table );

		$like = '';
		if ( '' !== $subscriber_search ) {
			$like = '%' . $wpdb->esc_like( $subscriber_search ) . '%';
		}

		$rows        = self::get_log_rows( $wpdb, $log_table, $status, $campaign_id, $subscriber_search, $like, $limit, $offset );
		$total       = self::get_log_total( $wpdb, $log_table, $status, $campaign_id, $subscriber_search, $like );
		$total_pages = ( $total > 0 ) ? (int) ceil( $total / $limit ) : 1;
		$base_url    = self::get_pagination_base_url();
		$status_label = '' === $status ? __( 'All statuses', 'product-mailer-campaigns' ) : ucfirst( $status );

		echo '<div class="pmcpc-email-log">';
		echo '<style>
		.pmcpc-email-history-viewbar{display:flex;flex-wrap:wrap;gap:10px 14px;align-items:center;justify-content:space-between;margin:12px 0 0;padding:12px 14px;background:#fff;border:1px solid #dcdcde;border-radius:12px;}
		.pmcpc-email-history-viewbar__label{font-weight:600;color:#1d2327;}
		.pmcpc-email-history-viewbar__controls{display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center;}
		.pmcpc-email-history-viewbar__check{display:inline-flex;align-items:center;gap:6px;color:#3c434a;}
		.pmcpc-email-history-col-hidden{display:none !important;}
		.pmcpc-email-history-columns-reset{font-size:12px;}
		</style>';
		echo '<script>document.addEventListener("change",function(e){var box=e.target.closest(".pmcpc-email-history-column-toggle");if(!box){return;}var key=box.getAttribute("data-column");if(!key){return;}var hidden=[];try{hidden=JSON.parse(localStorage.getItem("pmcpc_email_history_hidden_columns")||"[]");}catch(err){hidden=[];}hidden=hidden.filter(function(x){return x!==key;});if(!box.checked){hidden.push(key);}localStorage.setItem("pmcpc_email_history_hidden_columns",JSON.stringify(hidden));document.querySelectorAll(".pmcpc-email-history-col-"+key).forEach(function(el){el.classList.toggle("pmcpc-email-history-col-hidden",!box.checked);});});document.addEventListener("click",function(e){var btn=e.target.closest(".pmcpc-email-history-columns-reset");if(!btn){return;}e.preventDefault();localStorage.removeItem("pmcpc_email_history_hidden_columns");document.querySelectorAll(".pmcpc-email-history-column-toggle").forEach(function(box){box.checked=true;});document.querySelectorAll("[class*=pmcpc-email-history-col-]").forEach(function(el){el.classList.remove("pmcpc-email-history-col-hidden");});});document.addEventListener("DOMContentLoaded",function(){var hidden=[];try{hidden=JSON.parse(localStorage.getItem("pmcpc_email_history_hidden_columns")||"[]");}catch(err){hidden=[];}hidden.forEach(function(key){document.querySelectorAll(".pmcpc-email-history-col-"+key).forEach(function(el){el.classList.add("pmcpc-email-history-col-hidden");});var box=document.querySelector(".pmcpc-email-history-column-toggle[data-column=\'"+key+"\']");if(box){box.checked=false;}});});</script>';
		PMCPC_Admin::render_stats_strip(
			array(
				array(
					'label' => __( 'Matching emails', 'product-mailer-campaigns' ),
					'value' => number_format_i18n( (int) $total ),
					'meta'  => __( 'Records in the current history view', 'product-mailer-campaigns' ),
				),
				array(
					'label' => __( 'Status filter', 'product-mailer-campaigns' ),
					'value' => $status_label,
					'meta'  => 0 !== $campaign_id ? __( 'Filtered to one campaign', 'product-mailer-campaigns' ) : __( 'Across all campaigns', 'product-mailer-campaigns' ),
				),
				array(
					'label' => __( 'Current page', 'product-mailer-campaigns' ),
					'value' => (string) max( 1, (int) $paged ),
					'meta'  => sprintf(
						/* translators: 1: current page number, 2: total page count */
						__( 'Page %1$s of %2$s', 'product-mailer-campaigns' ),
						number_format_i18n( (int) max( 1, $paged ) ),
						number_format_i18n( (int) max( 1, $total_pages ) )
					),
				),
			)
		);

		self::render_filter_form( $page_slug, $tab, $status, $campaign_id, $subscriber_search, $campaigns );

		if ( empty( $rows ) ) {
			echo '<div class="pmcpc-card"><p>' . esc_html__( 'No log entries match this filter.', 'product-mailer-campaigns' ) . '</p></div>';
		} else {
			self::render_results_table( $rows );
			self::render_pagination( $base_url, $paged, $total_pages );
		}

		echo '</div>';
	}
}
