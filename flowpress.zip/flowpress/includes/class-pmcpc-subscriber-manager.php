<?php
// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


require_once PMCPC_PLUGIN_DIR . 'includes/subscribers/class-pmcpc-subscribers-controller.php';
class PMCPC_Subscriber_Manager extends PMCPC_Subscribers_Controller {

	/**
	 * Compatibility wrapper used by the Messages screen.
	 *
	 * Some admin UI components check whether a specific blocked reason would be
	 * auto-deleted under current Spam Protection settings.
	 *
	 * @param string $reason  Block reason key.
	 * @param string $context Submission context (subscribe/contact/selling/etc).
	 * @return bool
	 */
	public static function should_auto_delete_blocked_attempt( $reason, $context = 'subscribe' ) {
		// Prefer the internal method if it exists.
		if ( method_exists( __CLASS__, 'should_auto_discard_spam_entry' ) ) {
			return (bool) self::should_auto_discard_spam_entry( $reason, $context );
		}
		return false;
	}

    /**
     * Create a short-lived double opt-in confirmation token for an email.
     *
     * We avoid using the raw email address in a nonce/action because some email
     * clients (notably on mobile) can normalize or decode parts of the URL,
     * causing nonce verification to fail. A random token stored server-side is
     * robust across clients.
     *
     * @param string $email Subscriber email.
     * @return string Token.
     */
    public static function create_double_optin_token( $email ) {
        $email = sanitize_email( (string) $email );
        if ( ! $email || ! is_email( $email ) ) {
            return '';
        }

        $email_key = 'pmcpc_confirm_email_' . md5( strtolower( $email ) );
        $old_token = get_transient( $email_key );
        if ( ! empty( $old_token ) && is_string( $old_token ) ) {
            delete_transient( 'pmcpc_confirm_token_' . $old_token );
        }

        // 32 hex chars.
        try {
            $token = bin2hex( random_bytes( 16 ) );
        } catch ( Exception $e ) {
            $token = wp_generate_password( 32, false, false );
        }

        /**
         * Filter the double opt-in confirmation token lifetime.
         *
         * @param int $ttl_seconds Lifetime in seconds. Default: 48 hours.
         */
        $ttl = (int) apply_filters( 'pmcpc_double_optin_token_ttl', 48 * HOUR_IN_SECONDS );
        if ( $ttl < HOUR_IN_SECONDS ) {
            $ttl = HOUR_IN_SECONDS;
        }

        // Map token -> email and email -> token (for invalidation on resend).
        set_transient( 'pmcpc_confirm_token_' . $token, $email, $ttl );
        set_transient( $email_key, $token, $ttl );

        return $token;
    }

    /**
     * Build a double opt-in confirmation URL for a subscriber email.
     *
     * @param string $email Subscriber email.
     * @return string Confirmation URL (raw, not HTML-escaped).
     */
    public static function build_double_optin_confirm_url( $email ) {
        $token = self::create_double_optin_token( $email );
        if ( empty( $token ) ) {
            return '';
        }
        $url = add_query_arg(
            array(
                'pmcpc_confirm' => 1,
                'pmcpc_token'   => $token,
            ),
            home_url( '/' )
        );
        return $url;
    }

    /**
     * Resolve a double opt-in confirmation token to an email (if valid).
     *
     * @param string $token Token from the confirmation URL.
     * @return string Email or empty string.
     */
    public static function resolve_double_optin_token( $token ) {
        $token = sanitize_text_field( (string) $token );
        if ( empty( $token ) ) {
            return '';
        }
        $email = get_transient( 'pmcpc_confirm_token_' . $token );
        $email = sanitize_email( (string) $email );
        if ( $email && is_email( $email ) ) {
            return $email;
        }
        return '';
    }
    /**
     * Get WooCommerce purchase stats for a billing email.
     *
     * Uses an in-request cache and a short-lived transient cache to keep the
     * Subscribers table performant.
     *
     * @param string $email Billing email.
     * @return array{order_count:int,total_spend:float,last_completed_ts:int}
     */
    public static function get_wc_purchase_stats_for_email( $email ) {
        $email = sanitize_email( $email );
        if ( ! $email || ! is_email( $email ) ) {
            return array(
                'order_count'       => 0,
                'total_spend'       => 0.0,
                'last_completed_ts' => 0,
            );
        }

        if ( isset( self::$wc_stats_cache[ $email ] ) ) {
            return self::$wc_stats_cache[ $email ];
        }

        // WooCommerce not active.
        if ( ! function_exists( 'wc_get_orders' ) ) {
            $stats = array(
                'order_count'       => 0,
                'total_spend'       => 0.0,
                'last_completed_ts' => 0,
            );
            self::$wc_stats_cache[ $email ] = $stats;
            return $stats;
        }

        $transient_key = 'pmcpc_wc_stats_' . md5( strtolower( $email ) );
        $cached        = get_transient( $transient_key );
        if ( is_array( $cached ) && isset( $cached['order_count'], $cached['total_spend'], $cached['last_completed_ts'] ) ) {
            $stats = array(
                'order_count'       => (int) $cached['order_count'],
                'total_spend'       => (float) $cached['total_spend'],
                'last_completed_ts' => (int) $cached['last_completed_ts'],
            );
            self::$wc_stats_cache[ $email ] = $stats;
            return $stats;
        }

        // Fetch all completed orders for this billing email.
        $orders = wc_get_orders(
            array(
                'status'        => array( 'completed' ),
                'limit'         => -1,
                'billing_email' => $email,
                'return'        => 'ids',
            )
        );

        if ( ! is_array( $orders ) ) {
            $orders = array();
        }

        $order_count       = count( $orders );
        $total_spend       = 0.0;
        $last_completed_ts = 0;

        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) {
                continue;
            }
            $total_spend += (float) $order->get_total();

            $completed = $order->get_date_completed();
            if ( $completed ) {
                $ts = (int) $completed->getTimestamp();
                if ( $ts > $last_completed_ts ) {
                    $last_completed_ts = $ts;
                }
            }
        }

        $stats = array(
            'order_count'       => (int) $order_count,
            'total_spend'       => (float) $total_spend,
            'last_completed_ts' => (int) $last_completed_ts,
        );

        // Cache for 1 hour.
        set_transient( $transient_key, $stats, HOUR_IN_SECONDS );
        self::$wc_stats_cache[ $email ] = $stats;
        return $stats;
    }
	/**
	 * Internal guard to prevent duplicate submission-row inserts when
	 * record_spam_submission() calls record_spam_block().
	 *
	 * @var bool
	 */
	protected static $pmcpc_in_record_submission = false;

	/**
	 * Default spam protection settings.
	 *
	 * @return array
	 */
	public static function get_default_spam_settings() {
		return array(
			'spam_protection_enabled' => 'yes',
			// Spam handling mode (Inbox noise control).
			'spam_handling_mode'    => 'review_all',
			'spam_honeypot_enabled'   => 'yes',
			// Signed timing token + minimum submit time (contact/selling forms).
			'spam_form_timing_enabled' => 'yes',
			'spam_min_submit_seconds'  => 4,
			'spam_rate_limit_enabled' => 'yes',
			'spam_rate_limit_max'     => 5,
			'spam_rate_limit_window'  => 600, // seconds.
			'spam_suspicious_tlds_enabled' => 'yes',
			'spam_suspicious_tlds'    => "ru\nxyz\ntop\nclub\nsite\nclick\nlink\nfit\nrest\nmonster\nwork\nbiz",
			// Auto-add domains to the blocked domains list after repeated blocked attempts.
			'spam_auto_block_domains_enabled'  => 'yes',
			'spam_auto_block_domains_threshold' => 3,
			'spam_auto_block_domains_window'    => 86400, // seconds.
			'spam_name_policy'        => 'blank', // blank|block
			'spam_log_enabled'         => 'yes',

			// Email sanity checks.
			// When enabled we treat domains with no MX or A records as blocked.
			'spam_email_dns_enabled'   => 'yes',

			// Message/content scoring (primarily for contact/selling forms).
			'spam_message_scoring_enabled' => 'yes',
			'spam_message_max_links'        => 1,
			'spam_message_keywords_enabled' => 'yes',
			'spam_message_keywords'         => "seo\nbacklink\nbacklinks\nlink building\nguest post\nwrite for us\n\ncasino\npoker\nbetting\nloan\ncrypto\ntelegram\nwhatsapp\n\nказино\nонлайн казино\nслоты\nбукмекер\nставки\n\nxrumer\nxrum\n\n\"best service\"\n\"promote your site\"\n\"website promotion\"",
			'spam_message_non_ascii_threshold' => 0.30,
			'spam_message_suspicious_markup_enabled' => 'yes',
			// Scores: >= hold => held, >= block => blocked.
			'spam_message_hold_score'  => 3,
			'spam_message_block_score' => 6,
		);
	}

	/**
	 * Whether a domain is already in the user-configured blocked domains list.
	 */
	public static function is_domain_in_blocked_list( $domain ) {
		$domain = strtolower( trim( (string) $domain ) );
		if ( '' === $domain ) {
			return false;
		}
		foreach ( PMCPC_Settings::get_multiline_list( 'blocked_email_domains' ) as $line ) {
			$line = strtolower( trim( (string) $line ) );
			if ( $line && $line === $domain ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Append a domain to the blocked domains setting (one domain per line).
	 */
	public static function add_domain_to_blocked_list( $domain ) {
		$domain = strtolower( trim( (string) $domain ) );
			// Safety: never allow adding protected/shared provider domains to the manual blocked list.
			if ( method_exists( __CLASS__, "is_auto_block_protected_domain" ) && self::is_auto_block_protected_domain( $domain ) ) {
				return false;
			}

		if ( '' === $domain || self::is_domain_in_blocked_list( $domain ) ) {
			return false;
		}
		$current   = PMCPC_Settings::get_multiline_list( 'blocked_email_domains' );
		$current[] = $domain;
		PMCPC_Settings::update_multiline_list( 'blocked_email_domains', $current );
		return true;
	}

	/**
	 * Get a spam setting (merged with defaults).
	 */
	public static function get_spam_setting( $key, $fallback = '' ) {
		$defaults = self::get_default_spam_settings();
		$default  = array_key_exists( $key, $defaults ) ? $defaults[ $key ] : $fallback;
		return PMCPC_Settings::get( $key, $default );
	}

	/**
	 * Read a newline-delimited email option as a normalized unique list.
	 *
	 * @param string $option_name Option name.
	 * @return string[]
	 */
	protected static function get_email_list_option( $option_name ) {
		$list = get_option( $option_name, '' );
		if ( ! is_string( $list ) || '' === trim( $list ) ) {
			return array();
		}

		$lines = preg_split( '/\r\n|\r|\n/', $list );
		if ( ! is_array( $lines ) ) {
			return array();
		}

		$out = array();
		foreach ( $lines as $line ) {
			$email = sanitize_email( trim( (string) $line ) );
			if ( $email ) {
				$out[] = strtolower( $email );
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Persist a normalized unique email list option.
	 *
	 * @param string   $option_name Option name.
	 * @param string[] $emails      Email list.
	 * @return void
	 */
	protected static function update_email_list_option( $option_name, $emails ) {
		if ( ! is_array( $emails ) ) {
			$emails = array();
		}

		$normalized = array();
		foreach ( $emails as $email ) {
			$email = sanitize_email( (string) $email );
			if ( $email ) {
				$normalized[] = strtolower( $email );
			}
		}

		update_option( $option_name, implode( "\n", array_values( array_unique( $normalized ) ) ), false );
	}

	/**
	 * Get the protected domains that should never be auto-blocked.
	 *
	 * @return string[]
	 */
	protected static function get_auto_block_protected_domains_setting() {
		$protected_domains = array(
			'gmail.com',
			'googlemail.com',
			'yahoo.com',
			'hotmail.com',
			'outlook.com',
			'live.com',
			'icloud.com',
			'gmx.com',
		);

		foreach ( PMCPC_Settings::get_multiline_list( 'spam_auto_block_protected_domains' ) as $line ) {
			$domain = self::normalize_domain_value( $line );
			if ( '' === $domain ) {
				continue;
			}
			if ( ! preg_match( '/^[a-z0-9][a-z0-9\-\.]*\.[a-z0-9\-\.]+$/', $domain ) ) {
				continue;
			}
			$protected_domains[] = $domain;
		}

		return array_values( array_unique( array_filter( $protected_domains ) ) );
	}

	/**
	 * Normalize a domain-like string for comparisons/storage.
	 *
	 * @param string $domain Raw domain.
	 * @return string
	 */
	protected static function normalize_domain_value( $domain ) {
		$domain = strtolower( trim( (string) $domain ) );
		$domain = ltrim( $domain, "@ \t" );

		return $domain;
	}

	/**
	 * Extract the normalized domain from an email address.
	 *
	 * @param string $email Email address.
	 * @return string
	 */
	protected static function get_domain_from_email( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email || strpos( $email, '@' ) === false ) {
			return '';
		}

		$parts = explode( '@', $email );

		return self::normalize_domain_value( end( $parts ) );
	}

	/**
	 * Get the current request IP in a normalized, sanitized form.
	 *
	 * @return string
	 */
	protected static function get_request_ip() {
		if ( empty( $_SERVER['REMOTE_ADDR'] ) ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.
		return sanitize_text_field( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
	}

	/**
	 * Get the privacy-preserving hash of the current request IP.
	 *
	 * @return string|null
	 */
	protected static function get_request_ip_hash() {
		$ip = self::get_request_ip();

		return $ip ? hash( 'sha256', $ip ) : null;
	}

	/**
	 * Read the spam stats option as a normalized array.
	 *
	 * @return array
	 */
	protected static function get_spam_stats() {
		$stats = get_option( 'pmcpc_spam_stats', array() );

		return is_array( $stats ) ? $stats : array();
	}

	/**
	 * Persist the spam stats option.
	 *
	 * @param array $stats Stats payload.
	 * @return void
	 */
	protected static function update_spam_stats( $stats ) {
		update_option( 'pmcpc_spam_stats', is_array( $stats ) ? $stats : array(), false );
	}

	/**
	 * Increment a spam-stats reason bucket.
	 *
	 * @param string $reason Reason key.
	 * @return void
	 */
	protected static function increment_spam_stats_reason( $reason ) {
		$reason = sanitize_key( (string) $reason );
		if ( '' === $reason ) {
			return;
		}

		$stats = self::get_spam_stats();
		if ( ! isset( $stats['reasons'] ) || ! is_array( $stats['reasons'] ) ) {
			$stats['reasons'] = array();
		}

		$stats['reasons'][ $reason ] = isset( $stats['reasons'][ $reason ] ) ? (int) $stats['reasons'][ $reason ] + 1 : 1;
		self::update_spam_stats( $stats );
	}

	/**
	 * Build a short hashed transient key for spam/rate-limit counters.
	 *
	 * @param string $prefix Key prefix.
	 * @param string $value  Raw value to hash.
	 * @return string
	 */
	protected static function get_hashed_transient_key( $prefix, $value ) {
		return sanitize_key( (string) $prefix ) . substr( hash( 'sha256', (string) $value ), 0, 20 );
	}

	/**
	 * Increment a transient-backed counter and return the new value.
	 *
	 * @param string $key Transient key.
	 * @param int    $ttl Time to live in seconds.
	 * @return int
	 */
	protected static function increment_transient_counter( $key, $ttl ) {
		$key   = (string) $key;
		$ttl   = max( 1, (int) $ttl );
		$count = (int) get_transient( $key );
		$count++;
		set_transient( $key, $count, $ttl );

		return $count;
	}


	/**
	 * Whether a blocked submission should be auto-discarded (kept out of the Inbox).
	 *
	 * This keeps aggregate spam counts via pmcpc_spam_stats, but avoids cluttering
	 * the review UI with high-confidence bot noise.
	 *
	 * @param string $reason  Reason key.
	 * @param string $context Context key.
	 * @return bool
	 */
	protected static function should_auto_discard_spam_entry( $reason, $context = 'subscribe' ) {
		$mode = self::get_spam_setting( 'spam_handling_mode', 'review_all' );
		if ( 'auto_delete_obvious' !== $mode ) {
			return false;
		}
		$reason  = sanitize_key( (string) $reason );
		$context = sanitize_key( (string) $context );

		// Conservative defaults: only discard high-confidence automated spam signals.
		$high_confidence = array(
			'honeypot',
			'blocked_domain',
			'blocked_email',
			'suspicious_tld',
		);

		if ( in_array( $reason, $high_confidence, true ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Check whether a domain is in the "never auto-block" protected list.
	 *
	 * This is used for safety in admin actions (e.g. disabling "Ban domain" for
	 * shared providers / protected domains).
	 *
	 * @param string $domain Domain to check.
	 * @return bool
	 */
	public static function is_auto_block_protected_domain( $domain ) {
		$domain = self::normalize_domain_value( $domain );
		if ( '' === $domain ) {
			return false;
		}

		$protected_domains = self::get_auto_block_protected_domains_setting();
		$protected_domains = apply_filters( 'pmcpc_auto_block_protected_domains', $protected_domains, $domain, '', '' );

		foreach ( (array) $protected_domains as $protected ) {
			$protected = strtolower( trim( (string) $protected ) );
			if ( '' === $protected ) {
				continue;
			}
			$pattern = '/(^|\.)' . preg_quote( $protected, '/' ) . '$/';
			if ( preg_match( $pattern, $domain ) ) {
				return true;
			}
		}

		return false;
	}


	/**
	 * Get additional blocked email addresses (one per line).
	 *
	 * @return string[]
	 */
	public static function get_additional_blocked_emails() {
		return self::get_email_list_option( 'pmcpc_additional_blocked_emails' );
	}

	/**
	 * Add an email address to the additional blocked emails list.
	 *
	 * @param string $email Email address.
	 * @return void
	 */
	public static function add_blocked_email( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email ) {
			return;
		}
		$current = self::get_additional_blocked_emails();
		$current[] = strtolower( $email );
		self::update_email_list_option( 'pmcpc_additional_blocked_emails', $current );
	}

	/**
	 * Get allowlisted email addresses (one per line).
	 *
	 * @return string[]
	 */
	public static function get_allowlisted_emails() {
		return self::get_email_list_option( 'pmcpc_allowlisted_emails' );
	}

	/**
	 * Add an email address to the allowlist.
	 *
	 * @param string $email Email address.
	 * @return void
	 */
	public static function add_allowlisted_email( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email ) {
			return;
		}
		$current   = self::get_allowlisted_emails();
		$current[] = strtolower( $email );
		self::update_email_list_option( 'pmcpc_allowlisted_emails', $current );
	}

	/**
	 * Check if an email address is allowlisted.
	 *
	 * @param string $email Email address.
	 * @return bool
	 */
	public static function is_allowlisted_email_address( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email ) {
			return false;
		}
		$allowed = self::get_allowlisted_emails();
		return in_array( strtolower( $email ), $allowed, true );
	}

	/**
	 * Get allowlisted email domains (one per line, no @).
	 *
	 * @return string[]
	 */
	public static function get_allowlisted_email_domains() {
		$out   = array();
		foreach ( PMCPC_Settings::get_multiline_list( 'allowlisted_email_domains' ) as $line ) {
			$domain = self::normalize_domain_value( $line );
			if ( $domain ) {
				$out[] = $domain;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Add an email domain to the allowlist.
	 *
	 * @param string $domain Domain (no @).
	 * @return void
	 */
	public static function add_allowlisted_email_domain( $domain ) {
		$domain = self::normalize_domain_value( $domain );
		if ( '' === $domain ) {
			return;
		}
		$current   = self::get_allowlisted_email_domains();
		$current[] = $domain;
		PMCPC_Settings::update_multiline_list( 'allowlisted_email_domains', $current );
	}

	/**
	 * Check if a sender (email or domain) is allowlisted.
	 *
	 * Note: This bypasses email/domain/message scoring blocks, but does not bypass
	 * form integrity checks like honeypots or timing tokens.
	 *
	 * @param string $email Email address.
	 * @return bool
	 */
	public static function is_allowlisted_sender( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email || strpos( $email, '@' ) === false ) {
			return false;
		}
		if ( self::is_allowlisted_email_address( $email ) ) {
			return true;
		}
		$domain = self::get_domain_from_email( $email );
		if ( '' === $domain ) {
			return false;
		}
		foreach ( self::get_allowlisted_email_domains() as $allowed_domain ) {
			if ( '' === $allowed_domain ) {
				continue;
			}
			$pattern = '/(^|\.)' . preg_quote( $allowed_domain, '/' ) . '$/';
			if ( preg_match( $pattern, $domain ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check if a specific email address is blocked.
	 *
	 * @param string $email Email address.
	 * @return bool
	 */
	public static function is_blocked_email_address( $email ) {
		$email = sanitize_email( (string) $email );
		if ( ! $email ) {
			return false;
		}
		$blocked = self::get_additional_blocked_emails();
		return in_array( strtolower( $email ), $blocked, true );
	}

	/**
	 * Detect quick repeat duplicate submissions.
	 *
	 * Used to prevent double-clicks and rapid re-submits from emailing admins multiple times.
	 * This check is intentionally conservative: it only flags submissions as duplicates when
	 * the same email+context and identical (subject+message) have been recorded within the
	 * configured window.
	 *
	 * @param string $email          Sender email.
	 * @param string $context        Context key (contact|selling|subscribe|...).
	 * @param string $subject        Subject.
	 * @param string $message        Message.
	 * @param int    $window_seconds Lookback window in seconds.
	 * @return bool
	 */
	public static function is_duplicate_submission_recent( $email, $context, $subject, $message, $window_seconds ) {
		$email   = sanitize_email( (string) $email );
		$context = sanitize_key( (string) $context );
		$window_seconds = absint( $window_seconds );
		if ( empty( $email ) || empty( $context ) || $window_seconds < 1 ) {
			return false;
		}

		$subject = (string) $subject;
		$message = (string) $message;
		$fingerprint = hash( 'sha256', strtolower( trim( $email ) ) . '|' . $context . '|' . trim( $subject ) . '|' . trim( $message ) );

		global $wpdb;
		// Table names are plugin-controlled (not user input). esc_sql() is used to satisfy static analyzers.
		$table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );

		$cache_key = 'pmcpc_dup_recent_' . md5( $email . '|' . $context . '|' . (string) $window_seconds );
		$rows      = wp_cache_get( $cache_key, 'pmcpc' );
		if ( false === $rows ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT subject, message FROM {$table}
					 WHERE email = %s AND context = %s
					   AND created_at >= ( NOW() - INTERVAL %d SECOND )
					 ORDER BY id DESC
					 LIMIT 10",
					$email,
					$context,
					$window_seconds
				)
			);
			// Cache briefly; this is only used as a short-term duplicate submission guard.
			wp_cache_set( $cache_key, $rows, 'pmcpc', 60 );
		}

		if ( empty( $rows ) ) {
			return false;
		}

		foreach ( $rows as $r ) {
			$fp2 = hash( 'sha256', strtolower( trim( $email ) ) . '|' . $context . '|' . trim( (string) $r->subject ) . '|' . trim( (string) $r->message ) );
			if ( hash_equals( $fingerprint, $fp2 ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Record a held/blocked spam submission with message content for admin review.
	 *
	 * @param string $email   Email address.
	 * @param string $reason  Reason key.
	 * @param string $context Context key.
	 * @param string $subject Subject line.
	 * @param string $message Message body.
	 * @param string $status  held|blocked
	 * @return void
	 */
	public static function record_spam_submission( $email, $reason, $context, $subject, $message, $status = 'held', $campaign_id = 0, $spam_score = null, $score_details = array() ) {
		$email   = sanitize_email( (string) $email );
		$reason  = sanitize_key( (string) $reason );
		$context = sanitize_key( (string) $context );
		$status  = sanitize_key( (string) $status );
		$campaign_id = absint( $campaign_id );
		$subject = sanitize_text_field( (string) $subject );
		$message = wp_kses_post( (string) $message );

		

		// Optional numeric spam score + details (used by message/content scoring).
		$spam_score = ( null === $spam_score ) ? null : (float) $spam_score;
		if ( ! is_array( $score_details ) ) {
			$score_details = array();
		}
		$score_details_json = ! empty( $score_details ) ? wp_json_encode( array_values( $score_details ) ) : null;
		// Spam handling mode: optionally auto-discard high-confidence spam to keep Inbox clean.
		if ( 'blocked' === $status && self::should_auto_discard_spam_entry( $reason, $context ) ) {
			$status = 'discarded';
		}
// Keep existing counters + domain tracking.
		self::$pmcpc_in_record_submission = true;
		self::record_spam_block( $email, $reason, $context );
		self::$pmcpc_in_record_submission = false;

		// Always store reviewable spam submissions.
		// The legacy "spam_log_enabled" setting controlled the old aggregated
		// stats log only; the new review table must remain populated so admins can
		// release or ban senders.

		$domain = self::get_domain_from_email( $email );

		global $wpdb;
		// Table names are plugin-controlled (not user input). esc_sql() is used to satisfy static analyzers.
		$table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );

		$ip_hash = self::get_request_ip_hash();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			$table,
			array(
				'email'      => $email ? $email : null,
				'domain'     => $domain ? $domain : null,
				'ip_hash'    => $ip_hash,
				'reason'     => $reason,
				'context'    => $context,
				'campaign_id'=> $campaign_id ? $campaign_id : null,
				'status'     => ( $status && in_array( $status, array( 'held', 'blocked', 'discarded' ), true ) ) ? $status : 'held',
				'subject'    => $subject ? $subject : null,
				'message'    => $message ? $message : null,
				'spam_score' => ( null === $spam_score ) ? null : $spam_score,
				'score_details' => $score_details_json,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%f', '%s', '%s' )
		);
	}

	/**
	 * Record a non-spam submission so it can be reviewed later in the Inbox.
	 *
	 * We intentionally store these in the same table as held/blocked spam so the
	 * admin UI can provide a unified Inbox view.
	 *
	 * @param string $email   Email address.
	 * @param string $context Context key (contact|selling|subscribe|checkout|etc).
	 * @param string $subject Subject line.
	 * @param string $message Message body.
	 * @param string $reason  Optional reason label (e.g. submitted).
	 * @return void
	 */
	public static function record_inbox_submission( $email, $context, $subject, $message, $reason = 'submitted', $campaign_id = 0, $spam_score = null, $score_details = array() ) {
		$email   = sanitize_email( (string) $email );
		$reason  = sanitize_key( (string) $reason );
		$context = sanitize_key( (string) $context );
		$campaign_id = absint( $campaign_id );
		$subject = sanitize_text_field( (string) $subject );
		$message = wp_kses_post( (string) $message );

		// Optional numeric spam score + details (used by message/content scoring).
		$spam_score = ( null === $spam_score ) ? null : (float) $spam_score;
		if ( ! is_array( $score_details ) ) {
			$score_details = array();
		}
		$score_details_json = ! empty( $score_details ) ? wp_json_encode( array_values( $score_details ) ) : null;


		$domain = self::get_domain_from_email( $email );

		$ip_hash = self::get_request_ip_hash();

		global $wpdb;
		// Table names are plugin-controlled (not user input). esc_sql() is used to satisfy static analyzers.
		$table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			$table,
			array(
				'email'      => $email ? $email : null,
				'domain'     => $domain ? $domain : null,
				'ip_hash'    => $ip_hash,
				'reason'     => $reason ? $reason : 'submitted',
				'context'    => $context ? $context : 'contact',
				'campaign_id'=> $campaign_id ? $campaign_id : null,
				'status'     => 'allowed',
				'subject'    => $subject ? $subject : null,
				'message'    => $message ? $message : null,
				'spam_score' => ( null === $spam_score ) ? null : $spam_score,
				'score_details' => $score_details_json,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%f', '%s', '%s' )
		);
	}

	/**
	 * Cleanup Inbox / spam submissions based on retention settings.
	 *
	 * Runs daily via WP-Cron (pmcpc_inbox_cleanup).
	 *
	 * Retention is split into two buckets:
	 * - Inbox (allowed + held)
	 * - Spam (blocked + discarded)
	 *
	 * @return void
	 */
	public static function cleanup_inbox_submissions() {
		global $wpdb;
		// Table names are plugin-controlled (not user input). esc_sql() is used to satisfy static analyzers.
		$table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );

		// Bail if table doesn't exist.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $exists !== $table ) {
			return;
		}

		$allowed_values = array( 0, 30, 90, 180 );

		$inbox_days = absint( PMCPC_Settings::get( 'inbox_retention_days', 90 ) );
		$spam_days  = absint( PMCPC_Settings::get( 'spam_retention_days', 180 ) );
		if ( ! in_array( $inbox_days, $allowed_values, true ) ) {
			$inbox_days = 90;
		}
		if ( ! in_array( $spam_days, $allowed_values, true ) ) {
			$spam_days = 180;
		}

		// Build cutoffs.
		$now_ts = current_time( 'timestamp' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		if ( $inbox_days > 0 ) {
			$cutoff = gmdate( 'Y-m-d H:i:s', (int) $now_ts - ( $inbox_days * DAY_IN_SECONDS ) );
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$table} WHERE created_at < %s AND status IN ('allowed','held')",
					$cutoff
				)
			);
		}

		if ( $spam_days > 0 ) {
			$cutoff = gmdate( 'Y-m-d H:i:s', (int) $now_ts - ( $spam_days * DAY_IN_SECONDS ) );
			$wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$table} WHERE created_at < %s AND status IN ('blocked','discarded')",
					$cutoff
				)
			);
		}
		// Keep DB query sniffs disabled for the remainder of the file (plugin uses custom tables heavily).
	}



	/**
	 * Record a blocked/filtered signup for visibility + reporting.
	 */
	public static function record_spam_block( $email, $reason, $context = 'subscribe' ) {
		$email  = sanitize_email( (string) $email );
		$reason = sanitize_key( (string) $reason );
		$context = sanitize_key( (string) $context );
		$domain = self::get_domain_from_email( $email );

		// Update aggregated stats.
		$stats = self::get_spam_stats();
		$stats['total'] = isset( $stats['total'] ) ? (int) $stats['total'] + 1 : 1;
		$today_key = gmdate( 'Ymd' );
		if ( ! isset( $stats['daily'] ) || ! is_array( $stats['daily'] ) ) {
			$stats['daily'] = array();
		}
		$stats['daily'][ $today_key ] = isset( $stats['daily'][ $today_key ] ) ? (int) $stats['daily'][ $today_key ] + 1 : 1;
		if ( ! isset( $stats['reasons'] ) || ! is_array( $stats['reasons'] ) ) {
			$stats['reasons'] = array();
		}
		$stats['reasons'][ $reason ] = isset( $stats['reasons'][ $reason ] ) ? (int) $stats['reasons'][ $reason ] + 1 : 1;

		// Track domains for reporting.
		if ( $domain ) {
			if ( ! isset( $stats['domains'] ) || ! is_array( $stats['domains'] ) ) {
				$stats['domains'] = array();
			}
			$stats['domains'][ $domain ] = isset( $stats['domains'][ $domain ] ) ? (int) $stats['domains'][ $domain ] + 1 : 1;
		}
		self::update_spam_stats( $stats );

		// Ensure spam blocks are visible in the admin review UI.
		// If record_spam_submission() was used, it already inserted a row.
		if ( ! self::$pmcpc_in_record_submission ) {
			global $wpdb;
			// Table names are plugin-controlled (not user input). esc_sql() is used to satisfy static analyzers.
			$table = esc_sql( $wpdb->prefix . 'pmcpc_spam_submissions' );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
			if ( $exists === $table ) {
				$ip_hash = self::get_request_ip_hash();

				$store_status = self::should_auto_discard_spam_entry( $reason, $context ) ? 'discarded' : 'blocked';
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$wpdb->insert(
					$table,
					array(
						'email'      => $email ? $email : null,
						'domain'     => $domain ? $domain : null,
						'ip_hash'    => $ip_hash,
						'reason'     => $reason,
						'context'    => $context,
						'status'     => $store_status,
						'subject'    => null,
						'message'    => null,
						'created_at' => current_time( 'mysql' ),
					),
					array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
				);
			}
		}

		// Optionally auto-add repeat offender domains to the blocked domains list.
		if ( $domain && 'yes' === self::get_spam_setting( 'spam_auto_block_domains_enabled', 'yes' ) && ! self::is_domain_in_blocked_list( $domain ) ) {
			$protected_domains = self::get_auto_block_protected_domains_setting();

			/**
			 * Domains that should never be auto-blocked.
			 *
			 * Site owners can add/remove domains via a filter.
			 *
			 * @param array  $protected_domains Default protected domains.
			 * @param string $domain            Domain being evaluated.
			 * @param string $reason            Spam reason.
			 * @param string $context           Context of the submission.
			 */
			$protected_domains = apply_filters( 'pmcpc_auto_block_protected_domains', $protected_domains, $domain, $reason, $context );

			$skip_auto_block = false;
			foreach ( (array) $protected_domains as $protected ) {
				$protected = strtolower( trim( (string) $protected ) );
				if ( '' === $protected ) {
					continue;
				}
				$pattern = '/(^|\.)' . preg_quote( $protected, '/' ) . '$/';
				if ( preg_match( $pattern, $domain ) ) {
					$skip_auto_block = true;
					break;
				}
			}

			/**
			 * Allow overriding whether a domain should be auto-blocked.
			 *
			 * Return true to skip auto-blocking for the given domain.
			 *
			 * @param bool   $skip_auto_block Whether to skip auto-blocking.
			 * @param string $domain          Domain being evaluated.
			 * @param string $reason          Spam reason.
			 * @param string $context         Context of the submission.
			 */
			$skip_auto_block = (bool) apply_filters( 'pmcpc_skip_auto_block_domain', $skip_auto_block, $domain, $reason, $context );

			if ( $skip_auto_block ) {
				self::increment_spam_stats_reason( 'auto_domain_skipped' );

				// Set a short-lived admin notice flag.
				set_transient( 'pmcpc_notice_auto_block_skipped', $domain, HOUR_IN_SECONDS );
				do_action( 'pmcpc_auto_block_domain_skipped', $domain, $reason, $context );
			} else {
				$threshold = (int) self::get_spam_setting( 'spam_auto_block_domains_threshold', 3 );
				$window    = (int) self::get_spam_setting( 'spam_auto_block_domains_window', 86400 );
				if ( $threshold < 2 ) {
					$threshold = 2;
				}
				if ( $window < 300 ) {
					$window = 300;
				}
				$k = self::get_hashed_transient_key( 'pmcpc_abd_', $domain );
				$c = self::increment_transient_counter( $k, $window );
				if ( $c >= $threshold ) {
					$added = self::add_domain_to_blocked_list( $domain );
					if ( $added ) {
						self::increment_spam_stats_reason( 'auto_domain_blocked' );
					}
				}
			}
		}

		// Optional lightweight log.
		if ( 'yes' !== self::get_spam_setting( 'spam_log_enabled', 'yes' ) ) {
			return;
		}

		global $wpdb;
		$table = esc_sql( $wpdb->prefix . 'pmcpc_block_log' );
		$ip_hash = self::get_request_ip_hash();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			$table,
			array(
				'email'      => $email ? $email : null,
				'domain'     => $domain ? $domain : null,
				'ip_hash'    => $ip_hash,
				'reason'     => $reason,
				'context'    => $context,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Basic name cleanup.
	 */
	public static function clean_name( $value ) {
		$value = wp_strip_all_tags( (string) $value );
		$value = preg_replace( "/[^\\p{L}\\p{M} '\\-]/u", '', $value );
		$value = trim( preg_replace( '/\s+/', ' ', (string) $value ) );
		return (string) $value;
	}

	public static function is_spammy_name( $first_name, $last_name ) {
		$first = mb_strtolower( (string) $first_name );
		$last  = mb_strtolower( (string) $last_name );
		if ( $first && $last && $first === $last ) {
			return true;
		}
		$haystack = $first . ' ' . $last;
		if ( preg_match( '/(http|www\\.|\\.ru|\\.xyz|\\.top|@)/i', $haystack ) ) {
			return true;
		}
		if ( mb_strlen( (string) $first_name ) > 40 || mb_strlen( (string) $last_name ) > 40 ) {
			return true;
		}
		return false;
	}

	/**
	 * Rate limit by IP to reduce bot floods.
	 */
	public static function is_rate_limited() {
		if ( 'yes' !== self::get_spam_setting( 'spam_rate_limit_enabled', 'yes' ) ) {
			return false;
		}
		$ip = self::get_request_ip();
		if ( ! $ip ) {
			return false;
		}
		$key = self::get_hashed_transient_key( 'pmcpc_rl_', $ip );
		$window = (int) self::get_spam_setting( 'spam_rate_limit_window', 600 );
		$max    = (int) self::get_spam_setting( 'spam_rate_limit_max', 5 );
		$count  = self::increment_transient_counter( $key, max( 60, $window ) );
		return ( $count > $max );
	}

	/**
	 * Check whether the current IP would be rate limited WITHOUT incrementing the counter.
	 *
	 * Useful for admin testing tools.
	 *
	 * @return bool
	 */
	public static function peek_rate_limited() {
		if ( 'yes' !== self::get_spam_setting( 'spam_rate_limit_enabled', 'yes' ) ) {
			return false;
		}
		$ip = self::get_request_ip();
		if ( ! $ip ) {
			return false;
		}
		$key    = self::get_hashed_transient_key( 'pmcpc_rl_', $ip );
		$max    = (int) self::get_spam_setting( 'spam_rate_limit_max', 5 );
		$count  = (int) get_transient( $key );
		return ( $count >= $max );
	}
}
