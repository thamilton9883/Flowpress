<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * User-facing profile fields for FlowPress.
 *
 * Adds birthday editing in:
 * - WordPress user profile screens
 * - WooCommerce My Account > Account details
 */
class PMCPC_Profile_Fields {

    /**
     * Register profile hooks.
     *
     * @return void
     */
    public static function init() {
        add_action( 'show_user_profile', array( __CLASS__, 'render_wp_profile_birthday_field' ) );
        add_action( 'edit_user_profile', array( __CLASS__, 'render_wp_profile_birthday_field' ) );
        add_action( 'personal_options_update', array( __CLASS__, 'save_wp_profile_birthday_field' ) );
        add_action( 'edit_user_profile_update', array( __CLASS__, 'save_wp_profile_birthday_field' ) );

        if ( class_exists( 'WooCommerce' ) ) {
            add_action( 'woocommerce_edit_account_form', array( __CLASS__, 'render_wc_account_birthday_field' ) );
            add_action( 'woocommerce_save_account_details', array( __CLASS__, 'save_wc_account_birthday_field' ) );
        }
    }

    /**
     * Render birthday field on WordPress profile pages.
     *
     * @param WP_User $user User object.
     * @return void
     */
    public static function render_wp_profile_birthday_field( $user ) {
        if ( ! $user instanceof WP_User ) {
            return;
        }

        $birthday = self::get_user_birthday( (int) $user->ID );
        ?>
        <h2><?php esc_html_e( 'FlowPress', 'product-mailer-campaigns' ); ?></h2>
        <table class="form-table" role="presentation">
            <tr>
                <th><label for="pmcpc_birthday"><?php esc_html_e( 'Birthday', 'product-mailer-campaigns' ); ?></label></th>
                <td>
                    <input
                        type="date"
                        name="pmcpc_birthday"
                        id="pmcpc_birthday"
                        value="<?php echo esc_attr( $birthday ); ?>"
                        class="regular-text"
                    />
                    <p class="description"><?php esc_html_e( 'Used for birthday email automations and subscriber segmentation.', 'product-mailer-campaigns' ); ?></p>
                    <?php $pmcpc_prefs_url = self::get_preferences_page_url(); ?>
                    <?php if ( $pmcpc_prefs_url ) : ?>
                        <p class="description">
                            <a href="<?php echo esc_url( $pmcpc_prefs_url ); ?>"><?php esc_html_e( 'Manage email preferences on the front end', 'product-mailer-campaigns' ); ?></a>
                        </p>
                    <?php endif; ?>
                    <?php wp_nonce_field( 'pmcpc_save_profile_birthday', 'pmcpc_profile_birthday_nonce' ); ?>
                </td>
            </tr>
        </table>
        <?php
    }

    /**
     * Save birthday field from WordPress profile pages.
     *
     * @param int $user_id User ID.
     * @return void
     */
    public static function save_wp_profile_birthday_field( $user_id ) {
        $user_id = absint( $user_id );
        if ( ! $user_id || ! current_user_can( 'edit_user', $user_id ) ) {
            return;
        }

        $nonce = isset( $_POST['pmcpc_profile_birthday_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['pmcpc_profile_birthday_nonce'] ) ) : '';
        if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'pmcpc_save_profile_birthday' ) ) {
            return;
        }

        $birthday = isset( $_POST['pmcpc_birthday'] ) ? sanitize_text_field( wp_unslash( $_POST['pmcpc_birthday'] ) ) : '';
        self::persist_user_birthday( $user_id, $birthday );
    }

    /**
     * Render birthday field on WooCommerce account details.
     *
     * @return void
     */
    public static function render_wc_account_birthday_field() {
        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return;
        }

        $birthday = self::get_user_birthday( $user_id );
        ?>
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
            <label for="pmcpc_birthday"><?php esc_html_e( 'Birthday', 'product-mailer-campaigns' ); ?></label>
            <input
                type="date"
                class="woocommerce-Input woocommerce-Input--text input-text"
                name="pmcpc_birthday"
                id="pmcpc_birthday"
                value="<?php echo esc_attr( $birthday ); ?>"
                autocomplete="bday"
            />
            <span><?php esc_html_e( 'Used for birthday campaigns and profile personalisation.', 'product-mailer-campaigns' ); ?></span>
        </p>
        <?php
    }

    /**
     * Save birthday from WooCommerce account details.
     *
     * @param int $user_id User ID.
     * @return void
     */
    public static function save_wc_account_birthday_field( $user_id ) {
        $user_id = absint( $user_id );
        if ( ! $user_id ) {
            return;
        }

        $birthday = isset( $_POST['pmcpc_birthday'] ) ? sanitize_text_field( wp_unslash( $_POST['pmcpc_birthday'] ) ) : '';
        self::persist_user_birthday( $user_id, $birthday );
    }

    /**
     * Persist birthday to user meta and matching subscriber record.
     *
     * @param int    $user_id   User ID.
     * @param string $birthday  Raw birthday string.
     * @return void
     */
    protected static function persist_user_birthday( $user_id, $birthday ) {
        $user_id  = absint( $user_id );
        $birthday = self::sanitize_birthday( $birthday );

        if ( ! $user_id ) {
            return;
        }

        if ( '' === $birthday ) {
            delete_user_meta( $user_id, 'pmcpc_birthday' );
        } else {
            update_user_meta( $user_id, 'pmcpc_birthday', $birthday );
        }

        $user = get_userdata( $user_id );
        if ( ! $user || empty( $user->user_email ) || ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {
            return;
        }

        $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( sanitize_email( $user->user_email ) );
        if ( $subscriber && ! empty( $subscriber->id ) && method_exists( 'PMCPC_Subscriber_Manager', 'set_subscriber_birthday' ) ) {
            PMCPC_Subscriber_Manager::set_subscriber_birthday( (int) $subscriber->id, $birthday );
        }
    }

    /**
     * Get the user's saved birthday.
     *
     * @param int $user_id User ID.
     * @return string
     */

    /**
     * Resolve the best front-end preferences URL.
     *
     * WooCommerce sites should use the My Account endpoint when available.
     *
     * @return string
     */
    protected static function get_preferences_page_url() {
        if ( class_exists( 'WooCommerce' ) && function_exists( 'wc_get_account_endpoint_url' ) && is_user_logged_in() ) {
            return wc_get_account_endpoint_url( 'email-preferences' );
        }

        $url = '';
        if ( function_exists( 'pmcpc_get_setting' ) ) {
            $url = (string) pmcpc_get_setting( 'email_prefs_url', '' );
        }

        return $url ? esc_url_raw( $url ) : '';
    }

    protected static function get_user_birthday( $user_id ) {
        $user_id = absint( $user_id );
        if ( ! $user_id ) {
            return '';
        }

        foreach ( array( 'pmcpc_birthday', 'birthday', 'birthdate' ) as $meta_key ) {
            $value = self::sanitize_birthday( (string) get_user_meta( $user_id, $meta_key, true ) );
            if ( '' !== $value ) {
                return $value;
            }
        }

        return '';
    }

    /**
     * Normalise birthday to YYYY-MM-DD or empty string.
     *
     * @param string $birthday Raw value.
     * @return string
     */
    protected static function sanitize_birthday( $birthday ) {
        $birthday = trim( (string) $birthday );
        if ( '' === $birthday ) {
            return '';
        }

        if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $birthday ) ) {
            $parts = explode( '-', $birthday );
            if ( 3 === count( $parts ) ) {
                $year  = (int) $parts[0];
                $month = (int) $parts[1];
                $day   = (int) $parts[2];
                if ( checkdate( $month, $day, $year ) ) {
                    return sprintf( '%04d-%02d-%02d', $year, $month, $day );
                }
            }
        }

        return '';
    }
}
