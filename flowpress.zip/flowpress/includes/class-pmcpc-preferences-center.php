<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PMCPC_Preferences_Center {

    public static function init() {
        add_shortcode( 'pmcpc_preferences_center', array( __CLASS__, 'render' ) );
        add_shortcode( 'pmcpc_preferences', array( __CLASS__, 'render' ) );
    }

    private static function issue_token( $email ) {
        $exp  = time() + WEEK_IN_SECONDS * 2;
        $data = strtolower( $email ) . '|' . $exp;
        $sig  = hash_hmac( 'sha256', $data, wp_salt( 'auth' ) );
        return rtrim( strtr( base64_encode( $data . '|' . $sig ), '+/', '-_' ), '=' );
    }

    private static function verify_token( $token ) {
        $raw = base64_decode( strtr( $token, '-_', '+/' ), true );
        if ( ! $raw ) return '';
        $parts = explode('|', $raw);
        if ( count($parts) !== 3 ) return '';
        list($email,$exp,$sig) = $parts;
        if ( $exp < time() ) return '';
        $check = hash_hmac('sha256', $email.'|'.$exp, wp_salt('auth'));
        return hash_equals($check,$sig) ? sanitize_email($email) : '';
    }

    public static function render() {

        if ( is_user_logged_in() && class_exists('PMCPC_Shortcodes') ) {
            return PMCPC_Shortcodes::render_email_preferences(array());
        }

        $token  = isset( $_GET['pmcpc_token'] ) ? sanitize_text_field( wp_unslash( $_GET['pmcpc_token'] ) ) : '';
        $action = isset( $_GET['pmcpc_action'] ) ? sanitize_key( wp_unslash( $_GET['pmcpc_action'] ) ) : '';
        $email  = $token ? self::verify_token($token) : '';

        if ( !$email ) {
            return '<p>Use the link from your email to manage preferences.</p>';
        }

        $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email($email);
        if ( !$subscriber ) return '<p>Subscriber not found.</p>';

        $messages = array();

        if ( isset( $_POST['pmcpc_confirm_unsub'], $_POST['pmcpc_unsub_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pmcpc_unsub_nonce'] ) ), 'pmcpc_unsub' ) ) {
            $confirm_email = isset( $_POST['pmcpc_email_confirm'] ) ? sanitize_email( wp_unslash( $_POST['pmcpc_email_confirm'] ) ) : '';
            if ( strtolower($confirm_email) === strtolower($email) ) {
                PMCPC_Subscriber_Manager::update_status($subscriber->id,'unsubscribed');
                $messages[] = '<div class="pmcpc-success">You are now unsubscribed.</div>';
            } else {
                $messages[] = '<div class="pmcpc-error">Email did not match.</div>';
            }
        }

        ob_start();
        if ( class_exists( 'PMCPC_Shortcodes' ) && method_exists( 'PMCPC_Shortcodes', 'render_frontend_form_assets' ) ) {
            echo PMCPC_Shortcodes::render_frontend_form_assets(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
        foreach ( $messages as $m ) {
            echo wp_kses_post( $m );
        }
        ?>

        <h2>Email Preferences</h2>
        <p><strong><?php echo esc_html( $email ); ?></strong></p>

        <form method="post" class="pmcpc-preferences-center-form">
            <?php wp_nonce_field('pmcpc_unsub','pmcpc_unsub_nonce'); ?>

            <?php
            $my_account_url = '';
            if ( function_exists( 'wc_get_page_permalink' ) ) {
                $my_account_url = wc_get_page_permalink( 'myaccount' );
            }
            if ( ! $my_account_url ) {
                $my_account_url = home_url( '/my-account/' );
            }
            ?>
            <div class="pmcpc-pref-cta" style="margin: 18px 0 22px 0; padding: 14px 16px; border: 1px solid rgba(0,0,0,0.1); border-radius: 8px;">
                <h3 style="margin-top: 0;"><?php esc_html_e( 'Looking to control what emails you receive?', 'product-mailer-campaigns' ); ?></h3>
                <p><?php esc_html_e( 'Detailed email preferences — like newsletter types and email frequency — are available for customers with an account.', 'product-mailer-campaigns' ); ?></p>
                <p>
                    <a class="button" href="<?php echo esc_url( $my_account_url ); ?>">
                        <?php esc_html_e( 'Create a free account / Log in', 'product-mailer-campaigns' ); ?>
                    </a>
                </p>
                <p style="margin-bottom: 0;"><?php esc_html_e( 'If you still want to stop all emails, you can unsubscribe below.', 'product-mailer-campaigns' ); ?></p>
            </div>

            <div id="pmcpc-unsubscribe"></div>
            <h3>Unsubscribe from all emails</h3>
            <p>Type your email to confirm:</p>
            <input type="email" name="pmcpc_email_confirm" required />
            <p><button type="submit" name="pmcpc_confirm_unsub" class="button button-secondary">Unsubscribe</button></p>
        </form>

        <?php
        return ob_get_clean();
    }
}
PMCPC_Preferences_Center::init();
