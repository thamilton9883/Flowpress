<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Shortcodes methods live in the public traits folder (kept for back-compat).
require_once PMCPC_PLUGIN_DIR . 'includes/public/traits/trait-pmcpc-shortcodes-methods.php';

/**
 * Instance-first shortcodes controller (preferred for DI).
 * Legacy code can continue using PMCPC_Shortcodes.
 */
class PMCPC_Shortcodes_Controller {
    use PMCPC_Shortcodes_Methods;

    /**
     * One-time flash message HTML (set via transient in trait).
     *
     * @var string
     */
    protected static $last_message = '';

    /**
     * Back-compat: older code hooks PMCPC_Shortcodes::register_shortcodes() on init.
     *
     * @return void
     */
    public static function register_shortcodes() {
        // Delegate to the existing init() method provided by the methods trait.
        if ( method_exists( __CLASS__, 'init' ) ) {
            self::init();
            return;
        }
    }
}