<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Registers optional "extra" modules that extend the core plugin without cluttering bootstrap files.
 */
class PMCPC_Modules {

    public static function init() {
        // Front-end subscribe popup.
        if ( class_exists( 'PMCPC_Subscribe_Popup' ) ) {
            PMCPC_Subscribe_Popup::init();
        }

        // Admin: Email & Login customization.
        if ( class_exists( 'PMCPC_Email_Login_Customizer' ) ) {
            PMCPC_Email_Login_Customizer::init();
        }

        // SMTP support (optional).
        if ( class_exists( 'PMCPC_SMTP' ) ) {
            PMCPC_SMTP::init();
        }

        // Keep WP users and PMCPC subscribers in sync.
        if ( class_exists( 'PMCPC_User_Subscriber_Sync' ) ) {
            PMCPC_User_Subscriber_Sync::init();
        }

        // Users screen integration (badge + filter).
        if ( class_exists( 'PMCPC_Users_List_Integration' ) ) {
            PMCPC_Users_List_Integration::init();
        }
    }
}
