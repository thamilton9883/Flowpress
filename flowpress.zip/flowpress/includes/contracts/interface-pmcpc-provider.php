<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

interface PMCPC_Provider_Interface {
    /**
     * Register container bindings.
     *
     * @param PMCPC_Container $container
     * @return void
     */
    public function register( $container );

    /**
     * Return service IDs (or callables) that should be booted.
     *
     * @return array
     */
    public function boot_services();
}
