<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Minimal contract for plugin services.
 */
interface PMCPC_Service_Interface {
    /**
     * Register WordPress hooks (actions/filters).
     *
     * @return void
     */
    public function register();
}
