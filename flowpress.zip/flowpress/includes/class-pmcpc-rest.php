<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/rest/class-pmcpc-rest-controller.php';

/**
 * REST facade (back-compat).
 *
 * Static surface remains, implementation is delegated to a controller instance.
 */
class PMCPC_REST {

    /** @var PMCPC_REST_Controller|null */
    private static $controller = null;

    /**
     * @return PMCPC_REST_Controller
     */
    private static function controller() {
        if ( self::$controller instanceof PMCPC_REST_Controller ) {
            return self::$controller;
        }

        $c = function_exists( 'pmcpc_container' ) ? pmcpc_container() : null;
        if ( $c && method_exists( $c, 'has' ) && $c->has( 'controller.rest' ) ) {
            $svc = $c->get( 'controller.rest' );
            if ( $svc instanceof PMCPC_REST_Controller ) {
                self::$controller = $svc;
                return self::$controller;
            }
        }

        self::$controller = new PMCPC_REST_Controller();
        return self::$controller;
    }

    // Back-compat static methods.
    public static function register_routes() { self::controller()->register_routes(); }
    public static function can_subscribe( WP_REST_Request $request ) { return self::controller()->can_subscribe( $request ); }
    public static function handle_subscribe( WP_REST_Request $request ) { return self::controller()->handle_subscribe( $request ); }
}
