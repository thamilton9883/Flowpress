<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Central registry for email templates (presets + user templates).
 *
 * Goal:
 * - Single source of truth for both the Email Template admin screen and the Campaign -> Email dropdown.
 * - Back-compat with legacy option 'pmcpc_email_template' (string HTML).
 */
class PMCPC_Email_Templates {

    const OPTION_TEMPLATES = 'pmcpc_pro_email_templates';
    const OPTION_DEFAULT   = 'pmcpc_pro_email_template_default';
    const OPTION_LEGACY    = 'pmcpc_email_template';

    /**
     * Preset templates (campaign-content mode).
     * These should be safe HTML for email editors and include {{products_block}} where appropriate.
     */
    public static function get_presets() : array {
        $site = get_bloginfo( 'name' );

        // ---------------------------------------------------------------------
        // Brand-agnostic presets
        // ---------------------------------------------------------------------

        $classic = implode( "", array(
            '<h2 style="margin:0 0 10px 0;font-weight:600;">' . esc_html( $site ) . '</h2>',
            '<h3 style="margin:0 0 14px 0;">' . esc_html__( 'New arrivals', 'product-mailer-campaigns' ) . '</h3>',
            '<p style="margin:0 0 16px 0;">' . esc_html__( 'A few freshly listed pieces we thought you might love.', 'product-mailer-campaigns' ) . '</p>',
            '{{products_block}}',
        ) );

        // A refined, “quiet luxury” preset that suits antique / vintage brands.
        $refined = implode( "", array(
            '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.5px;">' . esc_html( $site ) . '</h2>',
            '<h3 style="margin:0 0 14px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html__( 'A newly curated selection', 'product-mailer-campaigns' ) . '</h3>',
            '<p style="margin:0 0 14px 0;">' . esc_html__( 'Dear {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
            '<p style="margin:0 0 16px 0;">' . esc_html__( 'We are pleased to present a new collection of pieces—chosen for character, craftsmanship, and timeless presence.', 'product-mailer-campaigns' ) . '</p>',
            '{{products_block}}',
            '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
        ) );

        $minimal = implode( "", array(
            '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
            '<p style="margin:0 0 16px 0;">' . esc_html__( 'Here are the latest items added to our collection:', 'product-mailer-campaigns' ) . '</p>',
            '{{products_block}}',
        ) );

        return array(
            'classic' => array(
                'label'        => __( 'Classic', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#e11d48',
                'header_html'  => $classic,
            ),
            'refined' => array(
                'label'        => __( 'Refined', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => $refined,
            ),
            'minimal' => array(
                'label'        => __( 'Minimal', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#1d4ed8',
                'header_html'  => $minimal,
            ),

            // -----------------------------------------------------------------
            // Trigger-specific presets (one per automation trigger)
            // -----------------------------------------------------------------

            'new_subscriber' => array(
                'label'        => __( 'Welcome — New subscriber', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Welcome', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'Thank you for joining our mailing list. Below is a small selection of pieces we think you may enjoy.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'welcome_follow_up' => array(
                'label'        => __( 'Welcome follow-up', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'A few places to start', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'We wanted to follow up with a few highlights from the collection, along with a handful of useful links to help you explore more.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'lead_magnet_download' => array(
                'label'        => __( 'Lead magnet — Delivery', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Your download is ready', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'Thank you for signing up. Here is the resource you requested, along with a few items you may enjoy next.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'subscriber_inactive' => array(
                'label'        => __( 'Re-engagement — Subscriber inactive', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'We have missed you', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'It has been a little while since your last visit. Here is a small selection to help you reconnect with our latest finds.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'subscriber_anniversary' => array(
                'label'        => __( 'Anniversary — Subscriber milestone', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Thank you for being with us', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'It is an anniversary worth marking, and we are delighted you are still with us. Here is a small curated selection in thanks.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'subscriber_birthday' => array(
                'label'        => __( 'Birthday — Subscriber celebration', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Happy birthday', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'Wishing you a wonderful day. To celebrate, we have gathered a few pieces you may enjoy.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'new_customer' => array(
                'label'        => __( 'Thank you — First order (new customer)', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Thank you for your first order', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'We appreciate your order. Your order reference is {{order_id}}. If you would like to continue browsing, here are a few pieces that complement our current collection.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'With thanks,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'repeat_customer' => array(
                'label'        => __( 'Appreciation — Repeat customer', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'A sincere thank you', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'Thank you for returning. Your recent order reference is {{order_id}}. We have set aside a few new arrivals you may wish to see.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'post_purchase' => array(
                'label'        => __( 'Post-purchase — After order completed', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Thank you for your order', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'We hope you enjoy your purchase. Your order reference is {{order_id}}. If you would like to continue browsing, here is a small selection that may be of interest.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'With thanks,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'abandoned_cart_step_1' => array(
                'label'        => __( 'Abandoned cart — Step 1 (gentle reminder)', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'A quick note', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'You recently added items to your cart but didn\'t complete checkout. If you would like to continue, your cart is saved below.', 'product-mailer-campaigns' ) . '</p>',
                    '<div style="margin:0 0 14px 0;">{{cart_items}}</div>',
                    '<p style="margin:0 0 16px 0;"><strong>' . esc_html__( 'Cart total:', 'product-mailer-campaigns' ) . '</strong> {{cart_total}}</p>',
                    '<p style="margin:0 0 16px 0;"><a href="{{cart_url}}">' . esc_html__( 'Resume checkout', 'product-mailer-campaigns' ) . '</a></p>',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'abandoned_cart_step_2' => array(
                'label'        => __( 'Abandoned cart — Step 2 (helpful follow-up)', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Still considering?', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'Just a reminder — your cart is still saved. If you have any questions about condition, measurements, or delivery, simply reply to this email and we\'ll be happy to help.', 'product-mailer-campaigns' ) . '</p>',
                    '<div style="margin:0 0 14px 0;">{{cart_items}}</div>',
                    '<p style="margin:0 0 16px 0;"><strong>' . esc_html__( 'Cart total:', 'product-mailer-campaigns' ) . '</strong> {{cart_total}}</p>',
                    '<p style="margin:0 0 16px 0;"><a href="{{cart_url}}">' . esc_html__( 'Return to your cart', 'product-mailer-campaigns' ) . '</a></p>',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'abandoned_cart_step_3' => array(
                'label'        => __( 'Abandoned cart — Step 3 (final reminder)', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Final reminder', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'As many of our pieces are one-of-a-kind, availability can change quickly. If you would like to complete your purchase, you can do so below.', 'product-mailer-campaigns' ) . '</p>',
                    '<div style="margin:0 0 14px 0;">{{cart_items}}</div>',
                    '<p style="margin:0 0 16px 0;"><strong>' . esc_html__( 'Cart total:', 'product-mailer-campaigns' ) . '</strong> {{cart_total}}</p>',
                    '<p style="margin:0 0 16px 0;"><a href="{{cart_url}}">' . esc_html__( 'Complete checkout', 'product-mailer-campaigns' ) . '</a></p>',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'review_request' => array(
                'label'        => __( 'Review request', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'A small favour', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'We hope you\'re enjoying your recent purchase.', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'Your feedback helps other customers shop with confidence and helps our small business grow.', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'It only takes a moment and really helps small independent shops like ours.', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 10px 0;"><strong>' . esc_html__( 'How was your experience?', 'product-mailer-campaigns' ) . '</strong></p>',
                    '{{review_stars_block}}',
                    '<p style="margin:16px 0 10px 0;">' . esc_html__( 'If you prefer, you can also leave a review using the link below:', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;"><a href="{{review_url}}" style="display:inline-block;padding:12px 18px;background:#c0392b;color:#ffffff;text-decoration:none;border-radius:4px;">' . esc_html__( 'Leave a Review', 'product-mailer-campaigns' ) . '</a></p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'Thank you for supporting our small business.', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'review_reminder' => array(
                'label'        => __( 'Review reminder', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Just a quick reminder', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'If you have a moment, we\'d love to hear what you thought of your recent purchase.', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'Your feedback helps other customers and means a great deal to our small business.', 'product-mailer-campaigns' ) . '</p>',
                    '{{review_stars_block}}',
                    '<p style="margin:16px 0 10px 0;">' . esc_html__( 'Or use the link below:', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;"><a href="{{review_url}}" style="display:inline-block;padding:12px 18px;background:#c0392b;color:#ffffff;text-decoration:none;border-radius:4px;">' . esc_html__( 'Leave a Review', 'product-mailer-campaigns' ) . '</a></p>',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Many thanks,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'customer_inactive' => array(
                'label'        => __( 'Win-back — Customer inactive', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'A few new arrivals you may like', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'It has been a little while since your last visit. We have recently added a number of pieces we thought you may enjoy.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'high_value' => array(
                'label'        => __( 'VIP — High-value customer', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'Early access', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'As one of our most valued customers, we wanted to share a few recent arrivals with you first.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'lapsed_high_value_customer' => array(
                'label'        => __( 'Lapsed high-value customer', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'A curated return visit', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'It has been a little while since your last order, and we thought you might enjoy a curated look at a few recent arrivals from the collection.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),

            'date' => array(
                'label'        => __( 'Scheduled — On a specific date', 'product-mailer-campaigns' ),
                'logo_url'     => '',
                'accent_color' => '#3a3a3a',
                'header_html'  => implode( '', array(
                    '<h2 style="margin:0 0 10px 0;font-weight:500;letter-spacing:0.6px;">' . esc_html( $site ) . '</h2>',
                    '<h3 style="margin:0 0 14px 0;font-weight:500;">' . esc_html__( 'An update from our collection', 'product-mailer-campaigns' ) . '</h3>',
                    '<p style="margin:0 0 14px 0;">' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>',
                    '<p style="margin:0 0 16px 0;">' . esc_html__( 'We are pleased to share a small curated selection for you.', 'product-mailer-campaigns' ) . '</p>',
                    '{{products_block}}',
                    '<p style="margin:18px 0 0 0;">' . esc_html__( 'Warm regards,', 'product-mailer-campaigns' ) . '<br><strong>' . esc_html( $site ) . '</strong></p>',
                ) ),
            ),
        );
    }



    public static function get_template_context_map() : array {
        return array(
            'classic' => array(
                'group' => 'general',
                'compatible_triggers' => array( 'manual', 'date', '' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'refined' => array(
                'group' => 'general',
                'compatible_triggers' => array( 'manual', 'date', '' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'minimal' => array(
                'group' => 'general',
                'compatible_triggers' => array( 'manual', 'date', '' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'new_subscriber' => array(
                'group' => 'wordpress',
                'compatible_triggers' => array( 'new_subscriber' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'welcome_follow_up' => array(
                'group' => 'wordpress',
                'compatible_triggers' => array( 'welcome_follow_up' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'lead_magnet_download' => array(
                'group' => 'wordpress',
                'compatible_triggers' => array( 'lead_magnet_download' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'subscriber_inactive' => array(
                'group' => 'wordpress',
                'compatible_triggers' => array( 'subscriber_inactive' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'subscriber_anniversary' => array(
                'group' => 'wordpress',
                'compatible_triggers' => array( 'subscriber_anniversary' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'subscriber_birthday' => array(
                'group' => 'wordpress',
                'compatible_triggers' => array( 'subscriber_birthday' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'post_purchase' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'post_purchase' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{order_id}}', '{{products_block}}' ),
            ),
            'review_request' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'review_request' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{review_url}}', '{{review_stars_block}}' ),
            ),
            'review_reminder' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'review_request' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{review_url}}', '{{review_stars_block}}' ),
            ),
            'new_customer' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'new_customer', 'first_order' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{order_id}}', '{{products_block}}' ),
            ),
            'repeat_customer' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'repeat_customer' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{order_id}}', '{{products_block}}' ),
            ),
            'customer_inactive' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'customer_inactive' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'high_value' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'high_value', 'vip_customer' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'lapsed_high_value_customer' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'lapsed_high_value_customer' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
            'abandoned_cart_step_1' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'abandoned_cart_step_1' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{cart_items}}', '{{cart_total}}', '{{cart_url}}' ),
            ),
            'abandoned_cart_step_2' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'abandoned_cart_step_2' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{cart_items}}', '{{cart_total}}', '{{cart_url}}' ),
            ),
            'abandoned_cart_step_3' => array(
                'group' => 'woocommerce',
                'compatible_triggers' => array( 'abandoned_cart_step_3' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{cart_items}}', '{{cart_total}}', '{{cart_url}}' ),
            ),
            'date' => array(
                'group' => 'general',
                'compatible_triggers' => array( 'date', 'manual', '' ),
                'recommended_placeholders' => array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' ),
            ),
        );
    }

    public static function get_recommended_template_id_for_trigger( string $trigger ) : string {
        $trigger = sanitize_key( $trigger );
        if ( '' === $trigger ) {
            return self::get_default_id();
        }

        $contexts = self::get_template_context_map();
        foreach ( $contexts as $template_id => $context ) {
            $compatible = isset( $context['compatible_triggers'] ) && is_array( $context['compatible_triggers'] ) ? $context['compatible_triggers'] : array();
            if ( in_array( $trigger, $compatible, true ) ) {
                return (string) $template_id;
            }
        }

        return self::get_default_id();
    }

    public static function get_recommended_placeholders_for_trigger( string $trigger ) : array {
        $recommended_template = self::get_recommended_template_id_for_trigger( $trigger );
        $contexts             = self::get_template_context_map();
        if ( isset( $contexts[ $recommended_template ]['recommended_placeholders'] ) && is_array( $contexts[ $recommended_template ]['recommended_placeholders'] ) ) {
            return array_values( array_unique( array_map( 'strval', $contexts[ $recommended_template ]['recommended_placeholders'] ) ) );
        }

        return array( '{{first_name}}', '{{email}}', '{{products_block}}' );
    }

    /**
     * Return merged templates: presets overridden by saved templates with the same id,
     * plus any additional custom templates.
     */
    public static function get_all() : array {
        $presets = self::get_presets();
        $saved   = get_option( self::OPTION_TEMPLATES, array() );
        if ( ! is_array( $saved ) ) {
            $saved = array();
        }

        // One-time legacy migration (safe to call repeatedly).
        self::maybe_migrate_legacy_into_saved( $saved, $presets );

        // Merge: saved overrides win.
        $all = $presets;
        foreach ( $saved as $id => $tpl ) {
            $id = sanitize_key( (string) $id );
            if ( '' === $id || ! is_array( $tpl ) ) {
                continue;
            }
            $base = isset( $all[ $id ] ) && is_array( $all[ $id ] ) ? $all[ $id ] : array();
            $all[ $id ] = array_merge( $base, self::sanitize_template( $tpl, $id ) );
        }

        // Ensure minimum shape.
        foreach ( $all as $id => $tpl ) {
            if ( ! is_array( $tpl ) ) {
                unset( $all[ $id ] );
                continue;
            }
            $all[ $id ] = array_merge(
                array(
                    'label'        => $id,
                    'logo_url'     => '',
                    'accent_color' => '#1d4ed8',
                    'header_html'  => '',
                    'updated_at'   => 0,
                ),
                $tpl
            );
        }

        return $all;
    }

    public static function get_default_id() : string {
        $all = self::get_all();

        $default = get_option( self::OPTION_DEFAULT, '' );
        $default = sanitize_key( (string) $default );
        if ( '' === $default ) {
            $default = 'classic';
        }
        if ( ! isset( $all[ $default ] ) ) {
            $default = isset( $all['classic'] ) ? 'classic' : (string) array_key_first( $all );
        }
        return $default ?: 'classic';
    }

    private static function sanitize_template( array $tpl, string $id ) : array {
        $out = array();

        $out['label'] = isset( $tpl['label'] ) ? sanitize_text_field( (string) $tpl['label'] ) : $id;

        if ( isset( $tpl['logo_url'] ) ) {
            $out['logo_url'] = esc_url_raw( (string) $tpl['logo_url'] );
        }

        if ( isset( $tpl['accent_color'] ) ) {
            $c = sanitize_text_field( (string) $tpl['accent_color'] );
            if ( preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $c ) ) {
                $out['accent_color'] = $c;
            }
        }

        if ( isset( $tpl['header_html'] ) ) {
            $html = (string) $tpl['header_html'];
            // Strip scripts (email-safe).
            $html = preg_replace( '/<\s*script[^>]*>.*?<\s*\/\s*script\s*>/is', '', $html );
            $out['header_html'] = $html;
        }

        if ( isset( $tpl['updated_at'] ) ) {
            $out['updated_at'] = absint( $tpl['updated_at'] );
        }

        return $out;
    }

    /**
     * If an older install stored a single HTML string in pmcpc_email_template,
     * migrate it to a saved custom template so it appears in both dropdowns.
     */
    private static function maybe_migrate_legacy_into_saved( array $saved, array $presets ) : void {
        $legacy = get_option( self::OPTION_LEGACY, null );
        if ( null === $legacy ) {
            return;
        }
        if ( ! is_string( $legacy ) || '' === trim( $legacy ) ) {
            return;
        }

        // Don’t overwrite if they already have a custom legacy template stored.
        $legacy_id = 'custom_legacy';
        if ( isset( $saved[ $legacy_id ] ) || isset( $presets[ $legacy_id ] ) ) {
            return;
        }

        $saved[ $legacy_id ] = array(
            'label'        => __( 'Custom (legacy)', 'product-mailer-campaigns' ),
            'logo_url'     => '',
            'accent_color' => '#1d4ed8',
            'header_html'  => $legacy,
        );

        update_option( self::OPTION_TEMPLATES, $saved );
        // Keep legacy option in place to avoid breaking any external code that reads it.
    }
}
