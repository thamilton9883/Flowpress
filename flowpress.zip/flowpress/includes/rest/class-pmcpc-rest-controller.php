<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * REST subscribe endpoint controller.
 */
class PMCPC_REST_Controller {

    public function register_routes() {
        register_rest_route(
            'pmcpc/v1',
            '/subscribe',
            array(
                'methods'             => 'POST',
                'callback'            => array( $this, 'handle_subscribe' ),
                'permission_callback' => array( $this, 'can_subscribe' ),
            )
        );
    }

    /**
     * Permission callback for the public subscribe endpoint.
     *
     * @param WP_REST_Request $request Request.
     * @return bool
     */
    public function can_subscribe( WP_REST_Request $request ) {

        // Allow site owners / integrators to implement their own authorization.
        $allowed = apply_filters( 'pmcpc_rest_subscribe_allowed', null, $request );
        if ( null !== $allowed ) {
            return (bool) $allowed;
        }

        // 1) Same-site REST nonce.
        $nonce = $request->get_header( 'X-WP-Nonce' );
        if ( $nonce && wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            return true;
        }

        // 2) API key.
        $stored_key = '';
        if ( class_exists( 'PMCPC_Settings' ) ) {
            $stored_key = (string) PMCPC_Settings::get( 'api_subscribe_key', '' );
        }
        $stored_key = trim( $stored_key );

        if ( '' !== $stored_key ) {
            $provided = (string) $request->get_header( 'X-PMCPC-Subscribe-Key' );
            if ( '' === $provided ) {
                $provided = (string) $request->get_param( 'api_key' );
            }
            $provided = trim( $provided );

            if ( '' !== $provided ) {
                return hash_equals( $stored_key, $provided );
            }
        }

        return false;
    }

    public function handle_subscribe( WP_REST_Request $request ) {
        $email      = sanitize_email( $request->get_param( 'email' ) );
        $first_name = sanitize_text_field( (string) $request->get_param( 'first_name' ) );
        $last_name  = sanitize_text_field( (string) $request->get_param( 'last_name' ) );
        $birthday   = sanitize_text_field( (string) $request->get_param( 'birthday' ) );
        $status     = sanitize_text_field( (string) $request->get_param( 'status' ) );
        $tags_param = $request->get_param( 'tags' );

        if ( ! $status ) {
            $status = 'active';
        }

        if ( ! is_email( $email ) ) {
            return new WP_REST_Response(
                array(
                    'success' => false,
                    'message' => 'Invalid email address.',
                ),
                400
            );
        }

        $is_new = PMCPC_Subscriber_Manager::handle_opt_in(
            array(
                'email'      => $email,
                'first_name' => $first_name,
                'last_name'  => $last_name,
                'context'    => 'api',
                'status'     => $status,
            )
        );

        if ( false === $is_new && 'active' === $status ) {
            return new WP_REST_Response(
                array(
                    'success' => false,
                    'message' => 'Subscription blocked by spam protection.',
                ),
                403
            );
        }

        $tags = array();
        if ( is_string( $tags_param ) ) {
            $tags = array_filter( array_map( 'trim', explode( ',', $tags_param ) ) );
        } elseif ( is_array( $tags_param ) ) {
            foreach ( $tags_param as $t ) {
                $tags[] = trim( (string) $t );
            }
            $tags = array_filter( $tags );
        }

        $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $email );
        if ( $subscriber && ! empty( $tags ) ) {
            PMCPC_Subscriber_Manager::set_tags_for_subscriber( $subscriber->id, $tags );
        }
        if ( $subscriber && '' !== $birthday && method_exists( 'PMCPC_Subscriber_Manager', 'set_subscriber_birthday' ) ) {
            PMCPC_Subscriber_Manager::set_subscriber_birthday( (int) $subscriber->id, $birthday );
        }

        if ( $is_new && 'active' === $status ) {
            PMCPC_Campaign_Manager::send_welcome_campaigns_for_subscriber_email( $email );
        }

        return new WP_REST_Response(
            array(
                'success'    => true,
                'message'    => $is_new ? 'Subscriber created.' : 'Subscriber updated.',
                'new'        => $is_new,
                'subscriber' => array(
                    'email'      => $email,
                    'first_name' => $first_name,
                    'last_name'  => $last_name,
                    'status'     => $status,
                    'birthday'   => $birthday,
                    'tags'       => $tags,
                ),
            ),
            200
        );
    }
}
