<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Minimal service locator for back-compat static facades.
 *
 * The refactor introduces a DI container, but much of the plugin surface area
 * remains static for backward compatibility. These helpers provide a single
 * safe entry point to fetch the container when available.
 */

if ( ! function_exists( 'pmcpc_container' ) ) {
    /**
     * @return PMCPC_Container|null
     */
    function pmcpc_container() {
        if ( ! class_exists( 'PMCPC_Container' ) ) {
            return null;
        }
        return isset( $GLOBALS['pmcpc_container'] ) && $GLOBALS['pmcpc_container'] instanceof PMCPC_Container
            ? $GLOBALS['pmcpc_container']
            : null;
    }
}


/**
 * Detect whether the Pro add-on is active.
 *
 * This is intentionally defensive: it supports different load orders and
 * class/constant naming differences across Pro builds.
 *
 * @return bool
 */
function pmcpc_is_pro_active() {

    // 1) Fast path: Pro bootstrap class.
    if ( class_exists( 'PMCPC_Pro_Bootstrap' ) ) {
        return true;
    }

    // 2) Pro version constant.
    if ( defined( 'PMCPC_PRO_VERSION' ) ) {
        return true;
    }

    // 3) Check active plugins list (works even if Pro boot hasn't run yet).
    if ( ! function_exists( 'is_plugin_active' ) ) {
        $plugin_php = ABSPATH . 'wp-admin/includes/plugin.php';
        if ( file_exists( $plugin_php ) ) {
            include_once $plugin_php;
        }
    }

    if ( function_exists( 'is_plugin_active' ) ) {
        // Canonical slug for our Pro add-on.
        if ( is_plugin_active( 'product-mailer-campaigns-pro/product-mailer-campaigns-pro.php' ) ) {
            return true;
        }

        // Fallback: if folder name differs, scan active plugins for the main file.
        $active = (array) get_option( 'active_plugins', array() );
        foreach ( $active as $plugin_file ) {
            if ( substr( $plugin_file, -strlen( '/product-mailer-campaigns-pro.php' ) ) === '/product-mailer-campaigns-pro.php' ) {
                return true;
            }
        }
    }

    return false;
}

