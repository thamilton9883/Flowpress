<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Subscriber Updates settings helpers.
 */
class PMCPC_Subscriber_Updates_Settings {

    /**
     * Main option key.
     */
    const OPTION_KEY = 'pmcpc_sub_updates_settings';

    /**
     * Legacy page option key.
     */
    const PAGE_OPTION_KEY = 'pmcpc_sub_updates_page_id';

    /**
     * Sanitize settings input from a request array.
     *
     * @param array $request Raw request values.
     * @return array
     */
    public static function sanitize_settings_input( $request ) {
        $request  = is_array( $request ) ? $request : array();
        $settings = array(
            'enabled'                      => isset( $request['enabled'] ) ? 1 : 0,
            'auto_create_page'             => isset( $request['auto_create_page'] ) ? 1 : 0,
            'page_id'                      => isset( $request['page_id'] ) ? absint( wp_unslash( $request['page_id'] ) ) : 0,
            'post_status'                  => isset( $request['post_status'] ) ? sanitize_key( (string) wp_unslash( $request['post_status'] ) ) : 'publish',
            'posts_per_page'               => isset( $request['posts_per_page'] ) ? max( 1, min( 50, absint( wp_unslash( $request['posts_per_page'] ) ) ) ) : 10,
            'hide_expired_in_feed'         => isset( $request['hide_expired_in_feed'] ) ? 1 : 0,
            'show_date'                    => isset( $request['show_date'] ) ? 1 : 0,
            'show_topic_filter'            => isset( $request['show_topic_filter'] ) ? 1 : 0,
            'show_related'                 => isset( $request['show_related'] ) ? 1 : 0,
            'default_image_url'            => isset( $request['default_image_url'] ) ? esc_url_raw( (string) wp_unslash( $request['default_image_url'] ) ) : '',
            'intro_text'                   => isset( $request['intro_text'] ) ? sanitize_textarea_field( (string) wp_unslash( $request['intro_text'] ) ) : '',
            'log_limit'                    => isset( $request['log_limit'] ) ? max( 20, absint( wp_unslash( $request['log_limit'] ) ) ) : 100,
            'commerce_auto_enabled'        => isset( $request['commerce_auto_enabled'] ) ? 1 : 0,
            'commerce_new_product_enabled' => isset( $request['commerce_new_product_enabled'] ) ? 1 : 0,
            'commerce_mode'                => isset( $request['commerce_mode'] ) ? sanitize_key( (string) wp_unslash( $request['commerce_mode'] ) ) : 'latest',
            'commerce_limit'               => isset( $request['commerce_limit'] ) ? max( 1, min( 12, absint( wp_unslash( $request['commerce_limit'] ) ) ) ) : 4,
            'commerce_title_prefix'        => isset( $request['commerce_title_prefix'] ) ? sanitize_text_field( (string) wp_unslash( $request['commerce_title_prefix'] ) ) : '',
            'commerce_topic'               => isset( $request['commerce_topic'] ) ? sanitize_text_field( (string) wp_unslash( $request['commerce_topic'] ) ) : '',
            'commerce_cta_label'           => isset( $request['commerce_cta_label'] ) ? sanitize_text_field( (string) wp_unslash( $request['commerce_cta_label'] ) ) : '',
            'daily_publish_hour'           => isset( $request['daily_publish_hour'] ) ? max( 0, min( 23, absint( wp_unslash( $request['daily_publish_hour'] ) ) ) ) : 9,
            'daily_publish_minute'         => isset( $request['daily_publish_minute'] ) ? max( 0, min( 59, absint( wp_unslash( $request['daily_publish_minute'] ) ) ) ) : 0,
            'daily_publish_days'           => isset( $request['daily_publish_days'] ) && is_array( $request['daily_publish_days'] ) ? array_values( array_intersect( array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' ), array_map( 'sanitize_key', wp_unslash( $request['daily_publish_days'] ) ) ) ) : array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' ),
            'auto_expiry_days'             => isset( $request['auto_expiry_days'] ) ? max( 0, min( 365, absint( wp_unslash( $request['auto_expiry_days'] ) ) ) ) : 0,
            'only_in_stock'                => isset( $request['only_in_stock'] ) ? 1 : 0,
            'require_product_image'        => isset( $request['require_product_image'] ) ? 1 : 0,
            'exclude_categories'           => isset( $request['exclude_categories'] ) ? sanitize_text_field( (string) wp_unslash( $request['exclude_categories'] ) ) : '',
            'max_product_age_days'         => isset( $request['max_product_age_days'] ) ? max( 0, min( 3650, absint( wp_unslash( $request['max_product_age_days'] ) ) ) ) : 0,
            'avoid_repeat_product_days'    => isset( $request['avoid_repeat_product_days'] ) ? max( 0, min( 365, absint( wp_unslash( $request['avoid_repeat_product_days'] ) ) ) ) : 30,
            'preview_limit'                => isset( $request['preview_limit'] ) ? max( 1, min( 12, absint( wp_unslash( $request['preview_limit'] ) ) ) ) : 4,
            'feed_order'                   => isset( $request['feed_order'] ) ? sanitize_key( (string) wp_unslash( $request['feed_order'] ) ) : 'featured_desc',
            'feed_columns'                 => isset( $request['feed_columns'] ) ? max( 1, min( 3, absint( wp_unslash( $request['feed_columns'] ) ) ) ) : 2,
            'feed_image_ratio'             => isset( $request['feed_image_ratio'] ) ? sanitize_key( (string) wp_unslash( $request['feed_image_ratio'] ) ) : 'landscape',
            'feed_excerpt_length'          => isset( $request['feed_excerpt_length'] ) ? max( 10, min( 80, absint( wp_unslash( $request['feed_excerpt_length'] ) ) ) ) : 28,
            'show_images'                  => isset( $request['show_images'] ) ? 1 : 0,
        );

        if ( ! in_array( $settings['post_status'], array( 'publish', 'draft', 'private' ), true ) ) {
            $settings['post_status'] = 'publish';
        }

        if ( ! in_array( $settings['commerce_mode'], array( 'latest', 'featured' ), true ) ) {
            $settings['commerce_mode'] = 'latest';
        }

        if ( ! in_array( $settings['feed_order'], array( 'featured_desc', 'date_desc', 'date_asc' ), true ) ) {
            $settings['feed_order'] = 'featured_desc';
        }

        if ( ! in_array( $settings['feed_image_ratio'], array( 'landscape', 'square', 'portrait' ), true ) ) {
            $settings['feed_image_ratio'] = 'landscape';
        }

        if ( empty( $settings['daily_publish_days'] ) ) {
            $settings['daily_publish_days'] = array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' );
        }

        return $settings;
    }

    /**
     * Determine whether a page id is the special WordPress posts page.
     *
     * @param int $page_id Page id.
     * @return bool
     */
    public static function is_posts_page( $page_id ) {
        $page_id = absint( $page_id );
        if ( $page_id <= 0 ) {
            return false;
        }

        return $page_id === (int) get_option( 'page_for_posts', 0 );
    }

    /**
     * Ensure a dedicated Subscriber Updates page exists and contains the shortcode.
     *
     * @return int
     */
    public static function ensure_updates_page() {
        $existing_page = get_page_by_path( 'subscriber-updates' );
        if ( $existing_page instanceof WP_Post ) {
            self::normalize_updates_page_content( (int) $existing_page->ID );

            return (int) $existing_page->ID;
        }

        $page_id = wp_insert_post(
            array(
                'post_title'   => __( 'Subscriber Updates', 'product-mailer-campaigns' ),
                'post_name'    => 'subscriber-updates',
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_content' => '[pmcpc_sub_updates]',
            )
        );

        if ( $page_id && ! is_wp_error( $page_id ) ) {
            return (int) $page_id;
        }

        return 0;
    }

    /**
     * Ensure a specific page contains only the canonical Subscriber Updates shortcode once.
     *
     * @param int $page_id Page id.
     * @return void
     */
    public static function normalize_updates_page_content( $page_id ) {
        $page_id = absint( $page_id );
        if ( $page_id <= 0 ) {
            return;
        }

        $page = get_post( $page_id );
        if ( ! ( $page instanceof WP_Post ) || 'page' !== $page->post_type ) {
            return;
        }

        $content     = (string) $page->post_content;
        $has_current = false !== strpos( $content, '[pmcpc_sub_updates' );
        $has_legacy  = false !== strpos( $content, '[pmcpc_subscriber_updates' );

        if ( $has_current || $has_legacy ) {
            $normalized = preg_replace( '/\[(?:pmcpc_sub_updates|pmcpc_subscriber_updates)[^\]]*\]/i', '', $content );
            $normalized = is_string( $normalized ) ? trim( $normalized ) : '';
            $normalized = '' !== $normalized
                ? trim( $normalized . "\n\n[pmcpc_sub_updates]" )
                : '[pmcpc_sub_updates]';
        } else {
            $normalized = trim( $content . "\n\n[pmcpc_sub_updates]" );
        }

        if ( trim( $content ) === $normalized ) {
            return;
        }

        wp_update_post(
            array(
                'ID'           => $page_id,
                'post_content' => $normalized,
            )
        );
    }

    /**
     * Normalize settings so FlowPress does not use WordPress's special posts page
     * as the Subscriber Updates destination.
     *
     * @param array $settings Settings array.
     * @return array
     */
    public static function normalize_settings( $settings ) {
        $settings = is_array( $settings ) ? $settings : array();
        $settings = wp_parse_args(
            $settings,
            array(
                'auto_create_page' => 1,
                'page_id'          => 0,
            )
        );

        $page_id = absint( $settings['page_id'] );

        if ( self::is_posts_page( $page_id ) ) {
            $page_id = 0;
        }

        if ( $page_id <= 0 && ! empty( $settings['auto_create_page'] ) ) {
            $page_id = self::ensure_updates_page();
        }

        if ( $page_id > 0 ) {
            self::normalize_updates_page_content( $page_id );
        }

        $settings['page_id'] = $page_id;

        return $settings;
    }

    /**
     * Persist sanitized settings and keep the legacy page option in sync.
     *
     * @param array $settings Sanitized settings.
     * @return void
     */
    public static function save_settings( $settings ) {
        $settings = self::normalize_settings( $settings );
        update_option( self::OPTION_KEY, $settings, false );

        if ( ! empty( $settings['page_id'] ) ) {
            update_option( self::PAGE_OPTION_KEY, (int) $settings['page_id'], false );
            return;
        }

        delete_option( self::PAGE_OPTION_KEY );
    }

    /**
     * Build the data needed to render the settings screen.
     *
     * @param array $settings Current settings.
     * @return array
     */
    public static function get_settings_page_context( $settings ) {
        $settings      = self::normalize_settings( is_array( $settings ) ? $settings : array() );
        $selected_page = ! empty( $settings['page_id'] ) ? get_post( (int) $settings['page_id'] ) : null;

        if ( $selected_page instanceof WP_Post && 'page' !== $selected_page->post_type ) {
            $selected_page = null;
        }

        return array(
            'pages'         => get_pages(),
            'selected_page' => $selected_page instanceof WP_Post ? $selected_page : null,
            'view_url'      => $selected_page instanceof WP_Post ? get_permalink( $selected_page ) : '',
            'edit_url'      => $selected_page instanceof WP_Post ? get_edit_post_link( $selected_page->ID ) : '',
        );
    }
}
