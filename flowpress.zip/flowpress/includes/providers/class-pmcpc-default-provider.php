<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/contracts/interface-pmcpc-provider.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/domain/class-pmcpc-modules-service.php';

/**
 * Default service provider: defines container bindings and boot order.
 */
class PMCPC_Default_Provider implements PMCPC_Provider_Interface {

    public function register( $container ) {
        // Core service layer.
        $container->singleton( 'service.cron_migration', function( $c ) { return new PMCPC_Cron_Migration_Service(); } );
        $container->singleton( 'service.db_upgrader', function( $c ) { return new PMCPC_DB_Upgrader_Service(); } );
        $container->singleton( 'service.admin_ui', function( $c ) { return new PMCPC_Admin_UI_Service(); } );

        // Domain services (split by responsibility).
        $container->singleton( 'service.licensing', function( $c ) { return new PMCPC_Licensing_Service(); } );
        $container->singleton( 'service.admin_notices', function( $c ) { return new PMCPC_Admin_Notices_Service(); } );
        $container->singleton( 'service.cron', function( $c ) { return new PMCPC_Cron_Service(); } );
        $container->singleton( 'service.admin_post', function( $c ) { return new PMCPC_Admin_Post_Service(); } );
        $container->singleton( 'service.public_init', function( $c ) { return new PMCPC_Public_Init_Service(); } );
        $container->singleton( 'service.rest', function( $c ) { return new PMCPC_REST_Service(); } );
        $container->singleton( 'controller.rest', function( $c ) { return new PMCPC_REST_Controller(); } );
        $container->singleton( 'controller.tracking', function( $c ) { return new PMCPC_Tracking_Controller(); } );
        $container->singleton( 'service.woocommerce', function( $c ) { return new PMCPC_WooCommerce_Service(); } );

        // Premium module loader (automation, pro analytics, etc.).
        $container->singleton( 'service.premium_modules', function( $c ) { return new PMCPC_Premium_Modules_Service(); } );

        // Instance-first controllers (preferred; legacy facades still work).
        $container->singleton( 'controller.queue', function( $c ) { return new PMCPC_Queue_Controller(); } );
        $container->singleton( 'controller.campaigns', function( $c ) { return new PMCPC_Campaigns_Controller(); } );
        $container->singleton( 'controller.subscribers', function( $c ) { return new PMCPC_Subscribers_Controller(); } );
        $container->singleton( 'controller.shortcodes', function( $c ) { return new PMCPC_Shortcodes_Controller(); } );

        // Optional module bundle (subscribe popup, SMTP, etc.).
        $container->singleton( 'service.modules', function( $c ) { return new PMCPC_Modules_Service(); } );
    }

    public function boot_services() {
        return array(
            'service.cron_migration',
            'service.db_upgrader',
            'service.admin_ui',
            // Load licensing early so admin UI + notices can use it.
            'service.licensing',
            'service.admin_notices',
            'service.cron',
            'service.admin_post',
            'service.public_init',
            'service.rest',
            'service.woocommerce',
            'service.premium_modules',
            'service.modules',
        );
    }
}
