<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once PMCPC_PLUGIN_DIR . 'includes/campaign/traits/trait-pmcpc-campaign-manager-methods.php';

/**
 * Instance-first campaigns controller.
 * This is the preferred implementation to bind in the DI container.
 * Legacy code can continue using PMCPC_Campaign_Manager.
 */
class PMCPC_Campaigns_Controller {
    use PMCPC_Campaign_Manager_Methods;
}
