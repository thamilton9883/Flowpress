<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

        $editor_recipient_summary = __( 'Build the audience to estimate recipients', 'product-mailer-campaigns' );
        if ( ! empty( $campaign->id ) ) {
            $editor_recipient_estimate = self::count_recipients_for_campaign( $campaign );
            if ( is_numeric( $editor_recipient_estimate ) ) {
                $editor_recipient_summary = sprintf(
                    /* translators: %d: recipient estimate. */
                    __( '%d estimated recipients', 'product-mailer-campaigns' ),
                    (int) $editor_recipient_estimate
                );
            }
        } elseif ( 'Automation' === $campaign_mode_label ) {
            $editor_recipient_summary = __( 'Event-based recipients', 'product-mailer-campaigns' );
        }

        $editor_ready_reasons  = array();
        $editor_ready_warnings = array();
        $editor_readiness      = self::get_campaign_readiness_state( $campaign, $editor_ready_reasons, $editor_ready_warnings );
        $editor_readiness_label = __( 'Needs attention', 'product-mailer-campaigns' );
        if ( 'ready' === $editor_readiness ) {
            $editor_readiness_label = __( 'Ready to send', 'product-mailer-campaigns' );
        } elseif ( 'warn' === $editor_readiness ) {
            $editor_readiness_label = __( 'Ready with warnings', 'product-mailer-campaigns' );
        } elseif ( 'n/a' === $editor_readiness ) {
            $editor_readiness_label = __( 'Still configuring', 'product-mailer-campaigns' );
        }

        PMCPC_Admin::render_stats_strip(
            array(
                array(
                    'label' => __( 'Mode', 'product-mailer-campaigns' ),
                    'value' => $campaign_mode_label,
                    'meta'  => __( 'Manual, scheduled, or automation', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Audience', 'product-mailer-campaigns' ),
                    'value' => $editor_recipient_summary,
                    'meta'  => __( 'Estimate updates as the builder changes', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Readiness', 'product-mailer-campaigns' ),
                    'value' => $editor_readiness_label,
                    'meta'  => __( 'Review warnings before queueing or enabling', 'product-mailer-campaigns' ),
                ),
            )
        );

        if ( $current_id ) {
            $editor_preview_url = wp_nonce_url(
                add_query_arg(
                    array(
                        'page'          => 'pmcpc_campaigns',
                        'campaign_id'   => (int) $current_id,
                        'pmcpc_preview' => '1',
                    ),
                    admin_url( 'admin.php' )
                ),
                'pmcpc_preview_campaign_' . (int) $current_id
            );
            $editor_test_url = wp_nonce_url(
                admin_url( 'admin-post.php?action=pmcpc_test_campaign&campaign_id=' . (int) $current_id ),
                'pmcpc_test_campaign_' . (int) $current_id
            );
            $editor_send_test_url = wp_nonce_url(
                admin_url( 'admin-post.php?action=pmcpc_send_test_email&campaign_id=' . (int) $current_id ),
                'pmcpc_send_test_email_' . (int) $current_id
            );
            $editor_queue_url = wp_nonce_url(
                admin_url( 'admin-post.php?action=pmcpc_queue_campaign&campaign_id=' . (int) $current_id ),
                'pmcpc_send_campaign_' . (int) $current_id
            );

            echo '<div class="pmcpc-campaign-page-actions pmcpc-campaign-page-actions--editor">';
            echo '<a class="button button-primary" href="' . esc_url( $editor_preview_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Preview', 'product-mailer-campaigns' ) . '</a>';
            echo '<a class="button" href="' . esc_url( $editor_send_test_url ) . '">' . esc_html__( 'Send Test', 'product-mailer-campaigns' ) . '</a>';
            echo '<a class="button" href="' . esc_url( $editor_test_url ) . '">' . esc_html__( 'Check Audience', 'product-mailer-campaigns' ) . '</a>';
            echo '<a class="button" href="' . esc_url( $editor_queue_url ) . '">' . esc_html__( 'Add to Queue', 'product-mailer-campaigns' ) . '</a>';
            echo '</div>';
        }

        echo '<style>
        .pmcpc-campaign-layout{display:flex;gap:24px;align-items:flex-start;}
        .pmcpc-campaign-page-actions--editor{margin-top:-4px;margin-bottom:18px;display:flex;gap:10px;flex-wrap:wrap;}
        .pmcpc-campaign-layout .pmcpc-left{flex:1;min-width:0;}
        .pmcpc-campaign-layout .pmcpc-right{width:340px;max-width:100%;position:sticky;top:84px;}
        .pmcpc-campaign-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;box-shadow:0 1px 1px rgba(0,0,0,.02);}
        .pmcpc-campaign-card h3{margin:0 0 10px;font-size:14px;}
        .pmcpc-campaign-summary-pill{display:inline-block;padding:2px 8px;border-radius:999px;border:1px solid #dcdcde;font-size:12px;margin-right:6px;}
        .pmcpc-inline-warn{margin:8px 0 0;padding:10px;border-left:4px solid #d63638;background:#fff0f0;}
        .pmcpc-insight-panel{padding:14px 6px 6px;}
        .pmcpc-insight-columns{display:flex;gap:22px;flex-wrap:wrap;}
        .pmcpc-insight-col{flex:1;min-width:260px;}
        .pmcpc-insight-col h4{margin:0 0 8px;font-size:13px;}
        .pmcpc-insight-list{margin:0;padding-left:18px;}
        .pmcpc-insight-list li{margin:0 0 8px;}
        .pmcpc-insight-meta{color:#646970;}
        .pmcpc-insight-row td{border-top:none !important;background:#fcfcfd;}
        .pmcpc-muted{opacity:0.55;}
        .pmcpc-stages{margin:0 0 18px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;padding:0 0 12px;border-bottom:1px solid #e0e4e9;}
        .pmcpc-stage-chip{display:inline-flex;gap:8px;align-items:center;padding:8px 12px;border:1px solid #dcdcde;border-radius:999px;background:#fff;font-size:13px;font-weight:600;text-decoration:none;color:#50575e;position:relative;}
        .pmcpc-stage-chip[aria-current="step"]{border-color:#2271b1;box-shadow:0 0 0 1px #2271b1 inset;color:#2271b1;background:#f6fbff;}
        .pmcpc-stage-chip .pmcpc-stage-num{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:999px;border:1px solid #dcdcde;font-size:11px;background:#fff;}
        .pmcpc-stage-chip[aria-current="step"] .pmcpc-stage-num{border-color:#2271b1;color:#2271b1;}
        .pmcpc-stage-chip:not(:last-child)::after{content:"→";position:absolute;right:-16px;color:#9aa0a6;font-weight:400;}
        .pmcpc-stage-title{margin:0 0 10px;font-size:18px;line-height:1.35;}
        .pmcpc-stage-help{margin:6px 0 0;color:#646970;max-width:820px;line-height:1.55;}
        .pmcpc-stage-actions{display:flex;gap:10px;align-items:center;justify-content:flex-end;margin:18px 0 0;padding:14px 0 0;border-top:1px solid #e0e4e9;}
        .pmcpc-stage-actions .button{min-width:110px;}
        .pmcpc-stage-actions .pmcpc-stage-spacer{flex:1;}
        .pmcpc-stage-badge{display:inline-block;font-size:12px;color:#646970;margin-right:10px;}
        .pmcpc-builder-save{margin-top:12px;}
        .pmcpc-builder-save .button{min-width:120px;}
        .pmcpc-template-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;}
        .pmcpc-template-row .description{display:block;flex-basis:100%;margin:6px 0 0;}
        .pmcpc-placeholder-list{margin-top:10px;display:flex;flex-wrap:wrap;gap:8px;}
        .pmcpc-placeholder-chip{display:inline-block;background:#f6f7f7;border:1px solid #dcdcde;border-radius:999px;padding:4px 10px;font-family:monospace;font-size:12px;line-height:1.5;}
        .pmcpc-summary-block{margin-top:12px;padding:12px;border:1px solid #dcdcde;border-radius:12px;background:#fff;}
        .pmcpc-summary-row{margin:0 0 10px;line-height:1.55;}
        .pmcpc-summary-row:last-child{margin-bottom:0;}
        #pmcpc_campaign_builder_table{width:100%;display:block;background:transparent;border:none;box-shadow:none;overflow:visible;}
        #pmcpc_campaign_builder_table tbody.pmcpc-stage{display:none;padding:24px 28px 28px;background:#fff;border:1px solid #dcdcde;border-radius:16px;box-shadow:0 1px 1px rgba(0,0,0,.02);}
        #pmcpc_campaign_builder_table tbody.pmcpc-stage.is-active{display:block;}
        #pmcpc_campaign_builder_table tr{display:grid;grid-template-columns:minmax(180px,240px) minmax(0,1fr);gap:24px;padding:16px 18px;margin-top:12px;border:1px solid #e6e8eb;border-radius:12px;background:#fff;}
        #pmcpc_campaign_builder_table tr:first-child{border:none;background:transparent;border-radius:0;padding:0;margin-top:0;}
        #pmcpc_campaign_builder_table th,#pmcpc_campaign_builder_table td{display:block;width:auto;padding:0;margin:0;vertical-align:top;text-align:left;}
        #pmcpc_campaign_builder_table th{font-size:14px;font-weight:600;line-height:1.45;color:#1d2327;}
        #pmcpc_campaign_builder_table td{font-size:14px;line-height:1.5;}
        #pmcpc_campaign_builder_table tr > th[colspan="2"]{grid-column:1 / -1;padding-top:4px;}
        #pmcpc_campaign_builder_table .description{display:block;margin-top:8px;max-width:820px;line-height:1.55;color:#646970;}
        #pmcpc_campaign_builder_table p{margin-top:0;}
        #pmcpc_campaign_builder_table input[type="text"],#pmcpc_campaign_builder_table input[type="email"],#pmcpc_campaign_builder_table input[type="url"],#pmcpc_campaign_builder_table input[type="date"],#pmcpc_campaign_builder_table input[type="time"],#pmcpc_campaign_builder_table input[type="datetime-local"],#pmcpc_campaign_builder_table input[type="number"],#pmcpc_campaign_builder_table select,#pmcpc_campaign_builder_table textarea{background:#fff !important;max-width:100%;}
        #pmcpc_campaign_builder_table input.regular-text,#pmcpc_campaign_builder_table textarea,#pmcpc_campaign_builder_table select:not([multiple]){width:min(100%,620px);}
        #pmcpc_campaign_builder_table input[type="number"]{width:auto;min-width:90px;}
        #pmcpc_campaign_builder_table select[multiple]{width:min(100%,420px);min-height:132px;max-width:100%;}
        #pmcpc_campaign_builder_table label{line-height:1.45;}
        #pmcpc_campaign_builder_table td > label:first-child{display:inline-flex;align-items:flex-start;gap:8px;max-width:100%;}
        #pmcpc_campaign_builder_table .button{vertical-align:middle;}
        .pmcpc-collapsible-settings{margin-top:14px;max-width:900px;border:1px solid #dcdcde;border-radius:10px;background:#fff;overflow:hidden;}
        .pmcpc-collapsible-settings summary{cursor:pointer;list-style:none;padding:14px 16px;font-weight:600;display:flex;align-items:center;justify-content:space-between;gap:12px;background:#fcfcfd;}
        .pmcpc-collapsible-settings summary::-webkit-details-marker{display:none;}
        .pmcpc-collapsible-settings summary::after{content:"▾";font-size:14px;color:#646970;flex:0 0 auto;}
        .pmcpc-collapsible-settings:not([open]) summary::after{content:"▸";}
        .pmcpc-collapsible-settings__body{padding:0 16px 16px;border-top:1px solid #f0f0f1;}
        .pmcpc-collapsible-settings__intro{margin:12px 0 8px;color:#646970;}
        #pmcpc_campaign_summary_text{line-height:1.55;}
        #pmcpc_reset_recommended{width:100%;}
        @media (max-width:1100px){.pmcpc-campaign-layout{flex-direction:column;}.pmcpc-campaign-layout .pmcpc-right{width:100%;position:static;}.pmcpc-stage-chip:not(:last-child)::after{display:none;}}
        @media (max-width:900px){#pmcpc_campaign_builder_table tbody.pmcpc-stage{padding:20px 20px 24px;}#pmcpc_campaign_builder_table tr{grid-template-columns:1fr;gap:8px;padding:14px 16px;}.pmcpc-stage-actions{flex-wrap:wrap;}.pmcpc-stage-badge{width:100%;margin-right:0;}}
        @media (max-width:782px){.pmcpc-campaign-page-actions--editor .button{width:100%;justify-content:center;}.pmcpc-stages{gap:8px;}#pmcpc_campaign_builder_table tbody.pmcpc-stage{padding:18px 16px 22px;}}
        </style>';


        echo '<div class="pmcpc-campaign-layout">';
        echo '<div class="pmcpc-left">';

        echo '<form method="post" id="pmcpc_campaign_form">';
        wp_nonce_field( 'pmcpc_save_campaign', 'pmcpc_save_campaign_nonce' );
        echo '<input type="hidden" name="campaign_id" value="' . esc_attr( $campaign->id ) . '">';
        // Stage chips (wizard-like navigation).
        // IMPORTANT: render as links as well as JS-driven chips so navigation still works if JS fails.
        $pmcpc_current_stage = isset( $_GET['pmcpc_stage'] ) ? max( 1, min( 6, absint( $_GET['pmcpc_stage'] ) ) ) : 1;
        $pmcpc_base_url = add_query_arg(
            array(
                'page'        => 'pmcpc_campaigns',
                'campaign_id' => (int) $campaign->id,
            ),
            admin_url( 'admin.php' )
        );

        echo '<div class="pmcpc-stages" role="navigation" aria-label="' . esc_attr__( 'Campaign builder stages', 'product-mailer-campaigns' ) . '">';
        echo '<a class="pmcpc-stage-chip" data-pmcpc-stage="1" href="' . esc_url( add_query_arg( 'pmcpc_stage', 1, $pmcpc_base_url ) ) . '" aria-current="' . ( 1 === $pmcpc_current_stage ? 'step' : 'false' ) . '"><span class="pmcpc-stage-num">1</span>' . esc_html__( 'Sending', 'product-mailer-campaigns' ) . '</a>';
        // Stage 2 is about what starts the campaign (manual/scheduled vs event-based triggers).
        echo '<a class="pmcpc-stage-chip" data-pmcpc-stage="2" href="' . esc_url( add_query_arg( 'pmcpc_stage', 2, $pmcpc_base_url ) ) . '" aria-current="' . ( 2 === $pmcpc_current_stage ? 'step' : 'false' ) . '"><span class="pmcpc-stage-num">2</span>' . esc_html__( 'Schedule / trigger', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="pmcpc-stage-chip" data-pmcpc-stage="3" href="' . esc_url( add_query_arg( 'pmcpc_stage', 3, $pmcpc_base_url ) ) . '" aria-current="' . ( 3 === $pmcpc_current_stage ? 'step' : 'false' ) . '"><span class="pmcpc-stage-num">3</span>' . esc_html__( 'Audience', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="pmcpc-stage-chip" data-pmcpc-stage="4" href="' . esc_url( add_query_arg( 'pmcpc_stage', 4, $pmcpc_base_url ) ) . '" aria-current="' . ( 4 === $pmcpc_current_stage ? 'step' : 'false' ) . '"><span class="pmcpc-stage-num">4</span>' . esc_html__( 'Product block', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="pmcpc-stage-chip" data-pmcpc-stage="5" href="' . esc_url( add_query_arg( 'pmcpc_stage', 5, $pmcpc_base_url ) ) . '" aria-current="' . ( 5 === $pmcpc_current_stage ? 'step' : 'false' ) . '"><span class="pmcpc-stage-num">5</span>' . esc_html__( 'Content', 'product-mailer-campaigns' ) . '</a>';
        echo '</div>';

        echo '<table class="form-table" id="pmcpc_campaign_builder_table">';
        echo '<tbody class="pmcpc-stage' . ( 1 === $pmcpc_current_stage ? ' is-active' : '' ) . '" data-stage="1">';
        echo '<tr><th colspan="2"><h3 class="pmcpc-stage-title">' . esc_html__( 'Sending details', 'product-mailer-campaigns' ) . '</h3><p class="pmcpc-stage-help">' . esc_html__( 'Start with the campaign basics that recipients see first: internal name, subject line, and sender details.', 'product-mailer-campaigns' ) . '</p></th></tr>';
        echo '<tr><th><label for="pmcpc_name">' . esc_html__( 'Name', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="name" type="text" id="pmcpc_name" class="regular-text" value="' . esc_attr( $campaign->name ) . '" required></td></tr>';
        echo '<tr><th><label for="pmcpc_subject">' . esc_html__( 'Subject', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="subject" type="text" id="pmcpc_subject" class="regular-text" value="' . esc_attr( $campaign->subject ) . '" required></td></tr>';

        // Campaign type picker removed (deprecated).
        echo '<tr><th><label for="pmcpc_from_name">' . esc_html__( 'From Name', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="from_name" type="text" id="pmcpc_from_name" class="regular-text" value="' . esc_attr( $campaign->from_name ) . '"></td></tr>';
        echo '<tr><th><label for="pmcpc_from_email">' . esc_html__( 'From Email', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td><input name="from_email" type="email" id="pmcpc_from_email" class="regular-text" value="' . esc_attr( $campaign->from_email ) . '"></td></tr>';

        echo '</tbody>';

        echo '<tbody class="pmcpc-stage' . ( 2 === $pmcpc_current_stage ? ' is-active' : '' ) . '" data-stage="2">';
        echo '<tr><th colspan="2"><h3 class="pmcpc-stage-title">' . esc_html__( 'Schedule / trigger', 'product-mailer-campaigns' ) . '</h3><p class="pmcpc-stage-help">' . esc_html__( 'Choose what starts this campaign. Send manually or on a schedule, or let an automation trigger it when an event happens.', 'product-mailer-campaigns' ) . '</p></th></tr>';

        // Trigger overview (keeps the mental model consistent: trigger starts the campaign, audience filters who qualifies).
        echo '<tr>';
        echo '<th>' . esc_html__( 'Trigger', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p class="description">' . esc_html__( 'Pick what starts this campaign. Manual/scheduled campaigns send only when you click Queue or choose a date/time. Automated triggers send when the selected event occurs (signup, order, etc).', 'product-mailer-campaigns' ) . '</p>';
        echo '</td>';
        echo '</tr>';

        // Automation trigger & delay.
        // Prefer the canonical stored trigger (newer versions), then fall back to legacy flags.
        $automation_trigger = ( isset( $campaign->automation_trigger ) && '' !== (string) $campaign->automation_trigger )
            ? sanitize_key( (string) $campaign->automation_trigger )
            : 'none';

        // Normalize older / Pro labels that may have been stored in the DB.
        // e.g. "new_customer_automation" should behave like the "new_customer" trigger.
        // IMPORTANT: keep trigger keys stable across UI, storage and dispatch.
        // Win-back is canonicalised to `customer_inactive` (not `inactive`) so it matches the
        // Automations page, dispatcher, and cron scan.
        $trigger_aliases = array(
            'welcome_automation'        => 'welcome',
            'new_subscriber_automation' => 'welcome',
            'new_customer_automation'   => 'new_customer',
            'post_purchase_automation'  => 'post_purchase',
            'vip_automation'            => 'high_value',
            'high_value_automation'     => 'high_value',
            'win_back_automation'       => 'customer_inactive',
            'inactive'                  => 'customer_inactive',
        );
        if ( isset( $trigger_aliases[ $automation_trigger ] ) ) {
            $automation_trigger = $trigger_aliases[ $automation_trigger ];
        }

		$trigger_delay = isset( $campaign->trigger_delay_minutes ) ? absint( $campaign->trigger_delay_minutes ) : 0;
		if ( 0 === $trigger_delay ) {
			$trigger_delay = isset( $campaign->broadcast_delay_minutes ) ? absint( $campaign->broadcast_delay_minutes ) : 0;
		}

        // Derive sensible defaults from legacy flags when editing older campaigns.
        if ( 'none' === $automation_trigger ) {
            if ( ! empty( $campaign->is_welcome ) ) {
                $automation_trigger = 'welcome';
                $trigger_delay      = isset( $campaign->welcome_delay_minutes ) ? absint( $campaign->welcome_delay_minutes ) : $trigger_delay;
            } elseif ( ! empty( $campaign->is_post_purchase ) ) {
                $automation_trigger = 'post_purchase';
                $trigger_delay      = isset( $campaign->post_purchase_delay_minutes ) ? absint( $campaign->post_purchase_delay_minutes ) : $trigger_delay;
            }
        }


// If no trigger stored yet and a trigger is present in the URL,
        // use that as the default to make Automations/Segments shortcuts preselect it.
        if ( 'none' === $automation_trigger && isset( $_GET['trigger'] ) ) {
            $from_url = sanitize_text_field( (string) wp_unslash( $_GET['trigger'] ) );
            switch ( $from_url ) {
                case 'new_subscriber':
                    $automation_trigger = 'welcome';
                    break;
                case 'new_customer':
                    // WooCommerce trigger: first completed order for a customer.
                    if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
                        $automation_trigger = 'new_customer';
                    }
                    break;
                case 'post_purchase':
                    if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
                        $automation_trigger = 'post_purchase';
                    }
                    break;
                case 'review_request':
                    if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
                        $automation_trigger = 'review_request';
                    }
                    break;
                case 'customer_inactive':
                    if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
                        $automation_trigger = 'customer_inactive';
                    }
                    break;
                case 'high_value':
                    if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
                        $automation_trigger = 'high_value';
                    }
                    break;
				case 'repeat_customer':
					if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
						$automation_trigger = 'repeat_customer';
					}
					break;
				case 'vip_customer':
					if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
						$automation_trigger = 'vip_customer';
					}
					break;
                case 'abandoned_cart_step_1':
                case 'abandoned_cart_step_2':
                case 'abandoned_cart_step_3':
                    if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
                        $automation_trigger = sanitize_key( $from_url );
                    }
                    break;
                case 'lead_magnet_download':
                case 'subscriber_inactive':
                case 'subscriber_anniversary':
                case 'subscriber_birthday':
                    $automation_trigger = sanitize_key( $from_url );
                    break;
                case 'date':
                    // Back-compat: old "date" trigger is now the default manual/scheduled option.
                    $automation_trigger = 'none';
                    break;
            }
        }

        // Existing abandoned-cart starter campaigns may have been created with
        // a zero delay. Show the staggered defaults in the editor so the three-step
        // sequence does not appear as if every email should send at once.
        if ( 0 === (int) $trigger_delay && class_exists( 'PMCPC_Abandoned_Carts' ) ) {
            if ( 'abandoned_cart_step_1' === $automation_trigger ) {
                $trigger_delay = (int) PMCPC_Abandoned_Carts::get_recovery_delay_minutes_for_step( 1 );
            } elseif ( 'abandoned_cart_step_2' === $automation_trigger ) {
                $trigger_delay = (int) PMCPC_Abandoned_Carts::get_recovery_delay_minutes_for_step( 2 );
            } elseif ( 'abandoned_cart_step_3' === $automation_trigger ) {
                $trigger_delay = (int) PMCPC_Abandoned_Carts::get_recovery_delay_minutes_for_step( 3 );
            }
        }

        $has_wc     = class_exists( 'WooCommerce' );
        $wc_enabled = function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled();
        $hide_paid_features = function_exists( 'pmcpc_should_hide_paid_features' ) && pmcpc_should_hide_paid_features();

        echo '<tr><th><label for="pmcpc_automation_trigger">' . esc_html__( 'Send trigger', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<select name="automation_trigger" id="pmcpc_automation_trigger">';
        echo '<option value="none"' . selected( 'none', $automation_trigger, false ) . '>' . esc_html__( 'Manual or scheduled (not automated)', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="welcome"' . selected( 'welcome', $automation_trigger, false ) . '>' . esc_html__( 'Welcome (new subscribers)', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="welcome_follow_up"' . selected( 'welcome_follow_up', $automation_trigger, false ) . '>' . esc_html__( 'Welcome follow-up', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="lead_magnet_download"' . selected( 'lead_magnet_download', $automation_trigger, false ) . '>' . esc_html__( 'Lead magnet delivery', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="subscriber_inactive"' . selected( 'subscriber_inactive', $automation_trigger, false ) . '>' . esc_html__( 'Subscriber inactive', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="subscriber_anniversary"' . selected( 'subscriber_anniversary', $automation_trigger, false ) . '>' . esc_html__( 'Subscriber anniversary', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="subscriber_birthday"' . selected( 'subscriber_birthday', $automation_trigger, false ) . '>' . esc_html__( 'Subscriber birthday', 'product-mailer-campaigns' ) . '</option>';
        // WooCommerce triggers are only available when WooCommerce is installed AND
        // the WooCommerce automation layer is enabled (trial/license).
        if ( $hide_paid_features ) {
            // Paid WooCommerce triggers are hidden in free-mode compact view.
        } elseif ( ! $has_wc ) {
            echo '<option value="post_purchase" disabled' . selected( 'post_purchase', $automation_trigger, false ) . '>' . esc_html__( 'Post-purchase (after WooCommerce order) — Install WooCommerce', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="new_customer" disabled' . selected( 'new_customer', $automation_trigger, false ) . '>' . esc_html__( 'New customer (first WooCommerce order) — Install WooCommerce', 'product-mailer-campaigns' ) . '</option>';
			echo '<option value="repeat_customer" disabled' . selected( 'repeat_customer', $automation_trigger, false ) . '>' . esc_html__( 'Repeat customer (2+ orders) — Install WooCommerce', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="high_value" disabled' . selected( 'high_value', $automation_trigger, false ) . '>' . esc_html__( 'High-value customer (crosses threshold) — Install WooCommerce', 'product-mailer-campaigns' ) . '</option>';
			echo '<option value="vip_customer" disabled' . selected( 'vip_customer', $automation_trigger, false ) . '>' . esc_html__( 'VIP customer (crosses VIP threshold) — Install WooCommerce', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="customer_inactive" disabled' . selected( 'customer_inactive', $automation_trigger, false ) . '>' . esc_html__( 'Customer inactive / win-back — Install WooCommerce', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="lapsed_high_value_customer" disabled' . selected( 'lapsed_high_value_customer', $automation_trigger, false ) . '>' . esc_html__( 'Lapsed high-value customer - Install WooCommerce', 'product-mailer-campaigns' ) . '</option>';
        } elseif ( ! $wc_enabled ) {
            echo '<option value="post_purchase" disabled' . selected( 'post_purchase', $automation_trigger, false ) . '>' . esc_html__( 'Post-purchase (after WooCommerce order) — Requires activation', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="new_customer" disabled' . selected( 'new_customer', $automation_trigger, false ) . '>' . esc_html__( 'New customer (first WooCommerce order) — Requires activation', 'product-mailer-campaigns' ) . '</option>';
			echo '<option value="repeat_customer" disabled' . selected( 'repeat_customer', $automation_trigger, false ) . '>' . esc_html__( 'Repeat customer (2+ orders) — Requires activation', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="high_value" disabled' . selected( 'high_value', $automation_trigger, false ) . '>' . esc_html__( 'High-value customer (crosses threshold) — Requires activation', 'product-mailer-campaigns' ) . '</option>';
			echo '<option value="vip_customer" disabled' . selected( 'vip_customer', $automation_trigger, false ) . '>' . esc_html__( 'VIP customer (crosses VIP threshold) — Requires activation', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="customer_inactive" disabled' . selected( 'customer_inactive', $automation_trigger, false ) . '>' . esc_html__( 'Customer inactive / win-back — Requires activation', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="lapsed_high_value_customer" disabled' . selected( 'lapsed_high_value_customer', $automation_trigger, false ) . '>' . esc_html__( 'Lapsed high-value customer - Requires activation', 'product-mailer-campaigns' ) . '</option>';
        } else {
            $high_value_threshold_label = class_exists( 'PMCPC_Settings' ) ? self::get_plain_price_preview_text( PMCPC_Settings::get( 'lifecycle_high_value_threshold', '0' ) ) : '';
            $vip_threshold_label        = class_exists( 'PMCPC_Settings' ) ? self::get_plain_price_preview_text( PMCPC_Settings::get( 'lifecycle_vip_threshold', '0' ) ) : '';
            $high_value_option_label    = $high_value_threshold_label ? sprintf( __( 'High-value customer (≥ %s lifetime spend)', 'product-mailer-campaigns' ), $high_value_threshold_label ) : __( 'High-value customer (crosses threshold)', 'product-mailer-campaigns' );
            $vip_value_option_label     = $vip_threshold_label ? sprintf( __( 'VIP customer (≥ %s lifetime spend)', 'product-mailer-campaigns' ), $vip_threshold_label ) : __( 'VIP customer (crosses VIP threshold)', 'product-mailer-campaigns' );
            echo '<option value="post_purchase"' . selected( 'post_purchase', $automation_trigger, false ) . '>' . esc_html__( 'Post-purchase (after WooCommerce order)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="new_customer"' . selected( 'new_customer', $automation_trigger, false ) . '>' . esc_html__( 'New customer (first WooCommerce order)', 'product-mailer-campaigns' ) . '</option>';
			echo '<option value="repeat_customer"' . selected( 'repeat_customer', $automation_trigger, false ) . '>' . esc_html__( 'Repeat customer (2+ orders)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="high_value"' . selected( 'high_value', $automation_trigger, false ) . '>' . esc_html( $high_value_option_label ) . '</option>';
			echo '<option value="vip_customer"' . selected( 'vip_customer', $automation_trigger, false ) . '>' . esc_html( $vip_value_option_label ) . '</option>';
            echo '<option value="customer_inactive"' . selected( 'customer_inactive', $automation_trigger, false ) . '>' . esc_html__( 'Customer inactive / win-back', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="lapsed_high_value_customer"' . selected( 'lapsed_high_value_customer', $automation_trigger, false ) . '>' . esc_html__( 'Lapsed high-value customer', 'product-mailer-campaigns' ) . '</option>';

            echo '<option value="review_request"' . selected( 'review_request', $automation_trigger, false ) . '>' . esc_html__( 'Review request (after purchase)', 'product-mailer-campaigns' ) . '</option>';

            // Abandoned cart recovery (3-step triggers).
            echo '<option value="abandoned_cart_step_1"' . selected( 'abandoned_cart_step_1', $automation_trigger, false ) . '>' . esc_html__( 'Abandoned cart (Step 1)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="abandoned_cart_step_2"' . selected( 'abandoned_cart_step_2', $automation_trigger, false ) . '>' . esc_html__( 'Abandoned cart (Step 2)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="abandoned_cart_step_3"' . selected( 'abandoned_cart_step_3', $automation_trigger, false ) . '>' . esc_html__( 'Abandoned cart (Step 3)', 'product-mailer-campaigns' ) . '</option>';
        }


        echo '</select>';
        // Trigger-specific helper line (filled by JS).
        echo '<p class="description" id="pmcpc_trigger_explain" style="margin-top:6px"></p>';
        echo '<p class="description">' . esc_html( $hide_paid_features ? __( 'Manual/scheduled campaigns only send when you click Queue or choose a date/time below. Automated triggers send when the selected event occurs.', 'product-mailer-campaigns' ) : __( 'Manual/scheduled campaigns only send when you click Queue or choose a date/time below. Automated triggers send when the selected event occurs (signup, order, etc). WooCommerce triggers require WooCommerce Automation activation.', 'product-mailer-campaigns' ) ) . '</p>';

        if ( ! $hide_paid_features && $has_wc && ! $wc_enabled ) {
            $trial_url = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );
            $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
            echo '<p style="margin:10px 0 0;">'
                . '<a class="button button-primary" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Start free WooCommerce automation trial', 'product-mailer-campaigns' ) . '</a> '
                . '<a class="button" href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Activate license', 'product-mailer-campaigns' ) . '</a>'
                . '</p>';
        }
        echo '</td></tr>';

        // Unified trigger delay.
        echo '<tr><th><label for="pmcpc_trigger_delay_minutes">' . esc_html__( 'Delay after trigger (minutes)', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        echo '<input name="trigger_delay_minutes" type="number" id="pmcpc_trigger_delay_minutes" min="0" step="1" value="' . esc_attr( $trigger_delay ) . '" style="width:80px;">';
        echo '<p class="description">' . esc_html__( 'Wait time after the trigger (signup, order, or manual queue) before queuing this email. Use 0 to send immediately.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        $subscriber_updates_open = ( 1 === (int) $subscriber_page_enabled )
            || '' !== trim( (string) $subscriber_page_title )
            || '' !== trim( (string) $subscriber_page_excerpt )
            || '' !== trim( (string) $subscriber_page_topic )
            || '' !== trim( (string) $subscriber_page_post_status )
            || ! empty( $subscriber_page_featured )
            || '' !== trim( (string) $subscriber_page_image_url )
            || '' !== trim( (string) $subscriber_page_cta_label )
            || '' !== trim( (string) $subscriber_page_cta_url )
            || 'public' !== (string) $subscriber_page_visibility
            || '' !== trim( (string) $subscriber_page_segment )
            || '' !== trim( (string) $subscriber_page_expires_at )
            || '' !== trim( (string) $subscriber_page_content );

        echo '<tr><th>' . esc_html__( 'Subscriber Updates page', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="publish_to_subscriber_page" value="1" ' . checked( 1, $subscriber_page_enabled, false ) . '> ' . esc_html__( 'Also publish this campaign to the public Subscriber Updates page when it sends.', 'product-mailer-campaigns' ) . '</label>';
        echo '<p class="description">' . esc_html__( 'On the first successful send, the plugin will create or use your configured Subscriber Updates page. Automated campaigns are de-duplicated to one update per campaign per day.', 'product-mailer-campaigns' ) . '<br>' . esc_html__( 'Tip: if you fill any Website fields below, publishing is automatically enabled when you save.', 'product-mailer-campaigns' ) . '</p>';
        echo '<details class="pmcpc-collapsible-settings"' . ( $subscriber_updates_open ? ' open' : '' ) . '>';
        echo '<summary>' . esc_html__( 'Subscriber Updates settings', 'product-mailer-campaigns' ) . '</summary>';
        echo '<div class="pmcpc-collapsible-settings__body">';
        echo '<p class="pmcpc-collapsible-settings__intro">' . esc_html__( 'Use these options only when you want the email to also create or update the public Subscriber Updates website entry.', 'product-mailer-campaigns' ) . '</p>';
        echo '<input type="hidden" name="subscriber_page_settings_present" value="1">';
        echo '<input type="hidden" id="pmcpc_subscriber_page_payload" name="subscriber_page_payload" value="">';
        echo '<p><label for="pmcpc_subscriber_page_title"><strong>' . esc_html__( 'Website title override', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<input type="text" class="regular-text" style="width:100%;max-width:640px;" id="pmcpc_subscriber_page_title" name="subscriber_page_title" value="' . esc_attr( $subscriber_page_title ) . '" placeholder="' . esc_attr__( 'Leave blank to use the campaign subject', 'product-mailer-campaigns' ) . '"></p>';
        echo '<p><label for="pmcpc_subscriber_page_excerpt"><strong>' . esc_html__( 'Website excerpt override', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<textarea id="pmcpc_subscriber_page_excerpt" name="subscriber_page_excerpt" rows="3" style="width:100%;max-width:640px;">' . esc_textarea( $subscriber_page_excerpt ) . '</textarea></p>';
        echo '<p><label for="pmcpc_subscriber_page_topic"><strong>' . esc_html__( 'Website topic', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<input type="text" class="regular-text" id="pmcpc_subscriber_page_topic" name="subscriber_page_topic" value="' . esc_attr( $subscriber_page_topic ) . '" placeholder="' . esc_attr__( 'Example: New arrivals, VIP offers, Care guides', 'product-mailer-campaigns' ) . '" style="width:100%;max-width:320px;"></p>';
        echo '<p><label for="pmcpc_subscriber_page_post_status"><strong>' . esc_html__( 'Website post status', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<select id="pmcpc_subscriber_page_post_status" name="subscriber_page_post_status">';
        echo '<option value=""' . selected( '', $subscriber_page_post_status, false ) . '>' . esc_html__( 'Use global default', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="publish"' . selected( 'publish', $subscriber_page_post_status, false ) . '>' . esc_html__( 'Publish', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="draft"' . selected( 'draft', $subscriber_page_post_status, false ) . '>' . esc_html__( 'Draft', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="private"' . selected( 'private', $subscriber_page_post_status, false ) . '>' . esc_html__( 'Private', 'product-mailer-campaigns' ) . '</option>';
        echo '</select></p>';
        echo '<p><label><input type="checkbox" name="subscriber_page_featured" value="1" ' . checked( 1, $subscriber_page_featured, false ) . '> ' . esc_html__( 'Mark this website update as featured.', 'product-mailer-campaigns' ) . '</label></p>';
        echo '<p><label for="pmcpc_subscriber_page_image_url"><strong>' . esc_html__( 'Feature image URL', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<input type="url" class="regular-text" style="width:100%;max-width:760px;" id="pmcpc_subscriber_page_image_url" name="subscriber_page_image_url" value="' . esc_attr( $subscriber_page_image_url ) . '" placeholder="' . esc_attr__( 'https://example.com/image.jpg', 'product-mailer-campaigns' ) . '">';
        echo '<br><span class="description">' . esc_html__( 'Optional large image shown on the feed card and single update page.', 'product-mailer-campaigns' ) . '</span></p>';
        echo '<p><label for="pmcpc_subscriber_page_cta_label"><strong>' . esc_html__( 'CTA button label', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<input type="text" class="regular-text" style="width:100%;max-width:320px;" id="pmcpc_subscriber_page_cta_label" name="subscriber_page_cta_label" value="' . esc_attr( $subscriber_page_cta_label ) . '" placeholder="' . esc_attr__( 'Shop now', 'product-mailer-campaigns' ) . '"></p>';
        echo '<p><label for="pmcpc_subscriber_page_cta_url"><strong>' . esc_html__( 'CTA button URL', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<input type="url" class="regular-text" style="width:100%;max-width:760px;" id="pmcpc_subscriber_page_cta_url" name="subscriber_page_cta_url" value="' . esc_attr( $subscriber_page_cta_url ) . '" placeholder="' . esc_attr__( 'https://example.com/collection', 'product-mailer-campaigns' ) . '"></p>';
        echo '<p><label for="pmcpc_subscriber_page_visibility"><strong>' . esc_html__( 'Website visibility', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<select id="pmcpc_subscriber_page_visibility" name="subscriber_page_visibility">';
        echo '<option value="public"' . selected( 'public', $subscriber_page_visibility, false ) . '>' . esc_html__( 'Public', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="subscribers"' . selected( 'subscribers', $subscriber_page_visibility, false ) . '>' . esc_html__( 'Subscribers only', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="segment"' . selected( 'segment', $subscriber_page_visibility, false ) . '>' . esc_html__( 'Subscriber segment only', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="private"' . selected( 'private', $subscriber_page_visibility, false ) . '>' . esc_html__( 'Private (admins only)', 'product-mailer-campaigns' ) . '</option>';
        echo '</select><br><span class="description">' . esc_html__( 'Choose who can view the full update on the website.', 'product-mailer-campaigns' ) . '</span></p>';
        echo '<p><label for="pmcpc_subscriber_page_segment"><strong>' . esc_html__( 'Required subscriber segment tag', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<input type="text" class="regular-text" style="width:100%;max-width:320px;" id="pmcpc_subscriber_page_segment" name="subscriber_page_segment" value="' . esc_attr( $subscriber_page_segment ) . '" placeholder="' . esc_attr__( 'Example: VIP, trade, showroom', 'product-mailer-campaigns' ) . '">';
        echo '<br><span class="description">' . esc_html__( 'Used only when visibility is set to Subscriber segment only. Match this to an existing subscriber preference tag.', 'product-mailer-campaigns' ) . '</span></p>';
        echo '<p><label for="pmcpc_subscriber_page_expires_at"><strong>' . esc_html__( 'Expiry date/time', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<input type="datetime-local" class="regular-text" style="width:100%;max-width:320px;" id="pmcpc_subscriber_page_expires_at" name="subscriber_page_expires_at" value="' . esc_attr( $subscriber_page_expires_at ) . '">';
        echo '<br><span class="description">' . esc_html__( 'Optional. After this date/time the update is hidden from the feed and the single page shows an expired message.', 'product-mailer-campaigns' ) . '</span></p>';
        echo '<p><label for="pmcpc_subscriber_page_content"><strong>' . esc_html__( 'Website content override', 'product-mailer-campaigns' ) . '</strong></label><br>';
        echo '<textarea id="pmcpc_subscriber_page_content" name="subscriber_page_content" rows="8" style="width:100%;max-width:760px;">' . esc_textarea( $subscriber_page_content ) . '</textarea>';
        echo '<br><span class="description">' . esc_html__( 'Leave blank to publish the rendered campaign content. Use this when your website version should read differently from the email version.', 'product-mailer-campaigns' ) . '</span></p>';
        echo '</div>';
        echo '</details>';
        echo '</td></tr>';

        // Scheduling options.
        echo '<tr><th>' . esc_html__( 'Schedule (manual/scheduled only)', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p>';
        echo '<label for="pmcpc_schedule_type">' . esc_html__( 'Send type', 'product-mailer-campaigns' ) . ' </label>';
        echo '<select name="schedule_type" id="pmcpc_schedule_type">';
        echo '<option value="manual" ' . selected( 'manual', $schedule_type, false ) . '>' . esc_html__( 'Manual (queue when you click)', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="one_time" ' . selected( 'one_time', $schedule_type, false ) . '>' . esc_html__( 'One-time at specific date/time', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="recurring" ' . selected( 'recurring', $schedule_type, false ) . '>' . esc_html__( 'Recurring', 'product-mailer-campaigns' ) . '</option>';
        echo '</select>';
        echo '</p>';

        echo '<p>';
        echo '<label>' . esc_html__( 'Start date', 'product-mailer-campaigns' ) . ' ';
        echo '<input type="date" id="pmcpc_schedule_date" name="schedule_date" value="' . esc_attr( $schedule_date ) . '">';
        echo '</label> ';
        echo '<label>' . esc_html__( 'Time', 'product-mailer-campaigns' ) . ' ';
        echo '<input type="time" id="pmcpc_schedule_time" name="schedule_time" value="' . esc_attr( $schedule_time ) . '">';
        echo '</label>';
        echo '</p>';

        echo '<p>';
        echo '<label for="pmcpc_schedule_frequency">' . esc_html__( 'Frequency', 'product-mailer-campaigns' ) . ' </label>';
        echo '<select name="schedule_frequency" id="pmcpc_schedule_frequency">';
        echo '<option value="">' . esc_html__( 'None (one-time)', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="daily" ' . selected( 'daily', $campaign->schedule_frequency, false ) . '>' . esc_html__( 'Daily', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="weekly" ' . selected( 'weekly', $campaign->schedule_frequency, false ) . '>' . esc_html__( 'Weekly', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="monthly" ' . selected( 'monthly', $campaign->schedule_frequency, false ) . '>' . esc_html__( 'Monthly', 'product-mailer-campaigns' ) . '</option>';
        echo '</select>';
        echo '</p>';
        echo '<p class="description">' . esc_html__( 'Scheduling is only used for manual newsletters and broadcasts. For scheduled/recurring campaigns, the system will automatically queue emails around the chosen date/time and frequency.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '</tbody>';

        echo '<tbody class="pmcpc-stage' . ( 3 === $pmcpc_current_stage ? ' is-active' : '' ) . '" data-stage="3">';
        echo '<tr><th colspan="2"><h3 class="pmcpc-stage-title">' . esc_html__( 'Audience', 'product-mailer-campaigns' ) . '</h3><p class="pmcpc-stage-help">' . esc_html__( 'Choose who should receive this campaign using tags, source or lifecycle filters, and Commerce segments when available.', 'product-mailer-campaigns' ) . '</p></th></tr>';


        // Advanced audience toggle (keeps the default “All subscribers” path simple).
        // If any advanced filters are already set, default the toggle to ON so existing settings are visible.
        $pmcpc_adv_on = false;
        if ( ! empty( $campaign->target_tag ) || ! empty( $campaign->exclude_tags ) || ! empty( $campaign->target_source_tags ) || ! empty( $campaign->target_origin_tags ) || ! empty( $campaign->target_lifecycle_tags ) ) {
            $pmcpc_adv_on = true;
        }
        echo '<tr><th>' . esc_html__( 'Refine audience (optional)', 'product-mailer-campaigns' ) . '</th>';
        echo '<td><label><input type="checkbox" id="pmcpc_show_audience_advanced" value="1" ' . checked( $pmcpc_adv_on, true, false ) . '> ' . esc_html__( 'Show audience filters', 'product-mailer-campaigns' ) . '</label>';
        echo '<p class="description">' . esc_html__( 'Leave this off to target all subscribers (default). Turn it on to narrow who qualifies.', 'product-mailer-campaigns' ) . '</p></td></tr>';

        
// Build tag suggestions for user-facing tags (Interest + Preference) and system tags (Source/Lifecycle).
$tag_catalogs = array();
if ( class_exists( 'PMCPC_Subscriber_Manager' ) ) {
    // get_tag_catalogs() is protected; use a safe reflection-based access.
    try {
        $ref = new ReflectionClass( 'PMCPC_Subscriber_Manager' );
        if ( $ref->hasMethod( 'get_tag_catalogs' ) ) {
            $mth = $ref->getMethod( 'get_tag_catalogs' );
            $mth->setAccessible( true );
            $tag_catalogs = (array) $mth->invoke( null );
        }
    } catch ( Exception $e ) {
        $tag_catalogs = array();
    }
}
$interest_catalog   = isset( $tag_catalogs['interest'] ) ? (array) $tag_catalogs['interest'] : array();
$source_catalog     = isset( $tag_catalogs['source'] ) ? (array) $tag_catalogs['source'] : array();
$lifecycle_catalog  = isset( $tag_catalogs['lifecycle'] ) ? (array) $tag_catalogs['lifecycle'] : array();
$health_catalog     = isset( $tag_catalogs['health'] ) ? (array) $tag_catalogs['health'] : array();

// Discover additional user-facing tags from the database (manual preferences, custom interest tags, etc).
$user_facing_tags = array();
if ( isset( $wpdb ) ) {
    $tags_table = $wpdb->prefix . 'pmcpc_subscriber_tags';
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $raw_tags = $wpdb->get_col( "SELECT DISTINCT tag FROM {$tags_table} ORDER BY tag ASC" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
    $raw_tags = is_array( $raw_tags ) ? $raw_tags : array();
    foreach ( $raw_tags as $raw_tag ) {
        $t = sanitize_text_field( (string) $raw_tag );
        if ( '' === $t ) {
            continue;
        }
        if ( 0 === strpos( $t, 'origin:' ) || 0 === strpos( $t, 'form-' ) || 0 === strpos( $t, 'health:' ) ) {
            continue;
        }
        if ( in_array( $t, $source_catalog, true ) || in_array( $t, $lifecycle_catalog, true ) || in_array( $t, $health_catalog, true ) ) {
            continue;
        }
        $user_facing_tags[] = $t;
    }
}
$user_facing_tags = array_values( array_unique( array_filter( $user_facing_tags ) ) );

// Compose suggestion lists.
$tag_suggestions       = array_values( array_unique( array_merge( $interest_catalog, $user_facing_tags ) ) );
sort( $tag_suggestions );
$source_suggestions    = array_values( array_unique( array_filter( $source_catalog ) ) );
sort( $source_suggestions );
$lifecycle_suggestions = array_values( array_unique( array_filter( $lifecycle_catalog ) ) );
sort( $lifecycle_suggestions );

// Origin tags (technical audit trail). Discovered from existing subscriber tags with prefix "origin:".
$origin_suggestions = array();
if ( isset( $wpdb ) ) {
    $origin_like = $wpdb->esc_like( 'origin:' ) . '%';
    $tags_table  = $wpdb->prefix . 'pmcpc_subscriber_tags';
    $cache_key   = 'pmcpc_origin_tags_' . get_current_blog_id();
    $origin_rows = wp_cache_get( $cache_key, 'pmcpc' );
    if ( false === $origin_rows ) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        $origin_rows = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT tag FROM {$tags_table} WHERE tag LIKE %s ORDER BY tag ASC",
                $origin_like
            )
        );
        wp_cache_set( $cache_key, $origin_rows, 'pmcpc', 300 );
    }
    if ( ! empty( $origin_rows ) && is_array( $origin_rows ) ) {
        foreach ( $origin_rows as $ot ) {
            $ot = sanitize_text_field( (string) $ot );
            if ( '' === $ot ) { continue; }
            // Display without the "origin:" prefix to match the Subscribers table.
            if ( 0 === strpos( $ot, 'origin:' ) ) {
                $origin_suggestions[] = substr( $ot, 7 );
            } else {
                $origin_suggestions[] = $ot;
            }
        }
    }
}
$origin_suggestions = array_values( array_unique( array_filter( $origin_suggestions ) ) );
sort( $origin_suggestions );



// Interest / Preference tags (user-facing segmentation).
echo '<tr class="pmcpc-audience-advanced"' . ( $pmcpc_adv_on ? '' : ' style="display:none"' ) . '><th><label for="pmcpc_target_tag">' . esc_html__( 'Interest tags', 'product-mailer-campaigns' ) . '</label></th>';
echo '<td><input name="target_tag" type="text" id="pmcpc_target_tag" class="regular-text" list="pmcpc_tag_suggest" value="' . esc_attr( $campaign->target_tag ) . '">';
echo '<datalist id="pmcpc_tag_suggest">';
foreach ( $tag_suggestions as $ts ) {
    echo '<option value="' . esc_attr( $ts ) . '"></option>';
}
echo '</datalist>';
echo '<p class="description">' . esc_html__( 'Optional. Comma-separated list of user-facing tags. Matches subscriber Interest tags. You can add your own tags beyond the defaults.', 'product-mailer-campaigns' ) . '</p></td></tr>';

// Exclude tags (user-facing).
echo '<tr class="pmcpc-audience-advanced"' . ( $pmcpc_adv_on ? '' : ' style="display:none"' ) . '><th><label for="pmcpc_exclude_tags">' . esc_html__( 'Exclude interest tags', 'product-mailer-campaigns' ) . '</label></th>';
echo '<td><input name="exclude_tags" type="text" id="pmcpc_exclude_tags" class="regular-text" list="pmcpc_tag_suggest" value="' . esc_attr( isset( $campaign->exclude_tags ) ? $campaign->exclude_tags : '' ) . '">';
echo '<p class="description">' . esc_html__( 'Optional. Subscribers with any of these Interest tags will be excluded.', 'product-mailer-campaigns' ) . '</p></td></tr>';

// Source tags (system-managed).
// IMPORTANT: Use a single-select (like the Subscribers table filters). Multi-select requires
// ctrl/cmd and was frequently misunderstood; it also made saving feel unreliable.
// We still store as CSV for back-compat, but in practice this will be 0/1 values.
$saved_sources = isset( $campaign->target_source_tags ) ? (string) $campaign->target_source_tags : '';
$saved_sources_arr = array_filter( array_map( 'trim', explode( ',', $saved_sources ) ) );
echo '<tr class="pmcpc-audience-advanced"' . ( $pmcpc_adv_on ? '' : ' style="display:none"' ) . '><th><label for="pmcpc_target_source_tags_select">' . esc_html__( 'Source tags', 'product-mailer-campaigns' ) . '</label></th>';
echo '<td>';
echo '<select id="pmcpc_target_source_tags_select" name="target_source_tags_arr" style="min-width: 320px; max-width: 520px;">';
echo '<option value="">' . esc_html__( 'Any', 'product-mailer-campaigns' ) . '</option>';
foreach ( $source_suggestions as $ss ) {
    echo '<option value="' . esc_attr( $ss ) . '"' . selected( in_array( $ss, $saved_sources_arr, true ), true, false ) . '>' . esc_html( $ss ) . '</option>';
}
echo '</select>';
echo '<input name="target_source_tags" type="hidden" id="pmcpc_target_source_tags" value="' . esc_attr( $saved_sources ) . '">';
echo '<p class="description">' . esc_html__( 'Optional. Filter by acquisition source (how they joined). These are system-managed tags.', 'product-mailer-campaigns' ) . '</p>';
echo '</td></tr>';


// Origin tags (system-managed audit trail). Single-select (matches Subscribers UI). Stored as CSV for back-compat.
$saved_origin = isset( $campaign->target_origin_tags ) ? (string) $campaign->target_origin_tags : '';
$saved_origin_arr = array_filter( array_map( 'trim', explode( ',', $saved_origin ) ) );
echo '<tr class="pmcpc-audience-advanced"' . ( $pmcpc_adv_on ? '' : ' style="display:none"' ) . '><th><label for="pmcpc_target_origin_tags_select">' . esc_html__( 'Origin', 'product-mailer-campaigns' ) . '</label></th>';
echo '<td>';
echo '<select id="pmcpc_target_origin_tags_select" name="target_origin_tags_arr" style="min-width: 320px; max-width: 520px;">';
echo '<option value="">' . esc_html__( 'Any', 'product-mailer-campaigns' ) . '</option>';
foreach ( $origin_suggestions as $os ) {
    echo '<option value="' . esc_attr( $os ) . '"' . selected( in_array( $os, $saved_origin_arr, true ), true, false ) . '>' . esc_html( $os ) . '</option>';
}
echo '</select>';
echo '<input name="target_origin_tags" type="hidden" id="pmcpc_target_origin_tags" value="' . esc_attr( $saved_origin ) . '">';
echo '<p class="description">' . esc_html__( 'Optional. Filter by Origin (technical audit trail). Stored internally as origin:* tags (shown here without the prefix), matching the Subscribers table.', 'product-mailer-campaigns' ) . '</p>';
echo '</td></tr>';


// Lifecycle tags (system-managed). Single-select (matches Subscribers UI). Stored as CSV for back-compat.
$saved_lifecycle = isset( $campaign->target_lifecycle_tags ) ? (string) $campaign->target_lifecycle_tags : '';
$saved_lifecycle_arr = array_filter( array_map( 'trim', explode( ',', $saved_lifecycle ) ) );
echo '<tr class="pmcpc-audience-advanced"' . ( $pmcpc_adv_on ? '' : ' style="display:none"' ) . '><th><label for="pmcpc_target_lifecycle_tags_select">' . esc_html__( 'Lifecycle tags', 'product-mailer-campaigns' ) . '</label></th>';
echo '<td>';
echo '<select id="pmcpc_target_lifecycle_tags_select" name="target_lifecycle_tags_arr" style="min-width: 320px; max-width: 520px;">';
echo '<option value="">' . esc_html__( 'Any', 'product-mailer-campaigns' ) . '</option>';
foreach ( $lifecycle_suggestions as $ls ) {
    echo '<option value="' . esc_attr( $ls ) . '"' . selected( in_array( $ls, $saved_lifecycle_arr, true ), true, false ) . '>' . esc_html( $ls ) . '</option>';
}
echo '</select>';
echo '<input name="target_lifecycle_tags" type="hidden" id="pmcpc_target_lifecycle_tags" value="' . esc_attr( $saved_lifecycle ) . '">';
echo '<p class="description">' . esc_html__( 'Optional. Filter by lifecycle (customer stage). These are system-managed tags.', 'product-mailer-campaigns' ) . '</p>';
echo '</td></tr>';

// Recipient segment (Pro).
// This is an optional eligibility filter applied *when the trigger fires* (automations)
// or when you queue a manual/scheduled broadcast.
if ( ! $hide_paid_features ) {
        // This is an optional eligibility filter applied *when the trigger fires* (automations)
        // or when you queue a manual/scheduled broadcast.
        echo '<tr><th><label for="pmcpc_recipient_segment">' . esc_html__( 'Eligibility (optional)', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
            // Start with the value saved on the campaign, if any.
            $segment_value = isset( $campaign->pro_segment_key ) ? $campaign->pro_segment_key : '';

            // If nothing is saved yet and a pro_segment_key is present in the URL,
            // use that as the default. This allows "Create campaign" or "Set up"
            // links from Pro pages to preselect a segment here.
            if ( empty( $segment_value ) && isset( $_GET['pro_segment_key'] ) ) {
                $allowed_segments = array( '', 'customers', 'new_customers', 'repeat_customers', 'recent', 'high_value', 'vip', 'lapsed' );
                $from_url         = sanitize_text_field( (string) wp_unslash( $_GET['pro_segment_key'] ) );
                if ( in_array( $from_url, $allowed_segments, true ) ) {
                    $segment_value = $from_url;
                }
            }

            echo '<select name="pro_segment_key" id="pmcpc_recipient_segment">';
            echo '<option value="">' . esc_html__( 'All subscribers (default)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="customers"' . selected( 'customers', $segment_value, false ) . '>' . esc_html__( 'Customers (at least one order)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="new_customers"' . selected( 'new_customers', $segment_value, false ) . '>' . esc_html__( 'New customers (first order only)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="repeat_customers"' . selected( 'repeat_customers', $segment_value, false ) . '>' . esc_html__( 'Repeat customers (2+ orders)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="recent"' . selected( 'recent', $segment_value, false ) . '>' . esc_html__( 'Recent customers (last 30 days)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="high_value"' . selected( 'high_value', $segment_value, false ) . '>' . esc_html__( 'High-value customers (over threshold)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="vip"' . selected( 'vip', $segment_value, false ) . '>' . esc_html__( 'VIP customers (top spenders)', 'product-mailer-campaigns' ) . '</option>';
            echo '<option value="lapsed"' . selected( 'lapsed', $segment_value, false ) . '>' . esc_html__( 'Lapsed customers (90+ days without orders)', 'product-mailer-campaigns' ) . '</option>';
            echo '</select>';
            echo '<p class="description" id="pmcpc_recipient_segment_help">' . esc_html__( 'Optional: further restrict who qualifies. This filter is applied when the trigger fires (automations) or when you queue a manual/scheduled broadcast. Leave as “All subscribers” unless you want to narrow eligibility (e.g. only VIP customers).', 'product-mailer-campaigns' ) . '</p>';
        } else {
            echo '<select disabled="disabled" id="pmcpc_recipient_segment">';
            echo '<option>' . esc_html__( 'All subscribers (default)', 'product-mailer-campaigns' ) . '</option>';
            echo '</select>';
            echo '<div class="description" style="margin-top:6px;">' . esc_html__( 'Customer segments based on purchase behaviour require WooCommerce Automation activation.', 'product-mailer-campaigns' ) . '</div>';
            if ( class_exists( 'WooCommerce' ) ) {
                $trial_url   = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_start_trial' ), 'pmcpc_start_trial' );
                $upgrade_url = admin_url( 'admin.php?page=pmcpc_upgrade' );
                echo '<p style="margin:10px 0 0;">'
                    . '<a class="button button-primary" href="' . esc_url( $trial_url ) . '">' . esc_html__( 'Start free trial', 'product-mailer-campaigns' ) . '</a> '
                    . '<a class="button" href="' . esc_url( $upgrade_url ) . '">' . esc_html__( 'Activate license', 'product-mailer-campaigns' ) . '</a>'
                    . '</p>';
            } else {
                echo '<div class="description" style="margin-top:6px;">' . esc_html__( 'Install WooCommerce to use customer segments.', 'product-mailer-campaigns' ) . '</div>';
            }
        }
        echo '</td></tr>';
}


        // Recipient preview (approximate count based on current settings).
        if ( $campaign->id ) {
            $audience_result  = self::get_campaign_audience_result( $campaign );
            $recipient_count = isset( $audience_result['final_count'] ) ? (int) $audience_result['final_count'] : 0;
            $preview_trigger = self::get_campaign_preview_trigger_key( $campaign );
            $firing_preview  = self::get_campaign_automation_preview_data( $campaign );

            echo '<tr>';
            echo '<th>' . esc_html__( 'Recipient preview', 'product-mailer-campaigns' ) . '</th>';
            echo '<td>';
            if ( $recipient_count > 0 ) {
	                echo '<p>' . sprintf(
	                    /* translators: %d: approximate number of recipients. */
	                    esc_html__( 'This campaign would currently send to approximately %d subscribers after audience filters and eligibility are applied.', 'product-mailer-campaigns' ),
                    (int) $recipient_count
                ) . '</p>';
            } else {
                echo '<p>' . esc_html__( 'With the current audience filters and eligibility, this campaign would not send to any subscribers yet.', 'product-mailer-campaigns' ) . '</p>';
            }

            if ( ! empty( $audience_result ) ) {
                echo '<div class="pmcpc-recipient-breakdown" style="margin:10px 0 0;max-width:760px;padding:10px 12px;border:1px solid #dcdcde;border-radius:4px;background:#fff;">';
                echo '<p style="margin:0 0 6px;"><strong>' . esc_html__( 'Active subscribers', 'product-mailer-campaigns' ) . ':</strong> ' . intval( $audience_result['initial_count'] ) . '</p>';
                echo '<p style="margin:0 0 6px;"><strong>' . esc_html__( 'After audience filters', 'product-mailer-campaigns' ) . ':</strong> ' . intval( $audience_result['refined_count'] ) . '</p>';
                echo '<p style="margin:0;"><strong>' . esc_html__( 'After eligibility', 'product-mailer-campaigns' ) . ':</strong> ' . intval( $audience_result['final_count'] ) . '</p>';
                echo '</div>';
            }

            if ( ! empty( $firing_preview ) && 'none' !== $preview_trigger ) {
                if ( isset( $firing_preview['trigger_count'] ) && null !== $firing_preview['trigger_count'] ) {
                    echo '<div class="pmcpc-trigger-breakdown" style="margin:10px 0 0;max-width:760px;padding:10px 12px;border:1px solid #dcdcde;border-radius:4px;background:#fff;">';
                    echo '<p style="margin:0 0 6px;"><strong>' . esc_html__( 'Trigger candidates now', 'product-mailer-campaigns' ) . ':</strong> ' . intval( $firing_preview['trigger_count'] ) . '</p>';
                    echo '<p style="margin:0;"><strong>' . esc_html__( 'Estimated recipients now', 'product-mailer-campaigns' ) . ':</strong> ' . intval( $firing_preview['trigger_count'] ) . '</p>';
                    echo '</div>';
                }
                echo '<details class="pmcpc-automation-firing-preview" open="open" style="margin-top:12px;padding:12px 14px;border:1px solid #dcdcde;background:#fff;border-radius:4px;max-width:760px;">';
                echo '<summary style="cursor:pointer;font-weight:600;">' . esc_html__( 'Automation firing preview', 'product-mailer-campaigns' ) . '</summary>';
                echo '<div style="margin-top:12px;">';
                echo '<p style="margin:0 0 8px;"><strong>' . esc_html__( 'How it fires', 'product-mailer-campaigns' ) . ':</strong> ' . esc_html( $firing_preview['how_it_fires'] ) . '</p>';
                if ( ! empty( $firing_preview['qualifying_rule'] ) ) {
                    echo '<p style="margin:0 0 8px;"><strong>' . esc_html__( 'Qualifying rule', 'product-mailer-campaigns' ) . ':</strong> ' . esc_html( $firing_preview['qualifying_rule'] ) . '</p>';
                    if ( 'lead_magnet_download' === $preview_trigger ) {
                        echo '<div style="margin:0 0 8px;padding:10px 12px;border-left:3px solid #2271b1;background:#f6f7f7;">';
                        echo '<strong>' . esc_html__( 'Example flow', 'product-mailer-campaigns' ) . '</strong>';
                        echo '<p style="margin:6px 0 0;">' . esc_html__( 'Visitor downloads a guide → signup form adds the lead magnet tag/source → subscriber is added to the list → this email is sent.', 'product-mailer-campaigns' ) . '</p>';
                        echo '</div>';
                    }
                }
                echo '<p style="margin:0 0 8px;"><strong>' . esc_html__( 'Subscribers currently matching this rule', 'product-mailer-campaigns' ) . ':</strong> ' . intval( $firing_preview['eligible_count'] ) . '</p>';
                if ( ! empty( $firing_preview['threshold_value'] ) ) {
                    echo '<p style="margin:0 0 8px;"><strong>' . esc_html__( 'Current threshold', 'product-mailer-campaigns' ) . ':</strong> ' . esc_html( $firing_preview['threshold_value'] ) . '</p>';
                }
                if ( null !== $firing_preview['today_count'] && '' !== $firing_preview['today_label'] ) {
                    echo '<p style="margin:0 0 8px;"><strong>' . esc_html( $firing_preview['today_label'] ) . ':</strong> ' . intval( $firing_preview['today_count'] ) . '</p>';
                    if ( ! empty( $firing_preview['today_emails'] ) ) {
                        echo '<p style="margin:0 0 8px;"><strong>' . esc_html__( 'Examples', 'product-mailer-campaigns' ) . ':</strong> ' . esc_html( implode( ', ', $firing_preview['today_emails'] ) ) . '</p>';
                    }
                }
                if ( ! empty( $firing_preview['next_evaluation'] ) ) {
                    echo '<p style="margin:0 0 8px;"><strong>' . esc_html__( 'Next evaluation', 'product-mailer-campaigns' ) . ':</strong> ' . esc_html( $firing_preview['next_evaluation'] ) . '</p>';
                }
                echo '<div style="margin-top:10px;">';
                echo '<strong>' . esc_html__( 'Recent activity', 'product-mailer-campaigns' ) . ':</strong>';
                if ( empty( $firing_preview['recent_activity'] ) ) {
                    echo '<p style="margin:6px 0 0;">' . esc_html__( 'No emails have been queued or sent for this campaign yet.', 'product-mailer-campaigns' ) . '</p>';
                } else {
                    echo '<ul style="margin:6px 0 0 18px;list-style:disc;">';
                    foreach ( $firing_preview['recent_activity'] as $activity_row ) {
                        $when_raw = ! empty( $activity_row->updated_at ) ? (string) $activity_row->updated_at : ( ! empty( $activity_row->created_at ) ? (string) $activity_row->created_at : '' );
                        $when_txt = $when_raw ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $when_raw ) ) : '';
                        $line = trim( sprintf( '%s — %s%s', ! empty( $activity_row->email ) ? $activity_row->email : __( 'Unknown subscriber', 'product-mailer-campaigns' ), ucfirst( (string) $activity_row->status ), $when_txt ? ' · ' . $when_txt : '' ) );
                        echo '<li>' . esc_html( $line ) . '</li>';
                    }
                    echo '</ul>';
                }
                echo '</div>';
                echo '</div>';
                echo '</details>';
            }
            echo '</td>';
            echo '</tr>';
        }

        
        // Audience builder (tags).
        $audience_tags = array();
        if ( ! empty( $campaign->target_tag ) ) {
            $audience_tags = array_map( 'trim', explode( ',', $campaign->target_tag ) );
            $audience_tags = array_filter( $audience_tags );
        }

        echo '<tr class="pmcpc-audience-advanced"' . ( $pmcpc_adv_on ? '' : ' style="display:none"' ) . '><th>' . esc_html__( 'Audience (tags)', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<fieldset>';
        echo '<legend class="screen-reader-text">' . esc_html__( 'Audience tags', 'product-mailer-campaigns' ) . '</legend>';
        echo '<label><input type="checkbox" name="pmcpc_audience_tags[]" value="newsletter" ' . checked( in_array( 'newsletter', $audience_tags, true ), true, false ) . '> ' . esc_html__( 'General newsletter', 'product-mailer-campaigns' ) . '</label><br>';
        echo '<label><input type="checkbox" name="pmcpc_audience_tags[]" value="product-updates" ' . checked( in_array( 'product-updates', $audience_tags, true ), true, false ) . '> ' . esc_html__( 'Product updates &amp; releases', 'product-mailer-campaigns' ) . '</label><br>';
        echo '<label><input type="checkbox" name="pmcpc_audience_tags[]" value="tips" ' . checked( in_array( 'tips', $audience_tags, true ), true, false ) . '> ' . esc_html__( 'Tips, tutorials &amp; content', 'product-mailer-campaigns' ) . '</label>';
        echo '<p class="description">' . esc_html__( 'Select one or more tags to target subscribers who have chosen those email types. Leaving all unchecked will fall back to the free-form Target Tag field above.', 'product-mailer-campaigns' ) . '</p>';
        echo '</fieldset>';
        echo '</td></tr>';

        echo '</tbody>';

        echo '<tbody class="pmcpc-stage' . ( 4 === $pmcpc_current_stage ? ' is-active' : '' ) . '" data-stage="4">';
        echo '<tr><th colspan="2"><h3 class="pmcpc-stage-title">' . esc_html__( 'Product block / extras', 'product-mailer-campaigns' ) . '</h3><p class="pmcpc-stage-help">' . esc_html__( 'Optionally add products, reviews, and website update extras. These enhance the email but are secondary to the core content and audience setup.', 'product-mailer-campaigns' ) . '</p></th></tr>';

// Product block configuration.
        echo '<tr><th>' . esc_html__( 'Products Block', 'product-mailer-campaigns' ) . '</th>';
        echo '<td>';
        echo '<p><label><input type="checkbox" name="product_block_enabled" value="1" ' . checked( true, $product_block_enabled, false ) . '> ' . esc_html__( 'Include a WooCommerce products block in this email.', 'product-mailer-campaigns' ) . '</label></p>';
        echo '<p>';
        echo '<label for="pmcpc_product_block_source">' . esc_html__( 'Products to show', 'product-mailer-campaigns' ) . ' </label>';
        echo '<select name="product_block_source" id="pmcpc_product_block_source">';
        echo '<option value="latest" ' . selected( 'latest', $product_block_source, false ) . '>' . esc_html__( 'Latest products', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="on_sale" ' . selected( 'on_sale', $product_block_source, false ) . '>' . esc_html__( 'On sale', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="featured" ' . selected( 'featured', $product_block_source, false ) . '>' . esc_html__( 'Featured products', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="random" ' . selected( 'random', $product_block_source, false ) . '>' . esc_html__( 'Random products', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="specific" ' . selected( 'specific', $product_block_source, false ) . '>' . esc_html__( 'Specific products (IDs)', 'product-mailer-campaigns' ) . '</option>';
        echo '</select>';
        echo '</p>';
        echo '<p>';
        echo '<label>' . esc_html__( 'Number of products', 'product-mailer-campaigns' ) . ' ';
        echo '<input type="number" name="product_block_limit" min="1" max="20" value="' . esc_attr( $product_block_limit ) . '" style="width:80px;">';
        echo '</label>';
        echo '</p>';

        echo '<p>';
        echo '<label for="pmcpc_product_block_layout">' . esc_html__( 'Layout preset', 'product-mailer-campaigns' ) . ' </label>';
        echo '<select name="product_block_layout" id="pmcpc_product_block_layout">';
        echo '<option value="classic_left" ' . selected( 'classic_left', $product_block_layout, false ) . '>' . esc_html__( 'Classic list (image left)', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="classic_right" ' . selected( 'classic_right', $product_block_layout, false ) . '>' . esc_html__( 'Classic list (image right)', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="compact_left" ' . selected( 'compact_left', $product_block_layout, false ) . '>' . esc_html__( 'Compact list (smaller images)', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="grid_2" ' . selected( 'grid_2', $product_block_layout, false ) . '>' . esc_html__( 'Grid (2 columns)', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="grid_3" ' . selected( 'grid_3', $product_block_layout, false ) . '>' . esc_html__( 'Grid (3 columns)', 'product-mailer-campaigns' ) . '</option>';
        echo '</select>';
        echo '<span class="description" style="margin-left:8px;">' . esc_html__( 'Email-friendly presets (tables + inline styles).', 'product-mailer-campaigns' ) . '</span>';
        echo '</p>';
        echo '<p>';
        echo '<label><input type="checkbox" name="product_block_exclude_oos" value="1" ' . checked( true, $product_block_exclude_oos, false ) . '> ' . esc_html__( 'Exclude out-of-stock products', 'product-mailer-campaigns' ) . '</label><br>';
        echo '<span class="description">' . esc_html__( 'If enabled, products with stock status "Out of stock" will be skipped (including in specific product IDs).', 'product-mailer-campaigns' ) . '</span>';
        echo '</p>';

        echo '<p>';
        echo '<label for="pmcpc_product_block_specific_ids">' . esc_html__( 'Specific product IDs', 'product-mailer-campaigns' ) . '</label><br>';
        echo '<input type="text" name="product_block_specific_ids" id="pmcpc_product_block_specific_ids" class="regular-text" value="' . esc_attr( $product_block_specific_ids ) . '" placeholder="12, 34, 56">';
        echo '<p class="description">' . esc_html__( 'Optional. Comma-separated list of product IDs to show when using the "Specific products" source.', 'product-mailer-campaigns' ) . '</p>';
        echo '</p>';
$categories = get_terms(
    array(
        'taxonomy'   => 'product_cat',
        'hide_empty' => false,
    )
);

if ( ! is_wp_error( $categories ) && ! empty( $categories ) ) {
    echo '<p>';
    echo '<label for="pmcpc_product_block_categories">' . esc_html__( 'Product categories', 'product-mailer-campaigns' ) . '</label><br>';
    echo '<select name="product_block_categories[]" id="pmcpc_product_block_categories" multiple="multiple" style="min-width:220px;height:120px;">';

    foreach ( $categories as $cat ) {
        echo '<option value="' . esc_attr( $cat->term_id ) . '"' . selected( in_array( $cat->term_id, $selected_category_ids, true ), true, false ) . '>' . esc_html( $cat->name ) . '</option>';
    }

    echo '</select>';
    echo '<p class="description">' . esc_html__( 'Optional. Limit the products block to these categories (ignored when using "Specific products"). Hold Ctrl/Cmd to select multiple.', 'product-mailer-campaigns' ) . '</p>';
    echo '</p>';
}

        echo '<p class="description">' . esc_html__( 'The products block is appended at the end.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';


        echo '</tbody>';

        echo '<tbody class="pmcpc-stage' . ( 5 === $pmcpc_current_stage ? ' is-active' : '' ) . '" data-stage="5">';
        echo '<tr><th colspan="2"><h3 class="pmcpc-stage-title">' . esc_html__( 'Content', 'product-mailer-campaigns' ) . '</h3><p class="pmcpc-stage-help">' . esc_html__( 'Write the email itself. Use placeholders like {{first_name}} and trigger-specific blocks such as {{order_id}}, {{products_block}}, or {{reviews_block}}. Footer links can be added automatically, or you can place unsubscribe/manage links directly in your HTML.', 'product-mailer-campaigns' ) . '</p></th></tr>';

                // Template dropdown (applies starter HTML into the editor).
        // Pull from the central template store so defaults + user templates appear here seamlessly.
        $pmcpc_all_templates    = class_exists( 'PMCPC_Email_Templates' ) ? PMCPC_Email_Templates::get_all() : array();
        $pmcpc_preset_templates = class_exists( 'PMCPC_Email_Templates' ) ? PMCPC_Email_Templates::get_presets() : array();
        $pmcpc_default_tpl_id   = class_exists( 'PMCPC_Email_Templates' ) ? PMCPC_Email_Templates::get_default_id() : 'classic';
        $pmcpc_template_context = class_exists( 'PMCPC_Email_Templates' ) ? PMCPC_Email_Templates::get_template_context_map() : array();
        $pmcpc_recommended_tpl  = class_exists( 'PMCPC_Email_Templates' ) ? PMCPC_Email_Templates::get_recommended_template_id_for_trigger( (string) $automation_trigger ) : $pmcpc_default_tpl_id;
        $pmcpc_selected_tpl_id  = $pmcpc_recommended_tpl ? $pmcpc_recommended_tpl : $pmcpc_default_tpl_id;

        // Fallback (should rarely be hit if helper loads).
        if ( empty( $pmcpc_all_templates ) ) {
            $pmcpc_all_templates = array(
                'classic' => array(
                    'label' => __( 'Classic', 'product-mailer-campaigns' ),
                    'header_html' => '<p>' . esc_html__( 'Hello {{first_name}},', 'product-mailer-campaigns' ) . '</p>{{products_block}}',
                ),
            );
        }

        $pmcpc_manage_templates_url = admin_url( 'admin.php?page=pmcpc_email_templates' );

        echo '<tr><th>' . esc_html__( 'Template', 'product-mailer-campaigns' ) . '</th><td>';
        echo '<div class="pmcpc-template-row">';
        echo '<label for="pmcpc_email_template_pick" class="screen-reader-text">' . esc_html__( 'Template', 'product-mailer-campaigns' ) . '</label>';
        echo '<select id="pmcpc_email_template_pick" style="min-width:260px">';

        // Presets grouped by context so WooCommerce and WordPress templates stay clearly separated.
        $pmcpc_template_groups = array(
            'recommended' => array(
                'label' => __( 'Recommended for this trigger', 'product-mailer-campaigns' ),
                'ids'   => array(),
            ),
            'woocommerce' => array(
                'label' => __( 'WooCommerce templates', 'product-mailer-campaigns' ),
                'ids'   => array(),
            ),
            'wordpress' => array(
                'label' => __( 'WordPress templates', 'product-mailer-campaigns' ),
                'ids'   => array(),
            ),
            'general' => array(
                'label' => __( 'General templates', 'product-mailer-campaigns' ),
                'ids'   => array(),
            ),
        );

        if ( ! empty( $pmcpc_preset_templates ) ) {
            foreach ( $pmcpc_preset_templates as $tid => $tdata ) {
                $group = isset( $pmcpc_template_context[ $tid ]['group'] ) ? (string) $pmcpc_template_context[ $tid ]['group'] : 'general';
                if ( ! isset( $pmcpc_template_groups[ $group ] ) ) {
                    $group = 'general';
                }
                $pmcpc_template_groups[ $group ]['ids'][] = $tid;

                $compatible = isset( $pmcpc_template_context[ $tid ]['compatible_triggers'] ) && is_array( $pmcpc_template_context[ $tid ]['compatible_triggers'] ) ? $pmcpc_template_context[ $tid ]['compatible_triggers'] : array();
                if ( $tid === $pmcpc_recommended_tpl || ( '' !== (string) $automation_trigger && in_array( (string) $automation_trigger, $compatible, true ) ) ) {
                    $pmcpc_template_groups['recommended']['ids'][] = $tid;
                }
            }

            foreach ( $pmcpc_template_groups as $pmcpc_group_key => $pmcpc_group ) {
                $pmcpc_ids = array_values( array_unique( array_filter( $pmcpc_group['ids'] ) ) );
                if ( empty( $pmcpc_ids ) ) {
                    continue;
                }
                echo '<optgroup label="' . esc_attr( $pmcpc_group['label'] ) . '">';
                foreach ( $pmcpc_ids as $tid ) {
                    if ( ! isset( $pmcpc_preset_templates[ $tid ] ) ) {
                        continue;
                    }
                    $tdata  = $pmcpc_preset_templates[ $tid ];
                    $label  = isset( $tdata['label'] ) ? (string) $tdata['label'] : (string) $tid;
                    $suffix = '';
                    if ( 'recommended' === $pmcpc_group_key ) {
                        $suffix = ' — ' . __( 'Baseline', 'product-mailer-campaigns' );
                    } elseif ( $tid === $pmcpc_default_tpl_id ) {
                        $suffix = ' — ' . __( 'Default', 'product-mailer-campaigns' );
                    }
                    echo '<option value="' . esc_attr( $tid ) . '"' . selected( $pmcpc_selected_tpl_id, $tid, false ) . '>' . esc_html( $label . $suffix ) . '</option>';
                }
                echo '</optgroup>';
            }
        }

        // Custom templates (anything not in presets).
        $pmcpc_custom_ids = array();
        foreach ( $pmcpc_all_templates as $tid => $tdata ) {
            if ( isset( $pmcpc_preset_templates[ $tid ] ) ) {
                continue;
            }
            $pmcpc_custom_ids[] = $tid;
        }
        if ( ! empty( $pmcpc_custom_ids ) ) {
            echo '<optgroup label="' . esc_attr__( 'Your templates', 'product-mailer-campaigns' ) . '">';
            foreach ( $pmcpc_custom_ids as $tid ) {
                $tdata = $pmcpc_all_templates[ $tid ];
                $label = isset( $tdata['label'] ) ? (string) $tdata['label'] : (string) $tid;
                $suffix = ( $tid === $pmcpc_default_tpl_id ) ? ' — ' . __( 'Default', 'product-mailer-campaigns' ) : '';
                echo '<option value="' . esc_attr( $tid ) . '"' . selected( $pmcpc_selected_tpl_id, $tid, false ) . '>' . esc_html( $label . $suffix ) . '</option>';
            }
            echo '</optgroup>';
        }

        echo '</select>';
        echo '<button type="button" class="button" id="pmcpc_apply_email_template">' . esc_html__( 'Apply', 'product-mailer-campaigns' ) . '</button>';
        echo '<span class="description">' . esc_html__( 'Applies the selected template content to the editor and replaces the current email body.', 'product-mailer-campaigns' ) . '</span>';
        echo '</div>';

        // JS map (id => header_html).
        $pmcpc_tpl_js = array();
        foreach ( $pmcpc_all_templates as $tid => $tdata ) {
            if ( ! is_array( $tdata ) ) {
                continue;
            }
            $pmcpc_tpl_js[ $tid ] = (string) ( $tdata['header_html'] ?? '' );
        }
        echo '<script>window.PMCPC_EMAIL_TEMPLATES = ' . wp_json_encode( $pmcpc_tpl_js ) . ';</script>';

        $pmcpc_email_step_js = <<<'PMCPCJS'
(function(){
  function setEditor(html){
    try{
      if(window.tinymce && tinymce.get("pmcpc_content")){
        tinymce.get("pmcpc_content").setContent(html);
      }else{
        var ta=document.getElementById("pmcpc_content");
        if(ta){ ta.value = html; }
      }
    }catch(e){
      var ta2=document.getElementById("pmcpc_content");
      if(ta2){ ta2.value = html; }
    }
  }
  document.addEventListener("click",function(e){
    if(!e.target || e.target.id!=="pmcpc_apply_email_template") return;
    var sel=document.getElementById("pmcpc_email_template_pick");
    if(!sel) return;
    var id=sel.value;
    var html=(window.PMCPC_EMAIL_TEMPLATES||{})[id]||"";
    if(!html) return;
    if(!window.confirm("Apply this template and overwrite the current email content?")) return;
    setEditor(html);
  });
})();
PMCPCJS;
        echo '<script>' . $pmcpc_email_step_js . '</script>';
        echo '</td></tr>';

        echo '<tr><th>' . esc_html__( 'Footer links', 'product-mailer-campaigns' ) . '</th><td>';
        echo '<label><input type="checkbox" name="auto_footer_links_enabled" value="1" ' . checked( 1, $auto_footer_links_enabled, false ) . '> ' . esc_html__( 'Add footer links automatically (Manage preferences + Unsubscribe)', 'product-mailer-campaigns' ) . '</label>';
        echo '<p class="description">' . esc_html__( 'Enabled by default. Turn this off if you want to place your own unsubscribe/manage links directly in the email HTML.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

// Content editor.
        echo '<tr><th><label for="pmcpc_content">' . esc_html__( 'Content (HTML allowed)', 'product-mailer-campaigns' ) . '</label></th>';
        echo '<td>';
        wp_editor(
            $campaign->content,
            'pmcpc_content',
            array(
                'textarea_name' => 'content',
                'textarea_rows' => 12,
            )
        );
        // Context-aware placeholder help (trigger-specific baseline).
        $pmcpc_placeholders = class_exists( 'PMCPC_Email_Templates' )
            ? PMCPC_Email_Templates::get_recommended_placeholders_for_trigger( (string) $automation_trigger )
            : array( '{{first_name}}', '{{email}}', '{{products_block}}', '{{reviews_block}}' );
		// Render each placeholder wrapped in its own <code> tag.
		// This avoids markup edge cases where the first opening <code> tag can be dropped by the editor/sanitizer,
		// which would leave a stray closing </code> in the UI.
		$pmcpc_placeholder_codes = array_map(
			function ( $p ) {
				return '<span class="pmcpc-placeholder-chip">' . esc_html( $p ) . '</span>';
			},
			$pmcpc_placeholders
		);
		if ( ! empty( $automation_trigger ) && ! empty( $pmcpc_recommended_tpl ) && isset( $pmcpc_all_templates[ $pmcpc_recommended_tpl ]['label'] ) ) {
			echo '<p class="description">' . esc_html( sprintf( __( 'Starter placeholders for %s', 'product-mailer-campaigns' ), (string) $pmcpc_all_templates[ $pmcpc_recommended_tpl ]['label'] ) ) . '</p>';
		}
		echo '<p class="description">' . esc_html__( 'Available placeholders', 'product-mailer-campaigns' ) . '</p>';
		echo '<div class="pmcpc-placeholder-list">' . implode( '', $pmcpc_placeholder_codes ) . '</div>';
        echo '<p style="margin:10px 0 8px;"><strong>' . esc_html__( 'Insert blocks', 'product-mailer-campaigns' ) . '</strong></p>';
        echo '<div class="pmcpc-placeholder-list pmcpc-insert-actions">';
        echo '<button type="button" class="button" data-pmcpc-insert-target="pmcpc_content" data-pmcpc-insert-value="{{reviews_block}}">' . esc_html__( 'Insert Reviews', 'product-mailer-campaigns' ) . '</button>';
        if ( 'review_request' === (string) $automation_trigger ) {
            echo '<button type="button" class="button" data-pmcpc-insert-target="pmcpc_content" data-pmcpc-insert-value="{{review_stars_block}}">' . esc_html__( 'Insert Review Stars', 'product-mailer-campaigns' ) . '</button>';
        }
        echo '</div>';
        echo '<p class="description">' . esc_html__( 'Adds the placeholder at the current cursor position in the email editor.', 'product-mailer-campaigns' ) . '</p>';
        echo '<script>(function(){
'
            . 'function pmcpcInsertAtCursor(field, value){ if(!field){ return false; } var start = typeof field.selectionStart === "number" ? field.selectionStart : field.value.length; var end = typeof field.selectionEnd === "number" ? field.selectionEnd : field.value.length; field.focus(); field.value = field.value.substring(0,start) + value + field.value.substring(end); var pos = start + value.length; try { field.selectionStart = field.selectionEnd = pos; } catch(e){} try { field.dispatchEvent(new Event("input", { bubbles:true })); field.dispatchEvent(new Event("change", { bubbles:true })); } catch(e){} return true; }
'
            . 'function pmcpcInsertIntoEditor(targetId, value){ try { if(window.tinymce && tinymce.get(targetId)){ tinymce.get(targetId).focus(); tinymce.get(targetId).execCommand("mceInsertContent", false, value); return true; } } catch(e){} return pmcpcInsertAtCursor(document.getElementById(targetId), value); }
'
            . 'function pmcpcBindInsertButtons(){ var buttons = document.querySelectorAll("[data-pmcpc-insert-target][data-pmcpc-insert-value]"); if(!buttons.length){ return; } buttons.forEach(function(btn){ if(btn.dataset.pmcpcInsertBound === "1"){ return; } btn.dataset.pmcpcInsertBound = "1"; btn.addEventListener("click", function(e){ e.preventDefault(); pmcpcInsertIntoEditor(btn.getAttribute("data-pmcpc-insert-target"), btn.getAttribute("data-pmcpc-insert-value") || ""); }); }); }
'
            . 'if(document.readyState === "loading"){ document.addEventListener("DOMContentLoaded", pmcpcBindInsertButtons); } else { pmcpcBindInsertButtons(); }
'
            . 'setTimeout(pmcpcBindInsertButtons, 300);
'
            . '})();</script>';
        echo '</td></tr>';

        echo '</tbody>';

        // Stage 6: final review + save.
        echo '<tbody class="pmcpc-stage' . ( 6 === $pmcpc_current_stage ? ' is-active' : '' ) . '" data-stage="6">';
        echo '<tr><th colspan="2"><h3 class="pmcpc-stage-title">' . esc_html__( 'Review & save', 'product-mailer-campaigns' ) . '</h3>';
        echo '<p class="pmcpc-stage-help">' . esc_html__( 'Review the key settings and preview the email. When you are happy, click “Save campaign”.', 'product-mailer-campaigns' ) . '</p></th></tr>';

        echo '<tr><th>' . esc_html__( 'Checklist', 'product-mailer-campaigns' ) . '</th><td>';
        echo '<ul style="margin:0 0 0 1.2em;list-style:disc">';
        echo '<li>' . esc_html__( 'Subject and From details are filled in.', 'product-mailer-campaigns' ) . '</li>';
        echo '<li>' . esc_html__( 'Audience is selected (tags / lifecycle / segment).', 'product-mailer-campaigns' ) . '</li>';
        echo '<li>' . esc_html__( 'Trigger is correct (manual/schedule or automated event).', 'product-mailer-campaigns' ) . '</li>';
        echo '<li>' . esc_html__( 'Email content looks correct and unsubscribe link is present.', 'product-mailer-campaigns' ) . '</li>';
        echo '</ul>';
        $preview_url = add_query_arg(
            array(
                'page'         => 'pmcpc_campaigns',
                'campaign_id'  => (int) $campaign->id,
                'pmcpc_preview'=> '1',
            ),
            admin_url( 'admin.php' )
        );
        $preview_url = wp_nonce_url( $preview_url, 'pmcpc_preview_campaign_' . (int) $campaign->id );
        echo '<p style="margin-top:10px"><a href="' . esc_url( $preview_url ) . '" class="button" id="pmcpc_review_preview_link" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Preview email in a new tab', 'product-mailer-campaigns' ) . '</a></p>';
        echo '<p class="description">' . esc_html__( 'Tip: after saving, use “View email” from the list below to confirm products render and links track correctly.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';

        echo '</tbody>';
        echo '</table>';

        // Stage navigation (Back/Next) lives under the table so the editor isn't cramped.
        $pmcpc_prev_stage = max( 1, $pmcpc_current_stage - 1 );
        $pmcpc_next_stage = min( 6, $pmcpc_current_stage + 1 );
        echo '<div class="pmcpc-stage-actions" id="pmcpc_stage_actions">';
        echo '<span class="pmcpc-stage-badge" id="pmcpc_stage_badge"></span>';
        echo '<span class="pmcpc-stage-spacer"></span>';
        // Render anchors styled as buttons so navigation works even if JS is blocked.
        echo '<a class="button" id="pmcpc_stage_back" href="' . esc_url( add_query_arg( 'pmcpc_stage', $pmcpc_prev_stage, $pmcpc_base_url ) ) . '"' . ( 1 === $pmcpc_current_stage ? ' aria-disabled="true" onclick="return false;"' : '' ) . '>' . esc_html__( 'Back', 'product-mailer-campaigns' ) . '</a>';
        if ( 6 === $pmcpc_current_stage ) {
            echo '<button type="submit" class="button button-primary" id="pmcpc_stage_next">' . esc_html__( 'Save campaign', 'product-mailer-campaigns' ) . '</button>';
        } else {
            echo '<a class="button button-primary" id="pmcpc_stage_next" href="' . esc_url( add_query_arg( 'pmcpc_stage', $pmcpc_next_stage, $pmcpc_base_url ) ) . '">' . esc_html__( 'Next', 'product-mailer-campaigns' ) . '</a>';
        }
        echo '</div>';
        echo '<input type="hidden" id="pmcpc_recipient_count_nonce" value="' . esc_attr( wp_create_nonce( 'pmcpc_recipient_count' ) ) . '">';
        echo '<div class="pmcpc-builder-save">';
        submit_button( __( 'Save progress', 'product-mailer-campaigns' ), 'secondary', 'submit', false );
        echo '</div>';
        echo '</form>';

        // Close left column and render right-hand summary/help.
        echo '</div>'; // .pmcpc-left

        echo '<div class="pmcpc-right">';
        echo '<div class="pmcpc-campaign-card" id="pmcpc_campaign_summary">';
        echo '<h3>' . esc_html__( 'Campaign summary', 'product-mailer-campaigns' ) . '</h3>';
        echo '<div id="pmcpc_campaign_summary_text">' . esc_html__( 'Use the stages on the left to configure the trigger, audience, products and email content.', 'product-mailer-campaigns' ) . '</div>';
        $pmcpc_recipient_initial = '&mdash;';

        // Precompute an estimate when possible so the sidebar can stay in sync even if the user navigates stages via JS.
        $pmcpc_estimate_value = '';
        if ( ! empty( $campaign->id ) ) {
            $pmcpc_est = self::count_recipients_for_campaign( $campaign );
            if ( is_numeric( $pmcpc_est ) ) {
                $pmcpc_estimate_value = (string) (int) $pmcpc_est;
            }
        }

        // Before the Audience stage is configured, show an intentional hint instead of a dash.
        if ( $pmcpc_current_stage < 3 ) {
            $pmcpc_recipient_initial = esc_html__( 'Configure audience to calculate', 'product-mailer-campaigns' );
        }

        // For triggered automations, recipient counts are event-based.
        if ( isset( $automation_trigger ) && 'none' !== (string) $automation_trigger ) {
            $pmcpc_recipient_initial = esc_html__( 'Event-based', 'product-mailer-campaigns' );
        } elseif ( $pmcpc_current_stage >= 3 && '' !== $pmcpc_estimate_value ) {
            // From Audience onward, show the server-side estimate for manual/scheduled campaigns.
            $pmcpc_recipient_initial = $pmcpc_estimate_value;
        }

        echo '<div id="pmcpc_recipient_live" data-pmcpc-estimate="' . esc_attr( $pmcpc_estimate_value ) . '" style="margin-top:10px;padding:10px;border:1px solid #dcdcde;border-radius:10px;background:#fff;">'
            . '<span id="pmcpc_recipient_live_label">' . esc_html__( 'Estimated recipients:', 'product-mailer-campaigns' ) . '</span> <strong id="pmcpc_recipient_live_num">' . $pmcpc_recipient_initial . '</strong>'
            . '<div id="pmcpc_recipient_live_meta" style="margin-top:6px;font-size:12px;color:#646970;line-height:1.4">'
            . '<span id="pmcpc_meta_trigger"></span><br><span id="pmcpc_meta_segment"></span>'
            . '</div>'
            . '</div>';
        echo '<div id="pmcpc_summary_meta" class="pmcpc-summary-block">'
            . '<div class="pmcpc-summary-row"><strong>' . esc_html__( 'Send trigger', 'product-mailer-campaigns' ) . '</strong><br><span id="pmcpc_summary_trigger">&mdash;</span></div>'
            . '<div class="pmcpc-summary-row"><strong>' . esc_html__( 'Audience', 'product-mailer-campaigns' ) . '</strong><br><span id="pmcpc_summary_segment">&mdash;</span></div>'
            . '</div>';
        echo '<div id="pmcpc_campaign_summary_warn" class="pmcpc-inline-warn" style="display:none"></div>';
        echo '<p style="margin-top:10px;"><button type="button" class="button" id="pmcpc_reset_recommended">' . esc_html__( 'Reset to recommended defaults', 'product-mailer-campaigns' ) . '</button></p>';
        echo '</div>';

        echo '<div class="pmcpc-campaign-card" style="margin-top:12px">';
        echo '<h3>' . esc_html__( 'Quick guidance', 'product-mailer-campaigns' ) . '</h3>';
        echo '<ul style="margin:0 0 0 1.2em;list-style:disc">';
        echo '<li>' . esc_html__( 'Use “Post-purchase” + customer segments for order follow-ups (not the Welcome trigger).', 'product-mailer-campaigns' ) . '</li>';
        echo '<li>' . esc_html__( 'If this is a one-off newsletter, choose “Manual or scheduled (not automated)” and use Schedule for a send time.', 'product-mailer-campaigns' ) . '</li>';
        echo '<li>' . esc_html__( 'Lifecycle tags (new / repeat / lapsed) are exclusive — a subscriber should only have one at a time.', 'product-mailer-campaigns' ) . '</li>';
        echo '</ul>';
        echo '</div>';
        echo '</div>'; // .pmcpc-right

        echo '</div>'; // .pmcpc-campaign-layout

        // Guided builder JS: hide irrelevant fields and warn on mismatches.
        echo '<script>
        (function(){
            var $ = function(id){return document.getElementById(id);};
            var trigger = $("pmcpc_automation_trigger");
            var scheduleType = $("pmcpc_schedule_type");
            var scheduleDate = $("pmcpc_schedule_date");
            var scheduleTime = $("pmcpc_schedule_time");
            var schedFreq = $("pmcpc_schedule_frequency");
            var advAudience = $("pmcpc_show_audience_advanced");
            var targetTag = $("pmcpc_target_tag");
            var excludeTags = $("pmcpc_exclude_tags");
            var prodEnabled = document.querySelector("input[name=product_block_enabled]");
            var prodSource = $("pmcpc_product_block_source");
            
            var originTags = $("pmcpc_target_origin_tags");
            var originSelect = $("pmcpc_target_origin_tags_select");
            var sourceTags = $("pmcpc_target_source_tags");
            var lifeTags = $("pmcpc_target_lifecycle_tags");
            var sourceSelect = $("pmcpc_target_source_tags_select");
            var lifeSelect = $("pmcpc_target_lifecycle_tags_select");
            var seg = $("pmcpc_recipient_segment");
	            var segTouched = false;
            var summary = $("pmcpc_campaign_summary_text");
            var warn = $("pmcpc_campaign_summary_warn");
            var resetBtn = $("pmcpc_reset_recommended");
            var recipientNum = $("pmcpc_recipient_live_num");
            var recipientLabel = $("pmcpc_recipient_live_label");
            var summaryTrig = $("pmcpc_summary_trigger");
            var summarySeg = $("pmcpc_summary_segment");
            var nonceField = $("pmcpc_recipient_count_nonce");
            var ajaxNonce = nonceField ? (nonceField.value || "") : "";

            // Determine the current stage from the URL (works even when stage navigation is link-based).
            // Falls back to 1 (Goal) if missing/invalid.
            var currentStage = (function(){
                try {
                    var p = new URLSearchParams(window.location.search || "");
                    var v = parseInt(p.get("pmcpc_stage") || "", 10);
                    return (isNaN(v) || v < 1) ? 1 : v;
                } catch(e) {
                    return 1;
                }
            })();

	            if (seg) {
	                seg.addEventListener("change", function(){ segTouched = true; });
	            }
                // Sync multi-selects (Source/Lifecycle) to hidden comma-separated fields.
                function syncMulti(selectEl, hiddenEl){
                    if (!selectEl || !hiddenEl) return;
                    var vals = [];
                    for (var i=0; i<selectEl.options.length; i++) {
                        var opt = selectEl.options[i];
                        if (opt.selected) vals.push(opt.value);
                    }
                    hiddenEl.value = vals.join(", ");
                }
                if (sourceSelect && sourceTags) {
                    sourceSelect.addEventListener("change", function(){ syncMulti(sourceSelect, sourceTags); });
                    // Ensure initial sync (in case of browser quirks).
                    syncMulti(sourceSelect, sourceTags);
                }
                if (originSelect && originTags) {
                    originSelect.addEventListener("change", function(){ syncMulti(originSelect, originTags); });
                    // Ensure initial sync (in case of browser quirks).
                    syncMulti(originSelect, originTags);
                }
                if (lifeSelect && lifeTags) {
                    lifeSelect.addEventListener("change", function(){ syncMulti(lifeSelect, lifeTags); });
                    syncMulti(lifeSelect, lifeTags);
                }

                // Ensure we capture the latest multi-select values even if the user clicks Save immediately.
                var formEl = document.getElementById("pmcpc_campaign_form");
                if (formEl) {
                    formEl.addEventListener("submit", function(){
                        try { syncMulti(sourceSelect, sourceTags); } catch(e) {}
                        try { syncMulti(lifeSelect, lifeTags); } catch(e) {}
                        try {
                            var payloadField = document.getElementById("pmcpc_subscriber_page_payload");
                            if (payloadField) {
                                var pick = function(id){ var el = document.getElementById(id); return el ? el.value : ""; };
                                var pickChecked = function(name){ var el = formEl.querySelector("input[name=\"" + name + "\"]"); return !!(el && el.checked); };
                                payloadField.value = JSON.stringify({
                                    enabled: pickChecked("publish_to_subscriber_page"),
                                    title: pick("pmcpc_subscriber_page_title"),
                                    excerpt: pick("pmcpc_subscriber_page_excerpt"),
                                    topic: pick("pmcpc_subscriber_page_topic"),
                                    post_status: pick("pmcpc_subscriber_page_post_status"),
                                    featured: pickChecked("subscriber_page_featured"),
                                    image_url: pick("pmcpc_subscriber_page_image_url"),
                                    cta_label: pick("pmcpc_subscriber_page_cta_label"),
                                    cta_url: pick("pmcpc_subscriber_page_cta_url"),
                                    visibility: pick("pmcpc_subscriber_page_visibility"),
                                    segment: pick("pmcpc_subscriber_page_segment"),
                                    expires_at: pick("pmcpc_subscriber_page_expires_at"),
                                    content: pick("pmcpc_subscriber_page_content")
                                });
                            }
                        } catch(e) {}
                    });
                }

	            // Stage-by-stage builder state.
            var table = $("pmcpc_campaign_builder_table");
            var stageBadge = $("pmcpc_stage_badge");
            var btnBack = $("pmcpc_stage_back");
            var btnNext = $("pmcpc_stage_next");
            var stageChips = document.querySelectorAll(".pmcpc-stage-chip");
            var stages = table ? table.querySelectorAll("tbody.pmcpc-stage") : [];
            var maxStage = 6;
            // currentStage is initialised from the URL earlier in this script.
            currentStage = (typeof currentStage === "number" && !isNaN(currentStage) && currentStage >= 1) ? currentStage : 1;

            function showStage(n){
                n = parseInt(n, 10);
                if (!n || n < 1) n = 1;
                if (n > maxStage) n = maxStage;
                currentStage = n;
                stages.forEach(function(tb){
                    tb.classList.toggle("is-active", tb.getAttribute("data-stage") === String(n));
                });
                stageChips.forEach(function(chip){
                    var isCurrent = chip.getAttribute("data-pmcpc-stage") === String(n);
                    chip.setAttribute("aria-current", isCurrent ? "step" : "false");
                });
                if (stageBadge) {
                    var labels = {
                        1: "' . esc_js( __( 'Stage 1 of 6: Sending details', 'product-mailer-campaigns' ) ) . '",
                        2: "' . esc_js( __( 'Stage 2 of 6: Schedule / trigger', 'product-mailer-campaigns' ) ) . '",
                        3: "' . esc_js( __( 'Stage 3 of 6: Audience', 'product-mailer-campaigns' ) ) . '",
                        4: "' . esc_js( __( 'Stage 4 of 6: Product block / extras', 'product-mailer-campaigns' ) ) . '",
                        5: "' . esc_js( __( 'Stage 5 of 6: Content', 'product-mailer-campaigns' ) ) . '",
                        6: "' . esc_js( __( 'Stage 6 of 6: Review', 'product-mailer-campaigns' ) ) . '"
                    };
                    stageBadge.textContent = labels[n] || ("Stage " + n);
                }
                if (btnBack) btnBack.disabled = (n === 1);
                if (btnNext) btnNext.textContent = (n === maxStage) ? "' . esc_js( __( 'Save campaign', 'product-mailer-campaigns' ) ) . '" : "' . esc_js( __( 'Next', 'product-mailer-campaigns' ) ) . '";
                // Keep the form header in view when moving stages.
                try { window.scrollTo({top: 0, behavior: "smooth"}); } catch(e) { window.scrollTo(0,0); }

                // Recalculate the recipient estimate whenever the stage changes.
                // This prevents stale counts when users jump between Trigger/Audience.
                try { updateRecipientCount(); } catch(e) {}
            }

            var pmcpcStagesInited = false;
            function initStages(){
                // Prevent double-binding of events (can cause Next/Back to fire twice and skip steps).
                if (pmcpcStagesInited) { return; }
                pmcpcStagesInited = true;
                // Default to stage 1, or a stage specified in the URL.
                var params = new URLSearchParams(window.location.search);
                var fromUrl = params.get("pmcpc_stage");
                if (fromUrl) currentStage = parseInt(fromUrl, 10) || 1;
                showStage(currentStage);

                if (btnBack) btnBack.addEventListener("click", function(e){
                    // When rendered as <a>, prevent navigation so the JS wizard works.
                    if (e && typeof e.preventDefault === "function") e.preventDefault();
                    showStage(currentStage - 1);
                    update();
                });
                if (btnNext) btnNext.addEventListener("click", function(e){
                    if (e && typeof e.preventDefault === "function") e.preventDefault();
                    if (currentStage < maxStage) {
                        showStage(currentStage + 1);
                        update();
                        return;
                    }
                    // On final stage, submit the form.
                    var form = document.getElementById("pmcpc_campaign_form");
                    if (form) {
                        try { form.requestSubmit ? form.requestSubmit() : form.submit(); } catch(e) { form.submit(); }
                    }
                });

                stageChips.forEach(function(chip){
                    chip.addEventListener("click", function(e){
                        if (e && typeof e.preventDefault === "function") e.preventDefault();
                        var n = chip.getAttribute("data-pmcpc-stage");
                        showStage(n);
                        update();
                    });
                });
            }

            function trOf(el){
                while (el && el.tagName !== "TR") el = el.parentNode;
                return el;
            }

            function setRowVisible(el, visible){
                var tr = trOf(el);
                if (!tr) return;
                tr.style.display = visible ? "" : "none";
            }

            function setRowMuted(el, muted){
                var tr = trOf(el);
                if (!tr) return;
                tr.classList.toggle("pmcpc-muted", !!muted);
                var inputs = tr.querySelectorAll("input,select,textarea");
                inputs.forEach(function(i){ if(i.name !== "name" && i.name !== "subject") i.disabled = !!muted; });
            }

            function getVal(el){ return el ? (el.value || "") : ""; }

            function getSelectLabel(el){
                try {
                    if (!el || !el.options || typeof el.selectedIndex === "undefined") return "";
                    var opt = el.options[el.selectedIndex];
                    return opt && opt.textContent ? opt.textContent.trim() : "";
                } catch(e) {
                    return "";
                }
            }

            function update(){
                var trig = getVal(trigger) || "none";
                var sched = getVal(scheduleType) || "manual";
                var prodOn = prodEnabled ? !!prodEnabled.checked : false;

                // Recipient summary in sidebar.
                // - Before Audience: show a helpful hint.
                // - Triggered automations: event-based.
                // - Manual/scheduled from Audience onward: prefer the server-side estimate cached on the summary card.
                // IMPORTANT: never overwrite a valid server-rendered number with an em-dash.

                if (recipientLabel && recipientNum) {
                    var estWrap = document.getElementById("pmcpc_recipient_live");
                    var cachedEst = estWrap ? (estWrap.getAttribute("data-pmcpc-estimate") || "") : "";
                    cachedEst = (cachedEst + "").trim();

                    if (currentStage < 3) {
                        recipientLabel.textContent = "Estimated recipients:";
                        recipientNum.textContent = "Configure audience to calculate";
                    } else if (trig && trig !== "none") {
                        recipientLabel.textContent = "Recipients:";
                        recipientNum.textContent = "Event-based";
                    } else {
                        recipientLabel.textContent = "Estimated recipients:";
                        // If we have a cached server estimate, use it (this keeps the sidebar aligned with Recipient preview).
                        if (cachedEst && /^\d+$/.test(cachedEst)) {
                            recipientNum.textContent = cachedEst;
                        } else {
                            // No cached estimate available. Do not stomp a valid number.
                            // Leave whatever is already rendered (e.g. an earlier server-side value).
                        }
                    }
                }


                // Keep the right-hand summary in sync.
                if (summaryTrig) {
                    var tl = getSelectLabel(trigger);
                    summaryTrig.textContent = tl || "—";
                }
                if (summarySeg) {
                    var sl = getSelectLabel(seg);
                    summarySeg.textContent = sl || "—";
                }

                // Trigger-specific explanation line.
                var trigExplain = document.getElementById("pmcpc_trigger_explain");
                if (trigExplain) {
                    var explain = "";
                    if (trig === "none") explain = "Manual/scheduled: sends when you click Queue or at a chosen date/time.";
                    else if (trig === "welcome") explain = "Automated: sends when someone joins your mailing list.";
                    else if (trig === "welcome_follow_up") explain = "Automated: sends a few days after someone joins your mailing list.";
                    else if (trig === "post_purchase") explain = "Automated: sends after a WooCommerce order is completed.";
                    else if (trig === "new_customer") explain = "Automated: sends when a customer places their first completed order.";
					else if (trig === "repeat_customer") explain = "Automated: sends when a customer completes their second (or later) order.";
					else if (trig === "high_value") explain = "Automated: sends when a customer crosses your high-value lifetime spend threshold.";
					else if (trig === "vip_customer") explain = "Automated: sends when a customer crosses your VIP lifetime spend threshold.";
                    else if (trig === "customer_inactive") explain = "Automated: sends when a customer has not ordered for your chosen number of days.";
                    else if (trig === "lapsed_high_value_customer") explain = "Automated: sends when a high-value customer has not ordered for 90+ days.";
                    trigExplain.textContent = explain;
                }

                // Keep preview link updated on the Review step.
                var previewLink = document.getElementById("pmcpc_review_preview_link");
                if (previewLink) {
                    var currentHref = previewLink.getAttribute("href") || "";
	                    // If PHP already rendered a real preview URL (with nonce), do not override it.
                    if (currentHref && currentHref !== "#" && currentHref.indexOf("_wpnonce=") !== -1) {
                        // no-op
                    } else {
                    // Point to the built-in server-side preview (pmcpc_preview=1).
                    try {
                        var u = new URL(window.location.href);
                        var cid = u.searchParams.get("campaign_id") || u.searchParams.get("id") || "";
                        if (cid) {
                            u.searchParams.set("page", "pmcpc_campaigns");
                            u.searchParams.set("campaign_id", cid);
                            u.searchParams.set("pmcpc_preview", "1");
                            // Clean up legacy params that are not used by the preview handler.
                            u.searchParams.delete("action");
                            u.searchParams.delete("id");
                            previewLink.href = u.toString();
                        }
                    } catch(e) {
                        // Leave the server-rendered href intact.
                    }
                    }
                }

                // Default visibility: show everything, then selectively hide.
                if (sourceTags) setRowVisible(sourceTags, true);
                if (lifeTags) setRowVisible(lifeTags, true);
                if (seg) setRowVisible(seg, true);
                if (prodSource) setRowVisible(prodSource, true);

                // Audience advanced filters toggle.
                // Use a row-class toggle so the UI still works even if individual field IDs change.
                var advOn = advAudience ? !!advAudience.checked : false;
                var advRows = document.querySelectorAll("tr.pmcpc-audience-advanced");
                if (advRows && advRows.length) {
                    advRows.forEach(function(tr){ tr.style.display = advOn ? "" : "none"; });
                } else {
                    // Fallback for older markup.
                    if (targetTag) setRowVisible(targetTag, advOn);
                    if (excludeTags) setRowVisible(excludeTags, advOn);
                    if (sourceTags) setRowVisible(sourceTags, advOn);
                    if (lifeTags) setRowVisible(lifeTags, advOn);
                }

                // Schedule controls only apply to manual/scheduled campaigns.
                // For any event-based trigger, hide the schedule row to avoid confusion.
                var showSchedule = (trig === "none");
                if (scheduleType) {
                    if (!showSchedule) {
                        // Prevent a previously saved schedule from being interpreted alongside an automation trigger.
                        scheduleType.value = "manual";
                    }
                    setRowVisible(scheduleType, showSchedule);
                }

                // Allow trigger selection. Scheduling is only relevant when using the manual/scheduled trigger.
                setRowMuted(trigger, false);

	                // Segment is an optional *eligibility* filter (applied when the trigger fires).
	                // To keep the mental model simple, default to "All subscribers" for all triggers
	                // unless the user explicitly picks a narrower segment.
	                if (seg && !segTouched) {
	                    try { seg.value = ""; } catch(e) {}
	                }


                warn.style.display = "none";
                warn.innerHTML = "";
                var warnings = [];

                summary.innerHTML = "<span class=\"pmcpc-campaign-summary-pill\">Campaign</span> Choose a trigger (optional), schedule, and audience filters.";

                // Products block specific IDs field: only relevant if specific.
                var specificIds = $("pmcpc_product_block_specific_ids");
                if (specificIds && prodSource) {
                    setRowMuted(specificIds, (getVal(prodSource) !== "specific"));
                }
                var catSelect = $("pmcpc_product_block_categories");
                if (catSelect && prodSource) {
                    setRowMuted(catSelect, (getVal(prodSource) === "specific"));
                }

                // Lifecycle tags sanity check: prevent conflicting states.
                if (lifeTags) {
                    var lt = getVal(lifeTags).toLowerCase();
                    if (lt.indexOf("new_customer") !== -1 && lt.indexOf("repeat_customer") !== -1) {
                        warnings.push("Lifecycle tags look conflicting (new_customer + repeat_customer). Subscribers should have only one lifecycle state at a time.");
                    }
                }

	                // Tip: for automations, the trigger already targets an individual subscriber.
	                // Use segments only if you want to further restrict eligibility (e.g. VIPs only).
	                if (trigger && getVal(trigger) !== "none" && seg && getVal(seg) === "") {
	                    // Note: avoid single quotes here because this script is output inside a single-quoted PHP string.
	                    warnings.push("Tip: this is an automation trigger. Leave Eligibility as All subscribers unless you want to further restrict who qualifies when the trigger fires." );
	                }

                if (warnings.length){
                    warn.style.display = "block";
                    warn.innerHTML = "<strong>Check:</strong> <ul style=\"margin:6px 0 0 1.2em;list-style:disc\"><li>" + warnings.join("</li><li>") + "</li></ul>";
                }
            }

            // Live recipient preview (approximate).
            var recipientTimer = null;
            function scheduleRecipientUpdate(){
                if (!recipientNum) return;
                if (typeof currentStage !== "undefined" && currentStage < 3) return;
                if (trigger && (getVal(trigger) || "none") !== "none") return;
                if (recipientTimer) { clearTimeout(recipientTimer); }
                recipientTimer = setTimeout(updateRecipientCount, 350);
            }

            function updateRecipientCount(){
                if (!recipientNum) return;
                if (typeof currentStage !== "undefined" && currentStage < 3) {
                    recipientNum.textContent = "Configure audience to calculate";
                    return;
                }
                if (trigger && (getVal(trigger) || "none") !== "none") {
                    recipientNum.textContent = "Event-based";
                    return;
                }
                // If we do not have an AJAX nonce, do not overwrite a valid server-rendered estimate.
                // Many installs intentionally disable the AJAX endpoint; the Audience step still
                // renders a correct estimate server-side.
                if (!ajaxNonce) { return; }

                recipientNum.textContent = "…";

                var post = new FormData();
                post.append("action", "pmcpc_recipient_count");
                post.append("nonce", ajaxNonce);

                var params = new URLSearchParams(window.location.search);
                var cid = params.get("campaign_id");
                if (cid) {
                    post.append("campaign_id", cid);
                } else {
                    var fields = {
                        target_tag: $("pmcpc_target_tag"),
                        exclude_tags: $("pmcpc_exclude_tags"),
                        target_source_tags: $("pmcpc_target_source_tags"),
                        target_origin_tags: $("pmcpc_target_origin_tags"),
                        target_lifecycle_tags: $("pmcpc_target_lifecycle_tags"),
                        pro_segment_key: $("pmcpc_recipient_segment"),
                        automation_trigger: $("pmcpc_automation_trigger")
                    };
                    Object.keys(fields).forEach(function(k){
                        var el = fields[k];
                        post.append(k, el ? (el.value || "") : "");
                    });
                }

                var endpoint = (typeof window.ajaxurl !== "undefined") ? window.ajaxurl : "admin-ajax.php";
                fetch(endpoint, { method: "POST", credentials: "same-origin", body: post })
                    .then(function(r){ return r.json(); })
                    .then(function(res){
                        if (res && res.success && res.data && typeof res.data.count !== "undefined") {
                            recipientNum.textContent = String(res.data.count);
                        }
                    })
                    .catch(function(){ /* keep existing */ });
            }

            // Reset button: apply safe, recommended defaults (does not overwrite name/subject/content).
            function applyRecommendedDefaults(){
                // Conservative reset: keep users goal/audience/product choices, but put timing back to safe defaults.
                if (trigger) trigger.value = "none";
                if (scheduleType) scheduleType.value = "manual";
            }

            if (resetBtn) {
                resetBtn.addEventListener("click", function(){
                    applyRecommendedDefaults();
                    update();
                    scheduleRecipientUpdate();
                });
            }

            [trigger, scheduleType, scheduleDate, scheduleTime, schedFreq, advAudience, targetTag, excludeTags, prodEnabled, prodSource, sourceTags, lifeTags, seg].forEach(function(el){
                if (!el) return;
                el.addEventListener("change", update);
                el.addEventListener("keyup", update);
                el.addEventListener("change", scheduleRecipientUpdate);
                el.addEventListener("keyup", scheduleRecipientUpdate);
            });
            document.addEventListener("DOMContentLoaded", function(){
                initStages();
                update();
                updateRecipientCount();
            });
            // Fallback for admin pages where DOMContentLoaded has already fired.
            try { initStages(); } catch(e) {}
            update();
            scheduleRecipientUpdate();
        })();
        </script>';

        // Inline confirmation bar for "Queue Broadcast" (no modal).
        echo '<div id="pmcpc_queue_confirm" class="notice notice-warning" style="display:none;margin:12px 0;padding:12px;">';
        echo '<p style="margin:0 0 8px;">' . esc_html__( 'You are about to queue this campaign for sending.', 'product-mailer-campaigns' ) . ' <span id="pmcpc_queue_confirm_count" style="font-weight:600"></span></p>';
        echo '<p style="margin:0;">';
        echo '<a href="#" class="button button-primary" id="pmcpc_queue_confirm_go">' . esc_html__( 'Confirm queue broadcast', 'product-mailer-campaigns' ) . '</a> ';
        echo '<button type="button" class="button" id="pmcpc_queue_confirm_cancel">' . esc_html__( 'Cancel', 'product-mailer-campaigns' ) . '</button>';
        echo '</p>';
        echo '</div>';

        echo '<script>(function(){
            var $ = function(id){return document.getElementById(id);};
            var box = $("pmcpc_queue_confirm");
            var go = $("pmcpc_queue_confirm_go");
            var cancel = $("pmcpc_queue_confirm_cancel");
            var countEl = $("pmcpc_queue_confirm_count");
            function nonce(){ var n = $("pmcpc_recipient_count_nonce"); return n ? (n.value||"") : ""; }
            function hide(){ if(box) box.style.display = "none"; if(go) go.setAttribute("href", "#"); }
            if (cancel) cancel.addEventListener("click", function(e){ e.preventDefault(); hide(); });
            document.addEventListener("click", function(e){
                var a = e.target && e.target.closest ? e.target.closest("a.pmcpc-queue-broadcast") : null;
                if (!a) return;
                if (!box || !go) return;
                e.preventDefault();
                var href = a.getAttribute("href") || "#";
                var cid = a.getAttribute("data-campaign-id") || "";
                go.setAttribute("href", href);
                box.style.display = "block";
                if (countEl) countEl.textContent = "";
                var n = nonce();
                if (!n || !cid || !window.fetch) { return; }
                if (countEl) countEl.textContent = "(" + "…" + " recipients)";
                var post = new FormData();
                post.append("action", "pmcpc_recipient_count");
                post.append("nonce", n);
                post.append("campaign_id", cid);
                var endpoint = (typeof window.ajaxurl !== "undefined") ? window.ajaxurl : "admin-ajax.php";
                fetch(endpoint, { method: "POST", credentials: "same-origin", body: post })
                    .then(function(r){ return r.json(); })
                    .then(function(res){
                        if (!countEl) return;
                        if (res && res.success && res.data && typeof res.data.count !== "undefined") {
                            countEl.textContent = "(" + String(res.data.count) + " recipients)";
                        } else {
                            countEl.textContent = "";
                        }
                    })
                    .catch(function(){ if(countEl) countEl.textContent = ""; });
            });
        })();</script>';


