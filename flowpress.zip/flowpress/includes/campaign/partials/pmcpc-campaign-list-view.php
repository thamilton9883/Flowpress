<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

            // Shared wrapper, page title, tabs, and primary actions are rendered by the admin shell.

            // Lightweight accordion UI for grouped automations (e.g. abandoned cart steps).
            // Kept inline to avoid adding new build assets.
            echo '<style>
                .pmcpc-campaign-page-actions{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:0 0 18px;}
                .pmcpc-campaign-list-toolbar{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;flex-wrap:wrap;margin:0 0 18px;}
                .pmcpc-campaign-list-toolbar .subsubsub{float:none;margin:0;}
                .pmcpc-campaign-list-toolbar .pmcpc-campaign-list-toolbar__hint{max-width:420px;color:#646970;margin:0;font-size:13px;line-height:1.5;}
                .pmcpc-campaign-table-wrap{border:1px solid #dcdcde;border-radius:16px;background:#fff;box-shadow:0 10px 24px rgba(15,23,42,.04);overflow:hidden;}
                .pmcpc-campaign-table-wrap__scroll{overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch;max-width:100%;scrollbar-gutter:stable both-edges;padding-bottom:2px;}
                .pmcpc-campaign-table-wrap table{margin:0;border:none;}
                .pmcpc-campaign-table-wrap th,.pmcpc-campaign-table-wrap td{vertical-align:top;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns{min-width:0;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns col.pmcpc-campaign-col-name{width:300px;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns col.pmcpc-campaign-col-status,
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns col.pmcpc-campaign-col-ready{width:110px;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns col.pmcpc-campaign-col-mode,
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns col.pmcpc-campaign-col-audience{width:180px;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns col.pmcpc-campaign-col-schedule{width:160px;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns col.pmcpc-campaign-col-next,
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns col.pmcpc-campaign-col-created{width:150px;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns col.pmcpc-campaign-col-actions{width:190px;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns th,
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns td{text-align:left;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns th.pmcpc-col-compare,
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns td.pmcpc-col-compare{text-align:left;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns th.pmcpc-col-actions,
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns td.pmcpc-col-actions{text-align:right;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns td.pmcpc-col-meta .pmcpc-table-cell-stack,
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns td.pmcpc-col-meta .pmcpc-table-record{min-width:0;max-width:none;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns td.pmcpc-col-meta .pmcpc-table-cell-stack__main,
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns td.pmcpc-col-meta .pmcpc-table-cell-stack__sub{display:block;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns td.pmcpc-col-actions .pmcpc-table-actions{min-width:0;max-width:none;}
                .pmcpc-campaign-name{display:flex;flex-direction:column;gap:4px;min-width:190px;}
                .pmcpc-campaign-name__subject{color:#646970;font-size:12px;line-height:1.45;}
                .pmcpc-campaign-badge{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;border:1px solid #dcdcde;background:#f6f7f7;font-size:12px;font-weight:600;line-height:1.2;}
                .pmcpc-campaign-badge--status-scheduled,.pmcpc-campaign-badge--ready{background:#ecfdf3;border-color:#9dd4ac;color:#166534;}
                .pmcpc-campaign-badge--status-queued,.pmcpc-campaign-badge--status-active{background:#eff6ff;border-color:#93c5fd;color:#1d4ed8;}
                .pmcpc-campaign-badge--status-draft,.pmcpc-campaign-badge--status-inactive{background:#f8fafc;border-color:#cbd5e1;color:#475569;}
                .pmcpc-campaign-badge--status-completed{background:#faf5ff;border-color:#d8b4fe;color:#7c3aed;}
                .pmcpc-campaign-badge--warn{background:#fff7ed;border-color:#fdba74;color:#c2410c;}
                .pmcpc-campaign-badge--blocked{background:#fff1f2;border-color:#fda4af;color:#be123c;}
                .pmcpc-campaign-meta{display:flex;flex-direction:column;gap:5px;min-width:150px;}
                .pmcpc-campaign-meta__label{font-size:12px;font-weight:600;color:#111827;}
                .pmcpc-campaign-meta__text{font-size:12px;color:#646970;line-height:1.5;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns > thead > tr > th:last-child{width:1%;white-space:nowrap;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns > tbody > tr > td:last-child{background:linear-gradient(180deg,#fcfcfd 0%,#f8fafc 100%);border-left:1px solid #eef2f6;}
                .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns > tbody > tr > td.pmcpc-workflow-detail{background:#fff;border-left:none;}
                .pmcpc-campaign-actions{display:flex;flex-direction:column;gap:8px;min-width:176px;max-width:196px;}
                .pmcpc-campaign-viewbar{display:flex;flex-wrap:wrap;gap:10px 14px;align-items:center;justify-content:space-between;margin:12px 0 12px;padding:12px 14px;background:#fff;border:1px solid #dcdcde;border-radius:12px;}
                .pmcpc-campaign-viewbar__label{font-weight:600;color:#1d2327;}
                .pmcpc-campaign-viewbar__controls{display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center;}
                .pmcpc-campaign-viewbar__check{display:inline-flex;align-items:center;gap:6px;color:#3c434a;}
                .pmcpc-campaign-col-hidden{display:none !important;}
                .pmcpc-acc-header{background:#f6f7f7;}
                .pmcpc-workflow-parent td{background:#f8fbff;border-top:1px solid #d7e7ff;border-bottom:1px solid #d7e7ff;}
                .pmcpc-workflow-title{display:flex;flex-direction:column;gap:4px;}
                .pmcpc-workflow-title__main{display:flex;align-items:center;gap:8px;font-weight:700;}
                .pmcpc-workflow-summary{font-size:12px;color:#646970;line-height:1.45;}
                .pmcpc-workflow-actions{display:flex;flex-wrap:wrap;gap:6px;justify-content:flex-end;}
                .pmcpc-workflow-detail{padding:16px;background:#fff;overflow-x:auto;}
                .pmcpc-workflow-detail__intro{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;margin:0 0 12px;}
                .pmcpc-workflow-detail__intro p{margin:0;color:#50575e;}
                .pmcpc-workflow-steps{width:100%;min-width:820px;table-layout:fixed;border:1px solid #dcdcde;border-radius:12px;overflow:hidden;border-collapse:separate;border-spacing:0;background:#fff;}
                .pmcpc-workflow-steps th,.pmcpc-workflow-steps td{padding:10px 12px;border-bottom:1px solid #f0f0f1;vertical-align:top;text-align:left;word-break:normal;overflow-wrap:normal;}
                .pmcpc-workflow-steps th{white-space:nowrap;}
                .pmcpc-workflow-steps th:nth-child(1),.pmcpc-workflow-steps td:nth-child(1){width:100px;}
                .pmcpc-workflow-steps th:nth-child(2),.pmcpc-workflow-steps td:nth-child(2){width:110px;}
                .pmcpc-workflow-steps th:nth-child(4),.pmcpc-workflow-steps td:nth-child(4),.pmcpc-workflow-steps th:nth-child(5),.pmcpc-workflow-steps td:nth-child(5){width:120px;}
                .pmcpc-workflow-steps th:nth-child(6),.pmcpc-workflow-steps td:nth-child(6){width:250px;}
                .pmcpc-workflow-steps tr:last-child td{border-bottom:none;}
                .pmcpc-workflow-step-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center;justify-content:flex-start;min-width:220px;}
                .pmcpc-workflow-step-actions a{display:inline-flex;white-space:nowrap;word-break:normal;overflow-wrap:normal;}
                .pmcpc-workflow-missing{background:#fffaf0;}
                .pmcpc-acc-toggle{display:flex;align-items:center;gap:8px;text-decoration:none;}
                .pmcpc-acc-toggle .dashicons{transition:transform .15s ease;}
                .pmcpc-acc-header.is-open .pmcpc-acc-toggle .dashicons{transform:rotate(90deg);}
                tr.pmcpc-acc-row{display:none;}
                tr.pmcpc-acc-row.is-open{display:table-row;}
                .pmcpc-acc-subtle{color:#646970;font-size:12px;}
                .pmcpc-insight-panel{padding:8px 0;}
                .pmcpc-insight-columns{display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap;}
                .pmcpc-insight-col{min-width:280px;flex:1 1 320px;}
                .pmcpc-insight-list{margin:0;padding-left:18px;}
                .pmcpc-insight-list li{margin:0 0 10px 0;}
                .pmcpc-insight-meta{color:#646970;}
                @media (max-width:782px){
                    .pmcpc-campaign-page-actions{flex-direction:column;align-items:stretch;}
                    .pmcpc-campaign-page-actions .button{width:100%;justify-content:center;}
                    .pmcpc-campaign-list-toolbar{align-items:stretch;}
                    .pmcpc-campaign-actions{min-width:0;}
                    .pmcpc-campaign-table-wrap .pmcpc-wide-table--campaigns > tbody > tr > td:last-child{background:transparent;border-left:none;}
                }
            </style>';
            echo '<script>document.addEventListener("click",function(e){var btn=e.target.closest(".pmcpc-insight-toggle");if(btn){e.preventDefault();var targetId=btn.getAttribute("aria-controls");if(!targetId){return;}var row=document.getElementById(targetId);if(!row){return;}var expanded=btn.getAttribute("aria-expanded")=="true";btn.setAttribute("aria-expanded", expanded ? "false" : "true");row.style.display=expanded?"none":"table-row";btn.textContent=expanded?' . wp_json_encode( __( 'Trigger insight', 'product-mailer-campaigns' ) ) . ':' . wp_json_encode( __( 'Hide insight', 'product-mailer-campaigns' ) ) . ';return;}var reset=e.target.closest(".pmcpc-campaign-columns-reset");if(reset){e.preventDefault();localStorage.removeItem("pmcpc_campaign_hidden_columns");document.querySelectorAll(".pmcpc-campaign-column-toggle").forEach(function(box){box.checked=true;});document.querySelectorAll("[class*=pmcpc-campaign-col-toggle-]").forEach(function(el){el.classList.remove("pmcpc-campaign-col-hidden");});}});document.addEventListener("change",function(e){var box=e.target.closest(".pmcpc-campaign-column-toggle");if(!box){return;}var key=box.getAttribute("data-column");if(!key){return;}var hidden=[];try{hidden=JSON.parse(localStorage.getItem("pmcpc_campaign_hidden_columns")||"[]");}catch(err){hidden=[];}hidden=hidden.filter(function(x){return x!==key;});if(!box.checked){hidden.push(key);}localStorage.setItem("pmcpc_campaign_hidden_columns",JSON.stringify(hidden));document.querySelectorAll(".pmcpc-campaign-col-toggle-"+key).forEach(function(el){el.classList.toggle("pmcpc-campaign-col-hidden",!box.checked);});});document.addEventListener("DOMContentLoaded",function(){var hidden=[];try{hidden=JSON.parse(localStorage.getItem("pmcpc_campaign_hidden_columns")||"[]");}catch(err){hidden=[];}hidden.forEach(function(key){document.querySelectorAll(".pmcpc-campaign-col-toggle-"+key).forEach(function(el){el.classList.add("pmcpc-campaign-col-hidden");});var box=document.querySelector(".pmcpc-campaign-column-toggle[data-column=\'"+key+"\']");if(box){box.checked=false;}});});</script>';

            echo '<script>
                (function(){
                    function closest(el, sel){
                        while(el && el.nodeType===1){
                            if(el.matches && el.matches(sel)) return el;
                            el = el.parentNode;
                        }
                        return null;
                    }
                    function openGroup(group, scroll){
                        if(!group) return;
                        var header = document.querySelector("tr.pmcpc-acc-header[data-pmcpc-acc=\""+group+"\"]");
                        if(header) header.classList.add("is-open");
                        var rows = document.querySelectorAll("tr.pmcpc-acc-row[data-pmcpc-acc=\""+group+"\"]");
                        rows.forEach(function(r){ r.classList.add("is-open"); });
                        if(scroll && header && header.scrollIntoView){ header.scrollIntoView({behavior:"smooth", block:"center"}); }
                    }
                    document.addEventListener("click", function(e){
                        var a = closest(e.target, "a.pmcpc-acc-toggle");
                        if(!a) return;
                        e.preventDefault();
                        var group = a.getAttribute("data-pmcpc-acc");
                        if(!group) return;
                        var tr = closest(a, "tr");
                        if(tr) tr.classList.toggle("is-open");
                        var rows = document.querySelectorAll("tr.pmcpc-acc-row[data-pmcpc-acc=\""+group+"\"]");
                        rows.forEach(function(r){ r.classList.toggle("is-open"); });
                    });
                    document.addEventListener("DOMContentLoaded", function(){
                        try {
                            var params = new URLSearchParams(window.location.search || "");
                            var group = (params.get("pmcpc_open_acc") || "").trim();
                            if(group){ openGroup(group, true); }
                        } catch(err) {}
                    });
                })();
            </script>';
            // Render the campaigns list below.
$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'all';

        // Group campaigns into sections for easier review.
        $groups = array(
            'automation' => array(),
            'one_time'   => array(),
            'weekly'     => array(),
            'recurring'  => array(),
            'manual'     => array(),
        );

        foreach ( (array) $campaigns as $c ) {
            $is_automation = ( ! empty( $c->is_welcome ) || ! empty( $c->is_post_purchase ) || ( isset( $c->automation_trigger ) && '' !== (string) $c->automation_trigger && 'none' !== (string) $c->automation_trigger ) );

            if ( $is_automation ) {
                $groups['automation'][] = $c;
                continue;
            }

            $schedule_type = isset( $c->schedule_type ) ? $c->schedule_type : 'manual';
            $freq          = isset( $c->schedule_frequency ) ? $c->schedule_frequency : '';

            if ( 'one_time' === $schedule_type ) {
                $groups['one_time'][] = $c;
            } elseif ( 'recurring' === $schedule_type && 'weekly' === $freq ) {
                $groups['weekly'][] = $c;
            } elseif ( 'recurring' === $schedule_type ) {
                $groups['recurring'][] = $c;
            } else {
                $groups['manual'][] = $c;
            }
        }


        if ( isset( $pmcpc_recent_automation_timeline ) && is_callable( $pmcpc_recent_automation_timeline ) ) {
            $timeline_items = $pmcpc_recent_automation_timeline( 8 );
            if ( ! empty( $timeline_items ) ) {
                echo '<div class="pmcpc-automation-timeline" style="margin:14px 0 18px 0;padding:12px 14px;border:1px solid #ccd0d4;background:#fff;">';
                echo '<h3 style="margin:0 0 8px 0;">' . esc_html__( 'Recent automation events', 'product-mailer-campaigns' ) . '</h3>';
                echo '<ul style="margin:0;padding-left:18px;">';
                foreach ( $timeline_items as $timeline_item ) {
                    $email = ! empty( $timeline_item->to_email ) ? sanitize_email( (string) $timeline_item->to_email ) : '';
                    $status = ! empty( $timeline_item->status ) ? ucfirst( sanitize_text_field( (string) $timeline_item->status ) ) : __( 'Queued', 'product-mailer-campaigns' );
                    $title = ! empty( $timeline_item->name ) ? sanitize_text_field( (string) $timeline_item->name ) : ( ! empty( $timeline_item->subject ) ? sanitize_text_field( (string) $timeline_item->subject ) : __( 'Automation email', 'product-mailer-campaigns' ) );
                    $when = ! empty( $timeline_item->activity_at ) ? mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (string) $timeline_item->activity_at ) : '';
                    echo '<li style="margin:0 0 6px 0;"><strong>' . esc_html( $when ? $when : __( 'Recent', 'product-mailer-campaigns' ) ) . '</strong> — ' . esc_html( $title ) . ( $email ? ' — ' . esc_html( $email ) : '' ) . ' — ' . esc_html( $status ) . '</li>';
                }
                echo '</ul>';
                echo '</div>';
            }
        }

        // Default ordering: for one-time scheduled campaigns, show the soonest upcoming send first.
        // (The main query can be sorted globally, but the grouped list needs an explicit order.)
        if ( ! empty( $groups['one_time'] ) ) {
            usort(
                $groups['one_time'],
                function ( $a, $b ) {
                    $status_a = isset( $a->status ) ? (string) $a->status : '';
                    $status_b = isset( $b->status ) ? (string) $b->status : '';

                    // Rank: scheduled first, then draft/manual, then completed last.
                    $rank = function ( $s ) {
                        if ( 'scheduled' === $s || 'queued' === $s ) {
                            return 0;
                        }
                        if ( 'completed' === $s ) {
                            return 2;
                        }
                        return 1;
                    };

                    $ra = $rank( $status_a );
                    $rb = $rank( $status_b );
                    if ( $ra !== $rb ) {
                        return $ra - $rb;
                    }

                    // Compare by next run timestamp (UTC), falling back to schedule_datetime.
                    $ts = function ( $c ) {
                        $dt = '';
                        if ( ! empty( $c->next_run_at ) ) {
                            $dt = (string) $c->next_run_at;
                        } elseif ( ! empty( $c->schedule_datetime ) ) {
                            $dt = (string) $c->schedule_datetime;
                        }
                        if ( '' === $dt ) {
                            return 0;
                        }
                        try {
                            return ( new DateTimeImmutable( $dt, new DateTimeZone( 'UTC' ) ) )->getTimestamp();
                        } catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
                            return 0;
                        }
                    };

                    $ta = $ts( $a );
                    $tb = $ts( $b );
                    if ( $ta && $tb && $ta !== $tb ) {
                        return ( $ta < $tb ) ? -1 : 1;
                    }

                    // Stable fallback: newest first.
                    $ca = isset( $a->created_at ) ? strtotime( (string) $a->created_at ) : 0;
                    $cb = isset( $b->created_at ) ? strtotime( (string) $b->created_at ) : 0;
                    if ( $ca !== $cb ) {
                        return ( $ca > $cb ) ? -1 : 1;
                    }

                    return (int) $a->id - (int) $b->id;
                }
            );
        }

        $counts = array(
            'all'        => count( (array) $campaigns ),
            'automation' => count( $groups['automation'] ),
            'one_time'   => count( $groups['one_time'] ),
            'weekly'     => count( $groups['weekly'] ),
            'recurring'  => count( $groups['recurring'] ),
            'manual'     => count( $groups['manual'] ),
        );

        // Labels shown above the campaign list. Keep them user-friendly and consistent with the builder.
        $views = array(
            'all'        => __( 'All', 'product-mailer-campaigns' ),
            'automation' => __( 'Automations', 'product-mailer-campaigns' ),
            'one_time'   => __( 'One-time scheduled', 'product-mailer-campaigns' ),
            'weekly'     => __( 'Weekly (recurring)', 'product-mailer-campaigns' ),
            'recurring'  => __( 'Recurring', 'product-mailer-campaigns' ),
            'manual'     => __( 'Manual / drafts', 'product-mailer-campaigns' ),
        );

        PMCPC_Admin::render_stats_strip(
            array(
                array(
                    'label' => __( 'All campaigns', 'product-mailer-campaigns' ),
                    'value' => (string) $counts['all'],
                    'meta'  => __( 'Everything in this workspace', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Manual & drafts', 'product-mailer-campaigns' ),
                    'value' => (string) $counts['manual'],
                    'meta'  => __( 'Create, edit, and queue manually', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Scheduled', 'product-mailer-campaigns' ),
                    'value' => (string) ( $counts['one_time'] + $counts['weekly'] + $counts['recurring'] ),
                    'meta'  => __( 'One-time and recurring sends', 'product-mailer-campaigns' ),
                ),
                array(
                    'label' => __( 'Automations', 'product-mailer-campaigns' ),
                    'value' => (string) $counts['automation'],
                    'meta'  => __( 'Event-driven workflows', 'product-mailer-campaigns' ),
                ),
            )
        );

        echo '<div class="pmcpc-campaign-page-actions">';
        echo '<a class="button button-primary" href="' . esc_url( $create_campaign_url ) . '">' . esc_html__( 'New Campaign', 'product-mailer-campaigns' ) . '</a>';
        echo '<a class="button" href="' . esc_url( $create_automation_url ) . '">' . esc_html__( 'New Automation', 'product-mailer-campaigns' ) . '</a>';
        echo '</div>';

        echo '<div class="pmcpc-campaign-list-toolbar">';
        echo '<div>';
        echo '<ul class="subsubsub">';
        $i = 0;
        foreach ( $views as $key => $label ) {
            $i++;
            $url = add_query_arg(
                array(
                    'page' => 'pmcpc_campaigns',
                    'view' => $key,
                ),
                admin_url( 'admin.php' )
            );
            $class = ( $view === $key ) ? 'current' : '';
            echo '<li><a class="' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . ' <span class="count">(' . (int) $counts[ $key ] . ')</span></a>';
            echo ( $i < count( $views ) ) ? ' | ' : '';
            echo '</li>';
        }
        echo '</ul>';
        echo '</div>';
        echo '<p class="pmcpc-campaign-list-toolbar__hint">' . esc_html__( 'Start with New Campaign for one-off or scheduled emails. Use New Automation when an email should send automatically. Then preview, test, queue, or edit from the row actions.', 'product-mailer-campaigns' ) . '</p>';
        echo '</div>';
        // The .subsubsub list uses floats in wp-admin; clear them so headings/tables don't overlap.
        echo '<br class="clear" />';

        // Table header helper for sortable columns.
		// Match the default SQL ordering above.
		$current_orderby = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : 'next_run_at';
		$current_order   = isset( $_GET['order'] ) ? strtoupper( sanitize_key( wp_unslash( $_GET['order'] ) ) ) : 'ASC';
        if ( 'ASC' !== $current_order ) {
            $current_order = 'DESC';
        }

        $sort_link = function( $col ) use ( $view, $current_orderby, $current_order ) {
            $next_order = 'ASC';
            // Keep next-run ordering soonest-first.
            if ( 'next_run_at' !== $col && $current_orderby === $col && 'ASC' === $current_order ) {
                $next_order = 'DESC';
            }
            return add_query_arg(
                array(
                    'page'    => 'pmcpc_campaigns',
                    'view'    => $view,
                    'orderby' => $col,
                    'order'   => $next_order,
                ),
                admin_url( 'admin.php' )
            );
        };

        $is_woocommerce_automation = function( $campaign_row ) {
            $trigger_key = isset( $campaign_row->automation_trigger ) ? trim( (string) $campaign_row->automation_trigger ) : '';
            if ( ! empty( $campaign_row->is_post_purchase ) ) {
                $trigger_key = 'post_purchase';
            }
            $woo_triggers = array(
                'post_purchase',
                'review_request',
                'new_customer',
                'repeat_customer',
                'customer_inactive',
                'lapsed_high_value_customer',
                'high_value_customer',
                'high_value',
                'vip_customer',
                'vip',
                'abandoned_cart_step_1',
                'abandoned_cart_step_2',
                'abandoned_cart_step_3',
            );
            return in_array( $trigger_key, $woo_triggers, true );
        };

        $format_audience_summary = function( $campaign_row ) {
            $parts = array();

            $append_csv = function( $label, $value ) use ( &$parts ) {
                $value = trim( (string) $value );
                if ( '' === $value ) {
                    return;
                }
                $items = array_filter( array_map( 'trim', explode( ',', $value ) ) );
                if ( empty( $items ) ) {
                    return;
                }
                $parts[] = sprintf( '%s: %s', $label, implode( ', ', $items ) );
            };

            $append_single = function( $label, $value ) use ( &$parts ) {
                $value = trim( (string) $value );
                if ( '' === $value || 'all' === strtolower( $value ) || 'any' === strtolower( $value ) ) {
                    return;
                }
                $parts[] = sprintf( '%s: %s', $label, $value );
            };

            $append_csv( __( 'Interest', 'product-mailer-campaigns' ), isset( $campaign_row->target_tag ) ? $campaign_row->target_tag : '' );
            $append_csv( __( 'Exclude', 'product-mailer-campaigns' ), isset( $campaign_row->exclude_tags ) ? $campaign_row->exclude_tags : '' );
            $append_csv( __( 'Source', 'product-mailer-campaigns' ), isset( $campaign_row->target_source_tags ) ? $campaign_row->target_source_tags : '' );
            $append_csv( __( 'Origin', 'product-mailer-campaigns' ), isset( $campaign_row->target_origin_tags ) ? $campaign_row->target_origin_tags : '' );
            $append_csv( __( 'Lifecycle', 'product-mailer-campaigns' ), isset( $campaign_row->target_lifecycle_tags ) ? $campaign_row->target_lifecycle_tags : '' );
            $append_single( __( 'Eligibility', 'product-mailer-campaigns' ), isset( $campaign_row->segment ) ? $campaign_row->segment : '' );

            if ( empty( $parts ) ) {
                return __( 'All subscribers', 'product-mailer-campaigns' );
            }

            return implode( ' • ', $parts );
        };


        $pmcpc_resolve_campaign_trigger_label = function( $trigger_key ) {
            $map = array(
                'new_subscriber'       => __( 'Welcome automation', 'product-mailer-campaigns' ),
                'new_subscribers'      => __( 'Welcome automation', 'product-mailer-campaigns' ),
                'welcome'              => __( 'Welcome automation', 'product-mailer-campaigns' ),
                'welcome_follow_up'    => __( 'Welcome follow-up automation', 'product-mailer-campaigns' ),
                'lead_magnet_download' => __( 'Lead magnet delivery automation', 'product-mailer-campaigns' ),
                'subscriber_inactive'  => __( 'Subscriber inactive automation', 'product-mailer-campaigns' ),
                'subscriber_anniversary' => __( 'Subscriber anniversary automation', 'product-mailer-campaigns' ),
                'subscriber_birthday'  => __( 'Subscriber birthday automation', 'product-mailer-campaigns' ),
                'post_purchase'        => __( 'Post-purchase automation', 'product-mailer-campaigns' ),
                'review_request'       => __( 'Review request', 'product-mailer-campaigns' ),
                'new_customer'         => __( 'New customer automation', 'product-mailer-campaigns' ),
                'repeat_customer'      => __( 'Repeat customer automation', 'product-mailer-campaigns' ),
                'high_value_customer'  => __( 'High-value customer automation', 'product-mailer-campaigns' ),
                'high_value'           => __( 'High-value customer automation', 'product-mailer-campaigns' ),
                'lapsed_high_value_customer' => __( 'Lapsed high-value customer automation', 'product-mailer-campaigns' ),
                'vip_customer'         => __( 'VIP customer automation', 'product-mailer-campaigns' ),
                'vip'                  => __( 'VIP customer automation', 'product-mailer-campaigns' ),
                'customer_inactive'    => __( 'Win-back automation', 'product-mailer-campaigns' ),
                'abandoned_cart_step_1' => __( 'Abandoned cart (Step 1)', 'product-mailer-campaigns' ),
                'abandoned_cart_step_2' => __( 'Abandoned cart (Step 2)', 'product-mailer-campaigns' ),
                'abandoned_cart_step_3' => __( 'Abandoned cart (Step 3)', 'product-mailer-campaigns' ),
            );
            $trigger_key = trim( (string) $trigger_key );
            return isset( $map[ $trigger_key ] ) ? $map[ $trigger_key ] : __( 'Automation', 'product-mailer-campaigns' );
        };

        $pmcpc_get_active_subscribers_for_insight = function() {
            global $wpdb;
            static $cache = null;
            if ( null !== $cache ) {
                return $cache;
            }
            $table = $wpdb->prefix . 'pmcpc_subscribers';
            $cache = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$table} WHERE status = %s ORDER BY id ASC",
                    'active'
                )
            );
            if ( ! is_array( $cache ) ) {
                $cache = array();
            }
            return $cache;
        };

        $pmcpc_extract_birthday_parts = function( $subscriber ) {
            if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'get_subscriber_birthday' ) && ! empty( $subscriber->id ) ) {
                $raw = (string) PMCPC_Subscriber_Manager::get_subscriber_birthday( (int) $subscriber->id );
                if ( '' !== $raw && method_exists( 'PMCPC_Subscriber_Manager', 'parse_birthday_parts' ) ) {
                    $parts = (array) PMCPC_Subscriber_Manager::parse_birthday_parts( $raw );
                    if ( ! empty( $parts['month'] ) && ! empty( $parts['day'] ) ) {
                        return array(
                            'month' => (int) $parts['month'],
                            'day'   => (int) $parts['day'],
                            'time'  => ! empty( $parts['time'] ) ? (string) $parts['time'] : '09:00:00',
                        );
                    }
                }
            }
            $candidates = array();
            foreach ( array( 'birthday', 'birthdate', 'birth_date', 'date_of_birth', 'subscriber_birthday', 'profile_birthday', 'pmcpc_birthday' ) as $field ) {
                if ( ! empty( $subscriber->{$field} ) ) {
                    $candidates[] = (string) $subscriber->{$field};
                }
            }
            if ( ! empty( $subscriber->tags ) ) {
                $tags = array_filter( array_map( 'trim', explode( ',', (string) $subscriber->tags ) ) );
                foreach ( $tags as $tag ) {
                    if ( 0 === strpos( strtolower( $tag ), 'birthday:' ) ) {
                        $candidates[] = trim( substr( $tag, 9 ) );
                    }
                }
            }
            foreach ( $candidates as $raw ) {
                if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'parse_birthday_parts' ) ) {
                    $parts = (array) PMCPC_Subscriber_Manager::parse_birthday_parts( $raw );
                    if ( ! empty( $parts['month'] ) && ! empty( $parts['day'] ) ) {
                        return array(
                            'month' => (int) $parts['month'],
                            'day'   => (int) $parts['day'],
                            'time'  => ! empty( $parts['time'] ) ? (string) $parts['time'] : '09:00:00',
                        );
                    }
                }
            }
            return array();
        };

        $pmcpc_next_md_timestamp = function( $month, $day, $time = '09:00:00' ) {
            $month = (int) $month;
            $day   = (int) $day;
            if ( $month <= 0 || $day <= 0 ) {
                return 0;
            }
            try {
                $tz   = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
                $now  = new DateTimeImmutable( 'now', $tz );
                $year = (int) $now->format( 'Y' );
                $candidate = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', sprintf( '%04d-%02d-%02d %s', $year, $month, $day, $time ), $tz );
                if ( ! $candidate ) {
                    return 0;
                }
                if ( $candidate->getTimestamp() < $now->getTimestamp() ) {
                    $candidate = $candidate->modify( '+1 year' );
                }
                return (int) $candidate->getTimestamp();
            } catch ( Exception $e ) {
                return 0;
            }
        };

        $pmcpc_campaign_recent_activity = function( $campaign_id, $limit = 5 ) {
            global $wpdb;
            $queue_table = $wpdb->prefix . 'pmcpc_email_queue';
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT to_email, status, COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), created_at) AS activity_at FROM {$queue_table} WHERE campaign_id = %d ORDER BY COALESCE(NULLIF(updated_at, '0000-00-00 00:00:00'), created_at) DESC, id DESC LIMIT %d",
                    (int) $campaign_id,
                    (int) $limit
                )
            );
            return is_array( $rows ) ? $rows : array();
        };


        $pmcpc_get_trigger_insight_type = function( $campaign_row ) {
            $trigger = isset( $campaign_row->automation_trigger ) ? trim( (string) $campaign_row->automation_trigger ) : '';
            if ( ! empty( $campaign_row->is_welcome ) ) {
                $trigger = 'new_subscriber';
            } elseif ( ! empty( $campaign_row->is_post_purchase ) ) {
                $trigger = 'post_purchase';
            }
            if ( in_array( $trigger, array( 'subscriber_birthday', 'subscriber_anniversary', 'specific_date' ), true ) ) {
                return 'date';
            }
            if ( in_array( $trigger, array( 'subscriber_inactive', 'customer_inactive', 'high_value_customer', 'high_value', 'vip_customer', 'vip', 'new_customer', 'repeat_customer' ), true ) ) {
                return 'lifecycle';
            }
            return 'event';
        };

        $pmcpc_recent_automation_timeline = function( $limit = 8 ) {
            global $wpdb;
            $queue_table = $wpdb->prefix . 'pmcpc_email_queue';
            $campaigns_table = $wpdb->prefix . 'pmcpc_campaigns';
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT q.to_email, q.status, COALESCE(NULLIF(q.updated_at, '0000-00-00 00:00:00'), q.created_at) AS activity_at, c.subject, c.name
                     FROM {$queue_table} q
                     LEFT JOIN {$campaigns_table} c ON c.id = q.campaign_id
                     ORDER BY COALESCE(NULLIF(q.updated_at, '0000-00-00 00:00:00'), q.created_at) DESC, q.id DESC
                     LIMIT %d",
                    (int) $limit
                )
            );
            return is_array( $rows ) ? $rows : array();
        };

        $pmcpc_campaign_upcoming_candidates = function( $campaign_row, $limit = 5 ) use ( $pmcpc_get_active_subscribers_for_insight, $pmcpc_extract_birthday_parts, $pmcpc_next_md_timestamp ) {
            $trigger = isset( $campaign_row->automation_trigger ) ? trim( (string) $campaign_row->automation_trigger ) : '';
            if ( ! empty( $campaign_row->is_welcome ) ) {
                $trigger = 'new_subscriber';
            } elseif ( ! empty( $campaign_row->is_post_purchase ) ) {
                $trigger = 'post_purchase';
            }

            $subscribers = $pmcpc_get_active_subscribers_for_insight();
            if ( empty( $subscribers ) ) {
                return array();
            }

            $items = array();
            $now_ts = current_time( 'timestamp' );
            $inactive_days = class_exists( 'PMCPC_Settings' ) ? (int) PMCPC_Settings::get( 'lifecycle_lapsed_days', '180' ) : 180;
            $high_value_threshold = class_exists( 'PMCPC_Settings' ) ? (float) PMCPC_Settings::get( 'lifecycle_high_value_threshold', '0' ) : 0.0;
            $vip_threshold = class_exists( 'PMCPC_Settings' ) ? (float) PMCPC_Settings::get( 'lifecycle_vip_threshold', '0' ) : 0.0;

            foreach ( $subscribers as $subscriber ) {
                $email = ! empty( $subscriber->email ) ? sanitize_email( (string) $subscriber->email ) : '';
                if ( '' === $email ) {
                    continue;
                }
                switch ( $trigger ) {
                    case 'subscriber_birthday':
                        $birthday = $pmcpc_extract_birthday_parts( $subscriber );
                        if ( empty( $birthday['month'] ) || empty( $birthday['day'] ) ) {
                            continue 2;
                        }
                        $ts = $pmcpc_next_md_timestamp( $birthday['month'], $birthday['day'], ! empty( $birthday['time'] ) ? $birthday['time'] : '09:00:00' );
                        if ( ! $ts ) {
                            continue 2;
                        }
                        $items[] = array( 'email' => $email, 'ts' => $ts, 'note' => wp_date( 'j M', $ts ) );
                        break;
                    case 'subscriber_anniversary':
                        if ( empty( $subscriber->created_at ) ) {
                            continue 2;
                        }
                        $created_ts = strtotime( (string) $subscriber->created_at );
                        if ( ! $created_ts ) {
                            continue 2;
                        }
                        $ts = $pmcpc_next_md_timestamp( gmdate( 'm', $created_ts ), gmdate( 'd', $created_ts ), gmdate( 'H:i:s', $created_ts ) );
                        if ( ! $ts ) {
                            continue 2;
                        }
                        $items[] = array( 'email' => $email, 'ts' => $ts, 'note' => sprintf( __( 'Joined %s', 'product-mailer-campaigns' ), mysql2date( get_option( 'date_format' ), (string) $subscriber->created_at ) ) );
                        break;
                    case 'subscriber_inactive':
                        $reference_raw = '';
                        foreach ( array( 'last_engaged_at', 'last_clicked_at', 'last_opened_at', 'updated_at', 'created_at' ) as $field ) {
                            if ( ! empty( $subscriber->{$field} ) ) {
                                $reference_raw = (string) $subscriber->{$field};
                                break;
                            }
                        }
                        if ( '' === $reference_raw ) {
                            continue 2;
                        }
                        $reference_ts = strtotime( $reference_raw );
                        if ( ! $reference_ts ) {
                            continue 2;
                        }
                        $due_ts = $reference_ts + max( 1, $inactive_days ) * DAY_IN_SECONDS;
                        $items[] = array( 'email' => $email, 'ts' => $due_ts, 'note' => $due_ts <= $now_ts ? __( 'Eligible now', 'product-mailer-campaigns' ) : human_time_diff( $now_ts, $due_ts ) . ' ' . __( 'away', 'product-mailer-campaigns' ) );
                        break;
                    case 'high_value_customer':
                    case 'high_value':
                    case 'vip_customer':
                    case 'vip':
                    case 'new_customer':
                    case 'repeat_customer':
                    case 'customer_inactive':
                        if ( ! class_exists( 'PMCPC_Subscriber_Manager' ) ) {
                            continue 2;
                        }
                        $stats = PMCPC_Subscriber_Manager::get_wc_purchase_stats_for_email( $email );
                        if ( ! is_array( $stats ) ) {
                            continue 2;
                        }
                        if ( in_array( $trigger, array( 'high_value_customer', 'high_value' ), true ) ) {
                            if ( $high_value_threshold <= 0 || (float) $stats['total_spend'] < $high_value_threshold ) {
                                continue 2;
                            }
                            $items[] = array( 'email' => $email, 'ts' => 0, 'sort' => -1 * (float) $stats['total_spend'], 'note' => sprintf( __( '%s lifetime spend', 'product-mailer-campaigns' ), function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( (float) $stats['total_spend'] ) ) : number_format_i18n( (float) $stats['total_spend'], 2 ) ) );
                        } elseif ( in_array( $trigger, array( 'vip_customer', 'vip' ), true ) ) {
                            if ( $vip_threshold <= 0 || (float) $stats['total_spend'] < $vip_threshold ) {
                                continue 2;
                            }
                            $items[] = array( 'email' => $email, 'ts' => 0, 'sort' => -1 * (float) $stats['total_spend'], 'note' => sprintf( __( '%s lifetime spend', 'product-mailer-campaigns' ), function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( (float) $stats['total_spend'] ) ) : number_format_i18n( (float) $stats['total_spend'], 2 ) ) );
                        } elseif ( 'new_customer' === $trigger ) {
                            if ( (int) $stats['order_count'] !== 1 ) {
                                continue 2;
                            }
                            $items[] = array( 'email' => $email, 'ts' => (int) $stats['last_completed_ts'], 'note' => __( '1 completed order', 'product-mailer-campaigns' ) );
                        } elseif ( 'repeat_customer' === $trigger ) {
                            if ( (int) $stats['order_count'] < 2 ) {
                                continue 2;
                            }
                            $items[] = array( 'email' => $email, 'ts' => (int) $stats['last_completed_ts'], 'note' => sprintf( _n( '%d completed order', '%d completed orders', (int) $stats['order_count'], 'product-mailer-campaigns' ), (int) $stats['order_count'] ) );
                        } elseif ( 'customer_inactive' === $trigger ) {
                            if ( empty( $stats['last_completed_ts'] ) ) {
                                continue 2;
                            }
                            $due_ts = (int) $stats['last_completed_ts'] + max( 1, $inactive_days ) * DAY_IN_SECONDS;
                            $items[] = array( 'email' => $email, 'ts' => $due_ts, 'note' => $due_ts <= $now_ts ? __( 'Eligible now', 'product-mailer-campaigns' ) : human_time_diff( $now_ts, $due_ts ) . ' ' . __( 'away', 'product-mailer-campaigns' ) );
                        }
                        break;
                    default:
                        continue 2;
                }
            }

            foreach ( $items as &$item ) {
                if ( ! isset( $item['sort'] ) ) {
                    $item['sort'] = isset( $item['ts'] ) ? (int) $item['ts'] : 0;
                }
            }
            unset( $item );

            usort( $items, function( $a, $b ) {
                return $a['sort'] <=> $b['sort'];
            } );
            return array_slice( $items, 0, max( 1, (int) $limit ) );
        };

        $render_campaign_table = function( $rows, $heading = '' ) use ( $sort_link, $format_audience_summary, $pmcpc_resolve_campaign_trigger_label, $pmcpc_campaign_recent_activity, $pmcpc_campaign_upcoming_candidates, $pmcpc_get_trigger_insight_type ) {
            if ( empty( $rows ) ) {
                return;
            }

            if ( $heading ) {
                echo '<h3 style="margin-top:18px;">' . esc_html( $heading ) . '</h3>';
            }

            echo '<div class="pmcpc-campaign-viewbar"><div class="pmcpc-campaign-viewbar__label">' . esc_html__( 'Visible columns', 'product-mailer-campaigns' ) . '</div><div class="pmcpc-campaign-viewbar__controls">';
            echo '<label class="pmcpc-campaign-viewbar__check"><input type="checkbox" class="pmcpc-campaign-column-toggle" data-column="ready" checked /> ' . esc_html__( 'Ready', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-campaign-viewbar__check"><input type="checkbox" class="pmcpc-campaign-column-toggle" data-column="mode" checked /> ' . esc_html__( 'Mode', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-campaign-viewbar__check"><input type="checkbox" class="pmcpc-campaign-column-toggle" data-column="audience" checked /> ' . esc_html__( 'Audience', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-campaign-viewbar__check"><input type="checkbox" class="pmcpc-campaign-column-toggle" data-column="schedule" checked /> ' . esc_html__( 'Schedule', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-campaign-viewbar__check"><input type="checkbox" class="pmcpc-campaign-column-toggle" data-column="next" checked /> ' . esc_html__( 'Next run', 'product-mailer-campaigns' ) . '</label>';
            echo '<label class="pmcpc-campaign-viewbar__check"><input type="checkbox" class="pmcpc-campaign-column-toggle" data-column="created" checked /> ' . esc_html__( 'Created', 'product-mailer-campaigns' ) . '</label>';
            echo '<a href="#" class="pmcpc-campaign-columns-reset">' . esc_html__( 'Reset columns', 'product-mailer-campaigns' ) . '</a>';
            echo '</div></div>';
            echo '<div class="pmcpc-campaign-table-wrap"><div class="pmcpc-campaign-table-wrap__scroll">';
            echo '<table class="widefat fixed striped pmcpc-wide-table pmcpc-wide-table--campaigns">';
            echo '<colgroup>';
            echo '<col class="pmcpc-campaign-col-name" />';
            echo '<col class="pmcpc-campaign-col-status" />';
            echo '<col class="pmcpc-campaign-col-ready" />';
            echo '<col class="pmcpc-campaign-col-mode" />';
            echo '<col class="pmcpc-campaign-col-audience" />';
            echo '<col class="pmcpc-campaign-col-schedule" />';
            echo '<col class="pmcpc-campaign-col-next" />';
            echo '<col class="pmcpc-campaign-col-created" />';
            echo '<col class="pmcpc-campaign-col-actions" />';
            echo '</colgroup>';
            echo '<thead><tr>';
            echo '<th class="pmcpc-col-anchor"><a href="' . esc_url( $sort_link( 'name' ) ) . '">' . esc_html__( 'Name', 'product-mailer-campaigns' ) . '</a></th>';
            echo '<th class="pmcpc-col-compare"><a href="' . esc_url( $sort_link( 'status' ) ) . '">' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</a></th>';
            echo '<th class="pmcpc-col-compare pmcpc-campaign-col-toggle-ready">' . esc_html__( 'Ready', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-meta pmcpc-campaign-col-toggle-mode">' . esc_html__( 'Mode', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-meta pmcpc-campaign-col-toggle-audience">' . esc_html__( 'Audience', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-meta pmcpc-campaign-col-toggle-schedule">' . esc_html__( 'Schedule', 'product-mailer-campaigns' ) . '</th>';
            echo '<th class="pmcpc-col-compare pmcpc-campaign-col-toggle-next"><a href="' . esc_url( $sort_link( 'next_run_at' ) ) . '">' . esc_html__( 'Next run', 'product-mailer-campaigns' ) . '</a></th>';
            echo '<th class="pmcpc-col-compare pmcpc-campaign-col-toggle-created"><a href="' . esc_url( $sort_link( 'created_at' ) ) . '">' . esc_html__( 'Created', 'product-mailer-campaigns' ) . '</a></th>';
            echo '<th class="pmcpc-col-actions">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
            echo '</tr></thead><tbody>';

            $datetime_format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
            $is_automation_table = ( '' !== $heading && false !== stripos( (string) $heading, 'automation' ) );

            $pmcpc_pretty_workflow_delay = function ( $delay_minutes ) {
                $delay_minutes = max( 0, (int) $delay_minutes );
                if ( $delay_minutes <= 0 ) {
                    return __( 'Immediately', 'product-mailer-campaigns' );
                }
                if ( 0 === ( $delay_minutes % 1440 ) ) {
                    $days = (int) ( $delay_minutes / 1440 );
                    return sprintf( _n( '%d day', '%d days', $days, 'product-mailer-campaigns' ), $days );
                }
                if ( $delay_minutes >= 60 && 0 === ( $delay_minutes % 60 ) ) {
                    $hours = (int) ( $delay_minutes / 60 );
                    return sprintf( _n( '%d hour', '%d hours', $hours, 'product-mailer-campaigns' ), $hours );
                }
                return sprintf( _n( '%d minute', '%d minutes', $delay_minutes, 'product-mailer-campaigns' ), $delay_minutes );
            };

            $pmcpc_render_generic_workflow = function ( $workflow_key, $workflow_rows ) use ( $format_audience_summary, $pmcpc_resolve_campaign_trigger_label, $pmcpc_pretty_workflow_delay, $datetime_format ) {
                $workflow_key = sanitize_key( (string) $workflow_key );
                if ( '' === $workflow_key || empty( $workflow_rows ) || ! is_array( $workflow_rows ) ) {
                    return;
                }

                usort(
                    $workflow_rows,
                    function ( $a, $b ) {
                        $as = isset( $a->workflow_step ) ? absint( $a->workflow_step ) : 0;
                        $bs = isset( $b->workflow_step ) ? absint( $b->workflow_step ) : 0;
                        if ( $as !== $bs ) {
                            return $as <=> $bs;
                        }
                        return (int) $a->id <=> (int) $b->id;
                    }
                );

                $first_row      = reset( $workflow_rows );
                $workflow_name  = ( $first_row && ! empty( $first_row->workflow_name ) ) ? (string) $first_row->workflow_name : ucwords( str_replace( array( '_', '-' ), ' ', $workflow_key ) );
                $step_map       = array();
                $active_count   = 0;
                $ready_count    = 0;
                $created_value  = '';
                $max_step       = 0;

                foreach ( $workflow_rows as $workflow_row ) {
                    $step_no = isset( $workflow_row->workflow_step ) ? absint( $workflow_row->workflow_step ) : 0;
                    if ( $step_no <= 0 ) {
                        $step_no = count( $step_map ) + 1;
                    }
                    $step_map[ $step_no ] = $workflow_row;
                    $max_step = max( $max_step, $step_no );
                    if ( isset( $workflow_row->status ) && 'active' === (string) $workflow_row->status ) {
                        $active_count++;
                    }
                    $ready_reasons  = array();
                    $ready_warnings = array();
                    if ( 'ready' === self::get_campaign_readiness_state( $workflow_row, $ready_reasons, $ready_warnings ) ) {
                        $ready_count++;
                    }
                    if ( ! empty( $workflow_row->created_at ) && ( '' === $created_value || (string) $workflow_row->created_at < $created_value ) ) {
                        $created_value = (string) $workflow_row->created_at;
                    }
                }

                $configured_count = count( $workflow_rows );
                $expected_steps   = max( $max_step, $configured_count, 1 );
                $first_id         = ( $first_row && ! empty( $first_row->id ) ) ? (int) $first_row->id : 0;
                $group_id         = 'workflow_' . substr( md5( $workflow_key ), 0, 12 );
                $manage_url       = admin_url( 'admin.php?page=pmcpc_campaigns&pmcpc_open_acc=' . rawurlencode( $group_id ) );
                $trigger_key      = ( $first_row && ! empty( $first_row->automation_trigger ) ) ? (string) $first_row->automation_trigger : '';
                $trigger_label    = $trigger_key ? $pmcpc_resolve_campaign_trigger_label( $trigger_key ) : __( 'Trigger-based workflow', 'product-mailer-campaigns' );
                $status_label     = $active_count > 0 ? __( 'Active', 'product-mailer-campaigns' ) : __( 'Inactive', 'product-mailer-campaigns' );
                $status_class     = $active_count > 0 ? 'pmcpc-campaign-badge--status-active' : 'pmcpc-campaign-badge--status-inactive';

                echo '<tr class="pmcpc-acc-header pmcpc-workflow-parent" data-pmcpc-acc="' . esc_attr( $group_id ) . '">';
                echo '<td class="pmcpc-col-anchor"><a href="#" class="pmcpc-acc-toggle" data-pmcpc-acc="' . esc_attr( $group_id ) . '"><span class="dashicons dashicons-arrow-right" aria-hidden="true"></span><span class="pmcpc-workflow-title"><span class="pmcpc-workflow-title__main">' . esc_html( $workflow_name ) . '</span><span class="pmcpc-workflow-summary">' . esc_html( sprintf( __( '%1$d of %2$d steps configured · step workflow', 'product-mailer-campaigns' ), $configured_count, $expected_steps ) ) . '</span></span></a></td>';
                echo '<td class="pmcpc-col-compare"><span class="pmcpc-campaign-badge ' . esc_attr( $status_class ) . '">' . esc_html( $status_label ) . '</span></td>';
                echo '<td class="pmcpc-col-compare pmcpc-campaign-col-toggle-ready"><span class="pmcpc-campaign-badge pmcpc-campaign-badge--ready">' . esc_html( sprintf( __( '%1$d/%2$d ready', 'product-mailer-campaigns' ), $ready_count, $configured_count ) ) . '</span></td>';
                echo '<td class="pmcpc-col-meta pmcpc-campaign-col-toggle-mode"><div class="pmcpc-campaign-meta"><span class="pmcpc-campaign-meta__label">' . esc_html__( 'Multi-step workflow', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-campaign-meta__text">' . esc_html( $trigger_label ) . '</span></div></td>';
                echo '<td class="pmcpc-col-meta pmcpc-campaign-col-toggle-audience"><div class="pmcpc-campaign-meta"><span class="pmcpc-campaign-meta__label">' . esc_html__( 'Audience', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-campaign-meta__text">' . esc_html( $first_row ? $format_audience_summary( $first_row ) : __( 'Workflow audience', 'product-mailer-campaigns' ) ) . '</span></div></td>';
                echo '<td class="pmcpc-col-meta pmcpc-campaign-col-toggle-schedule"><div class="pmcpc-campaign-meta"><span class="pmcpc-campaign-meta__label">' . esc_html__( 'Step sequence', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-campaign-meta__text">' . esc_html__( 'Step delays shown below', 'product-mailer-campaigns' ) . '</span></div></td>';
                echo '<td class="pmcpc-col-compare pmcpc-campaign-col-toggle-next">' . esc_html__( 'Trigger-driven', 'product-mailer-campaigns' ) . '</td>';
                echo '<td class="pmcpc-col-compare pmcpc-campaign-col-toggle-created">' . esc_html( $created_value ? mysql2date( $datetime_format, $created_value ) : '—' ) . '</td>';
                echo '<td class="pmcpc-col-actions"><div class="pmcpc-workflow-actions"><a class="button button-small button-secondary" href="' . esc_url( $manage_url ) . '">' . esc_html__( 'Manage workflow', 'product-mailer-campaigns' ) . '</a></div></td>';
                echo '</tr>';

                echo '<tr class="pmcpc-acc-row" data-pmcpc-acc="' . esc_attr( $group_id ) . '">';
                echo '<td colspan="9" class="pmcpc-workflow-detail">';
                echo '<div class="pmcpc-workflow-detail__intro">';
                echo '<p><strong>' . esc_html__( 'Workflow steps', 'product-mailer-campaigns' ) . '</strong><br>' . esc_html__( 'Each step is an editable email, grouped here so the campaign list stays tidy.', 'product-mailer-campaigns' ) . '</p>';
                echo '</div>';
                echo '<table class="pmcpc-workflow-steps">';
                echo '<thead><tr>';
                echo '<th>' . esc_html__( 'Step', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Delay', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Email subject', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Ready', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
                echo '</tr></thead><tbody>';

                for ( $workflow_step = 1; $workflow_step <= $expected_steps; $workflow_step++ ) {
                    if ( empty( $step_map[ $workflow_step ] ) ) {
                        echo '<tr class="pmcpc-workflow-missing">';
                        echo '<td><strong>' . esc_html( sprintf( __( 'Step %d', 'product-mailer-campaigns' ), $workflow_step ) ) . '</strong></td>';
                        echo '<td>—</td>';
                        echo '<td><span class="description">' . esc_html__( 'Step email not found', 'product-mailer-campaigns' ) . '</span></td>';
                        echo '<td><span class="pmcpc-campaign-badge pmcpc-campaign-badge--status-draft">' . esc_html__( 'Missing', 'product-mailer-campaigns' ) . '</span></td>';
                        echo '<td>—</td>';
                        echo '<td>—</td>';
                        echo '</tr>';
                        continue;
                    }

                    $step_row      = $step_map[ $workflow_step ];
                    $edit_url      = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . (int) $step_row->id );
                    $send_test_url = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_send_test_email&campaign_id=' . (int) $step_row->id ), 'pmcpc_send_test_email_' . (int) $step_row->id );
                    $preview_url   = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . (int) $step_row->id . '&pmcpc_preview=1' );
                    $delete_url    = wp_nonce_url( admin_url( 'admin-post.php?action=pmcpc_delete_campaign&campaign_id=' . (int) $step_row->id ), 'pmcpc_delete_campaign_' . (int) $step_row->id );
                    $delay_minutes = isset( $step_row->trigger_delay_minutes ) ? absint( $step_row->trigger_delay_minutes ) : 0;

                    $ready_reasons  = array();
                    $ready_warnings = array();
                    $ready_state    = self::get_campaign_readiness_state( $step_row, $ready_reasons, $ready_warnings );
                    $ready_cell     = '<span class="pmcpc-campaign-badge pmcpc-campaign-badge--blocked">' . esc_html__( 'Needs setup', 'product-mailer-campaigns' ) . '</span>';
                    if ( 'ready' === $ready_state ) {
                        $ready_cell = '<span class="pmcpc-campaign-badge pmcpc-campaign-badge--ready">' . esc_html__( 'Ready', 'product-mailer-campaigns' ) . '</span>';
                    } elseif ( 'warn' === $ready_state ) {
                        $ready_cell = '<span class="pmcpc-campaign-badge pmcpc-campaign-badge--warn">' . esc_html__( 'Warning', 'product-mailer-campaigns' ) . '</span>';
                    }

                    $display_status = isset( $step_row->status ) && 'active' === (string) $step_row->status ? __( 'Active', 'product-mailer-campaigns' ) : __( 'Inactive', 'product-mailer-campaigns' );
                    $step_status_class = isset( $step_row->status ) && 'active' === (string) $step_row->status ? 'pmcpc-campaign-badge--status-active' : 'pmcpc-campaign-badge--status-inactive';

                    echo '<tr>';
                    echo '<td><strong>' . esc_html( sprintf( __( 'Step %d', 'product-mailer-campaigns' ), $workflow_step ) ) . '</strong><br><span class="description">#' . esc_html( (int) $step_row->id ) . '</span></td>';
                    echo '<td>' . esc_html( $pmcpc_pretty_workflow_delay( $delay_minutes ) ) . '</td>';
                    echo '<td><a href="' . esc_url( $edit_url ) . '">' . esc_html( ! empty( $step_row->subject ) ? (string) $step_row->subject : (string) $step_row->name ) . '</a><br><span class="description">' . esc_html( (string) $step_row->name ) . '</span></td>';
                    echo '<td><span class="pmcpc-campaign-badge ' . esc_attr( $step_status_class ) . '">' . esc_html( $display_status ) . '</span></td>';
                    echo '<td>' . wp_kses( $ready_cell, array( 'span' => array( 'class' => array(), 'title' => array() ) ) ) . '</td>';
                    echo '<td><div class="pmcpc-workflow-step-actions">';
                    echo '<a href="' . esc_url( $edit_url ) . '">' . esc_html__( 'Edit', 'product-mailer-campaigns' ) . '</a>';
                    echo '<a href="' . esc_url( $preview_url ) . '">' . esc_html__( 'View email', 'product-mailer-campaigns' ) . '</a>';
                    echo '<a href="' . esc_url( $send_test_url ) . '">' . esc_html__( 'Send test', 'product-mailer-campaigns' ) . '</a>';
                    echo '<a href="' . esc_url( $delete_url ) . '">' . esc_html__( 'Delete', 'product-mailer-campaigns' ) . '</a>';
                    echo '</div></td>';
                    echo '</tr>';
                }

                echo '</tbody></table>';
                echo '</td>';
                echo '</tr>';
            };

            // Group custom/built step workflows under one expandable parent row on Campaigns.
            $workflow_groups = array();
            if ( $is_automation_table ) {
                foreach ( (array) $rows as $idx => $rc ) {
                    $workflow_key = isset( $rc->workflow_key ) ? sanitize_key( (string) $rc->workflow_key ) : '';
                    if ( '' === $workflow_key ) {
                        continue;
                    }
                    if ( empty( $workflow_groups[ $workflow_key ] ) ) {
                        $workflow_groups[ $workflow_key ] = array();
                    }
                    $workflow_groups[ $workflow_key ][] = $rc;
                    unset( $rows[ $idx ] );
                }
                if ( ! empty( $workflow_groups ) ) {
                    foreach ( $workflow_groups as $workflow_key => $workflow_rows ) {
                        $pmcpc_render_generic_workflow( $workflow_key, $workflow_rows );
                    }
                }
            }

            // If this is the Automations table, group abandoned cart steps under an expandable header.
            $abandoned_steps     = array();
            if ( $is_automation_table ) {
                foreach ( (array) $rows as $idx => $rc ) {
                    $tk = isset( $rc->automation_trigger ) ? trim( (string) $rc->automation_trigger ) : '';
                    if ( in_array( $tk, array( 'abandoned_cart_step_1', 'abandoned_cart_step_2', 'abandoned_cart_step_3' ), true ) ) {
                        // Extract step number.
                        if ( preg_match( '/abandoned_cart_step_(\d+)/', $tk, $m ) ) {
                            $step = (int) $m[1];
                            $abandoned_steps[ $step ] = $rc;
                            unset( $rows[ $idx ] );
                        }
                    }
                }
                if ( ! empty( $abandoned_steps ) ) {
                    ksort( $abandoned_steps );
                    $ab_step_count    = count( $abandoned_steps );
                    $ab_active_count  = 0;
                    $ab_ready_count   = 0;
                    $ab_first_step    = reset( $abandoned_steps );
                    $ab_first_step_id = ( $ab_first_step && isset( $ab_first_step->id ) ) ? (int) $ab_first_step->id : 0;
                    $ab_manage_url    = admin_url( 'admin.php?page=pmcpc_campaigns&pmcpc_open_acc=abandoned_cart' );
                    $ab_next_missing  = 0;
                    foreach ( array( 1, 2, 3 ) as $ab_step_no ) {
                        if ( empty( $abandoned_steps[ $ab_step_no ] ) && 0 === $ab_next_missing ) {
                            $ab_next_missing = $ab_step_no;
                        }
                        if ( ! empty( $abandoned_steps[ $ab_step_no ] ) ) {
                            $ab_step_row = $abandoned_steps[ $ab_step_no ];
                            if ( isset( $ab_step_row->status ) && 'active' === (string) $ab_step_row->status ) {
                                $ab_active_count++;
                            }
                            $ab_reasons = array();
                            $ab_warns   = array();
                            if ( 'ready' === self::get_campaign_readiness_state( $ab_step_row, $ab_reasons, $ab_warns ) ) {
                                $ab_ready_count++;
                            }
                        }
                    }
                    $ab_add_url = $ab_next_missing > 0 ? admin_url( 'admin.php?page=pmcpc_campaigns&action=new&trigger=abandoned_cart_step_' . $ab_next_missing . '&pro_segment_key=abandoned_cart&automation_hint=abandoned_cart_step_' . $ab_next_missing ) : '';
                    $ab_status_label = $ab_active_count > 0 ? __( 'Active', 'product-mailer-campaigns' ) : __( 'Inactive', 'product-mailer-campaigns' );
                    $ab_created_value = '';
                    foreach ( $abandoned_steps as $ab_step_row ) {
                        if ( ! empty( $ab_step_row->created_at ) && ( '' === $ab_created_value || (string) $ab_step_row->created_at < $ab_created_value ) ) {
                            $ab_created_value = (string) $ab_step_row->created_at;
                        }
                    }
                    echo '<tr class="pmcpc-acc-header pmcpc-workflow-parent" data-pmcpc-acc="abandoned_cart">';
                    echo '<td class="pmcpc-col-anchor"><a href="#" class="pmcpc-acc-toggle" data-pmcpc-acc="abandoned_cart"><span class="dashicons dashicons-arrow-right" aria-hidden="true"></span><span class="pmcpc-workflow-title"><span class="pmcpc-workflow-title__main">' . esc_html__( 'Abandoned Cart Automation', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-workflow-summary">' . esc_html( sprintf( __( '%1$d of 3 steps configured · customer recovery workflow', 'product-mailer-campaigns' ), $ab_step_count ) ) . '</span></span></a></td>';
                    echo '<td class="pmcpc-col-compare"><span class="pmcpc-campaign-badge pmcpc-campaign-badge--status-' . esc_attr( sanitize_html_class( strtolower( $ab_status_label ) ) ) . '">' . esc_html( $ab_status_label ) . '</span></td>';
                    echo '<td class="pmcpc-col-compare pmcpc-campaign-col-toggle-ready"><span class="pmcpc-campaign-badge pmcpc-campaign-badge--ready">' . esc_html( sprintf( __( '%1$d/%2$d ready', 'product-mailer-campaigns' ), $ab_ready_count, $ab_step_count ) ) . '</span></td>';
                    echo '<td class="pmcpc-col-meta pmcpc-campaign-col-toggle-mode"><div class="pmcpc-campaign-meta"><span class="pmcpc-campaign-meta__label">' . esc_html__( 'Multi-step workflow', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-campaign-meta__text">' . esc_html__( 'Cart abandoned trigger', 'product-mailer-campaigns' ) . '</span></div></td>';
                    echo '<td class="pmcpc-col-meta pmcpc-campaign-col-toggle-audience"><div class="pmcpc-campaign-meta"><span class="pmcpc-campaign-meta__label">' . esc_html__( 'Abandoned carts', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-campaign-meta__text">' . esc_html__( 'Customers with captured cart email', 'product-mailer-campaigns' ) . '</span></div></td>';
                    echo '<td class="pmcpc-col-meta pmcpc-campaign-col-toggle-schedule"><div class="pmcpc-campaign-meta"><span class="pmcpc-campaign-meta__label">' . esc_html__( 'Staggered sequence', 'product-mailer-campaigns' ) . '</span><span class="pmcpc-campaign-meta__text">' . esc_html__( 'Step delays shown below', 'product-mailer-campaigns' ) . '</span></div></td>';
                    echo '<td class="pmcpc-col-compare pmcpc-campaign-col-toggle-next">' . esc_html__( 'Cron-driven', 'product-mailer-campaigns' ) . '</td>';
                    echo '<td class="pmcpc-col-compare pmcpc-campaign-col-toggle-created">' . esc_html( $ab_created_value ? mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $ab_created_value ) : '—' ) . '</td>';
                    echo '<td class="pmcpc-col-actions"><div class="pmcpc-workflow-actions"><a class="button button-small button-secondary" href="' . esc_url( $ab_manage_url ) . '">' . esc_html__( 'Manage workflow', 'product-mailer-campaigns' ) . '</a>';
                    if ( $ab_add_url ) {
                        echo '<a class="button button-small" href="' . esc_url( $ab_add_url ) . '">' . esc_html( sprintf( __( 'Add Step %d', 'product-mailer-campaigns' ), $ab_next_missing ) ) . '</a>';
                    }
                    echo '</div></td>';
                    echo '</tr>';
                }
            }

            $datetime_format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
            $site_tz         = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
            // Format a UTC MySQL datetime into the site's timezone.
            $format_utc_mysql = function ( $mysql_dt ) use ( $datetime_format, $site_tz ) {
                if ( empty( $mysql_dt ) ) {
                    return '';
                }
                try {
                    $ts = ( new DateTimeImmutable( (string) $mysql_dt, new DateTimeZone( 'UTC' ) ) )->getTimestamp();
                    return wp_date( $datetime_format, $ts, $site_tz );
                } catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
                    return '';
                }
            };

            // Render grouped abandoned cart steps as one workflow detail row.
            if ( ! empty( $abandoned_steps ) ) {
                $pretty_delay = function ( $delay_minutes ) {
                    $delay_minutes = max( 0, (int) $delay_minutes );
                    if ( $delay_minutes <= 0 ) {
                        return __( 'Immediately', 'product-mailer-campaigns' );
                    }
                    if ( 0 === ( $delay_minutes % 1440 ) ) {
                        $days = (int) ( $delay_minutes / 1440 );
                        return sprintf( _n( '%d day', '%d days', $days, 'product-mailer-campaigns' ), $days );
                    }
                    if ( $delay_minutes >= 60 && 0 === ( $delay_minutes % 60 ) ) {
                        $hours = (int) ( $delay_minutes / 60 );
                        return sprintf( _n( '%d hour', '%d hours', $hours, 'product-mailer-campaigns' ), $hours );
                    }
                    return sprintf( _n( '%d minute', '%d minutes', $delay_minutes, 'product-mailer-campaigns' ), $delay_minutes );
                };
                $default_delay = function ( $step ) {
                    $step = max( 1, min( 3, (int) $step ) );
                    if ( class_exists( 'PMCPC_Abandoned_Carts' ) ) {
                        return (int) PMCPC_Abandoned_Carts::get_recovery_delay_minutes_for_step( $step );
                    }
                    $defaults = array( 1 => 60, 2 => 1440, 3 => 4320 );
                    return isset( $defaults[ $step ] ) ? (int) $defaults[ $step ] : 0;
                };

                echo '<tr class="pmcpc-acc-row" data-pmcpc-acc="abandoned_cart">';
                echo '<td colspan="9" class="pmcpc-workflow-detail">';
                echo '<div class="pmcpc-workflow-detail__intro">';
                echo '<p><strong>' . esc_html__( 'Workflow steps', 'product-mailer-campaigns' ) . '</strong><br>' . esc_html__( 'Each step is still an editable email, but the automation is managed as one recovery sequence.', 'product-mailer-campaigns' ) . '</p>';
                if ( ! empty( $ab_add_url ) ) {
                    echo '<a class="button button-primary" href="' . esc_url( $ab_add_url ) . '">' . esc_html( sprintf( __( 'Add Step %d', 'product-mailer-campaigns' ), (int) $ab_next_missing ) ) . '</a>';
                }
                echo '</div>';
                echo '<table class="pmcpc-workflow-steps">';
                echo '<thead><tr>';
                echo '<th>' . esc_html__( 'Step', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Delay', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Email subject', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Ready', 'product-mailer-campaigns' ) . '</th>';
                echo '<th>' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</th>';
                echo '</tr></thead><tbody>';

                for ( $workflow_step = 1; $workflow_step <= 3; $workflow_step++ ) {
                    if ( empty( $abandoned_steps[ $workflow_step ] ) ) {
                        $create_step_url = admin_url( 'admin.php?page=pmcpc_campaigns&action=new&trigger=abandoned_cart_step_' . $workflow_step . '&pro_segment_key=abandoned_cart&automation_hint=abandoned_cart_step_' . $workflow_step );
                        echo '<tr class="pmcpc-workflow-missing">';
                        echo '<td><strong>' . esc_html( sprintf( __( 'Step %d', 'product-mailer-campaigns' ), $workflow_step ) ) . '</strong></td>';
                        echo '<td>' . esc_html( $pretty_delay( $default_delay( $workflow_step ) ) ) . '</td>';
                        echo '<td><span class="description">' . esc_html__( 'Not created yet', 'product-mailer-campaigns' ) . '</span></td>';
                        echo '<td><span class="pmcpc-campaign-badge pmcpc-campaign-badge--status-draft">' . esc_html__( 'Missing', 'product-mailer-campaigns' ) . '</span></td>';
                        echo '<td>—</td>';
                        echo '<td><a class="button button-small" href="' . esc_url( $create_step_url ) . '">' . esc_html__( 'Create step', 'product-mailer-campaigns' ) . '</a></td>';
                        echo '</tr>';
                        continue;
                    }

                    $c = $abandoned_steps[ $workflow_step ];
                    $edit_url      = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . (int) $c->id );
                    $send_test_url = wp_nonce_url(
                        admin_url( 'admin-post.php?action=pmcpc_send_test_email&campaign_id=' . (int) $c->id ),
                        'pmcpc_send_test_email_' . (int) $c->id
                    );
                    $preview_url = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . (int) $c->id . '&pmcpc_preview=1' );
                    $delete_url  = wp_nonce_url(
                        admin_url( 'admin-post.php?action=pmcpc_delete_campaign&campaign_id=' . (int) $c->id ),
                        'pmcpc_delete_campaign_' . (int) $c->id
                    );

                    $delay_minutes = isset( $c->trigger_delay_minutes ) ? absint( $c->trigger_delay_minutes ) : 0;
                    if ( 0 === $delay_minutes ) {
                        $delay_minutes = $default_delay( $workflow_step );
                    }

                    $ready_reasons  = array();
                    $ready_warnings = array();
                    $ready_state    = self::get_campaign_readiness_state( $c, $ready_reasons, $ready_warnings );
                    $ready_cell     = '<span class="pmcpc-campaign-badge pmcpc-campaign-badge--blocked">' . esc_html__( 'Needs setup', 'product-mailer-campaigns' ) . '</span>';
                    if ( 'ready' === $ready_state ) {
                        $ready_cell = '<span class="pmcpc-campaign-badge pmcpc-campaign-badge--ready">' . esc_html__( 'Ready', 'product-mailer-campaigns' ) . '</span>';
                    } elseif ( 'warn' === $ready_state ) {
                        $ready_cell = '<span class="pmcpc-campaign-badge pmcpc-campaign-badge--warn">' . esc_html__( 'Warning', 'product-mailer-campaigns' ) . '</span>';
                    }

                    $display_status = isset( $c->status ) && 'active' === (string) $c->status ? __( 'Active', 'product-mailer-campaigns' ) : __( 'Inactive', 'product-mailer-campaigns' );
                    $status_class   = isset( $c->status ) && 'active' === (string) $c->status ? 'pmcpc-campaign-badge--status-active' : 'pmcpc-campaign-badge--status-inactive';

                    echo '<tr>';
                    echo '<td><strong>' . esc_html( sprintf( __( 'Step %d', 'product-mailer-campaigns' ), $workflow_step ) ) . '</strong><br><span class="description">#' . esc_html( (int) $c->id ) . '</span></td>';
                    echo '<td>' . esc_html( $pretty_delay( $delay_minutes ) ) . '</td>';
                    echo '<td><a href="' . esc_url( $edit_url ) . '">' . esc_html( ! empty( $c->subject ) ? (string) $c->subject : (string) $c->name ) . '</a><br><span class="description">' . esc_html( (string) $c->name ) . '</span></td>';
                    echo '<td><span class="pmcpc-campaign-badge ' . esc_attr( $status_class ) . '">' . esc_html( $display_status ) . '</span></td>';
                    echo '<td>' . wp_kses( $ready_cell, array( 'span' => array( 'class' => array(), 'title' => array() ) ) ) . '</td>';
                    echo '<td><div class="pmcpc-workflow-step-actions">';
                    echo '<a href="' . esc_url( $edit_url ) . '">' . esc_html__( 'Edit', 'product-mailer-campaigns' ) . '</a>';
                    echo '<a href="' . esc_url( $preview_url ) . '">' . esc_html__( 'View email', 'product-mailer-campaigns' ) . '</a>';
                    echo '<a href="' . esc_url( $send_test_url ) . '">' . esc_html__( 'Send test', 'product-mailer-campaigns' ) . '</a>';
                    echo '<a href="' . esc_url( $delete_url ) . '">' . esc_html__( 'Delete', 'product-mailer-campaigns' ) . '</a>';
                    echo '</div></td>';
                    echo '</tr>';
                }

                echo '</tbody></table>';
                echo '</td>';
                echo '</tr>';
            }

            foreach ( $rows as $c ) {
                $edit_url    = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . (int) $c->id );
                $queue_url   = wp_nonce_url(
                    admin_url( 'admin-post.php?action=pmcpc_queue_campaign&campaign_id=' . (int) $c->id ),
                    'pmcpc_send_campaign_' . (int) $c->id
                );
                $test_url    = wp_nonce_url(
                    admin_url( 'admin-post.php?action=pmcpc_test_campaign&campaign_id=' . (int) $c->id ),
                    'pmcpc_test_campaign_' . (int) $c->id
                );
				$send_test_url = wp_nonce_url(
					admin_url( 'admin-post.php?action=pmcpc_send_test_email&campaign_id=' . (int) $c->id ),
					'pmcpc_send_test_email_' . (int) $c->id
				);
                $preview_url = admin_url( 'admin.php?page=pmcpc_campaigns&campaign_id=' . (int) $c->id . '&pmcpc_preview=1' );
                $delete_url  = wp_nonce_url(
                    admin_url( 'admin-post.php?action=pmcpc_delete_campaign&campaign_id=' . (int) $c->id ),
                    'pmcpc_delete_campaign_' . (int) $c->id
                );

                // Human-readable automation label.
                // Keep this independent from schedule labels (Triggered / One-time / Recurring).
                $automation_label = __( 'Manual / scheduled', 'product-mailer-campaigns' );

                $trigger_key = isset( $c->automation_trigger ) ? trim( (string) $c->automation_trigger ) : '';

                // Back-compat flags for earlier versions.
                if ( ! empty( $c->is_welcome ) ) {
                    $trigger_key = 'new_subscriber';
                } elseif ( ! empty( $c->is_post_purchase ) ) {
                    $trigger_key = 'post_purchase';
                }

                if ( '' !== $trigger_key && 'none' !== $trigger_key ) {
                    $map = array(
                        // Core/free.
                        'new_subscriber'       => __( 'Welcome automation', 'product-mailer-campaigns' ),
                        'welcome'              => __( 'Welcome automation', 'product-mailer-campaigns' ),
                        'welcome_follow_up'    => __( 'Welcome follow-up automation', 'product-mailer-campaigns' ),
                        'lead_magnet_download' => __( 'Lead magnet delivery automation', 'product-mailer-campaigns' ),
                        'subscriber_inactive'  => __( 'Subscriber inactive automation', 'product-mailer-campaigns' ),
                        'subscriber_anniversary' => __( 'Subscriber anniversary automation', 'product-mailer-campaigns' ),
                        'subscriber_birthday'  => __( 'Subscriber birthday automation', 'product-mailer-campaigns' ),
                        'post_purchase'        => __( 'Post-purchase automation', 'product-mailer-campaigns' ),
                        'review_request'       => __( 'Review request', 'product-mailer-campaigns' ),

                        // WooCommerce automations.
                        'new_customer'         => __( 'New customer automation', 'product-mailer-campaigns' ),
                        'high_value_customer'  => __( 'High-value customer automation', 'product-mailer-campaigns' ),
                        'high_value'           => __( 'High-value customer automation', 'product-mailer-campaigns' ), // legacy alias
                        'lapsed_high_value_customer' => __( 'Lapsed high-value customer automation', 'product-mailer-campaigns' ),
                        'vip_customer'         => __( 'VIP customer automation', 'product-mailer-campaigns' ),
                        'vip'                  => __( 'VIP customer automation', 'product-mailer-campaigns' ), // legacy alias
                        'repeat_customer'      => __( 'Repeat customer automation', 'product-mailer-campaigns' ),
                        'customer_inactive'    => __( 'Win-back automation', 'product-mailer-campaigns' ),

                        // Abandoned cart recovery (3-step).
                        'abandoned_cart_step_1' => __( 'Abandoned cart (Step 1)', 'product-mailer-campaigns' ),
                        'abandoned_cart_step_2' => __( 'Abandoned cart (Step 2)', 'product-mailer-campaigns' ),
                        'abandoned_cart_step_3' => __( 'Abandoned cart (Step 3)', 'product-mailer-campaigns' ),
                    );
                    $automation_label = $pmcpc_resolve_campaign_trigger_label( $trigger_key );
                }

                // Human-readable schedule.
                $schedule_label = __( 'Manual', 'product-mailer-campaigns' );
                $schedule_type  = isset( $c->schedule_type ) ? $c->schedule_type : 'manual';
                $freq           = isset( $c->schedule_frequency ) ? $c->schedule_frequency : '';

                // If this is an automation (event-based trigger), the campaign is not date/time scheduled.
                // Keep this label distinct from truly manual (no trigger, no schedule) campaigns.
                $trigger = isset( $c->automation_trigger ) ? (string) $c->automation_trigger : '';
                if ( ( ! empty( $trigger ) && 'none' !== $trigger ) || ( ! empty( $c->is_welcome ) ) || ( ! empty( $c->is_post_purchase ) ) ) {
                    $schedule_label = __( 'Triggered', 'product-mailer-campaigns' );
                } elseif ( 'one_time' === $schedule_type ) {
                    if ( ! empty( $c->schedule_datetime ) ) {
                        $pretty_dt = $format_utc_mysql( $c->schedule_datetime );
                        $schedule_label = sprintf(
                            /* translators: %s: scheduled date/time */
                            __( 'One-time on %s', 'product-mailer-campaigns' ),
                            $pretty_dt ? $pretty_dt : mysql2date( $datetime_format, $c->schedule_datetime )
                        );
                    } else {
                        $schedule_label = __( 'One-time', 'product-mailer-campaigns' );
                    }
                } elseif ( 'recurring' === $schedule_type ) {
                    $freq_map = array(
                        'daily'   => __( 'Daily', 'product-mailer-campaigns' ),
                        'weekly'  => __( 'Weekly', 'product-mailer-campaigns' ),
                        'monthly' => __( 'Monthly', 'product-mailer-campaigns' ),
                    );
                    $schedule_label = isset( $freq_map[ $freq ] ) ? $freq_map[ $freq ] : __( 'Recurring', 'product-mailer-campaigns' );
                }

                $next_run = '';
                if ( ! empty( $c->next_run_at ) ) {
                    $next_run = $format_utc_mysql( $c->next_run_at );
                    if ( '' === $next_run ) {
                        $next_run = mysql2date( $datetime_format, $c->next_run_at );
                    }
                } elseif ( 'one_time' === $schedule_type && ! empty( $c->schedule_datetime ) ) {
                    $next_run = $format_utc_mysql( $c->schedule_datetime );
                    if ( '' === $next_run ) {
                        $next_run = mysql2date( $datetime_format, $c->schedule_datetime );
                    }
                }

				// Show a readiness tick only for scheduled/automation campaigns.
				$is_sched_or_auto = ( 'manual' !== $schedule_type ) || ( ! empty( $c->automation_trigger ) && 'none' !== $c->automation_trigger );
				$ready_reasons    = array();
				$ready_warnings   = array();
				$ready_state      = $is_sched_or_auto ? self::get_campaign_readiness_state( $c, $ready_reasons, $ready_warnings ) : 'n/a';
				$ready_label      = __( 'Not applicable', 'product-mailer-campaigns' );
				$ready_class      = 'pmcpc-campaign-badge';
				if ( $is_sched_or_auto ) {
					if ( 'ready' === $ready_state ) {
						$ready_label = __( 'Ready', 'product-mailer-campaigns' );
						$ready_class = 'pmcpc-campaign-badge pmcpc-campaign-badge--ready';
					} elseif ( 'warn' === $ready_state ) {
						$ready_label = __( 'Ready with warnings', 'product-mailer-campaigns' );
						$ready_class = 'pmcpc-campaign-badge pmcpc-campaign-badge--warn';
					} else {
						$ready_label = __( 'Needs attention', 'product-mailer-campaigns' );
						$ready_class = 'pmcpc-campaign-badge pmcpc-campaign-badge--blocked';
					}
				}

				
				// Completed campaigns do not require readiness checks (avoid misleading red X).
				if ( isset( $c->status ) && 'completed' === (string) $c->status ) {
					$ready_state = 'n/a';
					$ready_label = __( 'Completed', 'product-mailer-campaigns' );
					$ready_class = 'pmcpc-campaign-badge pmcpc-campaign-badge--status-completed';
				}

// Status label improvements (automation drafts are "Inactive").
				$is_automation_row = ( ( isset( $c->automation_trigger ) && $c->automation_trigger && 'none' !== $c->automation_trigger ) || ! empty( $c->is_welcome ) || ! empty( $c->is_post_purchase ) );
				$display_status    = (string) $c->status;
				if ( $is_automation_row ) {
					if ( 'active' === $display_status ) {
						$display_status = __( 'Active', 'product-mailer-campaigns' );
					} else {
						$display_status = __( 'Inactive', 'product-mailer-campaigns' );
					}
				} else {
					if ( 'draft' === $display_status ) {
						$display_status = __( 'Draft', 'product-mailer-campaigns' );
					} elseif ( 'scheduled' === $display_status ) {
						$display_status = __( 'Scheduled', 'product-mailer-campaigns' );
					} elseif ( 'queued' === $display_status ) {
						$display_status = __( 'Queued', 'product-mailer-campaigns' );
					}
				}

                $status_class = 'pmcpc-campaign-badge pmcpc-campaign-badge--status-' . sanitize_html_class( strtolower( preg_replace( '/[^a-z0-9]+/i', '-', (string) $display_status ) ) );
                $readiness_title = '';
                if ( 'warn' === $ready_state && ! empty( $ready_warnings ) ) {
                    $readiness_title = implode( ', ', $ready_warnings );
                } elseif ( 'ready' !== $ready_state && 'n/a' !== $ready_state && ! empty( $ready_reasons ) ) {
                    $readiness_title = implode( ', ', $ready_reasons );
                }

                echo '<tr>';
                echo '<td class="pmcpc-col-anchor"><div class="pmcpc-table-record"><span class="pmcpc-table-record__title"><a href="' . esc_url( $edit_url ) . '">' . esc_html( $c->name ) . '</a></span><span class="pmcpc-table-record__meta">' . esc_html( $c->subject ) . '</span></div></td>';
                echo '<td class="pmcpc-col-compare"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-badges"><span class="' . esc_attr( $status_class ) . '">' . esc_html( $display_status ) . '</span></span></div></td>';
				echo '<td class="pmcpc-col-compare pmcpc-campaign-col-toggle-ready"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-badges"><span class="' . esc_attr( $ready_class ) . '"' . ( $readiness_title ? ' title="' . esc_attr( $readiness_title ) . '"' : '' ) . '>' . esc_html( $ready_label ) . '</span></span></div></td>';
                echo '<td class="pmcpc-col-meta pmcpc-campaign-col-toggle-mode"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $automation_label ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html( $is_automation_row ? __( 'Trigger-based workflow', 'product-mailer-campaigns' ) : __( 'Manual or scheduled mode', 'product-mailer-campaigns' ) ) . '</span></div></td>';
                echo '<td class="pmcpc-col-meta pmcpc-campaign-col-toggle-audience"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $format_audience_summary( $c ) ) . '</span></div></td>';
                echo '<td class="pmcpc-col-meta pmcpc-campaign-col-toggle-schedule"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $schedule_label ) . '</span></div></td>';
                $next_run_markup = $next_run ? esc_html( $next_run ) : '&mdash;';
                if ( $is_automation_row ) {
                    $insight_id = 'pmcpc-insight-' . (int) $c->id;
                    $next_run_markup .= '<div style="margin-top:6px;"><button type="button" class="button button-small pmcpc-insight-toggle" aria-expanded="false" aria-controls="' . esc_attr( $insight_id ) . '">' . esc_html__( 'Trigger insight', 'product-mailer-campaigns' ) . '</button></div>';
                }
                echo '<td class="pmcpc-col-compare pmcpc-campaign-col-toggle-next"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . wp_kses_post( $next_run_markup ) . '</span><span class="pmcpc-table-cell-stack__sub">' . esc_html__( 'Next scheduled activity', 'product-mailer-campaigns' ) . '</span></div></td>';
                echo '<td class="pmcpc-col-compare pmcpc-campaign-col-toggle-created"><div class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $c->created_at ) . '</span></div></td>';
				// Enable/disable toggle.
				$toggle_action = '';
				$toggle_url    = '';
				if ( $is_automation_row ) {
					$toggle_action = ( 'active' === (string) $c->status ) ? 'disable' : 'enable';
				} else {
					// For scheduled campaigns, "enable" means allow the schedule to run.
					$toggle_action = ( 'scheduled' === (string) $c->status ) ? 'disable' : 'enable';
				}

				$toggle_url = wp_nonce_url(
					add_query_arg(
						array(
							'action'      => 'pmcpc_toggle_campaign',
							'campaign_id' => (int) $c->id,
							'toggle'      => $toggle_action,
						),
						admin_url( 'admin-post.php' )
					),
					'pmcpc_toggle_campaign_' . (int) $c->id
				);

									// Actions: keep automation rows focused on workflow actions (automation ≠ email/broadcast).
					$is_completed = ( isset( $c->status ) && 'completed' === (string) $c->status );
					$dup_url = wp_nonce_url(
						add_query_arg(
							array(
								'action'      => 'pmcpc_duplicate_campaign',
								'campaign_id' => (int) $c->id,
							),
							admin_url( 'admin-post.php' )
						),
						'pmcpc_duplicate_campaign_' . (int) $c->id
					);

					if ( $is_automation_row ) {
						$action_links   = array(
							'<a href="' . esc_url( $edit_url ) . '">' . esc_html__( 'Edit workflow', 'product-mailer-campaigns' ) . '</a>',
							'<a href="' . esc_url( $toggle_url ) . '">' . ( 'disable' === $toggle_action ? esc_html__( 'Disable', 'product-mailer-campaigns' ) : esc_html__( 'Enable', 'product-mailer-campaigns' ) ) . '</a>',
							'<a href="' . esc_url( $dup_url ) . '">' . esc_html__( 'Duplicate', 'product-mailer-campaigns' ) . '</a>',
							'<a href="' . esc_url( $delete_url ) . '">' . esc_html__( 'Delete', 'product-mailer-campaigns' ) . '</a>',
						);
						echo '<td class="pmcpc-col-actions"><div class="pmcpc-campaign-actions pmcpc-table-actions"><details class="pmcpc-table-actions__menu"><summary class="button button-small pmcpc-table-actions__summary">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</summary><div class="pmcpc-table-actions__popover">' . implode( '', $action_links ) . '</div></details></div></td>';
					} else {
						$action_links = array(
							'<a class="pmcpc-queue-broadcast" data-campaign-id="' . (int) $c->id . '" href="' . esc_url( $queue_url ) . '">' . esc_html__( 'Add to Queue', 'product-mailer-campaigns' ) . '</a>',
							'<a href="' . esc_url( $edit_url ) . '">' . esc_html__( 'Edit', 'product-mailer-campaigns' ) . '</a>',
							'<a href="' . esc_url( $send_test_url ) . '">' . esc_html__( 'Send test email', 'product-mailer-campaigns' ) . '</a>',
							'<a href="' . esc_url( $preview_url ) . '">' . esc_html__( 'View email', 'product-mailer-campaigns' ) . '</a>',
							'<a href="' . esc_url( $test_url ) . '">' . esc_html__( 'Test audience match', 'product-mailer-campaigns' ) . '</a>',
						);

						// Toggle action: for completed one-time campaigns, offer Duplicate instead of Enable/Disable.
						if ( $is_completed ) {
							$action_links[] = '<a href="' . esc_url( $dup_url ) . '">' . esc_html__( 'Duplicate', 'product-mailer-campaigns' ) . '</a>';
						} else {
							$action_links[] = '<a href="' . esc_url( $toggle_url ) . '">' . ( 'disable' === $toggle_action ? esc_html__( 'Disable', 'product-mailer-campaigns' ) : esc_html__( 'Enable', 'product-mailer-campaigns' ) ) . '</a>';
						}

						$action_links[] = '<a href="' . esc_url( $delete_url ) . '">' . esc_html__( 'Delete', 'product-mailer-campaigns' ) . '</a>';
						echo '<td class="pmcpc-col-actions"><div class="pmcpc-campaign-actions pmcpc-table-actions"><details class="pmcpc-table-actions__menu"><summary class="button button-small pmcpc-table-actions__summary">' . esc_html__( 'Actions', 'product-mailer-campaigns' ) . '</summary><div class="pmcpc-table-actions__popover">' . implode( '', $action_links ) . '</div></details></div></td>';
					}
                echo '</tr>';
                if ( $is_automation_row ) {
                    $insight_id       = 'pmcpc-insight-' . (int) $c->id;
                    $recent_activity  = $pmcpc_campaign_recent_activity( (int) $c->id, 5 );
                    $upcoming_matches = $pmcpc_campaign_upcoming_candidates( $c, 5 );
                    echo '<tr id="' . esc_attr( $insight_id ) . '" class="pmcpc-insight-row" style="display:none;background:#fcfcfd;">';
                    echo '<td colspan="9">';
                    echo '<div class="pmcpc-insight-panel">';
                    echo '<div class="pmcpc-insight-columns">';
                    echo '<div class="pmcpc-insight-col">';
                    echo '<h4>' . esc_html__( 'Recent activity', 'product-mailer-campaigns' ) . '</h4>';
                    if ( ! empty( $recent_activity ) ) {
                        echo '<ul class="pmcpc-insight-list">';
                        foreach ( $recent_activity as $activity ) {
                            $email  = ! empty( $activity->to_email ) ? sanitize_email( (string) $activity->to_email ) : '';
                            $status = ! empty( $activity->status ) ? ucfirst( sanitize_text_field( (string) $activity->status ) ) : __( 'Queued', 'product-mailer-campaigns' );
                            $when   = ! empty( $activity->activity_at ) ? mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (string) $activity->activity_at ) : '';
                            echo '<li><strong>' . esc_html( $email ? $email : __( 'Unknown recipient', 'product-mailer-campaigns' ) ) . '</strong><br><span class="pmcpc-insight-meta">' . esc_html( trim( $status . ( $when ? ' • ' . $when : '' ) ) ) . '</span></li>';
                        }
                        echo '</ul>';
                    } else {
                        echo '<p class="description">' . esc_html__( 'No recent queue or send history for this automation yet.', 'product-mailer-campaigns' ) . '</p>';
                    }
                    echo '</div>';
                    echo '<div class="pmcpc-insight-col">';
                    $insight_type = $pmcpc_get_trigger_insight_type( $c );
                    $upcoming_heading = __( 'Upcoming / likely matches', 'product-mailer-campaigns' );
                    $empty_message = __( 'This automation is mostly event-driven, so there is no fixed next recipient to preview here yet. Use recent activity above to see who it has run for.', 'product-mailer-campaigns' );
                    if ( 'date' === $insight_type ) {
                        $upcoming_heading = __( 'Upcoming dates / likely matches', 'product-mailer-campaigns' );
                        $empty_message = __( 'No upcoming subscriber dates were found in the preview window yet. Make sure birthdays or anniversaries are stored on active subscriber records in a recognised format like 10 Mar or 10/03.', 'product-mailer-campaigns' );
                    } elseif ( 'lifecycle' === $insight_type ) {
                        $upcoming_heading = __( 'Eligibility preview', 'product-mailer-campaigns' );
                        $empty_message = __( 'No subscribers are close to this lifecycle threshold yet.', 'product-mailer-campaigns' );
                    }
                    echo '<h4>' . esc_html( $upcoming_heading ) . '</h4>';
                    if ( ! empty( $upcoming_matches ) ) {
                        echo '<ul class="pmcpc-insight-list">';
                        foreach ( $upcoming_matches as $candidate ) {
                            $email = isset( $candidate['email'] ) ? sanitize_email( (string) $candidate['email'] ) : '';
                            $note  = isset( $candidate['note'] ) ? (string) $candidate['note'] : '';
                            $ts    = isset( $candidate['ts'] ) ? (int) $candidate['ts'] : 0;
                            $when  = $ts > 0 ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $ts ) : '';
                            echo '<li><strong>' . esc_html( $email ? $email : __( 'Unknown subscriber', 'product-mailer-campaigns' ) ) . '</strong><br><span class="pmcpc-insight-meta">' . esc_html( trim( ( $when ? $when . ' • ' : '' ) . $note ) ) . '</span></li>';
                        }
                        echo '</ul>';
                    } else {
                        echo '<p class="description">' . esc_html( $empty_message ) . '</p>';
                    }
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                    echo '</td>';
                    echo '</tr>';
                }
            }

            echo '</tbody></table>';
            echo '</div></div>';
        };

        // Render based on selected view.
        if ( 'all' === $view ) {
            $wordpress_automations = array();
            $woocommerce_automations = array();
            foreach ( (array) $groups['automation'] as $automation_row ) {
                if ( $is_woocommerce_automation( $automation_row ) ) {
                    $woocommerce_automations[] = $automation_row;
                } else {
                    $wordpress_automations[] = $automation_row;
                }
            }
            $render_campaign_table( $wordpress_automations, __( 'WordPress automations', 'product-mailer-campaigns' ) );
            $render_campaign_table( $woocommerce_automations, __( 'WooCommerce automations', 'product-mailer-campaigns' ) );
            $render_campaign_table( $groups['one_time'], __( 'One-time scheduled', 'product-mailer-campaigns' ) );
            $render_campaign_table( $groups['weekly'], __( 'Weekly (recurring)', 'product-mailer-campaigns' ) );
            $render_campaign_table( $groups['recurring'], __( 'Recurring', 'product-mailer-campaigns' ) );
            $render_campaign_table( $groups['manual'], __( 'Manual / drafts', 'product-mailer-campaigns' ) );
        } elseif ( isset( $groups[ $view ] ) ) {
            $render_campaign_table( $groups[ $view ] );
        } else {
            $render_campaign_table( (array) $campaigns );
        }

        if ( empty( $campaigns ) ) {
            echo '<p>' . esc_html__( 'No campaigns found.', 'product-mailer-campaigns' ) . '</p>';
        }
            return;
