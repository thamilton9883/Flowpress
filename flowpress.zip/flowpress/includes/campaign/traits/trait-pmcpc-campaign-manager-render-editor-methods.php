<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Campaign_Manager_Render_Editor_Methods {
    protected function render_campaign_editor_view_from_context( array $context ) {
        if ( isset( $context['this'] ) ) {
            unset( $context['this'] );
        }

        extract( $context, EXTR_SKIP );

        require PMCPC_PLUGIN_DIR . 'includes/campaign/partials/pmcpc-campaign-editor-view.php';
    }
}
