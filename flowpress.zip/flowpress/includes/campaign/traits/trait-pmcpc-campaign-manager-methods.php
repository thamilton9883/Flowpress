<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/trait-pmcpc-campaign-manager-request-methods.php';
require_once __DIR__ . '/trait-pmcpc-campaign-manager-save-methods.php';
require_once __DIR__ . '/trait-pmcpc-campaign-manager-render-methods.php';
require_once __DIR__ . '/trait-pmcpc-campaign-manager-actions-methods.php';

trait PMCPC_Campaign_Manager_Methods {
    use PMCPC_Campaign_Manager_Request_Methods;
    use PMCPC_Campaign_Manager_Save_Methods;
    use PMCPC_Campaign_Manager_Render_Methods;
    use PMCPC_Campaign_Manager_Actions_Methods;
}
