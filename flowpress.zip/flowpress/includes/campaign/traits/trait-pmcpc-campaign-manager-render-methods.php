<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/trait-pmcpc-campaign-manager-render-list-methods.php';
require_once __DIR__ . '/trait-pmcpc-campaign-manager-render-editor-methods.php';

/**
 * Campaign admin page rendering methods.
 */
trait PMCPC_Campaign_Manager_Render_Methods {
    use PMCPC_Campaign_Manager_Render_List_Methods;
    use PMCPC_Campaign_Manager_Render_Editor_Methods;


    
public function render_page() {
        global $wpdb;
        $table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

        $current_id     = isset( $_GET['campaign_id'] ) ? absint( $_GET['campaign_id'] ) : 0;
        $request_action = isset( $_GET['action'] ) ? sanitize_key( (string) wp_unslash( $_GET['action'] ) ) : '';
        $is_new         = ( isset( $_GET['pmcpc_new'] ) && '1' === sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_new'] ) ) ) || in_array( $request_action, array( 'new', 'create' ), true );
        $campaign       = null;

        if ( $current_id ) {
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$campaign = $wpdb->get_row(
				$wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $table, $current_id )
			);
        }

        if ( $current_id && isset( $_GET['pmcpc_preview'] ) && '1' === $_GET['pmcpc_preview'] && $campaign ) {
            $nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
            if ( $nonce && ! wp_verify_nonce( $nonce, 'pmcpc_preview_campaign_' . (int) $current_id ) ) {
                wp_die( esc_html__( 'Security check failed.', 'product-mailer-campaigns' ) );
            }
            // Admin preview of the email HTML, with placeholders and products block rendered.
            $back_url = add_query_arg(
                array(
                    'page'        => 'pmcpc_campaigns',
                    'campaign_id' => (int) $current_id,
                ),
                admin_url( 'admin.php' )
            );

            $body_html = (string) $campaign->content;
            $body_html = str_replace( '{{first_name}}', esc_html__( 'Jane', 'product-mailer-campaigns' ), $body_html );
            $body_html = str_replace( '{{email}}', 'jane@example.com', $body_html );
            $body_html = str_replace( '{{unsubscribe_url}}', esc_url( home_url( '/?pmcpc_unsubscribe=preview' ) ), $body_html );
            $body_html = self::inject_products_block( $campaign, $body_html );

            $html  = '<div style="max-width:900px;margin:20px auto; padding:0 14px;">';
            $html .= '<p><a class="button" href="' . esc_url( $back_url ) . '">&larr; ' . esc_html__( 'Back to campaign', 'product-mailer-campaigns' ) . '</a></p>';
            $html .= '<h1 style="margin:0 0 10px;">' . esc_html( $campaign->subject ) . '</h1>';
            $html .= '<div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px;">' . $body_html . '</div>';
            $html .= '</div>';
            $allowed_html = wp_kses_allowed_html( 'post' );

            // Email previews commonly rely on inline styles and table markup.
            // Expand allowed attributes so the admin preview matches the sent email layout.
            $global_attrs = array(
                'class'       => true,
                'id'          => true,
                'style'       => true,
                'title'       => true,
                'role'        => true,
                'align'       => true,
                'valign'      => true,
                'width'       => true,
                'height'      => true,
                'bgcolor'     => true,
                'aria-label'  => true,
                'aria-hidden' => true,
            );

            foreach ( $allowed_html as $tag => $attrs ) {
                if ( is_array( $attrs ) ) {
                    $allowed_html[ $tag ] = array_merge( $attrs, $global_attrs );
                } else {
                    $allowed_html[ $tag ] = $global_attrs;
                }
            }

            // Ensure common email elements/attributes are allowed.
            $allowed_html['a']     = array_merge( $allowed_html['a'] ?? array(), array( 'href' => true, 'target' => true, 'rel' => true ) );
            $allowed_html['img']   = array_merge( $allowed_html['img'] ?? array(), array( 'src' => true, 'srcset' => true, 'sizes' => true, 'alt' => true ) );
            $allowed_html['table'] = array_merge( $allowed_html['table'] ?? array(), array( 'cellpadding' => true, 'cellspacing' => true, 'border' => true ) );

            echo '<div class="wrap pmcpc-email-preview">' . wp_kses( $html, $allowed_html ) . '</div>';
            return;
        }
        self::render_campaign_query_notice( 'pmcpc_test_campaign_result', 'test_campaign' );
        self::render_campaign_query_notice( 'pmcpc_toggle_result', 'toggle_campaign' );
        self::render_campaign_query_notice( 'pmcpc_delete_result', 'delete_campaign' );
        self::render_campaign_query_notice( 'pmcpc_queue_result', 'queue_campaign' );

        if ( ! $campaign ) {
            $campaign = (object) array(
                'id'                          => 0,
                'name'                        => '',
                'subject'                     => '',
                'from_name'                   => PMCPC_Settings::get( 'from_name_default', get_bloginfo( 'name' ) ),
                'from_email'                  => PMCPC_Settings::get( 'from_email_default', get_option( 'admin_email' ) ),
                'content'                     => '<p>Hello {{first_name}},</p>

<p>This is a sample campaign. You can customize this message with your product highlights, promotions, or latest updates.</p>

',
                'status'                      => 'draft',
                'is_welcome'                  => 0,
                'is_post_purchase'            => 0,
                'target_tag'                  => '',
                'target_source_tags'          => '',
                'target_origin_tags'          => '',
                'target_lifecycle_tags'       => '',
                'pro_segment_key'            => '',
                'welcome_delay_minutes'       => 0,
                'post_purchase_delay_minutes' => 0,
                'broadcast_delay_minutes'     => 0,
                'trigger_delay_minutes'       => 0,
                'campaign_type'               => 'manual',
                'schedule_type'               => 'manual',
                'schedule_datetime'           => null,
                'schedule_frequency'          => '',
                'next_run_at'                 => null,
                'product_block_enabled'       => 0,
                'product_block_source'        => 'latest',
                'product_block_limit'         => 3,
                'product_block_categories'    => '',
                'auto_footer_links_enabled'   => 1,
            );
        } else {
            // Ensure new properties exist on existing rows.
            if ( ! isset( $campaign->schedule_type ) ) {
                $campaign->schedule_type = 'manual';
            }
            if ( ! isset( $campaign->campaign_type ) || ! $campaign->campaign_type ) {
                $campaign->campaign_type = 'manual';
            }
            if ( ! isset( $campaign->schedule_datetime ) ) {
                $campaign->schedule_datetime = null;
            }
            if ( ! isset( $campaign->schedule_frequency ) ) {
                $campaign->schedule_frequency = '';
            }
            if ( ! isset( $campaign->next_run_at ) ) {
                $campaign->next_run_at = null;
            }
            if ( ! isset( $campaign->target_source_tags ) ) {
                $campaign->target_source_tags = '';
            }
            if ( ! isset( $campaign->target_origin_tags ) ) {
                $campaign->target_origin_tags = '';
            }
            if ( ! isset( $campaign->target_lifecycle_tags ) ) {
                $campaign->target_lifecycle_tags = '';
            }
            if ( ! isset( $campaign->exclude_tags ) ) {
                $campaign->exclude_tags = '';
            }
            if ( ! isset( $campaign->pro_segment_key ) ) {
                $campaign->pro_segment_key = '';
            }
            if ( ! isset( $campaign->product_block_enabled ) ) {
                $campaign->product_block_enabled = 0;
            }
            if ( ! isset( $campaign->product_block_source ) || ! $campaign->product_block_source ) {
                $campaign->product_block_source = 'latest';
            }
            if ( ! isset( $campaign->product_block_limit ) ) {
                $campaign->product_block_limit = 3;
            }
            if ( ! isset( $campaign->product_block_specific_ids ) ) {
                $campaign->product_block_specific_ids = '';
            }
            if ( ! isset( $campaign->product_block_categories ) ) {
                $campaign->product_block_categories = '';
            }
            if ( ! isset( $campaign->product_block_exclude_oos ) ) {
                $campaign->product_block_exclude_oos = 0;
            }
            if ( ! isset( $campaign->auto_footer_links_enabled ) ) {
                $campaign->auto_footer_links_enabled = 1;
            }
        }

        // Derive schedule date/time fields for the UI.
        // Prefer the next_run_at value so the form reflects the next scheduled run.
        // If there is no next_run_at yet, fall back to the original schedule_datetime.
        $schedule_type = $campaign->schedule_type;
        $schedule_date = '';
        $schedule_time = '';

        $source_dt = '';
        if ( ! empty( $campaign->next_run_at ) ) {
            $source_dt = $campaign->next_run_at;
        } elseif ( ! empty( $campaign->schedule_datetime ) ) {
            $source_dt = $campaign->schedule_datetime;
        }

        if ( $source_dt ) {
            $ts = strtotime( $source_dt );
            if ( $ts ) {
                $schedule_date = gmdate( 'Y-m-d', $ts );
                $schedule_time = gmdate( 'H:i', $ts );
            }
        }

        $product_block_enabled      = ! empty( $campaign->product_block_enabled );
        $product_block_source       = $campaign->product_block_source;
        $product_block_limit        = (int) $campaign->product_block_limit;
        $product_block_specific_ids = isset( $campaign->product_block_specific_ids ) ? $campaign->product_block_specific_ids : '';
        $product_block_categories   = isset( $campaign->product_block_categories ) ? $campaign->product_block_categories : '';
        $product_block_layout       = isset( $campaign->product_block_layout ) ? (string) $campaign->product_block_layout : 'classic_left';
        $product_block_exclude_oos  = ! empty( $campaign->product_block_exclude_oos );
        $auto_footer_links_enabled = isset( $campaign->auto_footer_links_enabled ) ? (int) $campaign->auto_footer_links_enabled : 1;
        $campaign_id = isset( $campaign->id ) ? absint( $campaign->id ) : 0;
        $subscriber_page_config = array();
        $per_campaign_subscriber_page_config = ( $campaign_id > 0 ) ? get_option( 'pmcpc_campaign_subscriber_page_settings_' . $campaign_id, null ) : null;
        if ( is_array( $per_campaign_subscriber_page_config ) ) {
            $subscriber_page_config = $per_campaign_subscriber_page_config;
        } else {
            $subscriber_page_settings = get_option( 'pmcpc_campaign_subscriber_page_settings', array() );
            $subscriber_page_config   = ( is_array( $subscriber_page_settings ) && ! empty( $subscriber_page_settings[ $campaign_id ] ) && is_array( $subscriber_page_settings[ $campaign_id ] ) ) ? $subscriber_page_settings[ $campaign_id ] : array();
        }
                $subscriber_page_has_saved_data = (
            ! empty( $subscriber_page_config['title'] )
            || ! empty( $subscriber_page_config['excerpt'] )
            || ! empty( $subscriber_page_config['content'] )
            || ! empty( $subscriber_page_config['topic'] )
            || ! empty( $subscriber_page_config['post_status'] )
            || ! empty( $subscriber_page_config['featured'] )
            || ! empty( $subscriber_page_config['image_url'] )
            || ! empty( $subscriber_page_config['cta_label'] )
            || ! empty( $subscriber_page_config['cta_url'] )
            || ( isset( $subscriber_page_config['visibility'] ) && 'public' !== (string) $subscriber_page_config['visibility'] )
            || ! empty( $subscriber_page_config['segment'] )
            || ! empty( $subscriber_page_config['expires_at'] )
        );
        $subscriber_page_enabled  = ( ! empty( $subscriber_page_config['enabled'] ) || $subscriber_page_has_saved_data ) ? 1 : 0;
        $subscriber_page_title    = isset( $subscriber_page_config['title'] ) ? (string) $subscriber_page_config['title'] : '';
        $subscriber_page_excerpt  = isset( $subscriber_page_config['excerpt'] ) ? (string) $subscriber_page_config['excerpt'] : '';
        $subscriber_page_content  = isset( $subscriber_page_config['content'] ) ? (string) $subscriber_page_config['content'] : '';
        $subscriber_page_topic    = isset( $subscriber_page_config['topic'] ) ? (string) $subscriber_page_config['topic'] : '';
        $subscriber_page_post_status = isset( $subscriber_page_config['post_status'] ) ? (string) $subscriber_page_config['post_status'] : '';
        $subscriber_page_featured = ! empty( $subscriber_page_config['featured'] ) ? 1 : 0;
        $subscriber_page_image_url = isset( $subscriber_page_config['image_url'] ) ? (string) $subscriber_page_config['image_url'] : '';
        $subscriber_page_cta_label = isset( $subscriber_page_config['cta_label'] ) ? (string) $subscriber_page_config['cta_label'] : '';
        $subscriber_page_cta_url   = isset( $subscriber_page_config['cta_url'] ) ? (string) $subscriber_page_config['cta_url'] : '';
        $subscriber_page_visibility = isset( $subscriber_page_config['visibility'] ) ? (string) $subscriber_page_config['visibility'] : 'public';
        $subscriber_page_segment    = isset( $subscriber_page_config['segment'] ) ? (string) $subscriber_page_config['segment'] : '';
        $subscriber_page_expires_at = isset( $subscriber_page_config['expires_at'] ) ? (string) $subscriber_page_config['expires_at'] : '';
        if ( '' !== $subscriber_page_expires_at ) {
            $subscriber_page_expires_at = str_replace( ' ', 'T', substr( $subscriber_page_expires_at, 0, 16 ) );
        }
        $selected_category_ids      = array_filter( array_map( 'absint', explode( ',', $product_block_categories ) ) );

	// Fetch recent campaigns for listing (with optional sorting).
	// Whitelist both the column and direction, and sanitize the final ORDER BY with sanitize_sql_orderby()
	// to avoid dynamic SQL injection issues and satisfy security scanners.
	// Default to sorting by next run (soonest first) so scheduled/automation campaigns bubble to the top.
	$orderby_raw = isset( $_GET['orderby'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['orderby'] ) ) : 'next_run_at';
	$orderby     = sanitize_key( $orderby_raw );

	$order_raw = isset( $_GET['order'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['order'] ) ) : 'ASC';
	$order     = strtoupper( sanitize_key( $order_raw ) ); // results in ASC/DESC when valid.

	$allowed_orderby = array(
		'created_at'  => 'created_at',
		'name'        => 'name',
		'status'      => 'status',
		'next_run_at' => 'next_run_at',
	);

	if ( ! isset( $allowed_orderby[ $orderby ] ) ) {
		$orderby = 'next_run_at';
	}

	if ( ! in_array( $order, array( 'ASC', 'DESC' ), true ) ) {
		$order = 'ASC';
	}

		// Campaign scheduling is most useful sorted soonest-first; keep next_run ordering ascending.
		if ( 'next_run_at' === $orderby ) {
			$order = 'ASC';
		}

	$orderby_sql = $allowed_orderby[ $orderby ];

	if ( 'next_run_at' === $orderby_sql ) {
		// Special handling: sort NULL next_run_at values last using a computed alias.
		$order_clause = sanitize_sql_orderby( 'next_run_at_is_null ASC, next_run_at ' . $order );

		if ( empty( $order_clause ) ) {
			$order_clause = sanitize_sql_orderby( 'next_run_at_is_null ASC, next_run_at DESC' );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$campaigns = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *, (next_run_at IS NULL) AS next_run_at_is_null FROM %i ORDER BY {$order_clause} LIMIT %d",
				$table,
				200
			)
		);
	} else {
		$order_clause = sanitize_sql_orderby( $orderby_sql . ' ' . $order );

		if ( empty( $order_clause ) ) {
			$order_clause = sanitize_sql_orderby( 'created_at DESC' );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$campaigns = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM %i ORDER BY {$order_clause} LIMIT %d",
				$table,
				200
			)
		);
	}

        settings_errors( 'pmcpc_campaigns' );

        $source_bits = array();
        // If this is a new campaign and we arrived here from a shortcut,
        // show a small hint about where it came from.
        if ( ! $current_id ) {
        
        if ( isset( $_GET['trigger'] ) ) {
        $trigger_from = sanitize_text_field( (string) wp_unslash( $_GET['trigger'] ) );
        switch ( $trigger_from ) {
        case 'post_purchase':
        $source_bits[] = __( 'WooCommerce order automation', 'product-mailer-campaigns' );
        break;
        case 'welcome':
        case 'new_subscriber':
        $source_bits[] = __( 'Welcome automation', 'product-mailer-campaigns' );
        break;
        case 'date':
        $source_bits[] = __( 'Date/time schedule or manual only', 'product-mailer-campaigns' );
        break;
        }
        }
        
        if ( isset( $_GET['pro_segment_key'] ) ) {
        $seg_from = sanitize_text_field( (string) wp_unslash( $_GET['pro_segment_key'] ) );
        switch ( $seg_from ) {
        case 'customers':
        $source_bits[] = __( 'Segment: Customers (at least one order)', 'product-mailer-campaigns' );
        break;
        case 'new_customers':
        $source_bits[] = __( 'Segment: New customers (first order only)', 'product-mailer-campaigns' );
        break;
        case 'repeat_customers':
        $source_bits[] = __( 'Segment: Repeat customers (2+ orders)', 'product-mailer-campaigns' );
        break;
        case 'recent':
        $source_bits[] = __( 'Segment: Recent customers (last 30 days)', 'product-mailer-campaigns' );
        break;
        case 'high_value':
        $source_bits[] = __( 'Segment: High-value customers', 'product-mailer-campaigns' );
        break;
        case 'vip':
        $source_bits[] = __( 'Segment: VIP customers', 'product-mailer-campaigns' );
        break;
        case 'lapsed':
        $source_bits[] = __( 'Segment: Lapsed customers', 'product-mailer-campaigns' );
        break;
        }
        }
        
        if ( ! empty( $source_bits ) ) {
        echo '<p class="description">';
        printf(
					/* translators: %s: creation sources. */
					esc_html__( 'Created from: %s. Audience filter has been preselected.', 'product-mailer-campaigns' ),
        esc_html( implode( ' · ', $source_bits ) )
        );
        echo '</p>';
        }
        }
        $create_campaign_url = add_query_arg(
            array(
                'page'      => 'pmcpc_campaigns',
                'pmcpc_new' => '1',
            ),
            admin_url( 'admin.php' )
        );
        $create_automation_url = add_query_arg(
            array(
                'page'          => 'pmcpc_campaigns',
                'campaign_type' => 'automation',
                'pmcpc_new'     => '1',
                'pmcpc_stage'   => '2',
                'step'          => 'timing',
                'stage'         => 'timing',
                'wizard_step'   => 'timing',
                'tab'           => 'timing',
                'view'          => 'timing',
            ),
            admin_url( 'admin.php' )
        );

        $campaign_mode_label = __( 'Manual', 'product-mailer-campaigns' );
        if ( ! empty( $campaign->automation_trigger ) && 'none' !== (string) $campaign->automation_trigger ) {
            $campaign_mode_label = __( 'Automation', 'product-mailer-campaigns' );
        } elseif ( ! empty( $campaign->is_welcome ) || ! empty( $campaign->is_post_purchase ) ) {
            $campaign_mode_label = __( 'Automation', 'product-mailer-campaigns' );
        } elseif ( isset( $campaign->schedule_type ) && 'manual' !== (string) $campaign->schedule_type ) {
            $campaign_mode_label = __( 'Scheduled', 'product-mailer-campaigns' );
        } elseif ( ! $current_id && isset( $_GET['trigger'] ) ) {
            $campaign_mode_label = 'date' === sanitize_text_field( (string) wp_unslash( $_GET['trigger'] ) )
                ? __( 'Manual', 'product-mailer-campaigns' )
                : __( 'Automation', 'product-mailer-campaigns' );
        }

        if ( ! $current_id && ! $is_new ) {
            $this->render_campaign_list_view_from_context( get_defined_vars() );
            return;
        }

        $this->render_campaign_editor_view_from_context( get_defined_vars() );
    }
}
