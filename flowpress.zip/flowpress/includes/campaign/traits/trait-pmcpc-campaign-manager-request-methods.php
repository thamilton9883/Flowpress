<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Campaign schema, request, and payload helper methods.
 */
trait PMCPC_Campaign_Manager_Request_Methods {
    /**
     * Ensure new flag / automation / scheduling columns exist on older installs.
     */
		/*
		 * This method performs direct schema/introspection queries (SHOW COLUMNS / ALTER TABLE).
		 * These are intentional during upgrade routines and are not cacheable.
		 */
			protected function pmcpc_ensure_schema_flags() {
			        global $wpdb;
			        /* phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange */
		    $table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

	        // These schema changes run only for admins and only when needed.
	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'is_welcome' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
		            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN is_welcome TINYINT(1) NOT NULL DEFAULT 0" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
		}

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'is_post_purchase' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
		            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN is_post_purchase TINYINT(1) NOT NULL DEFAULT 0" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'target_tag' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
		            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN target_tag VARCHAR(100) NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'target_source_tags' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
		            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN target_source_tags TEXT NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'target_lifecycle_tags' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
		            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN target_lifecycle_tags TEXT NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'target_origin_tags' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
        if ( empty( $columns ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN target_origin_tags TEXT NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'exclude_tags' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
        if ( empty( $columns ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN exclude_tags TEXT NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'welcome_delay_minutes' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN welcome_delay_minutes INT(11) UNSIGNED NOT NULL DEFAULT 0" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'post_purchase_delay_minutes' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN post_purchase_delay_minutes INT(11) UNSIGNED NOT NULL DEFAULT 0" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'broadcast_delay_minutes' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN broadcast_delay_minutes INT(11) UNSIGNED NOT NULL DEFAULT 0" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // Canonical trigger delay (unified for all triggers).
	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'trigger_delay_minutes' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN trigger_delay_minutes INT(11) UNSIGNED NOT NULL DEFAULT 0" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

        // New scheduling fields.
	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'schedule_type' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN schedule_type VARCHAR(20) NOT NULL DEFAULT 'manual'" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // Guided builder: campaign type (UI only).
	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'campaign_type' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN campaign_type VARCHAR(30) NOT NULL DEFAULT 'manual'" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'schedule_datetime' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN schedule_datetime DATETIME NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'schedule_frequency' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN schedule_frequency VARCHAR(20) NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'next_run_at' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN next_run_at DATETIME NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

        // Product block configuration.
	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'product_block_enabled' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN product_block_enabled TINYINT(1) NOT NULL DEFAULT 0" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'product_block_source' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN product_block_source VARCHAR(50) NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'product_block_limit' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN product_block_limit INT(11) UNSIGNED NOT NULL DEFAULT 3" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'auto_footer_links_enabled' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN auto_footer_links_enabled TINYINT(1) NOT NULL DEFAULT 1" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		        $columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'product_block_specific_ids' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
		            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
		            $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN product_block_specific_ids TEXT NULL" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }
	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i LIKE %s', $table, 'pro_segment_key' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( $wpdb->prepare( 'ALTER TABLE %i ADD COLUMN pro_segment_key VARCHAR(50) NULL', $table ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	        $columns = $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i LIKE %s', $table, 'product_block_categories' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        if ( empty( $columns ) ) {
	            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
	            $wpdb->query( $wpdb->prepare( 'ALTER TABLE %i ADD COLUMN product_block_categories TEXT NULL', $table ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
	        }

			// Product block layout preset (email-friendly presets).
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
			$columns = $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i LIKE %s', $table, 'product_block_layout' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
			if ( empty( $columns ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
				$wpdb->query( $wpdb->prepare( "ALTER TABLE %i ADD COLUMN product_block_layout VARCHAR(30) NOT NULL DEFAULT 'classic_left'", $table ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
			}

			// Exclude out-of-stock products (optional filter for the products block).
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
			$columns = $wpdb->get_col( $wpdb->prepare( "SHOW COLUMNS FROM `{$table}` LIKE %s", 'product_block_exclude_oos' ) ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
			if ( empty( $columns ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
				$wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN product_block_exclude_oos TINYINT(1) NOT NULL DEFAULT 0" ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter
			}

		// Intentionally leaving direct DB query sniffs disabled for this file: this plugin uses custom tables.
	}
    protected function maybe_handle_campaign_save_request() {
        $nonce = isset( $_POST['pmcpc_save_campaign_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_save_campaign_nonce'] ) ) : '';
        if ( $nonce && wp_verify_nonce( $nonce, 'pmcpc_save_campaign' ) ) {
            $this->save_campaign();
        }
    }

    protected static function maybe_handle_legacy_campaign_delete_request() {
        if ( isset( $_GET['pmcpc_delete_campaign'], $_GET['campaign_id'] ) ) {
            self::handle_delete_campaign_action();
        }
    }

            public function handle_request() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Save/edit campaign via the form.
			$this->maybe_handle_campaign_save_request();

        // Backward-compatible support for older inline delete links.
        // Delegate to the admin-post handler so all delete logic stays in one place.
        self::maybe_handle_legacy_campaign_delete_request();
	    }
		// Intentionally leaving direct DB query sniffs disabled for this file: this plugin uses custom tables.

    /**
     * Normalize a comma-separated list into a unique CSV string.
     *
     * @param string $raw_csv Raw CSV value.
     * @return string
     */
    protected static function pmcpc_normalize_csv_list( $raw_csv ) {
        $raw_csv = sanitize_text_field( (string) $raw_csv );
        if ( '' === $raw_csv ) {
            return '';
        }

        $parts = array_map( 'trim', explode( ',', $raw_csv ) );
        $parts = array_values( array_unique( array_filter( $parts ) ) );

        return ! empty( $parts ) ? implode( ',', $parts ) : '';
    }

    /**
     * Read a checkbox/multi-select style post field into unique CSV.
     *
     * @param string $array_key  POST key for array input.
     * @param string $string_key POST key for CSV fallback input.
     * @return string
     */
    protected static function pmcpc_read_unique_csv_from_post( $array_key, $string_key = '' ) {
        if ( isset( $_POST[ $array_key ] ) ) {
            $raw_values = (array) wp_unslash( $_POST[ $array_key ] );
            $values     = array();

            foreach ( $raw_values as $value ) {
                $value = sanitize_text_field( (string) $value );
                if ( '' !== $value ) {
                    $values[] = $value;
                }
            }

            $values = array_values( array_unique( $values ) );

            return ! empty( $values ) ? implode( ',', $values ) : '';
        }

        if ( '' !== $string_key && isset( $_POST[ $string_key ] ) ) {
            return self::pmcpc_normalize_csv_list( wp_unslash( $_POST[ $string_key ] ) );
        }

        return '';
    }

    /**
     * Read a posted array of IDs into a unique CSV string.
     *
     * @param string $array_key POST key.
     * @return string
     */
    protected static function pmcpc_read_absint_csv_from_post( $array_key ) {
        if ( ! isset( $_POST[ $array_key ] ) ) {
            return '';
        }

        $raw_values = (array) wp_unslash( $_POST[ $array_key ] );
        $values     = array();

        foreach ( $raw_values as $value ) {
            $value = absint( wp_unslash( $value ) );
            if ( $value > 0 ) {
                $values[] = $value;
            }
        }

        $values = array_values( array_unique( $values ) );

        return ! empty( $values ) ? implode( ',', $values ) : '';
    }

    /**
     * Allowed automation triggers for campaign saving.
     *
     * @return array
     */
    protected static function pmcpc_get_allowed_automation_triggers() {
		$allowed_triggers = array( 'none', 'welcome', 'welcome_follow_up', 'post_purchase', 'lead_magnet_download', 'subscriber_inactive', 'subscriber_anniversary', 'subscriber_birthday' );

		$wc_enabled = ( class_exists( 'WooCommerce' ) && function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() );
		if ( $wc_enabled ) {
			$allowed_triggers = array_merge(
				$allowed_triggers,
				array(
					'abandoned_cart_step_1',
					'abandoned_cart_step_2',
					'abandoned_cart_step_3',
					'post_purchase',
					'review_request',
					'new_customer',
					'repeat_customer',
					'high_value',
					'vip_customer',
					'customer_inactive',
					'lapsed_high_value_customer',
				)
			);
		}

		if ( defined( 'PMCPC_PRO_VERSION' ) || class_exists( 'PMCPC_Pro_Bootstrap' ) ) {
			$allowed_triggers = array_merge( $allowed_triggers, array( 'review_request' ) );
		}

		return (array) apply_filters( 'pmcpc_allowed_automation_triggers', $allowed_triggers );
    }

    /**
     * Normalize scheduling fields and derive status/next-run values.
     *
     * @param string      $schedule_type      Schedule type.
     * @param string      $schedule_date      Schedule date.
     * @param string      $schedule_time      Schedule time.
     * @param string      $schedule_frequency Schedule frequency.
     * @param string      $current_status     Current campaign status.
     * @param object|null $existing           Existing campaign row.
     * @return array<string,mixed>
     */
    protected static function pmcpc_normalize_schedule_for_save( $schedule_type, $schedule_date, $schedule_time, $schedule_frequency, $current_status = 'draft', $existing = null ) {
        $schedule_type      = sanitize_key( (string) $schedule_type );
        $schedule_date      = sanitize_text_field( (string) $schedule_date );
        $schedule_time      = sanitize_text_field( (string) $schedule_time );
        $schedule_frequency = sanitize_text_field( (string) $schedule_frequency );
        $schedule_datetime  = null;
        $next_run_at        = null;
        $status             = (string) $current_status ? (string) $current_status : 'draft';

        if ( 'manual' !== $schedule_type && ! empty( $schedule_date ) ) {
            $time_str = $schedule_time ? $schedule_time : '00:00';
            if ( 5 === strlen( $time_str ) ) {
                $time_str .= ':00';
            }

            $dt_raw = $schedule_date . ' ' . $time_str;

            try {
                $tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
                $dt = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $dt_raw, $tz );
                if ( $dt instanceof DateTimeImmutable ) {
                    $schedule_datetime = gmdate( 'Y-m-d H:i:s', $dt->getTimestamp() );
                } else {
                    $schedule_type      = 'manual';
                    $schedule_frequency = '';
                }
            } catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
                $schedule_type      = 'manual';
                $schedule_frequency = '';
            }
        } else {
            $schedule_type      = 'manual';
            $schedule_frequency = '';
        }

        $now_ts       = current_time( 'timestamp' );
        $scheduled_ts = 0;
        if ( $schedule_datetime ) {
            try {
                $scheduled_ts = ( new DateTimeImmutable( $schedule_datetime, new DateTimeZone( 'UTC' ) ) )->getTimestamp();
            } catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
                $scheduled_ts = 0;
            }
        }

        $schedule_is_future = ( 'manual' !== $schedule_type && $schedule_datetime && $scheduled_ts && $scheduled_ts > $now_ts );

        if ( $schedule_is_future ) {
            $status = 'scheduled';
        } else {
            $schedule_type      = 'manual';
            $schedule_frequency = '';
            $schedule_datetime  = null;
        }

        if ( $existing ) {
            if ( $schedule_is_future ) {
                if ( 'manual' === $existing->schedule_type || $schedule_datetime !== $existing->schedule_datetime ) {
                    $next_run_at = $schedule_datetime;
                } else {
                    $next_run_at = $existing->next_run_at;
                    if ( empty( $next_run_at ) ) {
                        $next_run_at = $schedule_datetime;
                    }
                }
            } else {
                $next_run_at = null;
            }
        } elseif ( $schedule_is_future ) {
            $next_run_at = $schedule_datetime;
        }

        return array(
            'schedule_type'      => $schedule_type,
            'schedule_frequency' => $schedule_frequency,
            'schedule_datetime'  => $schedule_datetime,
            'schedule_is_future' => $schedule_is_future,
            'status'             => $status,
            'next_run_at'        => $next_run_at,
        );
    }

    /**
     * Load existing subscriber page settings for a campaign.
     *
     * @param int $campaign_id Campaign ID.
     * @return array
     */
    protected static function pmcpc_get_existing_subscriber_page_config( $campaign_id ) {
        $campaign_id = absint( $campaign_id );
        if ( ! $campaign_id ) {
            return array();
        }

        $per_campaign = get_option( 'pmcpc_campaign_subscriber_page_settings_' . $campaign_id, null );
        if ( is_array( $per_campaign ) ) {
            return $per_campaign;
        }

        $all_settings = get_option( 'pmcpc_campaign_subscriber_page_settings', array() );
        if ( is_array( $all_settings ) && ! empty( $all_settings[ $campaign_id ] ) && is_array( $all_settings[ $campaign_id ] ) ) {
            return $all_settings[ $campaign_id ];
        }

        return array();
    }

    /**
     * Build subscriber page settings from the campaign form request.
     *
     * @param int $campaign_id Campaign ID.
     * @return array
     */
    protected static function pmcpc_get_subscriber_page_settings_from_post( $campaign_id ) {
        $existing_config                  = self::pmcpc_get_existing_subscriber_page_config( $campaign_id );
        $settings_present                 = isset( $_POST['subscriber_page_settings_present'] ) ? 1 : 0;
        $payload                          = isset( $_POST['subscriber_page_payload'] ) ? json_decode( wp_unslash( (string) $_POST['subscriber_page_payload'] ), true ) : null;
        $payload                          = is_array( $payload ) ? $payload : array();
        $subscriber_page_title            = isset( $payload['title'] ) ? sanitize_text_field( (string) $payload['title'] ) : ( isset( $_POST['subscriber_page_title'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['subscriber_page_title'] ) ) : ( isset( $existing_config['title'] ) ? (string) $existing_config['title'] : '' ) );
        $subscriber_page_excerpt          = isset( $payload['excerpt'] ) ? sanitize_textarea_field( (string) $payload['excerpt'] ) : ( isset( $_POST['subscriber_page_excerpt'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['subscriber_page_excerpt'] ) ) : ( isset( $existing_config['excerpt'] ) ? (string) $existing_config['excerpt'] : '' ) );
        $subscriber_page_content          = isset( $payload['content'] ) ? wp_kses_post( (string) $payload['content'] ) : ( isset( $_POST['subscriber_page_content'] ) ? wp_kses_post( (string) wp_unslash( $_POST['subscriber_page_content'] ) ) : ( isset( $existing_config['content'] ) ? (string) $existing_config['content'] : '' ) );
        $subscriber_page_topic            = isset( $payload['topic'] ) ? sanitize_text_field( (string) $payload['topic'] ) : ( isset( $_POST['subscriber_page_topic'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['subscriber_page_topic'] ) ) : ( isset( $existing_config['topic'] ) ? (string) $existing_config['topic'] : '' ) );
        $subscriber_page_post_status      = isset( $payload['post_status'] ) ? sanitize_key( (string) $payload['post_status'] ) : ( isset( $_POST['subscriber_page_post_status'] ) ? sanitize_key( (string) wp_unslash( $_POST['subscriber_page_post_status'] ) ) : ( isset( $existing_config['post_status'] ) ? sanitize_key( (string) $existing_config['post_status'] ) : '' ) );
        $subscriber_page_featured         = isset( $payload['featured'] ) ? ( ! empty( $payload['featured'] ) ? 1 : 0 ) : ( $settings_present ? ( isset( $_POST['subscriber_page_featured'] ) ? 1 : 0 ) : ( ! empty( $existing_config['featured'] ) ? 1 : 0 ) );
        $subscriber_page_image_url        = isset( $payload['image_url'] ) ? esc_url_raw( (string) $payload['image_url'] ) : ( isset( $_POST['subscriber_page_image_url'] ) ? esc_url_raw( (string) wp_unslash( $_POST['subscriber_page_image_url'] ) ) : ( isset( $existing_config['image_url'] ) ? esc_url_raw( (string) $existing_config['image_url'] ) : '' ) );
        $subscriber_page_cta_label        = isset( $payload['cta_label'] ) ? sanitize_text_field( (string) $payload['cta_label'] ) : ( isset( $_POST['subscriber_page_cta_label'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['subscriber_page_cta_label'] ) ) : ( isset( $existing_config['cta_label'] ) ? (string) $existing_config['cta_label'] : '' ) );
        $subscriber_page_cta_url          = isset( $payload['cta_url'] ) ? esc_url_raw( (string) $payload['cta_url'] ) : ( isset( $_POST['subscriber_page_cta_url'] ) ? esc_url_raw( (string) wp_unslash( $_POST['subscriber_page_cta_url'] ) ) : ( isset( $existing_config['cta_url'] ) ? esc_url_raw( (string) $existing_config['cta_url'] ) : '' ) );
        $subscriber_page_visibility       = isset( $payload['visibility'] ) ? sanitize_key( (string) $payload['visibility'] ) : ( isset( $_POST['subscriber_page_visibility'] ) ? sanitize_key( (string) wp_unslash( $_POST['subscriber_page_visibility'] ) ) : ( isset( $existing_config['visibility'] ) ? sanitize_key( (string) $existing_config['visibility'] ) : 'public' ) );
        $subscriber_page_segment          = isset( $payload['segment'] ) ? sanitize_text_field( (string) $payload['segment'] ) : ( isset( $_POST['subscriber_page_segment'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['subscriber_page_segment'] ) ) : ( isset( $existing_config['segment'] ) ? (string) $existing_config['segment'] : '' ) );
        $subscriber_page_expires_at       = isset( $payload['expires_at'] ) ? sanitize_text_field( (string) $payload['expires_at'] ) : ( isset( $_POST['subscriber_page_expires_at'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['subscriber_page_expires_at'] ) ) : ( isset( $existing_config['expires_at'] ) ? (string) $existing_config['expires_at'] : '' ) );

        $existing_config_has_data = (
            ! empty( $existing_config['title'] )
            || ! empty( $existing_config['excerpt'] )
            || ! empty( $existing_config['content'] )
            || ! empty( $existing_config['topic'] )
            || ! empty( $existing_config['post_status'] )
            || ! empty( $existing_config['featured'] )
            || ! empty( $existing_config['image_url'] )
            || ! empty( $existing_config['cta_label'] )
            || ! empty( $existing_config['cta_url'] )
            || ( isset( $existing_config['visibility'] ) && 'public' !== (string) $existing_config['visibility'] )
            || ! empty( $existing_config['segment'] )
            || ! empty( $existing_config['expires_at'] )
        );

        $fields_have_data = (
            '' !== $subscriber_page_title
            || '' !== $subscriber_page_excerpt
            || '' !== $subscriber_page_content
            || '' !== $subscriber_page_topic
            || '' !== $subscriber_page_post_status
            || ! empty( $subscriber_page_featured )
            || '' !== $subscriber_page_image_url
            || '' !== $subscriber_page_cta_label
            || '' !== $subscriber_page_cta_url
            || 'public' !== $subscriber_page_visibility
            || '' !== $subscriber_page_segment
            || '' !== $subscriber_page_expires_at
        );

        $enabled = isset( $payload['enabled'] )
            ? ( ! empty( $payload['enabled'] ) ? 1 : 0 )
            : ( $settings_present
                ? ( ( isset( $_POST['publish_to_subscriber_page'] ) || $fields_have_data || $existing_config_has_data ) ? 1 : 0 )
                : ( ( ! empty( $existing_config['enabled'] ) || $existing_config_has_data ) ? 1 : 0 ) );

        if ( '' !== $subscriber_page_expires_at ) {
            $subscriber_page_expires_at = str_replace( 'T', ' ', $subscriber_page_expires_at );
            if ( 16 === strlen( $subscriber_page_expires_at ) ) {
                $subscriber_page_expires_at .= ':00';
            }
        }

        if ( ! in_array( $subscriber_page_post_status, array( '', 'publish', 'draft', 'private' ), true ) ) {
            $subscriber_page_post_status = '';
        }
        if ( ! in_array( $subscriber_page_visibility, array( 'public', 'subscribers', 'segment', 'private' ), true ) ) {
            $subscriber_page_visibility = 'public';
        }

        return array(
            'enabled'     => (int) $enabled,
            'title'       => $subscriber_page_title,
            'excerpt'     => $subscriber_page_excerpt,
            'content'     => $subscriber_page_content,
            'topic'       => $subscriber_page_topic,
            'post_status' => $subscriber_page_post_status,
            'featured'    => (int) $subscriber_page_featured,
            'image_url'   => $subscriber_page_image_url,
            'cta_label'   => $subscriber_page_cta_label,
            'cta_url'     => $subscriber_page_cta_url,
            'visibility'  => $subscriber_page_visibility,
            'segment'     => $subscriber_page_segment,
            'expires_at'  => $subscriber_page_expires_at,
        );
    }

    /**
     * Product block settings from the campaign form request.
     *
     * @return array
     */
    protected static function pmcpc_get_product_block_settings_from_post() {
        $layout = isset( $_POST['product_block_layout'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['product_block_layout'] ) ) : 'classic_left';
        if ( ! in_array( $layout, array( 'classic_left', 'classic_right', 'compact_left', 'grid_2', 'grid_3' ), true ) ) {
            $layout = 'classic_left';
        }

        return array(
            'product_block_enabled'      => isset( $_POST['product_block_enabled'] ) ? 1 : 0,
            'product_block_source'       => isset( $_POST['product_block_source'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['product_block_source'] ) ) : '',
            'product_block_limit'        => isset( $_POST['product_block_limit'] ) ? absint( wp_unslash( $_POST['product_block_limit'] ) ) : 3,
            'product_block_specific_ids' => isset( $_POST['product_block_specific_ids'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['product_block_specific_ids'] ) ) : '',
            'product_block_layout'       => $layout,
            'product_block_exclude_oos'  => isset( $_POST['product_block_exclude_oos'] ) ? 1 : 0,
            'product_block_categories'   => self::pmcpc_read_absint_csv_from_post( 'product_block_categories' ),
            'auto_footer_links_enabled'  => isset( $_POST['auto_footer_links_enabled'] ) ? 1 : 0,
        );
    }

    /**
     * Build the DB payload for a campaign save.
     *
     * @param array  $campaign_data Base campaign data.
     * @param string $now           Current timestamp.
     * @param bool   $include_created_at Whether to include created_at.
     * @return array
     */
    protected static function pmcpc_build_campaign_db_payload( $campaign_data, $now, $include_created_at = false ) {
        $payload = array(
            'name'                       => $campaign_data['name'],
            'campaign_type'              => $campaign_data['campaign_type'],
            'automation_trigger'         => $campaign_data['automation_trigger'],
            'pro_segment_key'            => $campaign_data['pro_segment_key'],
            'subject'                    => $campaign_data['subject'],
            'from_name'                  => $campaign_data['from_name'],
            'from_email'                 => $campaign_data['from_email'],
            'content'                    => $campaign_data['content'],
            'status'                     => $campaign_data['status'],
            'is_welcome'                 => $campaign_data['is_welcome'],
            'is_post_purchase'           => $campaign_data['is_post_purchase'],
            'target_tag'                 => $campaign_data['target_tag'],
            'exclude_tags'               => $campaign_data['exclude_tags'],
            'target_source_tags'         => $campaign_data['target_source_tags'],
            'target_origin_tags'         => $campaign_data['target_origin_tags'],
            'target_lifecycle_tags'      => $campaign_data['target_lifecycle_tags'],
            'trigger_delay_minutes'      => $campaign_data['trigger_delay_minutes'],
            'schedule_type'              => $campaign_data['schedule_type'],
            'schedule_datetime'          => $campaign_data['schedule_datetime'],
            'schedule_frequency'         => $campaign_data['schedule_frequency'],
            'next_run_at'                => $campaign_data['next_run_at'],
            'product_block_enabled'      => $campaign_data['product_block_enabled'],
            'product_block_source'       => $campaign_data['product_block_source'],
            'product_block_limit'        => $campaign_data['product_block_limit'],
            'product_block_specific_ids' => $campaign_data['product_block_specific_ids'],
            'product_block_categories'   => $campaign_data['product_block_categories'],
            'product_block_layout'       => $campaign_data['product_block_layout'],
            'product_block_exclude_oos'  => $campaign_data['product_block_exclude_oos'],
            'auto_footer_links_enabled'  => $campaign_data['auto_footer_links_enabled'],
            'updated_at'                 => $now,
        );

        if ( $include_created_at ) {
            $payload['created_at'] = $now;
        }

        return $payload;
    }

    /**
     * DB formats for campaign save payloads.
     *
     * @param bool $include_created_at Whether to include created_at.
     * @return array
     */
    protected static function pmcpc_get_campaign_db_formats( $include_created_at = false ) {
        $formats = array(
            '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s',
            '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d',
            '%s', '%s', '%s', '%s',
            '%d', '%s', '%d', '%s', '%s', '%s', '%d', '%d',
            '%s',
        );

        if ( $include_created_at ) {
            $formats[] = '%s';
        }

        return $formats;
    }

    /**
     * Load the existing campaign row for save operations.
     *
     * @param string $table       Campaign table name.
     * @param int    $campaign_id Campaign ID.
     * @return object|null
     */
    protected static function pmcpc_get_existing_campaign_for_save( $table, $campaign_id ) {
        global $wpdb;

        if ( ! $campaign_id ) {
            return null;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $table, $campaign_id )
        );
    }

    /**
     * Resolve the requested automation trigger while preserving wizard-stage compatibility.
     *
     * @param int $campaign_id Campaign ID.
     * @return string
     */
    protected static function pmcpc_resolve_campaign_trigger_from_post( $campaign_id ) {
        global $wpdb;

        if ( isset( $_POST['automation_trigger'] ) ) {
            return sanitize_text_field( (string) wp_unslash( $_POST['automation_trigger'] ) );
        }

        $automation_trigger = 'none';
        if ( ! empty( $campaign_id ) ) {
            $existing_trigger = $wpdb->get_var( $wpdb->prepare( "SELECT automation_trigger FROM {$wpdb->prefix}pmcpc_campaigns WHERE id = %d", absint( $campaign_id ) ) );
            if ( ! empty( $existing_trigger ) ) {
                $automation_trigger = sanitize_text_field( (string) $existing_trigger );
            }
        }

        return $automation_trigger;
    }

    /**
     * Apply trigger and schedule guardrails without changing legacy behavior.
     *
     * @param string $automation_trigger Requested trigger.
     * @param int    $campaign_id        Campaign ID.
     * @param string $schedule_type      Requested schedule type.
     * @param string $schedule_date      Requested schedule date.
     * @param string $schedule_time      Requested schedule time.
     * @param string $schedule_frequency Requested schedule frequency.
     * @return array
     */
    protected static function pmcpc_normalize_campaign_trigger_state( $automation_trigger, $campaign_id, $schedule_type, $schedule_date, $schedule_time, $schedule_frequency ) {
        global $wpdb;

        $allowed_triggers = self::pmcpc_get_allowed_automation_triggers();
        $is_welcome       = ( 'welcome' === $automation_trigger ) ? 1 : 0;
        $is_post_purchase = ( 'post_purchase' === $automation_trigger ) ? 1 : 0;

        if ( ! in_array( $automation_trigger, $allowed_triggers, true ) ) {
            $automation_trigger = 'none';
            $is_welcome         = 0;
            $is_post_purchase   = 0;
        }

        if ( function_exists( 'pmcpc_is_premium_wc_trigger' )
            && pmcpc_is_premium_wc_trigger( $automation_trigger )
            && ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() )
        ) {
            if ( $campaign_id > 0 ) {
                $existing_trigger = $wpdb->get_var( $wpdb->prepare( "SELECT automation_trigger FROM {$wpdb->prefix}pmcpc_campaigns WHERE id = %d", absint( $campaign_id ) ) );
                $existing_trigger = sanitize_key( (string) $existing_trigger );
                if ( $existing_trigger && function_exists( 'pmcpc_is_premium_wc_trigger' ) && pmcpc_is_premium_wc_trigger( $existing_trigger ) ) {
                    $automation_trigger = $existing_trigger;
                } else {
                    $automation_trigger = 'none';
                }
            } else {
                $automation_trigger = 'none';
            }

            $is_welcome       = ( 'welcome' === $automation_trigger ) ? 1 : 0;
            $is_post_purchase = ( 'post_purchase' === $automation_trigger ) ? 1 : 0;
        }

        if ( 'none' !== $automation_trigger ) {
            $schedule_type      = 'manual';
            $schedule_frequency = '';
            $schedule_date      = '';
            $schedule_time      = '';
        } elseif ( 'manual' !== $schedule_type ) {
            $automation_trigger = 'none';
            $is_welcome         = 0;
            $is_post_purchase   = 0;
        }

        return array(
            'automation_trigger' => $automation_trigger,
            'is_welcome'         => $is_welcome,
            'is_post_purchase'   => $is_post_purchase,
            'schedule_type'      => $schedule_type,
            'schedule_date'      => $schedule_date,
            'schedule_time'      => $schedule_time,
            'schedule_frequency' => $schedule_frequency,
        );
    }

    /**
     * Insert or update a campaign row.
     *
     * @param string $table            Campaign table name.
     * @param int    $campaign_id      Campaign ID.
     * @param array  $campaign_payload Prepared campaign payload.
     * @return int
     */
    protected static function pmcpc_persist_campaign_payload( $table, $campaign_id, $campaign_payload ) {
        global $wpdb;

        if ( $campaign_id ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update(
                $table,
                $campaign_payload,
                array( 'id' => $campaign_id ),
                self::pmcpc_get_campaign_db_formats( false ),
                array( '%d' )
            );

            return (int) $campaign_id;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->insert(
            $table,
            $campaign_payload,
            self::pmcpc_get_campaign_db_formats( true )
        );

        return (int) $wpdb->insert_id;
    }

}
