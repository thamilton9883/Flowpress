<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait PMCPC_Campaign_Manager_Render_List_Methods {
    protected function render_campaign_list_view_from_context( array $context ) {
        if ( isset( $context['this'] ) ) {
            unset( $context['this'] );
        }

        extract( $context, EXTR_SKIP );

        require PMCPC_PLUGIN_DIR . 'includes/campaign/partials/pmcpc-campaign-list-view.php';
    }
}
