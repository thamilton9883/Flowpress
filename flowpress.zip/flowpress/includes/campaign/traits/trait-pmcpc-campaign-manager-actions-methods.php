<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Campaign actions and list handlers.
 */
trait PMCPC_Campaign_Manager_Actions_Methods {






    /**
     * Delete a single campaign and its queued emails.
     *
     * @param int $campaign_id Campaign ID.
     */
    protected function delete_campaign( $campaign_id, $add_notice = true ) {
        $campaign_id = absint( $campaign_id );
        if ( ! $campaign_id ) {
            return false;
        }

        global $wpdb;
        $campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
        $queue_table     = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );

        // Delete queued emails for this campaign.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->delete( $queue_table, array( 'campaign_id' => $campaign_id ), array( '%d' ) );

        // Delete the campaign itself.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->delete( $campaigns_table, array( 'id' => $campaign_id ), array( '%d' ) );

        delete_option( 'pmcpc_campaign_subscriber_page_settings_' . $campaign_id );

        $subscriber_page_settings = get_option( 'pmcpc_campaign_subscriber_page_settings', array() );
        if ( is_array( $subscriber_page_settings ) && isset( $subscriber_page_settings[ $campaign_id ] ) ) {
            unset( $subscriber_page_settings[ $campaign_id ] );
            update_option( 'pmcpc_campaign_subscriber_page_settings', $subscriber_page_settings, false );
        }

        if ( $add_notice ) {
            add_settings_error(
                'pmcpc_campaigns',
                'pmcpc_campaign_deleted',
                __( 'Campaign deleted.', 'product-mailer-campaigns' ),
                'updated'
            );
        }

        return true;
    }

    /**
     * Handle the admin-post action to queue a broadcast for a campaign.
     * This keeps "Queue Broadcast" separate from the edit/save form.
     */
    public static function handle_queue_broadcast_action() {
        $campaign_id = self::get_campaign_list_action_campaign_id( 'pmcpc_send_campaign_' );

        $self   = new self();
        $result = $self->queue_campaign_to_all( $campaign_id, false );

        self::redirect_back_to_campaigns(
            $result ? array( 'pmcpc_queue_result' => $result ) : array()
        );
    }


    /**
     * Handle the admin-post action to send a one-off test email for a campaign.
     *
     * Sends to the current admin users email, but only if that subscriber matches
     * the campaign's tags and any Pro segment / automation filters.
     */
    protected static function get_campaign_action_request_campaign_id( $nonce_action ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to perform this action.', 'product-mailer-campaigns' ) );
        }

        $campaign_id = isset( $_GET['campaign_id'] ) ? absint( $_GET['campaign_id'] ) : 0;
        if ( ! $campaign_id ) {
            wp_die( esc_html__( 'Missing campaign ID.', 'product-mailer-campaigns' ) );
        }

        $nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, $nonce_action . $campaign_id ) ) {
            wp_die( esc_html__( 'Invalid request.', 'product-mailer-campaigns' ) );
        }

        return $campaign_id;
    }

    /**
     * Ensure the current admin user also has an active subscriber record for testing.
     *
     * @param bool $add_notice Whether to add an admin notice before redirecting on failure.
     * @return array{email:string,subscriber:object}
     */
    protected static function get_current_admin_test_recipient( $add_notice = true ) {
        $current_user = wp_get_current_user();
        if ( ! $current_user || ! $current_user->user_email ) {
            if ( $add_notice ) {
                add_settings_error(
                    'pmcpc_campaigns',
                    'pmcpc_test_campaign_no_admin_email',
                    __( 'Unable to determine your email address to send the test to.', 'product-mailer-campaigns' ),
                    'error'
                );
            }

            self::redirect_back_to_campaigns( array( 'pmcpc_test_campaign_result' => 'no_admin_email' ) );
        }

        $email      = $current_user->user_email;
        $first_name = $current_user->user_firstname ? $current_user->user_firstname : $current_user->display_name;
        $last_name  = $current_user->user_lastname;

        PMCPC_Subscriber_Manager::upsert_subscriber( $email, $first_name, $last_name, 'active' );
        $subscriber = PMCPC_Subscriber_Manager::get_subscriber_by_email( $email );

        if ( ! $subscriber || empty( $subscriber->id ) ) {
            if ( $add_notice ) {
                add_settings_error(
                    'pmcpc_campaigns',
                    'pmcpc_test_campaign_no_subscriber',
                    __( 'Could not find or create a subscriber record for your admin email, so no test email was sent.', 'product-mailer-campaigns' ),
                    'error'
                );
            }

            self::redirect_back_to_campaigns( array( 'pmcpc_test_campaign_result' => 'no_subscriber' ) );
        }

        return array(
            'email'      => (string) $email,
            'subscriber' => $subscriber,
        );
    }

    /**
     * Load a campaign for a test action or redirect back with a notice.
     *
     * @param int  $campaign_id Campaign ID.
     * @param bool $add_notice  Whether to add an admin notice on failure.
     * @return object
     */
    protected static function get_campaign_for_test_action( $campaign_id, $add_notice = true ) {
        $campaign = class_exists( 'PMCPC_Campaign_Repository' ) ? PMCPC_Campaign_Repository::get_campaign( $campaign_id ) : null;

        if ( $campaign ) {
            return $campaign;
        }

        if ( $add_notice ) {
            add_settings_error(
                'pmcpc_campaigns',
                'pmcpc_test_campaign_not_found',
                __( 'Campaign not found.', 'product-mailer-campaigns' ),
                'error'
            );
        }

        self::redirect_back_to_campaigns( array( 'pmcpc_test_campaign_result' => 'not_found' ) );
    }

    /**
     * Get normalized audience tags used by the campaign test-send filter.
     *
     * @param object $campaign Campaign row.
     * @return array
     */
    protected static function get_campaign_test_audience_tags( $campaign ) {
        $all_tags = array();

        $all_tags = array_merge( $all_tags, self::get_campaign_csv_values( isset( $campaign->target_tag ) ? $campaign->target_tag : '' ) );
        $all_tags = array_merge( $all_tags, self::get_campaign_csv_values( isset( $campaign->target_source_tags ) ? $campaign->target_source_tags : '' ) );
        $all_tags = array_merge(
            $all_tags,
            self::normalize_campaign_origin_values(
                self::get_campaign_csv_values( isset( $campaign->target_origin_tags ) ? $campaign->target_origin_tags : '' )
            )
        );
        $all_tags = array_merge( $all_tags, self::get_campaign_csv_values( isset( $campaign->target_lifecycle_tags ) ? $campaign->target_lifecycle_tags : '' ) );

        return array_values( array_unique( array_filter( array_map( 'trim', $all_tags ) ) ) );
    }

    /**
     * Fetch candidate subscribers for a campaign test-send, limited to the admin email.
     *
     * @param string $email    Admin email address.
     * @param array  $all_tags Normalized audience tags.
     * @return array
     */
    protected static function get_test_campaign_candidates_for_email( $email, $all_tags ) {
        global $wpdb;

        $subscribers_table = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );
        $tags_table        = esc_sql( $wpdb->prefix . 'pmcpc_subscriber_tags' );

        if ( empty( $all_tags ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            return (array) $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM %i WHERE status = %s AND email = %s",
                    $subscribers_table,
                    'active',
                    $email
                )
            );
        }

        $placeholders = implode( ',', array_fill( 0, count( $all_tags ), '%s' ) );

        // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (array) $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DISTINCT s.*
                 FROM %i s
                 INNER JOIN %i t ON t.subscriber_id = s.id
                 WHERE s.status = %s
                 AND s.email = %s
                 AND t.tag IN ($placeholders)",
                array_merge( array( $subscribers_table, $tags_table, 'active', $email ), $all_tags )
            )
        );
    }

    public static function handle_test_campaign_action() {
        $campaign_id     = self::get_campaign_action_request_campaign_id( 'pmcpc_test_campaign_' );
        $recipient_data  = self::get_current_admin_test_recipient( true );
        $email           = $recipient_data['email'];
        $campaign        = self::get_campaign_for_test_action( $campaign_id, true );
        $all_tags        = self::get_campaign_test_audience_tags( $campaign );
        $candidates      = self::get_test_campaign_candidates_for_email( $email, $all_tags );

        if ( empty( $candidates ) ) {
            add_settings_error(
                'pmcpc_campaigns',
                'pmcpc_test_campaign_no_tags_match',
                __( 'Your admin email does not currently match this campaign\'s target tags, so no test email was sent. Try adding the relevant tags to your subscriber record.', 'product-mailer-campaigns' ),
                'error'
            );
            self::redirect_back_to_campaigns( array( 'pmcpc_test_campaign_result' => 'no_tags_match' ) );
        }

        // Let Pro (segments / automation triggers) filter the subscribers in the same way as real sends.
        $filtered = apply_filters( 'pmcpc_campaign_subscribers', $candidates, $campaign );

        if ( empty( $filtered ) ) {
            add_settings_error(
                'pmcpc_campaigns',
                'pmcpc_test_campaign_filtered_out',
                __( 'Your admin email does not currently fall into this campaign\'s segment or automation rules, so no test email was sent.', 'product-mailer-campaigns' ),
                'error'
            );
            self::redirect_back_to_campaigns( array( 'pmcpc_test_campaign_result' => 'filtered_out' ) );
        }

        // Use the first matching subscriber.
        $test_subscriber = reset( $filtered );

        // Queue just this one email, with zero delay.
        self::queue_campaign_for_subscriber( $campaign, $test_subscriber, 0 );

        // Try to send immediately via the normal queue processor.
        if ( class_exists( 'PMCPC_Queue_Processor' ) && method_exists( 'PMCPC_Queue_Processor', 'process_queue' ) ) {
            PMCPC_Queue_Processor::process_queue();
        }

        add_settings_error(
            'pmcpc_campaigns',
            'pmcpc_test_campaign_sent',
            sprintf(
                /* translators: %s: email address */
                __( 'Test email queued for %s. If your email settings are configured correctly, it should arrive shortly.', 'product-mailer-campaigns' ),
                $email
            ),
            'updated'
        );

        self::redirect_back_to_campaigns( array( 'pmcpc_test_campaign_result' => 'sent' ) );
    }

	/**
	 * Admin-post action: always send a test email to the current admin, regardless of audience filters.
	 *
	 * This avoids confusion where "Test (must match audience)" queues nothing if the admin does not
	 * qualify for the campaign's tags/segments.
	 */
	public static function handle_send_test_email_action() {
		$campaign_id    = self::get_campaign_action_request_campaign_id( 'pmcpc_send_test_email_' );
		$recipient_data = self::get_current_admin_test_recipient( false );
		$subscriber     = $recipient_data['subscriber'];
		$campaign       = self::get_campaign_for_test_action( $campaign_id, false );

		// Queue exactly one email for the admin subscriber, without applying audience filters.
		// Allow duplicates so an admin can re-test the same campaign multiple times.
		self::queue_campaign_for_subscriber( $campaign, $subscriber, 0, true );

		// Try to send immediately via the normal queue processor.
		if ( class_exists( 'PMCPC_Queue_Processor' ) && method_exists( 'PMCPC_Queue_Processor', 'process_queue' ) ) {
			PMCPC_Queue_Processor::process_queue();
		}

		self::redirect_back_to_campaigns( array( 'pmcpc_test_campaign_result' => 'sent_force' ) );
	}

    /**
     * Validate a campaign list action request and return its campaign id.
     *
     * @param string $nonce_action Nonce action prefix.
     * @return int
     */
    protected static function get_campaign_list_action_campaign_id( $nonce_action ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to perform this action.', 'product-mailer-campaigns' ) );
        }

        $campaign_id = isset( $_GET['campaign_id'] ) ? absint( $_GET['campaign_id'] ) : 0;
        if ( ! $campaign_id ) {
            wp_die( esc_html__( 'Missing campaign ID.', 'product-mailer-campaigns' ) );
        }

        $nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, $nonce_action . $campaign_id ) ) {
            wp_die( esc_html__( 'Invalid request.', 'product-mailer-campaigns' ) );
        }

        return $campaign_id;
    }

    /**
     * Determine whether a campaign should be treated as automation-driven.
     *
     * @param object $campaign Campaign row.
     * @return bool
     */
    protected static function is_automation_campaign_record( $campaign ) {
        $trigger = isset( $campaign->automation_trigger ) ? (string) $campaign->automation_trigger : '';

        return ( ( $trigger && 'none' !== $trigger ) || ! empty( $campaign->is_welcome ) || ! empty( $campaign->is_post_purchase ) );
    }

    /**
     * Helper: redirect back to the campaigns list after an admin-post action.
     */


    /**
     * Handle the admin-post action to delete a campaign.
     *
     * This is triggered from the "Delete" link in the campaigns list table,
     * which uses admin-post.php?action=pmcpc_delete_campaign&campaign_id=ID.
     */
    public static function handle_delete_campaign_action() {
        $campaign_id = self::get_campaign_list_action_campaign_id( 'pmcpc_delete_campaign_' );

        $self   = new self();
        $result = $self->delete_campaign( $campaign_id, false );

        self::redirect_back_to_campaigns(
            $result ? array( 'pmcpc_delete_result' => 'deleted' ) : array()
        );
    }

	/**
	 * Enable/disable campaigns from the list view.
	 *
	 * - Automations: status active|inactive (affects welcome/post-purchase triggers).
	 * - Scheduled: status scheduled|draft (draft disables future runs).
	 */
	public static function handle_toggle_campaign_action() {
		$campaign_id = self::get_campaign_list_action_campaign_id( 'pmcpc_toggle_campaign_' );
		$toggle      = isset( $_GET['toggle'] ) ? sanitize_key( (string) wp_unslash( $_GET['toggle'] ) ) : '';
		if ( 'enable' !== $toggle && 'disable' !== $toggle ) {
			wp_die( esc_html__( 'Invalid request.', 'product-mailer-campaigns' ) );
		}

		global $wpdb;
		$campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

		$campaign = class_exists( 'PMCPC_Campaign_Repository' ) ? PMCPC_Campaign_Repository::get_campaign( $campaign_id ) : null;
		if ( ! $campaign ) {
			self::redirect_back_to_campaigns();
		}

		$now          = current_time( 'mysql' );
		$schedule_ty  = isset( $campaign->schedule_type ) ? (string) $campaign->schedule_type : 'manual';
		$schedule_dt  = isset( $campaign->schedule_datetime ) ? (string) $campaign->schedule_datetime : '';
		$next_run_at  = isset( $campaign->next_run_at ) ? (string) $campaign->next_run_at : '';
		$trigger       = isset( $campaign->automation_trigger ) ? (string) $campaign->automation_trigger : '';
		$is_automation = self::is_automation_campaign_record( $campaign );

		$result = '';

		if ( $is_automation ) {
			if ( 'enable' === $toggle ) {
				// Require a trigger to enable. If this is a legacy automation campaign,
				// derive and backfill the trigger automatically.
				if ( empty( $trigger ) || 'none' === $trigger ) {
					$derived = '';
					if ( ! empty( $campaign->is_welcome ) ) {
						$derived = 'new_subscriber';
					} elseif ( ! empty( $campaign->is_post_purchase ) ) {
						$derived = 'post_purchase';
					}
					if ( $derived ) {
						$trigger = $derived;
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
						$wpdb->update(
							$campaigns_table,
							array( 'automation_trigger' => $trigger, 'updated_at' => $now ),
							array( 'id' => $campaign_id ),
							array( '%s', '%s' ),
							array( '%d' )
						);
					} else {
						$result = 'cannot_enable';
					}
				}

				if ( 'cannot_enable' !== $result ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->update(
						$campaigns_table,
						array( 'status' => 'active', 'updated_at' => $now ),
						array( 'id' => $campaign_id ),
						array( '%s', '%s' ),
						array( '%d' )
					);
					$result = 'enabled';
				}
			} else {
				// disable
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->update(
					$campaigns_table,
					array( 'status' => 'inactive', 'updated_at' => $now ),
					array( 'id' => $campaign_id ),
					array( '%s', '%s' ),
					array( '%d' )
				);
				$result = 'disabled';
			}
		} else {
			// Scheduled/manual campaigns.
			if ( 'enable' === $toggle ) {
				// Only enable if it has a future schedule.
				$now_ts       = current_time( 'timestamp' );
				$schedule_ts  = $schedule_dt ? strtotime( $schedule_dt ) : 0;
				$has_future   = ( 'manual' !== $schedule_ty && $schedule_ts && $schedule_ts > $now_ts );
				if ( ! $has_future ) {
					$result = 'cannot_enable';
				} else {
					$nr = $next_run_at;
					if ( empty( $nr ) ) {
						$nr = $schedule_dt;
					}
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->update(
						$campaigns_table,
						array( 'status' => 'scheduled', 'next_run_at' => $nr, 'updated_at' => $now ),
						array( 'id' => $campaign_id ),
						array( '%s', '%s', '%s' ),
						array( '%d' )
					);
					$result = 'enabled';
				}
			} else {
				// disable: prevent future runs.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->update(
					$campaigns_table,
					array( 'status' => 'draft', 'next_run_at' => null, 'updated_at' => $now ),
					array( 'id' => $campaign_id ),
					array( '%s', '%s', '%s' ),
					array( '%d' )
				);
				$result = 'disabled';
			}
		}

		self::redirect_back_to_campaigns( $result ? array( 'pmcpc_toggle_result' => $result ) : array() );
	}

	/**
	 * Lightweight campaign readiness check (used for UI indicators).
	 *
	 * We only treat scheduled/automation campaigns as needing a "ready" indicator.
	 * Manual/draft campaigns can be intentionally incomplete.
	 *
	 * @param object $campaign
	 * @param array  $reasons Filled with human-readable issues when not ready.
	 * @return bool
	 */
	/**
	 * Readiness state for the list view.
	 *
	 * - "ready": safe to run
	 * - "warn":  configuration is valid, but likely to do nothing (e.g. 0 audience)
	 * - "not_ready": missing required configuration
	 */
	protected static function get_campaign_readiness_state( $campaign, &$reasons = array(), &$warnings = array() ) {
		$reasons  = array();
		$warnings = array();
		if ( ! is_object( $campaign ) ) {
			$reasons[] = __( 'Invalid campaign', 'product-mailer-campaigns' );
			return 'not_ready';
		}

		$subject = isset( $campaign->subject ) ? trim( (string) $campaign->subject ) : '';
		$content = isset( $campaign->content ) ? trim( (string) $campaign->content ) : '';
		$from_e  = isset( $campaign->from_email ) ? trim( (string) $campaign->from_email ) : '';
		$from_n  = isset( $campaign->from_name ) ? trim( (string) $campaign->from_name ) : '';

		if ( '' === $subject ) {
			$reasons[] = __( 'Missing subject', 'product-mailer-campaigns' );
		}
		if ( '' === $content ) {
			$reasons[] = __( 'Missing email content', 'product-mailer-campaigns' );
		}
		if ( '' === $from_n ) {
			$reasons[] = __( 'Missing From name', 'product-mailer-campaigns' );
		}
		if ( '' === $from_e || ! is_email( $from_e ) ) {
			$reasons[] = __( 'Invalid From email', 'product-mailer-campaigns' );
		}

		// Timing: schedule must have a next run, automation must be enabled.
		$schedule_type = isset( $campaign->schedule_type ) ? (string) $campaign->schedule_type : 'manual';
		$next_run_at   = isset( $campaign->next_run_at ) ? (string) $campaign->next_run_at : '';
		$schedule_dt   = isset( $campaign->schedule_datetime ) ? (string) $campaign->schedule_datetime : '';
		$trigger       = isset( $campaign->automation_trigger ) ? (string) $campaign->automation_trigger : '';
		$is_automation = ( ( $trigger && 'none' !== $trigger ) || ! empty( $campaign->is_welcome ) || ! empty( $campaign->is_post_purchase ) );

		if ( $is_automation ) {
			if ( 'active' !== (string) $campaign->status ) {
				$reasons[] = __( 'Automation is disabled', 'product-mailer-campaigns' );
			}
			if ( empty( $trigger ) ) {
				$reasons[] = __( 'Missing automation trigger', 'product-mailer-campaigns' );
			}
		} elseif ( 'manual' !== $schedule_type ) {
			// For scheduled campaigns, either next_run_at or schedule_datetime is acceptable.
			if ( '' === $next_run_at && '' === $schedule_dt ) {
				$reasons[] = __( 'Missing next run time', 'product-mailer-campaigns' );
			}
			if ( 'scheduled' !== (string) $campaign->status ) {
				$reasons[] = __( 'Schedule is disabled', 'product-mailer-campaigns' );
			}
		}

		if ( ! empty( $reasons ) ) {
			return 'not_ready';
		}

		// Audience warning: if there are no active subscribers (or no matches for target tags), flag as "warn".
		$audience_count = self::estimate_campaign_audience_count( $campaign );
		if ( 0 === $audience_count ) {
			$warnings[] = __( 'Audience currently 0', 'product-mailer-campaigns' );
			return 'warn';
		}

		return 'ready';
	}

	/**
	 * Backwards compatible boolean readiness check.
	 */
	protected static function is_campaign_ready( $campaign, &$reasons = array() ) {
		$warnings = array();
		$state    = self::get_campaign_readiness_state( $campaign, $reasons, $warnings );
		return 'ready' === $state || 'warn' === $state;
	}

	/**
	 * Cheap audience estimate (count) for list readiness.
	 *
	 * For automation campaigns, this is a best-effort approximation based on current subscriber list.
	 */
	protected static function estimate_campaign_audience_count( $campaign ) {
		global $wpdb;
		$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
		$tags_table        = $wpdb->prefix . 'pmcpc_subscriber_tags';

		$target_tag            = isset( $campaign->target_tag ) ? trim( (string) $campaign->target_tag ) : '';
		$target_source_tags    = isset( $campaign->target_source_tags ) ? trim( (string) $campaign->target_source_tags ) : '';
		$target_origin_tags    = isset( $campaign->target_origin_tags ) ? trim( (string) $campaign->target_origin_tags ) : '';
		$target_lifecycle_tags = isset( $campaign->target_lifecycle_tags ) ? trim( (string) $campaign->target_lifecycle_tags ) : '';

		$all_tags = array();
		foreach ( array( $target_tag, $target_source_tags, $target_origin_tags, $target_lifecycle_tags ) as $raw ) {
			if ( '' === $raw ) {
				continue;
			}
			$parts    = array_filter( array_map( 'trim', explode( ',', $raw ) ) );
			$all_tags = array_merge( $all_tags, $parts );
		}
		$all_tags = array_values( array_unique( $all_tags ) );

		if ( empty( $all_tags ) ) {
			// All active subscribers.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$count = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s', $subscribers_table, 'active' ) );
			return max( 0, $count );
		}

		$placeholders = implode( ',', array_fill( 0, count( $all_tags ), '%s' ) );
		// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT s.id)
				 FROM %i s
				 INNER JOIN %i t ON t.subscriber_id = s.id
				 WHERE s.status = %s
				 AND t.tag IN ($placeholders)",
				array_merge( array( $subscribers_table, $tags_table, 'active' ), $all_tags )
			)
		);

		return max( 0, $count );
	}

protected static function redirect_back_to_campaigns( $extra_args = array() ) {
    $base_args = array(
        'page' => 'pmcpc_campaigns',
    );

    if ( is_array( $extra_args ) ) {
        $base_args = array_merge( $base_args, $extra_args );
    }

    $redirect = add_query_arg(
        $base_args,
        admin_url( 'admin.php' )
    );
    wp_safe_redirect( $redirect );
    exit;
}

	/**
	 * Duplicate a campaign as a new draft (safe alternative to "Enable" on completed one-time sends).
	 */
	public static function handle_duplicate_campaign_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'product-mailer-campaigns' ) );
		}

		$campaign_id = isset( $_GET['campaign_id'] ) ? absint( $_GET['campaign_id'] ) : 0;
		if ( ! $campaign_id ) {
			wp_safe_redirect( admin_url( 'admin.php?page=pmcpc-campaigns' ) );
			exit;
		}

		check_admin_referer( 'pmcpc_duplicate_campaign_' . $campaign_id );

		global $wpdb;
		$table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

		$campaign = $wpdb->get_row(
			// Table name is plugin-owned (no user input).
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $campaign_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
			ARRAY_A
		);

		if ( empty( $campaign ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=pmcpc-campaigns' ) );
			exit;
		}

		// Build the duplicated row.
		unset( $campaign['id'] );

		// Name tweak.
		$name = isset( $campaign['name'] ) ? (string) $campaign['name'] : '';
		if ( $name ) {
			// Avoid stacking "(Copy)" endlessly.
			if ( ! preg_match( '/\s\((Copy)\)\s*$/i', $name ) ) {
				$name .= ' (Copy)';
			}
		} else {
			$name = __( 'Campaign (Copy)', 'product-mailer-campaigns' );
		}
		$campaign['name'] = $name;

		// Reset send/schedule state.
		$campaign['status']            = 'draft';
		$campaign['schedule_datetime'] = null;
		$campaign['next_run_at']        = null;

		$now = current_time( 'mysql' );
		$campaign['created_at'] = $now;
		$campaign['updated_at'] = $now;

		// Insert duplicate.
		$wpdb->insert( $table, $campaign );

		$new_id = (int) $wpdb->insert_id;
		$redirect = admin_url( 'admin.php?page=pmcpc-campaigns&action=edit&campaign_id=' . $new_id . '&duplicated=1' );
		wp_safe_redirect( $redirect );
		exit;
	}

}
