<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Campaign save and queue preparation methods.
 */
trait PMCPC_Campaign_Manager_Save_Methods {


    protected function save_campaign() {
        $this->pmcpc_ensure_schema_flags();

        global $wpdb;
        $table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

        $campaign_id = isset( $_POST['campaign_id'] ) ? absint( $_POST['campaign_id'] ) : 0;

        $name       = isset( $_POST['name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['name'] ) ) : '';
        $subject    = isset( $_POST['subject'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['subject'] ) ) : '';
        $from_name  = isset( $_POST['from_name'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['from_name'] ) ) : PMCPC_Settings::get( 'from_name_default', get_bloginfo( 'name' ) );
        $from_email = isset( $_POST['from_email'] ) ? sanitize_email( wp_unslash( $_POST['from_email'] ) ) : PMCPC_Settings::get( 'from_email_default', get_option( 'admin_email' ) );
        // Normalize to string to avoid PHP 8.1+ deprecation notices when WP string helpers receive null.
        $content    = isset( $_POST['content'] ) ? wp_kses_post( (string) wp_unslash( $_POST['content'] ) ) : '';

        // Campaign type is deprecated (kept only for backwards compatibility in the DB).
        // We no longer accept a user-selected type from the UI.
        $campaign_type = 'manual';

        // Unified automation trigger and delay.
        $automation_trigger = self::pmcpc_resolve_campaign_trigger_from_post( $campaign_id );

		$trigger_delay = isset( $_POST['trigger_delay_minutes'] )
			? absint( wp_unslash( $_POST['trigger_delay_minutes'] ) )
            : 0;

        $target_tag   = self::pmcpc_read_unique_csv_from_post( 'pmcpc_audience_tags', 'target_tag' );
        $exclude_tags = self::pmcpc_read_unique_csv_from_post( '', 'exclude_tags' );

        // Pro recipient segment key, if available.
        $pro_segment_key = '';
        if ( function_exists( 'pmcpc_wc_automation_enabled' ) && pmcpc_wc_automation_enabled() ) {
            $allowed_segments = array( '', 'customers', 'new_customers', 'repeat_customers', 'recent', 'high_value', 'vip', 'lapsed' );
            $pro_segment_key  = isset( $_POST['pro_segment_key'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pro_segment_key'] ) ) : '';
            if ( ! in_array( $pro_segment_key, $allowed_segments, true ) ) {
                $pro_segment_key = '';
            }
        }
        $target_source_tags    = self::pmcpc_read_unique_csv_from_post( 'target_source_tags_arr', 'target_source_tags' );
        $target_origin_tags    = self::pmcpc_read_unique_csv_from_post( 'target_origin_tags_arr', 'target_origin_tags' );
        $target_lifecycle_tags = self::pmcpc_read_unique_csv_from_post( 'target_lifecycle_tags_arr', 'target_lifecycle_tags' );

        $welcome_delay    = $trigger_delay;
        $post_delay       = $trigger_delay;
        $broadcast_delay  = $trigger_delay;

        // Scheduling fields.
        $schedule_type      = isset( $_POST['schedule_type'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['schedule_type'] ) ) : 'manual';
        $schedule_date      = isset( $_POST['schedule_date'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['schedule_date'] ) ) : '';
        $schedule_time      = isset( $_POST['schedule_time'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['schedule_time'] ) ) : '';
        $schedule_frequency = isset( $_POST['schedule_frequency'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['schedule_frequency'] ) ) : '';


        // Enforce consistent timing rules:
        // - Automated triggers must NOT have a schedule.
        // - Scheduled/recurring campaigns can only use the manual/scheduled trigger option.
        //
        // IMPORTANT: When switching a campaign from scheduled -> automated in the UI, the hidden
        // schedule fields may still submit stale values. We therefore enforce this server-side.
        $trigger_state = self::pmcpc_normalize_campaign_trigger_state(
            $automation_trigger,
            $campaign_id,
            $schedule_type,
            $schedule_date,
            $schedule_time,
            $schedule_frequency
        );
        $automation_trigger = $trigger_state['automation_trigger'];
        $is_welcome         = $trigger_state['is_welcome'];
		$is_post_purchase   = $trigger_state['is_post_purchase'];
        $schedule_type      = $trigger_state['schedule_type'];
        $schedule_date      = $trigger_state['schedule_date'];
        $schedule_time      = $trigger_state['schedule_time'];
        $schedule_frequency = $trigger_state['schedule_frequency'];
        $product_block_settings   = self::pmcpc_get_product_block_settings_from_post();
        $subscriber_page_settings = self::pmcpc_get_subscriber_page_settings_from_post( $campaign_id );



        if ( empty( $name ) || empty( $subject ) ) {
            add_settings_error( 'pmcpc_campaigns', 'pmcpc_campaign_required', __( 'Name and subject are required.', 'product-mailer-campaigns' ), 'error' );
            return;
        }

        $now      = current_time( 'mysql' );
        $existing = null;

        // Determine base status (draft by default).
        $status = 'draft';
        if ( $campaign_id ) {
			$existing = self::pmcpc_get_existing_campaign_for_save( $table, $campaign_id );
            if ( $existing ) {
                $status = $existing->status;
				// Preserve legacy campaign_type silently for existing rows.
				if ( ! empty( $existing->campaign_type ) ) {
					$campaign_type = (string) $existing->campaign_type;
				}
            }
        }

        $schedule_state      = self::pmcpc_normalize_schedule_for_save( $schedule_type, $schedule_date, $schedule_time, $schedule_frequency, $status, $existing );
        $schedule_type       = $schedule_state['schedule_type'];
        $schedule_frequency  = $schedule_state['schedule_frequency'];
        $schedule_datetime   = $schedule_state['schedule_datetime'];
        $status              = $schedule_state['status'];
        $next_run_at         = $schedule_state['next_run_at'];

        $campaign_payload = self::pmcpc_build_campaign_db_payload(
            array(
                'name'                       => $name,
                'campaign_type'              => $campaign_type,
                'automation_trigger'         => $automation_trigger,
                'pro_segment_key'            => $pro_segment_key,
                'subject'                    => $subject,
                'from_name'                  => $from_name,
                'from_email'                 => $from_email,
                'content'                    => $content,
                'status'                     => $status,
                'is_welcome'                 => $is_welcome,
                'is_post_purchase'           => $is_post_purchase,
                'target_tag'                 => $target_tag,
                'exclude_tags'               => $exclude_tags,
                'target_source_tags'         => $target_source_tags,
                'target_origin_tags'         => $target_origin_tags,
                'target_lifecycle_tags'      => $target_lifecycle_tags,
                'trigger_delay_minutes'      => $trigger_delay,
                'schedule_type'              => $schedule_type,
                'schedule_datetime'          => $schedule_datetime,
                'schedule_frequency'         => $schedule_frequency,
                'next_run_at'                => $next_run_at,
                'product_block_enabled'      => $product_block_settings['product_block_enabled'],
                'product_block_source'       => $product_block_settings['product_block_source'],
                'product_block_limit'        => $product_block_settings['product_block_limit'],
                'product_block_specific_ids' => $product_block_settings['product_block_specific_ids'],
                'product_block_categories'   => $product_block_settings['product_block_categories'],
                'product_block_layout'       => $product_block_settings['product_block_layout'],
                'product_block_exclude_oos'  => $product_block_settings['product_block_exclude_oos'],
                'auto_footer_links_enabled'  => $product_block_settings['auto_footer_links_enabled'],
            ),
            $now,
            ! $campaign_id
        );

	        // Save campaign.
            $campaign_id = self::pmcpc_persist_campaign_payload( $table, $campaign_id, $campaign_payload );

        if ( $campaign_id ) {
            update_option( 'pmcpc_campaign_subscriber_page_settings_' . $campaign_id, $subscriber_page_settings, false );

            $all_subscriber_page_settings = get_option( 'pmcpc_campaign_subscriber_page_settings', array() );
            if ( ! is_array( $all_subscriber_page_settings ) ) {
                $all_subscriber_page_settings = array();
            }
            $all_subscriber_page_settings[ $campaign_id ] = $subscriber_page_settings;
            update_option( 'pmcpc_campaign_subscriber_page_settings', $all_subscriber_page_settings, false );
        }

        add_settings_error( 'pmcpc_campaigns', 'pmcpc_campaign_saved', __( 'Campaign saved.', 'product-mailer-campaigns' ), 'updated' );
    }

    /**
     * Apply exclude-tags segmentation for a campaign.
     *
     * @param array  $subscribers List of subscriber row objects.
     * @param object $campaign    Campaign row with ->exclude_tags (comma-separated).
     * @return array Filtered subscribers.
     */
    protected static function filter_subscribers_by_exclude_tags( $subscribers, $campaign ) {
        if ( empty( $subscribers ) || ! is_array( $subscribers ) ) {
            return $subscribers;
        }

        if ( ! isset( $campaign->exclude_tags ) || '' === $campaign->exclude_tags ) {
            return $subscribers;
        }

        $raw = array_map( 'trim', explode( ',', $campaign->exclude_tags ) );
        $raw = array_filter( $raw );
        if ( empty( $raw ) ) {
            return $subscribers;
        }

        $exclude_lookup = array();
        foreach ( $raw as $tag ) {
            $exclude_lookup[ $tag ] = true;
        }

        foreach ( $subscribers as $index => $subscriber ) {
            if ( empty( $subscriber->id ) ) {
                continue;
            }

            $tags = PMCPC_Subscriber_Manager::get_tags_for_subscriber( (int) $subscriber->id );
            if ( empty( $tags ) || ! is_array( $tags ) ) {
                continue;
            }

            foreach ( $tags as $tag ) {
                if ( isset( $exclude_lookup[ $tag ] ) ) {
                    unset( $subscribers[ $index ] );
                    break;
                }
            }
        }

        return array_values( $subscribers );
    }

    /**
     * Apply Pro-style WooCommerce segments to a subscriber list.
     *
     * Supported segments:
     * - customers         : at least one completed/processing order.
     * - new_customers     : exactly one completed/processing order.
     * - repeat_customers  : two or more completed/processing orders.
     * - recent            : at least one completed/processing order within the recent window.
     * - high_value        : total spend at or above a configurable threshold.
     * - vip               : like high_value, but with a higher threshold or VIP tag.
     * - lapsed            : at least one past order, but none within the lapsed window.
     *
     * If WooCommerce is not active or the segment key is empty/unknown, the list is returned unchanged.
     *
     * @param array  $subscribers List of subscriber row objects.
     * @param object $campaign    Campaign row with ->pro_segment_key.
     * @return array Filtered subscribers.
     */
    protected static function filter_subscribers_by_pro_segment( $subscribers, $campaign ) {
        if ( empty( $subscribers ) || ! is_array( $subscribers ) ) {
            return $subscribers;
        }

        if ( ! isset( $campaign->pro_segment_key ) || '' === $campaign->pro_segment_key ) {
            return $subscribers;
        }

        $segment = $campaign->pro_segment_key;

        $allowed_segments = array( 'customers', 'new_customers', 'repeat_customers', 'recent', 'high_value', 'vip', 'lapsed' );
        if ( ! in_array( $segment, $allowed_segments, true ) ) {
            return $subscribers;
        }

        if ( ! class_exists( 'WooCommerce' ) ) {
            // Cannot satisfy WooCommerce-based segments if WooCommerce is not active.
            return array();
        }

        foreach ( $subscribers as $index => $subscriber ) {
            if ( ! self::is_subscriber_in_pro_segment( $subscriber, $segment, $campaign ) ) {
                unset( $subscribers[ $index ] );
            }
        }

        return array_values( $subscribers );
    }

    /**
     * Determine whether a single subscriber matches a given Pro segment.
     *
     * @param object $subscriber Subscriber row (pmcpc_subscribers).
     * @param string $segment    Segment key.
     * @param object $campaign   Campaign row (pmcpc_campaigns).
     * @return bool
     */
    protected static function is_subscriber_in_pro_segment( $subscriber, $segment, $campaign ) {
        if ( empty( $subscriber ) || ! is_object( $subscriber ) ) {
            return false;
        }

        if ( empty( $subscriber->email ) ) {
            return false;
        }

        if ( ! class_exists( 'WooCommerce' ) ) {
            return false;
        }

        $email = $subscriber->email;

        // Basic Woo helpers if available.
        $user        = function_exists( 'get_user_by' ) ? get_user_by( 'email', $email ) : false;
        $customer_id = $user ? $user->ID : 0;

        $order_statuses = array( 'wc-completed', 'wc-processing' );

        // Allow add-ons to short-circuit before we do any heavy work.
        $pre = apply_filters( 'pmcpc_pro_segment_pre_match', null, $subscriber, $segment, $campaign );
        if ( null !== $pre ) {
            return (bool) $pre;
        }

        // Helper closures for order lookups.
        $get_order_count = function() use ( $customer_id, $email, $order_statuses ) {
            if ( $customer_id && function_exists( 'wc_get_customer_order_count' ) ) {
                $count = (int) wc_get_customer_order_count( $customer_id );
                if ( $count > 0 ) {
                    return $count;
                }
            }

            if ( function_exists( 'wc_get_orders' ) ) {
                $orders = wc_get_orders(
                    array(
                        'limit'         => -1,
                        'status'        => $order_statuses,
                        'billing_email' => $email,
                        'return'        => 'ids',
                    )
                );
                return is_array( $orders ) ? count( $orders ) : 0;
            }

            return 0;
        };

        $get_spend_and_last_order = function() use ( $customer_id, $email, $order_statuses ) {
            $total_spent = 0.0;
            $last_ts     = 0;

            if ( $customer_id && function_exists( 'wc_get_customer_total_spent' ) ) {
                $total_spent = (float) wc_get_customer_total_spent( $customer_id );

                if ( function_exists( 'wc_get_orders' ) ) {
                    $orders = wc_get_orders(
                        array(
                            'limit'         => 1,
                            'status'        => $order_statuses,
                            'customer_id'   => $customer_id,
                            'orderby'       => 'date',
                            'order'         => 'DESC',
                        )
                    );
                    if ( ! empty( $orders ) ) {
                        $order = is_array( $orders ) ? reset( $orders ) : $orders;
                        if ( $order && is_object( $order ) && method_exists( $order, 'get_date_created' ) ) {
                            $date = $order->get_date_created();
                            if ( $date ) {
                                $last_ts = $date->getTimestamp();
                            }
                        }
                    }
                }
            }

            // Fallback: guest orders looked up by billing email.
            if ( ( ! $customer_id || $last_ts === 0 ) && function_exists( 'wc_get_orders' ) ) {
                $orders = wc_get_orders(
                    array(
                        'limit'         => -1,
                        'status'        => $order_statuses,
                        'billing_email' => $email,
                    )
                );
                if ( ! empty( $orders ) && is_array( $orders ) ) {
                    foreach ( $orders as $order ) {
                        if ( ! $order || ! is_object( $order ) ) {
                            continue;
                        }
                        if ( method_exists( $order, 'get_total' ) ) {
                            $total_spent += (float) $order->get_total();
                        }
                        if ( method_exists( $order, 'get_date_created' ) ) {
                            $date = $order->get_date_created();
                            if ( $date ) {
                                $ts = $date->getTimestamp();
                                if ( $ts > $last_ts ) {
                                    $last_ts = $ts;
                                }
                            }
                        }
                    }
                }
            }

            return array( $total_spent, $last_ts );
        };

        switch ( $segment ) {
            case 'customers':
                return $get_order_count() > 0;

            case 'new_customers':
                return $get_order_count() === 1;

            case 'repeat_customers':
                return $get_order_count() >= 2;

            case 'recent_7':
        $source_bits[] = __( 'Segment: Recent customers (last 7 days)', 'product-mailer-campaigns' );
        break;
        case 'at_risk_60':
        $source_bits[] = __( 'Segment: At-risk customers (60+ days)', 'product-mailer-campaigns' );
        break;
        case 'recent':
                $days   = (int) apply_filters( 'pmcpc_pro_segment_recent_days', 30, $subscriber, $campaign );
                $window = max( 1, $days );
                $cutoff = time() - ( $window * DAY_IN_SECONDS );

                if ( ! function_exists( 'wc_get_orders' ) ) {
                    return false;
                }

                $orders = wc_get_orders(
                    array(
                        'limit'         => 1,
                        'status'        => $order_statuses,
                        'billing_email' => $email,
                        'date_created'  => '>' . gmdate( 'Y-m-d H:i:s', $cutoff ),
                    )
                );

                return ! empty( $orders );

            case 'high_value':
            case 'vip':
            case 'lapsed':
                list( $total_spent, $last_ts ) = $get_spend_and_last_order();

                // No orders at all, cannot match these segments.
                if ( $total_spent <= 0 && $last_ts === 0 ) {
                    return false;
                }

                $now = time();

                if ( 'high_value' === $segment ) {
                    $threshold = (float) apply_filters( 'pmcpc_pro_segment_high_value_threshold', 200.0, $subscriber, $campaign );
                    return $total_spent >= $threshold;
                }

                if ( 'vip' === $segment ) {
                    $threshold = (float) apply_filters( 'pmcpc_pro_segment_vip_threshold', 500.0, $subscriber, $campaign );
                    $is_vip_spender = $total_spent >= $threshold;

                    // Also treat subscribers tagged with "vip" as VIPs.
                    $has_vip_tag = false;
                    if ( ! empty( $subscriber->id ) && method_exists( 'PMCPC_Subscriber_Manager', 'get_tags_for_subscriber' ) ) {
                        $tags = PMCPC_Subscriber_Manager::get_tags_for_subscriber( (int) $subscriber->id );
                        if ( is_array( $tags ) && in_array( 'vip', $tags, true ) ) {
                            $has_vip_tag = true;
                        }
                    }

                    return ( $is_vip_spender || $has_vip_tag );
                }

                if ( 'lapsed' === $segment ) {
                    $days    = (int) apply_filters( 'pmcpc_pro_segment_lapsed_days', 90, $subscriber, $campaign );
                    $window  = max( 1, $days );
                    $cutoff  = $now - ( $window * DAY_IN_SECONDS );

                    // Lapsed customers: at least one order, but last order is older than the cutoff.
                    return ( $last_ts > 0 && $last_ts < $cutoff );
                }

                break;
        }

        return false;
    }



    /**
     * Count how many subscribers would currently receive a given campaign,
     * based on status, tags, exclude tags, and Pro segment.
     *
     * This uses similar logic to queue_campaign_to_all(), but only returns a count
     * and does not enqueue any emails.
     *
     * @param object $campaign Campaign row (pmcpc_campaigns).
     * @return int Number of matching subscribers.
     */

    protected static function get_campaign_csv_values( $raw_value ) {
        if ( ! is_string( $raw_value ) || '' === trim( $raw_value ) ) {
            return array();
        }

        $values = array_filter( array_map( 'trim', explode( ',', $raw_value ) ) );
        return array_values( array_unique( $values ) );
    }

    protected static function normalize_campaign_origin_values( $values ) {
        $normalized = array();
        foreach ( (array) $values as $value ) {
            $value = trim( (string) $value );
            if ( '' === $value ) {
                continue;
            }
            if ( 0 === strpos( $value, 'origin:' ) || 0 === strpos( $value, 'form-' ) ) {
                $normalized[] = $value;
            } else {
                $normalized[] = 'origin:' . $value;
            }
        }

        return array_values( array_unique( $normalized ) );
    }

    protected static function get_active_subscribers_for_audience_engine() {
        global $wpdb;

        $subscribers_table = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $subscribers = $wpdb->get_results(
            $wpdb->prepare( 'SELECT * FROM %i WHERE status = %s', $subscribers_table, 'active' )
        );

        return is_array( $subscribers ) ? $subscribers : array();
    }

    protected static function subscriber_has_any_campaign_tag( $subscriber, $required_tags, &$tag_cache ) {
        if ( empty( $required_tags ) ) {
            return true;
        }

        if ( empty( $subscriber ) || ! is_object( $subscriber ) || empty( $subscriber->id ) ) {
            return false;
        }

        $subscriber_id = (int) $subscriber->id;
        if ( ! isset( $tag_cache[ $subscriber_id ] ) ) {
            $tag_cache[ $subscriber_id ] = method_exists( 'PMCPC_Subscriber_Manager', 'get_tags_for_subscriber' )
                ? PMCPC_Subscriber_Manager::get_tags_for_subscriber( $subscriber_id )
                : array();
        }

        $tags = is_array( $tag_cache[ $subscriber_id ] ) ? $tag_cache[ $subscriber_id ] : array();
        if ( empty( $tags ) ) {
            return false;
        }

        foreach ( $required_tags as $tag ) {
            if ( in_array( $tag, $tags, true ) ) {
                return true;
            }
        }

        return false;
    }

    protected static function apply_campaign_refine_filters_to_subscribers( $subscribers, $campaign ) {
        if ( empty( $subscribers ) || ! is_array( $subscribers ) || ! $campaign ) {
            return is_array( $subscribers ) ? array_values( $subscribers ) : array();
        }

        $interest_tags  = self::get_campaign_csv_values( isset( $campaign->target_tag ) ? (string) $campaign->target_tag : '' );
        $source_tags    = self::get_campaign_csv_values( isset( $campaign->target_source_tags ) ? (string) $campaign->target_source_tags : '' );
        $origin_tags    = self::normalize_campaign_origin_values( self::get_campaign_csv_values( isset( $campaign->target_origin_tags ) ? (string) $campaign->target_origin_tags : '' ) );
        $lifecycle_tags = self::get_campaign_csv_values( isset( $campaign->target_lifecycle_tags ) ? (string) $campaign->target_lifecycle_tags : '' );

        $tag_cache = array();
        $filtered  = array();

        foreach ( $subscribers as $subscriber ) {
            if ( ! self::subscriber_has_any_campaign_tag( $subscriber, $interest_tags, $tag_cache ) ) {
                continue;
            }
            if ( ! self::subscriber_has_any_campaign_tag( $subscriber, $source_tags, $tag_cache ) ) {
                continue;
            }
            if ( ! self::subscriber_has_any_campaign_tag( $subscriber, $origin_tags, $tag_cache ) ) {
                continue;
            }
            if ( ! self::subscriber_has_any_campaign_tag( $subscriber, $lifecycle_tags, $tag_cache ) ) {
                continue;
            }

            $filtered[] = $subscriber;
        }

        $filtered = self::filter_subscribers_by_exclude_tags( $filtered, $campaign );
        return array_values( $filtered );
    }

    protected static function apply_campaign_eligibility_filter_to_subscribers( $subscribers, $campaign ) {
        if ( empty( $subscribers ) || ! is_array( $subscribers ) ) {
            return array();
        }

        $subscribers = self::filter_subscribers_by_pro_segment( $subscribers, $campaign );
        $subscribers = apply_filters( 'pmcpc_campaign_subscribers', $subscribers, $campaign );

        return is_array( $subscribers ) ? array_values( $subscribers ) : array();
    }

    protected static function get_campaign_audience_result( $campaign, $seed_subscribers = null ) {
        $initial_subscribers = is_array( $seed_subscribers ) ? array_values( $seed_subscribers ) : self::get_active_subscribers_for_audience_engine();
        $refined_subscribers = self::apply_campaign_refine_filters_to_subscribers( $initial_subscribers, $campaign );
        $final_subscribers   = self::apply_campaign_eligibility_filter_to_subscribers( $refined_subscribers, $campaign );

        return array(
            'initial_count' => count( $initial_subscribers ),
            'refined_count' => count( $refined_subscribers ),
            'final_count'   => count( $final_subscribers ),
            'subscribers'   => $final_subscribers,
        );
    }

    protected static function get_preview_subscribers_for_campaign( $campaign ) {
        $result = self::get_campaign_audience_result( $campaign );
        return ! empty( $result['subscribers'] ) && is_array( $result['subscribers'] ) ? $result['subscribers'] : array();
    }

    /**
     * Count how many subscribers would currently receive a given campaign.
     *
     * @param object $campaign Campaign row (pmcpc_campaigns).
     * @return int Number of matching subscribers.
     */
    protected static function count_recipients_for_campaign( $campaign ) {
        if ( ! is_object( $campaign ) ) {
            return 0;
        }

        $result = self::get_campaign_audience_result( $campaign );
        return isset( $result['final_count'] ) ? (int) $result['final_count'] : 0;
    }

    /**
     * Return the effective automation trigger key for preview purposes.
     *
     * @param object $campaign Campaign object.
     * @return string
     */
    protected static function get_campaign_preview_trigger_key( $campaign ) {
        $trigger = isset( $campaign->automation_trigger ) ? sanitize_key( (string) $campaign->automation_trigger ) : '';
        if ( empty( $trigger ) || 'none' === $trigger ) {
            if ( ! empty( $campaign->is_welcome ) ) {
                return 'new_subscriber';
            }
            if ( ! empty( $campaign->is_post_purchase ) ) {
                return 'post_purchase';
            }
            return 'none';
        }
        if ( 'welcome' === $trigger ) {
            return 'new_subscriber';
        }
        return $trigger;
    }

    /**
     * Resolve a campaign admin notice from a query-string result.
     *
     * @param string $type   Notice type key.
     * @param string $result Notice result key.
     * @return array{class:string,message:string}
     */
    protected static function get_campaign_admin_notice_definition( $type, $result ) {
        $type   = sanitize_key( (string) $type );
        $result = sanitize_key( (string) $result );

        $definitions = array(
            'test_campaign' => array(
                'sent_force' => array(
                    'class'   => 'notice-success',
                    'message' => __( 'Test email queued for your admin email address (ignoring audience filters). If your email settings are configured correctly, it should arrive shortly.', 'product-mailer-campaigns' ),
                ),
                'sent' => array(
                    'class'   => 'notice-success',
                    'message' => __( 'Test email queued for your admin email address. If your email settings are configured correctly, it should arrive shortly.', 'product-mailer-campaigns' ),
                ),
                'no_admin_email' => array(
                    'class'   => 'notice-error',
                    'message' => __( 'Unable to determine your admin email address to send the test to.', 'product-mailer-campaigns' ),
                ),
                'no_subscriber' => array(
                    'class'   => 'notice-error',
                    'message' => __( 'Could not find or create a subscriber record for your admin email address, so no test email was sent.', 'product-mailer-campaigns' ),
                ),
                'not_found' => array(
                    'class'   => 'notice-error',
                    'message' => __( 'Campaign not found for test audience action.', 'product-mailer-campaigns' ),
                ),
                'no_tags_match' => array(
                    'class'   => 'notice-warning',
                    'message' => __( 'Your admin subscriber does not currently match this campaign\'s target tags, so no test email was sent.', 'product-mailer-campaigns' ),
                ),
                'filtered_out' => array(
                    'class'   => 'notice-warning',
                    'message' => __( 'Your admin subscriber was filtered out by segments or automation rules for this campaign, so no test email was sent.', 'product-mailer-campaigns' ),
                ),
            ),
            'toggle_campaign' => array(
                'enabled' => array(
                    'class'   => 'notice-success',
                    'message' => __( 'Campaign enabled.', 'product-mailer-campaigns' ),
                ),
                'disabled' => array(
                    'class'   => 'notice-success',
                    'message' => __( 'Campaign disabled.', 'product-mailer-campaigns' ),
                ),
                'cannot_enable' => array(
                    'class'   => 'notice-warning',
                    'message' => __( 'Campaign could not be enabled. Check its schedule/trigger settings.', 'product-mailer-campaigns' ),
                ),
            ),
            'delete_campaign' => array(
                'deleted' => array(
                    'class'   => 'notice-success',
                    'message' => __( 'Campaign deleted.', 'product-mailer-campaigns' ),
                ),
            ),
            'queue_campaign' => array(
                'queued' => array(
                    'class'   => 'notice-success',
                    'message' => __( 'Campaign queued for sending to matching subscribers.', 'product-mailer-campaigns' ),
                ),
                'not_found' => array(
                    'class'   => 'notice-error',
                    'message' => __( 'Campaign not found.', 'product-mailer-campaigns' ),
                ),
                'no_subscribers' => array(
                    'class'   => 'notice-error',
                    'message' => __( 'No matching subscribers to send to.', 'product-mailer-campaigns' ),
                ),
            ),
        );

        if ( isset( $definitions[ $type ][ $result ] ) ) {
            return $definitions[ $type ][ $result ];
        }

        return array(
            'class'   => '',
            'message' => '',
        );
    }

    /**
     * Render a dismissible campaign admin notice from query args.
     *
     * @param string $query_key Notice query arg key.
     * @param string $type      Notice definition group.
     * @return void
     */
    protected static function render_campaign_query_notice( $query_key, $type ) {
        if ( ! isset( $_GET[ $query_key ] ) ) {
            return;
        }

        $definition = self::get_campaign_admin_notice_definition(
            $type,
            sanitize_text_field( (string) wp_unslash( $_GET[ $query_key ] ) )
        );

        if ( '' === $definition['message'] ) {
            return;
        }

        echo '<div class="notice ' . esc_attr( $definition['class'] ) . ' is-dismissible"><p>' . esc_html( $definition['message'] ) . '</p></div>';
    }

    protected static function get_campaign_recent_activity_preview( $campaign_id, $limit = 5 ) {
        global $wpdb;

        $campaign_id = absint( $campaign_id );
        $limit       = max( 1, min( 10, absint( $limit ) ) );
        if ( $campaign_id <= 0 ) {
            return array();
        }

        $queue_table       = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
        $subscribers_table = esc_sql( $wpdb->prefix . 'pmcpc_subscribers' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT q.status, q.updated_at, q.created_at, s.email
                 FROM {$queue_table} q
                 LEFT JOIN {$subscribers_table} s ON s.id = q.subscriber_id
                 WHERE q.campaign_id = %d
                 ORDER BY q.updated_at DESC, q.id DESC
                 LIMIT %d",
                $campaign_id,
                $limit
            )
        );

        return is_array( $rows ) ? $rows : array();
    }

    protected static function get_preview_wc_customer_stats( $subscriber, $campaign = null ) {
        static $cache = array();

        if ( empty( $subscriber ) || ! is_object( $subscriber ) || empty( $subscriber->email ) ) {
            return array(
                'email'         => '',
                'order_count'   => 0,
                'total_spent'   => 0.0,
                'last_order_ts' => 0,
            );
        }

        $email = sanitize_email( (string) $subscriber->email );
        if ( '' === $email ) {
            return array(
                'email'         => '',
                'order_count'   => 0,
                'total_spent'   => 0.0,
                'last_order_ts' => 0,
            );
        }

        if ( isset( $cache[ $email ] ) ) {
            return $cache[ $email ];
        }

        $stats = array(
            'email'         => $email,
            'order_count'   => 0,
            'total_spent'   => 0.0,
            'last_order_ts' => 0,
        );

        if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
            $cache[ $email ] = $stats;
            return $stats;
        }

        $user        = function_exists( 'get_user_by' ) ? get_user_by( 'email', $email ) : false;
        $customer_id = $user ? (int) $user->ID : 0;
        $statuses    = array( 'wc-completed', 'wc-processing' );

        if ( $customer_id && function_exists( 'wc_get_customer_order_count' ) ) {
            $stats['order_count'] = max( 0, (int) wc_get_customer_order_count( $customer_id ) );
        }

        if ( $customer_id && function_exists( 'wc_get_customer_total_spent' ) ) {
            $stats['total_spent'] = max( 0.0, (float) wc_get_customer_total_spent( $customer_id ) );
        }

        $orders = wc_get_orders(
            array(
                'limit'         => -1,
                'status'        => $statuses,
                'billing_email' => $email,
            )
        );

        if ( ! empty( $orders ) && is_array( $orders ) ) {
            $stats['order_count'] = max( $stats['order_count'], count( $orders ) );
            foreach ( $orders as $order ) {
                if ( ! $order || ! is_object( $order ) ) {
                    continue;
                }
                if ( method_exists( $order, 'get_total' ) ) {
                    $stats['total_spent'] += (float) $order->get_total();
                }
                if ( method_exists( $order, 'get_date_created' ) ) {
                    $date = $order->get_date_created();
                    if ( $date ) {
                        $ts = $date->getTimestamp();
                        if ( $ts > $stats['last_order_ts'] ) {
                            $stats['last_order_ts'] = $ts;
                        }
                    }
                }
            }
            if ( $customer_id && function_exists( 'wc_get_customer_total_spent' ) ) {
                // Avoid double counting when a registered customer's spend already came from Woo helpers.
                $stats['total_spent'] = max( 0.0, (float) wc_get_customer_total_spent( $customer_id ) );
            }
        }

        $cache[ $email ] = $stats;
        return $stats;
    }

    protected static function get_campaign_wc_abandoned_cart_preview( $campaign, $step ) {
        global $wpdb;

        $step = max( 1, min( 3, absint( $step ) ) );
        $data = array(
            'count'  => 0,
            'emails' => array(),
        );

        if ( empty( $campaign ) || ! is_object( $campaign ) ) {
            return $data;
        }

        $delay_minutes = isset( $campaign->trigger_delay_minutes ) ? max( 0, absint( $campaign->trigger_delay_minutes ) ) : 0;
        $table         = esc_sql( $wpdb->prefix . 'pmcpc_abandoned_carts' );
        $step_trigger  = 'abandoned_cart_step_' . $step;

        // No dynamic value placeholders are needed here; $table is derived from
        // $wpdb->prefix and escaped above. Do not wrap this in $wpdb->prepare,
        // as WordPress logs a notice when prepare() receives no placeholders.
        $rows = $wpdb->get_results(
            "SELECT email, abandoned_at, recovery_step, recovery_status, recovery_next_at
             FROM {$table}
             WHERE status = 'abandoned'
               AND email <> ''
               AND email IS NOT NULL
             ORDER BY abandoned_at ASC
             LIMIT 250"
        );

        if ( empty( $rows ) || ! is_array( $rows ) ) {
            return $data;
        }

        foreach ( $rows as $row ) {
            if ( empty( $row->email ) ) {
                continue;
            }

            $email = sanitize_email( (string) $row->email );
            if ( '' === $email ) {
                continue;
            }

            $abandoned_at = ! empty( $row->abandoned_at ) ? strtotime( (string) $row->abandoned_at ) : 0;
            if ( ! $abandoned_at ) {
                continue;
            }

            $due_ts = $abandoned_at + ( $delay_minutes * MINUTE_IN_SECONDS );
            if ( $step > 1 && ! empty( $row->recovery_next_at ) ) {
                $next_ts = strtotime( (string) $row->recovery_next_at );
                if ( $next_ts ) {
                    $due_ts = $next_ts;
                }
            }

            if ( $due_ts > current_time( 'timestamp' ) ) {
                continue;
            }

            $already_sent = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}pmcpc_email_queue q
                     INNER JOIN {$wpdb->prefix}pmcpc_campaigns c ON c.id = q.campaign_id
                     WHERE q.to_email = %s AND c.automation_trigger = %s",
                    $email,
                    $step_trigger
                )
            );
            if ( $already_sent > 0 ) {
                continue;
            }

            $data['count']++;
            if ( count( $data['emails'] ) < 5 ) {
                $data['emails'][] = $email;
            }
        }

        return $data;
    }


    protected static function get_plain_price_preview_text( $amount ) {
        $amount = (float) $amount;
        if ( $amount <= 0 ) {
            return '';
        }

        if ( function_exists( 'wc_price' ) ) {
            return html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' );
        }

        return html_entity_decode( wp_strip_all_tags( (string) $amount ), ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' );
    }

    protected static function get_campaign_automation_preview_data( $campaign ) {
        $trigger          = self::get_campaign_preview_trigger_key( $campaign );
        $eligible         = self::get_preview_subscribers_for_campaign( $campaign );
        $eligible_count   = count( $eligible );
        $site_now         = current_time( 'timestamp' );
        $today_count      = null;
        $today_label      = '';
        $today_emails     = array();
        $next_evaluation  = '';
        $how_it_fires     = '';
        $trigger_count    = null;
        $trigger_label    = '';
        $threshold_value  = '';
        $datetime_format  = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

        switch ( $trigger ) {
            case 'subscriber_birthday':
                $today_label = __( 'Will trigger today', 'product-mailer-campaigns' );
                foreach ( $eligible as $subscriber ) {
                    $birthday_raw = '';
                    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'get_subscriber_birthday' ) && ! empty( $subscriber->id ) ) {
                        $birthday_raw = (string) PMCPC_Subscriber_Manager::get_subscriber_birthday( (int) $subscriber->id );
                    }
                    if ( '' === $birthday_raw ) {
                        foreach ( array( 'birthday', 'birth_date', 'date_of_birth', 'subscriber_birthday', 'pmcpc_birthday' ) as $field ) {
                            if ( ! empty( $subscriber->{$field} ) ) {
                                $birthday_raw = (string) $subscriber->{$field};
                                break;
                            }
                        }
                    }
                    if ( '' === $birthday_raw ) {
                        continue;
                    }
                    $month_day = '';
                    if ( class_exists( 'PMCPC_Subscriber_Manager' ) && method_exists( 'PMCPC_Subscriber_Manager', 'parse_birthday_parts' ) ) {
                        $parts = (array) PMCPC_Subscriber_Manager::parse_birthday_parts( $birthday_raw );
                        if ( ! empty( $parts['month'] ) && ! empty( $parts['day'] ) ) {
                            $month_day = sprintf( '%02d-%02d', (int) $parts['month'], (int) $parts['day'] );
                        }
                    }
                    if ( $month_day && current_time( 'm-d' ) === $month_day ) {
                        $today_count++;
                        if ( ! empty( $subscriber->email ) && count( $today_emails ) < 5 ) {
                            $today_emails[] = (string) $subscriber->email;
                        }
                    }
                }
                $next_evaluation = sprintf(
                    /* translators: %s: next hourly run in site local time. */
                    __( 'Checked hourly. Next scan around %s.', 'product-mailer-campaigns' ),
                    wp_date( $datetime_format, strtotime( '+1 hour', $site_now ) )
                );
                $how_it_fires = __( "Fires on the subscriber's birthday when the date matches today.", 'product-mailer-campaigns' );
                break;

            case 'subscriber_anniversary':
                $today_label = __( 'Will trigger today', 'product-mailer-campaigns' );
                foreach ( $eligible as $subscriber ) {
                    if ( empty( $subscriber->created_at ) ) {
                        continue;
                    }
                    $created_ts = strtotime( (string) $subscriber->created_at );
                    if ( $created_ts && current_time( 'm-d' ) === wp_date( 'm-d', $created_ts ) ) {
                        $today_count++;
                        if ( ! empty( $subscriber->email ) && count( $today_emails ) < 5 ) {
                            $today_emails[] = (string) $subscriber->email;
                        }
                    }
                }
                $next_evaluation = sprintf(
                    __( 'Checked hourly. Next scan around %s.', 'product-mailer-campaigns' ),
                    wp_date( $datetime_format, strtotime( '+1 hour', $site_now ) )
                );
                $how_it_fires = __( 'Fires on the anniversary of when the subscriber joined your list.', 'product-mailer-campaigns' );
                break;

            case 'subscriber_inactive':
                $threshold_days = isset( $campaign->inactive_days_threshold ) ? absint( $campaign->inactive_days_threshold ) : 0;
                if ( $threshold_days <= 0 ) {
                    $threshold_days = 30;
                }
                $today_label = sprintf(
                    /* translators: %d: inactivity threshold in days. */
                    __( 'Currently due (%d+ days inactive)', 'product-mailer-campaigns' ),
                    $threshold_days
                );
                foreach ( $eligible as $subscriber ) {
                    $reference_raw = '';
                    foreach ( array( 'last_engaged_at', 'last_clicked_at', 'last_opened_at', 'updated_at', 'created_at' ) as $field ) {
                        if ( ! empty( $subscriber->{$field} ) ) {
                            $reference_raw = (string) $subscriber->{$field};
                            break;
                        }
                    }
                    $reference_ts = $reference_raw ? strtotime( $reference_raw ) : 0;
                    if ( ! $reference_ts ) {
                        continue;
                    }
                    $event_ts = $reference_ts + ( $threshold_days * DAY_IN_SECONDS );
                    if ( $event_ts <= $site_now ) {
                        $today_count++;
                        if ( ! empty( $subscriber->email ) && count( $today_emails ) < 5 ) {
                            $today_emails[] = (string) $subscriber->email;
                        }
                    }
                }
                $next_evaluation = sprintf(
                    __( 'Checked hourly. Next scan around %s.', 'product-mailer-campaigns' ),
                    wp_date( $datetime_format, strtotime( '+1 hour', $site_now ) )
                );
                $how_it_fires = sprintf(
                    /* translators: %d: inactivity threshold in days. */
                    __( 'Fires when a subscriber has had no recent engagement for at least %d days.', 'product-mailer-campaigns' ),
                    $threshold_days
                );
                break;

            case 'lead_magnet_download':
                $today_label     = __( 'Who can qualify', 'product-mailer-campaigns' );
                $today_count     = null;
                $next_evaluation = __( 'This automation fires immediately when a new subscriber signs up and matches the lead magnet rule. An hourly scan runs as a fallback so no qualifying subscribers are missed.', 'product-mailer-campaigns' );
                $how_it_fires    = __( 'This automation runs when a subscriber joins your mailing list through a lead magnet. A subscriber qualifies when they subscribe to your list, their signup source or tag indicates a lead magnet, and they match any audience filters applied above.', 'product-mailer-campaigns' );
                break;

            case 'new_subscriber':
                $today_label     = __( 'Who can qualify', 'product-mailer-campaigns' );
                $today_count     = null;
                $next_evaluation = __( 'Fires immediately when a new subscriber is created.', 'product-mailer-campaigns' );
                $how_it_fires    = __( 'The audience filters are applied at the moment the subscriber joins.', 'product-mailer-campaigns' );
                break;

            case 'post_purchase':
            case 'review_request':
            case 'new_customer':
            case 'repeat_customer':
            case 'high_value':
            case 'vip_customer':
            case 'customer_inactive':
            case 'abandoned_cart_step_1':
            case 'abandoned_cart_step_2':
            case 'abandoned_cart_step_3':
                if ( ! class_exists( 'WooCommerce' ) ) {
                    return array();
                }

                $delay_minutes = isset( $campaign->trigger_delay_minutes ) ? max( 0, absint( $campaign->trigger_delay_minutes ) ) : 0;
                $recent_cutoff = strtotime( '-1 day', $site_now );

                if ( 0 === strpos( $trigger, 'abandoned_cart_step_' ) ) {
                    $step = (int) str_replace( 'abandoned_cart_step_', '', $trigger );
                    $cart_preview = self::get_campaign_wc_abandoned_cart_preview( $campaign, $step );
                    $today_label  = __( 'Currently due carts', 'product-mailer-campaigns' );
                    $today_count  = isset( $cart_preview['count'] ) ? (int) $cart_preview['count'] : 0;
                    $today_emails = ! empty( $cart_preview['emails'] ) ? $cart_preview['emails'] : array();
                    $next_evaluation = sprintf(
                        /* translators: 1: step number, 2: delay in minutes. */
                        __( 'Checked regularly by the recovery runner. Step %1$d is due after %2$d minutes of abandonment.', 'product-mailer-campaigns' ),
                        $step,
                        $delay_minutes
                    );
                    $how_it_fires = sprintf(
                        /* translators: 1: step number, 2: delay in minutes. */
                        __( 'Fires for carts that remain abandoned until Step %1$d reaches its %2$d minute delay.', 'product-mailer-campaigns' ),
                        $step,
                        $delay_minutes
                    );
                    break;
                }

                $high_value_threshold = class_exists( 'PMCPC_Settings' ) ? (float) PMCPC_Settings::get( 'lifecycle_high_value_threshold', '0' ) : 0.0;
                $vip_threshold        = class_exists( 'PMCPC_Settings' ) ? (float) PMCPC_Settings::get( 'lifecycle_vip_threshold', '0' ) : 0.0;
                $inactive_days        = class_exists( 'PMCPC_Settings' ) ? absint( PMCPC_Settings::get( 'lifecycle_lapsed_days', '180' ) ) : 180;
                if ( $inactive_days <= 0 ) {
                    $inactive_days = 180;
                }
                $inactive_cutoff = strtotime( '-' . $inactive_days . ' days', $site_now );

                foreach ( $eligible as $subscriber ) {
                    $stats = self::get_preview_wc_customer_stats( $subscriber, $campaign );
                    $email = ! empty( $stats['email'] ) ? $stats['email'] : ( ! empty( $subscriber->email ) ? (string) $subscriber->email : '' );

                    switch ( $trigger ) {
                        case 'post_purchase':
                        case 'review_request':
                            if ( $stats['last_order_ts'] && $stats['last_order_ts'] >= $recent_cutoff ) {
                                $today_count++;
                                if ( $email && count( $today_emails ) < 5 ) {
                                    $today_emails[] = $email;
                                }
                            }
                            break;

                        case 'new_customer':
                            if ( 1 === (int) $stats['order_count'] ) {
                                $today_count++;
                                if ( $email && count( $today_emails ) < 5 ) {
                                    $today_emails[] = $email;
                                }
                            }
                            break;

                        case 'repeat_customer':
                            if ( (int) $stats['order_count'] >= 2 ) {
                                $today_count++;
                                if ( $email && count( $today_emails ) < 5 ) {
                                    $today_emails[] = $email;
                                }
                            }
                            break;

                        case 'high_value':
                            if ( $high_value_threshold > 0 && (float) $stats['total_spent'] >= $high_value_threshold ) {
                                $today_count++;
                                if ( $email && count( $today_emails ) < 5 ) {
                                    $today_emails[] = $email;
                                }
                            }
                            break;

                        case 'vip_customer':
                            if ( $vip_threshold > 0 && (float) $stats['total_spent'] >= $vip_threshold ) {
                                $today_count++;
                                if ( $email && count( $today_emails ) < 5 ) {
                                    $today_emails[] = $email;
                                }
                            }
                            break;

                        case 'customer_inactive':
                            if ( $stats['last_order_ts'] && $stats['last_order_ts'] <= $inactive_cutoff ) {
                                $today_count++;
                                if ( $email && count( $today_emails ) < 5 ) {
                                    $today_emails[] = $email;
                                }
                            }
                            break;
                    }
                }

                switch ( $trigger ) {
                    case 'post_purchase':
                        $today_label = __( 'Recent completed orders (last 24 hours)', 'product-mailer-campaigns' );
                        $next_evaluation = $delay_minutes > 0
                            ? sprintf( __( 'Fires when an order completes, then waits %d minutes before queueing.', 'product-mailer-campaigns' ), $delay_minutes )
                            : __( 'Fires immediately when a WooCommerce order completes.', 'product-mailer-campaigns' );
                        $how_it_fires = __( "Queues after every completed WooCommerce order for customers who match this campaign's audience rules.", 'product-mailer-campaigns' );
                        break;

                    case 'review_request':
                        $today_label = __( 'Recent purchasers', 'product-mailer-campaigns' );
                        $next_evaluation = $delay_minutes > 0
                            ? sprintf( __( 'Fires after purchase once the %d minute delay has passed.', 'product-mailer-campaigns' ), $delay_minutes )
                            : __( 'Fires straight after a qualifying completed order unless you add a delay.', 'product-mailer-campaigns' );
                        $how_it_fires = __( 'Use the delay to control when the review request goes out after the purchase trigger.', 'product-mailer-campaigns' );
                        break;

                    case 'new_customer':
                        $today_label = __( 'Customers who currently match first-order status', 'product-mailer-campaigns' );
                        $next_evaluation = __( 'Fires immediately when a customer completes their first WooCommerce order.', 'product-mailer-campaigns' );
                        $how_it_fires = __( "The customer must be on their first completed order and still match this campaign's audience filters.", 'product-mailer-campaigns' );
                        break;

                    case 'repeat_customer':
                        $today_label = __( 'Customers who currently match repeat status', 'product-mailer-campaigns' );
                        $next_evaluation = __( 'Fires when a customer completes their second WooCommerce order.', 'product-mailer-campaigns' );
                        $how_it_fires = __( 'The trigger happens on the second completed order, then the audience filters are applied.', 'product-mailer-campaigns' );
                        break;

                    case 'high_value':
                        $today_label = __( 'Customers currently above the high-value threshold', 'product-mailer-campaigns' );
                        $threshold_value = $high_value_threshold > 0 ? self::get_plain_price_preview_text( $high_value_threshold ) : '';
                        $next_evaluation = $high_value_threshold > 0
                            ? sprintf( __( 'Runs when a new order increases lifetime spend past %s.', 'product-mailer-campaigns' ), $threshold_value )
                            : __( 'Set a high-value threshold in WooCommerce settings to enable this trigger fully.', 'product-mailer-campaigns' );
                        $how_it_fires = __( 'This automation fires once when a customer\'s lifetime spend crosses the high-value threshold.', 'product-mailer-campaigns' );
                        break;

                    case 'vip_customer':
                        $today_label = __( 'Customers currently above the VIP threshold', 'product-mailer-campaigns' );
                        $threshold_value = $vip_threshold > 0 ? self::get_plain_price_preview_text( $vip_threshold ) : '';
                        $next_evaluation = $vip_threshold > 0
                            ? sprintf( __( 'Runs when a new order increases lifetime spend past the VIP threshold of %s.', 'product-mailer-campaigns' ), $threshold_value )
                            : __( 'Set a VIP threshold in WooCommerce settings to enable this trigger fully.', 'product-mailer-campaigns' );
                        $how_it_fires = __( 'This automation fires once when a customer\'s lifetime spend crosses the VIP threshold.', 'product-mailer-campaigns' );
                        break;

                    case 'customer_inactive':
                        $today_label = sprintf( __( 'Currently due (%d+ days since last order)', 'product-mailer-campaigns' ), $inactive_days );
                        $next_evaluation = sprintf( __( 'Checked on the inactive-customer scan. Current win-back window: %d days.', 'product-mailer-campaigns' ), $inactive_days );
                        $how_it_fires = __( 'Customers qualify once their most recent completed order falls outside the inactive window.', 'product-mailer-campaigns' );
                        break;
                }
                break;

            default:
                return array();
        }

        if ( null !== $today_count ) {
            $trigger_count = (int) $today_count;
            $trigger_label = $today_label ? $today_label : __( 'Trigger candidates now', 'product-mailer-campaigns' );
        }

        $qualifying_rule = '';
        if ( 'lead_magnet_download' === $trigger ) {
            $rule_parts = array();
            if ( ! empty( $campaign->target_tag ) ) {
                $rule_parts[] = sprintf(
                    /* translators: %s: comma-separated tag list. */
                    __( 'Subscribers with tag: %s', 'product-mailer-campaigns' ),
                    (string) $campaign->target_tag
                );
            }
            if ( ! empty( $campaign->target_source_tags ) ) {
                $rule_parts[] = sprintf(
                    /* translators: %s: comma-separated source list. */
                    __( 'Subscribers from source: %s', 'product-mailer-campaigns' ),
                    (string) $campaign->target_source_tags
                );
            }
            if ( empty( $rule_parts ) ) {
                $rule_parts[] = __( 'Subscribers whose signup source or tag indicates a lead magnet', 'product-mailer-campaigns' );
            }
            $qualifying_rule = implode( ' · ', $rule_parts );
        }

        return array(
            'trigger'         => $trigger,
            'eligible_count'  => $eligible_count,
            'today_label'     => $today_label,
            'today_count'     => $today_count,
            'today_emails'    => $today_emails,
            'next_evaluation' => $next_evaluation,
            'how_it_fires'    => $how_it_fires,
            'qualifying_rule' => $qualifying_rule,
            'trigger_count'   => $trigger_count,
            'trigger_label'   => $trigger_label,
            'threshold_value' => $threshold_value,
            'recent_activity' => self::get_campaign_recent_activity_preview( isset( $campaign->id ) ? $campaign->id : 0, 5 ),
        );
    }


    /**
     * AJAX: return an approximate recipient count for the current campaign builder values.
     *
     * Used by the stage-by-stage editor and the inline "Queue broadcast" confirmation.
     */
    public static function ajax_recipient_count() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
        }

        check_ajax_referer( 'pmcpc_recipient_count', 'nonce' );

        $campaign_id = isset( $_POST['campaign_id'] ) ? absint( $_POST['campaign_id'] ) : 0;

        // If a campaign id is provided, load it and count against the saved campaign.
        if ( $campaign_id > 0 ) {
            $campaign = class_exists( 'PMCPC_Campaign_Repository' ) ? PMCPC_Campaign_Repository::get_campaign( $campaign_id ) : null;
            $count    = self::count_recipients_for_campaign( $campaign );
            wp_send_json_success( array( 'count' => (int) $count ) );
        }

        // Otherwise, use posted builder fields (for new/unsaved campaigns).
        $campaign = (object) array(
            'id'                   => 0,
            'target_tag'           => isset( $_POST['target_tag'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['target_tag'] ) ) : '',
            'exclude_tags'         => isset( $_POST['exclude_tags'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['exclude_tags'] ) ) : '',
            'target_source_tags'   => isset( $_POST['target_source_tags'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['target_source_tags'] ) ) : '',
            'target_origin_tags'   => isset( $_POST['target_origin_tags'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['target_origin_tags'] ) ) : '',
            'target_lifecycle_tags'=> isset( $_POST['target_lifecycle_tags'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['target_lifecycle_tags'] ) ) : '',
            'pro_segment_key'      => isset( $_POST['pro_segment_key'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pro_segment_key'] ) ) : '',
            // Allow Pro/filters to reason about automation trigger when needed.
            'automation_trigger'   => isset( $_POST['automation_trigger'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['automation_trigger'] ) ) : 'none',
        );

        $count = self::count_recipients_for_campaign( $campaign );
        wp_send_json_success( array( 'count' => (int) $count ) );
    }

    function queue_campaign_to_all( $campaign_id, $add_notice = true ) {
        global $wpdb;

	        $campaign = class_exists( 'PMCPC_Campaign_Repository' ) ? PMCPC_Campaign_Repository::get_campaign( $campaign_id ) : null;

        if ( ! $campaign ) {
            if ( $add_notice ) {
                add_settings_error( 'pmcpc_campaigns', 'pmcpc_campaign_not_found', __( 'Campaign not found.', 'product-mailer-campaigns' ), 'error' );
            }
            return 'not_found';
        }


        $audience_result = self::get_campaign_audience_result( $campaign );
        $subscribers     = ! empty( $audience_result['subscribers'] ) && is_array( $audience_result['subscribers'] ) ? $audience_result['subscribers'] : array();

        if ( ! $subscribers ) {
            if ( $add_notice ) {
                add_settings_error( 'pmcpc_campaigns', 'pmcpc_no_subscribers', __( 'No matching subscribers to send to.', 'product-mailer-campaigns' ), 'error' );
            }
            return 'no_subscribers';
        }

        $delay = isset( $campaign->broadcast_delay_minutes ) ? absint( $campaign->broadcast_delay_minutes ) : 0;

        foreach ( $subscribers as $sub ) {
            self::queue_campaign_for_subscriber( $campaign, $sub, $delay );
        }

        $campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
        $now             = current_time( 'mysql' );
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $campaigns_table,
            array(
                'status'     => 'queued',
                'updated_at' => $now,
            ),
            array( 'id' => $campaign_id ),
            array( '%s', '%s' ),
            array( '%d' )
        );

        if ( $add_notice ) {
            add_settings_error( 'pmcpc_campaigns', 'pmcpc_campaign_queued', __( 'Campaign queued for sending to matching subscribers.', 'product-mailer-campaigns' ), 'updated' );
        }

        return 'queued';
    }

    /**
     * Queue a single email for a subscriber for this campaign, with tracking.
     *
     * @param object $campaign
     * @param object $subscriber
     * @param int    $delay_minutes
     */

    public static function queue_campaign_for_subscriber( $campaign, $subscriber, $delay_minutes = 0, $allow_duplicate = false, $context = array() ) {
        global $wpdb;

        $queue_table = $wpdb->prefix . 'pmcpc_email_queue';

        $campaign_trigger = '';
        if ( is_object( $campaign ) && isset( $campaign->automation_trigger ) ) {
            $campaign_trigger = sanitize_key( (string) $campaign->automation_trigger );
        }
        if ( '' === $campaign_trigger && is_object( $campaign ) && ! empty( $campaign->is_post_purchase ) ) {
            $campaign_trigger = 'post_purchase';
        }

        if ( function_exists( 'pmcpc_is_premium_wc_trigger' )
            && pmcpc_is_premium_wc_trigger( $campaign_trigger )
            && ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() )
        ) {
            return;
        }

        /*
         * Prevent duplicate queue entries.
         *
         * On some hosts, caching layers, checkout re-processing, or plugin updates can cause
         * the same campaign to be queued more than once for the same subscriber. This
         * results in repeated emails.
         *
         * A campaign should only be queued once per subscriber for a given campaign ID.
         */
		if ( ! $allow_duplicate ) {
			$existing_id = class_exists( 'PMCPC_Campaign_Repository' )
				? PMCPC_Campaign_Repository::get_existing_queue_item_id( (int) $subscriber->id, (int) $campaign->id )
				: 0;
			if ( $existing_id > 0 ) {
				return;
			}
		}

        $timestamp    = current_time( 'timestamp' ) + ( absint( $delay_minutes ) * 60 );
        $scheduled_at = gmdate( 'Y-m-d H:i:s', $timestamp );
        $now          = current_time( 'mysql' );

        // Template variables.
        // Keep legacy placeholders while supporting richer automation context.
        $vars = array(
            'email'      => (string) $subscriber->email,
            'first_name' => (string) $subscriber->first_name,
            'last_name'  => (string) $subscriber->last_name,
        );

        // Common WooCommerce/cart context helpers.
        if ( is_array( $context ) ) {
            if ( isset( $context['cart_total'] ) ) {
                $vars['cart_total'] = (string) $context['cart_total'];
            }
            if ( isset( $context['cart_url'] ) ) {
                $vars['cart_url'] = (string) $context['cart_url'];
            }
            if ( isset( $context['cart_items_html'] ) ) {
                $vars['cart_items'] = (string) $context['cart_items_html'];
            }
            if ( isset( $context['order_id'] ) ) {
                $vars['order_id'] = (string) absint( $context['order_id'] );
            }
        }

        /**
         * Filter template vars for a campaign before queuing.
         *
         * Keys become placeholders like {{first_name}}.
         *
         * @param array  $vars
         * @param object $campaign
         * @param object $subscriber
         * @param array  $context
         */
        $vars = apply_filters( 'pmcpc_campaign_template_vars', $vars, $campaign, $subscriber, is_array( $context ) ? $context : array() );

        // Apply replacements to subject + body.
        $search  = array();
        $replace = array();
        foreach ( (array) $vars as $k => $v ) {
            $k = trim( (string) $k );
            if ( '' === $k ) {
                continue;
            }
            $search[]  = '{{' . $k . '}}';
            $replace[] = (string) $v;
        }

        $subject  = str_replace( $search, $replace, (string) $campaign->subject );
        $body_html = str_replace( $search, $replace, (string) $campaign->content );

        // Inject WooCommerce products block if enabled on this campaign.
        $body_html = self::inject_products_block( $campaign, $body_html );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->insert(
            $queue_table,
            array(
                'subscriber_id' => $subscriber->id,
                'campaign_id'   => $campaign->id,
                'to_email'      => $subscriber->email,
                'subject'       => $subject,
                'body_html'     => $body_html,
                'scheduled_at'  => $scheduled_at,
                'attempts'      => 0,
                'status'        => 'pending',
                'created_at'    => $now,
                'updated_at'    => $now,
            ),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
        );

        $queue_id = $wpdb->insert_id;
        if ( ! $queue_id ) {
            return;
        }

        // Generate and persist a view-in-browser token at queue creation time (robust across salt/key changes).
        $view_token = PMCPC_Tracking::generate_view_token();
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $queue_table,
            array(
                'view_token' => $view_token,
                'updated_at' => $now,
            ),
            array( 'id' => $queue_id ),
            array( '%s', '%s' ),
            array( '%d' )
        );

        $tracked_html = PMCPC_Tracking::add_tracking_to_html( $body_html, $queue_id, $view_token );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $queue_table,
            array(
                'body_html'  => $tracked_html,
                'updated_at' => $now,
            ),
            array( 'id' => $queue_id ),
            array( '%s', '%s' ),
            array( '%d' )
        );
    }

    public static function send_welcome_campaigns_for_subscriber_email( $email ) {
        global $wpdb;

		$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
		$campaigns_table   = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
		$email             = sanitize_email( $email );
		if ( empty( $email ) ) {
			return;
		}

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$subscriber = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM %i WHERE email = %s', $subscribers_table, $email )
		);
        if ( ! $subscriber ) {
            return;
        }

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$campaigns = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM %i WHERE status = %s AND (is_welcome = 1 OR automation_trigger IN (%s, %s))",
					$campaigns_table,
					'active',
					'new_subscriber',
					'welcome'
				)
			);
        if ( ! $campaigns ) {
            return;
        }

		foreach ( $campaigns as $campaign ) {
			$delay = self::get_delay_minutes_for_campaign_row( $campaign );

			// Allow Pro segments / automation filters to decide whether this subscriber
			// should receive this particular welcome campaign. Start with the single
			// subscriber row as the default candidate list.
			$candidates = array( $subscriber );

            // Apply exclude-tags first.
            $candidates = self::filter_subscribers_by_exclude_tags( $candidates, $campaign );

            // Then apply Pro segment logic (customers, recent, high-value, VIP, lapsed).
            $candidates = self::filter_subscribers_by_pro_segment( $candidates, $campaign );

            /**
             * Filter the list of subscribers that should receive a given campaign.
             *
             * @param array  $candidates List of subscriber rows (pmcpc_subscribers).
             * @param object $campaign   Campaign row (pmcpc_campaigns).
             */
            $filtered = apply_filters( 'pmcpc_campaign_subscribers', $candidates, $campaign );

            if ( empty( $filtered ) || ! is_array( $filtered ) ) {
                continue;
            }

            // Use the first (and only) subscriber object.
            $target = reset( $filtered );
            if ( ! $target ) {
                continue;
            }

            self::queue_campaign_for_subscriber( $campaign, $target, $delay );
        }
    }

    /**
     * Triggered for WooCommerce orders (post-purchase automations).
     */
    public static function send_post_purchase_campaigns_for_subscriber_email( $email ) {
        global $wpdb;

		$subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
		$campaigns_table   = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );
		$email             = sanitize_email( $email );
		if ( empty( $email ) ) {
			return;
		}

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$subscriber = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM %i WHERE email = %s', $subscribers_table, $email )
		);
        if ( ! $subscriber ) {
            return;
        }

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$campaigns = $wpdb->get_results(
			$wpdb->prepare( 'SELECT * FROM %i WHERE is_post_purchase = 1 AND status = %s', $campaigns_table, 'active' )
		);
        if ( ! $campaigns ) {
            return;
        }

        foreach ( $campaigns as $campaign ) {
            $delay = self::get_delay_minutes_for_campaign_row( $campaign );

            // Allow Pro segments / automation filters to decide whether this subscriber
            // should actually receive the campaign.
            $candidates = array( $subscriber );

            // Apply exclude-tags segmentation (if any) before Pro filters.
            $candidates = self::filter_subscribers_by_exclude_tags( $candidates, $campaign );

            // Apply Pro segment logic (customers, recent, high-value, VIP, lapsed).
            $candidates = self::filter_subscribers_by_pro_segment( $candidates, $campaign );

            /**
             * Filter the list of subscribers that should receive a given campaign.
             *
             * @param array  $candidates List of subscriber rows (pmcpc_subscribers).
             * @param object $campaign   Campaign row (pmcpc_campaigns).
             */
            $filtered = apply_filters( 'pmcpc_campaign_subscribers', $candidates, $campaign );

            if ( empty( $filtered ) || ! is_array( $filtered ) ) {
                continue;
            }

            $target = reset( $filtered );
            if ( ! $target ) {
                continue;
            }

            self::queue_campaign_for_subscriber( $campaign, $target, $delay );
        }
    }


    /**
     * Unified automation dispatcher for any trigger stored in campaigns. 
     *
     * Triggers (events) should call this rather than implementing their own
     * queueing logic.
     *
     * @param string $trigger_key
     * @param string $email
     * @param array  $context Optional context (order/cart/etc). Passed into template vars filter.
     * @return void
     */
    public static function dispatch_automation_trigger_for_subscriber_email( $trigger_key, $email, $context = array() ) {
        global $wpdb;

        $trigger_key = sanitize_key( (string) $trigger_key );
        $email       = sanitize_email( (string) $email );
        if ( empty( $trigger_key ) || empty( $email ) ) {
            return;
        }

        if ( function_exists( 'pmcpc_is_premium_wc_trigger' )
            && pmcpc_is_premium_wc_trigger( $trigger_key )
            && ( ! function_exists( 'pmcpc_wc_automation_enabled' ) || ! pmcpc_wc_automation_enabled() )
        ) {
            return;
        }

        $subscribers_table = $wpdb->prefix . 'pmcpc_subscribers';
        $campaigns_table   = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $subscriber = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM %i WHERE email = %s', $subscribers_table, $email )
        );
        if ( ! $subscriber ) {
            return;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $campaigns = $wpdb->get_results(
            $wpdb->prepare( 'SELECT * FROM %i WHERE automation_trigger = %s AND status = %s', $campaigns_table, $trigger_key, 'active' )
        );

        // Back-compat for installs where some campaigns still use legacy flags.
        if ( empty( $campaigns ) ) {
            if ( 'welcome' === $trigger_key ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $campaigns = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE is_welcome = 1 AND status = %s', $campaigns_table, 'active' ) );
            } elseif ( 'post_purchase' === $trigger_key ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $campaigns = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE is_post_purchase = 1 AND status = %s', $campaigns_table, 'active' ) );
            }
        }

        if ( empty( $campaigns ) ) {
            return;
        }

        foreach ( $campaigns as $campaign ) {
            $delay = self::get_delay_minutes_for_campaign_row( $campaign );
            if ( is_array( $context ) && ! empty( $context['__pmcpc_force_zero_delay'] ) ) {
                $delay = 0;
            }

            $candidates = array( $subscriber );

            // Apply exclude-tags segmentation (if any) before Pro filters.
            $candidates = self::filter_subscribers_by_exclude_tags( $candidates, $campaign );

            // Apply Pro segment logic.
            $candidates = self::filter_subscribers_by_pro_segment( $candidates, $campaign );

            /**
             * Filter the list of subscribers that should receive a given campaign.
             *
             * @param array  $candidates List of subscriber rows (pmcpc_subscribers).
             * @param object $campaign   Campaign row (pmcpc_campaigns).
             */
            $filtered = apply_filters( 'pmcpc_campaign_subscribers', $candidates, $campaign );

            if ( empty( $filtered ) || ! is_array( $filtered ) ) {
                continue;
            }

            $target = reset( $filtered );
            if ( ! $target ) {
                continue;
            }

            self::queue_campaign_for_subscriber( $campaign, $target, $delay, false, is_array( $context ) ? $context : array() );
        }
    }

    /**
     * Determine the delay minutes for a campaign row.
     *
     * The UI uses a unified "Delay after trigger" field, but the DB currently
     * stores it in legacy columns for backwards compatibility.
     *
     * @param object $campaign
     * @return int
     */
    protected static function get_delay_minutes_for_campaign_row( $campaign ) {
		// Canonical unified delay.
		if ( isset( $campaign->trigger_delay_minutes ) && absint( $campaign->trigger_delay_minutes ) > 0 ) {
			return absint( $campaign->trigger_delay_minutes );
		}
        if ( ! empty( $campaign->is_welcome ) ) {
            return isset( $campaign->welcome_delay_minutes ) ? absint( $campaign->welcome_delay_minutes ) : 0;
        }
        if ( ! empty( $campaign->is_post_purchase ) ) {
            return isset( $campaign->post_purchase_delay_minutes ) ? absint( $campaign->post_purchase_delay_minutes ) : 0;
        }
        // For other triggers, use broadcast_delay_minutes (the unified UI writes here too).
        return isset( $campaign->broadcast_delay_minutes ) ? absint( $campaign->broadcast_delay_minutes ) : 0;
    }


    /**
     * Inject WooCommerce products block into campaign body if enabled.
     *
     * Uses the {{products_block}} or {{products}} placeholder if present;
     * otherwise appends the block to the end of the email.
     *
     * @param object $campaign  Campaign row.
     * @param string $body_html Email HTML.
     * @return string
     */
    protected static function inject_products_block( $campaign, $body_html ) {
        if ( empty( $campaign->product_block_enabled ) ) {
            return $body_html;
        }

        $block_html = self::render_products_block( $campaign );
        if ( ! $block_html ) {
            return $body_html;
        }

        if ( false !== strpos( $body_html, '{{products_block}}' ) || false !== strpos( $body_html, '{{products}}' ) ) {
            $body_html = str_replace(
                array( '{{products_block}}', '{{products}}' ),
                $block_html,
                $body_html
            );
        } else {
            $body_html .= $block_html;
        }

        return $body_html;
    }

    /**
     * Render WooCommerce products HTML for a campaign.
     *
     * @param object $campaign Campaign row.
     * @return string
     */

    /**
     * Render WooCommerce products HTML for a campaign id so other layers
     * (such as Subscriber Updates front-end rendering) can reuse the same
     * products block output without duplicating the product query logic.
     *
     * @param int $campaign_id Campaign id.
     * @return string
     */
    public static function pmcpc_render_products_block_for_campaign_id( $campaign_id ) {
        $campaign_id = absint( $campaign_id );
        if ( $campaign_id <= 0 ) {
            return '';
        }

        $campaign = class_exists( 'PMCPC_Campaign_Repository' ) ? PMCPC_Campaign_Repository::get_campaign( $campaign_id ) : null;
        if ( ! $campaign ) {
            return '';
        }

        return self::render_products_block( $campaign );
    }

    /**
     * Replace campaign product block placeholders in arbitrary html using the
     * original campaign configuration when available.
     *
     * @param int    $campaign_id Campaign id.
     * @param string $content     Content to process.
     * @return string
     */
    public static function pmcpc_inject_products_block_for_campaign_id( $campaign_id, $content ) {
        $content = (string) $content;
        if ( '' === $content ) {
            return $content;
        }

        if ( false === strpos( $content, '{{products_block}}' ) && false === strpos( $content, '{{products}}' ) ) {
            return $content;
        }

        $block_html = self::pmcpc_render_products_block_for_campaign_id( $campaign_id );
        if ( '' === $block_html ) {
            return $content;
        }

        return str_replace(
            array( '{{products_block}}', '{{products}}' ),
            $block_html,
            $content
        );
    }

    protected static function render_products_block( $campaign ) {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return '';
        }

        $limit = isset( $campaign->product_block_limit ) ? absint( $campaign->product_block_limit ) : 3;
        if ( $limit <= 0 ) {
            $limit = 3;
        }

        $source = isset( $campaign->product_block_source ) && $campaign->product_block_source ? $campaign->product_block_source : 'latest';
$category_ids = array();
if ( ! empty( $campaign->product_block_categories ) ) {
    $raw_cats = explode( ',', $campaign->product_block_categories );
    foreach ( $raw_cats as $raw_cat ) {
        $cat_id = absint( trim( $raw_cat ) );
        if ( $cat_id > 0 ) {
            $category_ids[] = $cat_id;
        }
    }
    $category_ids = array_values( array_unique( $category_ids ) );
}


        $args = array(
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
        );

        $exclude_oos = ! empty( $campaign->product_block_exclude_oos );
        if ( $exclude_oos ) {
            // Exclude out-of-stock products.
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Needed to filter products by stock status.
            $args['meta_query'] = isset( $args['meta_query'] ) ? (array) $args['meta_query'] : array();
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Needed to filter products by stock status.
            $args['meta_query'][] = array(
                'key'     => '_stock_status',
                'value'   => 'outofstock',
                'compare' => '!=',
            );
        }

		if ( 'featured' === $source ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Uses WooCommerce product_visibility taxonomy to fetch featured products.
			$args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_visibility',
                    'field'    => 'name',
                    'terms'    => array( 'featured' ),
                    'operator' => 'IN',
                ),
            );
        } elseif ( 'on_sale' === $source && function_exists( 'wc_get_product_ids_on_sale' ) ) {
            $sale_ids = wc_get_product_ids_on_sale();
            $sale_ids = array_map( 'absint', (array) $sale_ids );
            if ( empty( $sale_ids ) ) {
                return '';
            }
            $args['post__in'] = $sale_ids;
        } elseif ( 'random' === $source ) {
            // Random published products.
            $args['orderby'] = 'rand';
        } elseif ( 'specific' === $source && ! empty( $campaign->product_block_specific_ids ) ) {
            $raw_ids = explode( ',', $campaign->product_block_specific_ids );
            $ids     = array();

            foreach ( $raw_ids as $raw_id ) {
                $id = absint( trim( $raw_id ) );
                if ( $id > 0 ) {
                    $ids[] = $id;
                }
            }

            $ids = array_values( array_unique( $ids ) );

            if ( empty( $ids ) ) {
                return '';
            }

            // Respect limit if it is smaller than the number of IDs.
            if ( $limit > 0 && count( $ids ) > $limit ) {
                $ids = array_slice( $ids, 0, $limit );
            }

            $args['post__in'] = $ids;
            $args['orderby']  = 'post__in';
        } else {
            // Latest products (default) - order by date desc.
            $args['orderby'] = 'date';
            $args['order']   = 'DESC';
        }

		if ( ! empty( $category_ids ) && 'specific' !== $source ) {
			$category_query = array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => $category_ids,
				'operator' => 'IN',
			);

			if ( isset( $args['tax_query'] ) ) {
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Needed to filter products by category.
				$args['tax_query'][] = $category_query;
			} else {
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Needed to filter products by category.
				$args['tax_query'] = array( $category_query );
			}
		}

		$q = new WP_Query( $args );
        if ( ! $q->have_posts() ) {
            wp_reset_postdata();
            return '';
        }

        $layout = isset( $campaign->product_block_layout ) && $campaign->product_block_layout ? (string) $campaign->product_block_layout : 'classic_left';
        $allowed_layouts = array( 'classic_left', 'classic_right', 'compact_left', 'grid_2', 'grid_3' );
        if ( ! in_array( $layout, $allowed_layouts, true ) ) {
            $layout = 'classic_left';
        }

        // Email-safe: tables + inline styles (no external CSS).
        $title_style = 'margin:0 0 12px 0;font-size:18px;line-height:1.2;';
        $cell_pad    = 'padding:10px 0;';
        $link_style  = 'color:inherit;text-decoration:none;';

        ob_start();
        echo '<div class="pmcpc-products-block">';
        echo '<h3 style="' . esc_attr( $title_style ) . '">' . esc_html__( 'Products', 'product-mailer-campaigns' ) . '</h3>';

        if ( 'grid_2' === $layout || 'grid_3' === $layout ) {
            $cols   = ( 'grid_3' === $layout ) ? 3 : 2;
            $img_w  = ( 'grid_3' === $layout ) ? 160 : 220;
            $img_h  = ( 'grid_3' === $layout ) ? 160 : 220;
            $i      = 0;

            echo '<table cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;">';
            while ( $q->have_posts() ) {
                $q->the_post();
                $product = wc_get_product( get_the_ID() );
                if ( ! $product ) {
                    continue;
                }

                if ( 0 === $i % $cols ) {
                    echo '<tr>';
                }

                echo '<td valign="top" style="' . esc_attr( $cell_pad ) . 'padding-right:12px;">';
                $thumb = '';
                if ( has_post_thumbnail() ) {
                    $thumb = wp_get_attachment_image( get_post_thumbnail_id( get_the_ID() ), array( $img_w, $img_h ), false, array( 'style' => 'display:block;width:100%;height:auto;border:0;max-width:' . (int) $img_w . 'px;' ) );
                }
                if ( $thumb ) {
                    echo '<a href="' . esc_url( get_permalink() ) . '" style="' . esc_attr( $link_style ) . '">' . $thumb . '</a>';
                }
                echo '<p style="margin:8px 0 4px 0;font-size:14px;line-height:1.35;">'
                    . '<a href="' . esc_url( get_permalink() ) . '" style="' . esc_attr( $link_style ) . '">' . esc_html( get_the_title() ) . '</a>'
                    . '</p>';
                echo '<p style="margin:0;font-size:14px;line-height:1.35;">' . wp_kses_post( $product->get_price_html() ) . '</p>';
                echo '</td>';

                $i++;

                if ( 0 === $i % $cols ) {
                    echo '</tr>';
                }
            }

            // Pad the last row if needed.
            $remainder = $i % $cols;
            if ( 0 !== $remainder ) {
                for ( $pad = $remainder; $pad < $cols; $pad++ ) {
                    echo '<td valign="top" style="' . esc_attr( $cell_pad ) . '"></td>';
                }
                echo '</tr>';
            }
            echo '</table>';
        } else {
            $img_w = ( 'compact_left' === $layout ) ? 64 : 96;
            $img_h = $img_w;
            $img_on_right = ( 'classic_right' === $layout );

            echo '<table cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;">';
            while ( $q->have_posts() ) {
                $q->the_post();
                $product = wc_get_product( get_the_ID() );
                if ( ! $product ) {
                    continue;
                }

                $thumb = '';
                if ( has_post_thumbnail() ) {
                    $thumb = wp_get_attachment_image( get_post_thumbnail_id( get_the_ID() ), array( $img_w, $img_h ), false, array( 'style' => 'display:block;border:0;width:' . (int) $img_w . 'px;height:auto;max-width:' . (int) $img_w . 'px;' ) );
                }

                $img_td  = '<td valign="top" width="' . (int) $img_w . '" style="' . esc_attr( $cell_pad ) . 'padding-right:12px;">'
                    . ( $thumb ? '<a href="' . esc_url( get_permalink() ) . '" style="' . esc_attr( $link_style ) . '">' . $thumb . '</a>' : '' )
                    . '</td>';

                $text_td = '<td valign="top" style="' . esc_attr( $cell_pad ) . '">'
                    . '<p style="margin:0 0 6px 0;font-size:14px;line-height:1.35;">'
                    . '<a href="' . esc_url( get_permalink() ) . '" style="' . esc_attr( $link_style ) . '">' . esc_html( get_the_title() ) . '</a>'
                    . '</p>'
                    . '<p style="margin:0;font-size:14px;line-height:1.35;">' . wp_kses_post( $product->get_price_html() ) . '</p>'
                    . '</td>';

                echo '<tr>';
                echo $img_on_right ? $text_td . $img_td : $img_td . $text_td; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Already escaped pieces.
                echo '</tr>';
            }
            echo '</table>';
        }

        echo '</div>';
        if ( ! empty( $automation_trigger ) ) {
            printf( '<p class="description">%s</p>', esc_html( sprintf( __( 'Recommended baseline for this trigger: %s. This gives the user the right starter content and placeholders for the selected automation.', 'product-mailer-campaigns' ), isset( $pmcpc_all_templates[ $pmcpc_recommended_tpl ]['label'] ) ? (string) $pmcpc_all_templates[ $pmcpc_recommended_tpl ]['label'] : (string) $pmcpc_recommended_tpl ) ) );
        }

        wp_reset_postdata();

        return ob_get_clean();
    }

    /**
     * Cron handler: process scheduled campaigns (date/time + frequency).
     */
        public static function process_scheduled_campaigns() {
			// Self-reschedule as a single event to avoid relying on a custom cron schedule.
			if ( ! wp_next_scheduled( 'pmcpc_process_scheduled_campaigns' ) ) {
				wp_schedule_single_event( time() + 60, 'pmcpc_process_scheduled_campaigns' );
			}

        global $wpdb;

	    $campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

        $now = current_time( 'mysql' );

        // Find all non-manual campaigns that are due to run.
// Only campaigns explicitly marked as "scheduled" are allowed to auto-run.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	    $campaigns = $wpdb->get_results(
	        $wpdb->prepare(
	            'SELECT * FROM %i
	             WHERE schedule_type != %s
	               AND status = %s
	               AND next_run_at IS NOT NULL
	               AND next_run_at <= %s',
	            $campaigns_table,
	            'manual',
	            'scheduled',
	            $now
	        )
	    );

        if ( empty( $campaigns ) ) {
            return;
        }

        $self = new self();

        foreach ( $campaigns as $campaign ) {
            // Queue this run for all matching subscribers.
            $self->queue_campaign_to_all( (int) $campaign->id );

            $next_run_at = null;
            $new_status  = 'queued';

            // For recurring schedules, calculate the next run time.
            if ( 'recurring' === $campaign->schedule_type && ! empty( $campaign->schedule_frequency ) ) {
                $base_ts = $campaign->next_run_at ? strtotime( $campaign->next_run_at ) : 0;

                if ( ! $base_ts && ! empty( $campaign->schedule_datetime ) ) {
                    $base_ts = strtotime( $campaign->schedule_datetime );
                }

                if ( ! $base_ts ) {
                    $base_ts = current_time( 'timestamp' );
                }

                switch ( $campaign->schedule_frequency ) {
                    case 'daily':
                        $base_ts = strtotime( '+1 day', $base_ts );
                        break;
                    case 'weekly':
                        $base_ts = strtotime( '+1 week', $base_ts );
                        break;
                    case 'monthly':
                        $base_ts = strtotime( '+1 month', $base_ts );
                        break;
                }

                if ( $base_ts ) {
                    $next_run_at = gmdate( 'Y-m-d H:i:s', $base_ts );
                    // Keep recurring campaigns marked as scheduled.
                    $new_status  = 'scheduled';
                }
            }

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->update(
                $campaigns_table,
                array(
                    'next_run_at' => $next_run_at,
                    'status'      => $new_status,
                    'updated_at'  => $now,
                ),
                array( 'id' => $campaign->id ),
                array( '%s', '%s', '%s' ),
                array( '%d' )
            );
        }
    }

}
