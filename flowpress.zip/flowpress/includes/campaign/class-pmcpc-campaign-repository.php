<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Shared campaign data-access helpers.
 */
class PMCPC_Campaign_Repository {

    /**
     * Load one campaign row by id.
     *
     * @param int $campaign_id Campaign ID.
     * @return object|null
     */
    public static function get_campaign( $campaign_id ) {
        global $wpdb;

        $campaign_id = absint( $campaign_id );
        if ( $campaign_id <= 0 ) {
            return null;
        }

        $campaigns_table = esc_sql( $wpdb->prefix . 'pmcpc_campaigns' );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$campaigns_table} WHERE id = %d",
                $campaign_id
            )
        );
    }

    /**
     * Check whether a queue item already exists for a subscriber/campaign pair.
     *
     * @param int   $subscriber_id Subscriber ID.
     * @param int   $campaign_id   Campaign ID.
     * @param array $statuses      Queue statuses to consider duplicates.
     * @return int Existing queue item ID, or 0 when none exists.
     */
    public static function get_existing_queue_item_id( $subscriber_id, $campaign_id, $statuses = array( 'pending', 'sent' ) ) {
        global $wpdb;

        $subscriber_id = absint( $subscriber_id );
        $campaign_id   = absint( $campaign_id );
        $statuses      = array_values( array_filter( array_map( 'sanitize_key', (array) $statuses ) ) );

        if ( $subscriber_id <= 0 || $campaign_id <= 0 || empty( $statuses ) ) {
            return 0;
        }

        $queue_table   = esc_sql( $wpdb->prefix . 'pmcpc_email_queue' );
        $placeholders  = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
        $prepare_args  = array_merge( array( $subscriber_id, $campaign_id ), $statuses );

        // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is plugin-controlled.
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$queue_table} WHERE subscriber_id = %d AND campaign_id = %d AND status IN ({$placeholders}) LIMIT 1",
                $prepare_args
            )
        );
    }
}
