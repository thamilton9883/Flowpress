# FlowPress – Email Automations for WordPress

FlowPress is a WordPress email automation plugin for creating subscriber forms, email campaigns, queues, automations, and simple workflow-based email journeys directly inside WordPress.

It is designed for site owners who want practical email automation without sending customer and subscriber data to a separate SaaS platform.

## Highlights

- WordPress-native email campaigns and automations
- Subscriber forms and list management
- Email queue with manual force-send tools
- SMTP configuration and test email tool
- Workflow-style automations, including multi-step sequences
- Dashboard insights and automation health checks
- Optional WooCommerce-focused automation features

## Core / Free Automations

FlowPress can be used for core WordPress email workflows such as:

- Subscriber welcome emails
- List-based campaigns
- Manual newsletters
- Scheduled campaigns
- Subscriber forms
- Preference and unsubscribe handling

## WooCommerce / Paid Automations

WooCommerce-focused automations are intended for the paid/commercial version and may include:

- Abandoned cart recovery
- Post-purchase follow-ups
- Repeat customer automations
- High-value customer workflows
- Review request emails
- Revenue attribution and insights

Learn more at: https://flowpress.uk/

## Installation

1. Download the plugin zip from the latest release.
2. In WordPress, go to **Plugins → Add New → Upload Plugin**.
3. Upload the zip file and activate FlowPress.
4. Open **FlowPress** in the WordPress admin menu.
5. Configure sender details and SMTP settings before sending live emails.

## Screenshots

Add screenshots to the `assets/` folder and reference them here, for example:

```markdown
![FlowPress dashboard](assets/dashboard.png)
![FlowPress workflows](assets/workflows.png)
```

## Privacy

FlowPress stores subscriber, campaign, queue, and tracking data in your WordPress database. By default, it does not require an external email marketing SaaS platform.

You are responsible for complying with local email marketing, privacy, and consent laws, including unsubscribe and consent requirements.

## Development Notes

This repository is suitable as a public GitHub home for FlowPress. Before submitting to WordPress.org, create a stricter WordPress.org-ready build with reduced commercial messaging and a full guideline audit.

## License

GPLv2 or later.
