<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package Product_Mailer_Campaigns
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Only delete data if the user explicitly opted in.
$pmcpc_delete_data = get_option( 'pmcpc_delete_data_on_uninstall', false );

if ( $pmcpc_delete_data ) {
    global $wpdb;

	$pmcpc_tables = array(
        $wpdb->prefix . 'pmcpc_subscribers',
        $wpdb->prefix . 'pmcpc_campaigns',
        $wpdb->prefix . 'pmcpc_email_queue',
        $wpdb->prefix . 'pmcpc_email_log',
        // Add any other custom tables you use.
    );

	    foreach ( $pmcpc_tables as $pmcpc_table ) {
	        // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $pmcpc_table is plugin-controlled.
	        $wpdb->query( "DROP TABLE IF EXISTS {$pmcpc_table}" );
	    }

    // Delete plugin options.
    delete_option( 'pmcpc_settings' );
    delete_option( 'pmcpc_delete_data_on_uninstall' );
}
