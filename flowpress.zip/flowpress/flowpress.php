<?php
/**
 * Plugin Name:       FlowPress
 * Description:       Email, audience, and content workflows for WordPress, with optional WooCommerce revenue automation.
 * Version:           1.4.24
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Author:            FlowPress
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       flowpress
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'PMCPC_PLUGIN_FILE', __FILE__ );
define( 'PMCPC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PMCPC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'PMCPC_PLUGIN_VERSION', '1.4.24' );
// Back-compat: older builds referenced PMCPC_PATH.
if ( ! defined( 'PMCPC_PATH' ) ) {
    define( 'PMCPC_PATH', PMCPC_PLUGIN_DIR );
}

/**
 * Suppress noisy host warnings caused by WordPress/core libraries attempting to
 * call set_time_limit() on shared hosts where that PHP function is disabled.
 *
 * FlowPress does not call set_time_limit() directly, but WordPress maintenance,
 * update, and schema routines can do so before/around plugin admin requests.
 * The warning is harmless, but it pollutes debug logs and the FlowPress bug
 * report. Only this very specific disabled-function warning is swallowed; all
 * other PHP errors continue through the normal handler chain.
 */
if ( ! function_exists( 'pmcpc_suppress_disabled_set_time_limit_warning' ) ) {
    function pmcpc_suppress_disabled_set_time_limit_warning( $errno, $errstr, $errfile = '', $errline = 0 ) {
        $message = strtolower( (string) $errstr );

        if ( false !== strpos( $message, 'set_time_limit' ) && ( false !== strpos( $message, 'disabled function' ) || false !== strpos( $message, 'has been disabled' ) || false !== strpos( $message, 'not allowed' ) ) ) {
            return true;
        }

        if ( isset( $GLOBALS['pmcpc_previous_error_handler'] ) && is_callable( $GLOBALS['pmcpc_previous_error_handler'] ) ) {
            return (bool) call_user_func( $GLOBALS['pmcpc_previous_error_handler'], $errno, $errstr, $errfile, $errline );
        }

        return false;
    }
}

if ( ! function_exists( 'pmcpc_register_disabled_set_time_limit_warning_filter' ) ) {
    function pmcpc_register_disabled_set_time_limit_warning_filter() {
        if ( ! function_exists( 'pmcpc_suppress_disabled_set_time_limit_warning' ) ) {
            return;
        }

        // Re-register on key WordPress hooks because some plugins/libraries replace
        // the PHP error handler after FlowPress has loaded. This keeps the very
        // narrow disabled set_time_limit warning filter at the top of the chain
        // during admin, cron, updater, and diagnostics requests.
        $current = isset( $GLOBALS['pmcpc_previous_error_handler'] ) ? $GLOBALS['pmcpc_previous_error_handler'] : null;
        $previous = set_error_handler( 'pmcpc_suppress_disabled_set_time_limit_warning' );
        if ( 'pmcpc_suppress_disabled_set_time_limit_warning' !== $previous && is_callable( $previous ) ) {
            $GLOBALS['pmcpc_previous_error_handler'] = $previous;
        } elseif ( is_callable( $current ) ) {
            $GLOBALS['pmcpc_previous_error_handler'] = $current;
        }
        $GLOBALS['pmcpc_disabled_set_time_limit_handler_registered'] = true;
    }
}

pmcpc_register_disabled_set_time_limit_warning_filter();
add_action( 'plugins_loaded', 'pmcpc_register_disabled_set_time_limit_warning_filter', 9999 );
add_action( 'init', 'pmcpc_register_disabled_set_time_limit_warning_filter', 9999 );
add_action( 'admin_init', 'pmcpc_register_disabled_set_time_limit_warning_filter', 1 );
add_action( 'wp_loaded', 'pmcpc_register_disabled_set_time_limit_warning_filter', 1 );

// Core includes.
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-prefix-guard.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-activator.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-deactivator.php';
require_once PMCPC_PLUGIN_DIR . 'includes/helpers.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/class-pmcpc-activity-feed.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/class-pmcpc-automation-debug-log.php';
require_once PMCPC_PLUGIN_DIR . 'includes/services/class-pmcpc-logger.php';
require_once PMCPC_PLUGIN_DIR . 'includes/campaign/class-pmcpc-campaign-repository.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-plugin.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-compat.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-preferences-center.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-revenue-attribution.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-subscriber-updates-bootstrap.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-subscriber-updates-settings.php';
require_once PMCPC_PLUGIN_DIR . 'includes/subscriber-updates/functions-pmcpc-subscriber-updates-analytics.php';

// Optional modules (kept separate from core to avoid "patch pile" bootstrap files).
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-modules.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-subscribe-popup.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-email-login-customizer.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-smtp.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-user-subscriber-sync.php';
require_once PMCPC_PLUGIN_DIR . 'includes/class-pmcpc-users-list-integration.php';

// Register custom cron intervals on every request, including wp-cron runs.
// WordPress needs these intervals available before it can reschedule existing
// recurring events such as the abandoned-cart sweep.
add_filter( 'cron_schedules', array( 'PMCPC_Activator', 'add_cron_schedules' ), 1 );

// Hooks.
register_activation_hook( __FILE__, array( 'PMCPC_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'PMCPC_Deactivator', 'deactivate' ) );

// Ensure schema upgrades run even when plugin files are replaced during an update
// (activation hooks do not fire in that case).
add_action( 'plugins_loaded', array( 'PMCPC_Activator', 'maybe_upgrade' ), 5 );
PMCPC_Subscriber_Updates_Bootstrap::register_hooks();
add_action( 'woocommerce_checkout_order_processed', 'pmcpc_capture_order_email_click_attribution', 25 );

/**
 * Backward-compatible wrapper for subscriber update content registration.
 *
 * @return void
 */
function pmcpc_register_subscriber_updates_content() {
    PMCPC_Subscriber_Updates_Bootstrap::register_content();
}

/**
 * Backward-compatible wrapper for subscriber update cache flushing.
 *
 * @param int $post_id Post ID.
 * @return void
 */
function pmcpc_flush_subscriber_updates_cache( $post_id ) {
    PMCPC_Subscriber_Updates_Bootstrap::flush_cache( $post_id );
}

/**
 * Render Publishing Analytics page.
 *
 * @return void
 */


/**
 * Get Website Publishing settings with defaults applied.
 *
 * @return array
 */
function pmcpc_get_subscriber_updates_settings() {
    $settings = get_option( 'pmcpc_sub_updates_settings', array() );
    if ( ! is_array( $settings ) ) {
        $settings = array();
    }

    $settings = wp_parse_args(
        $settings,
        array(
            'enabled'                        => 1,
            'auto_create_page'               => 1,
            'page_id'                        => absint( get_option( 'pmcpc_sub_updates_page_id', 0 ) ),
            'post_status'                    => 'publish',
            'posts_per_page'                 => 10,
            'hide_expired_in_feed'           => 0,
            'show_date'                      => 1,
            'show_topic_filter'              => 1,
            'show_related'                   => 1,
            'default_image_url'              => '',
            'intro_text'                     => '',
            'log_limit'                      => 100,
            'commerce_auto_enabled'          => 0,
            'commerce_new_product_enabled'   => 0,
            'commerce_mode'                  => 'latest',
            'commerce_limit'                 => 4,
            'commerce_title_prefix'          => '',
            'commerce_topic'                 => __( 'New arrivals', 'product-mailer-campaigns' ),
            'commerce_cta_label'             => __( 'Shop now', 'product-mailer-campaigns' ),
            'daily_publish_hour'             => 9,
            'daily_publish_minute'           => 0,
            'daily_publish_days'             => array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' ),
            'auto_expiry_days'               => 0,
            'only_in_stock'                  => 1,
            'require_product_image'          => 1,
            'exclude_categories'             => '',
            'max_product_age_days'           => 120,
            'avoid_repeat_product_days'      => 30,
            'preview_limit'                  => 4,
            'feed_order'                     => 'featured_desc',
            'feed_columns'                   => 2,
            'feed_image_ratio'               => 'landscape',
            'feed_excerpt_length'            => 28,
            'show_images'                    => 1,
        )
    );

    if ( class_exists( 'PMCPC_Subscriber_Updates_Settings' ) ) {
        $normalized = PMCPC_Subscriber_Updates_Settings::normalize_settings( $settings );
        if ( $normalized !== $settings ) {
            PMCPC_Subscriber_Updates_Settings::save_settings( $normalized );
            $settings = $normalized;
        }
    }

    return $settings;
}


function pmcpc_render_subscriber_updates_analytics_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $days = isset( $_GET['range'] ) ? absint( wp_unslash( $_GET['range'] ) ) : 30; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if ( ! in_array( $days, array( 7, 30, 90 ), true ) ) {
        $days = 30;
    }

    $summary   = pmcpc_get_subscriber_updates_analytics_summary( $days );
    $totals    = $summary['totals'];
    $chart_max = 0;
    foreach ( $summary['days'] as $day_metrics ) {
        $chart_max = max( $chart_max, (int) $day_metrics['views'], (int) $day_metrics['clicks'], (int) $day_metrics['unlocks'] );
    }
    if ( $chart_max < 1 ) {
        $chart_max = 1;
    }

    echo '<div class="wrap">';
    PMCPC_Admin::render_app_header( __( 'Content Performance', 'product-mailer-campaigns' ) );
    PMCPC_Admin::render_page_intro(
        __( 'Measure subscriber update engagement', 'product-mailer-campaigns' ),
        __( 'See which updates are getting views, unlocks, and clicks so you know what content is working.', 'product-mailer-campaigns' ),
        array(
            array(
                'label' => sprintf( __( 'Current range: %d days', 'product-mailer-campaigns' ), (int) $days ),
                'icon'  => 'dashicons-calendar-alt',
            ),
            array(
                'label' => __( 'Content-only trends', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-chart-line',
            ),
            array(
                'label' => __( 'Top updates and segments', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-analytics',
            ),
        )
    );
    PMCPC_Admin::render_support_panels(
        array(
            array(
                'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                'icon'    => 'dashicons-editor-help',
                'title'   => __( 'Use this screen for content performance only', 'product-mailer-campaigns' ),
                'items'   => array(
                    __( 'Review the trend first.', 'product-mailer-campaigns' ),
                    __( 'Open the top updates list to see what content is working.', 'product-mailer-campaigns' ),
                    __( 'Use Email Results for campaign performance and revenue instead.', 'product-mailer-campaigns' ),
                ),
            ),
        )
    );
    echo '<div class="notice notice-info"><p>' . sprintf( wp_kses_post( __( 'Campaign-level website engagement and attributed revenue now also appear in <a href="%s">Email → Analytics</a>. Keep using this screen for content-only trends.', 'product-mailer-campaigns' ) ), esc_url( admin_url( 'admin.php?page=pmcpc_email&pmcpc_tab=analytics' ) ) ) . '</p></div>';

    echo '<div class="pmcpc-table-toolbar"><div class="pmcpc-table-toolbar__group">';
    foreach ( array( 7, 30, 90 ) as $range ) {
        $url = add_query_arg( array( 'page' => 'pmcpc-subscriber-analytics', 'range' => $range ), admin_url( 'admin.php' ) );
        $active = $range === $days ? 'display:inline-block;margin-right:8px;padding:8px 14px;border-radius:999px;background:#111827;color:#fff;text-decoration:none;' : 'display:inline-block;margin-right:8px;padding:8px 14px;border-radius:999px;background:#fff;border:1px solid #d1d5db;color:#111827;text-decoration:none;';
        echo '<a href="' . esc_url( $url ) . '" style="' . esc_attr( $active ) . '">' . sprintf( esc_html__( 'Last %d days', 'product-mailer-campaigns' ), (int) $range ) . '</a>';
    }
    echo '</div><div class="pmcpc-table-toolbar__meta"><span>' . esc_html__( 'Use this view for content performance only.', 'product-mailer-campaigns' ) . '</span></div></div>';

    PMCPC_Admin::render_stats_strip(
        array(
            array(
                'label' => __( 'Views', 'product-mailer-campaigns' ),
                'value' => (string) (int) $totals['views'],
                'meta'  => __( 'All update visits in range', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Subscriber Views', 'product-mailer-campaigns' ),
                'value' => (string) (int) $totals['subscriber_views'],
                'meta'  => __( 'Known subscriber visits', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Unlock Rate', 'product-mailer-campaigns' ),
                'value' => $summary['unlock_rate'] . '%',
                'meta'  => __( 'Unlocks from gated content', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Click-through rate', 'product-mailer-campaigns' ),
                'value' => $summary['conversion_rate'] . '%',
                'meta'  => __( 'Button and product clicks across updates', 'product-mailer-campaigns' ),
            ),
        )
    );

    echo '<div style="background:#fff;border:1px solid #e5e7eb;border-radius:20px;padding:20px 22px;margin:0 0 24px;">';
    echo '<h2 style="margin:0 0 18px;">' . esc_html__( 'Activity trend', 'product-mailer-campaigns' ) . '</h2>';
    if ( empty( $summary['days'] ) ) {
        echo '<p style="margin:0;color:#6b7280;">' . esc_html__( 'No analytics have been collected yet for this period.', 'product-mailer-campaigns' ) . '</p>';
    } else {
        echo '<div style="display:flex;align-items:flex-end;gap:10px;overflow-x:auto;padding-bottom:8px;">';
        foreach ( $summary['days'] as $day_key => $day_metrics ) {
            $views_height  = max( 8, (int) round( ( (int) $day_metrics['views'] / $chart_max ) * 120 ) );
            $click_height  = max( 4, (int) round( ( (int) $day_metrics['clicks'] / $chart_max ) * 120 ) );
            $unlock_height = max( 4, (int) round( ( (int) $day_metrics['unlocks'] / $chart_max ) * 120 ) );
            echo '<div style="min-width:56px;text-align:center;">';
            echo '<div style="height:132px;display:flex;align-items:flex-end;justify-content:center;gap:4px;margin-bottom:8px;">';
            echo '<span title="' . esc_attr__( 'Views', 'product-mailer-campaigns' ) . ': ' . esc_attr( (string) $day_metrics['views'] ) . '" style="display:inline-block;width:12px;height:' . esc_attr( (string) $views_height ) . 'px;background:#111827;border-radius:8px 8px 0 0;"></span>';
            echo '<span title="' . esc_attr__( 'Clicks', 'product-mailer-campaigns' ) . ': ' . esc_attr( (string) $day_metrics['clicks'] ) . '" style="display:inline-block;width:12px;height:' . esc_attr( (string) $click_height ) . 'px;background:#b45309;border-radius:8px 8px 0 0;"></span>';
            echo '<span title="' . esc_attr__( 'Unlocks', 'product-mailer-campaigns' ) . ': ' . esc_attr( (string) $day_metrics['unlocks'] ) . '" style="display:inline-block;width:12px;height:' . esc_attr( (string) $unlock_height ) . 'px;background:#2563eb;border-radius:8px 8px 0 0;"></span>';
            echo '</div>';
            echo '<div style="font-size:11px;color:#6b7280;">' . esc_html( date_i18n( 'j M', strtotime( $day_key ) ) ) . '</div>';
            echo '</div>';
        }
        echo '</div>';
        echo '<p style="margin:12px 0 0;color:#6b7280;font-size:12px;">' . esc_html__( 'Dark = views, amber = clicks, blue = unlocks.', 'product-mailer-campaigns' ) . '</p>';
    }
    echo '</div>';

    echo '<div style="display:grid;grid-template-columns:minmax(0,2fr) minmax(280px,1fr);gap:24px;align-items:start;">';
    echo '<div style="background:#fff;border:1px solid #e5e7eb;border-radius:20px;padding:20px 22px;">';
    echo '<h2 style="margin:0 0 14px;">' . esc_html__( 'Top updates', 'product-mailer-campaigns' ) . '</h2>';
    if ( empty( $summary['top_posts'] ) ) {
        echo '<p style="margin:0;color:#6b7280;">' . esc_html__( 'No update-level activity yet.', 'product-mailer-campaigns' ) . '</p>';
    } else {
        echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
        echo '<table class="widefat striped pmcpc-wide-table"><thead><tr><th class="pmcpc-col-anchor">' . esc_html__( 'Update', 'product-mailer-campaigns' ) . '</th><th class="pmcpc-col-metric">' . esc_html__( 'Views', 'product-mailer-campaigns' ) . '</th><th class="pmcpc-col-metric">' . esc_html__( 'Unlocks', 'product-mailer-campaigns' ) . '</th><th class="pmcpc-col-metric">' . esc_html__( 'Clicks', 'product-mailer-campaigns' ) . '</th></tr></thead><tbody>';
        $count = 0;
        foreach ( $summary['top_posts'] as $post_id => $post_metrics ) {
            $edit_link = get_edit_post_link( (int) $post_id );
            echo '<tr>';
            echo '<td class="pmcpc-col-anchor"><span class="pmcpc-table-record">';
            if ( $edit_link ) {
                echo '<span class="pmcpc-table-record__title"><a href="' . esc_url( $edit_link ) . '">' . esc_html( $post_metrics['title'] ) . '</a></span>';
            } else {
                echo '<span class="pmcpc-table-record__title">' . esc_html( $post_metrics['title'] ) . '</span>';
            }
            echo '<span class="pmcpc-table-record__meta">' . esc_html__( 'Subscriber update', 'product-mailer-campaigns' ) . '</span></span></td>';
            echo '<td class="pmcpc-col-metric">' . esc_html( (string) (int) $post_metrics['views'] ) . '</td>';
            echo '<td class="pmcpc-col-metric">' . esc_html( (string) (int) $post_metrics['unlocks'] ) . '</td>';
            echo '<td class="pmcpc-col-metric">' . esc_html( (string) (int) $post_metrics['clicks'] ) . '</td>';
            echo '</tr>';
            $count++;
            if ( $count >= 10 ) {
                break;
            }
        }
        echo '</tbody></table></div></div>';
    }
    echo '</div>';

    echo '<div style="display:grid;gap:24px;">';
    echo '<div style="background:#fff;border:1px solid #e5e7eb;border-radius:20px;padding:20px 22px;">';
    echo '<h2 style="margin:0 0 14px;">' . esc_html__( 'Top segments', 'product-mailer-campaigns' ) . '</h2>';
    if ( empty( $summary['top_segments'] ) ) {
        echo '<p style="margin:0;color:#6b7280;">' . esc_html__( 'No segment-specific activity yet.', 'product-mailer-campaigns' ) . '</p>';
    } else {
        echo '<ul style="margin:0;padding-left:18px;">';
        $count = 0;
        foreach ( $summary['top_segments'] as $segment => $segment_metrics ) {
            echo '<li style="margin:0 0 10px;"><strong>' . esc_html( $segment ) . '</strong> — ' . sprintf( esc_html__( '%1$d subscriber views, %2$d unlocks', 'product-mailer-campaigns' ), (int) $segment_metrics['subscriber_views'], (int) $segment_metrics['unlocks'] ) . '</li>';
            $count++;
            if ( $count >= 8 ) {
                break;
            }
        }
        echo '</ul>';
    }
    echo '</div>';

    echo '<div style="background:#fff;border:1px solid #e5e7eb;border-radius:20px;padding:20px 22px;">';
    echo '<h2 style="margin:0 0 14px;">' . esc_html__( 'Top campaigns', 'product-mailer-campaigns' ) . '</h2>';
    if ( empty( $summary['top_campaigns'] ) ) {
        echo '<p style="margin:0;color:#6b7280;">' . esc_html__( 'No campaign-level activity yet.', 'product-mailer-campaigns' ) . '</p>';
    } else {
        echo '<ul style="margin:0;padding-left:18px;">';
        $count = 0;
        foreach ( $summary['top_campaigns'] as $campaign_id => $campaign_metrics ) {
            $name = ! empty( $campaign_metrics['name'] ) ? $campaign_metrics['name'] : sprintf( __( 'Campaign #%d', 'product-mailer-campaigns' ), (int) $campaign_id );
            echo '<li style="margin:0 0 10px;"><strong>' . esc_html( $name ) . '</strong> — ' . sprintf( esc_html__( '%1$d views, %2$d clicks', 'product-mailer-campaigns' ), (int) $campaign_metrics['views'], (int) $campaign_metrics['clicks'] ) . '</li>';
            $count++;
            if ( $count >= 8 ) {
                break;
            }
        }
        echo '</ul>';
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
}

/**
 * Save Subscriber Updates settings.
 *
 * @return void
 */
function pmcpc_handle_subscriber_updates_settings_save() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( ! isset( $_POST['pmcpc_sub_updates_settings_nonce'] ) ) {
        return;
    }

    $nonce = sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_sub_updates_settings_nonce'] ) );
    if ( ! wp_verify_nonce( $nonce, 'pmcpc_save_subscriber_updates_settings' ) ) {
        return;
    }

    $requested_page_id = isset( $_POST['page_id'] ) ? absint( wp_unslash( $_POST['page_id'] ) ) : 0;
    $posts_page_used   = class_exists( 'PMCPC_Subscriber_Updates_Settings' ) && PMCPC_Subscriber_Updates_Settings::is_posts_page( $requested_page_id );
    $settings          = PMCPC_Subscriber_Updates_Settings::sanitize_settings_input( $_POST );

    if ( ! isset( $_POST['pmcpc_preview_rules'] ) ) {
        PMCPC_Subscriber_Updates_Settings::save_settings( $settings );

        if ( function_exists( 'pmcpc_sync_daily_commerce_update_schedule' ) ) {
            pmcpc_sync_daily_commerce_update_schedule();
        }

        pmcpc_flush_subscriber_updates_cache( 0 );

        add_settings_error( 'pmcpc_sub_updates_settings', 'pmcpc_sub_updates_saved', __( 'Website publishing settings saved.', 'product-mailer-campaigns' ), 'updated' );
        if ( $posts_page_used ) {
            add_settings_error(
                'pmcpc_sub_updates_settings',
                'pmcpc_sub_updates_posts_page_replaced',
                __( 'FlowPress moved Subscriber Updates off the WordPress Posts page and onto a dedicated Subscriber Updates page so the full feed can render correctly.', 'product-mailer-campaigns' ),
                'warning'
            );
        }
    }

    if ( isset( $_POST['pmcpc_repair_schedule'] ) ) {
        if ( function_exists( 'pmcpc_sync_daily_commerce_update_schedule' ) ) {
            pmcpc_sync_daily_commerce_update_schedule();
        }
        add_settings_error( 'pmcpc_sub_updates_settings', 'pmcpc_sub_updates_schedule_repaired', __( 'Daily publishing schedule checked and resynced.', 'product-mailer-campaigns' ), 'updated' );
    }

    if ( isset( $_POST['pmcpc_run_daily_now'] ) ) {
        $before = pmcpc_get_latest_subscriber_update_timestamp_by_source( 'commerce_automation' );
        pmcpc_publish_daily_commerce_update();
        $after  = pmcpc_get_latest_subscriber_update_timestamp_by_source( 'commerce_automation' );

        if ( $after > $before ) {
            add_settings_error( 'pmcpc_sub_updates_settings', 'pmcpc_sub_updates_run_now_success', __( 'A daily highlights update was created. Check Publishing Log to review it.', 'product-mailer-campaigns' ), 'updated' );
        } else {
            add_settings_error( 'pmcpc_sub_updates_settings', 'pmcpc_sub_updates_run_now_no_post', __( 'No daily highlights update was created. Check the preview, product rules, and Health Check to see why nothing qualified.', 'product-mailer-campaigns' ), 'warning' );
        }
    }

    if ( isset( $_POST['pmcpc_run_cron_test'] ) ) {
        $cron_test = pmcpc_run_daily_commerce_cron_test( $settings );
        add_settings_error(
            'pmcpc_sub_updates_settings',
            ! empty( $cron_test['ok'] ) ? 'pmcpc_sub_updates_cron_test_ok' : 'pmcpc_sub_updates_cron_test_fail',
            isset( $cron_test['message'] ) ? (string) $cron_test['message'] : __( 'Cron test finished.', 'product-mailer-campaigns' ),
            ! empty( $cron_test['ok'] ) ? 'updated' : 'warning'
        );
    }

    if ( isset( $_POST['pmcpc_run_due_cron_now'] ) ) {
        $run_due = pmcpc_force_due_daily_commerce_event( $settings );
        add_settings_error(
            'pmcpc_sub_updates_settings',
            ! empty( $run_due['ok'] ) ? 'pmcpc_sub_updates_run_due_ok' : 'pmcpc_sub_updates_run_due_fail',
            isset( $run_due['message'] ) ? (string) $run_due['message'] : __( 'Run due cron finished.', 'product-mailer-campaigns' ),
            ! empty( $run_due['ok'] ) ? 'updated' : 'warning'
        );
    }
}
add_action( 'admin_init', 'pmcpc_handle_subscriber_updates_settings_save' );

/**
 * Render Website Publishing settings page.
 *
 * @return void
 */
function pmcpc_render_subscriber_updates_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $settings            = pmcpc_get_subscriber_updates_settings();
    $preview_settings    = $settings;
    $preview_requested   = false;
    $preview_generated_at = '';

    if ( 'POST' === strtoupper( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['pmcpc_preview_rules'] ) && isset( $_POST['pmcpc_sub_updates_settings_nonce'] ) ) {
        $nonce = sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_sub_updates_settings_nonce'] ) );
        if ( wp_verify_nonce( $nonce, 'pmcpc_save_subscriber_updates_settings' ) ) {
            $preview_requested    = true;
            $preview_generated_at = current_time( 'mysql' );
            $preview_settings     = PMCPC_Subscriber_Updates_Settings::sanitize_settings_input( $_POST );
            $preview_settings     = wp_parse_args( $preview_settings, $settings );

            add_settings_error(
                'pmcpc_sub_updates_settings',
                'pmcpc_sub_updates_preview_generated',
                __( 'Preview generated from the current form values below. Nothing has been saved yet.', 'product-mailer-campaigns' ),
                'updated'
            );
        }
    }
    $preview_data = pmcpc_get_subscriber_update_preview_data( $preview_settings );
    $settings     = $preview_settings;

    settings_errors( 'pmcpc_sub_updates_settings' );

    $context = PMCPC_Subscriber_Updates_Settings::get_settings_page_context( $settings );
    $pages   = $context['pages'];

    echo '<div class="wrap">';
    PMCPC_Admin::render_app_header( __( 'Publishing Settings', 'product-mailer-campaigns' ) );
    PMCPC_Admin::render_page_intro(
        __( 'Control how subscriber updates are published', 'product-mailer-campaigns' ),
        __( 'Manage how Subscriber Updates are published, styled, and refreshed from WooCommerce while keeping the existing publishing workflows intact.', 'product-mailer-campaigns' ),
        array(
            array(
                'label' => __( 'Website publishing controls', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-admin-site-alt3',
            ),
            array(
                'label' => __( 'WooCommerce update sources', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-products',
            ),
            array(
                'label' => __( 'Feed and log settings', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-admin-tools',
            ),
        )
    );
    PMCPC_Admin::render_support_panels(
        array(
            array(
                'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                'icon'    => 'dashicons-editor-help',
                'title'   => __( 'Choose one publishing path and test it', 'product-mailer-campaigns' ),
                'items'   => array(
                    __( 'Set the updates page first.', 'product-mailer-campaigns' ),
                    __( 'Turn on daily highlights or new arrivals only if you want automatic posts.', 'product-mailer-campaigns' ),
                    __( 'Check Publishing Log after saving to confirm activity.', 'product-mailer-campaigns' ),
                ),
            ),
            array(
                'eyebrow' => __( 'Next steps', 'product-mailer-campaigns' ),
                'icon'    => 'dashicons-arrow-right-alt2',
                'title'   => __( 'Useful shortcuts', 'product-mailer-campaigns' ),
                'actions' => array(
                    array( 'label' => __( 'Open Publishing Log', 'product-mailer-campaigns' ), 'url' => admin_url( 'admin.php?page=pmcpc-publishing-log' ), 'class' => 'button' ),
                    array( 'label' => __( 'Create Update', 'product-mailer-campaigns' ), 'url' => admin_url( 'post-new.php?post_type=pmcpc_sub_update' ), 'class' => 'button button-primary' ),
                ),
            ),
        )
    );
    PMCPC_Admin::render_stats_strip(
        array(
            array(
                'label' => __( 'Website publishing', 'product-mailer-campaigns' ),
                'value' => ! empty( $settings['enabled'] ) ? __( 'Enabled', 'product-mailer-campaigns' ) : __( 'Disabled', 'product-mailer-campaigns' ),
                'meta'  => __( 'Campaigns can publish to the updates feed', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Updates page', 'product-mailer-campaigns' ),
                'value' => ! empty( $context['selected_page'] ) ? get_the_title( $context['selected_page'] ) : __( 'Auto-detect', 'product-mailer-campaigns' ),
                'meta'  => __( 'Current feed destination', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Daily highlights', 'product-mailer-campaigns' ),
                'value' => ! empty( $settings['commerce_auto_enabled'] ) ? __( 'On', 'product-mailer-campaigns' ) : __( 'Off', 'product-mailer-campaigns' ),
                'meta'  => __( 'One curated WooCommerce update per day', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'New arrivals', 'product-mailer-campaigns' ),
                'value' => ! empty( $settings['commerce_new_product_enabled'] ) ? __( 'On', 'product-mailer-campaigns' ) : __( 'Off', 'product-mailer-campaigns' ),
                'meta'  => __( 'Publish an update for newly published products', 'product-mailer-campaigns' ),
            ),
        )
    );

    pmcpc_render_subscriber_updates_health_notice( $settings, false );
    echo '<div class="pmcpc-card" style="margin:0 0 20px;max-width:920px;background:#f8fbff;border-color:#dbe4ff;"><strong>' . esc_html__( 'Recommended setup for discovery updates', 'product-mailer-campaigns' ) . '</strong><br>' . esc_html__( 'Use New product arrivals for one post per newly published item, or Daily shop highlights for one curated roundup per day.', 'product-mailer-campaigns' ) . '</div>';

    echo '<div class="pmcpc-card"><form method="post">';
    wp_nonce_field( 'pmcpc_save_subscriber_updates_settings', 'pmcpc_sub_updates_settings_nonce' );
    echo '<table class="form-table" role="presentation"><tbody>';
    echo '<tr><th scope="row">' . esc_html__( 'Enable website publishing', 'product-mailer-campaigns' ) . '</th><td><label><input type="checkbox" name="enabled" value="1" ' . checked( 1, (int) $settings['enabled'], false ) . '> ' . esc_html__( 'Allow campaigns to publish to Subscriber Updates.', 'product-mailer-campaigns' ) . '</label></td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Updates page', 'product-mailer-campaigns' ) . '</th><td><select name="page_id"><option value="0">' . esc_html__( 'Auto-create or detect page', 'product-mailer-campaigns' ) . '</option>';
    foreach ( $pages as $page ) {
        echo '<option value="' . esc_attr( (string) $page->ID ) . '"' . selected( (int) $settings['page_id'], (int) $page->ID, false ) . '>' . esc_html( $page->post_title ) . '</option>';
    }
    echo '</select><p class="description">' . esc_html__( 'Choose a normal page that contains the Subscriber Updates shortcode, or leave this on auto-create. FlowPress will avoid using the special WordPress Posts page here because blog archive templates can hide part of the updates feed.', 'product-mailer-campaigns' ) . '</p></td></tr>';
    if ( ! empty( $context['selected_page'] ) ) {
        echo '<tr><th scope="row">' . esc_html__( 'Current page', 'product-mailer-campaigns' ) . '</th><td>';
        echo '<strong>' . esc_html( get_the_title( $context['selected_page'] ) ) . '</strong>';
        if ( ! empty( $context['view_url'] ) ) {
            echo ' <a href="' . esc_url( $context['view_url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'View', 'product-mailer-campaigns' ) . '</a>';
        }
        if ( ! empty( $context['edit_url'] ) ) {
            echo ' | <a href="' . esc_url( $context['edit_url'] ) . '">' . esc_html__( 'Edit page', 'product-mailer-campaigns' ) . '</a>';
        }
        echo '<p class="description">' . esc_html__( 'This is the page currently selected for the Subscriber Updates feed.', 'product-mailer-campaigns' ) . '</p>';
        echo '</td></tr>';
    }
    echo '<tr><th scope="row">' . esc_html__( 'Feed shortcode', 'product-mailer-campaigns' ) . '</th><td>';
    echo '<code>[pmcpc_sub_updates]</code>';
    echo '<p class="description">' . esc_html__( 'Use only this shortcode once on the selected Updates page. Do not add the legacy alias or a second feed shortcode to the same page.', 'product-mailer-campaigns' ) . '</p>';
    echo '</td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Auto-create page', 'product-mailer-campaigns' ) . '</th><td><label><input type="checkbox" name="auto_create_page" value="1" ' . checked( 1, (int) $settings['auto_create_page'], false ) . '> ' . esc_html__( 'Create the Subscriber Updates page automatically if needed.', 'product-mailer-campaigns' ) . '</label></td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Default post status', 'product-mailer-campaigns' ) . '</th><td><select name="post_status">';
    echo '<option value="publish"' . selected( 'publish', (string) $settings['post_status'], false ) . '>' . esc_html__( 'Publish', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="draft"' . selected( 'draft', (string) $settings['post_status'], false ) . '>' . esc_html__( 'Draft', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="private"' . selected( 'private', (string) $settings['post_status'], false ) . '>' . esc_html__( 'Private', 'product-mailer-campaigns' ) . '</option>';
    echo '</select></td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Posts per page', 'product-mailer-campaigns' ) . '</th><td><input type="number" min="1" max="50" name="posts_per_page" value="' . esc_attr( (string) $settings['posts_per_page'] ) . '"> </td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Feed display', 'product-mailer-campaigns' ) . '</th><td>';
    echo '<label style="display:block;margin-bottom:8px;"><input type="checkbox" name="hide_expired_in_feed" value="1" ' . checked( 1, (int) $settings['hide_expired_in_feed'], false ) . '> ' . esc_html__( 'Hide expired updates from the public feed', 'product-mailer-campaigns' ) . '</label>';
    echo '<label style="display:block;margin-bottom:8px;"><input type="checkbox" name="show_date" value="1" ' . checked( 1, (int) $settings['show_date'], false ) . '> ' . esc_html__( 'Show publish date in the feed', 'product-mailer-campaigns' ) . '</label>';
    echo '<label style="display:block;margin-bottom:8px;"><input type="checkbox" name="show_topic_filter" value="1" ' . checked( 1, (int) $settings['show_topic_filter'], false ) . '> ' . esc_html__( 'Show topic filter dropdown above the feed', 'product-mailer-campaigns' ) . '</label>';
    echo '<label style="display:block;margin-bottom:8px;"><input type="checkbox" name="show_images" value="1" ' . checked( 1, (int) $settings['show_images'], false ) . '> ' . esc_html__( 'Show images on feed cards', 'product-mailer-campaigns' ) . '</label>';
    echo '<label style="display:block;margin-top:8px;"><input type="checkbox" name="show_related" value="1" ' . checked( 1, (int) $settings['show_related'], false ) . '> ' . esc_html__( 'Show related updates on single update pages', 'product-mailer-campaigns' ) . '</label>';
    echo '<p style="margin:12px 0 8px;"><strong>' . esc_html__( 'Layout', 'product-mailer-campaigns' ) . '</strong></p>';
    echo '<p><select name="feed_order">';
    echo '<option value="featured_desc"' . selected( 'featured_desc', (string) $settings['feed_order'], false ) . '>' . esc_html__( 'Featured first, then newest', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="date_desc"' . selected( 'date_desc', (string) $settings['feed_order'], false ) . '>' . esc_html__( 'Newest first', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="date_asc"' . selected( 'date_asc', (string) $settings['feed_order'], false ) . '>' . esc_html__( 'Oldest first', 'product-mailer-campaigns' ) . '</option>';
    echo '</select> <span class="description">' . esc_html__( 'Feed order', 'product-mailer-campaigns' ) . '</span></p>';
    echo '<p><input type="number" min="1" max="3" name="feed_columns" value="' . esc_attr( (string) $settings['feed_columns'] ) . '" class="small-text"> <span class="description">' . esc_html__( 'Cards per row on desktop', 'product-mailer-campaigns' ) . '</span></p>';
    echo '<p><select name="feed_image_ratio">';
    echo '<option value="landscape"' . selected( 'landscape', (string) $settings['feed_image_ratio'], false ) . '>' . esc_html__( 'Landscape images', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="square"' . selected( 'square', (string) $settings['feed_image_ratio'], false ) . '>' . esc_html__( 'Square images', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="portrait"' . selected( 'portrait', (string) $settings['feed_image_ratio'], false ) . '>' . esc_html__( 'Portrait images', 'product-mailer-campaigns' ) . '</option>';
    echo '</select> <span class="description">' . esc_html__( 'Image shape', 'product-mailer-campaigns' ) . '</span></p>';
    echo '<p><input type="number" min="10" max="80" name="feed_excerpt_length" value="' . esc_attr( (string) $settings['feed_excerpt_length'] ) . '" class="small-text"> <span class="description">' . esc_html__( 'Excerpt words per card', 'product-mailer-campaigns' ) . '</span></p>';
    echo '<p class="description" style="margin-top:10px;">' . esc_html__( 'By default the public feed shows all published updates. Turn on expiry filtering only if you want old updates to disappear from /subscriber-updates/.', 'product-mailer-campaigns' ) . '</p>';
    echo '</td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Default image URL', 'product-mailer-campaigns' ) . '</th><td><input type="url" name="default_image_url" value="' . esc_attr( (string) $settings['default_image_url'] ) . '" style="width:100%;max-width:680px;"><p class="description">' . esc_html__( 'Optional fallback image used when a campaign does not provide its own image.', 'product-mailer-campaigns' ) . '</p></td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Intro text', 'product-mailer-campaigns' ) . '</th><td><textarea name="intro_text" rows="4" style="width:100%;max-width:680px;">' . esc_textarea( (string) $settings['intro_text'] ) . '</textarea><p class="description">' . esc_html__( 'Optional introductory copy shown above the Subscriber Updates feed.', 'product-mailer-campaigns' ) . '</p></td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Log retention', 'product-mailer-campaigns' ) . '</th><td><input type="number" min="20" max="500" name="log_limit" value="' . esc_attr( (string) $settings['log_limit'] ) . '"> <span class="description">' . esc_html__( 'Recent publish events to keep in the admin log.', 'product-mailer-campaigns' ) . '</span></td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Daily shop highlights', 'product-mailer-campaigns' ) . '</th><td><label><input type="checkbox" name="commerce_auto_enabled" value="1" ' . checked( 1, (int) $settings['commerce_auto_enabled'], false ) . '> ' . esc_html__( 'Automatically publish one curated Subscriber Update per day from WooCommerce.', 'product-mailer-campaigns' ) . '</label><p class="description">' . esc_html__( 'Best for a daily highlights post built from your latest or featured pieces.', 'product-mailer-campaigns' ) . '</p><p><input type="number" min="0" max="23" name="daily_publish_hour" value="' . esc_attr( (string) $settings['daily_publish_hour'] ) . '" class="small-text"> : <input type="number" min="0" max="59" name="daily_publish_minute" value="' . esc_attr( sprintf( '%02d', (int) $settings['daily_publish_minute'] ) ) . '" class="small-text"> <span class="description">' . esc_html__( 'Publish time (site timezone)', 'product-mailer-campaigns' ) . '</span></p><p>';
    $publish_days = is_array( $settings['daily_publish_days'] ) ? $settings['daily_publish_days'] : array();
    foreach ( array( 'mon' => __( 'Mon', 'product-mailer-campaigns' ), 'tue' => __( 'Tue', 'product-mailer-campaigns' ), 'wed' => __( 'Wed', 'product-mailer-campaigns' ), 'thu' => __( 'Thu', 'product-mailer-campaigns' ), 'fri' => __( 'Fri', 'product-mailer-campaigns' ), 'sat' => __( 'Sat', 'product-mailer-campaigns' ), 'sun' => __( 'Sun', 'product-mailer-campaigns' ) ) as $day_key => $day_label ) {
        echo '<label style="display:inline-block;margin:0 12px 8px 0;"><input type="checkbox" name="daily_publish_days[]" value="' . esc_attr( $day_key ) . '" ' . checked( in_array( $day_key, $publish_days, true ), true, false ) . '> ' . esc_html( $day_label ) . '</label>';
    }
    echo '</p></td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'New product arrivals', 'product-mailer-campaigns' ) . '</th><td><label><input type="checkbox" name="commerce_new_product_enabled" value="1" ' . checked( 1, (int) $settings['commerce_new_product_enabled'], false ) . '> ' . esc_html__( 'Automatically publish a Subscriber Update when a new WooCommerce product is first published.', 'product-mailer-campaigns' ) . '</label><p class="description">' . esc_html__( 'Creates one update per newly published product so your Posts page becomes a live new-arrivals feed.', 'product-mailer-campaigns' ) . '</p></td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Publishing rules', 'product-mailer-campaigns' ) . '</th><td>';
    echo '<label style="display:block;margin-bottom:8px;"><input type="checkbox" name="only_in_stock" value="1" ' . checked( 1, (int) $settings['only_in_stock'], false ) . '> ' . esc_html__( 'Only include products that are in stock', 'product-mailer-campaigns' ) . '</label>';
    echo '<label style="display:block;margin-bottom:8px;"><input type="checkbox" name="require_product_image" value="1" ' . checked( 1, (int) $settings['require_product_image'], false ) . '> ' . esc_html__( 'Only include products with a featured image', 'product-mailer-campaigns' ) . '</label>';
    echo '<p><input type="text" name="exclude_categories" value="' . esc_attr( (string) $settings['exclude_categories'] ) . '" class="regular-text" placeholder="clearance, sold, restoration"> <span class="description">' . esc_html__( 'Exclude product category slugs, comma separated', 'product-mailer-campaigns' ) . '</span></p>';
    echo '<p><input type="number" min="0" max="3650" name="max_product_age_days" value="' . esc_attr( (string) $settings['max_product_age_days'] ) . '" class="small-text"> <span class="description">' . esc_html__( 'Ignore products older than this many days in daily highlight mode (0 = no limit)', 'product-mailer-campaigns' ) . '</span></p>';
    echo '<p><input type="number" min="0" max="365" name="avoid_repeat_product_days" value="' . esc_attr( (string) $settings['avoid_repeat_product_days'] ) . '" class="small-text"> <span class="description">' . esc_html__( 'Avoid reusing products already featured in recent updates for this many days', 'product-mailer-campaigns' ) . '</span></p>';
    echo '<p><input type="number" min="1" max="12" name="preview_limit" value="' . esc_attr( (string) $settings['preview_limit'] ) . '" class="small-text"> <span class="description">' . esc_html__( 'How many products to show in the preview generator', 'product-mailer-campaigns' ) . '</span></p>';
    echo '</td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Product source', 'product-mailer-campaigns' ) . '</th><td><select name="commerce_mode">';
    echo '<option value="latest"' . selected( 'latest', (string) $settings['commerce_mode'], false ) . '>' . esc_html__( 'Latest products / new arrivals', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="featured"' . selected( 'featured', (string) $settings['commerce_mode'], false ) . '>' . esc_html__( 'Featured products', 'product-mailer-campaigns' ) . '</option>';
    echo '</select> <input type="number" min="1" max="12" name="commerce_limit" value="' . esc_attr( (string) $settings['commerce_limit'] ) . '" class="small-text"> <span class="description">' . esc_html__( 'Products per update', 'product-mailer-campaigns' ) . '</span></td></tr>';
    echo '<tr><th scope="row">' . esc_html__( 'Update wording', 'product-mailer-campaigns' ) . '</th><td><p><input type="text" name="commerce_title_prefix" value="' . esc_attr( (string) $settings['commerce_title_prefix'] ) . '" class="regular-text" placeholder="' . esc_attr__( 'New arrivals at your shop', 'product-mailer-campaigns' ) . '"> <span class="description">' . esc_html__( 'Headline', 'product-mailer-campaigns' ) . '</span></p><p><input type="text" name="commerce_topic" value="' . esc_attr( (string) $settings['commerce_topic'] ) . '" class="regular-text" placeholder="' . esc_attr__( 'New arrivals', 'product-mailer-campaigns' ) . '"> <span class="description">' . esc_html__( 'Topic badge', 'product-mailer-campaigns' ) . '</span></p><p><input type="text" name="commerce_cta_label" value="' . esc_attr( (string) $settings['commerce_cta_label'] ) . '" class="regular-text" placeholder="' . esc_attr__( 'Shop now', 'product-mailer-campaigns' ) . '"> <span class="description">' . esc_html__( 'CTA button', 'product-mailer-campaigns' ) . '</span></p><p><input type="number" min="0" max="365" name="auto_expiry_days" value="' . esc_attr( (string) $settings['auto_expiry_days'] ) . '" class="small-text"> <span class="description">' . esc_html__( 'Auto-expire generated updates after this many days (0 keeps them visible)', 'product-mailer-campaigns' ) . '</span></p></td></tr>';
    echo '</tbody></table>';
    echo '<p class="submit">';
    submit_button( __( 'Save Publishing Settings', 'product-mailer-campaigns' ), 'primary', 'submit', false );
    echo ' ';
    submit_button( __( 'Generate preview', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_preview_rules', false );
    echo ' ';
    submit_button( __( 'Repair schedule', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_repair_schedule', false );
    echo ' ';
    submit_button( __( 'Run daily now', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_run_daily_now', false );
    echo ' ';
    submit_button( __( 'Run cron test', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_run_cron_test', false );
    echo ' ';
    submit_button( __( 'Run due cron now', 'product-mailer-campaigns' ), 'secondary', 'pmcpc_run_due_cron_now', false );
    echo '</p>';
    echo '</form></div>';

    echo '<div id="pmcpc-preview-generator" class="pmcpc-card pmcpc-preview-generator-card"' . ( $preview_requested ? ' data-pmcpc-scroll-into-view="1"' : '' ) . '>';
    echo '<h2 style="margin-top:0;">' . esc_html__( 'Publishing Rules preview', 'product-mailer-campaigns' ) . '</h2>';
    echo '<p style="margin-top:0;color:#50575e;">' . esc_html__( 'Use this to see what FlowPress would publish from your current rules before you save or run the next daily update.', 'product-mailer-campaigns' ) . '</p>';
    $cron_diag = pmcpc_get_daily_commerce_cron_diagnostics();
    if ( ! empty( $cron_diag['messages'] ) ) {
        echo '<p style="margin:0 0 12px;padding:10px 12px;background:#f7f7f7;border:1px solid #dcdcde;border-radius:8px;color:#50575e;">' . esc_html( implode( ' ', $cron_diag['messages'] ) ) . '</p>';
    }
    if ( $preview_requested ) {
        echo '<p style="margin:0 0 12px;padding:10px 12px;background:#f0f6ff;border:1px solid #cfe0ff;border-radius:8px;"><strong>' . esc_html__( 'Preview generated', 'product-mailer-campaigns' ) . '</strong>';
        if ( '' !== $preview_generated_at ) {
            echo ' <span style="color:#50575e;">' . esc_html( sprintf( __( 'at %s', 'product-mailer-campaigns' ), wp_date( get_option( 'date_format', 'j F Y' ) . ' ' . get_option( 'time_format', 'H:i' ), strtotime( $preview_generated_at ) ) ) ) . '</span>';
        }
        echo '<br><span style="color:#50575e;">' . esc_html__( 'The preview below uses the values currently in the form, even if you have not saved them yet.', 'product-mailer-campaigns' ) . '</span></p>';
    }
    echo '<p><strong>' . esc_html__( 'Next scheduled daily run:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( $preview_data['next_run_local'] ? $preview_data['next_run_local'] : __( 'Not scheduled yet', 'product-mailer-campaigns' ) ) . '</p>';
    echo '<p><strong>' . esc_html__( 'Would today run?', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( ! empty( $preview_data['runs_today'] ) ? __( 'Yes', 'product-mailer-campaigns' ) : __( 'No, today is outside the selected publish days.', 'product-mailer-campaigns' ) ) . '</p>';
    echo '<p><strong>' . esc_html__( 'Rule summary:', 'product-mailer-campaigns' ) . '</strong> ' . esc_html( implode( ' · ', array_filter( array_map( 'trim', (array) $preview_data['rules_summary'] ) ) ) ) . '</p>';
    echo '<div class="pmcpc-preview-generator-grid">';
    echo '<div><h3 style="margin:0 0 10px;">' . esc_html__( 'Products that would be included', 'product-mailer-campaigns' ) . '</h3>';
    if ( empty( $preview_data['selection']['included'] ) ) {
        echo '<p>' . esc_html__( 'No products currently match the active rules.', 'product-mailer-campaigns' ) . '</p>';
    } else {
        echo '<ul style="margin:0;padding-left:18px;">';
        foreach ( $preview_data['selection']['included'] as $preview_product ) {
            echo '<li style="margin:0 0 8px;"><strong>' . esc_html( get_the_title( $preview_product->ID ) ) . '</strong> <span style="color:#50575e;">#' . esc_html( (string) $preview_product->ID ) . '</span></li>';
        }
        echo '</ul>';
    }
    echo '</div>';
    echo '<div><h3 style="margin:0 0 10px;">' . esc_html__( 'Excluded examples', 'product-mailer-campaigns' ) . '</h3>';
    if ( empty( $preview_data['selection']['excluded'] ) ) {
        echo '<p>' . esc_html__( 'No exclusions were detected in the current sample set.', 'product-mailer-campaigns' ) . '</p>';
    } else {
        echo '<ul style="margin:0;padding-left:18px;">';
        foreach ( array_slice( $preview_data['selection']['excluded'], 0, 6 ) as $excluded_product ) {
            echo '<li style="margin:0 0 8px;"><strong>' . esc_html( $excluded_product['title'] ) . '</strong>: ' . esc_html( $excluded_product['reason'] ) . '</li>';
        }
        echo '</ul>';
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
}


/**
 * Handle bulk actions from the Publishing Log update-management table.
 *
 * @return void
 */
function pmcpc_handle_subscriber_update_management_actions() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( 'POST' !== strtoupper( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
        return;
    }

    if ( empty( $_POST['pmcpc_update_management_action'] ) ) {
        return;
    }

    $nonce = isset( $_POST['pmcpc_manage_subscriber_updates_nonce'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['pmcpc_manage_subscriber_updates_nonce'] ) ) : '';
    if ( ! wp_verify_nonce( $nonce, 'pmcpc_manage_subscriber_updates' ) ) {
        add_settings_error( 'pmcpc_sub_updates_log', 'pmcpc_updates_bulk_nonce', __( 'Update action could not be verified. Please try again.', 'product-mailer-campaigns' ), 'error' );
        return;
    }

    $action = sanitize_key( (string) wp_unslash( $_POST['pmcpc_update_management_action'] ) );
    $ids    = isset( $_POST['pmcpc_update_ids'] ) ? (array) wp_unslash( $_POST['pmcpc_update_ids'] ) : array();
    $ids    = array_values( array_filter( array_map( 'absint', $ids ) ) );

    if ( empty( $ids ) ) {
        add_settings_error( 'pmcpc_sub_updates_log', 'pmcpc_updates_bulk_empty', __( 'Select at least one update first.', 'product-mailer-campaigns' ), 'warning' );
        return;
    }

    $allowed = array( 'publish', 'draft', 'private', 'trash', 'restore', 'delete' );
    if ( ! in_array( $action, $allowed, true ) ) {
        add_settings_error( 'pmcpc_sub_updates_log', 'pmcpc_updates_bulk_invalid', __( 'Choose a valid update action.', 'product-mailer-campaigns' ), 'error' );
        return;
    }

    $done = 0;
    foreach ( $ids as $post_id ) {
        if ( 'pmcpc_sub_update' !== get_post_type( $post_id ) ) {
            continue;
        }

        $result = false;
        if ( 'trash' === $action ) {
            $result = wp_trash_post( $post_id );
        } elseif ( 'restore' === $action ) {
            $result = wp_untrash_post( $post_id );
        } elseif ( 'delete' === $action ) {
            $result = wp_delete_post( $post_id, true );
        } else {
            $result = wp_update_post(
                array(
                    'ID'          => $post_id,
                    'post_status' => $action,
                ),
                true
            );
        }

        if ( ! is_wp_error( $result ) && $result ) {
            $done++;
        }
    }

    if ( class_exists( 'PMCPC_Subscriber_Updates_Bootstrap' ) ) {
        PMCPC_Subscriber_Updates_Bootstrap::flush_cache( 0 );
    }

    if ( $done > 0 ) {
        add_settings_error(
            'pmcpc_sub_updates_log',
            'pmcpc_updates_bulk_done',
            sprintf(
                /* translators: %d: number of update posts changed. */
                _n( '%d update was changed.', '%d updates were changed.', $done, 'product-mailer-campaigns' ),
                (int) $done
            ),
            'updated'
        );
    } else {
        add_settings_error( 'pmcpc_sub_updates_log', 'pmcpc_updates_bulk_none', __( 'No updates were changed.', 'product-mailer-campaigns' ), 'warning' );
    }
}

/**
 * Count Subscriber Update posts by admin-management status.
 *
 * @return array<string,int>
 */
function pmcpc_get_subscriber_update_admin_status_counts() {
    $counts = array(
        'all'     => 0,
        'publish' => 0,
        'draft'   => 0,
        'pending' => 0,
        'private' => 0,
        'future'  => 0,
        'trash'   => 0,
    );

    if ( ! post_type_exists( 'pmcpc_sub_update' ) ) {
        return $counts;
    }

    $wp_counts = wp_count_posts( 'pmcpc_sub_update' );
    if ( ! $wp_counts ) {
        return $counts;
    }

    foreach ( array( 'publish', 'draft', 'pending', 'private', 'future', 'trash' ) as $status ) {
        $counts[ $status ] = isset( $wp_counts->{$status} ) ? (int) $wp_counts->{$status} : 0;
    }

    $counts['all'] = $counts['publish'] + $counts['draft'] + $counts['pending'] + $counts['private'] + $counts['future'];

    return $counts;
}

/**
 * Read per-post Subscriber Update metrics from the lightweight analytics store.
 *
 * @param int $post_id Subscriber update ID.
 * @return array{views:int,clicks:int,unlocks:int}
 */
function pmcpc_get_subscriber_update_admin_metrics( $post_id ) {
    $post_id = absint( $post_id );
    $metrics = array(
        'views'   => 0,
        'clicks'  => 0,
        'unlocks' => 0,
    );

    if ( ! $post_id || ! function_exists( 'pmcpc_get_subscriber_updates_analytics_summary' ) ) {
        return $metrics;
    }

    static $summary = null;
    if ( null === $summary ) {
        $summary = pmcpc_get_subscriber_updates_analytics_summary( 365 );
    }
    if ( empty( $summary['top_posts'][ $post_id ] ) || ! is_array( $summary['top_posts'][ $post_id ] ) ) {
        $metrics['views']  = (int) get_post_meta( $post_id, '_pmcpc_view_count', true );
        $metrics['clicks'] = (int) get_post_meta( $post_id, '_pmcpc_product_click_count', true );
        return $metrics;
    }

    $post_metrics       = $summary['top_posts'][ $post_id ];
    $metrics['views']   = isset( $post_metrics['views'] ) ? (int) $post_metrics['views'] : 0;
    $metrics['clicks']  = isset( $post_metrics['clicks'] ) ? (int) $post_metrics['clicks'] : (int) get_post_meta( $post_id, '_pmcpc_product_click_count', true );
    $metrics['unlocks'] = isset( $post_metrics['unlocks'] ) ? (int) $post_metrics['unlocks'] : 0;

    return $metrics;
}

/**
 * Render the update-management area that replaces the old standalone Updates list.
 *
 * @return void
 */
function pmcpc_render_subscriber_updates_management_panel( $entries = array() ) {
    if ( ! post_type_exists( 'pmcpc_sub_update' ) ) {
        return;
    }

    $entries = is_array( $entries ) ? $entries : array();

    $events_by_post_id = array();
    $log_only_entries  = array();
    foreach ( $entries as $entry ) {
        if ( ! is_array( $entry ) ) {
            continue;
        }

        $details = isset( $entry['details'] ) ? (string) $entry['details'] : '';
        $post_id = 0;
        if ( preg_match( '/post #(\d+)/', $details, $matches ) ) {
            $post_id = absint( $matches[1] );
        }

        if ( $post_id > 0 && 'pmcpc_sub_update' === get_post_type( $post_id ) ) {
            $current_time = ! empty( $events_by_post_id[ $post_id ]['timestamp'] ) ? strtotime( (string) $events_by_post_id[ $post_id ]['timestamp'] ) : 0;
            $entry_time   = ! empty( $entry['timestamp'] ) ? strtotime( (string) $entry['timestamp'] ) : 0;
            if ( empty( $events_by_post_id[ $post_id ] ) || $entry_time >= $current_time ) {
                $events_by_post_id[ $post_id ] = $entry;
            }
            continue;
        }

        $log_only_entries[] = $entry;
    }

    $allowed_statuses = array( 'all', 'publish', 'draft', 'pending', 'private', 'future', 'trash' );
    $status           = isset( $_GET['pmcpc_update_status'] ) ? sanitize_key( (string) wp_unslash( $_GET['pmcpc_update_status'] ) ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if ( ! in_array( $status, $allowed_statuses, true ) ) {
        $status = 'all';
    }

    $search = isset( $_GET['pmcpc_update_search'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_update_search'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $topic  = isset( $_GET['pmcpc_update_topic'] ) ? absint( wp_unslash( $_GET['pmcpc_update_topic'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $month  = isset( $_GET['pmcpc_update_month'] ) ? sanitize_text_field( (string) wp_unslash( $_GET['pmcpc_update_month'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $month  = preg_match( '/^\d{4}-\d{2}$/', $month ) ? $month : '';
    $paged  = isset( $_GET['pmcpc_update_paged'] ) ? max( 1, absint( wp_unslash( $_GET['pmcpc_update_paged'] ) ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

    $post_status = array( 'publish', 'draft', 'pending', 'private', 'future' );
    if ( 'trash' === $status ) {
        $post_status = array( 'trash' );
    } elseif ( 'all' !== $status ) {
        $post_status = array( $status );
    }

    $query_args = array(
        'post_type'      => 'pmcpc_sub_update',
        'post_status'    => $post_status,
        'posts_per_page' => 25,
        'paged'          => $paged,
        'orderby'        => 'date',
        'order'          => 'DESC',
    );

    if ( '' !== $search ) {
        $query_args['s'] = $search;
    }

    if ( '' !== $month ) {
        $query_args['year']     = absint( substr( $month, 0, 4 ) );
        $query_args['monthnum'] = absint( substr( $month, 5, 2 ) );
    }

    if ( $topic > 0 ) {
        $query_args['tax_query'] = array(
            array(
                'taxonomy' => 'pmcpc_update_topic',
                'field'    => 'term_id',
                'terms'    => array( $topic ),
            ),
        );
    }

    $updates = new WP_Query( $query_args );
    $counts  = pmcpc_get_subscriber_update_admin_status_counts();
    $terms   = get_terms(
        array(
            'taxonomy'   => 'pmcpc_update_topic',
            'hide_empty' => false,
        )
    );
    $terms   = is_wp_error( $terms ) ? array() : $terms;

    global $wpdb;
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
    $month_rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT YEAR(post_date) AS year_num, MONTH(post_date) AS month_num FROM {$wpdb->posts} WHERE post_type = %s AND post_status NOT IN ('auto-draft','inherit') GROUP BY YEAR(post_date), MONTH(post_date) ORDER BY MAX(post_date) DESC LIMIT 36",
            'pmcpc_sub_update'
        )
    );
    $month_rows = is_array( $month_rows ) ? $month_rows : array();

    $status_labels = array(
        'all'     => __( 'All', 'product-mailer-campaigns' ),
        'publish' => __( 'Published', 'product-mailer-campaigns' ),
        'draft'   => __( 'Drafts', 'product-mailer-campaigns' ),
        'pending' => __( 'Pending', 'product-mailer-campaigns' ),
        'private' => __( 'Private', 'product-mailer-campaigns' ),
        'future'  => __( 'Scheduled', 'product-mailer-campaigns' ),
        'trash'   => __( 'Trash', 'product-mailer-campaigns' ),
    );

    $show_log_only_entries = ( 'all' === $status && '' === $search && 0 === $topic && '' === $month && 1 === $paged );
    $log_only_entries      = $show_log_only_entries ? array_slice( $log_only_entries, 0, 20 ) : array();
    $has_update_rows       = $updates->have_posts();
    $has_any_rows          = $has_update_rows || ! empty( $log_only_entries );

    echo '<div class="pmcpc-card pmcpc-update-manager">';
    echo '<div class="pmcpc-card__header" style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;">';
    echo '<div><p class="pmcpc-kicker" style="margin:0 0 6px;">' . esc_html__( 'Content', 'product-mailer-campaigns' ) . '</p>';
    echo '<h2 style="margin:0;">' . esc_html__( 'Publishing activity', 'product-mailer-campaigns' ) . '</h2>';
    echo '<p class="description" style="margin:8px 0 0;">' . esc_html__( 'Create and manage website updates while reviewing the latest publishing result in the same table.', 'product-mailer-campaigns' ) . '</p></div>';
    echo '<p style="margin:0;"><a class="button button-primary" href="' . esc_url( admin_url( 'post-new.php?post_type=pmcpc_sub_update' ) ) . '">' . esc_html__( 'Create update', 'product-mailer-campaigns' ) . '</a></p>';
    echo '</div>';

    echo '<div class="subsubsub pmcpc-update-status-tabs" style="margin:16px 0 12px;">';
    $status_links = array();
    foreach ( $status_labels as $key => $label ) {
        if ( 'all' !== $key && empty( $counts[ $key ] ) && $key !== $status ) {
            continue;
        }
        $url = add_query_arg(
            array(
                'page'                 => 'pmcpc-publishing-log',
                'pmcpc_update_status'  => $key,
                'pmcpc_update_search'  => '' !== $search ? $search : false,
                'pmcpc_update_topic'   => $topic ? $topic : false,
                'pmcpc_update_month'   => '' !== $month ? $month : false,
                'pmcpc_update_paged'   => false,
            ),
            admin_url( 'admin.php' )
        );
        $class = $status === $key ? ' class="current"' : '';
        $status_links[] = '<a' . $class . ' href="' . esc_url( $url ) . '">' . esc_html( $label ) . ' <span class="count">(' . esc_html( (string) ( $counts[ $key ] ?? 0 ) ) . ')</span></a>';
    }
    echo wp_kses_post( implode( ' | ', $status_links ) );
    echo '</div>';

    echo '<form method="get" class="pmcpc-table-toolbar pmcpc-update-filters" style="align-items:flex-end;">';
    echo '<input type="hidden" name="page" value="pmcpc-publishing-log">';
    echo '<input type="hidden" name="pmcpc_update_status" value="' . esc_attr( $status ) . '">';
    echo '<div class="pmcpc-table-toolbar__group">';
    echo '<label><span class="screen-reader-text">' . esc_html__( 'Search publishing activity', 'product-mailer-campaigns' ) . '</span><input type="search" name="pmcpc_update_search" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'Search updates...', 'product-mailer-campaigns' ) . '"></label>';
    echo '<label><span class="screen-reader-text">' . esc_html__( 'Filter by topic', 'product-mailer-campaigns' ) . '</span><select name="pmcpc_update_topic"><option value="0">' . esc_html__( 'All topics', 'product-mailer-campaigns' ) . '</option>';
    foreach ( $terms as $term ) {
        echo '<option value="' . esc_attr( (string) $term->term_id ) . '" ' . selected( $topic, (int) $term->term_id, false ) . '>' . esc_html( $term->name ) . '</option>';
    }
    echo '</select></label>';
    echo '<label><span class="screen-reader-text">' . esc_html__( 'Filter by date', 'product-mailer-campaigns' ) . '</span><select name="pmcpc_update_month"><option value="">' . esc_html__( 'All dates', 'product-mailer-campaigns' ) . '</option>';
    foreach ( $month_rows as $month_row ) {
        $month_value = sprintf( '%04d-%02d', (int) $month_row->year_num, (int) $month_row->month_num );
        $month_label = date_i18n( 'F Y', strtotime( $month_value . '-01' ) );
        echo '<option value="' . esc_attr( $month_value ) . '" ' . selected( $month, $month_value, false ) . '>' . esc_html( $month_label ) . '</option>';
    }
    echo '</select></label>';
    echo '<button type="submit" class="button">' . esc_html__( 'Filter', 'product-mailer-campaigns' ) . '</button>';
    if ( '' !== $search || $topic > 0 || '' !== $month || 'all' !== $status ) {
        echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc-publishing-log' ) ) . '">' . esc_html__( 'Reset', 'product-mailer-campaigns' ) . '</a>';
    }
    echo '</div><div class="pmcpc-table-toolbar__meta"><span>' . esc_html__( 'Titles open the editor. The latest result column replaces the old separate publishing-events table.', 'product-mailer-campaigns' ) . '</span></div></form>';

    if ( ! $has_any_rows ) {
        echo '<div class="pmcpc-empty-state"><p>' . esc_html__( 'No publishing activity matches the current filters.', 'product-mailer-campaigns' ) . '</p></div>';
        echo '</div>';
        wp_reset_postdata();
        return;
    }

    $current_url = add_query_arg(
        array(
            'page'                => 'pmcpc-publishing-log',
            'pmcpc_update_status' => $status,
            'pmcpc_update_search' => '' !== $search ? $search : false,
            'pmcpc_update_topic'  => $topic ? $topic : false,
            'pmcpc_update_month'  => '' !== $month ? $month : false,
            'pmcpc_update_paged'  => $paged > 1 ? $paged : false,
        ),
        admin_url( 'admin.php' )
    );

    echo '<form method="post" action="' . esc_url( $current_url ) . '" class="pmcpc-update-management-form">';
    wp_nonce_field( 'pmcpc_manage_subscriber_updates', 'pmcpc_manage_subscriber_updates_nonce' );
    echo '<div class="pmcpc-table-wrap"><div class="pmcpc-table-wrap__scroll">';
    echo '<table class="widefat striped pmcpc-wide-table" data-pmcpc-table="publishing-activity"><thead><tr>';
    echo '<th class="check-column"><input type="checkbox" class="pmcpc-check-all" aria-label="' . esc_attr__( 'Select all updates', 'product-mailer-campaigns' ) . '"></th>';
    echo '<th>' . esc_html__( 'Title', 'product-mailer-campaigns' ) . '</th>';
    echo '<th>' . esc_html__( 'Status', 'product-mailer-campaigns' ) . '</th>';
    echo '<th>' . esc_html__( 'Latest result', 'product-mailer-campaigns' ) . '</th>';
    echo '<th>' . esc_html__( 'Date', 'product-mailer-campaigns' ) . '</th>';
    echo '<th>' . esc_html__( 'Source', 'product-mailer-campaigns' ) . '</th>';
    echo '<th>' . esc_html__( 'Details', 'product-mailer-campaigns' ) . '</th>';
    echo '<th>' . esc_html__( 'Topics', 'product-mailer-campaigns' ) . '</th>';
    echo '<th>' . esc_html__( 'Views', 'product-mailer-campaigns' ) . '</th>';
    echo '<th>' . esc_html__( 'Clicks', 'product-mailer-campaigns' ) . '</th>';
    echo '</tr></thead><tbody>';

    if ( $has_update_rows ) {
        while ( $updates->have_posts() ) {
            $updates->the_post();
            $post_id   = get_the_ID();
            $edit_link = get_edit_post_link( $post_id, '' );
            $view_link = 'publish' === get_post_status( $post_id ) ? get_permalink( $post_id ) : '';
            $topics    = get_the_terms( $post_id, 'pmcpc_update_topic' );
            $topic_names = array();
            if ( ! is_wp_error( $topics ) && ! empty( $topics ) ) {
                foreach ( $topics as $term ) {
                    $topic_names[] = $term->name;
                }
            }
            $campaign_id = absint( get_post_meta( $post_id, '_pmcpc_campaign_id', true ) );
            $source      = $campaign_id ? sprintf( __( 'Campaign #%d', 'product-mailer-campaigns' ), $campaign_id ) : (string) get_post_meta( $post_id, '_pmcpc_update_source', true );
            if ( '' === $source ) {
                $source = __( 'Manual / feed', 'product-mailer-campaigns' );
            }
            $metrics      = pmcpc_get_subscriber_update_admin_metrics( $post_id );
            $status_label = get_post_status_object( get_post_status( $post_id ) );
            $event        = isset( $events_by_post_id[ $post_id ] ) && is_array( $events_by_post_id[ $post_id ] ) ? $events_by_post_id[ $post_id ] : array();
            $event_result = ! empty( $event['result'] ) ? ucfirst( (string) $event['result'] ) : __( 'Available', 'product-mailer-campaigns' );
            $event_date   = ! empty( $event['timestamp'] ) ? (string) $event['timestamp'] : get_post_time( 'Y-m-d H:i:s', false, $post_id );
            $event_details = ! empty( $event['details'] ) ? (string) $event['details'] : sprintf( __( 'Subscriber update post #%d is available in the feed.', 'product-mailer-campaigns' ), (int) $post_id );

            echo '<tr>';
            echo '<th class="check-column"><input type="checkbox" name="pmcpc_update_ids[]" value="' . esc_attr( (string) $post_id ) . '" aria-label="' . esc_attr( get_the_title( $post_id ) ) . '"></th>';
            echo '<td class="pmcpc-col-anchor"><span class="pmcpc-table-record"><span class="pmcpc-table-record__title"><a href="' . esc_url( $edit_link ) . '">' . esc_html( get_the_title( $post_id ) ) . '</a></span><span class="pmcpc-table-record__meta">';
            echo esc_html( sprintf( __( 'ID %d', 'product-mailer-campaigns' ), (int) $post_id ) );
            if ( $view_link ) {
                echo ' · <a href="' . esc_url( $view_link ) . '" target="_blank" rel="noopener">' . esc_html__( 'View', 'product-mailer-campaigns' ) . '</a>';
            }
            echo '</span></span></td>';
            echo '<td><span class="pmcpc-status-pill pmcpc-status-' . esc_attr( get_post_status( $post_id ) ) . '">' . esc_html( $status_label ? $status_label->label : ucfirst( (string) get_post_status( $post_id ) ) ) . '</span></td>';
            echo '<td><span class="pmcpc-status-pill">' . esc_html( $event_result ) . '</span></td>';
            echo '<td>' . esc_html( $event_date ) . '</td>';
            echo '<td>' . esc_html( $source ) . '</td>';
            echo '<td class="pmcpc-col-meta"><span class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $event_details ) . '</span></span></td>';
            echo '<td>' . esc_html( ! empty( $topic_names ) ? implode( ', ', $topic_names ) : '—' ) . '</td>';
            echo '<td class="pmcpc-col-metric">' . esc_html( (string) (int) $metrics['views'] ) . '</td>';
            echo '<td class="pmcpc-col-metric">' . esc_html( (string) (int) $metrics['clicks'] ) . '</td>';
            echo '</tr>';
        }
    }

    foreach ( $log_only_entries as $entry ) {
        $date    = isset( $entry['timestamp'] ) ? (string) $entry['timestamp'] : '';
        $name    = isset( $entry['campaign_name'] ) ? (string) $entry['campaign_name'] : '';
        $result  = isset( $entry['result'] ) ? ucfirst( (string) $entry['result'] ) : __( 'Logged', 'product-mailer-campaigns' );
        $details = isset( $entry['details'] ) ? (string) $entry['details'] : '';
        echo '<tr class="pmcpc-publishing-log-only-row">';
        echo '<th class="check-column"><input type="checkbox" disabled aria-label="' . esc_attr__( 'Publishing event rows cannot be selected', 'product-mailer-campaigns' ) . '"></th>';
        echo '<td class="pmcpc-col-anchor"><span class="pmcpc-table-record"><span class="pmcpc-table-record__title">' . esc_html( '' !== $name ? $name : __( 'Publishing event', 'product-mailer-campaigns' ) ) . '</span><span class="pmcpc-table-record__meta">' . esc_html__( 'Log-only event', 'product-mailer-campaigns' ) . '</span></span></td>';
        echo '<td>—</td>';
        echo '<td><span class="pmcpc-status-pill">' . esc_html( $result ) . '</span></td>';
        echo '<td>' . esc_html( $date ) . '</td>';
        echo '<td>' . esc_html__( 'Publishing log', 'product-mailer-campaigns' ) . '</td>';
        echo '<td class="pmcpc-col-meta"><span class="pmcpc-table-cell-stack"><span class="pmcpc-table-cell-stack__main">' . esc_html( $details ) . '</span></span></td>';
        echo '<td>—</td>';
        echo '<td>—</td>';
        echo '<td>—</td>';
        echo '</tr>';
    }

    echo '</tbody></table></div></div>';

    echo '<div class="pmcpc-table-toolbar pmcpc-selected-actions"><div class="pmcpc-table-toolbar__group">';
    echo '<label><span class="screen-reader-text">' . esc_html__( 'Bulk update action', 'product-mailer-campaigns' ) . '</span><select name="pmcpc_update_management_action">';
    echo '<option value="">' . esc_html__( 'Choose action…', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="publish">' . esc_html__( 'Publish selected', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="draft">' . esc_html__( 'Move selected to draft', 'product-mailer-campaigns' ) . '</option>';
    echo '<option value="private">' . esc_html__( 'Make selected private', 'product-mailer-campaigns' ) . '</option>';
    if ( 'trash' === $status ) {
        echo '<option value="restore">' . esc_html__( 'Restore selected', 'product-mailer-campaigns' ) . '</option>';
        echo '<option value="delete">' . esc_html__( 'Delete selected permanently', 'product-mailer-campaigns' ) . '</option>';
    } else {
        echo '<option value="trash">' . esc_html__( 'Move selected to trash', 'product-mailer-campaigns' ) . '</option>';
    }
    echo '</select></label>';
    echo '<button type="submit" class="button button-primary">' . esc_html__( 'Apply to selected', 'product-mailer-campaigns' ) . '</button>';
    echo '</div><div class="pmcpc-table-toolbar__meta"><span>' . esc_html__( 'Use the first column to select update posts. Log-only events are included for context and cannot be bulk edited.', 'product-mailer-campaigns' ) . '</span></div></div>';
    echo '</form>';

    $total_pages = (int) $updates->max_num_pages;
    if ( $total_pages > 1 ) {
        echo '<div class="tablenav"><div class="tablenav-pages">';
        echo wp_kses_post(
            paginate_links(
                array(
                    'base'      => esc_url_raw(
                        add_query_arg(
                            array(
                                'page'                => 'pmcpc-publishing-log',
                                'pmcpc_update_status' => $status,
                                'pmcpc_update_search' => '' !== $search ? $search : false,
                                'pmcpc_update_topic'  => $topic ? $topic : false,
                                'pmcpc_update_month'  => '' !== $month ? $month : false,
                                'pmcpc_update_paged'  => '%#%',
                            ),
                            admin_url( 'admin.php' )
                        )
                    ),
                    'format'    => '',
                    'current'   => $paged,
                    'total'     => $total_pages,
                    'prev_text' => __( 'Previous', 'product-mailer-campaigns' ),
                    'next_text' => __( 'Next', 'product-mailer-campaigns' ),
                )
            )
        );
        echo '</div></div>';
    }

    echo '</div>';
    wp_reset_postdata();
}


/**
 * Render the Subscriber Updates publishing log page.
 *
 * @return void
 */
function pmcpc_render_subscriber_updates_log_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    pmcpc_handle_subscriber_update_management_actions();

    $entries = get_option( 'pmcpc_sub_updates_publish_log', array() );
    if ( ! is_array( $entries ) ) {
        $entries = array();
    }

    $update_count = 0;
    if ( post_type_exists( 'pmcpc_sub_update' ) ) {
        $counts = wp_count_posts( 'pmcpc_sub_update' );
        if ( $counts ) {
            $update_count = (int) $counts->publish + (int) $counts->draft + (int) $counts->private;
        }
    }

    $recent_updates = get_posts(
        array(
            'post_type'      => 'pmcpc_sub_update',
            'post_status'    => array( 'publish', 'draft', 'private' ),
            'posts_per_page' => max( 20, count( $entries ) ),
            'orderby'        => 'date',
            'order'          => 'DESC',
        )
    );

    $existing_post_ids = array();
    foreach ( $entries as $entry ) {
        if ( ! empty( $entry['details'] ) && preg_match( '/post #(\\d+)/', (string) $entry['details'], $matches ) ) {
            $existing_post_ids[] = absint( $matches[1] );
        }
    }
    $existing_post_ids = array_filter( array_unique( $existing_post_ids ) );

    foreach ( $recent_updates as $update_post ) {
        if ( ! ( $update_post instanceof WP_Post ) ) {
            continue;
        }
        if ( in_array( (int) $update_post->ID, $existing_post_ids, true ) ) {
            continue;
        }
        $entries[] = array(
            'timestamp'     => get_post_time( 'Y-m-d H:i:s', false, $update_post ),
            'campaign_id'   => (int) get_post_meta( $update_post->ID, '_pmcpc_campaign_id', true ),
            'campaign_name' => get_the_title( $update_post->ID ),
            'result'        => 'published',
            'details'       => sprintf( __( 'Subscriber update post #%d is available in the feed.', 'product-mailer-campaigns' ), (int) $update_post->ID ),
        );
    }

    usort(
        $entries,
        static function( $a, $b ) {
            $a_time = ! empty( $a['timestamp'] ) ? strtotime( (string) $a['timestamp'] ) : 0;
            $b_time = ! empty( $b['timestamp'] ) ? strtotime( (string) $b['timestamp'] ) : 0;
            if ( $a_time === $b_time ) {
                return 0;
            }
            return ( $a_time > $b_time ) ? -1 : 1;
        }
    );

    $latest_source = '';
    if ( ! empty( $entries ) ) {
        $latest_entry  = reset( $entries );
        $latest_source = is_array( $latest_entry ) && ! empty( $latest_entry['campaign_name'] ) ? (string) $latest_entry['campaign_name'] : '';
        reset( $entries );
    }

    echo '<div class="wrap">';
    PMCPC_Admin::render_app_header( __( 'Publishing Log', 'product-mailer-campaigns' ) );
    PMCPC_Admin::render_page_intro(
        __( 'Manage website updates and publishing activity', 'product-mailer-campaigns' ),
        __( 'Create, search, edit, and review update posts while keeping recent publishing events in the same place.', 'product-mailer-campaigns' ),
        array(
            array(
                'label' => __( 'Update post management', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-welcome-write-blog',
            ),
            array(
                'label' => __( 'Publishing history and results', 'product-mailer-campaigns' ),
                'icon'  => 'dashicons-clock',
            ),
        )
    );
    PMCPC_Admin::render_support_panels(
        array(
            array(
                'eyebrow' => __( 'How this page works', 'product-mailer-campaigns' ),
                'icon'    => 'dashicons-editor-help',
                'title'   => __( 'Use this page for update posts and publishing checks', 'product-mailer-campaigns' ),
                'items'   => array(
                    __( 'Create and manage update posts in the Publishing activity table.', 'product-mailer-campaigns' ),
                    __( 'Review the latest publishing result beside each update instead of jumping between separate tables.', 'product-mailer-campaigns' ),
                    __( 'Return to Publishing Settings if you need to change the source or schedule.', 'product-mailer-campaigns' ),
                ),
            ),
        )
    );
    PMCPC_Admin::render_stats_strip(
        array(
            array(
                'label' => __( 'Events logged', 'product-mailer-campaigns' ),
                'value' => (string) count( $entries ),
                'meta'  => __( 'Recent publish events kept in the log', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Subscriber updates', 'product-mailer-campaigns' ),
                'value' => (string) $update_count,
                'meta'  => __( 'Published, draft, and private update posts', 'product-mailer-campaigns' ),
            ),
            array(
                'label' => __( 'Latest source', 'product-mailer-campaigns' ),
                'value' => '' !== $latest_source ? $latest_source : __( 'None yet', 'product-mailer-campaigns' ),
                'meta'  => __( 'Most recent campaign or automation in the log', 'product-mailer-campaigns' ),
            ),
        )
    );

    pmcpc_render_subscriber_updates_health_notice( null, true );
    settings_errors( 'pmcpc_sub_updates_log' );
    pmcpc_render_subscriber_updates_management_panel( $entries );

    echo '</div>';

}




/**
 * Helper to fetch subscriber update image URL.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function pmcpc_get_subscriber_update_image_url( $post_id ) {
    $post_id = absint( $post_id );
    if ( ! $post_id ) {
        return '';
    }

    $image = get_post_meta( $post_id, '_pmcpc_image_url', true );
    if ( $image ) {
        return esc_url( (string) $image );
    }

    if ( has_post_thumbnail( $post_id ) ) {
        $thumb = get_the_post_thumbnail_url( $post_id, 'large' );
        if ( $thumb ) {
            return esc_url( $thumb );
        }
    }

    $raw_product_ids = (string) get_post_meta( $post_id, '_pmcpc_product_ids', true );
    $product_ids     = array_filter( array_map( 'absint', array_map( 'trim', explode( ',', $raw_product_ids ) ) ) );
    if ( ! empty( $product_ids ) ) {
        $first_product_id = (int) reset( $product_ids );
        if ( $first_product_id > 0 ) {
            $product_thumb = get_the_post_thumbnail_url( $first_product_id, 'large' );
            if ( $product_thumb ) {
                return esc_url( $product_thumb );
            }
        }
    }

    $settings = get_option( 'pmcpc_sub_updates_settings', array() );
    if ( is_array( $settings ) && ! empty( $settings['default_image_url'] ) ) {
        return esc_url( (string) $settings['default_image_url'] );
    }

    return '';
}


/**
 * Resolve access status for a subscriber update post.
 *
 * @param int $post_id Post ID.
 * @return array
 */
function pmcpc_get_subscriber_update_access_status( $post_id ) {
    $post_id = absint( $post_id );
    $visibility = sanitize_key( (string) get_post_meta( $post_id, '_pmcpc_visibility', true ) );
    if ( '' === $visibility ) {
        $visibility = 'public';
    }

    $expires_at = sanitize_text_field( (string) get_post_meta( $post_id, '_pmcpc_expires_at', true ) );
    if ( '' !== $expires_at ) {
        $expires_ts = strtotime( $expires_at );
        if ( $expires_ts && $expires_ts < current_time( 'timestamp' ) ) {
            return array( 'allowed' => false, 'reason' => 'expired', 'visibility' => $visibility );
        }
    }

    if ( 'public' === $visibility ) {
        return array( 'allowed' => true, 'reason' => 'public', 'visibility' => $visibility );
    }

    if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
        return array( 'allowed' => true, 'reason' => 'admin', 'visibility' => $visibility );
    }

    if ( class_exists( 'PMCPC_Shortcodes_Controller' ) && method_exists( 'PMCPC_Shortcodes_Controller', 'pmcpc_can_view_subscriber_update' ) ) {
        return PMCPC_Shortcodes_Controller::pmcpc_can_view_subscriber_update( $post_id );
    }

    return array( 'allowed' => false, 'reason' => 'subscriber_required', 'visibility' => $visibility );
}

/**
 * Increment lightweight analytics counters for subscriber update views.
 *
 * @return void
 */
function pmcpc_track_subscriber_update_view() {
    if ( is_admin() || ! is_singular( 'pmcpc_sub_update' ) ) {
        return;
    }

    $post_id = get_queried_object_id();
    if ( ! $post_id ) {
        return;
    }

    $cookie_key = 'pmcpc_update_viewed_' . $post_id;
    if ( isset( $_COOKIE[ $cookie_key ] ) ) {
        return;
    }

    $status = pmcpc_get_subscriber_update_access_status( $post_id );
    if ( empty( $status['allowed'] ) ) {
        return;
    }

    $count = (int) get_post_meta( $post_id, '_pmcpc_view_count', true );
    update_post_meta( $post_id, '_pmcpc_view_count', $count + 1 );
    if ( function_exists( 'pmcpc_record_subscriber_update_event' ) ) {
        pmcpc_record_subscriber_update_event( $post_id, 'view' );
    }

    if ( 'public' !== (string) $status['reason'] ) {
        $subscriber_count = (int) get_post_meta( $post_id, '_pmcpc_subscriber_view_count', true );
        update_post_meta( $post_id, '_pmcpc_subscriber_view_count', $subscriber_count + 1 );
        if ( function_exists( 'pmcpc_record_subscriber_update_event' ) ) {
            pmcpc_record_subscriber_update_event( $post_id, 'subscriber_view' );
        }
    }

    setcookie( $cookie_key, '1', time() + DAY_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
    $_COOKIE[ $cookie_key ] = '1';
}

/**
 * Polished front-end layout for single subscriber update pages.
 *
 * @param string $content Post content.
 * @return string
 */
function pmcpc_filter_subscriber_update_single_content( $content ) {
    if ( is_admin() || ! is_singular( 'pmcpc_sub_update' ) || ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }

    $post_id = get_the_ID();
    $content = pmcpc_prepare_subscriber_update_single_body( $post_id, $content );
    $image   = pmcpc_get_subscriber_update_image_url( $post_id );
    $cta_url = esc_url( (string) get_post_meta( $post_id, '_pmcpc_cta_url', true ) );
    $cta_label = sanitize_text_field( (string) get_post_meta( $post_id, '_pmcpc_cta_label', true ) );
    $is_featured = (bool) get_post_meta( $post_id, '_pmcpc_is_featured', true );
    $terms = get_the_terms( $post_id, 'pmcpc_update_topic' );
    $settings = get_option( 'pmcpc_sub_updates_settings', array() );
    $show_related = ! is_array( $settings ) || ! isset( $settings['show_related'] ) ? 1 : (int) $settings['show_related'];
    $access = pmcpc_get_subscriber_update_access_status( $post_id );
    $visibility = ! empty( $access['visibility'] ) ? (string) $access['visibility'] : 'public';

    ob_start();
    echo '<div class="pmcpc-update-single" style="max-width:900px;margin:0 auto 48px;">';
    if ( $image ) {
        echo '<div style="margin:0 0 24px;overflow:hidden;border-radius:24px;background:#f6f3ee;">';
        echo '<img src="' . esc_url( $image ) . '" alt="' . esc_attr( get_the_title( $post_id ) ) . '" style="display:block;width:100%;height:auto;aspect-ratio:16/8;object-fit:cover;">';
        echo '</div>';
    }
    echo '<div style="padding:0 2px;">';
    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
        echo '<p style="margin:0 0 10px;">';
        foreach ( $terms as $term ) {
            echo '<span style="display:inline-block;margin:0 8px 8px 0;padding:6px 12px;border-radius:999px;background:#f3f0ea;border:1px solid #e0d7cb;font-size:12px;font-weight:600;">' . esc_html( $term->name ) . '</span>';
        }
        if ( $is_featured ) {
            echo '<span style="display:inline-block;margin:0 8px 8px 0;padding:6px 12px;border-radius:999px;background:#111827;color:#fff;font-size:12px;font-weight:600;">' . esc_html__( 'Featured', 'product-mailer-campaigns' ) . '</span>';
        }
        echo '</p>';
    } elseif ( $is_featured ) {
        echo '<p style="margin:0 0 10px;"><span style="display:inline-block;padding:6px 12px;border-radius:999px;background:#111827;color:#fff;font-size:12px;font-weight:600;">' . esc_html__( 'Featured', 'product-mailer-campaigns' ) . '</span></p>';
    }
    if ( 'subscribers' === $visibility || 'segment' === $visibility ) {
        echo '<p style="margin:0 0 16px;"><span style="display:inline-block;padding:6px 12px;border-radius:999px;background:#fff7ed;border:1px solid #fdba74;font-size:12px;font-weight:600;color:#9a3412;">' . esc_html__( 'Subscribers only', 'product-mailer-campaigns' ) . '</span></p>';
    } elseif ( 'private' === $visibility ) {
        echo '<p style="margin:0 0 16px;"><span style="display:inline-block;padding:6px 12px;border-radius:999px;background:#f3f4f6;border:1px solid #d1d5db;font-size:12px;font-weight:600;color:#374151;">' . esc_html__( 'Private', 'product-mailer-campaigns' ) . '</span></p>';
    }
    if ( ! empty( $access['allowed'] ) ) {
        echo '<div style="font-size:16px;line-height:1.8;color:#1f2937;">' . $content . '</div>';
        if ( $cta_url && $cta_label && class_exists( 'PMCPC_Shortcodes_Controller' ) && method_exists( 'PMCPC_Shortcodes_Controller', 'pmcpc_get_tracked_cta_url' ) ) {
            echo '<p style="margin:28px 0 0;"><a href="' . esc_url( PMCPC_Shortcodes_Controller::pmcpc_get_tracked_cta_url( $post_id, $cta_url ) ) . '" style="display:inline-block;padding:13px 20px;border-radius:999px;background:#111827;color:#fff;text-decoration:none;font-weight:600;">' . esc_html( $cta_label ) . '</a></p>';
        }
    } else {
        echo '<div style="font-size:16px;line-height:1.8;color:#1f2937;">' . wpautop( wp_kses_post( wp_trim_words( wp_strip_all_tags( $content ), 80 ) ) ) . '</div>';
        if ( 'expired' === $access['reason'] ) {
            echo '<div style="margin:28px 0 0;padding:22px;border:1px solid #f5d0a9;border-radius:20px;background:#fff7ed;color:#9a3412;">' . esc_html__( 'This update has expired and is no longer available.', 'product-mailer-campaigns' ) . '</div>';
        } elseif ( class_exists( 'PMCPC_Shortcodes_Controller' ) && method_exists( 'PMCPC_Shortcodes_Controller', 'pmcpc_render_update_unlock_form' ) ) {
            echo PMCPC_Shortcodes_Controller::pmcpc_render_update_unlock_form( $post_id, (string) $access['reason'] );
        }
    }
    echo '</div>';

    if ( ! empty( $access['allowed'] ) && $show_related ) {
        $term_ids = ! empty( $terms ) && ! is_wp_error( $terms ) ? wp_list_pluck( $terms, 'term_id' ) : array();
        $related_args = array(
            'post_type'      => 'pmcpc_sub_update',
            'post_status'    => 'publish',
            'posts_per_page' => 3,
            'post__not_in'   => array( $post_id ),
        );
        if ( ! empty( $term_ids ) ) {
            $related_args['tax_query'] = array(
                array(
                    'taxonomy' => 'pmcpc_update_topic',
                    'field'    => 'term_id',
                    'terms'    => $term_ids,
                ),
            );
        }
        $related = new WP_Query( $related_args );
        if ( $related->have_posts() ) {
            echo '<div style="margin-top:44px;padding-top:30px;border-top:1px solid #e5e7eb;">';
            echo '<h3 style="margin:0 0 18px;font-size:24px;line-height:1.2;">' . esc_html__( 'Related updates', 'product-mailer-campaigns' ) . '</h3>';
            echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px;">';
            while ( $related->have_posts() ) {
                $related->the_post();
                $rid = get_the_ID();
                $rimg = pmcpc_get_subscriber_update_image_url( $rid );
                echo '<article style="border:1px solid #e5e7eb;border-radius:20px;overflow:hidden;background:#fff;">';
                if ( $rimg ) {
                    echo '<a href="' . esc_url( get_permalink( $rid ) ) . '" style="display:block;"><img src="' . esc_url( $rimg ) . '" alt="' . esc_attr( get_the_title( $rid ) ) . '" style="display:block;width:100%;height:180px;object-fit:cover;"></a>';
                }
                echo '<div style="padding:18px;">';
                echo '<h4 style="margin:0 0 10px;font-size:18px;line-height:1.35;"><a href="' . esc_url( get_permalink( $rid ) ) . '" style="color:#111827;text-decoration:none;">' . esc_html( get_the_title( $rid ) ) . '</a></h4>';
                echo '<p style="margin:0;color:#4b5563;">' . esc_html( wp_trim_words( get_the_excerpt( $rid ), 18 ) ) . '</p>';
                echo '</div></article>';
            }
            wp_reset_postdata();
            echo '</div></div>';
        }
    }

    echo '</div>';
    return ob_get_clean();
}

/**
 * Prepare the single subscriber update body so product blocks survive custom
 * website publishing content and older published posts.
 *
 * @param int    $post_id  Subscriber update id.
 * @param string $content  Stored post content.
 * @return string
 */
function pmcpc_prepare_subscriber_update_single_body( $post_id, $content ) {
    $post_id  = absint( $post_id );
    $content  = (string) $content;
    $campaign_id = (int) get_post_meta( $post_id, '_pmcpc_campaign_id', true );

    if ( $campaign_id > 0 && class_exists( 'PMCPC_Campaign_Manager' ) && method_exists( 'PMCPC_Campaign_Manager', 'pmcpc_inject_products_block_for_campaign_id' ) ) {
        $content = PMCPC_Campaign_Manager::pmcpc_inject_products_block_for_campaign_id( $campaign_id, $content );
    }

    if ( pmcpc_subscriber_update_content_has_products( $content ) ) {
        return $content;
    }

    $products_html = pmcpc_get_subscriber_update_products_fallback_html( $post_id, $campaign_id );
    if ( '' === $products_html ) {
        return $content;
    }

    return $content . $products_html;
}

/**
 * Detect whether subscriber update content already contains a rendered product
 * section so we avoid duplicating it.
 *
 * @param string $content Content html.
 * @return bool
 */
function pmcpc_subscriber_update_content_has_products( $content ) {
    $content = (string) $content;
    if ( '' === $content ) {
        return false;
    }

    foreach ( array( 'pmcpc-commerce-update', 'pmcpc-email-products', 'pmcpc-product-card', 'pmcpc-product-grid' ) as $needle ) {
        if ( false !== strpos( $content, $needle ) ) {
            return true;
        }
    }

    return false;
}

/**
 * Rebuild a missing subscriber update product section from stored product ids
 * or the original campaign configuration.
 *
 * @param int $post_id      Subscriber update id.
 * @param int $campaign_id  Related campaign id.
 * @return string
 */
function pmcpc_get_subscriber_update_products_fallback_html( $post_id, $campaign_id = 0 ) {
    $post_id     = absint( $post_id );
    $campaign_id = absint( $campaign_id );

    $raw_product_ids = (string) get_post_meta( $post_id, '_pmcpc_product_ids', true );
    $product_ids     = array_filter( array_map( 'absint', array_map( 'trim', explode( ',', $raw_product_ids ) ) ) );

    if ( ! empty( $product_ids ) && function_exists( 'get_posts' ) ) {
        $products = get_posts(
            array(
                'post_type'      => 'product',
                'post_status'    => 'publish',
                'post__in'       => $product_ids,
                'orderby'        => 'post__in',
                'posts_per_page' => count( $product_ids ),
            )
        );

        if ( ! empty( $products ) ) {
            $cta_label = sanitize_text_field( (string) get_post_meta( $post_id, '_pmcpc_cta_label', true ) );
            return pmcpc_render_commerce_update_body( $products, $cta_label, $post_id );
        }
    }

    if ( $campaign_id > 0 && class_exists( 'PMCPC_Campaign_Manager' ) && method_exists( 'PMCPC_Campaign_Manager', 'pmcpc_render_products_block_for_campaign_id' ) ) {
        return (string) PMCPC_Campaign_Manager::pmcpc_render_products_block_for_campaign_id( $campaign_id );
    }

    return '';
}

// Public preferences center shortcodes (manage preferences/unsubscribe landing).
add_action( 'init', array( 'PMCPC_Preferences_Center', 'init' ) );

// Compatibility/hardening hooks in one place.
add_action( 'plugins_loaded', array( 'PMCPC_Compat', 'init' ), 0 );

// Boot core plugin + optional modules.
add_action(
    'plugins_loaded',
    function() {
        $plugin = new PMCPC_Plugin();
        $plugin->run();
    },
    10
);

/**
 * Build tracked product URL for subscriber updates.
 *
 * @param int    $update_id Subscriber update ID.
 * @param int    $product_id Product ID.
 * @param string $url Destination URL.
 * @return string
 */
function pmcpc_get_tracked_product_url( $update_id, $product_id, $url ) {
    $url = esc_url_raw( (string) $url );
    if ( '' === $url ) {
        return '';
    }
    return add_query_arg(
        array(
            'pmcpc_update_product' => absint( $update_id ),
            'pmcpc_product_id'     => absint( $product_id ),
            'pmcpc_target'         => rawurlencode( $url ),
        ),
        home_url( '/' )
    );
}

/**
 * Render a simple commerce update body from WooCommerce products.
 *
 * @param array  $products Array of WP_Post product objects.
 * @param string $cta_label CTA label.
 * @param int    $update_id Existing update ID when available.
 * @return string
 */
function pmcpc_render_commerce_update_body( $products, $cta_label = '', $update_id = 0 ) {
    if ( empty( $products ) || ! is_array( $products ) ) {
        return '';
    }

    if ( '' === trim( (string) $cta_label ) ) {
        $cta_label = __( 'View product', 'product-mailer-campaigns' );
    }

    ob_start();
    echo '<div class="pmcpc-commerce-update">';
    echo '<p>' . esc_html__( 'Here is a curated selection from the latest website update.', 'product-mailer-campaigns' ) . '</p>';
    echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:22px;margin:24px 0;">';
    foreach ( $products as $product_post ) {
        $product_id = $product_post instanceof WP_Post ? (int) $product_post->ID : 0;
        if ( $product_id <= 0 ) {
            continue;
        }
        $product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
        if ( ! $product ) {
            continue;
        }
        $image = get_the_post_thumbnail_url( $product_id, 'large' );
        $price = method_exists( $product, 'get_price_html' ) ? $product->get_price_html() : '';
        $url   = get_permalink( $product_id );
        if ( $update_id > 0 ) {
            $url = pmcpc_get_tracked_product_url( $update_id, $product_id, $url );
        }
        echo '<article style="border:1px solid #e5e7eb;border-radius:20px;overflow:hidden;background:#fff;">';
        if ( $image ) {
            echo '<a href="' . esc_url( $url ) . '" style="display:block;"><img src="' . esc_url( $image ) . '" alt="' . esc_attr( get_the_title( $product_id ) ) . '" style="display:block;width:100%;height:220px;object-fit:cover;"></a>';
        }
        echo '<div style="padding:18px;">';
        echo '<h3 style="margin:0 0 8px;font-size:20px;line-height:1.3;"><a href="' . esc_url( $url ) . '" style="color:#111827;text-decoration:none;">' . esc_html( get_the_title( $product_id ) ) . '</a></h3>';
        if ( '' !== trim( wp_strip_all_tags( (string) $price ) ) ) {
            echo '<div style="margin:0 0 10px;font-weight:600;">' . wp_kses_post( $price ) . '</div>';
        }
        echo '<p style="margin:0 0 16px;color:#4b5563;">' . esc_html( wp_trim_words( wp_strip_all_tags( (string) get_post_field( 'post_content', $product_id ) ), 24 ) ) . '</p>';
        echo '<p style="margin:0;"><a href="' . esc_url( $url ) . '" style="display:inline-block;padding:11px 16px;border-radius:999px;background:#111827;color:#fff;text-decoration:none;font-weight:600;">' . esc_html( $cta_label ) . '</a></p>';
        echo '</div></article>';
    }
    echo '</div></div>';
    return (string) ob_get_clean();
}


/**
 * Apply automatic expiry to generated subscriber updates when enabled.
 *
 * @param int   $update_id Update id.
 * @param array $settings Settings array.
 * @return void
 */
function pmcpc_maybe_apply_generated_update_expiry( $update_id, $settings ) {
    $update_id = absint( $update_id );
    if ( $update_id <= 0 ) {
        return;
    }

    $days = is_array( $settings ) && isset( $settings['auto_expiry_days'] ) ? absint( $settings['auto_expiry_days'] ) : 0;
    if ( $days <= 0 ) {
        delete_post_meta( $update_id, '_pmcpc_expires_at' );
        return;
    }

    $timestamp = current_time( 'timestamp' ) + ( $days * DAY_IN_SECONDS );
    update_post_meta( $update_id, '_pmcpc_expires_at', gmdate( 'Y-m-d H:i:s', $timestamp + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) );
}

/**
 * Determine whether the daily commerce update should run today.
 *
 * @param array $settings Settings array.
 * @return bool
 */
function pmcpc_should_publish_daily_commerce_update_today( $settings ) {
    $days = is_array( $settings ) && ! empty( $settings['daily_publish_days'] ) && is_array( $settings['daily_publish_days'] )
        ? array_map( 'sanitize_key', $settings['daily_publish_days'] )
        : array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' );

    $today = strtolower( function_exists( 'wp_date' ) ? wp_date( 'D' ) : gmdate( 'D' ) );
    $today = substr( $today, 0, 3 );

    return in_array( $today, $days, true );
}

/**
 * Build the next timestamp for the daily commerce schedule.
 *
 * @param array $settings Settings array.
 * @return int
 */
function pmcpc_get_daily_commerce_schedule_timestamp( $settings ) {
    $hour   = is_array( $settings ) && isset( $settings['daily_publish_hour'] ) ? max( 0, min( 23, absint( $settings['daily_publish_hour'] ) ) ) : 9;
    $minute = is_array( $settings ) && isset( $settings['daily_publish_minute'] ) ? max( 0, min( 59, absint( $settings['daily_publish_minute'] ) ) ) : 0;

    if ( function_exists( 'wp_timezone' ) && class_exists( 'DateTimeImmutable' ) ) {
        $timezone = wp_timezone();
        $now      = new DateTimeImmutable( 'now', $timezone );
        $target   = $now->setTime( $hour, $minute, 0 );

        if ( $target->getTimestamp() <= $now->getTimestamp() ) {
            $target = $target->modify( '+1 day' );
        }

        return $target->getTimestamp();
    }

    $now  = current_time( 'timestamp' );
    $base = mktime( $hour, $minute, 0, (int) wp_date( 'n', $now ), (int) wp_date( 'j', $now ), (int) wp_date( 'Y', $now ) );

    if ( $base <= $now ) {
        $base += DAY_IN_SECONDS;
    }

    return $base;
}

function pmcpc_get_recently_used_product_ids( $days ) {
    $days = absint( $days );
    if ( $days <= 0 ) {
        return array();
    }

    $updates = get_posts(
        array(
            'post_type'      => 'pmcpc_sub_update',
            'post_status'    => array( 'publish', 'draft', 'private' ),
            'posts_per_page' => 50,
            'date_query'     => array(
                array(
                    'after'     => gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) ),
                    'inclusive' => true,
                    'column'    => 'post_date_gmt',
                ),
            ),
            'fields'         => 'ids',
        )
    );

    $product_ids = array();
    foreach ( $updates as $update_id ) {
        $stored = (string) get_post_meta( (int) $update_id, '_pmcpc_product_ids', true );
        if ( '' === $stored ) {
            continue;
        }
        foreach ( array_filter( array_map( 'absint', array_map( 'trim', explode( ',', $stored ) ) ) ) as $product_id ) {
            $product_ids[] = $product_id;
        }
    }

    return array_values( array_unique( $product_ids ) );
}

function pmcpc_evaluate_commerce_product_for_updates( $product_id, $settings, $context = 'daily' ) {
    $product_id = absint( $product_id );
    if ( $product_id <= 0 || 'product' !== get_post_type( $product_id ) || 'publish' !== get_post_status( $product_id ) ) {
        return array( 'allowed' => false, 'reason' => __( 'Not a published WooCommerce product.', 'product-mailer-campaigns' ) );
    }

    $product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
    if ( ! $product ) {
        return array( 'allowed' => false, 'reason' => __( 'WooCommerce could not load this product.', 'product-mailer-campaigns' ) );
    }

    if ( ! empty( $settings['only_in_stock'] ) && method_exists( $product, 'is_in_stock' ) && ! $product->is_in_stock() ) {
        return array( 'allowed' => false, 'reason' => __( 'Out of stock.', 'product-mailer-campaigns' ) );
    }

    if ( ! empty( $settings['require_product_image'] ) && ! has_post_thumbnail( $product_id ) ) {
        return array( 'allowed' => false, 'reason' => __( 'No featured image set.', 'product-mailer-campaigns' ) );
    }

    $excluded_slugs = array_filter( array_map( 'sanitize_title', preg_split( '/[\s,]+/', (string) ( $settings['exclude_categories'] ?? '' ) ) ) );
    if ( ! empty( $excluded_slugs ) ) {
        $product_terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'slugs' ) );
        if ( ! is_wp_error( $product_terms ) && array_intersect( $excluded_slugs, array_map( 'sanitize_title', (array) $product_terms ) ) ) {
            return array( 'allowed' => false, 'reason' => __( 'Excluded by category rule.', 'product-mailer-campaigns' ) );
        }
    }

    if ( 'daily' === $context ) {
        $max_age_days = isset( $settings['max_product_age_days'] ) ? absint( $settings['max_product_age_days'] ) : 0;
        if ( $max_age_days > 0 ) {
            $product_time = get_post_time( 'U', true, $product_id );
            if ( $product_time > 0 && $product_time < ( time() - ( $max_age_days * DAY_IN_SECONDS ) ) ) {
                return array( 'allowed' => false, 'reason' => sprintf( __( 'Older than %d days.', 'product-mailer-campaigns' ), $max_age_days ) );
            }
        }

        $avoid_repeat_days = isset( $settings['avoid_repeat_product_days'] ) ? absint( $settings['avoid_repeat_product_days'] ) : 0;
        if ( $avoid_repeat_days > 0 ) {
            static $recent_product_cache = array();
            if ( ! isset( $recent_product_cache[ $avoid_repeat_days ] ) ) {
                $recent_product_cache[ $avoid_repeat_days ] = pmcpc_get_recently_used_product_ids( $avoid_repeat_days );
            }
            if ( in_array( $product_id, $recent_product_cache[ $avoid_repeat_days ], true ) ) {
                return array( 'allowed' => false, 'reason' => sprintf( __( 'Used in another update within the last %d days.', 'product-mailer-campaigns' ), $avoid_repeat_days ) );
            }
        }
    }

    return array( 'allowed' => true, 'reason' => '' );
}

function pmcpc_get_commerce_products_for_subscriber_update( $settings, $limit = 0, $context = 'daily' ) {
    $limit = $limit > 0 ? absint( $limit ) : ( isset( $settings['commerce_limit'] ) ? max( 1, min( 12, absint( $settings['commerce_limit'] ) ) ) : 4 );
    $mode  = isset( $settings['commerce_mode'] ) && 'featured' === $settings['commerce_mode'] ? 'featured' : 'latest';

    $args = array(
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => max( $limit * 4, 12 ),
    );

    if ( 'featured' === $mode ) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'product_visibility',
                'field'    => 'name',
                'terms'    => array( 'featured' ),
            ),
        );
    } else {
        $args['orderby'] = 'date';
        $args['order']   = 'DESC';
    }

    $products = get_posts( $args );
    $included = array();
    $excluded = array();

    foreach ( $products as $product_post ) {
        if ( count( $included ) >= $limit ) {
            break;
        }
        $evaluation = pmcpc_evaluate_commerce_product_for_updates( $product_post->ID, $settings, $context );
        if ( ! empty( $evaluation['allowed'] ) ) {
            $included[] = $product_post;
        } else {
            $excluded[] = array(
                'product_id' => (int) $product_post->ID,
                'title'      => get_the_title( $product_post->ID ),
                'reason'     => (string) $evaluation['reason'],
            );
        }
    }

    return array(
        'mode'     => $mode,
        'included' => $included,
        'excluded' => $excluded,
        'limit'    => $limit,
    );
}

function pmcpc_get_subscriber_update_preview_data( $settings ) {
    $settings       = wp_parse_args( is_array( $settings ) ? $settings : array(), pmcpc_get_subscriber_updates_settings() );
    $preview_limit  = isset( $settings['preview_limit'] ) ? max( 1, min( 12, absint( $settings['preview_limit'] ) ) ) : 4;
    $selection      = pmcpc_get_commerce_products_for_subscriber_update( $settings, $preview_limit, 'daily' );
    $next_timestamp = pmcpc_get_daily_commerce_schedule_timestamp( $settings );

    return array(
        'selection'             => $selection,
        'next_run_local'        => $next_timestamp > 0 ? wp_date( get_option( 'date_format', 'j F Y' ) . ' ' . get_option( 'time_format', 'H:i' ), $next_timestamp ) : '',
        'runs_today'            => pmcpc_should_publish_daily_commerce_update_today( $settings ),
        'rules_summary'         => array(
            ! empty( $settings['only_in_stock'] ) ? __( 'Only in-stock products', 'product-mailer-campaigns' ) : __( 'Stock status ignored', 'product-mailer-campaigns' ),
            ! empty( $settings['require_product_image'] ) ? __( 'Requires product image', 'product-mailer-campaigns' ) : __( 'Image not required', 'product-mailer-campaigns' ),
            ! empty( $settings['exclude_categories'] ) ? sprintf( __( 'Excluded categories: %s', 'product-mailer-campaigns' ), $settings['exclude_categories'] ) : __( 'No excluded categories', 'product-mailer-campaigns' ),
            ! empty( $settings['max_product_age_days'] ) ? sprintf( __( 'Max product age: %d days', 'product-mailer-campaigns' ), absint( $settings['max_product_age_days'] ) ) : __( 'No age limit', 'product-mailer-campaigns' ),
            ! empty( $settings['avoid_repeat_product_days'] ) ? sprintf( __( 'Avoid repeats for %d days', 'product-mailer-campaigns' ), absint( $settings['avoid_repeat_product_days'] ) ) : __( 'Repeats allowed', 'product-mailer-campaigns' ),
        ),
    );
}


/**
 * Get the latest Subscriber Update timestamp for a specific source type.
 *
 * @param string $source_type Source type meta value.
 * @return int
 */
function pmcpc_get_latest_subscriber_update_timestamp_by_source( $source_type ) {
    $source_type = sanitize_key( (string) $source_type );
    if ( '' === $source_type ) {
        return 0;
    }

    $posts = get_posts(
        array(
            'post_type'      => 'pmcpc_sub_update',
            'post_status'    => array( 'publish', 'draft', 'private' ),
            'posts_per_page' => 1,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_key'       => '_pmcpc_source_type',
            'meta_value'     => $source_type,
            'fields'         => 'ids',
        )
    );

    if ( empty( $posts ) ) {
        return 0;
    }

    return (int) get_post_time( 'U', false, (int) $posts[0] );
}

/**
 * Get lightweight cron diagnostics for daily commerce publishing.
 *
 * @return array
 */
function pmcpc_get_daily_commerce_cron_diagnostics() {
    $messages = array();

    if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
        $messages[] = __( 'DISABLE_WP_CRON is turned on, so normal page loads will not spawn wp-cron automatically.', 'product-mailer-campaigns' );
    }

    if ( defined( 'ALTERNATE_WP_CRON' ) && ALTERNATE_WP_CRON ) {
        $messages[] = __( 'ALTERNATE_WP_CRON is enabled.', 'product-mailer-campaigns' );
    }

    $next = (int) wp_next_scheduled( 'pmcpc_daily_commerce_update' );
    if ( $next > 0 ) {
        $messages[] = sprintf(
            __( 'Next due event: %s.', 'product-mailer-campaigns' ),
            wp_date( get_option( 'date_format', 'j F Y' ) . ' ' . get_option( 'time_format', 'H:i:s' ), $next )
        );
    } else {
        $messages[] = __( 'No daily highlights event is currently scheduled.', 'product-mailer-campaigns' );
    }

    return array( 'messages' => $messages );
}

/**
 * Directly run the due daily highlights callback for diagnostics.
 *
 * @param array|null $settings Optional settings array.
 * @return array
 */
function pmcpc_force_due_daily_commerce_event( $settings = null ) {
    if ( null === $settings ) {
        $settings = get_option( 'pmcpc_sub_updates_settings', array() );
    }
    if ( ! is_array( $settings ) ) {
        $settings = array();
    }

    $next = (int) wp_next_scheduled( 'pmcpc_daily_commerce_update' );
    $now  = current_time( 'timestamp' );

    if ( $next <= 0 ) {
        return array(
            'ok'      => false,
            'message' => __( 'Run due cron now failed: no daily highlights event is currently scheduled. Click Repair schedule first.', 'product-mailer-campaigns' ),
        );
    }

    if ( $next > $now ) {
        return array(
            'ok'      => false,
            'message' => sprintf(
                __( 'Run due cron now skipped: current site time is %1$s and the event is not due until %2$s.', 'product-mailer-campaigns' ),
                wp_date( get_option( 'date_format', 'j F Y' ) . ' ' . get_option( 'time_format', 'H:i:s' ), $now ),
                wp_date( get_option( 'date_format', 'j F Y' ) . ' ' . get_option( 'time_format', 'H:i:s' ), $next )
            ),
        );
    }

    $before = pmcpc_get_latest_subscriber_update_timestamp_by_source( 'commerce_automation' );
    do_action( 'pmcpc_daily_commerce_update' );
    $after = pmcpc_get_latest_subscriber_update_timestamp_by_source( 'commerce_automation' );

    if ( $after > $before ) {
        wp_clear_scheduled_hook( 'pmcpc_daily_commerce_update' );
        pmcpc_sync_daily_commerce_update_schedule();
        return array(
            'ok'      => true,
            'message' => __( 'Run due cron now succeeded: the daily highlights callback ran and a scheduled update was recorded. This points to normal WP-Cron spawning being the remaining problem on your site.', 'product-mailer-campaigns' ),
        );
    }

    $selection = pmcpc_get_commerce_products_for_subscriber_update( $settings, isset( $settings['commerce_limit'] ) ? max( 1, min( 12, absint( $settings['commerce_limit'] ) ) ) : 4, 'daily' );
    if ( empty( $selection['included'] ) ) {
        $reason = '';
        if ( ! empty( $selection['excluded'][0]['reason'] ) ) {
            $reason = ' ' . sprintf( __( 'Example exclusion: %s', 'product-mailer-campaigns' ), (string) $selection['excluded'][0]['reason'] );
        }
        return array(
            'ok'      => false,
            'message' => __( 'Run due cron now reached the publish callback, but no products qualified for the update.', 'product-mailer-campaigns' ) . $reason,
        );
    }

    return array(
        'ok'      => false,
        'message' => __( 'Run due cron now reached the publish callback, but no new daily highlights post was recorded. This suggests the callback ran but returned without creating a post, so the next step is to inspect the publish callback path more deeply.', 'product-mailer-campaigns' ),
    );
}

/**
 * Build a simple health summary for Subscriber Updates publishing.
 *
 * @param array|null $settings Optional settings array.
 * @return array
 */

/**
 * Force a wp-cron loopback for the daily highlights schedule and report what happened.
 *
 * @param array|null $settings Optional settings array.
 * @return array{ok:bool,message:string}
 */
function pmcpc_run_daily_commerce_cron_test( $settings = null ) {
    $settings        = wp_parse_args( is_array( $settings ) ? $settings : array(), pmcpc_get_subscriber_updates_settings() );
    $before          = pmcpc_get_latest_subscriber_update_timestamp_by_source( 'commerce_automation' );
    $next_before     = (int) wp_next_scheduled( 'pmcpc_daily_commerce_update' );
    $now             = time();
    $display_format  = get_option( 'date_format', 'j F Y' ) . ' ' . get_option( 'time_format', 'H:i' ) . ':s';
    $current_site_tm = wp_date( $display_format, $now );

    if ( empty( $settings['enabled'] ) || empty( $settings['commerce_auto_enabled'] ) ) {
        return array(
            'ok'      => false,
            'message' => __( 'Cron test stopped: Daily shop highlights is currently turned off.', 'product-mailer-campaigns' ),
        );
    }

    if ( ! has_action( 'pmcpc_daily_commerce_update', 'pmcpc_publish_daily_commerce_update' ) ) {
        return array(
            'ok'      => false,
            'message' => __( 'Cron test failed: the daily highlights cron hook is not connected to the publish callback on this request.', 'product-mailer-campaigns' ),
        );
    }

    if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
        return array(
            'ok'      => false,
            'message' => __( 'Cron test stopped: DISABLE_WP_CRON is turned on, so WordPress will not spawn wp-cron.php from the browser. Use a real server cron job for this site.', 'product-mailer-campaigns' ),
        );
    }

    if ( ! $next_before ) {
        return array(
            'ok'      => false,
            'message' => __( 'Cron test failed: no daily highlights event is currently scheduled. Click Repair schedule first, then run the test again.', 'product-mailer-campaigns' ),
        );
    }

    $doing_cron = sprintf( '%.22F', microtime( true ) );
    $cron_url   = add_query_arg( 'doing_wp_cron', rawurlencode( $doing_cron ), site_url( 'wp-cron.php' ) );
    $response   = wp_remote_post(
        $cron_url,
        array(
            'timeout'    => 20,
            'blocking'   => true,
            'sslverify'  => apply_filters( 'https_local_ssl_verify', false ),
            'headers'    => array( 'Cache-Control' => 'no-cache' ),
            'user-agent' => 'FlowPress-Cron-Test/' . ( defined( 'PMCPC_VERSION' ) ? PMCPC_VERSION : '1.0.0' ),
        )
    );

    if ( is_wp_error( $response ) ) {
        return array(
            'ok'      => false,
            'message' => sprintf( __( 'Cron loopback failed: %s', 'product-mailer-campaigns' ), $response->get_error_message() ),
        );
    }

    $code = (int) wp_remote_retrieve_response_code( $response );
    if ( $code < 200 || $code >= 300 ) {
        return array(
            'ok'      => false,
            'message' => sprintf( __( 'Cron loopback reached wp-cron.php, but it returned HTTP %d instead of a success response.', 'product-mailer-campaigns' ), $code ),
        );
    }

    $after      = pmcpc_get_latest_subscriber_update_timestamp_by_source( 'commerce_automation' );
    $next_after = (int) wp_next_scheduled( 'pmcpc_daily_commerce_update' );

    if ( $after > $before ) {
        return array(
            'ok'      => true,
            'message' => __( 'Cron test succeeded: wp-cron.php ran and a daily highlights update was recorded.', 'product-mailer-campaigns' ),
        );
    }

    if ( ! pmcpc_should_publish_daily_commerce_update_today( $settings ) ) {
        return array(
            'ok'      => false,
            'message' => __( 'Cron loopback succeeded, but today is outside the selected daily publish days, so no daily highlights update was expected.', 'product-mailer-campaigns' ),
        );
    }

    $preview_data = pmcpc_get_subscriber_update_preview_data( $settings );
    if ( empty( $preview_data['selection']['included'] ) ) {
        $first_reason = '';
        if ( ! empty( $preview_data['selection']['excluded'][0]['reason'] ) ) {
            $first_reason = (string) $preview_data['selection']['excluded'][0]['reason'];
        }

        return array(
            'ok'      => false,
            'message' => $first_reason
                ? sprintf( __( 'Cron loopback succeeded, but no products currently qualify for daily highlights. Example exclusion: %s', 'product-mailer-campaigns' ), $first_reason )
                : __( 'Cron loopback succeeded, but no products currently qualify for daily highlights under the active rules.', 'product-mailer-campaigns' ),
        );
    }

    if ( $next_before > $now ) {
        $seconds_until_due = max( 1, $next_before - $now );
        $due_label         = wp_date( $display_format, $next_before );

        if ( $seconds_until_due < MINUTE_IN_SECONDS ) {
            return array(
                'ok'      => false,
                'message' => sprintf(
                    __( 'Cron loopback succeeded, but the daily highlights event is not due yet. Current site time: %1$s. The event is scheduled for %2$s, which is %3$d second(s) from now. The time shown elsewhere is rounded to the minute, so it can look due before the exact second arrives.', 'product-mailer-campaigns' ),
                    $current_site_tm,
                    $due_label,
                    $seconds_until_due
                ),
            );
        }

        return array(
            'ok'      => false,
            'message' => sprintf(
                __( 'Cron loopback succeeded, but the daily highlights event is not due yet. Current site time: %1$s. It is currently scheduled for %2$s.', 'product-mailer-campaigns' ),
                $current_site_tm,
                $due_label
            ),
        );
    }

    if ( $next_after && $next_after === $next_before ) {
        return array(
            'ok'      => false,
            'message' => __( 'Cron loopback reached wp-cron.php, but the scheduled daily highlights event did not move forward. This usually means another plugin, host rule, or loopback restriction is preventing the cron queue from running due events properly.', 'product-mailer-campaigns' ),
        );
    }

    return array(
        'ok'      => false,
        'message' => __( 'Cron loopback succeeded, but no daily highlights update was recorded. Use Run daily now to confirm the publish callback itself still works, then check Scheduled Actions and your host cron setup.', 'product-mailer-campaigns' ),
    );
}

function pmcpc_get_subscriber_updates_health_report( $settings = null ) {
    $settings = wp_parse_args( is_array( $settings ) ? $settings : array(), pmcpc_get_subscriber_updates_settings() );
    $now      = current_time( 'timestamp' );

    $report = array(
        'status'                  => 'good',
        'summary'                 => __( 'Publishing checks look healthy.', 'product-mailer-campaigns' ),
        'messages'                => array(),
        'daily_enabled'           => ! empty( $settings['enabled'] ) && ! empty( $settings['commerce_auto_enabled'] ),
        'new_arrivals_enabled'    => ! empty( $settings['enabled'] ) && ! empty( $settings['commerce_new_product_enabled'] ),
        'next_daily_run_ts'       => (int) wp_next_scheduled( 'pmcpc_daily_commerce_update' ),
        'next_daily_run_local'    => '',
        'last_daily_run_ts'       => pmcpc_get_latest_subscriber_update_timestamp_by_source( 'commerce_automation' ),
        'last_daily_run_local'    => '',
        'last_new_arrival_ts'     => pmcpc_get_latest_subscriber_update_timestamp_by_source( 'commerce_new_product' ),
        'last_new_arrival_local'  => '',
        'daily_run_due_now'       => false,
        'daily_run_seen_today'    => false,
        'selected_today'          => false,
        'cron_disabled'           => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
    );

    if ( $report['next_daily_run_ts'] > 0 ) {
        $report['next_daily_run_local'] = wp_date( get_option( 'date_format', 'j F Y' ) . ' ' . get_option( 'time_format', 'H:i' ), $report['next_daily_run_ts'] );
    }
    if ( $report['last_daily_run_ts'] > 0 ) {
        $report['last_daily_run_local'] = wp_date( get_option( 'date_format', 'j F Y' ) . ' ' . get_option( 'time_format', 'H:i' ), $report['last_daily_run_ts'] );
    }
    if ( $report['last_new_arrival_ts'] > 0 ) {
        $report['last_new_arrival_local'] = wp_date( get_option( 'date_format', 'j F Y' ) . ' ' . get_option( 'time_format', 'H:i' ), $report['last_new_arrival_ts'] );
    }

    if ( $report['daily_enabled'] ) {
        $hour                 = isset( $settings['daily_publish_hour'] ) ? max( 0, min( 23, absint( $settings['daily_publish_hour'] ) ) ) : 9;
        $minute               = isset( $settings['daily_publish_minute'] ) ? max( 0, min( 59, absint( $settings['daily_publish_minute'] ) ) ) : 0;
        $today_target         = mktime( $hour, $minute, 0, (int) wp_date( 'n', $now ), (int) wp_date( 'j', $now ), (int) wp_date( 'Y', $now ) );
        if ( function_exists( 'wp_timezone' ) && class_exists( 'DateTimeImmutable' ) ) {
            $timezone     = wp_timezone();
            $current_time = new DateTimeImmutable( 'now', $timezone );
            $today_target = $current_time->setTime( $hour, $minute, 0 )->getTimestamp();
        }
        $report['selected_today']       = pmcpc_should_publish_daily_commerce_update_today( $settings );
        $report['daily_run_due_now']    = $report['selected_today'] && ( $today_target <= $now );
        $report['daily_run_seen_today'] = $report['last_daily_run_ts'] > 0 && wp_date( 'Ymd', $report['last_daily_run_ts'] ) === wp_date( 'Ymd', $now );

        if ( ! $report['next_daily_run_ts'] ) {
            $report['status']   = 'problem';
            $report['summary']  = __( 'Daily highlights are turned on, but no cron run is scheduled.', 'product-mailer-campaigns' );
            $report['messages'][] = __( 'Save the page once, then recheck this screen. If it still shows no schedule, WordPress cron may not be available on this site.', 'product-mailer-campaigns' );
        } elseif ( $report['next_daily_run_ts'] < ( $now - HOUR_IN_SECONDS ) ) {
            $report['status']   = 'problem';
            $report['summary']  = __( 'The next daily highlights run is overdue.', 'product-mailer-campaigns' );
            $report['messages'][] = __( 'This usually means WordPress cron is not firing, so the daily update job is waiting in the past instead of running on time.', 'product-mailer-campaigns' );
        } elseif ( $report['daily_run_due_now'] && ! $report['daily_run_seen_today'] ) {
            $report['status']   = 'warning';
            $report['summary']  = __( 'Today\'s daily highlights run looks missed.', 'product-mailer-campaigns' );
            $report['messages'][] = __( 'The scheduled publish time for today has already passed, but no daily update was recorded.', 'product-mailer-campaigns' );
            $report['messages'][] = __( 'Use Repair schedule to refresh the cron event, or Run daily now to test the workflow immediately.', 'product-mailer-campaigns' );
        }

        if ( 0 === $report['last_daily_run_ts'] ) {
            $report['messages'][] = __( 'No daily highlights post has been recorded yet.', 'product-mailer-campaigns' );
        } else {
            $report['messages'][] = sprintf( __( 'Last daily highlights post: %s', 'product-mailer-campaigns' ), $report['last_daily_run_local'] );
        }

        if ( '' !== $report['next_daily_run_local'] ) {
            $report['messages'][] = sprintf( __( 'Next scheduled daily run: %s', 'product-mailer-campaigns' ), $report['next_daily_run_local'] );
        }
    } else {
        $report['summary']    = __( 'Daily highlights are turned off.', 'product-mailer-campaigns' );
        $report['messages'][] = __( 'Turn on Daily shop highlights if you want one automatic WooCommerce update per day.', 'product-mailer-campaigns' );
    }

    if ( $report['new_arrivals_enabled'] ) {
        if ( $report['last_new_arrival_ts'] > 0 ) {
            $report['messages'][] = sprintf( __( 'Last new-arrivals post: %s', 'product-mailer-campaigns' ), $report['last_new_arrival_local'] );
        } else {
            $report['messages'][] = __( 'New arrivals are turned on, but no new-arrivals post has been recorded yet.', 'product-mailer-campaigns' );
        }
    }

    if ( $report['cron_disabled'] ) {
        $report['status'] = 'warning' === $report['status'] ? 'warning' : ( 'problem' === $report['status'] ? 'problem' : 'warning' );
        $report['messages'][] = __( 'DISABLE_WP_CRON is turned on. That is fine only if your server is running WordPress cron another way.', 'product-mailer-campaigns' );
    }

    return $report;
}

/**
 * Render a publishing health panel for Subscriber Updates.
 *
 * @param array|null $settings Optional settings array.
 * @param bool       $compact  Whether to render a compact panel for the log page.
 * @return void
 */
function pmcpc_render_subscriber_updates_health_notice( $settings = null, $compact = false ) {
    $report = pmcpc_get_subscriber_updates_health_report( $settings );

    $border_color = '#c3d9ff';
    $background   = '#f8fbff';
    $title        = __( 'Publishing health check', 'product-mailer-campaigns' );

    if ( 'warning' === $report['status'] ) {
        $border_color = '#f0c36d';
        $background   = '#fff9e8';
        $title        = __( 'Publishing needs a check', 'product-mailer-campaigns' );
    } elseif ( 'problem' === $report['status'] ) {
        $border_color = '#e28a8a';
        $background   = '#fff1f1';
        $title        = __( 'Publishing needs attention', 'product-mailer-campaigns' );
    }

    echo '<div class="pmcpc-card" style="margin:0 0 20px;max-width:' . ( $compact ? '100%' : '920px' ) . ';background:' . esc_attr( $background ) . ';border-color:' . esc_attr( $border_color ) . ';">';
    echo '<strong>' . esc_html( $title ) . '</strong><br>';
    echo '<span style="display:block;margin:8px 0 0;">' . esc_html( $report['summary'] ) . '</span>';

    if ( ! empty( $report['messages'] ) ) {
        echo '<ul style="margin:10px 0 0 18px;">';
        foreach ( $report['messages'] as $message ) {
            echo '<li>' . esc_html( $message ) . '</li>';
        }
        echo '</ul>';
    }

    echo '<p style="margin:12px 0 0;">';
    echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=pmcpc_diagnostics' ) ) . '">' . esc_html__( 'Open Health Check', 'product-mailer-campaigns' ) . '</a>';
    echo ' <a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=pmcpc-publishing-log' ) ) . '">' . esc_html__( 'Open Publishing Log', 'product-mailer-campaigns' ) . '</a>';
    echo ' <span style="display:inline-block;margin-left:10px;color:#50575e;">' . esc_html__( 'Use Run cron test below to force wp-cron.php and see the exact result. The test now shows the current site time and the exact due second if the event is scheduled later in the same minute.', 'product-mailer-campaigns' ) . '</span>';
    echo '</p>';
    echo '</div>';
}

/**
 * Publish a Subscriber Update for a newly published WooCommerce product.
 *
 * @param int $product_id Product ID.
 * @return int Update post ID or 0.
 */
function pmcpc_publish_new_product_arrival_update( $product_id ) {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return 0;
    }

    $product_id = absint( $product_id );
    if ( ! $product_id || 'product' !== get_post_type( $product_id ) || 'publish' !== get_post_status( $product_id ) ) {
        return 0;
    }

    $settings = get_option( 'pmcpc_sub_updates_settings', array() );
    if ( ! is_array( $settings ) ) {
        $settings = array();
    }
    if ( empty( $settings['enabled'] ) || empty( $settings['commerce_new_product_enabled'] ) ) {
        return 0;
    }

    $existing = get_posts(
        array(
            'post_type'      => 'pmcpc_sub_update',
            'post_status'    => array( 'publish', 'draft', 'private' ),
            'posts_per_page' => 1,
            'meta_key'       => '_pmcpc_new_arrival_product_id',
            'meta_value'     => $product_id,
            'fields'         => 'ids',
        )
    );
    if ( ! empty( $existing ) ) {
        return (int) $existing[0];
    }

    if ( empty( $settings['page_id'] ) && ! empty( $settings['auto_create_page'] ) ) {
        $existing_page = get_page_by_path( 'subscriber-updates' );
        if ( $existing_page instanceof WP_Post ) {
            update_option( 'pmcpc_sub_updates_page_id', (int) $existing_page->ID, false );
        }
    }

    $evaluation = pmcpc_evaluate_commerce_product_for_updates( $product_id, $settings, 'new_arrival' );
    if ( empty( $evaluation['allowed'] ) ) {
        return 0;
    }

    $product = wc_get_product( $product_id );
    if ( ! $product ) {
        return 0;
    }

    $post_status = isset( $settings['post_status'] ) && in_array( $settings['post_status'], array( 'publish', 'draft', 'private' ), true ) ? $settings['post_status'] : 'publish';
    $prefix = ! empty( $settings['commerce_title_prefix'] ) ? sanitize_text_field( (string) $settings['commerce_title_prefix'] ) : __( 'New arrival', 'product-mailer-campaigns' );
    $title  = sprintf( '%s: %s', $prefix, get_the_title( $product_id ) );

    $postarr = array(
        'post_type'    => 'pmcpc_sub_update',
        'post_title'   => $title,
        'post_excerpt' => wp_trim_words( wp_strip_all_tags( (string) get_post_field( 'post_content', $product_id ) ), 28 ),
        'post_status'  => $post_status,
        'post_content' => '',
    );
    $update_id = wp_insert_post( wp_slash( $postarr ), true );
    if ( ! $update_id || is_wp_error( $update_id ) ) {
        return 0;
    }

    $intro = '<p>' . esc_html__( 'A newly arrived item has just been added to your shop.', 'product-mailer-campaigns' ) . '</p>';
    $intro .= '<p>' . esc_html( get_the_title( $product_id ) ) . '</p>';
    $body = $intro . pmcpc_render_commerce_update_body( array( get_post( $product_id ) ), isset( $settings['commerce_cta_label'] ) ? (string) $settings['commerce_cta_label'] : '', (int) $update_id );
    wp_update_post( array( 'ID' => $update_id, 'post_content' => wp_kses_post( $body ) ) );

    update_post_meta( $update_id, '_pmcpc_new_arrival_product_id', $product_id );
    update_post_meta( $update_id, '_pmcpc_publish_key', 'new-arrival-' . $product_id );
    update_post_meta( $update_id, '_pmcpc_source_type', 'commerce_new_product' );
    update_post_meta( $update_id, '_pmcpc_source_trigger', 'woo_new_product' );
    update_post_meta( $update_id, '_pmcpc_product_click_count', 0 );
    update_post_meta( $update_id, '_pmcpc_cta_label', sanitize_text_field( (string) ( $settings['commerce_cta_label'] ?? __( 'Shop now', 'product-mailer-campaigns' ) ) ) );
    update_post_meta( $update_id, '_pmcpc_product_ids', (string) $product_id );
    pmcpc_maybe_apply_generated_update_expiry( $update_id, $settings );
    $hero = get_the_post_thumbnail_url( $product_id, 'large' );
    if ( $hero ) {
        update_post_meta( $update_id, '_pmcpc_image_url', esc_url_raw( $hero ) );
    }
    $topic = ! empty( $settings['commerce_topic'] ) ? sanitize_text_field( (string) $settings['commerce_topic'] ) : __( 'New arrivals', 'product-mailer-campaigns' );
    wp_set_post_terms( $update_id, array( $topic ), 'pmcpc_update_topic', false );

    if ( function_exists( 'pmcpc_flush_subscriber_updates_cache' ) ) {
        pmcpc_flush_subscriber_updates_cache( (int) $update_id );
    }

    return (int) $update_id;
}

/**
 * Create a new-arrivals update when a WooCommerce product is first published.
 *
 * @param string  $new_status New status.
 * @param string  $old_status Old status.
 * @param WP_Post $post       Post object.
 * @return void
 */
function pmcpc_maybe_publish_new_product_arrival_update( $new_status, $old_status, $post ) {
    if ( ! ( $post instanceof WP_Post ) || 'product' !== $post->post_type ) {
        return;
    }
    if ( 'publish' !== $new_status || 'publish' === $old_status ) {
        return;
    }
    if ( wp_is_post_revision( $post->ID ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
        return;
    }
    pmcpc_publish_new_product_arrival_update( (int) $post->ID );
}

/**
 * Publish a WooCommerce-powered Subscriber Update once per day.
 *
 * @return void
 */
function pmcpc_publish_daily_commerce_update() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return;
    }

    $settings = get_option( 'pmcpc_sub_updates_settings', array() );
    if ( ! is_array( $settings ) ) {
        $settings = array();
    }

    if ( empty( $settings['enabled'] ) || empty( $settings['commerce_auto_enabled'] ) ) {
        return;
    }

    if ( ! pmcpc_should_publish_daily_commerce_update_today( $settings ) ) {
        return;
    }

    if ( empty( $settings['page_id'] ) && ! empty( $settings['auto_create_page'] ) ) {
        $existing_page = get_page_by_path( 'subscriber-updates' );
        if ( $existing_page instanceof WP_Post ) {
            update_option( 'pmcpc_sub_updates_page_id', (int) $existing_page->ID, false );
            $settings['page_id'] = (int) $existing_page->ID;
        } else {
            $page_id = wp_insert_post(
                array(
                    'post_title'   => __( 'Updates', 'product-mailer-campaigns' ),
                    'post_name'    => 'subscriber-updates',
                    'post_type'    => 'page',
                    'post_status'  => 'publish',
                    'post_content' => '[pmcpc_sub_updates]',
                )
            );
            if ( $page_id && ! is_wp_error( $page_id ) ) {
                update_option( 'pmcpc_sub_updates_page_id', (int) $page_id, false );
                $settings['page_id'] = (int) $page_id;
            }
        }
    }

    $mode  = isset( $settings['commerce_mode'] ) && 'featured' === $settings['commerce_mode'] ? 'featured' : 'latest';
    $limit = isset( $settings['commerce_limit'] ) ? max( 1, min( 12, absint( $settings['commerce_limit'] ) ) ) : 4;
    $day_key = function_exists( 'wp_date' ) ? wp_date( 'Ymd' ) : gmdate( 'Ymd' );
    $publish_key = 'woo-' . $mode . '-' . $day_key;

    $existing = get_posts(
        array(
            'post_type'      => 'pmcpc_sub_update',
            'post_status'    => array( 'publish', 'draft', 'private' ),
            'posts_per_page' => 1,
            'meta_key'       => '_pmcpc_publish_key',
            'meta_value'     => $publish_key,
            'fields'         => 'ids',
        )
    );

    $selection = pmcpc_get_commerce_products_for_subscriber_update( $settings, $limit, 'daily' );
    $products  = ! empty( $selection['included'] ) ? $selection['included'] : array();
    if ( empty( $products ) ) {
        return;
    }

    $title = ! empty( $settings['commerce_title_prefix'] ) ? sanitize_text_field( (string) $settings['commerce_title_prefix'] ) : ( 'featured' === $mode ? __( 'Featured pieces this week', 'product-mailer-campaigns' ) : __( 'New arrivals this week', 'product-mailer-campaigns' ) );
    $title .= ' — ' . ( function_exists( 'wp_date' ) ? wp_date( get_option( 'date_format', 'j F Y' ) ) : gmdate( 'j F Y' ) );

    $post_status = isset( $settings['post_status'] ) && in_array( $settings['post_status'], array( 'publish', 'draft', 'private' ), true ) ? $settings['post_status'] : 'publish';

    $postarr = array(
        'post_type'    => 'pmcpc_sub_update',
        'post_title'   => $title,
        'post_excerpt' => wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $products[0]->ID ) ), 28 ),
        'post_status'  => $post_status,
        'post_content' => '',
    );

    $update_id = ! empty( $existing ) ? (int) $existing[0] : 0;
    if ( $update_id > 0 ) {
        $postarr['ID'] = $update_id;
        $update_id = wp_update_post( wp_slash( $postarr ), true );
    } else {
        $update_id = wp_insert_post( wp_slash( $postarr ), true );
    }

    if ( ! $update_id || is_wp_error( $update_id ) ) {
        return;
    }

    $body = pmcpc_render_commerce_update_body( $products, isset( $settings['commerce_cta_label'] ) ? (string) $settings['commerce_cta_label'] : '', (int) $update_id );
    wp_update_post( array( 'ID' => $update_id, 'post_content' => wp_kses_post( $body ) ) );

    update_post_meta( $update_id, '_pmcpc_publish_key', sanitize_text_field( $publish_key ) );
    update_post_meta( $update_id, '_pmcpc_source_type', 'commerce_automation' );
    update_post_meta( $update_id, '_pmcpc_source_trigger', 'woo_' . $mode );
    update_post_meta( $update_id, '_pmcpc_product_click_count', (int) get_post_meta( $update_id, '_pmcpc_product_click_count', true ) );
    update_post_meta( $update_id, '_pmcpc_cta_label', sanitize_text_field( (string) ( $settings['commerce_cta_label'] ?? __( 'Shop now', 'product-mailer-campaigns' ) ) ) );
    if ( ! empty( $products[0] ) ) {
        $hero = get_the_post_thumbnail_url( $products[0]->ID, 'large' );
        if ( $hero ) {
            update_post_meta( $update_id, '_pmcpc_image_url', esc_url_raw( $hero ) );
        }
    }
    $topic = ! empty( $settings['commerce_topic'] ) ? sanitize_text_field( (string) $settings['commerce_topic'] ) : __( 'New arrivals', 'product-mailer-campaigns' );
    wp_set_post_terms( $update_id, array( $topic ), 'pmcpc_update_topic', false );

    $product_ids = array();
    foreach ( $products as $product_post ) {
        $product_ids[] = absint( $product_post->ID );
    }
    update_post_meta( $update_id, '_pmcpc_product_ids', implode( ',', array_filter( $product_ids ) ) );
    pmcpc_maybe_apply_generated_update_expiry( $update_id, $settings );

    if ( function_exists( 'pmcpc_flush_subscriber_updates_cache' ) ) {
        pmcpc_flush_subscriber_updates_cache( (int) $update_id );
    }
}

/**
 * Keep the daily commerce update cron in sync with settings.
 *
 * @return void
 */
function pmcpc_sync_daily_commerce_update_schedule() {
    $settings = get_option( 'pmcpc_sub_updates_settings', array() );
    $enabled  = is_array( $settings ) && ! empty( $settings['enabled'] ) && ! empty( $settings['commerce_auto_enabled'] );
    $next = wp_next_scheduled( 'pmcpc_daily_commerce_update' );
    $target = pmcpc_get_daily_commerce_schedule_timestamp( is_array( $settings ) ? $settings : array() );
    if ( $enabled ) {
        if ( ! $next ) {
            wp_schedule_event( $target, 'daily', 'pmcpc_daily_commerce_update' );
        } else {
            $hour_changed = absint( wp_date( 'G', $next ) ) !== absint( $settings['daily_publish_hour'] ?? 9 );
            $minute_changed = absint( wp_date( 'i', $next ) ) !== absint( $settings['daily_publish_minute'] ?? 0 );
            if ( $hour_changed || $minute_changed ) {
                wp_clear_scheduled_hook( 'pmcpc_daily_commerce_update' );
                wp_schedule_event( $target, 'daily', 'pmcpc_daily_commerce_update' );
            }
        }
    } elseif ( $next ) {
        wp_clear_scheduled_hook( 'pmcpc_daily_commerce_update' );
    }
}

/**
 * Track product clicks from subscriber updates and keep lightweight attribution cookies.
 *
 * @return void
 */
function pmcpc_maybe_handle_subscriber_update_product_click() {
    if ( empty( $_GET['pmcpc_update_product'] ) || empty( $_GET['pmcpc_product_id'] ) || empty( $_GET['pmcpc_target'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        return;
    }
    $update_id   = absint( wp_unslash( $_GET['pmcpc_update_product'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $product_id  = absint( wp_unslash( $_GET['pmcpc_product_id'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $target      = esc_url_raw( rawurldecode( (string) wp_unslash( $_GET['pmcpc_target'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if ( ! $update_id || ! $product_id || '' === $target ) {
        return;
    }
    update_post_meta( $update_id, '_pmcpc_product_click_count', (int) get_post_meta( $update_id, '_pmcpc_product_click_count', true ) + 1 );
    if ( function_exists( 'pmcpc_record_subscriber_update_event' ) ) {
        pmcpc_record_subscriber_update_event( $update_id, 'product_click' );
    }
    $payload = array(
        'update_id'   => $update_id,
        'campaign_id' => absint( get_post_meta( $update_id, '_pmcpc_campaign_id', true ) ),
        'product_id'  => $product_id,
        'ts'          => current_time( 'timestamp' ),
    );
    $cookie = wp_json_encode( $payload );
    setcookie( 'pmcpc_last_product_click', rawurlencode( (string) $cookie ), time() + ( 7 * DAY_IN_SECONDS ), COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
    $_COOKIE['pmcpc_last_product_click'] = rawurlencode( (string) $cookie );
    wp_safe_redirect( $target );
    exit;
}

/**
 * Persist product-click attribution to WooCommerce orders when available.
 *
 * @param int $order_id Order ID.
 * @return void
 */
function pmcpc_capture_order_product_click_attribution( $order_id ) {
    $order_id = absint( $order_id );
    if ( ! $order_id || empty( $_COOKIE['pmcpc_last_product_click'] ) ) {
        return;
    }
    $raw = rawurldecode( (string) wp_unslash( $_COOKIE['pmcpc_last_product_click'] ) );
    $data = json_decode( $raw, true );
    if ( empty( $data ) || ! is_array( $data ) ) {
        return;
    }
    $ts = isset( $data['ts'] ) ? absint( $data['ts'] ) : 0;
    if ( ! $ts || $ts < ( current_time( 'timestamp' ) - ( 7 * DAY_IN_SECONDS ) ) ) {
        return;
    }
    if ( ! empty( $data['update_id'] ) ) {
        update_post_meta( $order_id, '_pmcpc_attributed_update_id', absint( $data['update_id'] ) );
    }
    if ( ! empty( $data['campaign_id'] ) ) {
        update_post_meta( $order_id, '_pmcpc_attributed_campaign_id', absint( $data['campaign_id'] ) );
    }
    if ( ! empty( $data['product_id'] ) ) {
        update_post_meta( $order_id, '_pmcpc_attributed_product_id', absint( $data['product_id'] ) );
    }
    update_post_meta( $order_id, '_pmcpc_attributed_source', 'subscriber_update_product_click' );
}

/**
 * Persist direct FlowPress email-click attribution onto WooCommerce orders.
 *
 * This covers normal campaign and automation clicks so revenue reporting does
 * not have to rely only on fallback email-event matching.
 *
 * @param int $order_id Order ID.
 * @return void
 */
function pmcpc_capture_order_email_click_attribution( $order_id ) {
    $order_id = absint( $order_id );
    if ( ! $order_id || empty( $_COOKIE['pmcpc_last_email_click'] ) ) {
        return;
    }

    if ( ! function_exists( 'wc_get_order' ) ) {
        return;
    }

    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        return;
    }

    // Preserve richer attribution that may already exist from other flows.
    if ( $order->get_meta( '_pmcpc_attributed_campaign_id', true ) || $order->get_meta( '_pmcpc_attributed_update_id', true ) ) {
        return;
    }

    $raw  = rawurldecode( (string) wp_unslash( $_COOKIE['pmcpc_last_email_click'] ) );
    $data = json_decode( $raw, true );
    if ( empty( $data ) || ! is_array( $data ) ) {
        return;
    }

    $ts = isset( $data['ts'] ) ? absint( $data['ts'] ) : 0;
    if ( ! $ts || $ts < ( current_time( 'timestamp' ) - ( 7 * DAY_IN_SECONDS ) ) ) {
        return;
    }

    $campaign_id      = isset( $data['campaign_id'] ) ? absint( $data['campaign_id'] ) : 0;
    $queue_id         = isset( $data['queue_id'] ) ? absint( $data['queue_id'] ) : 0;
    $subscriber_id    = isset( $data['subscriber_id'] ) ? absint( $data['subscriber_id'] ) : 0;
    $subscriber_email = isset( $data['subscriber_email'] ) ? sanitize_email( strtolower( (string) $data['subscriber_email'] ) ) : '';

    if ( $campaign_id <= 0 || '' === $subscriber_email ) {
        return;
    }

    $billing_email = sanitize_email( strtolower( (string) $order->get_billing_email() ) );
    if ( '' === $billing_email || $billing_email !== $subscriber_email ) {
        return;
    }

    update_post_meta( $order_id, '_pmcpc_attributed_campaign_id', $campaign_id );
    if ( $queue_id > 0 ) {
        update_post_meta( $order_id, '_pmcpc_attributed_queue_id', $queue_id );
    }
    if ( $subscriber_id > 0 ) {
        update_post_meta( $order_id, '_pmcpc_attributed_subscriber_id', $subscriber_id );
    }
    update_post_meta( $order_id, '_pmcpc_attributed_email', $subscriber_email );
    update_post_meta( $order_id, '_pmcpc_attributed_source', 'flowpress_email_click' );

    // One click should only attribute the next matching order.
    setcookie( 'pmcpc_last_email_click', '', time() - HOUR_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
    unset( $_COOKIE['pmcpc_last_email_click'] );
}
