
document.addEventListener('DOMContentLoaded', function() {
    var popup = document.getElementById('pmcpc-popup');
    if (!popup) return;

    // Config (defaults can be overridden via wp_localize_script).
    var cfg = window.pmcpcPopupConfig || {};
    var delayMs = typeof cfg.delayMs === 'number' ? cfg.delayMs : 3000; // delay before showing
    var storageKey = 'pmcPopupLastDismissed';
    var daysBetween = typeof cfg.daysBetween === 'number' ? cfg.daysBetween : 7; // only show once every N days

    function shouldShow() {
        try {
            var last = localStorage.getItem(storageKey);
            if (!last) return true;
            var lastTime = parseInt(last, 10);
            if (!lastTime) return true;
            var diffMs = Date.now() - lastTime;
            var diffDays = diffMs / 1000 / 60 / 60 / 24;
            return diffDays >= daysBetween;
        } catch (e) {
            return true;
        }
    }

    function rememberDismiss() {
        try {
            localStorage.setItem(storageKey, String(Date.now()));
        } catch (e) {}
    }

    function showPopup() {
        if (!shouldShow()) return;
        popup.style.display = 'block';
    }

    setTimeout(showPopup, delayMs);

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('pmcpc-popup-close') || e.target.id === 'pmcpc-popup') {
            popup.style.display = 'none';
            rememberDismiss();
        }
    });
});
