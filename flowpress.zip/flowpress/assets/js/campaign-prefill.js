(function () {
  'use strict';

  var cfg = window.pmcpcCampaignPrefill || {};

  function safeLower(v) { return (v || '').toString().toLowerCase(); }
  function isBlank(val) { return !(val || '').toString().trim(); }
  function stripTags(html) {
    return (html || '').toString().replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function isSample(html) {
    var t = safeLower(stripTags(html));
    return (t.indexOf('this is a sample campaign') !== -1) || (t.indexOf('you can customize this message') !== -1);
  }

  function qs(name) {
    return document.querySelector('[name="' + name + '"]');
  }
  function getEditor() {
    try {
      return (window.tinymce && window.tinymce.get) ? window.tinymce.get('pmcpc_content') : null;
    } catch (e) {
      return null;
    }
  }

  function getChosenTemplateIdFromUrl() {
    try {
      var p = new URLSearchParams(window.location.search);
      return p.get('pmcpc_template') || p.get('pmcpc_template_id') || '';
    } catch (e) {
      return '';
    }
  }

  function getChosenTemplateId() {
    // Persist template choice across wizard steps (the base wizard often drops extra query args).
    var tid = getChosenTemplateIdFromUrl();
    if (tid) {
      try { sessionStorage.setItem('pmcpc_chosen_template', tid); } catch (e) {}
      return tid;
    }
    try { return sessionStorage.getItem('pmcpc_chosen_template') || ''; } catch (e2) { return ''; }
  }

  function shouldForceTemplate() {
    try {
      var p = new URLSearchParams(window.location.search);
      if (p.get('pmcpc_pro_shortcut') === '1') return true;
      if (p.get('pmcpc_template') || p.get('pmcpc_template_id')) return true;
    } catch (e) {}
    return !!getChosenTemplateId();
  }

  function pickTemplateSettings() {
    var all = cfg.allTemplates || {};
    var tmpl = cfg.defaultTmpl || {};
    var tid = getChosenTemplateId();
    if (tid && all && all[tid]) tmpl = all[tid];
    return tmpl;
  }

  function computeDefaults() {
    var params;
    try { params = new URLSearchParams(window.location.search); } catch (e) { params = null; }

    var trigger = params ? safeLower(params.get('trigger')) : '';
    var hint = params ? safeLower(params.get('automation_hint')) : '';
    if (!trigger && hint) trigger = hint;

    var seg = params ? safeLower(params.get('pro_segment_key') || params.get('segment_key') || params.get('segment')) : '';
    var siteName = cfg.siteName || '';

    var triggerLabel = trigger ? trigger.replace(/[_-]/g, ' ') : 'Campaign';
    var segmentLabel = seg ? seg.replace(/[_-]/g, ' ') : '';

    var defName = '';
    if (trigger && segmentLabel) defName = 'Automation: ' + triggerLabel + ' · ' + segmentLabel;
    else if (trigger) defName = 'Automation: ' + triggerLabel;
    else if (segmentLabel) defName = 'Segment: ' + segmentLabel;
    else defName = 'Campaign: ' + siteName;

    var audience = (trigger + ' ' + hint + ' ' + segmentLabel).trim();

    // Subjects + body copy (one per trigger) — refined, brand-safe defaults.
    var defSubject = 'An update from ' + siteName;
    var body = '';

    switch (trigger) {
      case 'new_subscriber':
        defSubject = 'Welcome to ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>Thank you for joining our mailing list. Below is a small curated selection we think you may enjoy.</p>'
          + '<p>{{products_block}}</p>'
          + '<p>Warm regards,<br>' + siteName + '</p>';
        break;

      case 'new_customer':
        defSubject = 'Thank you for your first order — ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>Thank you for your order. Your order reference is {{order_id}}. If you would like to continue browsing, here are a few pieces that may complement your selection.</p>'
          + '<p>{{products_block}}</p>'
          + '<p>With thanks,<br>' + siteName + '</p>';
        break;

      case 'repeat_customer':
        defSubject = 'A sincere thank you — ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>Thank you for returning. Your recent order reference is {{order_id}}. We have selected a few recent arrivals you may wish to see.</p>'
          + '<p>{{products_block}}</p>'
          + '<p>Warm regards,<br>' + siteName + '</p>';
        break;

      case 'post_purchase':
        defSubject = 'Thank you for your order — ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>We hope you enjoy your purchase. Your order reference is {{order_id}}. If you would like to continue browsing, here is a small selection that may be of interest.</p>'
          + '<p>{{products_block}}</p>'
          + '<p>With thanks,<br>' + siteName + '</p>';
        break;

      case 'review_request':
        defSubject = 'A small favour — ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>If you are enjoying your purchase, we would be grateful if you could leave a short review. Your feedback helps other customers shop with confidence.</p>'
          + '<p>{{review_stars_block}}</p>'
          + '<p><a href="{{review_url}}">Leave a review</a></p>'
          + '<p>Thank you for supporting our small business.</p>'
          + '<p>Warm regards,<br>' + siteName + '</p>';
        break;

      case 'customer_inactive':
        defSubject = 'A few new arrivals you may like — ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>It has been a little while since your last visit. We have recently added a number of pieces we thought you may enjoy.</p>'
          + '<p>{{products_block}}</p>'
          + '<p>Warm regards,<br>' + siteName + '</p>';
        break;

      case 'high_value':
        defSubject = 'Early access — ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>As one of our most valued customers, we wanted to share a few recent arrivals with you first.</p>'
          + '<p>{{products_block}}</p>'
          + '<p>Warm regards,<br>' + siteName + '</p>';
        break;

      case 'abandoned_cart_step_1':
        defSubject = 'A quick note about your cart — ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>You recently added items to your cart but didn\'t complete checkout. If you would like to continue, your saved cart is below.</p>'
          + '<div>{{cart_items}}</div>'
          + '<p><strong>Cart total:</strong> {{cart_total}}</p>'
          + '<p><a href="{{cart_url}}">Resume checkout</a></p>'
          + '<p>Warm regards,<br>' + siteName + '</p>';
        break;

      case 'abandoned_cart_step_2':
        defSubject = 'Still considering? — ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>If you have any questions about condition, measurements, or delivery, simply reply to this email and we\'ll be happy to help.</p>'
          + '<div>{{cart_items}}</div>'
          + '<p><strong>Cart total:</strong> {{cart_total}}</p>'
          + '<p><a href="{{cart_url}}">Return to your cart</a></p>'
          + '<p>Warm regards,<br>' + siteName + '</p>';
        break;

      case 'abandoned_cart_step_3':
        defSubject = 'Final reminder — ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>As many of our pieces are one-of-a-kind, availability can change quickly. If you would like to complete your purchase, you can do so below.</p>'
          + '<div>{{cart_items}}</div>'
          + '<p><strong>Cart total:</strong> {{cart_total}}</p>'
          + '<p><a href="{{cart_url}}">Complete checkout</a></p>'
          + '<p>Warm regards,<br>' + siteName + '</p>';
        break;

      case 'date':
        defSubject = 'An update from ' + siteName;
        body = '<p>Dear {{first_name}},</p>'
          + '<p>We are pleased to share a small curated selection for you.</p>'
          + '<p>{{products_block}}</p>'
          + '<p>Warm regards,<br>' + siteName + '</p>';
        break;

      default:
        // Heuristic fallback.
        if (audience.indexOf('welcome') !== -1) {
          defSubject = 'Welcome to ' + siteName;
          body = '<p>Dear {{first_name}},</p>'
            + '<p>Thank you for joining ' + siteName + '. Here are a few pieces you might like:</p>'
            + '<p>{{products_block}}</p>'
            + '<p>Warm regards,<br>' + siteName + '</p>';
        } else if (audience.indexOf('post_purchase') !== -1 || audience.indexOf('post purchase') !== -1) {
          defSubject = 'Thank you for your order — ' + siteName;
          body = '<p>Dear {{first_name}},</p>'
            + '<p>Thank you for your recent order from ' + siteName + '.</p>'
            + '<p>Here are a few more items you might like:</p>'
            + '<p>{{products_block}}</p>'
            + '<p>Warm regards,<br>' + siteName + '</p>';
        } else if (audience.indexOf('lapsed') !== -1 || audience.indexOf('inactive') !== -1) {
          defSubject = 'A few new arrivals you may like — ' + siteName;
          body = '<p>Dear {{first_name}},</p>'
            + '<p>We\'ve selected a few new pieces you may enjoy.</p>'
            + '<p>{{products_block}}</p>'
            + '<p>Warm regards,<br>' + siteName + '</p>';
        } else {
          body = '<p>Dear {{first_name}},</p>'
            + '<p>A few freshly listed pieces we thought you might love.</p>'
            + '<p>{{products_block}}</p>'
            + '<p>Warm regards,<br>' + siteName + '</p>';
        }
        break;
    }

    var tmpl = pickTemplateSettings();
    var h = (tmpl && tmpl.header_html) ? tmpl.header_html : '';
    var logo = (tmpl && tmpl.logo_url) ? tmpl.logo_url : '';
    var accent = (tmpl && tmpl.accent_color) ? tmpl.accent_color : '#1d4ed8';

    var logoHtml = logo
      ? ('<img src="' + logo + '" alt="' + siteName + '" style="max-width:180px;height:auto;display:block;" />')
      : siteName;

    function replaceTokens(html) {
      return (html || '')
        .replace(/\{\{accent\}\}/g, accent).replace(/\{accent\}/g, accent)
        .replace(/\{\{site_name\}\}/g, siteName)
        .replace(/\{\{logo_html\}\}/g, logoHtml)
        .replace(/\{\{logo_url\}\}/g, logo);
    }

    var out = '';
    if (h && (h.indexOf('{pmcpc_body}') !== -1 || h.indexOf('{{pmcpc_body}}') !== -1)) {
      // Legacy wrapper mode: insert computed body into placeholder.
      out = h.replace(/\{\{pmcpc_body\}\}/g, body).replace(/\{pmcpc_body\}/g, body);
      out = replaceTokens(out);
    } else if (h && !isBlank(h)) {
      // Template mode: this HTML is inserted directly into the campaign.
      out = replaceTokens(h);
    } else {
      // Final fallback: basic email.
      out = replaceTokens(body);
    }

    return { name: defName, subject: defSubject, content: out };
  }

  function applyIfReady() {
    try {
      var storedName = sessionStorage.getItem('pmcpc_prefill_name') || '';
      var storedSubject = sessionStorage.getItem('pmcpc_prefill_subject') || '';
      var storedContent = sessionStorage.getItem('pmcpc_prefill_content') || '';

      var doneName = sessionStorage.getItem('pmcpc_prefill_done_name') === '1';
      var doneSubject = sessionStorage.getItem('pmcpc_prefill_done_subject') === '1';
      var doneContent = sessionStorage.getItem('pmcpc_prefill_done_content') === '1';

      var nameEl = qs('name');
      if (!doneName && nameEl && storedName && isBlank(nameEl.value)) {
        nameEl.value = storedName;
        try { nameEl.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
        sessionStorage.setItem('pmcpc_prefill_done_name', '1');
        doneName = true;
      }

      var subjectEl = qs('subject');
      if (!doneSubject && subjectEl && storedSubject && isBlank(subjectEl.value)) {
        subjectEl.value = storedSubject;
        try { subjectEl.dispatchEvent(new Event('input', { bubbles: true })); } catch (e2) {}
        sessionStorage.setItem('pmcpc_prefill_done_subject', '1');
        doneSubject = true;
      }

      if (!doneContent && storedContent) {
        var forceTemplate = shouldForceTemplate();
        var editor = getEditor();
        var contentEl = qs('content') || document.getElementById('pmcpc_content');
        var current = '';
        try { if (editor) current = editor.getContent({ format: 'raw' }) || ''; } catch (e3) {}
        if (!current && contentEl) current = contentEl.value || '';

        if ((forceTemplate || isBlank(current) || isSample(current)) && contentEl) {
          contentEl.value = storedContent;
          try {
            contentEl.dispatchEvent(new Event('input', { bubbles: true }));
            contentEl.dispatchEvent(new Event('change', { bubbles: true }));
          } catch (e4) {}
        }
        if ((forceTemplate || isBlank(current) || isSample(current)) && editor) {
          try { editor.setContent(storedContent); } catch (e5) {}
        }

        var after = '';
        try { if (editor) after = editor.getContent({ format: 'raw' }) || ''; } catch (e6) {}
        if (!after && contentEl) after = contentEl.value || '';
        if (!isBlank(after)) {
          sessionStorage.setItem('pmcpc_prefill_done_content', '1');
          doneContent = true;
        }
      }

      var wantName = !!storedName;
      var wantSubject = !!storedSubject;
      var wantContent = !!storedContent;
      return (!wantName || doneName) && (!wantSubject || doneSubject) && (!wantContent || doneContent);
    } catch (err) {
      return true;
    }
  }

  try {
    // Reset per-page applied flags for this wizard session.
    sessionStorage.removeItem('pmcpc_prefill_done_name');
    sessionStorage.removeItem('pmcpc_prefill_done_subject');
    sessionStorage.removeItem('pmcpc_prefill_done_content');

    // Capture template choice ASAP.
    getChosenTemplateId();

    // Compute + store defaults once.
    var defaults = computeDefaults();
    if (defaults && defaults.name) sessionStorage.setItem('pmcpc_prefill_name', defaults.name);
    if (defaults && defaults.subject) sessionStorage.setItem('pmcpc_prefill_subject', defaults.subject);
    if (defaults && defaults.content) sessionStorage.setItem('pmcpc_prefill_content', defaults.content);

    var tries = 0;
    var maxTries = 120; // ~30s at 250ms
    var timer = setInterval(function () {
      tries++;
      var done = applyIfReady();
      if (done || tries >= maxTries) clearInterval(timer);
    }, 250);
  } catch (e) {}
})();
