(function(){
  'use strict';

  function el(id){ return document.getElementById(id); }

  function escAttr(s){
    return String(s||'')
      .replace(/&/g,'&amp;')
      .replace(/"/g,'&quot;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;');
  }

  function logoHtml(siteName, logoUrl){
    if (logoUrl) {
      return '<img src="' + escAttr(logoUrl) + '" alt="' + escAttr(siteName||'') + '" style="max-width:180px;height:auto;display:block;" />';
    }
    return '<span>' + (siteName||'') + '</span>';
  }

  // Builds a preview document.
  // Supports two modes:
  // 1) Legacy wrapper mode: HTML includes {pmcpc_body} placeholder and bodyHtml is injected.
  // 2) Campaign-content mode: HTML is the full email content (same as Campaigns -> Email editor).
  function buildPreviewDoc(html, bodyHtml, accent, siteName, logoUrl){
    var w = String(html||'');

    var logo = logoHtml(siteName, logoUrl);

    // Sample products/reviews blocks for previews.
    var products = (window.pmcpcET && window.pmcpcET.productsHtml) ? window.pmcpcET.productsHtml : '';
    var reviews = (window.pmcpcET && window.pmcpcET.reviewsHtml) ? window.pmcpcET.reviewsHtml : '';

    // Body used when in legacy wrapper mode.
    var body = String(bodyHtml||'')
      .replace(/\{\{site_name\}\}/g, siteName)
      .replace(/\{\{accent\}\}/g, accent)
      .replace(/\{accent\}/g, accent)
      .replace(/\{\{logo_html\}\}/g, logo)
      .replace(/\{\{logo_url\}\}/g, logoUrl || '')
      .replace(/\{\{unsubscribe_url\}\}/g, '#')
      .replace(/\{\{products_block\}\}/g, products)
      .replace(/\{products_block\}/g, products)
      .replace(/\{\{reviews_block\}\}/g, reviews)
      .replace(/\{\{reviews\}\}/g, reviews)
      .replace(/\{reviews_block\}/g, reviews);

    // If wrapper mode, inject body. Otherwise treat as full campaign HTML.
    if (w && (w.indexOf('{pmcpc_body}') !== -1 || w.indexOf('{{pmcpc_body}}') !== -1)) {
      w = w.replace(/\{\{pmcpc_body\}\}/g, body).replace(/\{pmcpc_body\}/g, body);
    } else {
      // Full campaign HTML mode
      if (!w) {
        w = '<div style="font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.6;color:#111827;padding:18px;">' + body + '</div>';
      }
    }

    w = w
      .replace(/\{\{accent\}\}/g, accent)
      .replace(/\{accent\}/g, accent)
      .replace(/\{\{site_name\}\}/g, siteName)
      .replace(/\{\{unsubscribe_url\}\}/g, '#')
      .replace(/\{\{logo_url\}\}/g, logoUrl || '')
      .replace(/\{\{logo_html\}\}/g, logo)
      .replace(/\{\{products_block\}\}/g, products)
      .replace(/\{products_block\}/g, products)
      .replace(/\{\{reviews_block\}\}/g, reviews)
      .replace(/\{\{reviews\}\}/g, reviews)
      .replace(/\{reviews_block\}/g, reviews);

    var doc = '<!doctype html><html><head><meta charset="utf-8">' +
      '<meta name="viewport" content="width=device-width, initial-scale=1"></head>' +
      '<body style="margin:0;padding:0;background:#f4f4f4;">' +
      '<div style="padding:16px;display:flex;justify-content:center;">' +
      '<div style="width:100%;max-width:640px;">' + w + '</div></div></body></html>';

    return doc;
  }

  function updatePreview(){
    var iframe = el('pmcpc_template_preview');
    if (!iframe) return;

    // Field IDs come from the PHP admin form.
    // New (transferable) templates use template_html; legacy wrappers use header_html.
    var templateHtml = (el('template_html') && el('template_html').value) || '';
    var wrapper = (el('header_html') && el('header_html').value) || '';
    var accent  = (el('accent_color') && el('accent_color').value) || '#1d4ed8';
    var logoUrl = (el('logo_url') && el('logo_url').value) || '';

    var siteName = (window.pmcpcET && window.pmcpcET.siteName) ? window.pmcpcET.siteName : '';
    var previewBody = (window.pmcpcET && window.pmcpcET.previewBody) ? window.pmcpcET.previewBody : '';

    var doc = buildPreviewDoc(templateHtml || wrapper, previewBody, accent, siteName, logoUrl);

    try {
      iframe.srcdoc = doc;
    } catch (e) {
      try {
        var d = iframe.contentDocument || iframe.contentWindow.document;
        d.open();
        d.write(doc);
        d.close();
      } catch (e2) {}
    }
  }

  function debounce(fn, wait){
    var t;
    return function(){
      var args = arguments;
      clearTimeout(t);
      t = setTimeout(function(){ fn.apply(null, args); }, wait || 250);
    };
  }



  function insertAtCursor(field, value){
    if (!field) return false;
    field.focus();
    var start = typeof field.selectionStart === 'number' ? field.selectionStart : field.value.length;
    var end = typeof field.selectionEnd === 'number' ? field.selectionEnd : start;
    var before = field.value.substring(0, start);
    var after = field.value.substring(end);
    field.value = before + value + after;
    var pos = start + value.length;
    try {
      field.selectionStart = field.selectionEnd = pos;
    } catch(e) {}
    field.dispatchEvent(new Event('input', { bubbles: true }));
    field.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function insertIntoEditor(targetId, value){
    if (targetId === 'pmcpc_content') {
      try {
        if (window.tinymce && tinymce.get(targetId)) {
          tinymce.get(targetId).focus();
          tinymce.get(targetId).execCommand('mceInsertContent', false, value);
          return true;
        }
      } catch(e) {}
    }
    return insertAtCursor(el(targetId), value);
  }

  function bindInsertButtons(){
    var buttons = document.querySelectorAll('[data-pmcpc-insert-target][data-pmcpc-insert-value]');
    if (!buttons || !buttons.length) return;
    Array.prototype.forEach.call(buttons, function(btn){
      btn.addEventListener('click', function(e){
        e.preventDefault();
        var targetId = btn.getAttribute('data-pmcpc-insert-target');
        var value = btn.getAttribute('data-pmcpc-insert-value') || '';
        insertIntoEditor(targetId, value);
      });
    });
  }

  function initColorPicker(){
    if (window.jQuery && window.jQuery.fn && window.jQuery.fn.wpColorPicker) {
      var $ = window.jQuery;
      var $input = $('#accent_color');
      if ($input.length && !$input.data('wpColorPicker')) {
        $input.wpColorPicker({
          change: function(){ setTimeout(updatePreview, 10); },
          clear: function(){ setTimeout(updatePreview, 10); }
        });
      }
    }
  }

  function initMediaPicker(){
    var btn = el('pmcpcLogoPick');
    var clear = el('pmcpcLogoClear');
    var input = el('logo_url');
    var thumb = el('pmcpcLogoThumb');
    if (!btn || !input) return;

    function renderThumb(){
      if (!thumb) return;
      var url = (input.value || '').trim();
      if (url) {
        thumb.innerHTML = '<img src="' + escAttr(url) + '" alt="" />';
      } else {
        thumb.innerHTML = '<div class="pmcpc-et-logo-empty">No logo selected</div>';
      }
    }

    btn.addEventListener('click', function(e){
      e.preventDefault();
      if (!window.wp || !wp.media) return;

      var frame = wp.media({
        title: 'Select logo',
        button: { text: 'Use this logo' },
        multiple: false
      });

      frame.on('select', function(){
        var attachment = frame.state().get('selection').first().toJSON();
        if (attachment && attachment.url) {
          input.value = attachment.url;
          renderThumb();
          updatePreview();
        }
      });

      frame.open();
    });

    if (clear) {
      clear.addEventListener('click', function(e){
        e.preventDefault();
        input.value = '';
        renderThumb();
        updatePreview();
      });
    }

    // Ensure initial state is correct.
    renderThumb();
  }

  function bindLive(){
    var form = el('pmcpc_template_form');
    if (!form) return;

    var dirty = false;
    var dirtyBadge = el('pmcpcEtDirtyBadge');
    var templateId = (window.pmcpcET && pmcpcET.templateId) ? String(pmcpcET.templateId) : (el('pmcpc_template_id') ? String(el('pmcpc_template_id').value||'') : '');
    var updatedAt = (window.pmcpcET && pmcpcET.updatedAt) ? parseInt(pmcpcET.updatedAt, 10) : 0;
    var draftKey = 'pmcpc_et_draft_' + (templateId || 'default');
    var notice = el('pmcpcEtDraftNotice');

    function setDirty(v){
      dirty = !!v;
      if (dirtyBadge) {
        dirtyBadge.style.display = dirty ? 'inline-block' : 'none';
      }
    }

    // Draft helpers (localStorage).
    function snapshot(){
      return {
        label: (el('label') && el('label').value) ? el('label').value : '',
        logo_url: (el('logo_url') && el('logo_url').value) ? el('logo_url').value : '',
        accent_color: (el('accent_color') && el('accent_color').value) ? el('accent_color').value : '',
        header_html: (el('header_html') && el('header_html').value) ? el('header_html').value : '',
        template_html: (el('template_html') && el('template_html').value) ? el('template_html').value : ''
      };
    }

    function applySnapshot(snap){
      if (!snap) return;
      if (el('label') && typeof snap.label === 'string') el('label').value = snap.label;
      if (el('logo_url') && typeof snap.logo_url === 'string') el('logo_url').value = snap.logo_url;
      if (el('accent_color') && typeof snap.accent_color === 'string') el('accent_color').value = snap.accent_color;
      if (el('header_html') && typeof snap.header_html === 'string') el('header_html').value = snap.header_html;
      if (el('template_html') && typeof snap.template_html === 'string') el('template_html').value = snap.template_html;
      setDirty(true);
      setTimeout(updatePreview, 10);
    }

    function sameSnapshot(a,b){
      try {
        return JSON.stringify(a||{}) === JSON.stringify(b||{});
      } catch(e) {
        return false;
      }
    }

    var saveDraft = debounce(function(){
      try {
        var payload = { t: Math.floor(Date.now()/1000), data: snapshot() };
        window.localStorage.setItem(draftKey, JSON.stringify(payload));
      } catch(e) {}
    }, 700);

    function clearDraft(){
      try { window.localStorage.removeItem(draftKey); } catch(e) {}
    }

    function showDraftNotice(draft){
      if (!notice) return;
      notice.style.display = 'block';
      var when = '';
      if (draft && draft.t) {
        var mins = Math.max(1, Math.round((Date.now()/1000 - draft.t)/60));
        when = mins === 1 ? 'a minute ago' : (mins + ' minutes ago');
      }
      notice.innerHTML = '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">' +
        '<div><strong>Unsaved draft found</strong>' + (when ? ' <span style="color:#646970;">(' + when + ')</span>' : '') +
        '<div style="color:#646970;margin-top:2px;">Restore it, or discard and keep the saved version.</div></div>' +
        '<div style="display:flex;gap:8px;">' +
          '<button type="button" class="button button-primary" id="pmcpcEtDraftRestore">Restore</button>' +
          '<button type="button" class="button" id="pmcpcEtDraftDiscard">Discard</button>' +
        '</div>' +
      '</div>';

      var restoreBtn = el('pmcpcEtDraftRestore');
      var discardBtn = el('pmcpcEtDraftDiscard');
      if (restoreBtn) {
        restoreBtn.addEventListener('click', function(e){
          e.preventDefault();
          applySnapshot(draft.data);
          notice.style.display = 'none';
        });
      }
      if (discardBtn) {
        discardBtn.addEventListener('click', function(e){
          e.preventDefault();
          clearDraft();
          notice.style.display = 'none';
        });
      }
    }

    // On load, offer to restore a newer local draft.
    (function(){
      try {
        var raw = window.localStorage.getItem(draftKey);
        if (!raw) return;
        var parsed = JSON.parse(raw);
        if (!parsed || !parsed.data || !parsed.t) return;
        // Only prompt if the draft is newer than the last saved version.
        if (updatedAt && parsed.t <= (updatedAt + 15)) return;
        if (!sameSnapshot(parsed.data, snapshot())) {
          showDraftNotice(parsed);
        }
      } catch(e) {}
    })();

    var schedule = debounce(updatePreview, 250);

    // Any edit to the core fields updates preview.
    form.addEventListener('input', function(e){
      var t = e.target;
      if (!t) return;
      if (t.id === 'label' || t.id === 'logo_url' || t.id === 'accent_color' || t.id === 'header_html' || t.id === 'template_html') {
        schedule();
        setDirty(true);
        saveDraft();
      }
    });

    form.addEventListener('change', function(){
      schedule();
      setDirty(true);
      saveDraft();
    });

    // Warn about navigating away with unsaved changes.
    window.addEventListener('beforeunload', function(e){
      if (!dirty) return;
      e.preventDefault();
      e.returnValue = '';
      return '';
    });

    // Clear the local draft on successful submit.
    form.addEventListener('submit', function(){
      setDirty(false);
      clearDraft();
    });

    // Keep the "Editing" label in sync.
    var label = el('label');
    var editing = el('pmcpcEtEditingLabel');
    if (label && editing) {
      var syncEditing = function(){
        var id = (el('pmcpc_template_id') && el('pmcpc_template_id').value) ? el('pmcpc_template_id').value : '';
        editing.textContent = (label.value || '').trim() || id;
      };
      label.addEventListener('input', syncEditing);
      syncEditing();
    }

    // Initial preview.
    setTimeout(updatePreview, 30);
  }

  function ready(fn){
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  ready(function(){
    initColorPicker();
    initMediaPicker();
    bindLive();
    bindInsertButtons();

    // Save as new (duplicate).
    var saveAsNew = el('pmcpcEtSaveAsNew');
    if (saveAsNew) {
      saveAsNew.addEventListener('click', function(e){
        e.preventDefault();
        var current = (el('label') && el('label').value) ? el('label').value : ((el('pmcpc_template_id') && el('pmcpc_template_id').value) ? el('pmcpc_template_id').value : 'Template');
        var proposed = String(current).trim() ? (String(current).trim() + ' (copy)') : 'Template (copy)';
        var name = window.prompt('New template name:', proposed);
        if (!name) return;

        var hiddenLabel = el('pmcpcEtNewLabel');
        if (hiddenLabel) hiddenLabel.value = name;

        // Ensure pmcpc_action=duplicate is posted.
        var form = el('pmcpc_template_form');
        if (!form) return;
        var existing = form.querySelector('input[name="pmcpc_action"][type="hidden"]');
        if (existing) existing.parentNode.removeChild(existing);
        var action = document.createElement('input');
        action.type = 'hidden';
        action.name = 'pmcpc_action';
        action.value = 'duplicate';
        form.appendChild(action);
        form.submit();
      });
    }

    // Send test email (dropdown panel).
    var sendBtn = el('pmcpcEtSendTestGo');
    var toField = el('pmcpcEtTestTo');
    if (sendBtn) {
      if (toField && window.pmcpcET && pmcpcET.adminEmail && !toField.value) {
        toField.placeholder = pmcpcET.adminEmail;
      }

      sendBtn.addEventListener('click', function(e){
        e.preventDefault();
        if (!window.pmcpcET || !pmcpcET.ajaxUrl || !pmcpcET.sendTestNonce) {
          window.alert('AJAX is not available on this page.');
          return;
        }

        var to = (toField && toField.value) ? String(toField.value).trim() : '';
        if (!to && window.pmcpcET && pmcpcET.adminEmail) {
          to = String(pmcpcET.adminEmail).trim();
        }
        if (!to) {
          window.alert('Please enter an email address.');
          return;
        }

        var subject = 'Test email: ' + (pmcpcET.siteName || '');
        var html = buildPreviewDoc(
          (el('template_html') && el('template_html').value) || (el('header_html') && el('header_html').value) || '',
          (pmcpcET.previewBody || ''),
          (el('accent_color') && el('accent_color').value) || '#1d4ed8',
          (pmcpcET.siteName || ''),
          (el('logo_url') && el('logo_url').value) || ''
        );

        sendBtn.disabled = true;
        var prevText = sendBtn.textContent;
        sendBtn.textContent = 'Sending…';

        var payload = new window.FormData();
        payload.append('action', 'pmcpc_et_send_test');
        payload.append('nonce', pmcpcET.sendTestNonce);
        payload.append('to', to);
        payload.append('subject', subject);
        payload.append('html', html);

        window.fetch(pmcpcET.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: payload })
          .then(function(r){ return r.json(); })
          .then(function(resp){
            if (resp && resp.success) {
              window.alert((resp.data && resp.data.message) ? resp.data.message : 'Test email sent.');
            } else {
              window.alert((resp && resp.data && resp.data.message) ? resp.data.message : 'Could not send test email.');
            }
          })
          .catch(function(){ window.alert('Could not send test email.'); })
          .finally(function(){
            sendBtn.disabled = false;
            sendBtn.textContent = prevText;
          });
      });
    }

    // Confirm before deleting a custom template.
    var deletes = document.querySelectorAll('.pmcpc-et-delete');
    if (deletes && deletes.length) {
      Array.prototype.forEach.call(deletes, function(btn){
        btn.addEventListener('click', function(e){
          var ok = window.confirm('Delete this template? This cannot be undone.');
          if (!ok) {
            e.preventDefault();
            e.stopPropagation();
            return false;
          }
          return true;
        });
      });
    }
  });
})();
