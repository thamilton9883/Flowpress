/* FlowPress admin polish assets */
(function(){
    if (window.pmcpcDashboardSectionInit) { return; }
    window.pmcpcDashboardSectionInit = true;
    document.addEventListener("DOMContentLoaded", function(){
        document.querySelectorAll(".pmcpc-dashboard-group[data-storage-key]").forEach(function(section, index){
            var key = section.getAttribute("data-storage-key") || ("pmcpc_dashboard_group_" + index);
            var button = section.querySelector(".pmcpc-dashboard-group__toggle");
            var body = section.querySelector(".pmcpc-dashboard-group__body");
            if (!button || !body) { return; }
            var bodyId = body.id || ("pmcpc-dashboard-group-body-" + index);
            body.id = bodyId;
            button.setAttribute("aria-controls", bodyId);
            var isOpen = true;
            try {
                var stored = window.localStorage.getItem(key);
                if (stored === "closed") { isOpen = false; }
                else if (stored === "open") { isOpen = true; }
            } catch (err) {}
            var applyState = function(open){
                section.classList.toggle("is-collapsed", !open);
                button.setAttribute("aria-expanded", open ? "true" : "false");
                body.hidden = !open;
            };
            applyState(isOpen);
            button.addEventListener("click", function(){
                isOpen = section.classList.contains("is-collapsed");
                applyState(isOpen);
                try { window.localStorage.setItem(key, isOpen ? "open" : "closed"); } catch (err) {}
            });
        });
        function pmcpcApplyInboxTableView() {
            var table = document.querySelector(".pmcpc-wide-table--inbox");
            if (!table) { return; }
            var state = {};
            try { state = JSON.parse(localStorage.getItem("pmcpc_inbox_table_view_v2") || "{}") || {}; } catch (err) { state = {}; }
            var mode = state.mode === "full" ? "full" : "essential";
            var hidden = Array.isArray(state.hidden) ? state.hidden : [];
            var essentialColumns = ["context", "campaign", "optin", "reason", "ip", "actions"];
            var allColumns = ["date", "context", "campaign", "email", "subject", "optin", "status", "reason", "ip", "actions"];
            allColumns.forEach(function(key){
                var visible = true;
                if (key === "actions") { visible = false; }
                if (mode === "essential" && essentialColumns.indexOf(key) !== -1) { visible = false; }
                if (mode === "full" && hidden.indexOf(key) !== -1) { visible = false; }
                document.querySelectorAll(".pmcpc-inbox-col-" + key).forEach(function(el){
                    el.classList.toggle("pmcpc-inbox-col-hidden", !visible);
                });
            });
            table.classList.toggle("pmcpc-inbox-table-essential", mode === "essential");
            table.classList.toggle("pmcpc-inbox-table-full", mode === "full");
            document.querySelectorAll(".pmcpc-inbox-viewmode-button").forEach(function(button){
                var active = button.getAttribute("data-inbox-view") === mode;
                button.classList.toggle("is-active", active);
                button.setAttribute("aria-pressed", active ? "true" : "false");
            });
            document.querySelectorAll(".pmcpc-inbox-column-toggle").forEach(function(box){
                var key = box.getAttribute("data-column");
                box.checked = hidden.indexOf(key) === -1;
                box.disabled = mode === "essential";
            });
            var bar = document.querySelector(".pmcpc-inbox-viewbar");
            if (bar) { bar.classList.toggle("is-essential", mode === "essential"); }
            if (window.pmcpcRefreshResizableTables) {
                window.setTimeout(window.pmcpcRefreshResizableTables, 0);
            }
        }
        window.pmcpcApplyInboxTableView = pmcpcApplyInboxTableView;
        pmcpcApplyInboxTableView();

        function pmcpcInitInboxSelectedActions() {
            var table = document.querySelector(".pmcpc-wide-table--inbox");
            var block = document.querySelector(".pmcpc-inbox-table-wrap");
            if (!table || !block || table.dataset.pmcpcInboxSelectedActionsReady === "1") { return; }
            table.dataset.pmcpcInboxSelectedActionsReady = "1";
            var bar = document.createElement("div");
            bar.className = "pmcpc-selected-row-actions pmcpc-selected-actions pmcpc-inbox-selected-actions";
            bar.hidden = true;
            bar.innerHTML = '<div class="pmcpc-selected-row-actions__head"><strong>Selected message actions</strong><span class="pmcpc-selected-row-actions__hint">Select one or more messages to keep actions outside the table.</span></div><div class="pmcpc-selected-row-actions__body"></div>';
            block.parentNode.insertBefore(bar, block.nextSibling);
            var body = bar.querySelector(".pmcpc-selected-row-actions__body");
            var hint = bar.querySelector(".pmcpc-selected-row-actions__hint");
            function rowTitle(row) {
                var email = row.querySelector(".pmcpc-inbox-col-email");
                var subject = row.querySelector(".pmcpc-inbox-col-subject");
                var parts = [];
                if (email && email.textContent.trim()) { parts.push(email.textContent.replace(/\s+/g, " ").trim()); }
                if (subject && subject.textContent.trim()) { parts.push(subject.textContent.replace(/\s+/g, " ").trim()); }
                return parts.slice(0, 2).join(" · ") || "Selected message";
            }
            function cloneActions(cell) {
                var holder = document.createElement("div");
                holder.className = "pmcpc-selected-row-actions__links";
                if (!cell) { return holder; }
                Array.prototype.slice.call(cell.querySelectorAll("a,button")).forEach(function(action){
                    if (action.closest && action.closest("summary")) { return; }
                    var clone = action.cloneNode(true);
                    clone.removeAttribute("id");
                    clone.classList.add("pmcpc-outside-row-action");
                    if (clone.tagName && clone.tagName.toLowerCase() === "button") {
                        clone.type = clone.type || "button";
                    }
                    holder.appendChild(clone);
                });
                return holder;
            }
            function render() {
                var rows = Array.prototype.slice.call(table.querySelectorAll("tbody tr")).filter(function(row){
                    var box = row.querySelector("input[name='pmcpc_submission_ids[]']");
                    return box && box.checked;
                });
                body.innerHTML = "";
                if (!rows.length) {
                    bar.hidden = true;
                    return;
                }
                bar.hidden = false;
                hint.textContent = rows.length > 1 ? (rows.length + " messages selected. Showing message-specific actions outside the table.") : "Actions for the selected message.";
                rows.slice(0, 5).forEach(function(row){
                    var group = document.createElement("div");
                    group.className = "pmcpc-selected-row-actions__group";
                    var title = document.createElement("div");
                    title.className = "pmcpc-selected-row-actions__title";
                    title.textContent = rowTitle(row);
                    group.appendChild(title);
                    group.appendChild(cloneActions(row.querySelector(".pmcpc-col-actions")));
                    body.appendChild(group);
                });
                if (rows.length > 5) {
                    var more = document.createElement("p");
                    more.className = "description";
                    more.textContent = "Showing the first 5 selected messages.";
                    body.appendChild(more);
                }
            }
            table.addEventListener("change", function(e){
                if (e.target && e.target.matches && e.target.matches("input[type='checkbox']")) {
                    window.setTimeout(render, 0);
                }
            });
            table.addEventListener("click", function(e){
                if (e.target && e.target.closest && e.target.closest("a,button,input,select,textarea,label")) { return; }
                var row = e.target && e.target.closest ? e.target.closest("tbody tr") : null;
                if (!row || !table.contains(row)) { return; }
                var box = row.querySelector("input[name='pmcpc_submission_ids[]']");
                if (box) {
                    box.checked = !box.checked;
                    render();
                }
            });
            var all = document.getElementById("pmcpc_inbox_cb_all");
            if (all) { all.addEventListener("change", function(){ window.setTimeout(render, 0); }); }
            render();
        }
        pmcpcInitInboxSelectedActions();

        var preview = document.querySelector("[data-pmcpc-scroll-into-view='1']");
        if (preview && window.matchMedia && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
            preview.scrollIntoView({behavior:"smooth", block:"start"});
        } else if (preview) {
            preview.scrollIntoView();
        }

        var wrap = document.querySelector("body.pmcpc-workspace-screen #wpbody-content > .wrap");
        if (wrap) {
            var header = Array.prototype.slice.call(wrap.children).filter(function(el){ return el.classList && el.classList.contains("pmcpc-app-header"); })[0] || null;
            var insertAfter = header;
            function directChildren(selector) {
                return Array.prototype.slice.call(wrap.children).filter(function(el){ return el.matches && el.matches(selector); });
            }
            function moveAfter(el) {
                if (!el || !insertAfter || el === insertAfter) { return; }
                wrap.insertBefore(el, insertAfter.nextSibling);
                insertAfter = el;
            }
            directChildren(".pmcpc-notification-center").forEach(moveAfter);
            directChildren(".pmcpc-help-collapsible--intro,.pmcpc-help-collapsible--hub").forEach(moveAfter);
            directChildren(".pmcpc-stats-strip").slice(0, 1).forEach(moveAfter);
            directChildren(".pmcpc-help-collapsible--support").forEach(moveAfter);
        }
    });
    document.addEventListener("change", function(e){
        var box = e.target && e.target.closest ? e.target.closest(".pmcpc-inbox-column-toggle") : null;
        if (!box) { return; }
        var key = box.getAttribute("data-column");
        if (!key) { return; }
        var state = {};
        try { state = JSON.parse(localStorage.getItem("pmcpc_inbox_table_view_v2") || "{}") || {}; } catch (err) { state = {}; }
        var hidden = Array.isArray(state.hidden) ? state.hidden : [];
        hidden = hidden.filter(function(x){ return x !== key; });
        if (!box.checked) { hidden.push(key); }
        state.hidden = hidden;
        state.mode = "full";
        localStorage.setItem("pmcpc_inbox_table_view_v2", JSON.stringify(state));
        if (window.pmcpcApplyInboxTableView) { window.pmcpcApplyInboxTableView(); }
    });
    document.addEventListener("click", function(e){
        var reset = e.target && e.target.closest ? e.target.closest(".pmcpc-inbox-columns-reset") : null;
        if (reset) {
            e.preventDefault();
            localStorage.removeItem("pmcpc_inbox_hidden_columns");
            localStorage.removeItem("pmcpc_inbox_table_view_v2");
            if (window.pmcpcApplyInboxTableView) { window.pmcpcApplyInboxTableView(); }
            return;
        }
        var inboxViewButton = e.target && e.target.closest ? e.target.closest(".pmcpc-inbox-viewmode-button") : null;
        if (inboxViewButton) {
            e.preventDefault();
            var state = {};
            try { state = JSON.parse(localStorage.getItem("pmcpc_inbox_table_view_v2") || "{}") || {}; } catch (err) { state = {}; }
            state.mode = inboxViewButton.getAttribute("data-inbox-view") === "full" ? "full" : "essential";
            localStorage.setItem("pmcpc_inbox_table_view_v2", JSON.stringify(state));
            if (window.pmcpcApplyInboxTableView) { window.pmcpcApplyInboxTableView(); }
            return;
        }
        var globalAction = e.target && e.target.closest ? e.target.closest("a.pmcpc-global-action") : null;
        if (globalAction) {
            var globalMsg = globalAction.getAttribute("data-pmcpc-confirm") || "";
            if (globalMsg && !window.confirm(globalMsg)) {
                e.preventDefault();
            }
        }
    });
})();

/* Shared Essential / Full table views and outside-the-table row actions. */
(function(){
    if (window.pmcpcUnifiedTableViewsInit) { return; }
    window.pmcpcUnifiedTableViewsInit = true;

    function ready(callback) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback);
        } else {
            callback();
        }
    }

    function toArray(list) {
        return Array.prototype.slice.call(list || []);
    }

    function getPageKey() {
        try {
            return (window.location.pathname || "admin") + "|" + (new URLSearchParams(window.location.search || "").get("page") || "");
        } catch (err) {
            return (window.location.pathname || "admin") + "|" + (window.location.search || "");
        }
    }

    function isVisible(el) {
        if (!el) { return false; }
        var style = window.getComputedStyle ? window.getComputedStyle(el) : null;
        return !style || (style.display !== "none" && style.visibility !== "hidden");
    }

    function isEligibleTable(table) {
        if (!table || table.dataset.pmcpcUnifiedViewReady === "1") { return false; }
        if (table.matches && table.matches(".pmcpc-wide-table--inbox")) { return false; }
        if (table.matches && table.matches(".form-table,[role='presentation'],.pmcpc-subscribers-table")) { return false; }
        if (table.matches && table.matches(".wp-list-table") && !table.matches("[data-pmcpc-table],.pmcpc-wide-table,.pmcpc-automation-table,.pmcpc-subscribers-table")) { return false; }
        if (table.closest && table.closest(".form-table,[role='presentation'],.pmcpc-no-unified-view,.pmcpc-email-history")) { return false; }
        if (!(table.closest && table.closest(".pmcpc-workspace-screen"))) { return false; }
        if (!table.matches || !table.matches("table.widefat,table.pmcpc-wide-table,table.pmcpc-automation-table,table[data-pmcpc-table]")) { return false; }
        return table.querySelectorAll("th").length >= 2;
    }

    function getBestHeaderRow(table) {
        var rows = table.tHead ? toArray(table.tHead.rows) : toArray(table.querySelectorAll("thead tr"));
        var best = null;
        var bestScore = 0;
        rows.forEach(function(row){
            if (!isVisible(row)) { return; }
            var cells = toArray(row.cells).filter(function(cell){ return cell.tagName && cell.tagName.toLowerCase() === "th"; });
            if (cells.length < 2) { return; }
            var colCount = cells.reduce(function(total, cell){ return total + (parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1); }, 0);
            var singleCells = cells.filter(function(cell){ return (parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1) === 1; }).length;
            var score = (singleCells * 100) + colCount;
            if (score > bestScore) {
                best = row;
                bestScore = score;
            }
        });
        return best;
    }

    function getHeaderMeta(row) {
        var meta = [];
        var index = 0;
        toArray(row.cells).forEach(function(cell){
            var span = parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1;
            if (span === 1) {
                meta.push({
                    cell: cell,
                    index: index,
                    label: (cell.textContent || "").replace(/\s+/g, " ").trim(),
                    classes: (cell.className || "").toString()
                });
            }
            index += span;
        });
        return meta;
    }

    function getColumnCount(row) {
        return toArray(row.cells).reduce(function(total, cell){
            return total + (parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1);
        }, 0);
    }

    function getCellAtColumn(row, columnIndex) {
        var cursor = 0;
        var cells = toArray(row.cells);
        for (var i = 0; i < cells.length; i++) {
            var cell = cells[i];
            var span = parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1;
            if (columnIndex >= cursor && columnIndex < cursor + span) {
                return { cell: cell, span: span, start: cursor };
            }
            cursor += span;
        }
        return null;
    }

    function setColumnVisible(table, columnIndex, visible) {
        var colgroups = toArray(table.querySelectorAll("colgroup"));
        colgroups.forEach(function(group){
            var col = group.children[columnIndex];
            if (col) { col.style.display = visible ? "" : "none"; }
        });
        toArray(table.rows).forEach(function(row){
            var found = getCellAtColumn(row, columnIndex);
            if (!found || !found.cell) { return; }
            if (found.span === 1) {
                found.cell.style.display = visible ? "" : "none";
            }
        });
    }

    function tableKey(table, index) {
        var id = table.id ? ("#" + table.id) : "";
        var classes = (table.className || "").toString().replace(/\s+/g, ".").slice(0, 120);
        return "pmcpc_unified_table_view_v3:" + getPageKey() + ":" + index + ":" + id + ":" + classes;
    }

    function readState(key) {
        try {
            var parsed = JSON.parse(window.localStorage.getItem(key) || "{}");
            return parsed && typeof parsed === "object" ? parsed : {};
        } catch (err) {
            return {};
        }
    }

    function saveState(key, state) {
        try { window.localStorage.setItem(key, JSON.stringify(state || {})); } catch (err) {}
    }

    function isCheckColumn(meta) {
        var label = (meta.label || "").toLowerCase();
        return !label || /check-column|column-cb|manage-column/.test(meta.classes || "") || !!(meta.cell && meta.cell.querySelector("input[type='checkbox']"));
    }

    function isActionColumn(meta) {
        var label = (meta.label || "").toLowerCase();
        return /(^|\s)pmcpc-col-actions(\s|$)|column-actions|actions/.test(meta.classes || "") || label === "action" || label === "actions" || label === "selected actions";
    }

    function isImportantColumn(meta) {
        var label = (meta.label || "").toLowerCase();
        return /email|name|title|campaign|subscriber|trigger|status|type|source|created|date|orders|revenue|subject/.test(label);
    }

    function buildEssentialColumns(meta, count, actionIndex) {
        var keep = {};
        var nonAction = meta.filter(function(item){ return item.index !== actionIndex && !isActionColumn(item); });
        nonAction.forEach(function(item){ if (isCheckColumn(item)) { keep[item.index] = true; } });

        var core = nonAction.filter(function(item){ return !isCheckColumn(item); });
        core.slice(0, Math.min(core.length, count <= 6 ? core.length : 3)).forEach(function(item){ keep[item.index] = true; });
        core.forEach(function(item){ if (isImportantColumn(item) && Object.keys(keep).length < 6) { keep[item.index] = true; } });

        if (count <= 6) {
            core.forEach(function(item){ keep[item.index] = true; });
        }
        return keep;
    }

    function ensureTableScrollShell(table) {
        if (!table || !table.parentNode) { return table; }
        var existing = table.closest(".pmcpc-table-scroll,.pmcpc-table-wrap__scroll,.pmcpc-inbox-table-wrap__scroll,.pmcpc-managed-table-scroll,.pmcpc-subscribers-table-shell");
        if (existing) { return existing; }
        var parent = table.parentNode;
        if (parent.classList && parent.classList.contains("pmcpc-managed-table-scroll")) { return parent; }
        var shell = document.createElement("div");
        shell.className = "pmcpc-managed-table-scroll";
        parent.insertBefore(shell, table);
        shell.appendChild(table);
        return shell;
    }

    function findTableBlock(table) {
        return table.closest(".pmcpc-managed-table-scroll,.pmcpc-campaign-table-wrap,.pmcpc-inbox-table-wrap,.pmcpc-reviews-table-wrap,.pmcpc-table-wrap,.pmcpc-table-card") || table;
    }

    function findExistingViewbar(block) {
        var prev = block.previousElementSibling;
        while (prev && prev.nodeType === 1) {
            if (prev.matches && prev.matches(".pmcpc-campaign-viewbar,.pmcpc-inbox-viewbar,.pmcpc-email-history-viewbar,.pmcpc-table-viewbar")) {
                return prev;
            }
            if (prev.matches && prev.matches("h1,h2,h3,p,.notice,.pmcpc-card")) { break; }
            prev = prev.previousElementSibling;
        }
        return null;
    }

    function makeButton(label, view) {
        var button = document.createElement("button");
        button.type = "button";
        button.className = "button pmcpc-table-viewmode-button";
        button.dataset.view = view;
        button.textContent = label;
        return button;
    }

    function insertToolbar(table, block, labels, hasExistingColumnControls) {
        var bar = findExistingViewbar(block);
        if (!bar) {
            bar = document.createElement("div");
            bar.className = "pmcpc-table-viewbar pmcpc-unified-table-viewbar";
            var label = document.createElement("div");
            label.className = "pmcpc-table-viewbar__label";
            label.textContent = "Table view";
            bar.appendChild(label);
            block.parentNode.insertBefore(bar, block);
        } else {
            bar.classList.add("pmcpc-table-viewbar", "pmcpc-managed-viewbar");
        }

        if (!bar.querySelector(".pmcpc-table-viewmode")) {
            var mode = document.createElement("div");
            mode.className = "pmcpc-table-viewmode";
            mode.setAttribute("role", "group");
            mode.setAttribute("aria-label", "Table view");
            mode.appendChild(makeButton("Essential", "essential"));
            mode.appendChild(makeButton("Full", "full"));

            var labelEl = bar.querySelector(".pmcpc-table-viewbar__label,.pmcpc-campaign-viewbar__label,.pmcpc-inbox-viewbar__label,.pmcpc-email-history-viewbar__label");
            if (labelEl && labelEl.nextSibling) {
                bar.insertBefore(mode, labelEl.nextSibling);
            } else {
                bar.appendChild(mode);
            }
        }

        if (!hasExistingColumnControls && !bar.querySelector(".pmcpc-table-column-controls") && labels.length) {
            var controls = document.createElement("details");
            controls.className = "pmcpc-table-column-controls";
            var summary = document.createElement("summary");
            summary.textContent = "Columns";
            controls.appendChild(summary);
            var body = document.createElement("div");
            body.className = "pmcpc-table-column-controls__body";
            labels.forEach(function(item){
                if (isCheckColumn(item)) { return; }
                var label = document.createElement("label");
                label.className = "pmcpc-table-column-toggle-label";
                var input = document.createElement("input");
                input.type = "checkbox";
                input.className = "pmcpc-table-column-toggle";
                input.dataset.columnIndex = String(item.index);
                input.checked = true;
                label.appendChild(input);
                label.appendChild(document.createTextNode(" " + (item.label || ("Column " + (item.index + 1)))));
                body.appendChild(label);
            });
            controls.appendChild(body);
            bar.appendChild(controls);
        }
        return bar;
    }

    function cloneRowActions(actionCell) {
        var holder = document.createElement("div");
        holder.className = "pmcpc-selected-row-actions__links";
        if (!actionCell) { return holder; }
        var actions = toArray(actionCell.querySelectorAll("a,button"));
        if (!actions.length && actionCell.textContent.trim()) {
            holder.textContent = actionCell.textContent.trim();
            return holder;
        }
        actions.forEach(function(action){
            if (action.closest && action.closest("summary")) { return; }
            var clone = action.cloneNode(true);
            clone.removeAttribute("id");
            clone.classList.add("pmcpc-outside-row-action");
            if (clone.tagName && clone.tagName.toLowerCase() === "button") {
                clone.type = clone.type || "button";
            }
            holder.appendChild(clone);
        });
        return holder;
    }

    function rowTitle(row, actionIndex) {
        var pieces = [];
        toArray(row.cells).forEach(function(cell, i){
            if (i === actionIndex || !isVisible(cell)) { return; }
            var text = (cell.textContent || "").replace(/\s+/g, " ").trim();
            if (text) { pieces.push(text); }
        });
        return pieces.slice(0, 2).join(" · ") || "Selected row";
    }

    function initOutsideActions(table, actionIndex, block) {
        if (actionIndex < 0 || table.dataset.pmcpcOutsideActionsReady === "1") { return; }
        table.dataset.pmcpcOutsideActionsReady = "1";
        table.classList.add("pmcpc-has-outside-actions");

        var bar = document.createElement("div");
        bar.className = "pmcpc-selected-row-actions pmcpc-selected-actions";
        bar.hidden = true;
        bar.innerHTML = '<div class="pmcpc-selected-row-actions__head"><strong>Selected row actions</strong><span class="pmcpc-selected-row-actions__hint">Select a row to keep actions outside the table.</span></div><div class="pmcpc-selected-row-actions__body"></div>';
        block.parentNode.insertBefore(bar, block.nextSibling);
        var body = bar.querySelector(".pmcpc-selected-row-actions__body");
        var hint = bar.querySelector(".pmcpc-selected-row-actions__hint");

        function checkedRows() {
            var rows = [];
            toArray(table.querySelectorAll("tbody tr")).forEach(function(row){
                var box = row.querySelector("input[type='checkbox']");
                if (box && box.checked) { rows.push(row); }
            });
            return rows;
        }

        function selectedRows() {
            var checked = checkedRows();
            if (checked.length) { return checked; }
            return toArray(table.querySelectorAll("tbody tr.pmcpc-row-is-selected"));
        }

        function renderActions() {
            var rows = selectedRows().filter(function(row){
                var found = getCellAtColumn(row, actionIndex);
                return found && found.cell && (found.cell.querySelector("a,button") || (found.cell.textContent || "").trim());
            });
            body.innerHTML = "";
            if (!rows.length) {
                bar.hidden = true;
                return;
            }
            bar.hidden = false;
            hint.textContent = rows.length > 1 ? (rows.length + " rows selected. Showing actions outside the table.") : "Actions for the selected row.";
            rows.slice(0, 5).forEach(function(row){
                var found = getCellAtColumn(row, actionIndex);
                var group = document.createElement("div");
                group.className = "pmcpc-selected-row-actions__group";
                var title = document.createElement("div");
                title.className = "pmcpc-selected-row-actions__title";
                title.textContent = rowTitle(row, actionIndex);
                group.appendChild(title);
                group.appendChild(cloneRowActions(found ? found.cell : null));
                body.appendChild(group);
            });
            if (rows.length > 5) {
                var more = document.createElement("p");
                more.className = "description";
                more.textContent = "Showing the first 5 selected rows.";
                body.appendChild(more);
            }
        }

        table.addEventListener("click", function(e){
            if (e.target && e.target.closest && e.target.closest("a,button,input,select,textarea,details,summary,label")) {
                window.setTimeout(renderActions, 0);
                return;
            }
            var row = e.target && e.target.closest ? e.target.closest("tbody tr") : null;
            if (!row || !table.contains(row)) { return; }
            var found = getCellAtColumn(row, actionIndex);
            if (!found || !found.cell) { return; }
            if (!e.ctrlKey && !e.metaKey && !e.shiftKey) {
                toArray(table.querySelectorAll("tbody tr.pmcpc-row-is-selected")).forEach(function(other){
                    if (other !== row) { other.classList.remove("pmcpc-row-is-selected"); other.removeAttribute("aria-selected"); }
                });
            }
            var isSelected = !row.classList.contains("pmcpc-row-is-selected");
            row.classList.toggle("pmcpc-row-is-selected", isSelected);
            if (isSelected) { row.setAttribute("aria-selected", "true"); } else { row.removeAttribute("aria-selected"); }
            renderActions();
        });

        table.addEventListener("change", function(e){
            if (e.target && e.target.matches && e.target.matches("input[type='checkbox']")) {
                window.setTimeout(renderActions, 0);
            }
        });
    }

    function initUnifiedTable(table, index) {
        if (!isEligibleTable(table)) { return; }
        var row = getBestHeaderRow(table);
        if (!row) { return; }
        var count = getColumnCount(row);
        var meta = getHeaderMeta(row);
        if (count < 4 && !meta.some(isActionColumn)) { return; }

        table.dataset.pmcpcUnifiedViewReady = "1";
        table.classList.add("pmcpc-managed-table");

        ensureTableScrollShell(table);
        var actionMeta = meta.filter(isActionColumn)[0] || null;
        var actionIndex = actionMeta ? actionMeta.index : -1;
        var essentialKeep = buildEssentialColumns(meta, count, actionIndex);
        var block = findTableBlock(table);
        var previous = block.previousElementSibling;
        var hasExistingColumnControls = !!(previous && previous.querySelector && previous.querySelector(".pmcpc-campaign-column-toggle,.pmcpc-inbox-column-toggle,.pmcpc-email-history-column-toggle"));
        var toolbar = insertToolbar(table, block, meta, hasExistingColumnControls);
        var key = tableKey(table, index);
        var state = readState(key);
        var mode = state.mode === "full" ? "full" : "essential";
        var hidden = state.hidden && typeof state.hidden === "object" ? state.hidden : {};

        function updateButtons() {
            toArray(toolbar.querySelectorAll(".pmcpc-table-viewmode-button")).forEach(function(button){
                var active = button.dataset.view === mode;
                button.classList.toggle("is-active", active);
                button.setAttribute("aria-pressed", active ? "true" : "false");
            });
        }

        function apply() {
            table.classList.toggle("pmcpc-managed-table-essential", mode === "essential");
            table.classList.toggle("pmcpc-managed-table-full", mode === "full");
            for (var i = 0; i < count; i++) {
                var visible = true;
                if (mode === "essential") {
                    visible = !!essentialKeep[i] && i !== actionIndex;
                } else if (hidden[i]) {
                    visible = false;
                }
                setColumnVisible(table, i, visible);
            }
            toArray(toolbar.querySelectorAll(".pmcpc-table-column-toggle")).forEach(function(box){
                var idx = box.dataset.columnIndex;
                box.checked = !hidden[idx];
                box.disabled = mode === "essential";
            });
            updateButtons();
            if (window.pmcpcRefreshResizableTables) {
                window.setTimeout(window.pmcpcRefreshResizableTables, 0);
            }
        }

        toArray(toolbar.querySelectorAll(".pmcpc-table-viewmode-button")).forEach(function(button){
            button.addEventListener("click", function(){
                mode = button.dataset.view === "full" ? "full" : "essential";
                state.mode = mode;
                saveState(key, state);
                apply();
            });
        });
        toArray(toolbar.querySelectorAll(".pmcpc-table-column-toggle")).forEach(function(box){
            box.addEventListener("change", function(){
                hidden[box.dataset.columnIndex] = !box.checked;
                state.hidden = hidden;
                saveState(key, state);
                apply();
            });
        });

        initOutsideActions(table, actionIndex, block);
        apply();
    }

    function initAllUnifiedTables() {
        toArray(document.querySelectorAll(".pmcpc-workspace-screen table.widefat:not(.form-table):not([role='presentation']):not(.wp-list-table),.pmcpc-workspace-screen table.pmcpc-wide-table,.pmcpc-workspace-screen table.pmcpc-automation-table,.pmcpc-workspace-screen table[data-pmcpc-table]")).forEach(function(table, index){
            initUnifiedTable(table, index);
        });
    }

    ready(initAllUnifiedTables);
})();

/* Compact table column resizing. */
(function(){
    if (window.pmcpcResizableTablesInit) { return; }
    window.pmcpcResizableTablesInit = true;

    function ready(callback) {
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", callback);
        } else {
            callback();
        }
    }

    function toArray(list) {
        return Array.prototype.slice.call(list || []);
    }

    function getPageKey() {
        var params = "";
        try {
            params = new URLSearchParams(window.location.search || "").get("page") || "";
        } catch (err) {
            params = window.location.search || "";
        }
        return (window.location.pathname || "admin") + "|" + params;
    }

    function isVisible(el) {
        if (!el) { return false; }
        var style = window.getComputedStyle ? window.getComputedStyle(el) : null;
        return !style || (style.display !== "none" && style.visibility !== "hidden");
    }

    function isEligibleTable(table) {
        if (!table || table.dataset.pmcpcResizeReady === "1") { return false; }
        if (table.matches && table.matches(".form-table,[role='presentation']")) { return false; }
        if (table.matches && table.matches(".wp-list-table") && !table.matches("[data-pmcpc-table],.pmcpc-wide-table,.pmcpc-automation-table,.pmcpc-subscribers-table")) { return false; }
        if (table.closest && table.closest(".form-table,[role='presentation'],.pmcpc-no-resize")) { return false; }
        if (table.querySelectorAll("th").length < 2) { return false; }
        if (table.matches && table.matches(".pmcpc-wide-table,.pmcpc-subscribers-table,.pmcpc-automation-table,[data-pmcpc-table]")) { return true; }
        return !!(table.closest && table.closest(".pmcpc-workspace-screen") && table.matches("table.widefat"));
    }

    function getBestHeaderRow(table) {
        var rows = table.tHead ? toArray(table.tHead.rows) : toArray(table.querySelectorAll("thead tr"));
        var best = null;
        var bestColCount = 0;
        var bestCellCount = 0;
        rows.forEach(function(row){
            if (!isVisible(row)) { return; }
            var cells = toArray(row.cells).filter(function(cell){ return cell.tagName && cell.tagName.toLowerCase() === "th"; });
            if (cells.length < 2) { return; }
            var colCount = cells.reduce(function(total, cell){ return total + (parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1); }, 0);
            var singleCells = cells.filter(function(cell){ return (parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1) === 1; }).length;
            if (singleCells < 2) { return; }
            if (colCount > bestColCount || (colCount === bestColCount && cells.length > bestCellCount)) {
                best = row;
                bestColCount = colCount;
                bestCellCount = cells.length;
            }
        });
        return best;
    }

    function getColumnCount(row) {
        return toArray(row.cells).reduce(function(total, cell){
            return total + (parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1);
        }, 0);
    }

    function ensureTableScrollShell(table) {
        if (!table || !table.parentNode) { return table; }
        var existing = table.closest(".pmcpc-table-scroll,.pmcpc-table-wrap__scroll,.pmcpc-inbox-table-wrap__scroll,.pmcpc-managed-table-scroll,.pmcpc-subscribers-table-shell");
        if (existing) { return existing; }
        var parent = table.parentNode;
        if (parent.classList && parent.classList.contains("pmcpc-managed-table-scroll")) { return parent; }
        var shell = document.createElement("div");
        shell.className = "pmcpc-managed-table-scroll";
        parent.insertBefore(shell, table);
        shell.appendChild(table);
        return shell;
    }

    function ensureColGroup(table, count) {
        var colgroup = table.querySelector("colgroup");
        if (!colgroup) {
            colgroup = document.createElement("colgroup");
            table.insertBefore(colgroup, table.firstChild);
        }
        while (colgroup.children.length < count) {
            colgroup.appendChild(document.createElement("col"));
        }
        return colgroup;
    }

    function tableStorageKey(table, index) {
        var id = table.id ? ("#" + table.id) : "";
        var classes = (table.className || "").toString().replace(/\s+/g, ".").slice(0, 120);
        return "pmcpc_table_column_widths_v5:" + getPageKey() + ":" + index + ":" + id + ":" + classes;
    }

    function readWidths(key) {
        try {
            var parsed = JSON.parse(window.localStorage.getItem(key) || "{}");
            return parsed && typeof parsed === "object" ? parsed : {};
        } catch (err) {
            return {};
        }
    }

    function saveWidths(key, widths) {
        try { window.localStorage.setItem(key, JSON.stringify(widths || {})); } catch (err) {}
    }

    function currentWidth(col, cell) {
        var width = 0;
        if (col) {
            width = parseFloat((window.getComputedStyle ? window.getComputedStyle(col).width : col.style.width) || "0");
        }
        if ((!width || Number.isNaN(width)) && cell && cell.getBoundingClientRect) {
            width = cell.getBoundingClientRect().width;
        }
        return Math.max(36, Math.round(width || 80));
    }

    function syncColumnVisibility(row, cols) {
        var columnIndex = 0;
        toArray(row.cells).forEach(function(cell){
            var span = parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1;
            if (span === 1 && cols[columnIndex]) {
                cols[columnIndex].style.display = isVisible(cell) ? "" : "none";
            }
            columnIndex += span;
        });
    }

    function applyTableWidth(table, cols) {
        var total = 0;
        toArray(cols).forEach(function(col){
            var style = window.getComputedStyle ? window.getComputedStyle(col) : null;
            if (style && style.display === "none") { return; }
            var width = parseFloat(col.style.width || (style ? style.width : "0"));
            if (width && !Number.isNaN(width)) { total += width; }
        });
        if (total > 0) {
            table.style.width = Math.max(total, table.parentNode ? table.parentNode.clientWidth : total) + "px";
            table.style.minWidth = "100%";
        }
    }

    function initResizableTable(table, index) {
        if (!isEligibleTable(table)) { return; }
        var row = getBestHeaderRow(table);
        if (!row) { return; }

        var count = getColumnCount(row);
        if (count < 2) { return; }

        ensureTableScrollShell(table);
        table.dataset.pmcpcResizeReady = "1";
        table.classList.add("pmcpc-resizable-table");
        table.style.tableLayout = "fixed";
        table.style.minWidth = "100%";

        var colgroup = ensureColGroup(table, count);
        var cols = toArray(colgroup.children).slice(0, count);
        var key = tableStorageKey(table, index);
        var savedWidths = readWidths(key);
        var widths = {};

        var columnIndex = 0;
        toArray(row.cells).forEach(function(cell){
            var span = parseInt(cell.getAttribute("colspan") || cell.colSpan || 1, 10) || 1;
            if (span !== 1) {
                columnIndex += span;
                return;
            }
            var thisIndex = columnIndex;
            var col = cols[thisIndex];
            if (!col) {
                columnIndex += span;
                return;
            }

            var saved = parseFloat(savedWidths[thisIndex]);
            var startWidth = saved && !Number.isNaN(saved) ? saved : currentWidth(col, cell);
            startWidth = Math.max(36, Math.min(900, Math.round(startWidth)));
            col.style.width = startWidth + "px";
            widths[thisIndex] = startWidth;

            if (!cell.querySelector(".pmcpc-col-resize-handle")) {
                var handle = document.createElement("span");
                handle.className = "pmcpc-col-resize-handle";
                handle.setAttribute("role", "separator");
                handle.setAttribute("aria-orientation", "vertical");
                handle.setAttribute("aria-label", "Resize column");
                handle.tabIndex = 0;
                cell.appendChild(handle);

                var dragState = null;
                var beginResize = function(clientX) {
                    dragState = {
                        startX: clientX,
                        startWidth: currentWidth(col, cell),
                        col: col,
                        index: thisIndex
                    };
                    document.body.classList.add("pmcpc-is-resizing-column");
                };
                var moveResize = function(clientX) {
                    if (!dragState) { return; }
                    var next = Math.max(36, Math.min(900, Math.round(dragState.startWidth + (clientX - dragState.startX))));
                    dragState.col.style.width = next + "px";
                    widths[dragState.index] = next;
                    applyTableWidth(table, cols);
                };
                var endResize = function() {
                    if (!dragState) { return; }
                    saveWidths(key, widths);
                    dragState = null;
                    document.body.classList.remove("pmcpc-is-resizing-column");
                };

                handle.addEventListener("mousedown", function(e){
                    e.preventDefault();
                    beginResize(e.clientX);
                    var onMove = function(ev){ moveResize(ev.clientX); };
                    var onUp = function(){
                        document.removeEventListener("mousemove", onMove);
                        document.removeEventListener("mouseup", onUp);
                        endResize();
                    };
                    document.addEventListener("mousemove", onMove);
                    document.addEventListener("mouseup", onUp);
                });
                handle.addEventListener("touchstart", function(e){
                    if (!e.touches || !e.touches.length) { return; }
                    beginResize(e.touches[0].clientX);
                    var onMove = function(ev){
                        if (!ev.touches || !ev.touches.length) { return; }
                        moveResize(ev.touches[0].clientX);
                    };
                    var onEnd = function(){
                        document.removeEventListener("touchmove", onMove);
                        document.removeEventListener("touchend", onEnd);
                        document.removeEventListener("touchcancel", onEnd);
                        endResize();
                    };
                    document.addEventListener("touchmove", onMove, {passive:false});
                    document.addEventListener("touchend", onEnd);
                    document.addEventListener("touchcancel", onEnd);
                }, {passive:true});
                handle.addEventListener("keydown", function(e){
                    if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") { return; }
                    e.preventDefault();
                    var delta = e.key === "ArrowRight" ? 16 : -16;
                    var next = Math.max(36, Math.min(900, currentWidth(col, cell) + delta));
                    col.style.width = next + "px";
                    widths[thisIndex] = next;
                    applyTableWidth(table, cols);
                    saveWidths(key, widths);
                });
            }
            columnIndex += span;
        });
        syncColumnVisibility(row, cols);
        applyTableWidth(table, cols);
    }

    function refreshResizableTable(table) {
        if (!table || table.dataset.pmcpcResizeReady !== "1") { return; }
        var row = getBestHeaderRow(table);
        if (!row) { return; }
        var colgroup = table.querySelector("colgroup");
        if (!colgroup) { return; }
        var cols = toArray(colgroup.children);
        syncColumnVisibility(row, cols);
        applyTableWidth(table, cols);
    }

    function refreshAllResizableTables() {
        toArray(document.querySelectorAll("table.pmcpc-resizable-table")).forEach(function(table){
            refreshResizableTable(table);
        });
    }
    window.pmcpcRefreshResizableTables = refreshAllResizableTables;

    function initAllResizableTables() {
        var selector = ".pmcpc-workspace-screen table.widefat:not(.form-table):not(.wp-list-table), table.pmcpc-wide-table, table.pmcpc-subscribers-table, table.pmcpc-automation-table, table[data-pmcpc-table]";
        toArray(document.querySelectorAll(selector)).forEach(function(table, index){
            initResizableTable(table, index);
        });
    }

    ready(function(){
        initAllResizableTables();
        document.addEventListener("change", function(e){
            if (e.target && e.target.matches && e.target.matches(".pmcpc-subscribers-section-toggle,.pmcpc-inbox-column-toggle,.pmcpc-email-history-column-toggle")) {
                window.setTimeout(function(){ refreshAllResizableTables(); initAllResizableTables(); }, 0);
            }
        });
        document.addEventListener("click", function(e){
            if (e.target && e.target.closest && e.target.closest(".pmcpc-inbox-columns-reset,.pmcpc-email-history-columns-reset")) {
                window.setTimeout(function(){ refreshAllResizableTables(); initAllResizableTables(); }, 0);
            }
        });
    });
})();

/* FlowPress managed tables: checkbox select-all support. */
(function(){
    if (window.pmcpcManagedTableCheckAllInit) { return; }
    window.pmcpcManagedTableCheckAllInit = true;
    function ready(callback) {
        if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", callback); }
        else { callback(); }
    }
    ready(function(){
        document.addEventListener("change", function(event){
            var box = event.target;
            if (!box || !box.matches || !box.matches(".pmcpc-check-all")) { return; }
            var table = box.closest("table");
            if (!table) { return; }
            Array.prototype.slice.call(table.querySelectorAll("tbody input[type='checkbox']")).forEach(function(rowBox){
                rowBox.checked = box.checked;
                rowBox.dispatchEvent(new Event("change", { bubbles: true }));
            });
        });
    });
})();
