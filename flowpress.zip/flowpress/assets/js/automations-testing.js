(function($){
  function debounce(fn, wait){
    var t;
    return function(){
      var ctx = this, args = arguments;
      clearTimeout(t);
      t = setTimeout(function(){ fn.apply(ctx, args); }, wait || 250);
    };
  }

  function setOptions($list, emails){
    $list.empty();
    if(!emails || !emails.length){ return; }
    emails.forEach(function(email){
      if(!email){ return; }
      $list.append($('<option>').attr('value', email));
    });
  }

  function getCenter(){
    return $('[data-pmcpc-testing-center]').first();
  }

  function setCollapsed($center, collapsed){
    if(!$center.length){ return; }
    var $toggle = $center.find('.pmcpc-testing-center__toggle').first();
    var body = $center.find('.pmcpc-testing-center__body').get(0);
    var note = $center.find('.pmcpc-testing-center__collapsed-note').get(0);
    collapsed = !!collapsed;

    $center.toggleClass('is-collapsed', collapsed);
    if(body){ body.hidden = collapsed; }
    if(note){ note.hidden = !collapsed; }

    $toggle.text(collapsed ? PMCPC_PRO_AUTOMATIONS.expand_label : PMCPC_PRO_AUTOMATIONS.collapse_label)
      .attr('aria-expanded', collapsed ? 'false' : 'true');
    try {
      window.localStorage.setItem(PMCPC_PRO_AUTOMATIONS.storage_key, collapsed ? 'collapsed' : 'open');
    } catch(err) {}
  }

  function setActiveTab($center, tab){
    if(!$center.length || !tab){ return; }
    $center.find('.pmcpc-testing-center__tab')
      .removeClass('is-active')
      .attr('aria-selected', 'false');
    $center.find('.pmcpc-testing-center__pane').removeClass('is-active').attr('hidden', 'hidden');
    $center.find('.pmcpc-testing-center__tab[data-pmcpc-tab="' + tab + '"]')
      .addClass('is-active')
      .attr('aria-selected', 'true');
    $center.find('.pmcpc-testing-center__pane[data-pmcpc-pane="' + tab + '"]')
      .addClass('is-active')
      .removeAttr('hidden');
  }

  function bindAutocomplete(){
    var $inputs = $('.pmcpc-email-autocomplete');
    if(!$inputs.length || !$.fn.autocomplete){ return; }

    var $list = $('#pmcpc_pro_subscriber_suggestions');
    if(!$list.length){
      $list = $('<datalist id="pmcpc_pro_subscriber_suggestions"></datalist>').appendTo(document.body);
    }

    $inputs.each(function(){
      var $input = $(this);
      if($input.data('pmcpc-autocomplete-ready')){ return; }
      $input.attr('list', 'pmcpc_pro_subscriber_suggestions');
      $input.data('pmcpc-autocomplete-ready', true);

      var doSearch = debounce(function(){
        var term = ($input.val() || '').trim();
        if(term.length < 2){ setOptions($list, []); return; }
        $.get(PMCPC_PRO_AUTOMATIONS.ajax_url, {
          action: 'pmcpc_pro_subscriber_search',
          nonce: PMCPC_PRO_AUTOMATIONS.nonce,
          term: term
        }).done(function(resp){
          if(resp && resp.success){
            setOptions($list, resp.data || []);
          } else {
            setOptions($list, []);
          }
        }).fail(function(){ setOptions($list, []); });
      }, 250);

      $input.on('input', doSearch);

      $input.autocomplete({
        minLength: 2,
        delay: 200,
        source: function(request, response){
          $.getJSON(PMCPC_PRO_AUTOMATIONS.ajax_url, {
            action: 'pmcpc_pro_subscriber_search',
            nonce: PMCPC_PRO_AUTOMATIONS.nonce,
            term: request.term
          }).done(function(res){
            if(res && res.success && Array.isArray(res.data)){
              response(res.data.map(function(e){ return { label: e, value: e }; }));
            } else {
              response([]);
            }
          }).fail(function(){ response([]); });
        }
      });
    });
  }


  function bindProfileTriggerTest(){
    var $center = getCenter();
    if(!$center.length){ return; }
    var $select = $center.find('.pmcpc-profile-trigger-select').first();
    if(!$select.length){ return; }
    var $birthdayWrap = $center.find('.pmcpc-profile-field-wrap--birthday').first();
    var $annivWrap = $center.find('.pmcpc-profile-field-wrap--anniversary').first();
    var $birthday = $birthdayWrap.find('input').first();
    var $anniv = $annivWrap.find('input').first();
    var $help = $center.find('.pmcpc-profile-trigger-help').first();
    var helpMap = {
      subscriber_birthday: 'Birthday triggers fire when the subscriber birthday month/day matches the evaluation date. The year is ignored.',
      subscriber_anniversary: 'Anniversary triggers fire when the subscriber join date month/day matches the evaluation date. The year is ignored.',
      specific_date: 'Specific-date triggers fire when a scheduled campaign is due on the evaluation date.'
    };
    function sync(){
      var val = $select.val();
      var useBirthday = val === 'subscriber_birthday';
      var useAnniv = val === 'subscriber_anniversary';
      $birthday.prop('disabled', !useBirthday);
      $anniv.prop('disabled', !useAnniv);
      $birthdayWrap.css('opacity', useBirthday ? '1' : '0.55');
      $annivWrap.css('opacity', useAnniv ? '1' : '0.55');
      if(!useBirthday){ $birthday.val(''); }
      if(!useAnniv){ $anniv.val(''); }
      if($help.length){ $help.text(helpMap[val] || helpMap.subscriber_birthday); }
    }
    $select.on('change', sync);
    sync();
  }
  $(function(){
    if(typeof PMCPC_PRO_AUTOMATIONS === 'undefined'){ return; }
    bindAutocomplete();
    bindProfileTriggerTest();

    var $center = getCenter();
    if(!$center.length){ return; }

    var initialCollapsed = false;
    try {
      initialCollapsed = window.localStorage.getItem(PMCPC_PRO_AUTOMATIONS.storage_key) === 'collapsed';
    } catch(err) {}

    setActiveTab($center, $center.find('.pmcpc-testing-center__tab.is-active').data('pmcpc-tab') || 'quick_test');
    setCollapsed($center, initialCollapsed);

    $center.on('click', '.pmcpc-testing-center__toggle', function(e){
      e.preventDefault();
      setCollapsed($center, !$center.hasClass('is-collapsed'));
    });


    $center.on('click', '.pmcpc-copy-debug-report', function(e){
      e.preventDefault();
      var $btn = $(this);
      var report = $btn.attr('data-debug-report') || '';
      var $status = $btn.siblings('.pmcpc-copy-debug-report__status').first();
      function setStatus(msg){ if($status.length){ $status.text(msg); } }
      if(!report){ setStatus('Nothing to copy'); return; }
      if(navigator.clipboard && navigator.clipboard.writeText){
        navigator.clipboard.writeText(report).then(function(){ setStatus('Copied'); }).catch(function(){ setStatus('Copy failed'); });
      } else {
        var $temp = $('<textarea>').css({position:'absolute',left:'-9999px',top:'0'}).val(report).appendTo('body');
        $temp.get(0).select();
        try { document.execCommand('copy'); setStatus('Copied'); } catch(err){ setStatus('Copy failed'); }
        $temp.remove();
      }
    });

    $center.on('click', '.pmcpc-testing-center__tab', function(e){      e.preventDefault();
      var tab = $(this).data('pmcpc-tab');
      setActiveTab($center, tab);
      setCollapsed($center, false);
      var hash = '#pmcpc-tool-' + tab;
      if(window.history && window.history.replaceState){
        window.history.replaceState(null, document.title, window.location.pathname + window.location.search + hash);
      }
    });

    if(window.location.hash.indexOf('#pmcpc-tool-') === 0){
      var hashTab = window.location.hash.replace('#pmcpc-tool-', '');
      if(hashTab){
        setActiveTab($center, hashTab);
        setCollapsed($center, false);
      }
    }
  });
})(jQuery);
