=== FlowPress ===
Contributors: thamilton9883
Tags: email, newsletter, automation, campaigns, woocommerce
Requires at least: 6.3
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.4.24
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Simple WordPress email campaigns, subscriber forms, queues, automations, and optional WooCommerce revenue workflows.

== Description ==

FlowPress helps WordPress site owners create email campaigns and simple automations directly inside WordPress.

It includes subscriber forms, email queue management, SMTP tools, automation dashboards, and workflow-style email sequences. Optional WooCommerce-focused features support abandoned cart, post-purchase, review request, repeat customer, and revenue automation workflows.

**Highlights**

* Create email campaigns directly in WordPress.
* Manage subscribers and opt-in forms.
* Queue sending to reduce timeouts and load spikes.
* Test custom SMTP settings from the admin area.
* Build simple single-step and multi-step email workflows.
* Track opens, clicks, unsubscribes, and queue status.
* Keep data inside your WordPress database by default.

== Free / Core Features ==

* Subscriber list and opt-in forms.
* Manual and scheduled campaigns.
* Email sending queue.
* Open and click tracking.
* Unsubscribe and preferences handling.
* SMTP configuration and test email tool.
* Basic automation dashboard.

== WooCommerce Features ==

WooCommerce-focused features are available in the commercial version from FlowPress.

These may include:

* Abandoned cart recovery.
* Post-purchase follow-up workflows.
* Repeat customer automations.
* High-value customer automations.
* Review request sequences.
* Revenue attribution and WooCommerce insights.

Learn more: https://flowpress.uk/

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install via **Plugins → Add New → Upload Plugin**.
2. Activate the plugin through **Plugins → Installed Plugins**.
3. Go to **FlowPress → Settings** to configure sender details.
4. Configure SMTP before sending live campaigns.
5. Create your first campaign or automation from the FlowPress dashboard.

== Frequently Asked Questions ==

= Does this use a third-party email service? =

No external email marketing SaaS is required by default. Emails are sent using your WordPress site's configured mailer. For best deliverability, use a trusted SMTP provider.

= Where is data stored? =

Subscriber, campaign, queue, and tracking data are stored in your WordPress database.

= Can I use this without WooCommerce? =

Yes. Core email campaign, subscriber, form, and automation features can be used without WooCommerce. WooCommerce-specific automations require WooCommerce.

= Does this replace Mailchimp or Klaviyo? =

FlowPress is not intended to copy every feature of a large email marketing platform. It focuses on simple WordPress-native email automation and WooCommerce workflows.

== Privacy ==

This plugin may store:

* Subscriber data, including email address and optional name.
* Campaign and workflow content.
* Email queue and delivery records.
* Tracking events such as opens, clicks, and unsubscribes.

All data is stored in your WordPress database by default. You are responsible for ensuring your use complies with applicable privacy and email marketing laws.

== Changelog ==

= 1.4.24 =
* GitHub-ready public package refresh.
* Added cleaner README, license, and repository guidance.
